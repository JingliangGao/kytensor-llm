SHELL = /bin/bash

MAJOR ?= 2
MINOR ?= 0
PATCH ?= 16
BUILD ?= 12

