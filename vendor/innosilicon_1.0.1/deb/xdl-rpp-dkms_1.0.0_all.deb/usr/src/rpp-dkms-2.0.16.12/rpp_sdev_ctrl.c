/*
 * This file is part of the Azurengine RPP IP Core driver for Linux
 *
 * Copyright (c) 2016-present,  Azurengine, Inc.
 * All rights reserved.
 *
 * This source code is licensed under both the BSD-style license (found in the
 * LICENSE file in the root directory of this source tree) and the GPLv2 (found
 * in the COPYING file in the root directory of this source tree).
 * You may select, at your option, one of the above-listed licenses.
 */


#include <linux/ioctl.h>
#include <linux/mm.h>
#include <linux/idr.h>
#include <linux/spinlock.h>
#include <asm/cacheflush.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/kfifo.h>

#include "include/version.h"
#include "include/rpp_sdev.h"
#include "include/rpp_pages.h"
#include "include/rpp_cdev_ctrl.h"
#include "include/rpp_vdev_ctrl.h"
#include "include/rpp_sdev_ctrl.h"
#include "include/rpp_dev_list.h"
#include "include/rpp_hal_pcie.h"

#include "include/rpp_dev.h"

#define BUFFER_SIZE 2048

/*
 * character device file operations for control bus (through control bridge)
 */
static ssize_t switch_dev_read(struct file *file, char __user *buf, size_t count,
							   loff_t *pos)
{
	rpp_switch_t *xsdev = (rpp_switch_t *)file->private_data;
	char *info_buffer;
	int info_len;
	u32 w;
	int rv = 0;

	info_buffer = kzalloc(BUFFER_SIZE, GFP_KERNEL);
	if (!info_buffer)
		return -ENOMEM;

	info_len = rpp_sdev_dump(xsdev, info_buffer, sizeof(info_buffer));
	info_len = min(info_len, BUFFER_SIZE); /*  确保不超过实际分配的缓冲区 */

	/*  mutex_unlock(&xsdev->lock); */

	/*  rv = xcdev_check(__func__, xsdev, 0); */
	/*  if (rv < 0) */
	/*  	return rv; */

	if (count > info_len - *pos)
		count = info_len - *pos;

	if (copy_to_user(buf, info_buffer + *pos, count))
	{
		rv = -EFAULT;
		goto out;
	}

	*pos += count;
	rv = count;
out:
	kfree(info_buffer);
	return rv;
}

int switch_ioctl_getparam(struct file* filp, rpp_switch_t *sdev, void *data)
{
	struct switch_param_info *info = data;
	rpp_pcie_link_t lnk_attr = { 0 };
	struct rpp_switch_info switch_info;

	switch (info->param) {
	case SWITCH_GETPARAM_PCIID:
		snprintf((char *)info->value, sizeof(info->value), "%s", sdev->pci_id);
		break;
	case SWITCH_GETPARAM_CHLD_INFO:
		memcpy((void *)info->value, (void *)&sdev->chld, sizeof(struct switch_chld));
		break;
	case SWITCH_GETPARAM_PCIE_LINK:
		lnk_attr.cap_width = (sdev->lnkcap & PCI_EXP_LNKCAP_MLW) >> 4;  /*  capability width */
		lnk_attr.cap_speed = sdev->lnkcap & PCI_EXP_LNKCAP_SLS;         /*  capability speed */
		lnk_attr.sta_width = (sdev->lnksta & PCI_EXP_LNKSTA_NLW) >> 4;  /*  current width */
		lnk_attr.sta_speed = sdev->lnksta & PCI_EXP_LNKSTA_CLS;         /*  current speed */
		DEBUG_PRINT("Switch Cap max: width: %d speed: %d \n", lnk_attr.cap_width, lnk_attr.cap_speed);
		DEBUG_PRINT("Switch Cur sta: width: %d speed: %d \n", lnk_attr.sta_width, lnk_attr.sta_speed);
		memcpy((void *)info->value, (void *)&lnk_attr, sizeof(rpp_pcie_link_t));
		break;
	case SWITCH_GETPARAM_SWITCH_INFO:
		memset(&switch_info, 0, sizeof(switch_info));
		switch_info.switch_id = sdev->switch_idx;
		switch_info.idx_in_switch = 0;  /* N/A for switch device itself */
		switch_info.prefch_mem_start = sdev->bar_mem_start;
		switch_info.prefch_mem_end = sdev->bar_mem_end;
		memcpy((void *)info->value, (void *)&switch_info, sizeof(struct rpp_switch_info));
		break;
	default:
		ERROR_PRINT("Unsupported parameter 0x%llx\n", info->param);
		return -EINVAL;
	}
        return 0;
}

int switch_ioctl_setparam(struct file* filp, rpp_switch_t *sdev, void *data)
{
	struct switch_param_info *info = data;
	struct rpp_dev *pdev = NULL;

	switch (info->param) {
	case SWITCH_CONFIG_SWITCH_REG:
		{
			uint32_t size;
			/* 从 info->value 中读取 size 参数 */
			size = *(uint32_t *)info->value;
			
			if (!sdev->pdev) {
				ERROR_PRINT("No invalid parent switch found!\n");
				return -ENODEV;
			}
			configure_pci_switch_multicast(sdev, size);
		}
		break;
	case SWITCH_CONFIG_BRIDGE_REG:
		{
			uint32_t dev_id, dev_offs, size;
			/* 从 info->value 中读取三个参数：dev_id, dev_offs, size */
			dev_id = *(uint32_t *)(info->value + 0);
			dev_offs = *(uint32_t *)(info->value + 4);
			size = *(uint32_t *)(info->value + 8);
			
			if (dev_id > sdev->chld.num_of_chld) {
				ERROR_PRINT("Invalid child device index %d\n", dev_id);
				return -EINVAL;
			}
			/* 从 switch 的子设备中找到对应的 rpp_dev */
			if (sdev->chld_dev[dev_id] == NULL) {
				ERROR_PRINT("No child device found in switch at index %d!\n", dev_id);
				return -ENODEV;
			}
			pdev = sdev->chld_dev[dev_id];
			configure_pci_brigde_multicast(pdev, dev_offs, size);
		}
		break;
	default:
		ERROR_PRINT("Unsupported parameter 0x%llx\n", info->param);
		return -EINVAL;
	}

	return 0;
}

#define SWITCH_IOCTL_DEF(ioctl, _func) \
    [_IOC_NR(ioctl)] = {.cmd = ioctl, .func = _func, \
            .cmd_drv = 0, .name = #ioctl}

struct switch_ioctl_desc switch_ioctls[] = {
    SWITCH_IOCTL_DEF(SWITCH_IOCTL_GETPARAM,  switch_ioctl_getparam),
    SWITCH_IOCTL_DEF(SWITCH_IOCTL_SETPARAM,  switch_ioctl_setparam),
};

#define SWITCH_IOCTL_COUNT  ARRAY_SIZE(switch_ioctls)


static long switch_dev_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
    rpp_switch_t *xsdev = (rpp_switch_t *)filp->private_data;
    struct rpp_dev *xdev;
    const struct switch_ioctl_desc *ioctl = NULL;
    switch_ioctl_t *func;
    unsigned int nr = SWITCH_IOCTL_NR(cmd);
    int retcode = -EINVAL;
    char stack_kdata[128];
    char *kdata = NULL;
    unsigned int in_size, out_size, ksize;
    int rv = 0;
    rv = xsdev_check(__func__, xsdev, 0);
    if (rv < 0)
    return rv;

    if (nr >= SWITCH_IOCTL_COUNT)
        goto err_i1;
    ioctl = &switch_ioctls[nr];

    rv = down_interruptible(&xsdev->sem);
    if (rv) {
        ERROR_PRINT("%s, interrupted ret=%d\n", __func__, rv);
        retcode = rv;
        goto err_i1;  /* Interrupted */
    }

    out_size = in_size = _IOC_SIZE(cmd);
    if ((cmd & IOC_IN) == 0)
        in_size = 0;
    if ((cmd & IOC_OUT) == 0)
        out_size = 0;
    ksize = max(in_size, out_size);

    /*
    ERROR_PRINT("cmd 0x%x, arg 0x%lx, nr 0x%x, ksize 0x%x, pid=%d, ioctl_name %s\n",
            cmd, arg, nr, ksize, task_pid_nr(current), ioctl->name);
    */

    /* Do not trust userspace, use our own definition */
    func = ioctl->func;

    if (unlikely(!func)) {
        ERROR_PRINT("no function\n");
        retcode = -EINVAL;
        goto err_i1;
    }

    if (ksize <= sizeof(stack_kdata)) {
        kdata = stack_kdata;
    } else {
        kdata = kmalloc(ksize, GFP_KERNEL);
        if (!kdata) {
            retcode = -ENOMEM;
            goto err_i1;
        }
    }

    if (copy_from_user(kdata, (void __user *)arg, in_size) != 0) {
        retcode = -EFAULT;
        goto err_i1;
    }

    if (ksize > in_size)
        memset(kdata + in_size, 0, ksize - in_size);

    retcode = func(filp, xsdev, kdata);
    if (copy_to_user((void __user *)arg, kdata, out_size) != 0)
        retcode = -EFAULT;

err_i1:
    if (!ioctl)
        ERROR_PRINT("%s, invalid ioctl: pid=%d, cmd=0x%02x, nr=0x%02x\n", __func__, task_pid_nr(current), cmd, nr);

    if (kdata != stack_kdata)
        kfree(kdata);

    up(&xsdev->sem);
    return retcode;
}

static int switch_dev_open(struct inode *inode, struct file *file)
{
	rpp_switch_t *xsdev;
	struct rpp_dev *xdev;
	int pid;

	/* pointer to containing structure of the character device inode */
	xsdev = container_of(inode->i_cdev, rpp_switch_t, scdev);
	if (!xsdev) {
		ERROR_PRINT("switch_dev_open: invalid switch device\n");
		return -ENODEV;
	}
	/* create a reference to our char device in the opened file */
	file->private_data = xsdev;

	pid = (int)task_pid_nr(current);
	DEBUG_PRINT("[mm] %s, pid=0x%x\n", __func__, pid);

	return 0;
}

/*
 * Called when the device goes from used to unused.
 */
static int switch_dev_close(struct inode *inode, struct file *file)
{
	rpp_switch_t *xsdev = (rpp_switch_t *)file->private_data;
	int pid;

	if (!xsdev) {
		ERROR_PRINT("switch_dev_close: invalid switch device\n");
		return -ENODEV;
	}

	/* fetch device specific data stored earlier during open */

	pid = (int)task_pid_nr(current);
	DEBUG_PRINT("[mm] %s, pid=0x%x\n", __func__, pid);

	/* if (xdev->async_queue)
		entire_ctrl_fasync(-1, file, 0); */

	return 0;
}

static int switch_dev_mmap(struct file *filp, struct vm_area_struct *vma)
{
	rpp_switch_t *xsdev = (rpp_switch_t *)filp->private_data;
	int rv = 0;

	rv = xsdev_check(__func__, xsdev, 0);
	if (rv < 0)
		return rv;

	/* DEBUG_PRINT("vma->vm_pgoff 0x%lx\n", vma->vm_pgoff); */
	if (vma->vm_pgoff * PAGE_SIZE < 0x1000000) {
		/* 0x0 ~ 0x1000000 (16MB), map to switch bar_mem_start and bar_mem_end */
		return rpp_sdev_remap_pci_bar(xsdev, vma);
	} else {
        ERROR_PRINT("Unsupported mmap address 0x%lx\n", vma->vm_pgoff * PAGE_SIZE);
		return -EINVAL;
	}
}

/*
 * character device file operations for entire control
 */
static const struct file_operations entire_ctrl_fops = {
    .owner = THIS_MODULE,
    .open = switch_dev_open,
    .release = switch_dev_close,
    .read = switch_dev_read,
    .unlocked_ioctl = switch_dev_ioctl,
    .mmap = switch_dev_mmap,
};

void switch_dev_init(rpp_switch_t *xsdev)
{
	cdev_init(&xsdev->scdev, &entire_ctrl_fops);
}
