/*
 * This file is part of the Azurengine DMA IP Core driver for Linux
 *
 * Copyright (c) 2016-present,  Azurengine, Inc.
 * All rights reserved.
 *
 * This source code is licensed under both the BSD-style license (found in the
 * LICENSE file in the root directory of this source tree) and the GPLv2 (found
 * in the COPYING file in the root directory of this source tree).
 * You may select, at your option, one of the above-listed licenses.
 */


#include <linux/fs.h>
#include <linux/list.h>
#include <linux/mm.h>

#include "include/rpp_sdev.h"
#define SWITCH_NODE_NAME "rpp_switch"
#define SWITCH_MINOR_BASE (0)
#define SWITCH_MINOR_COUNT (255)

struct rpp_sdev_info
{
	struct class *switch_class;

	/*  device number info */
	dev_t dev;
	int major;
	int minor_assigned;
	int max_minor_num;
};

int g_rpp_sdev_info_init_flag = 0;
struct rpp_sdev_info g_rpp_sdev_info;
static LIST_HEAD(switch_list);
static DEFINE_MUTEX(switch_list_mutex);

rpp_switch_t glb_switch_tbl[12];
static glb_switch_idx = 0;

int rpp_sdev_info_init(void)
{
	int rv = 0;

	/*  already init, return directly. */
	if (g_rpp_sdev_info_init_flag == 1)
		return 0;

#if LINUX_VERSION_CODE < KERNEL_VERSION(6, 4, 0)
	g_rpp_sdev_info.switch_class = class_create(THIS_MODULE, SWITCH_NODE_NAME);
#else
	g_rpp_sdev_info.switch_class = class_create(SWITCH_NODE_NAME);
#endif
	if (IS_ERR(g_rpp_sdev_info.switch_class))
	{
		ERROR_PRINT(SWITCH_NODE_NAME ": failed to create class");
		return -1;
	}

	/* allocate a dynamically allocated char device node */
	rv = alloc_chrdev_region(&g_rpp_sdev_info.dev, SWITCH_MINOR_BASE, SWITCH_MINOR_COUNT, SWITCH_NODE_NAME);
	if (rv)
	{
		ERROR_PRINT("unable to allocate rpp_switch region %d.\n", rv);
		goto class_destroy_err;
	}

	g_rpp_sdev_info.major = MAJOR(g_rpp_sdev_info.dev);
	g_rpp_sdev_info.minor_assigned = 0;
	g_rpp_sdev_info.max_minor_num = SWITCH_MINOR_COUNT;

	g_rpp_sdev_info_init_flag = 1;

	return 0;

class_destroy_err:
	class_destroy(g_rpp_sdev_info.switch_class);
	g_rpp_sdev_info.switch_class = NULL;
	g_rpp_sdev_info_init_flag = 0;

	return rv;
}

int alloc_sdev_no(dev_t *pdevno)
{
	int rv = 0;
	rv = rpp_sdev_info_init();
	if (rv != 0)
		return rv;

	if (g_rpp_sdev_info.minor_assigned > g_rpp_sdev_info.max_minor_num)
	{
		ERROR_PRINT("there is no dev minor to be allocated\n");
		return -1;
	}

	*pdevno = MKDEV(g_rpp_sdev_info.major, g_rpp_sdev_info.minor_assigned);

	g_rpp_sdev_info.minor_assigned += 1;

	return 0;
}

/** */
enum sdev_type
{
	CHAR_ENTIRE_CTRL,
};

static const char *const devnode_names[] = {
	SWITCH_NODE_NAME "%d",
};

static inline void xsdev_flag_set(struct rpp_dev *xpdev,
				enum xpdev_flags_bits fbit)
{
	xpdev->flags |= 1 << fbit;
}

static inline void xsdev_flag_clear(struct rpp_dev *xpdev,
				enum xpdev_flags_bits fbit)
{
	xpdev->flags &= ~(1 << fbit);
}

static inline int xsdev_flag_test(struct rpp_dev *xpdev,
				enum xpdev_flags_bits fbit)
{
	return xpdev->flags & (1 << fbit);
}

/* create_xsdev() -- create a character device interface to data or control bus
 *
 * If at least one SG DMA engine is specified, the character device interface
 * is coupled to the SG DMA file operations which operate on the data bus. If
 * no engines are specified, the interface is coupled with the control bus.
 */

static int create_sys_sdevice(rpp_switch_t *xsdev)
{
	char name_str[256];

	xsdev->sys_device = device_create(g_rpp_sdev_info.switch_class, &xsdev->pdev->dev,
									   xsdev->devno, NULL, devnode_names[0], xsdev->switch_idx);

	if (!xsdev->sys_device)
	{
		ERROR_PRINT("device_create(%s) failed\n", devnode_names[0]);
		return -1;
	}

	/*  INFO_PRINT("device_create(%s), index %d success. \n", devnode_names[0], xdev->idx); */
	/*  multi cards swp2539 */
	sprintf(name_str, devnode_names[0], xsdev->switch_idx);
	INFO_PRINT("device_create(%s), success.\n", name_str);

	return 0;
}

static int destroy_xsdev(rpp_switch_t *sdev)
{
	if (!sdev) {
		WARNING_PRINT("xsdev NULL.\n");
		return 0;
	}

	INFO_PRINT("destroy_xsdev: start destroying switch_idx=%d (devno=%d:%d, addr=%p)\n",
			sdev->switch_idx, MAJOR(sdev->devno), MINOR(sdev->devno), sdev);


	if (sdev->sys_device) {
		INFO_PRINT("destroy_xsdev: device_destroy devno=%d:%d\n",
				MAJOR(sdev->devno), MINOR(sdev->devno));
		device_destroy(g_rpp_sdev_info.switch_class, sdev->devno);
		sdev->sys_device = NULL;
	}

	if (sdev->scdev.dev)
	{
		INFO_PRINT("cdev_del: devno=%d:%d\n",
				MAJOR(sdev->devno), MINOR(sdev->devno));
		cdev_del(&sdev->scdev);
	}

	if (sdev->devno != 0 && 
		!(sdev->devno == g_rpp_sdev_info.dev && SWITCH_MINOR_COUNT > 1)) {
		INFO_PRINT("destroy_xsdev: unregister devno=%d:%d\n",
				MAJOR(sdev->devno), MINOR(sdev->devno));
		unregister_chrdev_region(sdev->devno, 1);
		sdev->devno = 0;
	}

	INFO_PRINT("destroy_xsdev: destroyed switch_idx=%d successfully\n", sdev->switch_idx);
	/*  kfree(sdev); */

	return 0;
}

void rpp_sdev_info_exit(void)
{
	if (g_rpp_sdev_info_init_flag == 0)
		return;

	rpp_switch_t *rpp_switch, *tmp;
	INFO_PRINT("rpp_sdev_info_exit: start cleaning up all switch nodes\n");

	mutex_lock(&switch_list_mutex);
	uint32_t j = 0;
	/*  list_for_each_entry_safe(rpp_switch, tmp, &switch_list, entry) { */
	for (j = 0; j < 12; j++) {
		rpp_switch = &(glb_switch_tbl[j]);
		if (rpp_switch) {
			/*  list_del(&rpp_switch->entry); */
			destroy_xsdev(rpp_switch);
		}

	}
	mutex_unlock(&switch_list_mutex);

	if (g_rpp_sdev_info.switch_class) {
		INFO_PRINT("rpp_sdev_info_exit: destroy switch_class\n");
		class_destroy(g_rpp_sdev_info.switch_class);
		g_rpp_sdev_info.switch_class = NULL;
	}

	if (g_rpp_sdev_info.major && g_rpp_sdev_info.dev != 0) {
		INFO_PRINT("rpp_sdev_info_exit: unregister global dev region (major=%d, count=%d)\n",
				g_rpp_sdev_info.major, SWITCH_MINOR_COUNT);
		unregister_chrdev_region(g_rpp_sdev_info.dev, SWITCH_MINOR_COUNT);
		g_rpp_sdev_info.major = 0;
		g_rpp_sdev_info.dev = 0;
	}

	g_rpp_sdev_info.minor_assigned = 0;
	g_rpp_sdev_info.max_minor_num = 0;
	g_rpp_sdev_info_init_flag = 0;

	INFO_PRINT("rpp_sdev_info_exit: cleanup completed\n");
}

int xsdev_check(const char *fname, rpp_switch_t *xsdev, bool check_engine)
{
	if (!xsdev) {
		ERROR_PRINT("%s, xsdev 0x%p.\n",fname, xsdev);
		return -EINVAL;
	}
	return 0;
}


static uint64_t rpp_get_switch_prefetchable_mem_base(struct pci_dev *switch_pci_dev, bool get_start)
{
	struct resource *res;

	if (!switch_pci_dev) {
		ERROR_PRINT("%s: bridge is NULL\n", __func__);
		return 0;
	}

	/* PCI_BRIDGE_PREF_MEM_WINDOW = PCI_BRIDGE_RESOURCES + 2 */
	res = &switch_pci_dev->resource[PCI_BRIDGE_RESOURCES + 2];

	if (!res || !res->start || !(res->flags & IORESOURCE_PREFETCH)) {
		ERROR_PRINT("%s: No valid prefetchable memory window found\n", __func__);
		return 0;
	}

	DTRACE("Bridge prefetchable memory: 0x%llx-0x%llx [size=%lldM]\n",
			(uint64_t)res->start, (uint64_t)res->end,
			((uint64_t)res->end - (uint64_t)res->start + 1) / (1024 * 1024));

	if (get_start) {
		return (uint64_t)res->start;
	} else {
		return (uint64_t)res->end;
	}
}


static rpp_switch_t *rpp_sdev_create(struct pci_dev *spdev)
{
	static int switch_id = 0;
	rpp_switch_t *rpp_switch = NULL;
	uint32_t i = 0;
	int rv = 0;
	
	/*  rpp_switch = kzalloc(sizeof(rpp_switch_t), GFP_KERNEL); */
	/*  if (!rpp_switch) { */
	/*  	ERROR_PRINT("create_xsdev: kmalloc failed\n"); */
	/*  	return NULL; */
	/*  } */
	rpp_switch = &(glb_switch_tbl[glb_switch_idx++]);
	memset(rpp_switch, 0, sizeof(rpp_switch_t));
	/*  INIT_LIST_HEAD(&rpp_switch->entry); */

	DEBUG_PRINT("create_xsdev enter:  0x%p.\n", rpp_switch);

	/*
	* do not register yet, create kobjects and name them,
	*/
	
	rpp_switch->pdev = spdev;
	rpp_switch->switch_idx = switch_id++;

	sema_init(&rpp_switch->sem, 1);
	memset(&rpp_switch->chld, 0x0, sizeof(struct switch_chld));
	for (i = 0; i < MAX_CHLD_NUM; i++) {
		rpp_switch->chld_dev[i] = NULL;
	}

	snprintf(rpp_switch->name, sizeof(rpp_switch->name),
			"rpp_switch%d", rpp_switch->switch_idx);
	snprintf(rpp_switch->pci_id, sizeof(rpp_switch->pci_id),
			"%s", pci_name(rpp_switch->pdev));
	
	rpp_switch->bar_mem_start = rpp_get_switch_prefetchable_mem_base(rpp_switch->pdev, true);
	rpp_switch->bar_mem_end = rpp_get_switch_prefetchable_mem_base(rpp_switch->pdev, false);

	/* get parent pci bus link attr */
	pcie_capability_read_dword(rpp_switch->pdev, PCI_EXP_LNKCAP, &rpp_switch->lnkcap);
	uint8_t max_width = (rpp_switch->lnkcap & PCI_EXP_LNKCAP_MLW) >> 4;  /*  pci bus capability width */
	uint8_t max_speed = rpp_switch->lnkcap & PCI_EXP_LNKCAP_SLS;         /*  pci bus capability speed */

	pcie_capability_read_word(rpp_switch->pdev, PCI_EXP_LNKSTA, &rpp_switch->lnksta);
	uint8_t cur_width = (rpp_switch->lnksta & PCI_EXP_LNKSTA_NLW) >> 4;  /*  pci bus currently speed */
	uint8_t cur_speed = rpp_switch->lnksta & PCI_EXP_LNKSTA_CLS;         /*  pci bus currently speed */

	switch_dev_init(rpp_switch);
	rpp_switch->scdev.owner = THIS_MODULE;

	alloc_sdev_no(&rpp_switch->devno);

	/* bring character device live */
	rv = cdev_add(&rpp_switch->scdev, rpp_switch->devno, 1);
	if (rv < 0)
	{
		ERROR_PRINT("cdev_add failed %d.\n", rv);
		goto del_cdev;
	}

	/* create device on our class */
	rv = create_sys_sdevice(rpp_switch);
	if (rv < 0)
		goto del_cdev;

	/*  mutex_lock(&switch_list_mutex); */
	/*  glb_switch_tbl[switch_id - 1] = rpp_switch; */
	/*  list_add_tail(&rpp_switch->entry, &switch_list); */
	/*  mutex_unlock(&switch_list_mutex); */

	INFO_PRINT("create_xsdev success: 0x%p.\n", rpp_switch);

	return rpp_switch;

del_cdev:
	cdev_del(&rpp_switch->scdev);
	destroy_xsdev(rpp_switch);

	return NULL;
}

int rpp_sdev_dump(rpp_switch_t *xsdev, char *buff, uint32_t size_of_buff)
{
	uint32_t i = 0;
	uint32_t k = 0;

	if (xsdev == NULL) {
		return ;
	}

	k = snprintf(buff, size_of_buff,
		"Physical Device: %s\n"
		"Device Node: /dev/%s\n"
		"index: %d\n"
		"lnkcap: %d\n"
		"lnksta: %d\n"
		"Vendor ID: 0x%04x, Device ID: 0x%04x\n"
		"Class Code: 0x%06x\n"
		"Device: %02x, Function: %02x\n"
		"====================\n",
		xsdev->pci_id,
		xsdev->name, xsdev->switch_idx, xsdev->lnkcap, xsdev->lnksta,
		xsdev->pdev->vendor, xsdev->pdev->device,
		xsdev->pdev->class,
		PCI_SLOT(xsdev->pdev->devfn), PCI_FUNC(xsdev->pdev->devfn));

	k += snprintf(buff + k, size_of_buff, "Chld number %d\n", xsdev->chld.num_of_chld);
	for (i = 0; i < xsdev->chld.num_of_chld; i++) {
		k += snprintf(buff + k, size_of_buff, "pci_name=%s, chld_idx=%d, status=%d\n",
			xsdev->chld.chld_tbl[i].chld_pci_name,
			xsdev->chld.chld_tbl[i].chld_idx,
			xsdev->chld.chld_tbl[i].chld_status);
	}

	return k;
}


int rpp_sdev_remap_pci_bar(rpp_switch_t *sdev, struct vm_area_struct *vma)
{
	unsigned long off;
	unsigned long phys;
	unsigned long vsize;
	unsigned long psize;
	uint64_t mem_start, mem_end;
	int rv;

	if (!sdev) {
		ERROR_PRINT("switch device is NULL\n");
		return -ENODEV;
	}

	mem_start = sdev->bar_mem_start;
	mem_end = sdev->bar_mem_end;

	if (mem_start == 0 || mem_end == 0 || mem_start >= mem_end) {
		ERROR_PRINT("Invalid switch memory range: start=0x%llx, end=0x%llx\n",
		       mem_start, mem_end);
		return -ENODEV;
	}

	/* Calculate offset from vma->vm_pgoff to bar_mem_start */
	/* For switch, we assume vma->vm_pgoff is the page offset from a base address */
	/* The offset calculation depends on how the mmap is called */
	/* Here we assume vma->vm_pgoff directly corresponds to offset from bar_mem_start */
	off = (vma->vm_pgoff << PAGE_SHIFT);

	/* Calculate physical address */
	phys = mem_start + off + MC_BASE_ADDR_OFFSET;
	vsize = vma->vm_end - vma->vm_start;
	/* Available size from offset to end of memory range */
	psize = mem_end - mem_start + 1 - off;

	if (phys < mem_start || phys > mem_end) {
		ERROR_PRINT("Physical address 0x%lx is out of range [0x%llx, 0x%llx]\n",
		       phys, mem_start, mem_end);
		return -EINVAL;
	}

	if (vsize > psize) {
		ERROR_PRINT("Requested size 0x%lx exceeds available size 0x%lx\n",
		       vsize, psize);
		return -EINVAL;
	}

	/*
	 * pages must not be cached as this would result in cache line sized
	 * accesses to the end point
	 */
	vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
	/*
	 * prevent touching the pages (byte access) for swap-in,
	 * and prevent the pages from being swapped out
	 */
#if LINUX_VERSION_CODE < KERNEL_VERSION(6,3,0)
	vma->vm_flags |= (VM_IO | VM_DONTEXPAND | VM_DONTDUMP);
#else
	vm_flags_set(vma, VM_IO | VM_DONTEXPAND | VM_DONTDUMP);
#endif
	/* make MMIO accessible to user space */
	rv = io_remap_pfn_range(vma, vma->vm_start, phys >> PAGE_SHIFT,
			vsize, vma->vm_page_prot);

	if (rv)
		return -EAGAIN;
	return 0;
}
EXPORT_SYMBOL_GPL(rpp_sdev_remap_pci_bar);

int rpp_sdev_add_devices(struct rpp_dev *xpdev)
{
	int rv = 0;
	rpp_switch_t *rpp_switch=NULL;
	rpp_switch_t *next_switch=NULL;
	struct rpp_dev *test;
	static int switch_id = 0;
	static int dev_idx = 1;
	bool is_switch_exist = false;
	uint32_t idx_in_switch = 0;
	uint32_t i = 0;

	if ((xpdev->pdev->bus->parent == NULL) || (xpdev->pdev->bus->parent->self == NULL)) {
		DEV_DEBUG(xpdev, "No parent for xpdev\n");
		return 0;
	}

	if((xpdev->pdev->bus->parent->self->vendor != SWITCH_VENDOR_ID) || (xpdev->pdev->bus->parent->self->device != SWITCH_DEVICE_ID)) {
		DEV_DEBUG(xpdev, "The parent(%04x:%04x) of xpdev not match to rpp switch(%04x:%04x)\n",
			xpdev->pdev->bus->parent->self->vendor, xpdev->pdev->bus->parent->self->device, SWITCH_VENDOR_ID, SWITCH_DEVICE_ID);
		return 0;
	}

	mutex_lock(&switch_list_mutex);
	is_switch_exist = false;
	uint32_t j = 0;
	for (j = 0; j < glb_switch_idx; j++) {
		rpp_switch = &(glb_switch_tbl[j]);
		if ((rpp_switch != NULL) && (rpp_switch->pdev == xpdev->pdev->bus->parent->self))
		{
			DEV_DEBUG(xpdev, "Found existing switch %p, switch_idx=%d\n", rpp_switch, rpp_switch->switch_idx);

			is_switch_exist = true;
			mutex_unlock(&switch_list_mutex);

			for (i = 0; i < rpp_switch->chld.num_of_chld; i++) {
				if (strcmp(rpp_switch->chld.chld_tbl[i].chld_pci_name, pci_name(xpdev->pdev)) == 0) {
					break;
				}
			}
			if (i >= rpp_switch->chld.num_of_chld) {
				DEV_DEBUG(xpdev, "Add new chld in switch %d, chld_idx=%d, child_name=%s\n", rpp_switch->switch_idx, xpdev->idx, pci_name(xpdev->pdev));
				rpp_switch->chld.num_of_chld++;
			} else {
				DEV_DEBUG(xpdev, "Update chld in switch %d, chld_idx=%d, child_name=%s\n", rpp_switch->switch_idx, xpdev->idx, pci_name(xpdev->pdev));
			}

			idx_in_switch = i;

			rpp_switch->chld.chld_tbl[idx_in_switch].chld_idx = xpdev->idx;
			rpp_switch->chld.chld_tbl[idx_in_switch].chld_status = xpdev->status;
			snprintf((char *)rpp_switch->chld.chld_tbl[idx_in_switch].chld_pci_name, 
				 sizeof(rpp_switch->chld.chld_tbl[idx_in_switch].chld_pci_name), 
				 "%s", pci_name(xpdev->pdev));
			rpp_switch->chld_dev[idx_in_switch] = xpdev;

			xpdev->parent_switch = rpp_switch;
			xpdev->switch_pcidev = xpdev->pdev->bus->parent->self;
			xpdev->bridge_pcidev = xpdev->pdev->bus->self;
			xpdev->switch_idx = rpp_switch->switch_idx;
			xpdev->idx_in_switch = idx_in_switch;

			/*  uint8_t buff[2048]; */
			/*  memset(buff, 0x0, sizeof(buff)); */
			/*  rpp_sdev_dump(rpp_switch, buff, sizeof(buff)); */
			/*  INFO_PRINT("%s\n", buff); */

			/*  parent pci id info */
			DEV_INFO(xpdev, "Parent Switch: %s\n", pci_name(xpdev->switch_pcidev));
			DEV_INFO(xpdev, "Parent Bridge: %s\n", pci_name(xpdev->bridge_pcidev));
			DEV_INFO(xpdev, "  Vendor ID: 0x%04x, Device ID: 0x%04x\n",
				xpdev->switch_pcidev->vendor, xpdev->switch_pcidev->device);
			DEV_INFO(xpdev,"  Class Code: 0x%06x\n", xpdev->switch_pcidev->class);
			DEV_INFO(xpdev,"  Bus: %02x, Device: %02x, Function: %02x\n",
				xpdev->switch_pcidev->bus->number,
								PCI_SLOT(xpdev->switch_pcidev->devfn),
								PCI_FUNC(xpdev->switch_pcidev->devfn));

			return 0;
		}
	}
	mutex_unlock(&switch_list_mutex);

	if (!is_switch_exist) {
		/*  rpp_switch not exist */
		rpp_switch = rpp_sdev_create(xpdev->pdev->bus->parent->self);

		DEV_DEBUG(xpdev, "Add new chld in switch %d, chld_idx=%d, child_name=%s\n", rpp_switch->switch_idx, xpdev->idx, pci_name(xpdev->pdev));
		rpp_switch->chld.chld_tbl[0].chld_idx = xpdev->idx;
		rpp_switch->chld.chld_tbl[0].chld_status = xpdev->status;
		snprintf((char *)rpp_switch->chld.chld_tbl[0].chld_pci_name, 
			 sizeof(rpp_switch->chld.chld_tbl[0].chld_pci_name), 
			 "%s", pci_name(xpdev->pdev));
		rpp_switch->chld_dev[0] = xpdev;
		rpp_switch->chld.num_of_chld++;
	
		xpdev->parent_switch = rpp_switch;
		xpdev->switch_pcidev = xpdev->pdev->bus->parent->self;
		xpdev->bridge_pcidev = xpdev->pdev->bus->self;
		xpdev->switch_idx = rpp_switch->switch_idx;
		xpdev->idx_in_switch = 0;

		/*  uint8_t buff[2048]; */
		/*  memset(buff, 0x0, sizeof(buff)); */
		/*  rpp_sdev_dump(rpp_switch, buff, sizeof(buff)); */
		/*  INFO_PRINT("%s\n", buff); */

		/*  parent pci id info */
		DEV_INFO(xpdev, "Parent Switch: %s\n", pci_name(xpdev->switch_pcidev));
		DEV_INFO(xpdev, "Parent Bridge: %s\n", pci_name(xpdev->bridge_pcidev));
		DEV_INFO(xpdev, "  Vendor ID: 0x%04x, Device ID: 0x%04x\n",
			xpdev->switch_pcidev->vendor, xpdev->switch_pcidev->device);
		DEV_INFO(xpdev,"  Class Code: 0x%06x\n", xpdev->switch_pcidev->class);
		DEV_INFO(xpdev,"  Bus: %02x, Device: %02x, Function: %02x\n",
						xpdev->switch_pcidev->bus->number,
							PCI_SLOT(xpdev->switch_pcidev->devfn),
							PCI_FUNC(xpdev->switch_pcidev->devfn));
	}

	return rv;
}

rpp_switch_t *rpp_sdev_search_by_devices(struct rpp_dev *xpdev)
{
	rpp_switch_t *rpp_switch = NULL;

	if (xpdev == NULL) {
		return NULL;
	}

	if ((xpdev->pdev->bus->parent == NULL) || (xpdev->pdev->bus->parent->self == NULL)) {
		DEV_DEBUG(xpdev, "No parent for xpdev\n");
		return NULL;
	}

	if((xpdev->pdev->bus->parent->self->vendor != SWITCH_VENDOR_ID) || (xpdev->pdev->bus->parent->self->device != SWITCH_DEVICE_ID)) {
		DEV_DEBUG(xpdev, "The parent(%04x:%04x) of xpdev not match to rpp switch(%04x:%04x)\n",
			xpdev->pdev->bus->parent->self->vendor, xpdev->pdev->bus->parent->self->device, SWITCH_VENDOR_ID, SWITCH_DEVICE_ID);
		return NULL;
	}

	if ((xpdev->switch_idx == SWITCH_IDX_INVALID) || (xpdev->switch_idx >= glb_switch_idx)) {
		DEV_DEBUG(xpdev, "switch_idx 0x%x is out of range \n", xpdev->switch_idx);
		return NULL;
	}

	rpp_switch = &(glb_switch_tbl[xpdev->switch_idx]);
	if ((rpp_switch == NULL) || (rpp_switch->pdev != xpdev->pdev->bus->parent->self)) {
		return NULL;
	}

	return rpp_switch;
}

int rpp_sdev_remove_devices(struct rpp_dev *xpdev)
{
	int rv = 0;
	uint32_t i = 0;
	rpp_switch_t *rpp_switch = rpp_sdev_search_by_devices(xpdev);

	DEV_DEBUG(xpdev, "Remove chld from switch %d, chld_idx=%d, child_name=%s\n", xpdev->switch_idx, xpdev->idx, pci_name(xpdev->pdev));
	if (rpp_switch == NULL) {
		return 0;
	}

	for (i = 0; i < rpp_switch->chld.num_of_chld; i++) {
		if ((rpp_switch->chld.chld_tbl[i].chld_idx == xpdev->idx) && 
			(strcmp(rpp_switch->chld.chld_tbl[i].chld_pci_name, pci_name(xpdev->pdev)) == 0)) {
				rpp_switch->chld.chld_tbl[i].chld_idx = xpdev->idx;
				rpp_switch->chld.chld_tbl[i].chld_status = xpdev->status;
				snprintf((char *)rpp_switch->chld.chld_tbl[i].chld_pci_name, 
					 sizeof(rpp_switch->chld.chld_tbl[i].chld_pci_name), 
					 "%s", pci_name(xpdev->pdev));
				rpp_switch->chld_dev[i] = NULL;
				xpdev->parent_switch = NULL;
				xpdev->switch_pcidev = NULL;
				xpdev->bridge_pcidev = NULL;
				xpdev->switch_idx = SWITCH_IDX_INVALID;
				xpdev->idx_in_switch = 0;
		}
	}

	/*  uint8_t buff[2048]; */
	/*  memset(buff, 0x0, sizeof(buff)); */
	/*  rpp_sdev_dump(rpp_switch, buff, sizeof(buff)); */
	/*  INFO_PRINT("%s\n", buff); */

	return 0;
}
