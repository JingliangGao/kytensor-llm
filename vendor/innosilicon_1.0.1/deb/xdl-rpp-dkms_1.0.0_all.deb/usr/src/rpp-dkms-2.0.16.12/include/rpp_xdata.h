/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright (c) 2018 Synopsys, Inc. and/or its affiliates.
 * Synopsys DesignWare eDMA controller driver.
 */

#ifndef __RPP_XDATA_H__
#define __RPP_XDATA_H__

#include "rpp_types.h"
#include "rpp_dma.h"
#include <linux/types.h>

/*******************************************************************************
 *
 * MACRO DEFINITIONS
 *
 ******************************************************************************/
/**
 * xData Buffers
 */
#define XDATA_BUF_SIZE         8192
#define XDATA_BUF_DWORD_LEN    2048

/**
 *  xData Register Access Macros
 */
#define XDRP(rsc) ((PXDATA_REGS)((rsc)->xDataRegs))

#define XDATA_READ_STATUS(rsc)       RPP_READ_UINT32( (&(XDRP(rsc)->STATUS))    )
#define XDATA_READ_ADDR_LO(rsc)      RPP_READ_UINT32( (&(XDRP(rsc)->ADDR_LO))   )
#define XDATA_READ_ADDR_HI(rsc)      RPP_READ_UINT32( (&(XDRP(rsc)->ADDR_HI))   )
#define XDATA_READ_BURST_CNT(rsc)    RPP_READ_UINT32( (&(XDRP(rsc)->BURST_CNT)) )
#define XDATA_READ_CTRL(rsc)         RPP_READ_UINT32( (&(XDRP(rsc)->CTRL))      )
#define XDATA_READ_PATTERN(rsc)      RPP_READ_UINT32( (&(XDRP(rsc)->PATTERN))   )
#define XDATA_READ_RAM_ADDR(rsc)     RPP_READ_UINT32( (&(XDRP(rsc)->RAM_ADDR))  )
#define XDATA_READ_RAM_PORT(rsc)     RPP_READ_UINT32( (&(XDRP(rsc)->RAM_PORT))  )
#define XDATA_READ_SWITCHES(rsc)     RPP_READ_UINT32( (&(XDRP(rsc)->SWITCHES))  )
#define XDATA_READ_BURSTS(rsc)       RPP_READ_UINT32( (&(XDRP(rsc)->BURSTS))    )

#define XDATA_WRITE_STATUS(rsc,v)    RPP_WRITE_UINT32( (&(XDRP(rsc)->STATUS)),    (v) )
#define XDATA_WRITE_ADDR_LO(rsc,v)   RPP_WRITE_UINT32( (&(XDRP(rsc)->ADDR_LO)),   (v) )
#define XDATA_WRITE_ADDR_HI(rsc,v)   RPP_WRITE_UINT32( (&(XDRP(rsc)->ADDR_HI)),   (v) )
#define XDATA_WRITE_BURST_CNT(rsc,v) RPP_WRITE_UINT32( (&(XDRP(rsc)->BURST_CNT)), (v) )
#define XDATA_WRITE_CTRL(rsc,v)      RPP_WRITE_UINT32( (&(XDRP(rsc)->CTRL)),      (v) )
#define XDATA_WRITE_PATTERN(rsc,v)   RPP_WRITE_UINT32( (&(XDRP(rsc)->PATTERN)),   (v) )
#define XDATA_WRITE_RAM_ADDR(rsc,v)  RPP_WRITE_UINT32( (&(XDRP(rsc)->RAM_ADDR)),  (v) )
#define XDATA_WRITE_RAM_PORT(rsc,v)  RPP_WRITE_UINT32( (&(XDRP(rsc)->RAM_PORT)),  (v) )
#define XDATA_WRITE_SWITCHES(rsc,v)  RPP_WRITE_UINT32( (&(XDRP(rsc)->SWITCHES)),  (v) )
#define XDATA_WRITE_BURSTS(rsc,v)    RPP_WRITE_UINT32( (&(XDRP(rsc)->BURSTS)),    (v) )

/*******************************************************************************
 *
 * DATA STRUCTURE DEFINITIONS
 *
 ******************************************************************************/

/**
 *  Extra Data Engine Parameters
 */
typedef struct _XDATA_RSC {
	                                    /**< Extra Data parameters */
    PVOID            xDataRegs;         /**< xData control regs */
    UINT32           xDataMemSize;      /**< xData buffer size */
    PHYADDR          xDataMemPa;        /**< xData system buffer phy addr */
    PUINT32          xDataMemVa;        /**< xData system buffer virtual addr */
    dma_addr_t       xDataBus;
    UINT32           xDataMaxReadLen;   /**< xData max xfer burst len */
    UINT32           xDataMaxWriteLen;  /**< xData max xfer burst len */
    UINT32           xDataLocMemSize;   /**< xData local buffer size */
    PHYADDR          xDataLocMemPa;     /**< xData local buffer phy addr */
    PUINT32          xDataLocMemVa;     /**< xData local buffer virtual addr */
    BOOLEAN          xDataDownstreamRun;/**< xData downstream work flag  */

} XDATA_RSC, *PXDATA_RSC;

typedef enum
{
   XDATA_SUCCESS = 0,
   XDATA_ERROR   = 1,
} XDATA_RET;

/**
 *  xData Registers
 */
typedef union _XDATA_CTRL {

	struct {
		/* LSB */
		UINT32      DBELL     :1;  /* 0 */
		UINT32      IS_WRITE  :1;  /* 1 */
		UINT32      LENGTH    :12; /* 2:13 */
		UINT32      IS_64     :1;  /* 14 */
		UINT32      EP        :1;  /* 15 */
		UINT32      PATINC    :1;  /* 16 */
		UINT32      IE        :1;  /* 17 */
		UINT32      NOADDRINC :1;  /* 18 */
		UINT32      TRIGGER   :1;  /* 19 */
		UINT32      Reserved0 :12; /* 20:31 */
		/* MSB */
	};

    UINT32 AsUint32;
} XDATA_CTRL, *PXDATA_CTRL;

typedef union _XDATA_STATUS {

	struct {
		/* LSB */
		UINT32      DONE      :1;
		UINT32      Reserved0 :15;
		UINT32      VERSION   :16;
		/* MSB */
	};

    UINT32 AsUint32;
} XDATA_STATUS, *PXDATA_STATUS;


typedef struct _XDATA_REGISTERS{

	UINT32           ADDR_LO;   /* 0x00 */
	UINT32           ADDR_HI;   /* 0x04 */
	UINT32           BURST_CNT; /* 0x08 */
	XDATA_CTRL       CTRL;      /* 0x0c */
	UINT32           PATTERN;   /* 0x10 */
	XDATA_STATUS     STATUS;    /* 0x14 */
	UINT32           RAM_ADDR;  /* 0x18 */
	UINT32           RAM_PORT;  /* 0x1c */
	UINT32           rsvd;      /* 0x20 (was LED ctrl on old board) */
	UINT32           SWITCHES;  /* 0x24 */
	UINT32           BURSTS;    /* 0x28 */

} XDATA_REGS, *PXDATA_REGS;


/*******************************************************************************
 *
 * XDATA ENGINE API FUNCTIONS
 *
 ******************************************************************************/

/**
* @defgroup xdata_api XDATA ENGINE APIs.
* @{
* The functions in this group are XDATA engine APIs. All of them are defined
* in RPP_xdata.c
*/
XDATA_RET xDataInit( PXDATA_RSC rsc, UINT32 ReadMTU, UINT32 WriteMTU );
XDATA_RET xDataStartXfer( PXDATA_RSC rsc, BOOLEAN isWrite, BOOLEAN isUpstream,
        char *ResMsg );
XDATA_RET xDataStopXfer( PXDATA_RSC rsc, BOOLEAN isUpstream, char *ResMsg );
XDATA_RET xDataStatus( PXDATA_RSC rsc, char *ResMsg );
/** @}*/

#endif  /* __RPP_XDATA_H__ */
