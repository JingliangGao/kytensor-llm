/*
 * This file is part of the Azurengine DMA IP Core driver for Linux
 *
 * Copyright (c) 2016-present,  Azurengine, Inc.
 * All rights reserved.
 *
 * This source code is licensed under both the BSD-style license (found in the
 * LICENSE file in the root directory of this source tree) and the GPLv2 (found
 * in the COPYING file in the root directory of this source tree).
 * You may select, at your option, one of the above-listed licenses.
 */

#ifndef __RPP_CDEV_CTRL_H__
#define __RPP_CDEV_CTRL_H__

#include <linux/ioctl.h>

#include "rpp_com.h"
#include "rpp_dev.h"

/* Use 'x' as magic number */
#define RPP_IOC_MAGIC	'x'


/*
 * S means "Set" through a ptr,
 * T means "Tell" directly with the argument value
 * G means "Get": reply by setting through a pointer
 * Q means "Query": response is on the return value
 * X means "eXchange": switch G and S atomically
 * H means "sHift": switch T and Q atomically
 *
 * _IO(type,nr)		    no arguments
 * _IOR(type,nr,datatype)   read data from driver
 * _IOW(type,nr.datatype)   write data to driver
 * _IORW(type,nr,datatype)  read/write data
 *
 * _IOC_DIR(nr)		    returns direction
 * _IOC_TYPE(nr)	    returns magic
 * _IOC_NR(nr)		    returns number
 * _IOC_SIZE(nr)	    returns size
 */
#define RPP_DRM_HEADER_PATCHLEVEL 1

#define RPP_SETPARAMS_MASK      0xFFFF0000

/*  get parameters */
#define RPP_GETPARAM_BUSID          1
#define RPP_GETPARAM_BARTYPE        2
#define RPP_GETPARAM_VDEV_MEMINFO	3
#define RPP_GETPARAM_BARSIZE		4
#define RPP_GETPARAM_BLCONFIG       5
#define RPP_GETPARAM_PWR_MODE 		6
#define RPP_GETPARAM_WORK_MODE 		7
#define RPP_GETPARAM_IDLEDET_MODE 	8
#define RPP_GETPARAM_PARENT_PCI 	9
#define RPP_GETPARAM_PARENT_PCI_LNK 10
#define RPP_GETPARAM_SWITCH_INFO    11
#define RPP_GETPARAM_DRV_VERSION	12
#define RPP_GETPARAM_MCU_VERSION    13

/*  set parameters */
#define RPP_SETPARAM_PWR_MODE 		(1 << 16)
#define RPP_SETPARAM_WORK_MODE 		(2 << 16)
#define RPP_SETPARAM_IDLEDET_MODE (3 << 16)
#define RPP_CONFIG_SWITCH_REG    (4 << 16)
#define RPP_CONFIG_BRIDGE_REG    (5 << 16)

#ifndef RPP_CORE_FRAM_PARA_SIZE
#define RPP_CORE_FRAM_PARA_SIZE  128
#endif

struct rpp_param_info {
	uint64_t param;		/* < */
	uint8_t value[128];		/* > */
};

struct dma_mapped_blk {
	uint64_t dma_address;
	uint32_t dma_length;
};

/* used for pages_new and pages_info */
struct rpp_shm_info {	/* n i */
	uint64_t shm_addr;	/* < */
	uint64_t size;	/* < */
	int32_t handle;	/* > < */
	/* offset inside drm fd's vm space usable for mmapping */
	uint64_t map_handle;	/* > < */
	/* the max size of linux ioctl is 2^14 = 16K */
	/* so the map total size = 512 * PAGE_SIZE = 2M */
	uint64_t phys_addr; /* > */
	uint32_t mapped_num;
	unsigned long mapped_info; /* > */
};

struct rpp_xfer_info {
	uint32_t host_handle;	/* < */
	uint64_t host_offs; /* < */
	uint64_t dev_addr; /* < */
	uint32_t size;      /* < */
};

struct rpp_xfer_desc_info {
	uint32_t host_handle;	/* < MAP_SHM handle */
	uint64_t host_offs;	/* < offset in mapped host buffer */
	uint64_t dev_addr;	/* < device address */
	uint32_t size;		/* < transfer size */
	uint32_t dirc;		/* < DMA_WRITE: H2D, DMA_READ: D2H */
};

/* used for pages_new and pages_info */
struct rpp_pages_info {	/* n i */
	int32_t handle;	/* > < */
	uint64_t size;		/* < > */
	/* offset inside drm fd's vm space usable for mmapping */
	uint64_t map_handle;	/* > < */
};

/* used for pages_new and pages_info */
struct rpp_conn_info {	/* n i */
	long pid;	/* < */
};

#define RPP_SINGLE_ADDR_USER_VA		0x00000001
#define RPP_SINGLE_ADDR_PHYS		0x00000004
#define RPP_SINGLE_ADDR_MASK		0x00000005

#define RPP_SINGLE_DIR_TO_DEV		0x00000010
#define RPP_SINGLE_DIR_FROM_DEV		0x00000020
#define RPP_SINGLE_DIR_BIDIR		0x00000030
#define RPP_SINGLE_DIR_MASK		0x00000030

struct rpp_single_map_info {
	uint64_t addr;		/* < user VA or host physical address */
	uint64_t size;		/* < */
	uint32_t flags;		/* < RPP_SINGLE_ADDR_* | RPP_SINGLE_DIR_* */
	int32_t handle;		/* > < */
	uint64_t dma_addr;	/* > PCIe bus address */
	uint64_t host_phys;	/* > host physical address of buffer base */
	uint64_t map_handle;	/* > mmap offset, same encoding as rpp_shm_info */
};

/* switch information structure */
struct rpp_switch_info {
	uint32_t switch_id;	/* switch ID */
	uint32_t idx_in_switch;	/* device index in switch */
	uint32_t reserved[2];	/* reserved for future expansion */
	uint64_t prefch_mem_start; /* switch BAR start address */
	uint64_t prefch_mem_end;   /* switch BAR end address */
};

#define RPP_BO_CONTIG				0x00000001	/* needs to be contiguous in VRAM */
#define RPP_BO_MAPPABLE				0x00000002	/* intended to be mmapped by host */
#define RPP_BO_PHYSADDR				0x00000004	/* Provide the physical address */

#define RPP_BO_MEMTYPE_MASK			0x00000f00
#define RPP_BO_DEV_MEM_SMALL		0x00000100	/* VRAM with small pages */
#define RPP_BO_HOST_MEM_SNOOP		0x00000200
#define RPP_BO_DEV_MEM_LARGE		0x00000300	/* VRAM with large pages */
#define RPP_BO_HOST_MEM_NOSNOOP		0x00000400
#define RPP_BO_DEV_KFUNC_SMALL		0x00000500	/* DEV Kernel function with small pages */
#define RPP_BO_DEV_KFUNC_LARGE		0x00000600	/* DEV Kernel function with large pages */
#define RPP_BO_DEV_KPARA_SMALL		0x00000700	/* DEV Kernel parameters with small pages */
#define RPP_BO_DEV_KPARA_LARGE		0x00000800	/* DEV Kernel parameters with large pages */
#define RPP_BO_DEV_SRAM_SMALL		0x00000900	/* DEV SRAM with small pages */
#define RPP_BO_DEV_SRAM_LARGE		0x00000a00	/* DEV SRAM with large pages */
#define RPP_BO_GART					RPP_BO_HOST_MEM_SNOOP	/* compat */


enum rpp_bus_type {
	PCIE    = 0,
};

/**
 * Ioctl function type.
 *
 * \param p amdkfd process pointer.
 * \param data pointer to arg that was copied from user.
  * \param filep pointer to file structure.
 */
typedef int rpp_ioctl_t(struct file *filp, struct rpp_dev *pdev, void *data);

struct rpp_ioctl_desc {
	unsigned int cmd;
	int flags;
	rpp_ioctl_t *func;
	unsigned int cmd_drv;
	const char *name;
};

/* IOCTL codes */
#define RPP_IOCTL_START              	0x00
#define RPP_IOCTL_GETPARAM           	0x00	/* get some information from the card */
#define RPP_IOCTL_CONNECT            	0x01   	/* Connect from rpp_server */
#define RPP_IOCTL_DISCONNECT         	0x02   	/* Disconnect from rpp_server */
#define RPP_IOCTL_MAP_SHM			 	0x10	/* Map host shared memory to driver */
#define RPP_IOCTL_UNMAP_SHM			 	0x11	/* Unmap host shared memory to driver */
#define RPP_IOCTL_XFER_TO_DEV		 	0x12	/* Copy data from shared memory to device */
#define RPP_IOCTL_XFER_FROM_DEV	 	 	0x13	/* Copy data from device to shared memory */
#define RPP_IOCTL_SYNC_FOR_CPU	     	0x14
#define RPP_IOCTL_SYNC_FOR_DEVICE	 	0x15
#define RPP_IOCTL_MAP_SINGLE		 	0x16	/* pci_map_single host buffer */
#define RPP_IOCTL_UNMAP_PHYS		 	0x17	/* pci_unmap_single host buffer */
#define RPP_IOCTL_PAGES_NEW          	0x20	/* Malloc host pages memory */
#define RPP_IOCTL_PAGES_INFO         	0x21	/* get info about host pages memory */
#define RPP_IOCTL_PAGES_FREE 	     	0x22	/* Free host pages memory */
#define RPP_IOCTL_GET_INTERRUPT_INFO	0x23	/* Get the isr msg */
#define RPP_IOCTL_SETPARAM	 	 	 	0x24	/* set some information for the card */
#define RPP_IOCTL_TRIGGER_DMA	 	 	0x25	/* wakeup pcie dma async kernel thread */
#define RPP_IOCTL_XFER_DESC		 	0x26	/* Descriptor DMA transfer on CH2 */
#define RPP_IOCTL_END                	0x26

#define RPP_IOCTL_BASE			'd'
#define RPP_IO(nr)				_IO(RPP_IOCTL_BASE,nr)
#define RPP_IOR(nr,type)		_IOR(RPP_IOCTL_BASE,nr,type)
#define RPP_IOW(nr,type)		_IOW(RPP_IOCTL_BASE,nr,type)
#define RPP_IOWR(nr,type)		_IOWR(RPP_IOCTL_BASE,nr,type)
#define RPP_IOCTL_NR(cmd)		_IOC_NR(cmd)

#define RPP_GETPARAM           RPP_IOWR(RPP_IOCTL_GETPARAM, struct rpp_param_info)
#define RPP_CONNECT            RPP_IOWR(RPP_IOCTL_CONNECT, struct rpp_conn_info)
#define RPP_DISCONNECT         RPP_IOWR(RPP_IOCTL_DISCONNECT, struct rpp_conn_info)
#define RPP_SYNC_FOR_CPU       RPP_IOWR(RPP_IOCTL_SYNC_FOR_CPU, struct rpp_shm_info)
#define RPP_SYNC_FOR_DEVICE    RPP_IOWR(RPP_IOCTL_SYNC_FOR_DEVICE, struct rpp_shm_info)
#define RPP_MAP_SHM            RPP_IOWR(RPP_IOCTL_MAP_SHM, struct rpp_shm_info)
#define RPP_UNMAP_SHM          RPP_IOWR(RPP_IOCTL_UNMAP_SHM, struct rpp_shm_info)
#define RPP_MAP_SINGLE         RPP_IOWR(RPP_IOCTL_MAP_SINGLE, struct rpp_single_map_info)
#define RPP_UNMAP_PHYS         RPP_IOWR(RPP_IOCTL_UNMAP_PHYS, struct rpp_single_map_info)
#define RPP_XFER_TO_DEV        RPP_IOWR(RPP_IOCTL_XFER_TO_DEV, struct rpp_xfer_info)
#define RPP_XFER_FROM_DEV      RPP_IOWR(RPP_IOCTL_XFER_FROM_DEV, struct rpp_xfer_info)
#define RPP_PAGES_NEW          RPP_IOWR(RPP_IOCTL_PAGES_NEW, struct rpp_pages_info)
#define RPP_PAGES_INFO         RPP_IOWR(RPP_IOCTL_PAGES_INFO, struct rpp_pages_info)
#define RPP_PAGES_FREE         RPP_IOW(RPP_IOCTL_PAGES_FREE, struct rpp_pages_info)
#define RPP_GET_INT_INFO       RPP_IOWR(RPP_IOCTL_GET_INTERRUPT_INFO, struct rpp_int_info)
#define RPP_SETPARAM       	   RPP_IOWR(RPP_IOCTL_SETPARAM, struct rpp_param_info)
#define RPP_TRIGGER_DMA        RPP_IOWR(RPP_IOCTL_TRIGGER_DMA, struct rpp_param_info)
#define RPP_XFER_DESC         RPP_IOWR(RPP_IOCTL_XFER_DESC, struct rpp_xfer_desc_info)

#endif /* _RPP_ENTIRE_CTRL_H_ */
