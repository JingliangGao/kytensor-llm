/*
 * This file is part of the Azurengine DMA IP Core driver for Linux
 *
 * Copyright (c) 2016-present,  Azurengine, Inc.
 * All rights reserved.
 *
 * This source code is licensed under both the BSD-style license (found in the
 * LICENSE file in the root directory of this source tree) and the GPLv2 (found
 * in the COPYING file in the root directory of this source tree).
 * You may select, at your option, one of the above-listed licenses.
 */

#ifndef __RPP_DEBUG_H__
#define __RPP_DEBUG_H__

#include <linux/printk.h>


/* Switch debug printing on/off */
#define RPP_DEBUG 0

#ifdef __LIBRPP_DEBUG__
#define dbg_io		pr_err
#define dbg_fops	pr_err
#define dbg_perf	pr_err
#define dbg_sg		pr_err
#define dbg_tfr		pr_err
#define dbg_irq		pr_err
#define dbg_init	pr_err
#define dbg_desc	pr_err
#define dbg_mm		pr_err
#define dbg_kqueue	pr_err
#define dbg_stream  pr_err
#define dbg_event	pr_err
#define dbg_sw_sche	pr_err
#define dbg_dma		pr_err
#define dbg_iss 	pr_err
#define dbg_sche_desc pr_err
#else
/* disable debugging */
#define dbg_io(...)
#define dbg_fops(...)
#define dbg_perf(...)
#define dbg_sg(...)
#define dbg_tfr(...)
#define dbg_irq(...)
#define dbg_init(...)
#define dbg_desc(...)
#define dbg_mm(...)
#define dbg_kqueue 	pr_err
#define dbg_stream 	pr_err
#define dbg_event	pr_err
#define dbg_sw_sche	pr_err
#define dbg_dma		pr_err
#define dbg_iss		pr_err
#endif




#endif /* RPP_LIB_H */
