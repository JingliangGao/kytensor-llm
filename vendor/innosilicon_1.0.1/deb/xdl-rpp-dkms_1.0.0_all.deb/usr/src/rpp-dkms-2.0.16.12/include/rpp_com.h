/*****************************************************************************
 *
 * <COPYRIGHT_TAG>
 *
 *****************************************************************************/
 /*
 *****************************************************************************
 * Doxygen group definitions
 ****************************************************************************/
/*****************************************************************************
 * @file rpp_com.h
 *
 * @description
 *		This file contains the data structures that are used by
 *		RPP kernel.
 *
 *****************************************************************************/

#ifndef  __RPP_COM_H__
#define  __RPP_COM_H__

/* #include "rpp_types.h" */

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#ifdef RPP_CORE_V2
/*  #warning "RPP_CORE_V2" */
#else
/*  #warning "RPP_CORE_V1" */
#endif

#define __RPP__
/*  Defined when compiling C/C++/RPP source files, __NVCC__ */
#define __RPP_PLATFORM_CC__

/*  Defined when compiling RPP source files, __CUDACC__ */
#define __RPPCC__
#define __RPPCC_RDC__
#define __RPPCC_DEBUG__

/*  Auto enable __RPP_DEVICE_COMPILE__ if compiled in RPP or CUDA device path */
#if defined(__RPP__) || (defined(__CUDA_ARCH__) && __CUDA_ARCH__ != 0)
#define __RPP_DEVICE_COMPILE__ 	1
#endif

#define RPP_PRAM_SIZE           (2048*1024)
#define RPP_SRAM_SIZE           (24*1024*1024)
#define RPP_FRAM_SIZE           (8*1024)

#ifdef RPP_SIM
#define RPP_DMA_BASE         0x0
#define FRAM_BASE	         0x0
#define RPP_SRAM_BASE        0x0
#define RPP_PRAM_ADDR        0x0
#define RPP_SCHE_ADDR_VER1   0x0
#define RPP_SCHE_ADDR_VER2   0x0
#define RPP_CORE_REG_BASE    0x0
#else
#define RPP_DMA_BASE         0x1000000000
#ifdef RTL_TB
#define FRAM_BASE            0x1006000000
#define RPP_SRAM_BASE        0x1004000000
#define RPP_PRAM_ADDR        0x1007000000
#else
#define FRAM_BASE	     	 0x6000000
#define RPP_SRAM_BASE        0x4000000
#define RPP_PRAM_ADDR        0x7000000
#endif
/*  Scheduler, 0x400000 - 0x401000 */
#define RPP_SCHE_ADDR_VER1				0x400000
#define RPP_SCHE_ADDR_VER2				0x2080000
#define RPP_CORE_REG_BASE               0x1000000000
#endif

#ifdef RTL_TB
#define RPP_DMA_SRAM_BASE    (RPP_DMA_BASE + 0x4000000)
#define RPP_DMA_FRAM_BASE    (RPP_DMA_BASE + 0x6000000)
#define RPP_DMA_PRAM_BASE    (RPP_DMA_BASE + 0x7000000)
#else
#define RPP_DMA_SRAM_BASE    (RPP_DMA_BASE + 0x4000000)
#define RPP_DMA_FRAM_BASE    (RPP_DMA_BASE + 0x6000000)
#define RPP_DMA_PRAM_BASE    (RPP_DMA_BASE + 0x7000000)
#endif

#if 1 /* def RTL_TB */
#ifdef RTL_TB
#define AXI_BAR1_BASE				(RPP_CORE_REG_BASE + 0x3004000)
#define RPP_RESET_REG_ADDR          (RPP_CORE_REG_BASE + 0x3005004)
#define CDMA_BASE					(RPP_CORE_REG_BASE + 0x3000000)
#else
#define AXI_BAR1_BASE				(0x3004000)
#define RPP_RESET_REG_ADDR          (0x3005004)
#define CDMA_BASE					(0x3000000)
#endif
#define RPP_CORE_BUSY				(AXI_BAR1_BASE + 0x0)
#define RPP_YX_REG_ADDR				(AXI_BAR1_BASE + 0x10)
#define RPP_TZ_REG_ADDR				(AXI_BAR1_BASE + 0x14)
#define RPP_XYZ_FIFO_INFO_ADDR		(AXI_BAR1_BASE + 0x18)
#define RPP_IDLE_MIN_ADDR			(AXI_BAR1_BASE + 0x1c)
#define RPP_PRE_LINE_ADDR			(AXI_BAR1_BASE + 0x20)
#define RPP_ICACHE_MSB			    (AXI_BAR1_BASE + 0x24)
#define RPP_ICACHE_LSB			    (AXI_BAR1_BASE + 0x28)
#define RPP_FMEM_LEN_ADDR			(AXI_BAR1_BASE + 0x2c)
#define RPP_FMEM_MSB			    (AXI_BAR1_BASE + 0x30)
#define RPP_FMEM_LSB			    (AXI_BAR1_BASE + 0x34)

#define RPP_START_REG_ADDR			(AXI_BAR1_BASE + 0x40)
#define RPP_FIFO_INFO_ADDR			(AXI_BAR1_BASE + 0x44)

#define RPP_COLUMN_STATUS			(AXI_BAR1_BASE + 0x50)

#define RPP_INT_CLEAR_ADDR			(AXI_BAR1_BASE + 0x60)
#define RPP_INT_MASK_ADDR		    (AXI_BAR1_BASE + 0x64)
#define RPP_INT_TIMER_ADDR			(AXI_BAR1_BASE + 0x68)

#define RPP_CNTR_LOW_REG_ADDR		(AXI_BAR1_BASE + 0x70)
#define RPP_CNTR_HIGH_REG_ADDR		(AXI_BAR1_BASE + 0x74)
#define RPP_CNTR_CLEAR_REG_ADDR		(AXI_BAR1_BASE + 0x78)
#define RPP_VERSION_REG_ADDR		(AXI_BAR1_BASE + 0x7c)

#define RPP_ICACHE_CLR				(AXI_BAR1_BASE + 0x80)
#define RPP_ICACHE_CLR_START		(AXI_BAR1_BASE + 0x84)
#define RPP_ICACHE_CLR_END			(AXI_BAR1_BASE + 0x88)

#else
#define AXI_BAR1_BASE				0x204000
#define RPP_RESET_REG_ADDR          0x205004
#define CDMA_BASE					0x200000

#define RPP_CORE_BUSY				(AXI_BAR1_BASE + 0x0)
#define RPP_VERSION_REG_ADDR		(AXI_BAR1_BASE + 0xbc)
#define RPP_RESET_ERR_ADDR			(AXI_BAR1_BASE + 0x4)
#define RPP_YX_REG_ADDR				(AXI_BAR1_BASE + 0x20)
#define RPP_TZ_REG_ADDR				(AXI_BAR1_BASE + 0x24)
#define RPP_STACK_REG_ADDR			(AXI_BAR1_BASE + 0x28)

#define RPP_PRE_LINE_ADDR			(AXI_BAR1_BASE + 0x40)
#define RPP_ICACHE_MSB			    (AXI_BAR1_BASE + 0x44)
#define RPP_ICACHE_LSB			    (AXI_BAR1_BASE + 0x48)
#define RPP_FMEM_LEN_ADDR			(AXI_BAR1_BASE + 0x4c)
#define RPP_FMEM_MSB			    (AXI_BAR1_BASE + 0x50)

#define RPP_START_REG_ADDR			(AXI_BAR1_BASE + 0x80)
#define RPP_FIFO_INFO_ADDR			(AXI_BAR1_BASE + 0x84)

#define RPP_CNTR_LOW_REG_ADDR		(AXI_BAR1_BASE + 0xb0)
#define RPP_CNTR_HIGH_REG_ADDR		(AXI_BAR1_BASE + 0xb4)
#define RPP_CNTR_CLEAR_REG_ADDR		(AXI_BAR1_BASE + 0xb8)

#endif

/*
 *
 * channel 0 Descriptor Mode/Direct Mode: Core
 * channel 1 Descriptor Mode: APB descriptor
 * channel 1 Direct Mode: Scheduler
 * channel 2 Descriptor Mode/Direct Mode: MPU0
 * channel 3 Descriptor Mode/Direct Mode: MPU1
 *
 */
#define CDMACR						(CDMA_BASE + 0x0) /*  CDMA Control */
#define CDMASR						(CDMA_BASE + 0x4) /*  CDMA Status */
#define CH0_DESC_PTR_HI				(CDMA_BASE + 0x8) /*  CDMA Desc ptr, MSB 32 bits */
#define CH0_DESC_PTR				(CDMA_BASE + 0xc) /*  CDMA Desc ptr */
#define CH1_DESC_PTR_HI				(CDMA_BASE + 0x10) /*  CDMA Desc ptr, MSB 32 bits */
#define CH1_DESC_PTR				(CDMA_BASE + 0x14) /*  CDMA Desc ptr */
#define CH0_SA_MSB					(CDMA_BASE + 0x18) /*  Source address, MSB 32 bits */
#define CH0_SA						(CDMA_BASE + 0x1c) /*  Source address */
#define CH0_DA_MSB					(CDMA_BASE + 0x20) /*  Destination address, MSB 32 bits */
#define CH0_DA						(CDMA_BASE + 0x24) /*  Destination address */
#define CH0_BTT						(CDMA_BASE + 0x28) /*  Bytes to Transfer */
#define CH1_SA_MSB					(CDMA_BASE + 0x2c) /*  Source address, MSB 32 bits */
#define CH1_SA						(CDMA_BASE + 0x30) /*  Source address */
#define CH1_DA_MSB					(CDMA_BASE + 0x34) /*  Destination address, MSB 32 bits */
#define CH1_DA						(CDMA_BASE + 0x38) /*  Destination address */
#define CH1_BTT						(CDMA_BASE + 0x3c) /*  Bytes to Transfer */
#define AXI4_DATA_CFG_0				(CDMA_BASE + 0x40) /*  data ports */
#define AXI4_DATA_CFG_1				(CDMA_BASE + 0x44) /*  data ports */
#define AXI4_DESC_CFG_0				(CDMA_BASE + 0x48) /*  descriptor ports */
/* #define AXI4_DESC_CFG_1				(CDMA_BASE + 0x4c) */ /* descriptor ports */
#define CH2_DESC_PTR_HI				(CDMA_BASE + 0x50) /*  CDMA Desc ptr, MSB 32 bits */
#define CH2_DESC_PTR				(CDMA_BASE + 0x54) /*  CDMA Desc ptr */
#define CH3_DESC_PTR_HI				(CDMA_BASE + 0x58) /*  CDMA Desc ptr, MSB 32 bits */
#define CH3_DESC_PTR				(CDMA_BASE + 0x5c) /*  CDMA Desc ptr */
#define CH2_SA_MSB					(CDMA_BASE + 0x60) /*  Source address, MSB 32 bits */
#define CH2_SA						(CDMA_BASE + 0x64) /*  Source address */
#define CH2_DA_MSB					(CDMA_BASE + 0x68) /*  Destination address, MSB 32 bits */
#define CH2_DA						(CDMA_BASE + 0x6c) /*  Destination address */
#define CH2_BTT						(CDMA_BASE + 0x70) /*  Bytes to Transfer */
#define CH3_SA_MSB					(CDMA_BASE + 0x74) /*  Source address, MSB 32 bits */
#define CH3_SA						(CDMA_BASE + 0x78) /*  Source address */
#define CH3_DA_MSB					(CDMA_BASE + 0x7c) /*  Destination address, MSB 32 bits */
#define CH3_DA						(CDMA_BASE + 0x80) /*  Destination address */
#define CH3_BTT						(CDMA_BASE + 0x84) /*  Bytes to Transfer */
#define R_EXTRA_SIZES				(CDMA_BASE + 0x150) /*  axi can read more extra_sizes data than its internal memory size */

#define FRAM_PARA_OFFSET           (FRAM_BASE)

#define FRAM_PARA_SIZE             (896)
#define FRAM_STATIC_CFG_OFFSET     (FRAM_PARA_OFFSET + FRAM_PARA_SIZE)
#define FRAM_STATIC_CFG_SIZE       (128)
#define FRAM_1K
#ifdef FRAM_1K
#define FRAM_DMA_OFFSET				(4*1024 - 256)
#define FRAM_DMA_SIZE				(256)
#define FRAM_TASK_DESC_OFFSET		(3*1024)
#define FRAM_TASK_DESC_SIZE			(256)
#else
#define FRAM_DMA_OFFSET				(7*1024)
#define FRAM_DMA_SIZE				(768)
#define FRAM_TASK_DESC_OFFSET		(FRAM_DMA_OFFSET + FRAM_DMA_SIZE)
#define FRAM_TASK_DESC_SIZE			(256)
#endif

/* FRAM RESERVED PARA */
#define FRAM_RSVD_PARA_OFFSET       (FRAM_BASE + 256)
#define PARA_CODE_SIZE_OFFSET		FRAM_RSVD_PARA_OFFSET
#define PARA_GRID_X_OFFSET			(PARA_CODE_SIZE_OFFSET + 2)
#define PARA_GRID_Y_OFFSET			(PARA_GRID_X_OFFSET + 2)
#define PARA_GRID_Z_OFFSET			(PARA_GRID_Y_OFFSET + 2)

#define PARA_BLOCK_X_OFFSET			(PARA_GRID_Z_OFFSET + 2)
#define PARA_BLOCK_Y_OFFSET			(PARA_BLOCK_X_OFFSET + 2)
#define PARA_BLOCK_Z_OFFSET			(PARA_BLOCK_Y_OFFSET + 2)
#define PARA_TID_XYZ			    (PARA_BLOCK_Z_OFFSET + 2)

#define PARA_DMA_IN_LO_OFFSET			(PARA_TID_XYZ + 2)
#define PARA_DMA_IN_HI_OFFSET			(PARA_DMA_IN_LO_OFFSET + 4)
#define PARA_DMA_OUT_LO_OFFSET			(PARA_DMA_IN_HI_OFFSET + 4)
#define PARA_DMA_OUT_HI_OFFSET			(PARA_DMA_OUT_LO_OFFSET + 4)
#define PARA_DMA_IN_STRD_OFFSET			(PARA_DMA_OUT_HI_OFFSET + 4)
#define PARA_DMA_OUT_STRD_OFFSET		(PARA_DMA_IN_STRD_OFFSET + 2)

#define PARA_OUT_X_STRD					(PARA_DMA_OUT_STRD_OFFSET + 2)
#define PARA_OUT_Y_STRD					(PARA_OUT_X_STRD + 4)
#define PARA_OUT_Z_STRD					(PARA_OUT_Y_STRD + 4)
#define PARA_IN_Y_STRD					(PARA_OUT_Z_STRD + 4)
#define PARA_IN_Z_STRD					(PARA_IN_Y_STRD + 4)

#define PARA_FILTER_X_STRD				(PARA_IN_Z_STRD + 4)
#define PARA_TID_BASE				    (PARA_FILTER_X_STRD + 4)
#define PARA_TID_DEPACK				    (PARA_TID_BASE + 4)

#define PARA_DFT_OUTPUT					(PARA_TID_DEPACK + 4)
#define PARA_DUMMY_CYCLE				(PARA_DFT_OUTPUT + 4)

#define PARA_DIMX_SHADOW				(PARA_DUMMY_CYCLE + 4)
#define PARA_DIMY_SHADOW				(PARA_DIMX_SHADOW + 2)
#define PARA_DIMZ_SHADOW				(PARA_DIMY_SHADOW + 2)
#define PARA_XYZCFG_SHADOW  			(PARA_DIMZ_SHADOW + 2)

#define FRAM_RSVD_PARA_END              (PARA_XYZCFG_SHADOW + 2)


/* spill register offset */
#define SPILL_REG_NUM 16
#define SPILL_SCA_REG_NUM 16
#define SRAM_SPILL_OFFSET            (0x4000)
#define SRAM_AUG_OFFSET              (0x1700000) /* fix me here */
#define SRAM_PRED_OFFSET             (0x1780000) /* fix me here */

#define FRAM_SPILL_OFFSET            (256 + 128)
#define FRAM_SPILL_PAIR_OFFSET       (FRAM_SPILL_OFFSET + SPILL_REG_NUM * 4)
#define FRAM_SCA_SPILL_OFFSET        (FRAM_SPILL_PAIR_OFFSET + SPILL_REG_NUM * 4)
#define FRAM_SPILL_OFF_END           (FRAM_SCA_SPILL_OFFSET + SPILL_SCA_REG_NUM * 4)

#define PRED_NUM 16
#define FRAM_PRED_BEG            (FRAM_SPILL_OFF_END + 4)
#define FRAM_PRED_END            (FRAM_PRED_BEG + PRED_NUM*4)




#define FRAM_LOG_BASE       (768)
#define FRAM_AUG_BUF_LSB     (FRAM_LOG_BASE)
#define FRAM_AUG_BUF_MSB     (FRAM_AUG_BUF_LSB + 4)
#define FRAM_LOG_BUF_LSB    (FRAM_AUG_BUF_MSB + 4)
#define FRAM_LOG_BUF_MSB    (FRAM_LOG_BUF_LSB + 4)
#define FRAM_LOG_BIDX       (FRAM_LOG_BUF_MSB + 4)
#define FRAM_LOG_OFFSET     (FRAM_LOG_BIDX + 4)
#define FRAM_DS0            (FRAM_LOG_OFFSET + 4)
#define FRAM_DS1            (FRAM_DS0 + 4)
#define FRAM_DS2            (FRAM_DS1 + 4)
#define FRAM_DS3            (FRAM_DS2 + 4)
#define FRAM_DS4            (FRAM_DS3 + 4)
#define FRAM_LOG_END        (FRAM_DS4 + 4)

/* FRAM static configuration DEFINE */
#define FRAM_BASE_LSB         	(FRAM_STATIC_CFG_OFFSET)
#define FRAM_BASE_MSB         	(FRAM_STATIC_CFG_OFFSET + 0x4)
#define PRAM_BASE_LSB         	(FRAM_STATIC_CFG_OFFSET + 0x8)
#define PRAM_BASE_MSB         	(FRAM_STATIC_CFG_OFFSET + 0xc)
#define PARA_MAX_SIZE         	(FRAM_STATIC_CFG_OFFSET + 0x10)
#define KERN_FUNC_BASE_LSB      (FRAM_STATIC_CFG_OFFSET + 0x14)
#define KERN_FUNC_BASE_MSB      (FRAM_STATIC_CFG_OFFSET + 0x18)
#define KERN_FUNC_SIZE         	(FRAM_STATIC_CFG_OFFSET + 0x1c)
#define KERN_PARA_BASE_LSB      (FRAM_STATIC_CFG_OFFSET + 0x20)
#define KERN_PARA_BASE_MSB      (FRAM_STATIC_CFG_OFFSET + 0x24)
#define KERN_PARA_SIZE         	(FRAM_STATIC_CFG_OFFSET + 0x28)

#define FRAM_STATIC_CFG_END    (KERN_PARA_SIZE + 4)

/* FRAM DMA register DEFINE */
#define DMA_CONTROL          FRAM_DMA_OFFSET
#define DMA_STATUS           (DMA_CONTROL + 4)
#define DMA_CH0_DESC_HI      (DMA_STATUS + 4)
#define DMA_CH0_DESC_LOW     (DMA_CH0_DESC_HI + 4)
#define DMA_CH1_DESC_HI      (DMA_CH0_DESC_LOW + 4)
#define DMA_CH1_DESC_LOW     (DMA_CH1_DESC_HI + 4)
#define DMA_CH0_MOD1_SRC_HI   (DMA_CH1_DESC_LOW + 4)
#define DMA_CH0_MOD1_SRC_LO   (DMA_CH0_MOD1_SRC_HI + 4)
#define DMA_CH0_MOD1_DST_HI   (DMA_CH0_MOD1_SRC_LO + 4)
#define DMA_CH0_MOD1_DST_LO   (DMA_CH0_MOD1_DST_HI + 4)
#define DMA_CH0_MOD1_LEN      (DMA_CH0_MOD1_DST_LO + 4)

#define DMA_CH1_MOD1_SRC_HI   (DMA_CH0_MOD1_LEN + 4)
#define DMA_CH1_MOD1_SRC_LO   (DMA_CH1_MOD1_SRC_HI + 4)
#define DMA_CH1_MOD1_DST_HI   (DMA_CH1_MOD1_SRC_LO + 4)
#define DMA_CH1_MOD1_DST_LO   (DMA_CH1_MOD1_DST_HI + 4)
#define DMA_CH1_MOD1_LEN      (DMA_CH1_MOD1_DST_LO + 4)

#define FRAM_DMA_END          (DMA_CH1_MOD1_LEN + 4)


/* FRAM TASK DESCRIPTOR */
#define BLOCK_ID_X_OFFSET        (FRAM_BASE + FRAM_TASK_DESC_OFFSET)
#define BLOCK_ID_Y_OFFSET        (BLOCK_ID_X_OFFSET + 2)
#define BLOCK_ID_Z_OFFSET        (BLOCK_ID_Y_OFFSET + 2)
#define BLOCK_ID_RSVD_OFFSET     (BLOCK_ID_Z_OFFSET + 2)
#define STACK_PTR_OFFSET          (BLOCK_ID_RSVD_OFFSET + 2)
#define TASK_PTR_OFFSET           (STACK_PTR_OFFSET + 4)
#define FRAM_TASK_DESC_END        (TASK_PTR_OFFSET + 4)

#ifdef _RPP_WITH_SW_SCHEDULER
/* #warning _RPP_WITH_SW_SCHEDULER */
#define RPP_SCHE_REG_BASE				RPP_SCHE_ADDR_VER1
#else
#define RPP_SCHE_REG_BASE				RPP_SCHE_ADDR_VER2
#endif

#define RPP_INITIAL_HEAD_Q0				(RPP_SCHE_REG_BASE + 0x00)
#define RPP_CURR_HEAD_Q0				(RPP_SCHE_REG_BASE + 0x30)
#define RPP_CURR_TAIL_Q0				(RPP_SCHE_REG_BASE + 0x60)
#define RPP_RECONFIG_Q0					(RPP_SCHE_REG_BASE + 0x90)
#define RPP_TAIL_ADDR_REFRESH_Q0		(RPP_SCHE_REG_BASE + 0xc0)

#define RPP_SCHE_REG_CTRL				(RPP_SCHE_REG_BASE + 0xf0)
#define RPP_SCHE_REG_STATUS				(RPP_SCHE_REG_BASE + 0xf4)
#define RPP_CORE_REG_ADDR_MSB			(RPP_SCHE_REG_BASE + 0xf8)
#define RPP_CORE_REG_ADDR_LSB			(RPP_SCHE_REG_BASE + 0xfc)
/* #define RPP_CORE_REG_ADDR_OFFS			(RPP_SCHE_REG_BASE + 0x100) */
#define RPP_DESC_DDR_ADDR_MSB			(RPP_SCHE_REG_BASE + 0x104)
#define RPP_KERN_FUNC_DDR_ADDR_MSB		(RPP_SCHE_REG_BASE + 0x108)
#define RPP_KERN_PARA_DDR_ADDR_MSB		(RPP_SCHE_REG_BASE + 0x10c)
#define RPP_DEV0_ADDR_MSB				(RPP_SCHE_REG_BASE + 0x110)
#define RPP_DEV1_ADDR_MSB				(RPP_SCHE_REG_BASE + 0x114)
#define RPP_DEV2_ADDR_MSB				(RPP_SCHE_REG_BASE + 0x118)
#define RPP_DEV3_ADDR_MSB				(RPP_SCHE_REG_BASE + 0x11c)
#define RPP_DEV4_ADDR_MSB				(RPP_SCHE_REG_BASE + 0x120)
#define RPP_DEV5_ADDR_MSB				(RPP_SCHE_REG_BASE + 0x124)
#define RPP_DEV6_ADDR_MSB				(RPP_SCHE_REG_BASE + 0x128)
#define RPP_DEV7_ADDR_MSB				(RPP_SCHE_REG_BASE + 0x12c)
#define RPP_DEV8_ADDR_MSB				(RPP_SCHE_REG_BASE + 0x130)
#define RPP_DEV9_ADDR_MSB				(RPP_SCHE_REG_BASE + 0x134)
#define RPP_DEV10_ADDR_MSB				(RPP_SCHE_REG_BASE + 0x138)
#define RPP_DEV11_ADDR_MSB				(RPP_SCHE_REG_BASE + 0x13c)
#define RPP_DEV12_ADDR_MSB				(RPP_SCHE_REG_BASE + 0x140)
#define RPP_DEV13_ADDR_MSB				(RPP_SCHE_REG_BASE + 0x144)
#define RPP_DEV14_ADDR_MSB				(RPP_SCHE_REG_BASE + 0x148)
#define RPP_DEV15_ADDR_MSB				(RPP_SCHE_REG_BASE + 0x14c)

#define RPP_EVENT_RW_MPU0				(RPP_SCHE_REG_BASE + 0x150)
#define RPP_EVENT_RW_MPU1				(RPP_SCHE_REG_BASE + 0x154)
#define RPP_EVENT_RW_HOST				(RPP_SCHE_REG_BASE + 0x158)

#define RPP_MPU0_INT_CLEAR				(RPP_SCHE_REG_BASE + 0x160)
#define RPP_MPU1_INT_CLEAR				(RPP_SCHE_REG_BASE + 0x164)
#define RPP_PCIE_INT_CLEAR				(RPP_SCHE_REG_BASE + 0x168)

#define RPP_SCHE_INT_INFO_1				(RPP_SCHE_REG_BASE + 0x16c)
#define RPP_SCHE_INT_INFO_2				(RPP_SCHE_REG_BASE + 0x170)
#define RPP_SCHE_INT_INFO_3				(RPP_SCHE_REG_BASE + 0x174)
#define RPP_HOST_DONE_Q0				(RPP_SCHE_REG_BASE + 0x178)

#define RPP_AXI_CONFIG 					(RPP_SCHE_REG_BASE + 0x180)
#define RPP_SCHE_VERSION				(RPP_SCHE_REG_BASE + 0x184)
#define RPP_SCHE_DBG_SEL				(RPP_SCHE_REG_BASE + 0x188)
#define RPP_SCHE_DBG_INFO				(RPP_SCHE_REG_BASE + 0x18c)
#define RPP_SCHE_SPECIAL_CTRL			(RPP_SCHE_REG_BASE + 0x190)
#define RPP_SCHE_SOFT_RESET				(RPP_SCHE_REG_BASE + 0x194)
#define RPP_PROFILE_TIMEING_HI			(RPP_SCHE_REG_BASE + 0x198)
#define RPP_PROFILE_TIMEING_LO			(RPP_SCHE_REG_BASE + 0x19C)
#define RPP_MPU0_SEMA_WAIT_REQ			(RPP_SCHE_REG_BASE + 0x200)
#define RPP_MPU0_SEMA_WAIT_ACK			(RPP_SCHE_REG_BASE + 0x204)
#define RPP_MPU0_SEMA_POST				(RPP_SCHE_REG_BASE + 0x208)
#define RPP_MPU1_SEMA_WAIT_REQ			(RPP_SCHE_REG_BASE + 0x210)
#define RPP_MPU1_SEMA_WAIT_ACK			(RPP_SCHE_REG_BASE + 0x214)
#define RPP_MPU1_SEMA_POST				(RPP_SCHE_REG_BASE + 0x218)
#define RPP_QUEUE_BYPASS				(RPP_SCHE_REG_BASE + 0x230)
#define RPP_SCH_ADDR_LO_31_12			(RPP_SCHE_REG_BASE + 0x234)

#define RPP_MPU_ADDR_HI					(RPP_SCHE_REG_BASE + 0x238)
#define RPP_MPU_ADDR_LO_Q0				(RPP_SCHE_REG_BASE + 0x240)
#define RPP_MPU_ADDR_LO_Q1				(RPP_SCHE_REG_BASE + 0x244)
#define RPP_MPU_ADDR_LO_Q2				(RPP_SCHE_REG_BASE + 0x248)
#define RPP_MPU_ADDR_LO_Q3				(RPP_SCHE_REG_BASE + 0x24C)
#define RPP_MPU_ADDR_LO_Q4				(RPP_SCHE_REG_BASE + 0x250)
#define RPP_MPU_ADDR_LO_Q5				(RPP_SCHE_REG_BASE + 0x254)
#define RPP_MPU_ADDR_LO_Q6				(RPP_SCHE_REG_BASE + 0x258)
#define RPP_MPU_ADDR_LO_Q7				(RPP_SCHE_REG_BASE + 0x25C)
#define RPP_MPU_ADDR_LO_Q8				(RPP_SCHE_REG_BASE + 0x260)
#define RPP_MPU_ADDR_LO_Q9				(RPP_SCHE_REG_BASE + 0x264)

#define RPP_MPU_HEAD_ADDR0				(RPP_SCHE_REG_BASE + 0x270)
#define RPP_MPU_HEAD_ADDR1				(RPP_SCHE_REG_BASE + 0x274)
#define RPP_MPU_HEAD_ADDR2				(RPP_SCHE_REG_BASE + 0x278)
#define RPP_MPU_HEAD_ADDR3				(RPP_SCHE_REG_BASE + 0x27C)
#define RPP_MPU_HEAD_ADDR4				(RPP_SCHE_REG_BASE + 0x280)
#define RPP_MPU_HEAD_ADDR5				(RPP_SCHE_REG_BASE + 0x284)
#define RPP_MPU_HEAD_ADDR6				(RPP_SCHE_REG_BASE + 0x288)
#define RPP_MPU_HEAD_ADDR7				(RPP_SCHE_REG_BASE + 0x28C)
#define RPP_MPU_HEAD_ADDR8				(RPP_SCHE_REG_BASE + 0x290)
#define RPP_MPU_HEAD_ADDR9				(RPP_SCHE_REG_BASE + 0x294)

#define RPP_DUMMY_REG_0					(RPP_SCHE_REG_BASE + 0x300)
#define RPP_DUMMY_REG_1					(RPP_SCHE_REG_BASE + 0x304)

#define RPP_SCHE_ERROR_INFO				(RPP_SCHE_REG_BASE + 0x310)
#define RPP_DISPATCH_HEAD_Q0			(RPP_SCHE_REG_BASE + 0x320)

/* scheduler special ctrl register value */
#define MPU0_INT_EN						(1<<5)
#define MPU1_INT_EN						(1<<6)
#define PROFILE_TIMING_EN				(1<<4)
#define Q0_PRIORITY_HIGH                (1)
#define ICACHE_PRE_LINE_NUM				(6)  /* 3 <<1, defualt value */

/* End of Scheduler */

#define RPP_CDMA_1D_MODE_EN			1
#define RPP_CDMA_2D_MODE_EN			2
#define RPP_CDMA_3D_MODE_EN			4
#define RPP_CDMA_4D_MODE_EN			8
#define RPP_CDMA_INT_MODE_EN		16
#define RPP_CDMA_DEINT_MODE_EN		17

#define RPP_CDMA_SUSPEND_EN		   1
#define RPP_CDMA_INT_EN			   2
#define RPP_CDMA_INBOUND		   4
#define RPP_CDMA_OUTBOUND		   8
#define RPP_CDMA_D2D               16
#define RPP_CDMA_C2C               32

#define AUG_NUM 4
#define FMT_LEN 64
#define RPP_MAX_THREADS    (256*32)
typedef struct RppTbDim_t
{
	uint16_t X;
	uint16_t Y;
	uint16_t Z;
	uint16_t RSVD;
} tRppTbDim;

typedef struct RppGridDim_t
{
	uint16_t X;
	uint16_t Y;
	uint16_t Z;
	uint16_t RSVD;
} tRppGridDim;

#define RPP_TID_GEN_ADDR			(0)
typedef struct RppTidGen_t
{
	uint64_t xWidth   : 4;
	uint64_t yWidth   : 4;
	uint64_t baseAddr : 16;

	uint64_t xyzPack  : 16;
	uint64_t xyzRd    : 9;

	uint64_t xh16     : 5;
	uint64_t yh16     : 5;
	uint64_t zh16     : 5;

} tRppTidGen;

typedef struct SeqFifoW0_t
{
	uint32_t pOffset  : 14;
	uint32_t xyzPop   : 1;
	uint32_t cont     : 1;

	uint32_t framId   : 1;
	uint32_t jobId    : 15;

} SeqFifoW0_t;

typedef struct SeqFifoW1_t
{
	uint32_t blkx  : 16;
	uint32_t blky  : 16;
} SeqFifoW1_t;

typedef struct SeqFifoW2_t
{
	uint32_t blkz  : 16;
	uint32_t blkid  : 16;
} SeqFifoW2_t;

typedef struct SeqFifoW3_t
{
	uint32_t addrh  : 13;
	uint32_t rsvd   : 19;
} SeqFifoW3_t;

enum
{
	REG_I32,
	REG_I16,
	REG_DV32,
	REG_S32,
	REG_S16,
};

typedef struct AugInfo_t
{
	int augNum;
	int augType[AUG_NUM];
} AugInfo_t;

typedef struct RppLogPara_t
{
	uint32_t aug_buf_lsb;
	uint32_t aug_buf_msb;
	uint32_t log_buf_lsb;
	uint32_t log_buf_msb;
	uint32_t bidx;
	uint32_t log_offset;
	uint32_t ds0;
	uint32_t ds1;
	uint32_t ds2;
	uint32_t ds3;
	uint32_t ds4;
} tRppLogPara;

typedef struct RppLogDesc_t
{
	int log_num;
	char *log_fmt;
	AugInfo_t *aug_info;
	uint64_t log_dev_addr;
	uint64_t log_host_addr;
	tRppLogPara logPara;
} tRppLogDesc;

typedef struct rppCmdaCtrl_s
{
	uint8_t	 mode;
	uint8_t	 ctrl;
}rppCmdaCtrl_t;

typedef struct rppCdmaTransferCtrl_s
{
}rppCdmaTransferCtrl_t;


typedef struct rppCdmaMemDesc_s
{
	uint16_t  nextDesc;
	/**< next descriptor offset against current pointer, 16 bits */
	rppCmdaCtrl_t	ctrl;
	/**< RPP control 1 word / 16 bits*/
	uint32_t  descId;
	/**< RPP descriptor ID*/
	/* uint64_t  *pDeviceSrcAddr; */
	uint32_t  pDeviceSrcAddrLsb;
	uint32_t  pDeviceSrcAddrMsb;
	/**< source address, 64 bits*/
	/* uint64_t  *pDeviceDstAddr; */
	uint32_t  pDeviceDstAddrLsb;
	uint32_t  pDeviceDstAddrMsb;
	/**< destination address, 64 bits*/
	uint32_t  blockSize0;
	/**< block length of 1st dim, 24 bits, high 8 bits are not used */
	uint32_t  blockSize1;
	/**< block length of 2nd dim, 24 bits, high 8 bits are not used, valid when mode > 1D */
	uint32_t  blockSize2;
	/**< block length of 3rd dim, 24 bits, high 8 bits are not used, valid when mode > 2D */
	uint32_t  blockSize3;
	/**< block length of 4th dim, 24 bits, high 8 bits are not used, valid when mode > 3D */
	uint32_t  srcStride0;
	/**< source stride of 1st dim */
	uint32_t  dstStride0;
	/**< destination stride  of 1st dim */
	uint32_t  srcStride1;
	/**< source stride of 2nd dim */
	uint32_t  dstStride1;
	/**< destination stride of 2nd dim */
	uint32_t  srcStride2;
	/**< source stride of 3rd dim */
	uint32_t  dstStride2;
	/**< destination stride of 3rd dim */
#if 0
	uint32_t  blockLength;
	/**< [0:4] number of blocks to interleave,
		 [5:7] reserved,
		 [8:31] Length of each block
	*/
	uint32_t  intSrcStride;
	/**< source stride of interleave mode */
	uint32_t  intDstStride;
	/**< destination stride of interleave mode */
	/* uint32_t reserved[13+32]; */
#endif
}rppCdmaMemDesc_t;

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif
