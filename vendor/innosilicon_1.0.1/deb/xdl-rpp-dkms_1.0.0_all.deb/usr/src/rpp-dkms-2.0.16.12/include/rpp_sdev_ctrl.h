/*
 * This file is part of the Azurengine DMA IP Core driver for Linux
 *
 * Copyright (c) 2016-present,  Azurengine, Inc.
 * All rights reserved.
 *
 * This source code is licensed under both the BSD-style license (found in the
 * LICENSE file in the root directory of this source tree) and the GPLv2 (found
 * in the COPYING file in the root directory of this source tree).
 * You may select, at your option, one of the above-listed licenses.
 */

#ifndef __RPP_SDEV_CTRL_H__
#define __RPP_SDEV_CTRL_H__

#include <linux/ioctl.h>

#include "rpp_com.h"
#include "rpp_dev.h"

/*
 * S means "Set" through a ptr,
 * T means "Tell" directly with the argument value
 * G means "Get": reply by setting through a pointer
 * Q means "Query": response is on the return value
 * X means "eXchange": switch G and S atomically
 * H means "sHift": switch T and Q atomically
 *
 * _IO(type,nr)		    no arguments
 * _IOR(type,nr,datatype)   read data from driver
 * _IOW(type,nr.datatype)   write data to driver
 * _IORW(type,nr,datatype)  read/write data
 *
 * _IOC_DIR(nr)		    returns direction
 * _IOC_TYPE(nr)	    returns magic
 * _IOC_NR(nr)		    returns number
 * _IOC_SIZE(nr)	    returns size
 */

/*  get parameters */
#define SWITCH_GETPARAM_PCIID            1
#define SWITCH_GETPARAM_CHLD_INFO         2
#define SWITCH_GETPARAM_PCIE_LINK         3
#define SWITCH_GETPARAM_SWITCH_INFO       4

/*  set parameters */
#define SWITCH_CONFIG_SWITCH_REG    (1 << 16)
#define SWITCH_CONFIG_BRIDGE_REG    (2 << 16)

struct switch_param_info {
	uint64_t param;		/* < */
	uint8_t value[512];		/* > */
};

/**
 * Ioctl function type.
 *
 * \param p amdkfd process pointer.
 * \param data pointer to arg that was copied from user.
  * \param filep pointer to file structure.
 */
typedef int switch_ioctl_t(struct file *filp, rpp_switch_t *sdev, void *data);

struct switch_ioctl_desc {
	unsigned int cmd;
	int flags;
	switch_ioctl_t *func;
	unsigned int cmd_drv;
	const char *name;
};

/* IOCTL codes */
#define SWITCH_IOCTL_START              0x00
#define SWITCH_IOCTL_GETPARAM           0x00	/* get some information from the card */
#define SWITCH_IOCTL_SETPARAM           0x01	/* set some information for the card */

#define SWITCH_IOCTL_BASE			's'
#define SWITCH_IO(nr)				_IO(SWITCH_IOCTL_BASE,nr)
#define SWITCH_IOR(nr,type)		_IOR(SWITCH_IOCTL_BASE,nr,type)
#define SWITCH_IOW(nr,type)		_IOW(SWITCH_IOCTL_BASE,nr,type)
#define SWITCH_IOWR(nr,type)		_IOWR(SWITCH_IOCTL_BASE,nr,type)
#define SWITCH_IOCTL_NR(cmd)		_IOC_NR(cmd)

#define SWITCH_GETPARAM           SWITCH_IOWR(SWITCH_IOCTL_GETPARAM, struct switch_param_info)
#define SWITCH_SETPARAM           SWITCH_IOWR(SWITCH_IOCTL_SETPARAM, struct switch_param_info)


#endif /* _SWITCH_ENTIRE_CTRL_H_ */

