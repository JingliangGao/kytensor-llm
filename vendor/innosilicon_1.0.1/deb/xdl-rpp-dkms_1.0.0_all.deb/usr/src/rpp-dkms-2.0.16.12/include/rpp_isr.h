#ifndef __RPP_ISR_H__
#define __RPP_ISR_H__



#include "rpp_dev.h"

enum rpp_irq_vectors {
	RPP_DMA_INT = 0,
	RPP_SCH_INT,
	RPP_JPEG_INT0,
	RPP_JPEG_INT1,
	RPP_CODEC_INT0,
	RPP_CODEC_INT1,
	RPP_JPEG_INT2,
	RPP_JPEG_INT3,
	RPP_CODEC_INT2,
	RPP_CODEC_INT3,
	RPP_MPU_NORMAL_INT0,
	RPP_MPU_NORMAL_INT1,
	RPP_MPU_NORMAL_INT2,
	RPP_MPU_NORMAL_INT3,
	RPP_MPU_DMA_INT,
	RPP_VPU_NORMAL_INT0,
	RPP_VPU_NORMAL_INT1,
	RPP_VPU_NORMAL_INT2,
	RPP_VPU_NORMAL_INT3,
	RPP_VPU_DMA_INT,
	RPP_RESV,
	RPP_CORE_INT,
	RPP_PCIE_DMA_INT,
	RPP_IRQ_MAX
};

#ifdef SUPPORT_ISR_ITSELF
struct rpp_isr {
	irqreturn_t (*msi_isr)(int irq_vector, void *dev);
	char *isr_dev;
};
#endif

int rpp_isr_init(struct rpp_dev *pdev, bool bmisonly, short isr_num);
void rpp_isr_exit(struct rpp_dev *pdev);



#endif /* __RPP_ISR_H__ */

