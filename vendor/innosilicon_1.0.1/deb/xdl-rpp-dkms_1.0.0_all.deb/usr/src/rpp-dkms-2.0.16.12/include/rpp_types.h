/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright (c) 2018 Synopsys, Inc. and/or its affiliates.
 * Synopsys DesignWare eDMA controller driver.
 */

#ifndef __RPP_TYPES_H__
#define __RPP_TYPES_H__

#include <linux/types.h>

#define PCI_ENABLE_IO_SPACE                 0x0001
#define PCI_ENABLE_MEMORY_SPACE             0x0002
#define PCI_ENABLE_BUS_MASTER               0x0004
#define PCI_ENABLE_SPECIAL_CYCLES           0x0008
#define PCI_ENABLE_WRITE_AND_INVALIDATE     0x0010
#define PCI_ENABLE_VGA_COMPATIBLE_PALETTE   0x0020
#define PCI_ENABLE_PARITY                   0x0040  /*  (ro+) */
#define PCI_ENABLE_WAIT_CYCLE               0x0080  /*  (ro+) */
#define PCI_ENABLE_SERR                     0x0100  /*  (ro+) */
#define PCI_ENABLE_FAST_BACK_TO_BACK        0x0200  /*  (ro) */
#define PCI_DISABLE_LEVEL_INTERRUPT         0x0400

#define PCI_ADDRESS_IO_SPACE                0x00000001  /*  (ro) */
#define PCI_ADDRESS_MEMORY_TYPE_MASK        0x00000006  /*  (ro) */
#define PCI_ADDRESS_MEMORY_PREFETCHABLE     0x00000008  /*  (ro) */

#define PCI_ADDRESS_IO_ADDRESS_MASK         0xfffffffc
#define PCI_ADDRESS_MEMORY_ADDRESS_MASK     0xfffffff0
#define PCI_ADDRESS_ROM_ADDRESS_MASK        0xfffff800

#define PCI_TYPE_32BIT      0
#define PCI_TYPE_20BIT      2
#define PCI_TYPE_64BIT      4

#define PCI_MULTIFUNCTION                   0x80
#define PCI_DEVICE_TYPE                     0x00
#define PCI_BRIDGE_TYPE                     0x01
#define PCI_CARDBUS_BRIDGE_TYPE             0x02

#define PCI_ROMADDRESS_ENABLED              0x00000001


#ifndef TRUE
#define TRUE                true
#endif

#ifndef FALSE
#define FALSE               false
#endif


#define STATUS_SUCCESS      (0x00000000L)
#define STATUS_FAIL         (0x00000001L)
#define STATUS_UNSUCCESSFUL (0x00000001L)

typedef void                *HANDLE;
typedef int                 BOOL;
typedef unsigned char       BYTE;
typedef float               FLOAT;
typedef FLOAT               *PFLOAT;
typedef char                CHAR;
typedef char                *PCHAR;
typedef unsigned char       UCHAR;
typedef unsigned char       *PUCHAR;
typedef short               SHORT;
typedef short               *PSHORT;
typedef unsigned short      USHORT;
typedef unsigned short      *PUSHORT;
typedef long                LONG;
typedef unsigned short      WORD;
typedef unsigned int        DWORD;
typedef long long           LONGLONG;
typedef unsigned long long  ULONGLONG;
typedef ULONGLONG           *PULONGLONG;
typedef unsigned long       ULONG;
typedef ULONG               *PULONG;
typedef int                 INT;
typedef unsigned int        UINT;
typedef unsigned int        *PUINT;
typedef void                VOID;
typedef char                *LPSTR;
typedef const char          *LPCSTR;
typedef unsigned short      wchar_t;
typedef wchar_t             WCHAR;
typedef WCHAR               *LPWSTR;
typedef const WCHAR         *LPCWSTR;
typedef DWORD               *LPDWORD;
typedef unsigned long       UINT_PTR;
typedef UINT_PTR            SIZE_T;
typedef LONGLONG            USN;
typedef BYTE                BOOLEAN;
typedef void                *PVOID;
typedef int8_t			INT8, *PINT8;
typedef int16_t			INT16, *PINT16;
typedef int32_t			INT32, *PINT32;
typedef int64_t			INT64, *PINT64;
typedef uint8_t			UINT8, *PUINT8;
typedef uint16_t		UINT16, *PUINT16;
typedef uint32_t		UINT32, *PUINT32;
typedef uint64_t		UINT64, *PUINT64;


#define PCI_TYPE0_ADDRESSES             6
#define PCI_TYPE1_ADDRESSES             2
#define PCI_TYPE2_ADDRESSES             5

/**
 *  PCI info structure
 */
typedef struct _PCI_COMMON_CONFIG 
{
    USHORT  VendorID;                   /*  (ro) */
    USHORT  DeviceID;                   /*  (ro) */
    USHORT  Command;                    /*  Device control */
    USHORT  Status;
    UCHAR   RevisionID;                 /*  (ro) */
    UCHAR   ProgIf;                     /*  (ro) */
    UCHAR   SubClass;                   /*  (ro) */
    UCHAR   BaseClass;                  /*  (ro) */
    UCHAR   CacheLineSize;              /*  (ro+) */
    UCHAR   LatencyTimer;               /*  (ro+) */
    UCHAR   HeaderType;                 /*  (ro) */
    UCHAR   BIST;                       /*  Built in self test */

    union 
	{
        struct _PCI_HEADER_TYPE_0 
		{
            ULONG   BaseAddresses[PCI_TYPE0_ADDRESSES];
            ULONG   CIS;
            USHORT  SubVendorID;
            USHORT  SubSystemID;
            ULONG   ROMBaseAddress;
			UCHAR   CapabilitiesPtr;
			UCHAR   Reserved1[3];
            ULONG   Reserved2;

            UCHAR   InterruptLine;      /*  */
            UCHAR   InterruptPin;       /*  (ro) */
            UCHAR   MinimumGrant;       /*  (ro) */
            UCHAR   MaximumLatency;     /*  (ro) */
        } type0;


    } u;

    UCHAR   DeviceSpecific[192];

} PCI_COMMON_CONFIG, *PPCI_COMMON_CONFIG;


#define PCI_IOCTL_STR_LEN 128


/**
 *  Structure for getting "phd" reply
 */
typedef struct _PciCfg_GetHeader_USER_OUT {
    ULONG                 status;
    CHAR                  StatusStr[PCI_IOCTL_STR_LEN];
    PCI_COMMON_CONFIG     pciData;
} PciCfg_GetHeader_USER_OUT, *PPciCfg_GetHeader_USER_OUT;

typedef struct _PciCfg_GetDataByOffset_USER_IN {
    ULONG    Offset;
    ULONG    Length;
    ULONG    Num;
    INT      Rc;
} PciCfg_GetDataByOffset_USER_IN, *PPciCfg_GetDataByOffset_USER_IN;


/**
 *  Structure for saving PCI command input
 */
typedef struct _PciCfg_SetDataByOffset_USER_IN {
    ULONG    status;
    ULONG    Offset;
    ULONG    Length;
    UCHAR    Data[4];
    ULONG    Num;
    INT      Rc;
} PciCfg_SetDataByOffset_USER_IN, *PPciCfg_SetDataByOffset_USER_IN;

/**
 *  Structure for saving PCI command reply
 */
typedef struct _Pci_Data_USER_OUT {
    ULONG    status;
    CHAR     StatusStr[PCI_IOCTL_STR_LEN];
    UCHAR     Data[4];
} Pci_Data_USER_OUT, *PPci_Data_USER_OUT;

/**
 *  Structure for getting PCI bar info
 */
typedef struct _PciBar_GetDataByOffset_USER_IN {
    ULONG    Bar;
    ULONG    Offset;
    ULONG    Length;
    ULONG    Num;
} PciBar_GetDataByOffset_USER_IN, *PPciBar_GetDataByOffset_USER_IN;

/**
 *  Structure for setting PCI bar info
 */
typedef struct _PciBar_SetDataByOffset_USER_IN {
    ULONG    Bar;
    ULONG    Offset;
    ULONG    Length;
    UCHAR    Data[4];
    ULONG    Num;
} PciBar_SetDataByOffset_USER_IN, *PPciBar_SetDataByOffset_USER_IN;

/**
 *  Structure for PCI header read, "phr"
 */
typedef struct _Pci_Header_Read {
	PciCfg_GetDataByOffset_USER_IN ioctl_in;
	Pci_Data_USER_OUT ioctl_out;
} Pci_Header_Read, *pPci_Header_Read;

/**
 *  Structure for PCI header write, "phw"
 */
typedef struct _Pci_Header_Write {
	PciCfg_SetDataByOffset_USER_IN ioctl_in;
	Pci_Data_USER_OUT ioctl_out;
} Pci_Header_Write, *pPci_Header_Write;

/**
 *  Structure for PCI bar read, "pr"
 */
typedef struct _Pci_Bar_Read {
	PciBar_GetDataByOffset_USER_IN ioctl_in;
	Pci_Data_USER_OUT ioctl_out;
} Pci_Bar_Read, *pPci_Bar_Read;

/**
 *  Structure for PCI bar write, "pw"
 */
typedef struct _Pci_Bar_Write {
	PciBar_SetDataByOffset_USER_IN ioctl_in;
	Pci_Data_USER_OUT ioctl_out;
} Pci_Bar_Write, *pPci_Bar_Write;

/**
 * Unsigned Large interger defination
 */
#if defined(MIDL_PASS)
typedef struct _ULARGE_INTEGER {
#else
typedef union _ULARGE_INTEGER {
    struct {
        DWORD LowPart;
        DWORD HighPart;
    } DUMMYSTRUCTNAME;
    struct {
        DWORD LowPart;
        DWORD HighPart;
    } u;
#endif
    ULONGLONG QuadPart;
} ULARGE_INTEGER;
typedef ULARGE_INTEGER *PULARGE_INTEGER;

/**
 * Large interger defination
 */
#if defined(MIDL_PASS)
typedef struct _LARGE_INTEGER {
#else
typedef union _LARGE_INTEGER {
    struct {
        DWORD LowPart;
        LONG HighPart;
    } DUMMYSTRUCTNAME;
    struct {
        DWORD LowPart;
        LONG HighPart;
    } u;
#endif
    LONGLONG QuadPart;
} LARGE_INTEGER;
typedef LARGE_INTEGER *PLARGE_INTEGER;

#endif /* __RPP_TYPES_H__ */

