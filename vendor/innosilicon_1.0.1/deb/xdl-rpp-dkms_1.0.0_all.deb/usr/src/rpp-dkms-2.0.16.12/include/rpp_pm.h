#ifndef __RPP_PM_H__
#define __RPP_PM_H__

#include <linux/types.h>

struct rpp_dev;

int rpp_idle_low_power_init(struct rpp_dev *pdev);
void rpp_idle_low_power_deinit(struct rpp_dev *pdev);

int rpp_idle_low_power_get(struct rpp_dev *pdev, const char *reason);
int rpp_idle_low_power_put(struct rpp_dev *pdev, const char *reason);

int rpp_pm_poll_pcie_link(struct rpp_dev *pdev);
bool rpp_pm_need_restore_cfg(struct rpp_dev *pdev);
void rpp_pm_restore_cfg(struct rpp_dev *pdev);
int rpp_pm_store_cfg(struct rpp_dev *pdev);
void rpp_pm_log_cfg_state(struct rpp_dev *pdev, const char *stage);
int rpp_pm_wait_active_ioctl(struct rpp_dev *pdev);
int rpp_pm_wait_config_ready(struct rpp_dev *pdev);
void rpp_pm_restore_atu(struct rpp_dev *pdev);
int rpp_pm_restore_pcie_internal_state(struct rpp_dev *pdev);
int rpp_pm_reinit_dma(struct rpp_dev *pdev, const char *context);

#endif /* __RPP_PM_H__ */
