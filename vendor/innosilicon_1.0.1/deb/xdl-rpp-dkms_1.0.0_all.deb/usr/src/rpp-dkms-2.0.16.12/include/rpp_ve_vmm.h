/*
 *File Header
 ******************************************************************************
 * @file    mm.h
 * @author  Jerry (jerry.liu@azurengine.com)
 * @brief   virtual memory manager
 * @create  25 May 2023
 ******************************************************************************
 * Copyright by Azurengine Technology Co. Ltd
 * ve virtual memeory manager for codec and jpeg, it can manage total 4GB only,
 * and the maxium allocated size < 4GB
 *          
 *
 ******************************************************************************
 * @History
 ==============================================================================
 */

#ifndef __VIDEO_MEMORY_MANAGER_H_
#define __VIDEO_MEMORY_MANAGER_H_

#include <linux/types.h>

typedef struct video_mm_info_st{
    unsigned long   total_pages; 
    unsigned long   alloc_pages; 
    unsigned long   free_pages;
    unsigned long   page_size;
}vmem_info_t;

typedef struct page_struct {
    int             pageno;
    unsigned long   addr;
    int             used;
    int             alloc_pages;
    int             first_pageno;
} page_t;

typedef unsigned long long  vmem_key_t;

typedef struct avl_node_struct {
    vmem_key_t              key;
    int                     height;
    page_t                  *page;
    struct avl_node_struct  *left;
    struct avl_node_struct  *right;
} avl_node_t;

typedef struct _video_mm_struct {
    avl_node_t      *free_tree;
    avl_node_t      *alloc_tree;
    page_t          *page_list;
    int             num_pages;
    unsigned long   base_addr;
    unsigned int    mem_size;
    int             free_page_count;
    int             alloc_page_count;
    unsigned int    page_size;
} video_mm_t;

int vmem_init(  video_mm_t *mm, unsigned long addr, unsigned int size);
int vmem_exit(   video_mm_t *mm);
unsigned long vmem_alloc(video_mm_t *mm, unsigned int size, unsigned long pid);
int vmem_free(  video_mm_t *mm, unsigned long ptr, unsigned long pid);
int vmem_get_info(   video_mm_t *mm,  vmem_info_t *info);

#endif /* __VIDEO_MEMORY_MANAGER_H_ */
 
