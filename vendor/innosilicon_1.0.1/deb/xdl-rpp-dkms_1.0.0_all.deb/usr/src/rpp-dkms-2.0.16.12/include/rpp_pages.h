/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License (the "License").
 * You may not use this file except in compliance with the License.
 *
 * You can obtain a copy of the license at usr/src/OPENSOLARIS.LICENSE
 * or http://www.opensolaris.org/os/licensing.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at usr/src/OPENSOLARIS.LICENSE.
 * If applicable, add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your own identifying
 * information: Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 */

/*
 * Copyright 2010 PathScale Inc.  All rights reserved.
 * Use is subject to license terms.
 */

#ifndef __RPP_PAGES_H__
#define __RPP_PAGES_H__
/*  #include "rpp_mm.h" */

#include "rpp_dev.h"

struct rpp_single_map_info;

#define RPP_PAGES_SIZE 0x1000

#ifndef PMD_PAGE_SIZE
#define PMD_PAGE_SIZE 0x200000
#endif

#define RPP_MID_PAGES_SIZE PMD_PAGE_SIZE /* 2MB */

#define MAX_KMALLOC_SIZE		0x2000 /* linux slab max is slab_8kb */

#define RPP_IDR_OBJ_PAGES		1
#define RPP_IDR_OBJ_SINGLE		2

/* mmap offset base for host memory in entire_bridge_mmap (see map_handle) */
#define RPP_HOST_MAP_HANDLE_BASE	0x100000000ULL

typedef struct rpp_pages_s {
	uint32_t idr_type;
	int serial; /* /< Only used for debug. */
	uint64_t size; /* /< Always a multiple of page size. */
	unsigned int pages_nr;
	struct page **pages; /* /< HOST_MEM only: list of pages. */
	dma_addr_t *dmapages; /* /< DMA address of HOST_MEM, used in DMA descriptors. */
	struct sg_table sgt;
	uint32_t mapped_nents;
	uint32_t mapped_num;
	PBLK_ELEMENT mapped_blk;
} rpp_pages_t;

typedef struct rpp_single_map_s {
	uint32_t idr_type;
	int serial;
	uint64_t size;
	uint64_t map_len;
	uint32_t flags;
	dma_addr_t dma_addr;
	int dma_dir;
	void *kvirt;
	void *vmap_base;
	bool is_vmapped;
	struct page **pages;
	unsigned int pages_nr;
	uint64_t map_addr;
	uint64_t host_phys;
} rpp_single_map_t;

static inline bool rpp_idr_is_pages(void *obj)
{
	return obj && ((const uint32_t *)obj)[0] == RPP_IDR_OBJ_PAGES;
}

static inline bool rpp_idr_is_single(void *obj)
{
	return obj && ((const uint32_t *)obj)[0] == RPP_IDR_OBJ_SINGLE;
}

static inline uint64_t rpp_host_map_handle(int32_t handle)
{
	return (RPP_HOST_MAP_HANDLE_BASE | (uint64_t)(uint32_t)handle) << PAGE_SHIFT;
}

void rpp_unmap_user_buf(struct rpp_dev *pdev, rpp_pages_t *rpp_pages);
rpp_pages_t *rpp_map_user_buf(struct rpp_dev *pdev, uint64_t addr, uint64_t size);
void rpp_unmap_user_buf_2(struct rpp_dev *pdev, rpp_pages_t *rpp_pages);
rpp_pages_t *rpp_map_user_buf_2(struct rpp_dev *pdev, uint64_t addr, uint64_t size);
rpp_pages_t *rpp_pages_alloc(struct rpp_dev *pdev, uint64_t size);
void rpp_pages_free(struct rpp_dev *pdev, rpp_pages_t *rpp_pages);
void rpp_sync_sgt_for_cpu(struct rpp_dev *pdev, rpp_pages_t *rpp_pages);
void rpp_sync_sgt_for_device(struct rpp_dev *pdev, rpp_pages_t *rpp_pages);
rpp_single_map_t *rpp_map_single_buf(struct rpp_dev *pdev, struct rpp_single_map_info *info);
void rpp_unmap_single_buf(struct rpp_dev *pdev, rpp_single_map_t *single);

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,17,0)
vm_fault_t rpp_single_map_vm_fault(struct vm_fault *vmf);
vm_fault_t rpp_pages_vm_fault(struct vm_fault *vmf);
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,11,0)
int rpp_single_map_vm_fault(struct vm_fault *vmf);
int rpp_pages_vm_fault(struct vm_fault *vmf);
#else
int rpp_single_map_vm_fault(struct vm_area_struct *vma, struct vm_fault *vmf);
int rpp_pages_vm_fault(struct vm_area_struct *vma, struct vm_fault *vmf);
#endif
#endif

#endif /* __RPP_PAGES_H__ */
