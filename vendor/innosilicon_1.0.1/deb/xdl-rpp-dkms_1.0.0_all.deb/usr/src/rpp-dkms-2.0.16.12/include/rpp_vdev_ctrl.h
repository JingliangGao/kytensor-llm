/*
 * This file is part of the Azurengine video engine driver for Linux
 *
 * Copyright (c) 2016-present,  Azurengine, Inc.
 * All rights reserved.
 *
 * This source code is licensed under both the BSD-style license (found in the
 * LICENSE file in the root directory of this source tree) and the GPLv2 (found
 * in the COPYING file in the root directory of this source tree).
 * You may select, at your option, one of the above-listed licenses.
 */

#ifndef __VE_CDEV_CTRL_H__
#define __VE_CDEV_CTRL_H__
#include <linux/ioctl.h>
/* interrtupt manager */
#include <linux/kfifo.h>
#include <linux/wait.h>
#include <linux/spinlock.h>
#include <linux/version.h>
#include "rpp_ve_vmm.h"

/*user defined instance quantity*/
#define DECODER_INSTANCE_NUM        8    /*number codec instance for user, should less than 8 */
#define MJPEG_INSTANCE_NUM          8    /*number mjpeg instance for user, should less than 8 */

/*Note!!! Don't modify below contents while you don't confirm with omx*/
#define VE_SUPPORT_MULTI_CLIENT         /* x86 ve driver support multi processor mode */

#define VE_CODEC_NUM               4    /* number codec of rpp device */
#define VE_CODEC_INSTANCE_NUM      8    /* numbers instance per codec */

#define VE_JPEG_NUM                4    /* number jpeg of rpp device */
#define VE_JPEG_INSTANCE_NUM       8    /* numbers instance per jpeg(software) */
#define JPEG_INSTANCE_CORE         0    /* hardware instance num of jpeg codec, use instance 0 only*/

#define CODEC_ENGINE_NUM           (VE_CODEC_NUM > VE_JPEG_NUM? VE_CODEC_NUM:VE_JPEG_NUM) 
#define CODEC_INSTANCE_NUM         (VE_CODEC_INSTANCE_NUM > VE_JPEG_INSTANCE_NUM? VE_CODEC_INSTANCE_NUM:VE_JPEG_INSTANCE_NUM)

#define DMA_BUFFER_SIZE            8192                                 /* size of dma buffer fore ve feeding cache */
#define DMA_POOL_SIZE              (VE_CODEC_NUM*VE_CODEC_INSTANCE_NUM) /* size of dma pool */
#define DMA_OFFSET_HIGH            (DMA_BUFFER_SIZE*(DMA_POOL_SIZE-1))  /* offset of dma buffer highest */
#define DMA_BUFFER_LENGTH          (DMA_BUFFER_SIZE*DMA_POOL_SIZE)      /* length of dma buffer pool, should  <= 4MB */

#define VE_PCIE_DMA_CH             3

/* size for write and read user dma buffer, should <= 4MB */
#define WR_USER_DMA_BUFFER_SIZE    (1920*1080*2)                        /* FHD 8bit frame only */

/* VE Register I/O mapping area */
#define RPP_MAP_VECFG_ADDR          0x1002000000
#define RPP_MAP_VECFG_SIZE          0x80000

/* mmapping offset for dma buffers */
#define DMA_BUFFER_MAP_ADDR_START   0
#define DMA_BUFFER_MAP_ADDR_END     (DMA_BUFFER_MAP_ADDR_START+DMA_BUFFER_LENGTH)

#ifndef PAGE_SIZE
#define PAGE_SIZE                   4096
#endif
/* mmapping offset for user dma read/write buffers(support 4 cores) */
#define WUSR0_BUFFER_MAP_ADDR_START     (((DMA_BUFFER_MAP_ADDR_END+PAGE_SIZE-1)/PAGE_SIZE)*PAGE_SIZE)
#define WUSR0_BUFFER_MAP_ADDR_END       (WUSR0_BUFFER_MAP_ADDR_START+WR_USER_DMA_BUFFER_SIZE)
#define RUSR0_BUFFER_MAP_ADDR_START     (((WUSR0_BUFFER_MAP_ADDR_END+PAGE_SIZE-1)/PAGE_SIZE)*PAGE_SIZE)
#define RUSR0_BUFFER_MAP_ADDR_END       (RUSR0_BUFFER_MAP_ADDR_START+WR_USER_DMA_BUFFER_SIZE)

#define WUSR1_BUFFER_MAP_ADDR_START     (((RUSR0_BUFFER_MAP_ADDR_END+PAGE_SIZE-1)/PAGE_SIZE)*PAGE_SIZE)
#define WUSR1_BUFFER_MAP_ADDR_END       (WUSR1_BUFFER_MAP_ADDR_START+WR_USER_DMA_BUFFER_SIZE)
#define RUSR1_BUFFER_MAP_ADDR_START     (((WUSR1_BUFFER_MAP_ADDR_END+PAGE_SIZE-1)/PAGE_SIZE)*PAGE_SIZE)
#define RUSR1_BUFFER_MAP_ADDR_END       (RUSR1_BUFFER_MAP_ADDR_START+WR_USER_DMA_BUFFER_SIZE)

#define WUSR2_BUFFER_MAP_ADDR_START     (((RUSR1_BUFFER_MAP_ADDR_END+PAGE_SIZE-1)/PAGE_SIZE)*PAGE_SIZE)
#define WUSR2_BUFFER_MAP_ADDR_END       (WUSR2_BUFFER_MAP_ADDR_START+WR_USER_DMA_BUFFER_SIZE)
#define RUSR2_BUFFER_MAP_ADDR_START     (((WUSR2_BUFFER_MAP_ADDR_END+PAGE_SIZE-1)/PAGE_SIZE)*PAGE_SIZE)
#define RUSR2_BUFFER_MAP_ADDR_END       (RUSR2_BUFFER_MAP_ADDR_START+WR_USER_DMA_BUFFER_SIZE)

#define WUSR3_BUFFER_MAP_ADDR_START     (((RUSR2_BUFFER_MAP_ADDR_END+PAGE_SIZE-1)/PAGE_SIZE)*PAGE_SIZE)
#define WUSR3_BUFFER_MAP_ADDR_END       (WUSR3_BUFFER_MAP_ADDR_START+WR_USER_DMA_BUFFER_SIZE)
#define RUSR3_BUFFER_MAP_ADDR_START     (((WUSR3_BUFFER_MAP_ADDR_END+PAGE_SIZE-1)/PAGE_SIZE)*PAGE_SIZE)
#define RUSR3_BUFFER_MAP_ADDR_END       (RUSR3_BUFFER_MAP_ADDR_START+WR_USER_DMA_BUFFER_SIZE)

/* ve frame buffer output mode & ve app data inject mode
 * ve frame buffer(uncompressed) dma copy to dma buffer(host), then copy to user buffer
 * app data copy to dma buffer(host), then dma copy to ve device memory
 * VE_FRAME_BUFFER_CACHE for ruser/wuser dma buffer allocation
*/
#undef  VE_FRAME_BUFFER_CACHE       /* support dma buffer relay for ruser/wuser data */

/* Link list buffer for VE dma channel
 * Notice: link list buffer should iomapped to system memory space while pcie initial,
 * otherwise dma ll api can't work correctly and segment fault happen
 * Doesn't support DMA link list mode current. Detailed to check RPP_probe
*/
#undef  VE_DMA_LL_BUFFER            /* dma link list buffer flag */

#ifdef VE_DMA_LL_BUFFER
#define VE_DMA_LL_NUM               2048                                /* Maxiume of elements for LL DMA */
#else
#define VE_DMA_LL_NUM               0                                   /* Maxiume of elements for LL DMA */
#endif
#define VE_DMA_LL_BUF_SIZE         ((VE_DMA_LL_NUM+1)*6*2)              /* ll buffer length per channel */

#define SUPPORT_VE_ISR
#if ((VE_CODEC_INSTANCE_NUM > 1 || VE_JPEG_INSTANCE_NUM > 1) && defined(SUPPORT_VE_ISR))
    #define SUPPORT_MULTI_INST_INTR
#endif

#ifdef SUPPORT_MULTI_INST_INTR
#define VE_ISR_TASKLET              1                                   /* ve isr implement by tasklet */
#endif

#define SIZE_COMMON                 (2*1024*1024)                       /* codec common memery size per core */

#ifdef VE_SUPPORT_MULTI_CLIENT
#define INSTANCE_POOL_MAP_LENGTH    4096                                /* please check the vdi.h for 4 x vpu_instance_pool_t,
                                                                         * very important!!!
                                                                        */
#define JPEG_POOL_MAP_LENGTH        4096                                /* please check the jdi.h for 4 x vpu_instance_pool_t */

  #ifdef VE_FRAME_BUFFER_CACHE
#define INSTANCE_POOL_MAP_ADDR_START (((RUSR3_BUFFER_MAP_ADDR_END+PAGE_SIZE-1)/PAGE_SIZE)*PAGE_SIZE)
  #else
#define INSTANCE_POOL_MAP_ADDR_START (((DMA_BUFFER_MAP_ADDR_END+PAGE_SIZE-1)/PAGE_SIZE)*PAGE_SIZE)
  #endif
#define INSTANCE_POOL_MAP_ADDR_END   (INSTANCE_POOL_MAP_ADDR_START+INSTANCE_POOL_MAP_LENGTH)

#define JPEG_POOL_MAP_ADDR_START     (((INSTANCE_POOL_MAP_ADDR_END+PAGE_SIZE-1)/PAGE_SIZE)*PAGE_SIZE)
#define JPEG_POOL_MAP_ADDR_END       (JPEG_POOL_MAP_ADDR_START+JPEG_POOL_MAP_LENGTH)

#undef  SUPPORT_CUSTOMER_INFO_VMEM                                      /* support vmem allocate attach customer info */
#define ENABLE_MUTEX_T_RESTORE          1                               /* support mutex restore configuration while crash happen */
#define SUPPORT_CRASH_REPAIRED                                          /* support instance crash repaired */
#endif

#define INSTANCE_CORRECT_REQUEST    0x5555                              /* request for instance crash correct */
#define INSTANCE_CORRECT_START      0x6666                              /* running for instance crash correct */
#define INSTANCE_CORRECT_CLOSE      0x7777                              /* closed  for instance crash correct */
#define INSTANCE_CORRECT_RESET      0x0000                              /* initial  for instance crash correct */
#define CORRECT_RESPONDING_WAIT     50                                  /* correcting waiting time (n*500us) */
#define CORRECT_STOPING_WAIT        50                                  /* try times to stop instance */

/* memory region define for VPU HAL mmap
 * 1)vdi common memory, 0x40000
 * 2)rpc buffer, 48KByte per vpu core, 0x380000~0x4000000, 512KB total
 * Notice, aboved memory remap to bar0 region, size doesn't over bar map
 * VPU_HAL_MPU: enable VPU HAL MPU support (make variant=vpu / platform.mk)
*/

#ifdef VPU_HAL_MPU
#define VPU_RPC_MEMORY_OFFSET       (0x380000)                          /* offset in the bar0 memory */
#define VPU_RPC_MEMORY_START        (((VPU_RPC_MEMORY_OFFSET+PAGE_SIZE-1)/PAGE_SIZE)*PAGE_SIZE)
#define VPU_RPC_MEMORY_LENGTH       (48*1024*VE_CODEC_NUM)              /* vpu rpc command memory length */
#define VPU_RPC_MEMORY_END          (VPU_RPC_MEMORY_START+VPU_RPC_MEMORY_LENGTH)
#endif
#define MPU_VDI_MEMORY_OFFSET       0x40000                             /* mpu vdi memory offset for vdi dbase */
/******************************************************************************
* Notice Here:
* Any modification in this file should carefully and synchronize to user client
* please verify the modification with rpp_vdev_ctrl.h
* AZURENGEINE_OMX/verdor/R8-CNM/drv_api/rpp_drv_api/rpp_vdev_ctrl.h
******************************************************************************/
struct CodecInstance{
    int8_t index;                       /* -1 - invalid codec id, 0~max - codec id */
    int8_t ref;
};

struct DataInstance{
    int8_t used[CODEC_INSTANCE_NUM];    /* 0 - free; 1, allocated */
    int8_t ref[CODEC_INSTANCE_NUM];     /* instance number */
};

struct CodecEngine{
    struct CodecInstance codecs[CODEC_ENGINE_NUM];
    struct DataInstance dbInst[CODEC_ENGINE_NUM];
    int8_t avail_ins;                   /* remained the codec instace */
    int8_t populated;                   /* any video application populated */
    int8_t codec_min;                   /* min codec core hold */
    int8_t codec_max;                   /* max codec core hold */
    int8_t ins_max;                     /* instance per core */
};

#ifdef VE_FRAME_BUFFER_CACHE
struct DmaUser{
    uint64_t wuser;                     /* map start address for write dma */
    uint32_t wusersize;                 /* size of wuser dma */
    uint64_t ruser;                     /* map start address for read dma */
    uint32_t rusersize;                 /* size of ruser dma */
};
#endif

struct MemoryInfo{
    unsigned long   total_pages;        /* virtual memery information */
    unsigned long   alloc_pages;
    unsigned long   free_pages;
    unsigned long   page_size;

    uint64_t m_dma_addr;                /* map start address of dma buf */
    uint32_t m_dma_size;                /* size of dma buf */
    uint64_t m_mio_addr;                /* map start address of memory io */
    uint32_t m_mio_size;                /* size of memory io */

    struct {
        uint32_t size;                  /* video engine memory size */
        unsigned long phys_addr;        /* video engine mermory start (physical) address */
        size_t        virt_addr;        /* virtual user space address(mmap) */
    }ve_mem;

    struct{
        uint32_t size;                  /*vpu register space size*/
        unsigned long phys_addr;        /*vpu register start (physical) address*/
        size_t        virt_addr;        /*virtual user space address(mmap)*/
    }ve_register;

#ifdef VE_FRAME_BUFFER_CACHE
    struct DmaUser m_dma_user[VE_CODEC_NUM];    /* user dma infomation */
#endif

#ifdef VE_SUPPORT_MULTI_CLIENT
    uint64_t m_instance_pool_addr;      /* map start address of instance pool */
    uint32_t m_instance_pool_size;      /* size of instance pool */ 
    uint64_t m_jpeg_pool_addr;          /* map start address of jpeg instance pool */
    uint32_t m_jpeg_pool_size;          /* size of instance jpeg pool */ 
#endif

    uint64_t m_vpu_addr;                 /* map start address for vpu rpc */
    uint32_t m_vpu_size;                 /* size of vpu rpc */
};

struct CodecInfo{
    int8_t avali_ins;                   /* remain instance */
    int8_t populated;                   /* any instance residence */
};

struct DmaPool{
    uint8_t used;                       /* dma buffer free or used */
    uint8_t index;                      /* index of dma buffer id */
};

struct DmaBufRequest{
    int32_t offset;                     /* offset of dma buffer pool */
    uint32_t size;                      /* dma buffer actual size */
};

struct DmaElement{
    uint32_t size;                      /* size of DMA transform */
    uint64_t dmahost;                   /* dma address of host */
    uint64_t dmacodec;                  /* dma address of codec device */
};

struct DmaRequest{
    uint32_t size;                      /* size of request transform */
    uint32_t offset;                    /* offset for ve dma buffer */
    uint64_t host;                      /* host buffer address(VM address, it should
                                           be phyical continued!!!) */
    uint64_t device;                    /* ve device buffer address(physical ddr address) */
};

struct IntrRequest{
    uint32_t intr_core_index;           /* index or vpu core */
    uint32_t intr_inst_index;           /* index of instance */
    int      timeout;                   /* timeout of request */
    uint32_t intr_reason;               /* reason of interrupt, return back */
};

struct InstRequest{
    uint32_t inst_core_index;           /* index or vpu core */
    uint32_t inst_inst_index;           /* index of instance */
    uint32_t IsCodec;                   /* type of request */
    int      inst_count;                /* inst count for current coreIdx */
};

struct Vmem_DmaMemory{
    uint32_t        size;               /* size of dma memory block */
    unsigned long   phys_addr;          /* physical addr of dma memory */
    unsigned long   base;               /* base addr */
    unsigned long   virt_addr;          /* virtual addr of dma memory */
#ifdef SUPPORT_CUSTOMER_INFO_VMEM
    uint32_t        coreIdx;            /* assign to instance of coreIdx */
    uint32_t        instIdx;            /* assing to instance of instIdx */
#endif
};

struct InstRegRequest{
    uint32_t IsCodec;                   /* codec(0) or jpeg(1)*/
    uint32_t coreIdx;                   /* core index */
    uint32_t regAddr;                   /* register address */
    uint32_t regData;                   /* register data for read/write */
};

struct InstPool_t{
    uint32_t        size;               /* size of dma memory block */
    unsigned long   phys_addr;          /* physical addr of dma memory */
    unsigned long   base;               /* base addr */
    unsigned long   virt_addr;          /* virtual addr of dma memory */
    int             sizePMutex;         /* length of pthread mutex handle */
    int             nPMutex;            /* numbers of pthread mutex handle */
};

struct vdi_buffer_t{
    uint32_t size;                      /* size of bufferblock */
    uint64_t phys_addr;                 /* physical addr of vdi buffer */
    void     *base;                     /* base address of vdi buffer */
    uint64_t virt_addr;                 /* virtual addr of vdi buffer*/
};

#ifdef VE_FRAME_BUFFER_CACHE
struct DmaInfo_t{
    void        *dma_wuser;             /* dma buffer address for cache frame write */
    uint64_t    dma_wuser_handle;       /* dma physical address for cache frame write */
    void        *dma_ruser;             /* dma buffer address for cache user data read */
    uint64_t    dma_ruser_handle;       /* dma physical address for cache user data read */
};
#endif

/* vpu info description
 * 00000001, vpu hungup, should cold reset
 * 00000010, instance corrupted, should cold reset
 * 00000100, vpu busy
 * 00001000, vcore busy
 * 00010000, vpu-vcpu bus busy
*/
struct VpuInfoRequest{
    uint32_t coreIdx;                   /* vpu core index */
    uint32_t vpuInfo;                   /* vpu information */
};

struct VpuCrashReqest{
    uint32_t coreIdx;                   /* vpu core index */
    int state;                          /* vpu crash state */
};

struct VideoEngine{
    struct MemoryInfo   memInfo;        /* ve codec memory information*/
    struct CodecEngine  codec;          /* codec instance pool*/
    struct CodecEngine  jpeg;           /* jpeg instance pool*/
    struct DmaPool      dmapool[DMA_POOL_SIZE]; /* dma buffer pool*/
    int8_t              avali_dma;      /* remain dma buf */
    void                *dma;           /* dma buffer address for user mapping */
    uint64_t            dma_handle;     /* dma physical address for codec feeding */
#ifdef VE_FRAME_BUFFER_CACHE
    struct DmaInfo_t    dma_user[VE_CODEC_NUM];      /* user dam handle info */
#endif
#ifdef VE_DMA_LL_BUFFER
    uint64_t            dma_ll_base;    /* ve dma ll buffer base */
#endif
#ifdef VE_SUPPORT_MULTI_CLIENT
    struct InstPool_t   instance_pool;  /* instance memory for all ve core */
    struct InstPool_t   jpeg_pool;      /* instance memory for all jpeg core */
#endif
    struct vdi_buffer_t common_memory;  /* common memery info for all ve core */
    video_mm_t          vmem;           /* virtual memeory handle for ve */
    uint32_t            vpu_info;       /* vpu status for all cores */
    int8_t              state_flag;     /* chip state, b0: workloading heavely */
    int                 vdi_param_status;/*vdi param status*/
};

struct InterruptManager{
    int vint_flag[VE_CODEC_NUM][VE_CODEC_INSTANCE_NUM];
    wait_queue_head_t vint_wait[VE_CODEC_NUM][VE_CODEC_INSTANCE_NUM];

    struct kfifo vint_queue[VE_CODEC_NUM][VE_CODEC_INSTANCE_NUM];
    spinlock_t vint_lock[VE_CODEC_NUM][VE_CODEC_INSTANCE_NUM];

    int jint_flag[VE_JPEG_NUM][VE_JPEG_INSTANCE_NUM];
    wait_queue_head_t jint_wait[VE_JPEG_NUM][VE_JPEG_INSTANCE_NUM];

    struct kfifo jint_queue[VE_JPEG_NUM][VE_JPEG_INSTANCE_NUM];
    spinlock_t jint_lock[VE_JPEG_NUM][VE_JPEG_INSTANCE_NUM];
};

/* Use 'x' as magic number */
#define VE_IOC_MAGIC    'v'
/*
 * _IO(type,nr)             no arguments
 * _IOR(type,nr,datatype)   read data from driver
 * _IOW(type,nr.datatype)   write data to driver
 * _IORW(type,nr,datatype)  read/write data
 *
 * _IOC_DIR(nr)         returns direction
 * _IOC_TYPE(nr)        returns magic
 * _IOC_NR(nr)          returns number
 * _IOC_SIZE(nr)        returns size
 */

/**
 * Ioctl function type.
 *
 * \param p amdkfd process pointer.
 * \param data pointer to arg that was copied from user.
 * \param filep pointer to file structure.
 */
typedef int ve_ioctl_t(struct file *filp, struct rpp_dev *pdev, void *data);

struct ve_ioctl_desc {
    unsigned int cmd;
    int flags;
    ve_ioctl_t *func;
    unsigned int cmd_drv;
    const char *name;
};

/* IOCTL codes */
#define VE_IOCTL_START              0x00
#define VE_IOCTL_GET_MEMINFO        0x00    /* get ve memory info */
#define VE_IOCTL_ALLOC_DMA_BUF      0x01    /* alloc dma buffer for codec instance */
#define VE_IOCTL_FREE_DMA_BUF       0x02    /* free dma buffer for codec instance */
#define VE_IOCTL_WRITE_DMA_BUF      0x03    /* write dma buffer for codec instance */
#define VE_IOCTL_READ_DMA_BUF       0x04    /* read dma buffer for codec instance */
#define VE_IOCTL_ALLOC_CODEC        0x05    /* alloc codec instance */
#define VE_IOCTL_FREE_CODEC         0x06    /* free codec instance */
#define VE_IOCTL_GET_CODECINFO      0x07    /* get codec info */
#define VE_IOCTL_ALLOC_JPEG         0x08    /* alloc jpec instance */
#define VE_IOCTL_FREE_JPEG          0x09    /* free jpeg instance */
#define VE_IOCTL_GET_JPEGINFO       0x0a    /* get jpec info */
#define VE_IOCTL_WRITE_USER_BUF     0x0b    /* write dma buffer to host */
#define VE_IOCTL_READ_USER_BUF      0x0c    /* read dma buffer to device */
#define VE_IOCTL_GET_CODEC_INTR     0x0d    /* get codec interrupt flag */
#define VE_IOCTL_GET_JPEG_INTR      0x0e    /* get jpeg interrupt flag */
#define VE_IOCTL_ALLOC_INST         0x0f    /* alloc instance(kfifo) */
#define VE_IOCTL_FREE_INST          0x10    /* free instance(kfifo) */
#define VE_IOCTL_GET_COMMON_MEMORY  0x11    /* get common memory for vpu firmare */
#define VE_IOCTL_ALLOC_DMA_MEMORY   0x12    /* alloc dma memory for codec/jpeg instance */
#define VE_IOCTL_FREE_DMA_MEMORY    0x13    /* free dma memory for codec/jpeg instance */
#define VE_IOCTL_GET_CODEC_POOL     0x14    /* get codec instance pool */
#define VE_IOCTL_READ_REG           0x15    /* read register */
#define VE_IOCTL_WRITE_REG          0x16    /* write register */
#define VE_IOCTL_READ_VPU_INFO      0x17    /* read VPU status by monitor */
#define VE_IOCTL_WRITE_VPU_INFO     0x18    /* write VPU status by app */
#define VE_IOCTL_WRITE_STATE_FLAG   0x19    /* write chip state flag */
#define VE_IOCTL_GET_JPEG_POOL      0x1a    /* get jpeg instance pool*/
#define VE_IOCTL_GET_CRASH_STATE    0x1b    /* get crash state*/
#define VE_IOCTL_SET_CRASH_STATE    0x1c    /* set crash state*/
#define VE_IOCTL_VPU_VDI_PARAM      0x1d    /* set mpu vdi parameter*/
#define VE_IOCTL_END                0x1e

#define VE_IO(nr)                   _IO(VE_IOC_MAGIC,nr)
#define VE_IOR(nr,type)             _IOR(VE_IOC_MAGIC,nr,type)
#define VE_IOW(nr,type)             _IOW(VE_IOC_MAGIC,nr,type)
#define VE_IOWR(nr,type)            _IOWR(VE_IOC_MAGIC,nr,type)
#define VE_IOCTL_NR(cmd)            _IOC_NR(cmd)

#define VE_GET_MEMINFO              VE_IOWR(VE_IOCTL_GET_MEMINFO, struct MemoryInfo)
#define VE_ALLOC_DMA                VE_IOWR(VE_IOCTL_ALLOC_DMA_BUF, struct DmaBufRequest)
#define VE_FREE_DMA                 VE_IOWR(VE_IOCTL_FREE_DMA_BUF, struct DmaBufRequest)
#define VE_WRITE_DMA                VE_IOWR(VE_IOCTL_WRITE_DMA_BUF, struct DmaRequest)
#define VE_READ_DMA                 VE_IOWR(VE_IOCTL_READ_DMA_BUF, struct DmaRequest)
#define VE_ALLOC_CODEC              VE_IOWR(VE_IOCTL_ALLOC_CODEC, struct CodecInstance)
#define VE_FREE_CODEC               VE_IOWR(VE_IOCTL_FREE_CODEC, struct CodecInstance)
#define VE_GET_CODECINFO            VE_IOWR(VE_IOCTL_GET_CODECINFO, struct CodecInfo)
#define VE_ALLOC_JPEG               VE_IOWR(VE_IOCTL_ALLOC_JPEG, struct CodecInstance)
#define VE_FREE_JPEG                VE_IOWR(VE_IOCTL_FREE_JPEG, struct CodecInstance)
#define VE_GET_JPEGINFO             VE_IOWR(VE_IOCTL_GET_JPEGINFO, struct CodecInfo)
#define VE_WRITE_USER               VE_IOWR(VE_IOCTL_WRITE_USER_BUF, struct DmaRequest)
#define VE_READ_USER                VE_IOWR(VE_IOCTL_READ_USER_BUF, struct DmaRequest)
#define VE_GET_CODEC_INTR           VE_IOWR(VE_IOCTL_GET_CODEC_INTR, struct IntrRequest)
#define VE_GET_JPEG_INTR            VE_IOWR(VE_IOCTL_GET_JPEG_INTR, struct IntrRequest)
#define VE_ALLOC_INST               VE_IOWR(VE_IOCTL_ALLOC_INST, struct InstRequest)
#define VE_FREE_INST                VE_IOWR(VE_IOCTL_FREE_INST, struct InstRequest)
#define VE_GET_COMMON_MEMORY        VE_IOWR(VE_IOCTL_GET_COMMON_MEMORY, struct Vmem_DmaMemory)
#define VE_ALLOC_DMA_MEMORY         VE_IOWR(VE_IOCTL_ALLOC_DMA_MEMORY, struct Vmem_DmaMemory)
#define VE_FREE_DMA_MEMORY          VE_IOWR(VE_IOCTL_FREE_DMA_MEMORY, struct Vmem_DmaMemory)
#define VE_GET_CODEC_INSTANCE_POOL  VE_IOWR(VE_IOCTL_GET_CODEC_POOL, struct InstPool_t)
#define VE_READ_REGISTER            VE_IOWR(VE_IOCTL_READ_REG, struct InstRegRequest)
#define VE_WRITE_REGISTER           VE_IOWR(VE_IOCTL_WRITE_REG, struct InstRegRequest)
#define VE_READ_VPU_INFO            VE_IOWR(VE_IOCTL_READ_VPU_INFO, struct VpuInfoRequest)
#define VE_WRITE_VPU_INFO           VE_IOWR(VE_IOCTL_WRITE_VPU_INFO, struct VpuInfoRequest)
#define VE_WRITE_STATE_FLAG         VE_IOWR(VE_IOCTL_WRITE_STATE_FLAG, int8_t)
#define VE_GET_JPEG_INSTANCE_POOL   VE_IOWR(VE_IOCTL_GET_JPEG_POOL, struct InstPool_t)
#define VE_CET_CRASH_STATE          VE_IOWR(VE_IOCTL_GET_CRASH_STATE, struct VpuCrashReqest)
#define VE_SET_CRASH_STATE          VE_IOWR(VE_IOCTL_SET_CRASH_STATE, struct VpuCrashReqest)
#define VE_VPU_VDI_PARAM            VE_IOWR(VE_IOCTL_VPU_VDI_PARAM, uint64_t)

int rpp_init_veEngine(struct rpp_dev *xpdev, struct VideoEngine *veEngine);
int rpp_destroy_veEngine(struct rpp_dev *xpdev, struct VideoEngine *veEngine);

#ifdef SUPPORT_MULTI_INST_INTR
int rpp_init_veInterrupt(struct rpp_dev *xpdev, struct InterruptManager *veInterrupt);
int rpp_destroy_veInterrupt(struct rpp_dev *xpdev, struct InterruptManager *veInterrupt);

void codec0_isr_handler(void *dev);
void codec1_isr_handler(void *dev);
void codec2_isr_handler(void *dev);
void codec3_isr_handler(void *dev);
void jpeg0_isr_handler(void *dev);
void jpeg1_isr_handler(void *dev);
void jpeg2_isr_handler(void *dev);
void jpeg3_isr_handler(void *dev);

#endif
#endif /* _VE_ENTIRE_CTRL_H_ */

