/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright (c) 2018 Synopsys, Inc. and/or its affiliates.
 * Synopsys DesignWare eDMA controller driver.
 */

#ifndef __RPP_DMA_H__
#define __RPP_DMA_H__

/*******************************************************************************
 *
 *  HEADER FILE INCLUDES
 *
 ******************************************************************************/

#include "rpp_types.h"

/******************************************************************************
 *
 *  DATA STRUCTURE DEFINITIONS
 *
 ******************************************************************************/

/**
 * Physical address.
 */
typedef union {
    struct {
        UINT32 LowPart;
        UINT32 HighPart;
    };
    UINT64 QuadPart;
} PHYADDR;

/**
 * The direction of DMA transfer.
 */
typedef enum {
    DMA_WRITE = 0,  /**< Write */
    DMA_READ        /**< Read */
} DMA_DIRC;

/**
 * DMA transfer mode.
 */
typedef enum {
    DMA_SINGLE_BLOCK = 0,/**< Single block mode */
    DMA_MULTI_BLOCK      /**< Multi block mode */
} DMA_XFER_MODE;

/**
 * DMA interrupt type.
 */
typedef enum {
    DMA_INT_DONE = 0,   /**< DONE interrupt */
    DMA_INT_ABORT       /**< ABORT interrupt */
} DMA_INT_TYPE;

/**
 * DMA Channel status.
 */
typedef enum {
    CHAN_UNKNOWN = 0,   /**< Unknown */
    CHAN_RUNNING,       /**< Channel is running */
    CHAN_HALTED,        /**< Channel is halted */
    CHAN_STOPPED,       /**< Channel is stopped */
    CHAN_QUEUING	    /**< Queuing. Not a real HW status */
} DMA_CHAN_STATUS;

/**
 * DMA hardware error types.
 */
typedef enum {
    DMA_ERR_NONE,       /**< No DMA error found */
    DMA_ERR_WR,         /**< The DMA Write Channel has received an error
                         *   response from the AHB/AXI bus (or RTRGT1 interface
                         *   when the AHB/AXI Bridge is not used) while reading
                         *   data from it. It's fatal error. */
    DMA_ERR_RD,         /**< The DMA Read Channel has received an error response
                         *   from the AHB/AXI bus (or RTRGT1 interface when the
                         *   AHB/AXI Bridge is not used) while writing data to
                         *   it. It's fatal error.*/
    DMA_ERR_FETCH_LL,   /**< The DMA Write/Read Channel has received an error
                         *   response from the AHB/AXI bus (or RTRGT1 interface
                         *   when the AHB/AXI Bridge is not used) while reading
                         *   a Linked List Element from local memory. It's fatal
                         *   error. */
    DMA_ERR_UNSUPPORTED_RQST,
                        /**< The DMA Read Channel has received a PCIe
                         *   Unsupported Request CPL status from the remote
                         *   device in response to the MRd Request.*/
    DMA_ERR_COMPLETER_ABORT,
                        /**< The DMA Read Channel has received a PCIe Completer
                         *  Abort CPL status from the remote device in response
                         *  to the MRd Request. Non-fatal error.
                         */
    DMA_ERR_CPL_TIME_OUT,
                        /**< The DMA Read Channel has timed-out while waiting
                         * for the remote device to respond to the MRd Request,
                         * or a malformed CplD has been received. Non-fatal
                         * error. */
    DMA_ERR_DATA_POISONING,
                        /**< The DMA Read Channel has detected data poisoning
                         * in the CPL from the remote device in response to the
                         * MRd Request. Non-fatal error. */
} DMA_ERR;

/******************************************************************************
 *
 *  DATA STRUCTURE DECLARATIONS
 *
 ******************************************************************************/
/**
 * The object type which holds all DMA registers. It's transparent to the user
 * of dma.h.
 */
typedef struct DMA_REGS *PDMA_REGS;


/*******************************************************************************
 *
 * DEVICE REGISTERS
 *
 ******************************************************************************/
/**
 * The Enable Register for read and write.
 */
typedef union {
    struct {
        /* LSB */
        UINT32      Enb         :1;  /*  0 */
        UINT32      Reserved0   :31; /*  1:31 */
        /* MSB */
    };
    UINT32 AsDword;
} ENB;

/**
 * The DMA Control Register.
 */
typedef union {
    struct {
        /* LSB */
        UINT32      WrChans     :4;  /*  0:3 */
        UINT32      Reserved0   :12; /*  4:15 */
        UINT32      RdChans     :4;  /*  16:19 */
        UINT32      Reserved1   :12; /*  20:31 */
        /* MSB */
    };
    UINT32 AsDword;
} DMA_CTRL;

/**
 * The Doorbell Register for read and write.
 */
typedef union {
    struct {
        /* LSB */
        UINT32      Chnl        :3;  /*  0 */
        UINT32      Reserved0   :28; /*  3:30 */
        UINT32      Stop        :1;  /*  31 */
        /* MSB */
    };
    UINT32 AsDword;
} DOORBELL;

/**
 * The Interrupt Status Register for read and write.
 */
typedef union {
    struct {
        /* LSB */
        UINT32      DoneSta     :8;
        UINT32      Rsvd0       :8;
        UINT32      AbortSta    :8;
        UINT32      Rsvd1       :8;
        /* MSB */
    };
    UINT32 AsDword;
} INT_STATUS;

/**
 * The Interrupt Clear Register for read and write.
 */
typedef union {
    struct {
        /* LSB */
        UINT32      DoneClr     :8;
        UINT32      Rsvd0       :8;
        UINT32      AbortClr    :8;
        UINT32      Rsvd1       :8;
        /* MSB */
    };
    UINT32 AsDword;
} INT_CLEAR;

/**
 * The Error Status Register for read and write.
 */
typedef union {
    struct {
        /* LSB */
        UINT32      BrdgErr     :8;
        UINT32      Rsvd0       :8;
        UINT32      LLErr       :8;
        UINT32      Rsvd1       :8;
        /* MSB */
    };
    UINT32 AsDword;
} WR_ERR, RD_ERR_LO;

/**
 * Extra Error Status Register for read.
 */
typedef union {
    struct {
        /* LSB */
        UINT32      UrErr       :8;
        UINT32      CaErr       :8;
        UINT32      ToErr       :8;
        UINT32      EpErr       :8;
        /* MSB */
    };
    UINT32 AsDword;
} RD_ERR_HI;

/**
 * The Channel Control Register for read and write.
 */
typedef union {
    struct {
        /* LSB */
        UINT32      CB          :1;    /*  0 */
        UINT32      TCB         :1;    /*  1 */
        UINT32      LLP         :1;    /*  2 */
        UINT32      LIE         :1;    /*  3 */
        UINT32      RIE         :1;    /*  4 */
        UINT32      DMA_CS      :2;    /*  5:6 */
        UINT32      Rsvd1       :1;    /*  7 */
        UINT32      CCS         :1;    /*  8 */
        UINT32      LLEN        :1;    /*  9 */
        UINT32      b_64S       :1;    /*  10 */
        UINT32      b_64D       :1;    /*  11 */
        UINT32      PF          :5;    /*  12:16 */
        UINT32      Rsvd2       :7;    /*  17:23 */
        UINT32      SN          :1;    /*  24 */
        UINT32      RO          :1;    /*  25 */
        UINT32      TD          :1;    /*  26 */
        UINT32      TC          :3;    /*  27:29 */
        UINT32      AT          :2;    /*  30:31 */
        /* MSB */
    };
    UINT32 AsDword;
} CHAN_CTRL_LO;

/**
 * The Channel Control Register high part for read and write.
 */
typedef union {
    struct {
        /* LSB */
        UINT32      VFEnb       :1;     /*  0 */
        UINT32      VFunc       :8;     /*  1-8 */
        UINT32      Rsvd0       :23;    /*  9-31 */
        /* MSB */
    };
    UINT32 AsDword;
} CHAN_CTRL_HI;

/**
 * The Context Registers for read and write.
 */
typedef struct {
    CHAN_CTRL_LO    CtrlLo;     /*  0x00 */
    CHAN_CTRL_HI    CtrlHi;     /*  0x04 */
    UINT32          XferSize;   /*  0x08 */
    UINT32          SarPtrLo;   /*  0x0C */
    UINT32          SarPtrHi;   /*  0x10 */
    UINT32          DarPtrLo;   /*  0x14 */
    UINT32          DarPtrHi;   /*  0x18 */
    UINT32          ElPtrLo;    /*  0x1C */
    UINT32          ElPtrHi;    /*  0x20 */
} CTX_REGS;

/**
 * The Context Registers Combo
 */
typedef struct {
    UINT32	    DMARegGap_1[55];
    CTX_REGS        CtxRegs_WR;
    UINT32	    DMARegGap_2[55];
    CTX_REGS        CtxRegs_RD;
} CTX_GRP;

/**
 * The Context Register selector for read and write.
 */
typedef union {
    struct {
        /* LSB */
        UINT32      ViwPnt      :3;     /*  0:2 */
        UINT32      Rsvd0       :28;    /*  3:30 */
        UINT32      Sel         :1;     /*  31 */
        /* MSB */
    };
    UINT32  AsDword;
} CTX_SEL;

/**
 * The Channel Weight Register.
 */
typedef union {
    struct {
        /* LSB */
        UINT32      Weight0     :5;     /*  0:4 */
        UINT32      Weight1     :5;     /*  5:9 */
        UINT32      Weight2     :5;     /*  10:14 */
        UINT32      Weight3     :5;     /*  15:19 */
        UINT32      Rsvd        :12;    /*  20:31 */
        /* MSB */
    };
    UINT32 AsDword;
} WEIGHT;

/**
 * The Linked List Interrupt Error Enable Register for write and read
 */
typedef union {
    struct {
        /* LSB */
        UINT32      Reie        :8;     /*  0:7 */
        UINT32      Rsvd0       :8;     /*  8:15 */
        UINT32      Leie        :8;     /*  16:23 */
        UINT32      Rsvd1       :8;     /*  24:31 */
        /* MSB */
    };
    UINT32 AsDword;
} LL_ERR_ENB;


/**
 * DMA Registers starts from 0x970 to 0xB2C.
 */
struct DMA_REGS {
    UINT32          Rsvd0[2];       /*  0x970 - 0X974 */

    /* Control Registers */
    DMA_CTRL        DmaCtrl;        /*  0x978 */
    ENB             WrEnb;          /*  0x97C */
    DOORBELL        WrDb;           /*  0x980 */
    UINT32          WrCtrl;         /*  0x984 */
    WEIGHT          WrWeiLo;        /*  0x988 */
    WEIGHT          WrWeiHi;        /*  0x98C */
    UINT32          Rsvd1[3];       /*  0x990 - 0x998 */
    ENB             RdEnb;          /*  0x99C */
    DOORBELL        RdDb;           /*  0x9A0 */
    UINT32          RdCtrl;         /*  0x9A4 */
    WEIGHT          RdWeiLo;        /*  0x9A8 */
    WEIGHT          RdWeiHi;        /*  0x9AC */
    UINT32          Rsvd2[3];       /*  0x9B0 - 0x9B8 */

    /* Status and Interrupt Registers*/
    INT_STATUS      WrIntSta;       /*  0x9BC */
    UINT32          Rsvd3;          /*  0x9C0 */
    UINT32          WrIntMsk;       /*  0x9C4 */
    INT_CLEAR       WrIntClr;       /*  0x9C8 */
    WR_ERR          WrErrSta;       /*  0x9CC */
    UINT32          WrMsgDonAddrLo; /*  0x9D0 */
    UINT32          WrMsgDonAddrHi; /*  0x9D4 */
    UINT32          WrMsgAbtAddrLo; /*  0x9D8 */
    UINT32          WrMsgAbtAddrHi; /*  0x9DC */
    UINT16          WrMsgData[8];   /*  0x9E0 - 0x9EC data/channel */
    UINT32          Rsvd4[4];       /*  0x9F0 - 0x9FC */
    LL_ERR_ENB      WrIntLLErrEnb;  /*  0xA00 */
    UINT32          Rsvd5[3];       /*  0xA04 - 0xA0C */
    INT_STATUS      RdIntSta;       /*  0xA10 */
    UINT32          Rsvd6;          /*  0xA14 */
    UINT32          RdIntMsk;       /*  0xA18 */
    INT_CLEAR       RdIntClr;       /*  0xA1C */
    UINT32          Rsvd7;          /*  0xA20 */
    RD_ERR_LO       RdErrStaLo;     /*  0xA24 */
    RD_ERR_HI       RdErrStaHi;     /*  0xA28 */
    UINT32          Rsvd8[2];       /*  0xA2C - 0xA30 */
    LL_ERR_ENB      RdIntLLErrEnb;  /*  0xA34 */
    UINT32          Rsvd9;          /*  0xA38 */
    UINT32          RdMsgDonAddrLo; /*  0xA3C */
    UINT32          RdMsgDonAddrHi; /*  0xA40 */
    UINT32          RdMsgAbtAddrLo; /*  0xA44 */
    UINT32          RdMsgAbtAddrHi; /*  0xA48 */
    UINT16          RdMsgData[8];   /*  0xA4C - 0xA58 data/channel */
    UINT32          Rsvd10[4];      /*  0xA5C - 0xA68 */

    UINT32          Rsvd11[10];
    /* Context Register Unroll */
    CTX_GRP       CtxRegsGrp[8];
};

/******************************************************************************
 *
 *  EXTERN FUNCTION DECLARATIONS
 *
 ******************************************************************************/

/**
* @defgroup hal_api_lo Low level eDMA HAL APIs.
* @{
* The functions in this group are low level HAL APIs. All of them are defined
* in RPP_dma.c
*/
void DmaSetOp(PDMA_REGS pdreg, DMA_DIRC dirc, BOOLEAN enb);
void DmaSetDoorBell(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chnl, BOOLEAN stop);
void DmaSetXferSize(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chnl, UINT32 size);
void DmaSetSrc(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chnl, PHYADDR addr);
void DmaSetDst(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chnl, PHYADDR addr);
void DmaSetWei(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chnl, UINT8 wei);
void DmaSetCtrl(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chnl, DMA_XFER_MODE mode);
void DmaSetLLIntErr(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan, BOOLEAN loc,
        BOOLEAN enb);
void DmaSetMSIAddr(PDMA_REGS pdreg, DMA_DIRC dirc, DMA_INT_TYPE type,
        PHYADDR addr);
void DmaSetMSIData(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan, UINT16 data);
void DmaSetLL(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan, PHYADDR addr);
void DmaSetDataEle(PUINT32 lladdr, UINT32 idx, BOOLEAN pcs, BOOLEAN intr,
        UINT32 xferSize, PHYADDR src, PHYADDR dst);
void DmaSetLinkEle(PUINT32 lladdr, UINT32 idx, BOOLEAN pcs, PHYADDR nxt,
        BOOLEAN recyc);

void DmaGetDataEle(PUINT32 lladdr, UINT32 idx, BOOLEAN *pcs, BOOLEAN *intr,
        UINT32 *xferSize, PHYADDR *src, PHYADDR *dst);
void DmaGetLinkEle(PUINT32 lladdr, UINT32 idx, BOOLEAN *pcs, PHYADDR *nxt);
void DmaGetChanNum(PDMA_REGS pdreg, UINT8 *wrch, UINT8 *rdch);
void DmaGetChanStatus(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chnl,
        DMA_CHAN_STATUS *status);
void DmaGetXferSize(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chnl, UINT32 *size);
void DmaGetElementPtr(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan, PHYADDR *addr);

void DmaClrInt(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan, DMA_INT_TYPE type);
void DmaDumpReg(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan, char *str, int len);
void DmaDumpLL(PUINT32 llAddr, UINT32 llLen, char *str, int len);

BOOLEAN DmaQueryIntSrc(PDMA_REGS pdreg, DMA_DIRC *dirc, UINT8 *chan,
        DMA_INT_TYPE *type);
BOOLEAN DmaQueryErrSrc(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan,
        DMA_ERR *type);
/** @}*/

#endif /* __RPP_DMA_H__ */
