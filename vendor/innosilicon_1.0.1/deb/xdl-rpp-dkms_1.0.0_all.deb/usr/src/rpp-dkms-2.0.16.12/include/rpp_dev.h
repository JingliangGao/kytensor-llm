/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright (c) 2018 Synopsys, Inc. and/or its affiliates.
 * Synopsys DesignWare eDMA controller driver.
 */

#ifndef __RPP_DEV_H__
#define __RPP_DEV_H__


#include <linux/version.h>
#include <linux/cdev.h>
#include <linux/semaphore.h>
#include <linux/pci.h>
#include <linux/time64.h>
#include <linux/kfifo.h>
#include <linux/wait.h>
#include <linux/fs.h>
#include <linux/vmalloc.h>
#include <linux/mutex.h>

#include "version.h"
#include "rpp_types.h"
#include "rpp_dma.h"
#include "rpp_dfx.h"
#include "rpp_hal_dma.h"
#include "rpp_xdata.h"


/*******************************************************************************
 *
 * MACRO DEFINITIONS
 *
 ******************************************************************************/
#define DRV_MODULE_NAME		"RPP"
#define DRV_MODULE_DESC		"XDL RPP Driver"
#define DRVER_NAME          DRV_MODULE_NAME

MODULE_AUTHOR("XDL Technology Inc.");
MODULE_DESCRIPTION("XDL RPP driver");
MODULE_VERSION(DRV_MODULE_VERSION);
MODULE_LICENSE("Dual BSD/GPL");


// modified by jgd
//#define MAX_DEVICE              (1)
#define MAX_DEVICE              (2)
//#define RPP_CDEV_MAJOR         (0)
//#define RPP_NR_DEVS            (1)
//#define RPP_NR_DEVS            (2)
// modified by jgd end


#define BAR_MEM                (0)
#define RPP_BAR_NUM            (6)

/**
 * The device id of PCIe RC device
 */
#define RC_SNPS_VENDOR_ID	0x16C3
#define RC_SNPS_DEVICE_ID	0xEDDC

/**
 * RPP endpoint PCIe IDs and compile-time driver configuration.
 * Platform-specific options (IRQ_NUM, BAR_ACCESS_INLINE) remain in Makefile.
 */
#define RPP_TARGET_VENDOR_ID		0x16C3
#define RPP_TARGET_DEVICE_ID		0xABCD

#define XDATA				0
#define EDMA				1
#define MSI_ONLY			1
#define XDATA_BAR			0
#define XCFG_BAR			2
#define XMPU_BAR			4
#define EDMA_MEM_BAR			0
#define HW_PERFORMANCE_WORKAROUND	0
#define DDR_MEM_OFF			0x0
#define RPP_VE_DISABLE			0
#ifndef ROLLBACK_PROTECTION_V
#define ROLLBACK_PROTECTION_V		0
#endif

#define FIRMWARE			"firmware.bin"
#define FW_CONFIG			"config.bin"

/**
 * Default data pattern.
 */
#define DEFAULT_PATTERN 0x00000001

#define RPP_PCIE_OFFLINE					0x0
#define RPP_PCIE_ONLINE					0x1
#define RTD3_CFG_NUM_MAX					20

/* PCIe link status check constants */
#define PCIE_LINK_STATUS_MASK				0x00000006
#define PCIE_LINK_STATUS_INVALID			0xffffffff

/* ATU configuration constants */
#define ATU_INBOUND_BASE_ADDR				0xc0000000
#define ATU_INBOUND_BASE_ADDR_SMALL_BAR		0x300100
#define ATU_INBOUND_BASE_ADDR_LARGE_BAR		0x7300100
#define ATU_INBOUND_LIMIT_ADDR_SMALL_BAR		0x300104
#define ATU_INBOUND_LIMIT_ADDR_LARGE_BAR		0x7300104
#define ATU_INBOUND_TARGET_LOW_SMALL_BAR		0x300114
#define ATU_INBOUND_TARGET_LOW_LARGE_BAR		0x7300114
#define ATU_INBOUND_TARGET_HIGH_SMALL_BAR	0x300118
#define ATU_INBOUND_TARGET_HIGH_LARGE_BAR	0x7300118

/* PCIe register offsets */
#define PCIE_STATUS_REG_SMALL_BAR			0x04
#define PCIE_STATUS_REG_LARGE_BAR			0x7000004

/* Large bar mapping solution */
#define BAR0_MAP_OFFSET_LARGE_BAR		0x0
#define BAR2_MAP_OFFSET_LARGE_BAR		0x1000000000
#define BAR4_MAP_OFFSET_LARGE_BAR		0x1010000000

/* Small bar mapping solution */
#define BAR0_MAP_OFFSET_SMALL_BAR		0x0
#define BAR2_MAP_OFFSET_SMALL_BAR		0x1002000000
#define BAR4_MAP_OFFSET_SMALL_BAR		0x1007000000

/* MC base address offset from switch bar_mem_start */
#define MC_BASE_ADDR_OFFSET				0x2000000

/* VE frame buffer room definition */
#define VE_FRAME_BUFFER_SIZE        0xFFFE0000                          /* 4GB default, FFFE0000~FFFFFFFF(128KB) reseved for FIO */
#define VE_FRAME_BUFFER_SIZE_1G	    0x3FFE0000                          /* 1GB, 3FFE0000~3FFFFFFF(128KB) reseved for FIO */
#define VE_FRAME_BUFFER_SIZE_2G	    0x7FFE0000                          /* 2GB, 7FFE0000~7FFFFFFF(128KB) reseved for FIO */
#define VE_FRAME_BUFFER_SIZE_8G	    0x1FFFE0000                         /* 8GB, 1FFFE0000~1FFFFFFFF(128KB) reseved for FIO */
#define VE_FRAME_BUFFER_SIZE_16G	0x3FFFE0000                         /* 16GB, 3FFFE0000~3FFFFFFFF(128KB) reseved for FIO */
#define VE_FRAME_BUFFER_SIZE_512M   0x20000000                          /* 512M */

/* VE memory physical address definitions */
#define VE_MEM_PHYS_ADDR_512M		0x20000000
#define VE_MEM_PHYS_ADDR_1GB		0x40000000
#define VE_MEM_PHYS_ADDR_2GB		0x80000000
#define VE_MEM_PHYS_ADDR_4GB_1DDR	0x100000000
#define VE_MEM_PHYS_ADDR_4GB_4DDR	0x300000000

#define TEST_DESC_IN_SRAM      0
#define SRAM_DESC_BAR_OFFS 0x05000000
#define SRAM_DESC_PHYS 0x1005000000

#ifdef PETALINUX_SUPPORT
#define PETALINUX_FPGA_SUPPORT	1
#define PCIE_DMA_PHYS_ADDR_EN 	0
#define ICB_SUPPORT		1

#define PCIE_DMA_PHYS_ADDR 	0x870000000

#ifdef ICB_SUPPORT

#define S_AXI_LITE_ADDR		0x400000000
#define S_AXI_LITE_CSR_ADDR	0x420000000
#define S_AXI_LITE_OFFS		0x40000000

#define S_AXI_LITE_NUM				2
#define PCIE_BUS_ADDR		0x00000000
#define PCIE_BUS_TOTALSIZE	0x0
#define PCIE_BUS_ENTRY_SIZE	(0x20000000)
#define PCIE_BUS_WIN_SIZE	(PCIE_BUS_ENTRY_SIZE/0x1000)

#else

#define S_AXI_LITE_ADDR		0x80000000
#define S_AXI_LITE_CSR_ADDR	0x90000000
#define S_AXI_LITE_OFFS 	0x4000000


#define S_AXI_LITE_NUM				4
#define PCIE_BUS_ADDR		0x80000000
#define PCIE_BUS_TOTALSIZE	0x20000000
#define PCIE_BUS_ENTRY_SIZE	(PCIE_BUS_TOTALSIZE/8)
#define PCIE_BUS_WIN_SIZE	(PCIE_BUS_ENTRY_SIZE/0x1000)

#endif

#else
#define PCIE_DMA_PHYS_ADDR_EN 	0
#endif


typedef struct rpp_dev rpp_dev_t;

/* Physical address for eb pcie dma xfer */
#define PHY_ADDRESS_XFER_MODE 1

/**
 * Get the source id from channel direction and ddr usage.
 */
#define GET_CHAN_SRC(dirc, ddr) (dirc == DMA_WRITE ? \
                (ddr ? DMA_CHAN_DDR : DMA_CHAN_LOC) : DMA_CHAN_HST)
/**
 * Get the destination id from channel direction and ddr usage.
 */
#define GET_CHAN_DST(dirc, ddr) (dirc == DMA_READ ? \
                (ddr ? DMA_CHAN_DDR : DMA_CHAN_LOC) : DMA_CHAN_HST)

/* obtain the 32 most significant (high) bits of a 32-bit or 64-bit address */
#define pci_dma_h(addr) ((addr >> 16) >> 16)
/* obtain the 32 least significant (low) bits of a 32-bit or 64-bit address */
#define pci_dma_l(addr) (addr & 0xffffffffUL)

#define MPUARCHV2 0x2

/* Vendor/Device ID for RPP switch devices */
#define SWITCH_VENDOR_ID 0x11F8
#define SWITCH_DEVICE_ID 0x4068
/* Invalid switch index value (max 16-bit value) */
#define SWITCH_IDX_INVALID 0xffff

/*******************************************************************************
 *
 * DATA STRUCTURE DEFINITIONS
 *
 ******************************************************************************/
typedef enum {
	RPP = 0,
	PCIMAXNUM,
} synopsys_pci_t;


/**
 * Local RAM chunk id table
 */
typedef enum {
	CHUNK_ID_LLA,
	CHUNK_ID_LLB,
	CHUNK_ID_LLC,
	CHUNK_ID_LLD,
	CHUNK_ID_W0,
	CHUNK_ID_W1,
	CHUNK_ID_W2,
	CHUNK_ID_W3,
	CHUNK_ID_W4,
	CHUNK_ID_W5,
	CHUNK_ID_W6,
	CHUNK_ID_W7,
	CHUNK_ID_R0,
	CHUNK_ID_R1,
	CHUNK_ID_R2,
	CHUNK_ID_R3,
	CHUNK_ID_R4,
	CHUNK_ID_R5,
	CHUNK_ID_R6,
	CHUNK_ID_R7,
	CHUNK_ID_XDATA,
	CHUNK_ID_RSV0 = 0x1F, /* RESERVED IDs 0x15 - 0x1F */
	CHUNK_ID_DDR_W0,
	CHUNK_ID_DDR_R0
} CHUNK_ID;
/**
 * Supported commands of RPP.
 */
typedef enum {
	DMA_CMD_INIT,       /**< DMA Initialization */
	DMA_CMD_STATE,      /**< Get channel state */
	DMA_CMD_DW,         /**< DMA write */
	DMA_CMD_DR,         /**< DMA read */
	DMA_CMD_DQF,        /**< Flush queuing DMA jobs */
	DMA_CMD_ABORT,      /**< Abort undergoing DMA transfer */
	DMA_CMD_STOP,       /**< Stop undergoing DMA transfer */
	DMA_CMD_RESUME,     /**< Resume stopped DMA transfer */
	DMA_CMD_MDUMP,      /**< Dump buffers */
	DMA_CMD_MADDR,      /**< Get addresses allocated for DMA device */
	DMA_CMD_RDUMP,      /**< Dump DMA registers address and data of interest */
	DMA_CMD_LLDUMP,     /**< Dump linked list elements */
	DMA_CMD_PERF,
	DMA_CMD_XPERF,	    /**< Get xData Performance data */
	DMA_CMD_XSTART,     /**< Start xData transmission */
	DMA_CMD_XSTOP,      /**< Stop xData transmission */
	DMA_CMD_XSTATUS,    /**< Get xData xfer status */
	DMA_CMD_SG_TEST,
} DMA_CMD;

/**
 * Enumeration of data check status. Data check is performed after a transfer
 * is finished if requested.
 */
typedef enum {
	DATA_CHECK_NONE,    /**< No data check need to be performed */
	DATA_CHECK_UNKNOWN, /**< Transfer is running, so the result is unknown */
	DATA_CHECK_READY,   /**< Transfer is finished, ready to be checked. */
	DATA_CHECK_FAILURE, /**< Data check is failed */
	DATA_CHECK_SUCCESS  /**< Data check is successful */
} DMA_DATA_CHECK;

/**
* The end of a channel. Each channel has two ends, one for source and another
* for destination.
*/
typedef enum {
	DMA_CHAN_HST = 0,    /**< Host PC Buffer */
	DMA_CHAN_LOC,        /**< Local Buffer on FPGA */
	DMA_CHAN_DDR         /**< Local Buffer on DDR */
} DMA_CHAN_END;

/**
 * DMA channel information, as part of device extension, can be shared among
 * IRPs.
 * @note This data structure is used for application specific purpose. It has
 * nothing to do with the CHAN_INFO structure in HAL.
 */
typedef struct {
	UINT32 BlockSize;   	 /**< Block size */
	UINT64 TotalSize;   	 /**< Total transfer size of one request */
	UINT32 SgNent;
	DMA_DATA_CHECK DataCheck;/**< Data check status */
	UINT32 Pattern;     	 /**< Data pattern used by source data generation */
	UINT32 PatternIncre;	 /**< Increment of data pattern used by source data generation */
	UINT64 tick_count_start;
	UINT64 tick_count_stop;
} CHAN_INFO_EX, *PCHAN_INFO_EX;

/**
 * The RPP command data structure. It contains the requested command and its
 * arguments.
 */
typedef struct {
	DMA_CMD Cmd;        /**< Command */
	UINT8 Chan;         /**< Channel number. Value can be 0 to 7. */
	DMA_DIRC Dirc;      /**< Write or read. */
	BOOLEAN Upstream;   /**< Upstream or downstream. Used by xData only .*/
	DMA_CHAN_END End;   /**< Source or destination */
	UINT8 LLElements;   /**< Numbers of linked list element, including both data
	                     element and link element */
	UINT8 WaterMark;    /**< Watermark element index */
	UINT8 Weight;       /**< The weight of the channel */
	UINT32 Len;         /**< Data length for one block transfer */
	UINT32 Recyc;       /**< How many times recycle the linked list */
	UINT32 Offset;      /**< Offset to start address of the memory */
	BOOLEAN Chk;        /**< Check data or not after the transfer */
	BOOLEAN Queue;      /**< Queue up the request or not */
	BOOLEAN Ddr;        /**< Using DDR memory or not */
	char ResMsg[MAX_MSG_SIZE];/**< Storage for holding the command response. */
} CMD_INFO, *PCMD_INFO;

/**
 * An dma elemet of per continue address block.
 */
typedef struct {
	UINT64 dma_address;
	UINT32 dma_length;
} BLK_ELEMENT, *PBLK_ELEMENT;

/**
 * The block info of PCIe DMA use in transfer with sg.
 */
typedef struct {
	/* scatter-gather info */
	UINT32 mapped_num;
	PBLK_ELEMENT mapped_blk;
	/* xfer info */
	UINT32 vail_num;
	UINT32 start;
	UINT32 start_offs;
	UINT32 end_size;
} DMA_BLKS_INFO, *PDMA_BLKS_INFO;

typedef enum {
	RPP_DMA_RW5_ROUTE_INVALID = 0,
	RPP_DMA_RW5_ROUTE_SINGLE_DESC,
	RPP_DMA_RW5_ROUTE_PINGPONG_DESC,
} RPP_DMA_RW5_ROUTE;

/**
 *  Customized device extension
 */
typedef struct _DEVICE_EXTENSION {
	DMA_RSC DmaRsc;            /**< DMA resource object */
	UINT32 ChunkLen;           /**< Length of memory chunk for each channel */
	PHYADDR RamPa;             /**< The physical address of local RAM */
	PUINT32 RamVa;             /**< The virtual address of local RAM */
	UINT32 RamSize;            /**< The size of local RAM */
	PHYADDR IoMemPa[16];       /**< The physical address of buffer on system memory */
	PUINT32 IoMemVa[16];       /**< The virtual address of buffer on system memory */
	CHAN_INFO_EX WrChInfEx[8]; /**< The information for all write channels */
	CHAN_INFO_EX RdChInfEx[8]; /**< The information for all read channels */
	XDATA_RSC xDataRsc;        /**< Extra Data parameters */
	UINT32 ReadMTU;            /**< Max PCI packet payload size */
	UINT32 ReadMTUBits;
	UINT32 WriteMTU;
	UINT32 WriteMTUBits;
	dma_addr_t dma_bus[16];
	struct sg_table *sgt;
	PDMA_BLKS_INFO blk_info;
} DEVICE_EXTENSION, *PDEVICE_EXTENSION;


/* ------------------------------------------------------------------------- */

/* RPP PCIe device specific book-keeping */
#define XDEV_FLAG_OFFLINE	0x1

struct rpp_serv {
	long pid;
	uint32_t status;
};

struct rpp_int_info {
	uint32_t int_vector; /* [0:15]: 0--SCHE, 1--MPU, [16-31]: dev idx */
	uint32_t int_info_1;
	uint32_t int_info_2;
	uint32_t int_info_3;
	uint32_t int_desc[8];
	struct timespec64 isr_kts;
};

#define MAX_CHLD_NUM			16

struct chld_info {
	uint32_t chld_idx;
	uint32_t chld_status; /* 0 - offline, 1 - online */
	uint8_t chld_pci_name[16];
};

struct switch_chld {
	uint32_t num_of_chld;
	struct chld_info chld_tbl[MAX_CHLD_NUM];
};

typedef struct rpp_switch_s {
	struct list_head entry;			/* entry to glb_switch_list */
	struct pci_dev *pdev;
	struct device *sys_device;     /* switch device node */
	struct cdev scdev;        /* character device embedded struct */
	dev_t devno;                    /* character device major:minor */
	char name[64];                  /* switch node name */
	char pci_id[64];                /* switch pci_id */
	struct semaphore sem;           /* semephore for ioctls */
	uint32_t lnkcap;
	uint32_t lnksta;
	int switch_idx;		            /* switch index */
	struct switch_chld chld;
	struct rpp_dev *chld_dev[MAX_CHLD_NUM];
	uint64_t bar_mem_start;
	uint64_t bar_mem_end;
} rpp_switch_t;

struct rpp_cdev {
	void * prppdev;         /* point to rpp_dev */
	dev_t cdevno;           /* character device major:minor */
	struct cdev cdev;       /* character device embedded struct */
	int bar;                /* PCIe BAR for HW access, if needed */
	unsigned long base;     /* bar access offset */
	struct device *sys_device;  /* sysfs device */
	spinlock_t lock;
};

struct rpp_vdev {
    void  *prppdev;         /* point to rpp_dev */
    dev_t vdevno;           /* character device major:minor */
    struct cdev vdev;       /* character device embedded struct */
    int bar;                /* PCIe BAR for HW access, if needed */
    unsigned long base;     /* bar access offset */
    struct device *sys_device;  /* sysfs device */
    spinlock_t lock;        /* lock for ve resource manager */
    struct semaphore sem;   /* semephore for ioctls */
    struct mutex vMutex;    /* mutex for vmem alloc/free */
    void *veEngine;         /* video engine extend */
    void *veInterrupt;      /* ve interrupt manager */
    int nCount;             /* count for user open driver */
    int bInit;              /* flag for ve config initial */
    struct fasync_struct *async_queue;
};

enum xpdev_flags_bits {
    XDF_CDEV_ENTIRE_CTRL,   /*rpp cdev*/
    XDF_VDEV_ENTIRE_CTRL,   /*rpp vdev*/
};

#define RPP_BOARD_DUDI			0x0000
#define RPP_BOARD_V4			0x0001
#define RPP_BOARD_M3			0x0002
#define RPP_BOARD_M5			0x0003
#define RPP_BOARD_A4			0x0004
#define RPP_BOARD_A8			0x0005
#define RPP_BOARD_A9_V1			0x0006
#define RPP_BOARD_A9_V2			0x0007
#define RPP_BOARD_A9_V2_DFT		0x0008
#define RPP_BOARD_A10			0x0009
#define RPP_BOARD_A9_V2_PLUS		0x000a
#define RPP_BOARD_A15			0x000b

#define RPP_CHIP_R8_MPW			0x0
#define RPP_CHIP_R8_MP			0x1

//-----------------------------------------------------------------------------
typedef struct ee_control_header_struct_t {
	unsigned short magic_number;
	unsigned short size;
	unsigned short version;		// 3
	unsigned short board_info;  // 0x0000 - dudi, 0x0001 - v4, 0x0002 - M3, 0x0003 - M5, 0x0004 - A4, 0x0005 - A8, 0x0006 - A9_V1, 0x0007 - A9_V2, 0x0008 - A9_V2_DFT, 0x0009 - A10, 0x000a - A9_V2_PLUS, 0x000b - A15 (board version)

	unsigned int board_mn;
	/**
	 * bit[3:0]:MaxNumDDR 1 or 4;
	 * bit[11:4]:ddrsize;//0001 - 1GB, 0010 - 2GB, 0100 - 4GB, 1000 - 8GB, 10000 - 16GB 10000 - 32GB 100000 - 64GB
	 * bit[15:12]:PCIeGen; // Gen2 or Gen3
	 * bit[19:16]:PCIe_lane; //0x1 - C x1, 0x2 - C x2, 0x4 - x4
	 * bit[23:20]:bar_size, 0 - normal, 1 - small bar
	 * bit[27:24]:wdt_en, 0 - disable, 1 - enable
	 * bit[31:28]:chip_version; // 0 - r8, 1 - r9
	 */

	unsigned int freq;
	/**
	 * bit[11:0]:MaxRppFreq;// 600MHz, 800MHz, 1000MHz bit[31]:BoostModeCap; // =1: enable boost mode, =0: disable boost mode. Cannot set to '1' if MaxRppFreq<1GHz
	 * bit[23:12]:DefFreq; // 600MHz, 800MHz, 1000MHz --> max pll1 frequency for setworkmode
	 * bit[30:24]:BoostModeTriggerLimit; // When GPU loading reaches this limit,then trigger the boost // =0:no limit, =1: 15%, =2: 30%, =3: 45%, =4:60%, =5: 75%, =6: 90%, =7: 100%
	 * bit[31]: BoostModeCap; // =1: enable boost mode, =0: disable boost mode. Cannot set to '1' if MaxRppFreq<1GHz
	 */

	unsigned int   sn[4];
	unsigned int   date;
	/**
	 * bit[7:0]:The temperature that triggers the fan to turn on while waiting for sema;//97
	 * bit[15:8]:The temperature that triggers shutdown while waiting for sema; // 104
	 * bit[27:16]:ddr vendor; // 0: micron; 1: samsung;
	 * bit[31:28]: ddr protocol; // 0: lpddr4; 1; lpddr4x
	 */

	unsigned int   main_boot_temp_monitor;
	unsigned int   pci_device_id_vendor_id;
	unsigned int   pci_subsystem_id_subsystem_vendor_id;
	unsigned int   pci_class_code_revision_id;
	unsigned int   resv[3];
} EE_CONTROL_HDR, * EE_CONTROL_HDR_PTR;
#if 0 // 20241106 old version 0x3
typedef struct fw_control_header_struct_t {
    unsigned short magic_number;
    unsigned short size;
    unsigned int   thermal_ctrl;
  /*
  **bit[0:4]: fan speed
  **bit[5]: 0 -- fan auto speed disable, 1 -- fan auto speed enable//default is 1
  **bit[6]: 0 -- freq auto adjusting disable, 1 -- freq auto adjusting enable//default is 1
  **bit[7]: 0 -- auto shutdown disable, 1 -- auto shutdown enable//default is 1
  **bit[8:15]: working temperature[0:255] //default is 88
  **bit[16:23]: throttling temperature[0:255] //default is 97
  **bit[24:31]: trip temperature[0:255] //default is 104
  */
    unsigned short pmic_vol_ctrl;
    unsigned short ve_div;
    unsigned int   pll1_div;
    unsigned int   pll2_div;
    unsigned int   pll3_div;
    unsigned int   ddr_ctrl;
    unsigned int   dqsdelay0;
    unsigned int   dqsdelay1;
    unsigned int   dqsdelay2;
    unsigned int   dqsdelay3;
    unsigned int   date;
    unsigned short version;
    unsigned short resv;
    unsigned int   cmd_base_addr;       // offset of sram
} FW_CONTROL_HDR, *FW_CONTROL_HDR_PTR;
#else // 20241107 new version 0x4
typedef struct fw_control_header_struct_t {
	unsigned short magic_number;
	unsigned short size;
	unsigned int thermal_ctrl;
	/**
	 * bit[0:4]: fan speed
	 * bit[5]: 0 -- fan auto speed disable, 1 -- fan auto speed enable//default is 1
	 * bit[6]: 0 -- freq auto adjusting disable, 1 -- freq auto adjusting enable//default is 1
	 * bit[7]: 0 -- auto shutdown disable, 1 -- auto shutdown enable//default is 1
	 * bit[8:15]: working temperature[0:255] //default is 88
	 * bit[16:23]: throttling temperature[0:255] //default is 97
	 * bit[24:31]: trip temperature[0:255] //default is 104
	 */

	unsigned short resv;
	unsigned short ve_div;
	unsigned int resv1;
	unsigned int pll2_div;
	unsigned int pll3_div;
	unsigned int config0;
	/**
	 * bit[0:9]: pmic_vol // 0 - 1023
	 * bit[10:20]: ddr_freq // 0 - 2047
	 * bit[21:31]: core_freq // 0 - 2047
	 */

	unsigned int config1;
	/**
	 * bit[0:9]: pmic_vol // 0 - 1023
	 * bit[10:20]: ddr_freq // 0 - 2047
	 * bit[21:31]: core_freq // 0 - 2047
	 */

	unsigned int config2;
	/**
	 * bit[0:9]: pmic_vol // 0 - 1023
	 * bit[10:20]: ddr_freq // 0 - 2047
	 * bit[21:31]: core_freq // 0 - 2047
	 */

	unsigned int config3;
	/**
	 * bit[0:9]: pmic_vol // 0 - 1023
	 * bit[10:20]: ddr_freq // 0 - 2047
	 * bit[21:31]: core_freq // 0 - 2047
	 */

	unsigned int config_mn;
	/**
	 * bit[0:3]: config_id
	 * bit[4:15]: resv
	 * bit[16:31]: compatible_board_version
	 */

	unsigned int date;
	unsigned short version; // 0x4
	unsigned short firmware_control;
	/**
	 * bit[0]: wdt_en; // 0 - false, 1 - true
	 * bit[1:15]: resv;
	 */

	unsigned int cmd_base_addr;
	unsigned int resv2[2];
} FW_CONTROL_HDR, * FW_CONTROL_HDR_PTR;
#endif

/**
 * work mode
 */
#define WORKMODE_DFS_BIT    0
#define WORKMODE_VE_BIT     1
#define WORKMODE_BOOST_BIT	2
#define WORKMODE_PERF_BIT	3

#define RPP_WORKMODE_DFS_DISABLE            (0x0 << WORKMODE_DFS_BIT)
#define RPP_WORKMODE_DFS_ENABLE             (0x1 << WORKMODE_DFS_BIT)
#define RPP_WORKMODE_VE_DISABLE             (0x0 << WORKMODE_VE_BIT)
#define RPP_WORKMODE_VE_ENABLE              (0x1 << WORKMODE_VE_BIT)
#define RPP_WORKMODE_BOOST_DISABLE	        (0x0 << WORKMODE_BOOST_BIT)
#define RPP_WORKMODE_BOOST_ENABLE	        (0x1 << WORKMODE_BOOST_BIT)
#define RPP_WORKMODE_MODE0					(0x1 << WORKMODE_PERF_BIT)
#define RPP_WORKMODE_MODE1					(0x2 << WORKMODE_PERF_BIT)
#define RPP_WORKMODE_MODE2					(0x3 << WORKMODE_PERF_BIT)
#define RPP_WORKMODE_MODE3					(0x4 << WORKMODE_PERF_BIT)
#define	RPP_WORKMODE_MODE4					(0x5 << WORKMODE_PERF_BIT)
#define RPP_WORKMODE_MODE5					(0x6 << WORKMODE_PERF_BIT)
#define RPP_WORKMODE_MODE6					(0x7 << WORKMODE_PERF_BIT)
#define RPP_WORKMODE_MODE7					(0x8 << WORKMODE_PERF_BIT)
#define RPP_WORKMODE_MODE8					(0x9 << WORKMODE_PERF_BIT)
#define RPP_WORKMODE_MODE9					(0xa << WORKMODE_PERF_BIT)
#define RPP_WORKMODE_MODE10					(0xb << WORKMODE_PERF_BIT)


/**
 * power mode
 */
typedef enum {
    RPP_PWRMODE_WORKING     = 0x0,
    RPP_PWRMODE_LOW_POWER   = 0x1,
    RPP_PWRMODE_STANDBY     = 0x2,
    RPP_PWRMODE_RESUME      = 0x3,
} rpp_pwrmode_e;

/**
 * hw states
 */
typedef struct rpp_hw_states
{
    uint32_t pwr_state;
    uint32_t wrk_state;
    uint32_t wrk_user_state;    // from user app
	uint16_t max_pll1_freq;		// from bl_config
	uint16_t pwr_user_state;
} rpp_hw_states_t, *prpp_hw_states;

//-----------------------------------------------------------------------------
struct rpp_dev_info {
    uint32_t platform_version; // 0x0
    uint32_t sw_version_1; // 0x4
    uint32_t sw_version_2; // 0x8
    uint32_t boot_status; // 0xc
    uint32_t self_check; // 0x10 (old info: 0xff, new info: 0x2)
    uint32_t mpu_external_ctrl_0; // 0x14, map MPU external_ctrl_0(reg 0x22210) directly
    uint32_t rpp_clk; // 0x18
    uint32_t sche_clk; // 0x1c
    uint32_t ddr_clk; // 0x20
    uint32_t ddr_clk_1; // 0x24
	uint32_t bl_config_version;  // 0 --> 0x28
	uint32_t fw_config_version;  // 0 --> 0x2c
    uint32_t bootloader_version; // 0x28 --> 0x30
    uint32_t resv[3]; // resv[5] --> resv[3]
}; // Total 0x40

struct ve_mem_info {
    struct {
        uint32_t size;                  /*video engine memory size*/
        unsigned long phys_addr;        /*video engine mermory start (physical) address*/
        size_t        virt_addr;        /*virtual user space address(mmap)*/
    }ve_mem;

    struct{
        uint32_t size;                  /*vpu register space size*/
        unsigned long phys_addr;        /*vpu register start (physical) address*/
        size_t        virt_addr;        /*virtual user space address(mmap)*/
    }ve_register;
};

#define SUPPORT_ISR_ITSELF

#define RPP_DEV_MAGIC     0x44525644    /* "DRVD" - Driver Device */
/* Generic object header fields, used for all RPP DEV structures */
#define RPP_DEV_FIELDS                       \
    uint32_t magic;                     /* Magic number identifying generic object */ \
    char dev_prefix[24];                /* Pre-formatted device prefix string */ \
    void *reserved;                     /* Reserved for future use */

#define RPP_HOST_BUF_BASE_ADDR              0x800000000

#define RPP_DEV_MAX_COUNT 					(72)
#define RPP_DEV_PER_CHANNEL_BUFFER_SIZE		(2 * 1024 * 1024)  // eg: 2MB/128bytes = 0x4000(16384)
#define RPP_DEV_CHANNEL_COUNT				(3 * 2)
#define RPP_DEV_TASKS_HEADER_SIZE			(4 * 1024 * 1024)

typedef enum {
    CH0_CH1 = 0,    /**< channel 0 and channel 1 */
    CH2,            /**< channel 2 */
    CH3,            /**< channel 3 */
} DMA_CHANNEL;

typedef enum {
    UNMAPPED = 0,  	/**< unmapped */
    MAPPED,   		/**< mapped */
} MMAP_STATUS;

typedef enum {
	QUEUE_READY = 0,  	/**< queue ready */
	QUEUE_IN_USE, 		/**< queue is in use, xfer task is running */
} QUEUE_STATUS;

typedef enum {
	SEMA_WAIT = 0,  	/**< semaphore at P(wait) */
	SEMA_POST, 			/**< semaphore at V(post) */
} SEMA_STATUS;

/**
 * ---------------------------------
 *  rpp_dev_dma_queue_t
 * ---------------------------------
 * 	Device queue 2MB * n
 *  (n is read/write channel index)
 * ---------------------------------
 */
typedef void (*dma_xferdone_cb_t)(void *rpp_dev, void *cb_ctx);

typedef struct rpp_xfer_task_info_s {
	MMAP_STATUS mapped;			/* < the host mmap sta */
	DMA_DIRC dirc;				/* < the directory of R(0)/W(1) */
	DMA_CHANNEL chan;			/* < the DMA channel */
	uint64_t host_addr;			/* < no mmaped host memory address */ 
	uint32_t host_handle;		/* < xfer shm memory handle */
	uint64_t host_offs; 		/* < xfer host addr offs */
	uint64_t dev_addr; 			/* < xfer device addr */
	uint32_t size;      		/* < xfer size */
	uint32_t resv[8];			/* < reserved */
} rpp_xfer_task_info_t;

typedef struct rpp_xfer_done_ctx_s {
	DMA_DIRC dirc;				/* < the directory of R(0)/W(1) */
	uint32_t sta;				/* < 0 -- free, 1 -- alloc */
	void* virt_addr;			/* < virtual address */
	void* uhost_addr;			/* < user hosr address */
	uint32_t size;      		/* < xfer size */
	uint32_t khost_handle;		/* < xfer kernel memory handle */
	void *rpp_pages;
} rpp_xfer_done_ctx_t;

typedef struct rpp_dev_queue_config_s {
	uint32_t max_ne;					// the max number of rpp_xfer_task_info_t
	volatile uint64_t head;				// (head % (max_ne)) as index for the start rpp_xfer_task_info_t* ptask
	volatile uint64_t tail;				// (tail % (max_ne)) as index for the end rpp_xfer_task_info_t* ptask
	uint32_t resv[16];					// reserved 
} rpp_dev_queue_config_t;

typedef struct rpp_dev_dma_queue_s {
	volatile QUEUE_STATUS sta;		// queue status
	rpp_xfer_done_ctx_t xctx;		// queue xfer task done callback context
	// dma_xferdone_cb_t cb_func;	// queue xfer task done callback function
	rpp_dev_queue_config_t qcfg;	// queue management config
	uint32_t size;					// buffer size
	void* buf;  					// buffer(kernel address) for all struct rpp_xfer_task_info_t* ptask
	uint32_t resv[32];				// reserved
} rpp_dev_dma_queue_t;

typedef struct rpp_dev_dma_queues_s {
	uint32_t version;				// the version of rpp_dev_dma_tasks_t
	uint64_t size;					// the device buffer size
	uint32_t resv0[64];				// reserved 0
	rpp_dev_dma_queue_t wch0_ch1;	// queue for channel 0 and 1 to write(H2D)
	rpp_dev_dma_queue_t rch0_ch1;	// queue for channel 0 and 1 to read(D2H)
	rpp_dev_dma_queue_t wch2;		// queue for channel 2 to write(H2D)
	rpp_dev_dma_queue_t rch2;		// queue for channel 2 to read(D2H)
	rpp_dev_dma_queue_t wch3;		// queue for channel 3 to write(H2D)
	rpp_dev_dma_queue_t rch3;		// queue for channel 3 to read(D2H)
	uint32_t resv1[128];			// reserved 1
} rpp_dev_dma_queues_t;

typedef struct cfg_rtd3_regs_s {
	uint8_t addr;
	uint32_t value;
} cfg_rtd3_regs_t;

/**
 *  RPP device structure
 */
struct rpp_dev {
    RPP_DEV_FIELDS
    struct pci_dev *pdev;
//    dev_t devno;
    uint64_t dma_mask;

    void *mmio_addr;
    void *mmio_start;
    unsigned long mmio_len;
    int irq;
    void * __iomem bar[RPP_BAR_NUM];
    PHYADDR RegSpacePa[RPP_BAR_NUM];
    unsigned long bar_len[RPP_BAR_NUM];
    bool small_bar;

    int open_flag;
    int in_use;
    int got_regions;
    int dma_initialized;
    int ve_disable;

    /* device info */
	EE_CONTROL_HDR bl_config_info;
    struct rpp_dev_info dev_info;
	struct ve_mem_info ve_info;

    /* board info */
    uint8_t revision;                   /*                        ┌--------------┐                                     */
    uint8_t irq_pin;                    /*                        |       RC     |                                     */
    uint8_t irq_line;                   /*                        └--------------┘                                     */
    uint32_t no_of_msi;                 /*                                |                                            */
    uint16_t sub_vendor_id;             /*                      ┌-----------------┐                                    */
    uint16_t sub_system_id;             /*                      |     SWITCH      | <-- switch_pcidev                  */
    uint16_t vendor_id;                 /*                      └-----------------┘                                    */
    uint16_t device_id;                 /*                    /           |           \                                */
                                        /* ┌-----------------┐  ┌-----------------┐  ┌-----------------┐               */
    /* parent pci node info */          /* |     BRIDGE0     |  |     BRIDGE1     |  |    BRIDGEn      |<-bridge_pcidev*/
    /* multi EP board's switch */       /* └-----------------┘  └-----------------┘  └-----------------┘               */
    struct pci_dev *switch_pcidev;      /*          |                     |                    |                       */
    /* multi EP board's bridge */       /* ┌-----------------┐  ┌-----------------┐  ┌-----------------┐               */
    struct pci_dev *bridge_pcidev;      /* |     DEV0        |  |       DEV1      |  |       DEVn      | <-- rpp_dev   */
                                        /* └-----------------┘  └-----------------┘  └-----------------┘               */

    struct class *drv_cls;
    struct tasklet_struct tlet;
    struct completion xfer_done;

    DEVICE_EXTENSION RPP_ext;

    uint32_t irq_count;
    uint32_t status;
    pid_t last_error_pid;          /* PID of last process that printed error */
    uint32_t last_error_status;    /* Status when last error was printed */

    void (*probe)(unsigned long data);
#ifndef SUPPORT_ISR_ITSELF
    void *owner; // device to owner the pcie
    void (*isr)(int irq_vector, void *dev);
#endif
//-----------------------------------------------------------------------------
    struct list_head list_head;
    struct list_head rcu_node;

    //struct pci_dev *pdev;	/* pci device struct from probe() */
    //struct hal_pcie_dev *hpdev;
    //u64 dma_mask;   //????
    int idx;		/* dev index */
    int switch_idx;		/* switch index */
    int idx_in_switch;             /* dev index in switch */
    /* switch info */
    rpp_switch_t *parent_switch;

    const char *mod_name;		/* name of module owning the dev */

    spinlock_t lock;		/* protects concurrent access */
    unsigned int flags;

    struct semaphore sem; /* semephore for ioctls */

    /**
     * @idr:
     *
     * Mapping of mm object handles to object pointers
     */
    struct idr idr;
    spinlock_t idr_lock;

    struct rpp_serv *serv;

    int major;          /* major number */
    struct rpp_cdev entire_ctrl_cdev;
    struct rpp_vdev entire_ctrl_vdev;

//-----------------------------------------------------------------------------
    struct tasklet_struct rpp_tasklet;
    struct tasklet_struct rpp_mpu_tasklet;
    struct tasklet_struct codec0_tasklet;
    struct tasklet_struct codec1_tasklet;
    struct tasklet_struct codec2_tasklet;
    struct tasklet_struct codec3_tasklet;
    struct tasklet_struct jpeg0_tasklet;
    struct tasklet_struct jpeg1_tasklet;
    struct tasklet_struct jpeg2_tasklet;
    struct tasklet_struct jpeg3_tasklet;

	struct kfifo isr_kfifo;
	wait_queue_head_t wq;					// waitqueue for scheduler/mpu interrupt
	wait_queue_head_t wq_dma;				// waitqueue for dma interrupt
	uint8_t  isr_dma;						// 0 not interrupt

    // firmware version
    unsigned int fw_version;
    unsigned int cmd_base_addr;       // offset of sram
    rpp_hw_states_t hw_state;
    unsigned int hw_config_id;
	unsigned int init_dev_count;
	uint32_t mcu_version;
	cfg_rtd3_regs_t rtd3_regs[RTD3_CFG_NUM_MAX];
	bool pm_suspending;
	bool pm_notifier_offline;
	bool dma_xfer_active;
	bool pm_abort_xfer;
	bool idle_low_power_suspended;
	bool idle_low_power_system_ref;
	struct mutex idle_low_power_lock;
	atomic_t idle_low_power_refs;

	// dma task queues
	rpp_dev_dma_queues_t *dma_queues;
	SEMA_STATUS dma_sem_status;			// semaphore at P(wait) or V(post) option for this device	
};

struct rpp_pcie_cfg {
    void *owner;
    void (*probe)(unsigned long data);
    irqreturn_t (*isr)(int irq_vector, void *dev);
};

typedef struct rpp_pcie_link_s {
	uint32_t cap_speed;
	uint32_t cap_width;
	uint32_t sta_speed;
	uint32_t sta_width;
} rpp_pcie_link_t;
typedef struct rpp_pcie_switch_reg {
	uint32_t addr;
	uint32_t val;
} rpp_pcie_switch_reg_t;

/*******************************************************************************
 *
 * FUNCTION DECLARATION
 *
 ******************************************************************************/
//void * RPP_init(struct rpp_pcie_cfg *cfg);
int RPP_init(void);
void RPP_cleanup(void);

int RPP_remap_pci_bar(struct rpp_dev *priv, UINT32 bar, struct vm_area_struct *vma);
void RPP_Read_Header(struct pci_dev *pdev, PCI_COMMON_CONFIG *data);
void RPP_rw_pci_cfg(struct pci_dev *pdev, INT d, UINT32 length, UINT32 offset, UCHAR *val);
int RPP_rw_pci_hdr(struct pci_dev *pdev, INT rc, INT d, UINT32 length, UINT32 offset, UCHAR *val);
void DataCheckDpc(unsigned long arg);
UINT32 IoctlDmaInit2(struct rpp_dev *priv, PDEVICE_EXTENSION pDevExt, PCMD_INFO pcmd, XFER_DONE_FUNC func);
UINT32 IoctlDmaRW2(struct rpp_dev *priv, UINT8 Chan, DMA_DIRC write, u64 ep_addr, dma_addr_t host_addr, u32 size, u32 timeout_ms);
UINT32 IoctlDmaRW3(struct rpp_dev *pdev, UINT8 Chan, DMA_DIRC write, u64 ep_addr, struct sg_table *sgt, bool dma_mapped, u32 timeout_ms);
UINT32 IoctlDmaRW4(struct rpp_dev *pdev, UINT8 Chanping, UINT8 Chanpong, DMA_DIRC write, u64 ep_addr, PDMA_BLKS_INFO info, u32 timeout_ms);
UINT32 IoctlDmaRW4_1(struct rpp_dev *pdev, UINT8 Chanping, DMA_DIRC write, u64 ep_addr, PDMA_BLKS_INFO info, u32 timeout_ms);
UINT32 IoctlDmaRW5(struct rpp_dev *pdev, UINT8 ch, DMA_DIRC write, u64 ep_addr, PDMA_BLKS_INFO info, u32 timeout_ms);
UINT32 rpp_dma_rw5_select_route(UINT8 ch, const DMA_BLKS_INFO *info, UINT8 *chan, UINT8 *pong, RPP_DMA_RW5_ROUTE *route);
UINT32 IoctlDmaState(struct rpp_dev *pdev, DMA_DIRC dirc, UINT8 chan, DMA_CHAN_STATUS *stat, DMA_ERR *err, UINT64 *xferred,
        UINT32 *intCntDone, UINT32 *intCntAbort);

#if BAR_ACCESS_INLINE
extern inline void RPP_rw_pci_bar(struct rpp_dev *priv, UINT32 bar, INT dir, UINT32 length, UINT32 offset, UCHAR *val);
#else
extern void RPP_rw_pci_bar(struct rpp_dev *priv, UINT32 bar, INT dir, UINT32 length, UINT32 offset, UCHAR *val);
#endif

int rpp_firmware_load(struct rpp_dev *pdev, bool refresh_mcu_version);
int rpp_refresh_mcu_version(struct rpp_dev *pdev);
int rpp_get_devinfo(struct rpp_dev *pdev);
int rpp_dump_devinfo(struct rpp_dev *pdev);
int rpp_set_pmic(struct rpp_dev *pdev, bool state);
int rpp_set_power_mode_to_mpu(struct rpp_dev *pdev, uint32_t mode);
int rpp_set_worker_mode_to_mpu(struct rpp_dev *pdev, uint32_t mode);
int rpp_set_power_mode(struct rpp_dev *pdev, uint32_t mode);
int rpp_set_worker_mode(struct rpp_dev *pdev, uint32_t mode);
int rpp_get_mcu_version(struct rpp_dev *pdev, uint32_t *version);
int rpp_genx_speed_change(struct rpp_dev *pdev, uint8_t genx);
int rpp_mpu_isr_enable(struct rpp_dev *pdev);
int rpp_mpu_get_interrupt_info(struct rpp_dev *pdev, uint32_t *type, uint32_t *pvt, uint32_t *clk);
int rpp_pcie_read_write(struct rpp_dev *pdev, uint64_t dev_addr, uint32_t len, void *buf, bool write);
int rpp_device_offline(struct rpp_dev *pdev);
int rpp_device_online(struct rpp_dev *pdev);
bool rpp_edma_enabled(void);
int rpp_irq_num(void);

#endif  //__RPP_DEV_H__
