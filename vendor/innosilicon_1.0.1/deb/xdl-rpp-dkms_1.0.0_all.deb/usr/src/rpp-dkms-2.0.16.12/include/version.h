/*
 * This file is part of the Azurengine DMA IP Core driver for Linux
 *
 * Copyright (c) 2016-present,  Azurengine, Inc.
 * All rights reserved.
 *
 * This source code is licensed under both the BSD-style license (found in the
 * LICENSE file in the root directory of this source tree) and the GPLv2 (found
 * in the COPYING file in the root directory of this source tree).
 * You may select, at your option, one of the above-listed licenses.
 */

#ifndef __RPP_VERSION_H__
#define __RPP_VERSION_H__

/*  #define DRV_MOD_MAJOR		2017 */
/*  #define DRV_MOD_MINOR		1 */
/*  #define DRV_MOD_PATCHLEVEL	47 */

#define DRV_MODULE_VERSION      \
	__stringify(DRV_MOD_MAJOR) "." \
	__stringify(DRV_MOD_MINOR) "." \
	__stringify(DRV_MOD_PATCH) "." \
	__stringify(DRV_MOD_BUILD)

#define DRV_MOD_VERSION_NUMBER  \
	((DRV_MOD_MAJOR)*0x1000000 + (DRV_MOD_MINOR)*0x10000 + (DRV_MOD_PATCH)*0x100 + DRV_MOD_BUILD)

#endif /* ifndef __RPP_VERSION_H__ */
