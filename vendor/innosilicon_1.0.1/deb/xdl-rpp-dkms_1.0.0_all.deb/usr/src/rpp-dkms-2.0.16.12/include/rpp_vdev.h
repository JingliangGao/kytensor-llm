/*
 * This file is part of the Azurengine DMA IP Core driver for Linux
 *
 * Copyright (c) 2016-present,  Azurengine, Inc.
 * All rights reserved.
 *
 * This source code is licensed under both the BSD-style license (found in the
 * LICENSE file in the root directory of this source tree) and the GPLv2 (found
 * in the COPYING file in the root directory of this source tree).
 * You may select, at your option, one of the above-listed licenses.
 */

#ifndef __VE_CHRDEV_H__
#define __VE_CHRDEV_H__

#include <linux/kernel.h>
#include <linux/types.h>
#include <linux/uaccess.h>
#include <linux/errno.h>

#include "rpp_dev.h"

int vchar_open(struct inode *inode, struct file *file);
int vchar_close(struct inode *inode, struct file *file);
int xvdev_check(const char *, struct rpp_vdev *, bool);

void vdev_entire_ctrl_init(struct rpp_vdev *xvdev);
int rpp_vdev_info_init(void);
void rpp_vdev_info_exit(void);

int rpp_vdev_init(struct rpp_dev *pdev);
void rpp_vdev_exit(struct rpp_dev *pdev);

#endif /* __VE_CHRDEV_H__ */
