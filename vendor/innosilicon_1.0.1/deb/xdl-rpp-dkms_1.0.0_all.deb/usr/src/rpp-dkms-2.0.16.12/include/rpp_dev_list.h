/*
 * This file is part of the Azurengine DMA IP Core driver for Linux
 *
 * Copyright (c) 2016-present,  Azurengine, Inc.
 * All rights reserved.
 *
 * This source code is licensed under both the BSD-style license (found in the
 * LICENSE file in the root directory of this source tree) and the GPLv2 (found
 * in the COPYING file in the root directory of this source tree).
 * You may select, at your option, one of the above-listed licenses.
 */

#ifndef __RPP_DEV_LIST_H__
#define __RPP_DEV_LIST_H__


#include <net/sock.h>


#include "rpp_com.h"
#include "rpp_dev.h"
#include "rpp_pages.h"

void rpp_dev_list_add(struct rpp_dev *pdev);
void rpp_dev_list_remove(struct rpp_dev *pdev);
struct rpp_dev *xdev_find_by_pdev(struct pci_dev *pdev);
struct rpp_dev *xdev_find_by_cdev_devno(dev_t devno);

int rpp_dma_kthread_init(void);
void rpp_dma_kthread_exit(void);
void rpp_dma_wakeup(void);
void rpp_dma_isr_wakeup(struct rpp_dev *pdev);
int rpp_dev_queues_buf_mmap(struct rpp_dev *pdev, struct vm_area_struct *vma);

void rpp_wch0_ch1_xfer_done(struct rpp_dev *pdev, void *cb_ctx);
void rpp_rch0_ch1_xfer_done(struct rpp_dev *pdev, void *cb_ctx);
void rpp_wch2_xfer_done(struct rpp_dev *pdev, void *cb_ctx);
void rpp_rch2_xfer_done(struct rpp_dev *pdev, void *cb_ctx);
void rpp_wch3_xfer_done(struct rpp_dev *pdev, void *cb_ctx);
void rpp_rch3_xfer_done(struct rpp_dev *pdev, void *cb_ctx);

void rpp_dev_semaphore_init(struct rpp_dev *pdev);
void rpp_dev_semaphore_wait(struct rpp_dev *pdev);
void rpp_dev_semaphore_post(struct rpp_dev *pdev);
void rpp_dev_semaphore_destroy(void);

rpp_pages_t *rpp_pages_dma_alloc(struct rpp_dev *pdev, uint64_t size, rpp_xfer_done_ctx_t *ctx);
void rpp_pages_dma_free(struct rpp_dev *pdev, rpp_xfer_done_ctx_t *ctx);
HAL_DMA_RET HalDmaISR2(struct rpp_dev *pdev, PDMA_RSC pdrsc, UINT8 *channel, DMA_DIRC *direction);

#endif /* __RPP_DEV_LIST_H__ */
