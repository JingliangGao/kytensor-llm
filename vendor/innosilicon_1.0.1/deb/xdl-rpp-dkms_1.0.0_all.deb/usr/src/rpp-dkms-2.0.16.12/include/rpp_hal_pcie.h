#ifndef __RPP_HAL_PCIE_H__
#define __RPP_HAL_PCIE_H__

#include <linux/types.h>
#include <linux/module.h>
#include <linux/kref.h>

#include "rpp_dfx.h"

#include "rpp_hal_dma.h"
#include "rpp_dma.h"
#include "rpp_xdata.h"
#include "rpp_types.h"
#include "rpp_dev.h"

struct rpp_dma_cfg {
};


int rpp_xfer_single(struct rpp_dev *pdev,
						void *buf,
						uint64_t dev_offs,
						uint64_t size,
						bool write,
						bool dma_mapped,
						uint32_t timeout_ms);
int rpp_xfer_single_uninterruptible(struct rpp_dev *pdev,
						void *buf,
						uint64_t dev_offs,
						uint64_t size,
						bool write,
						bool dma_mapped,
						uint32_t timeout_ms);
int rpp_xfer_sgt(struct rpp_dev *pdev,
						struct sg_table *sgt,
						uint64_t dev_addr,
						uint64_t size,
						bool write,
						uint32_t timeout_ms);

int rpp_xfer_blks(struct 	rpp_dev *pdev,
							PDMA_BLKS_INFO info, 
							uint64_t dev_addr,
							uint64_t size,
							bool write,
							uint32_t timeout_ms);
int rpp_xfer_blks_ch(struct 	rpp_dev *pdev,
							DMA_CHANNEL ch,
							PDMA_BLKS_INFO info,
							uint64_t dev_addr,
							uint64_t size,
							bool write,
							uint32_t timeout_ms);

int rpp_xfer_blks_async(struct 	rpp_dev *pdev,
							DMA_CHANNEL ch,
							PDMA_BLKS_INFO info,
							uint64_t dev_addr,
							uint64_t size,
							bool write,
							uint32_t timeout_ms);

void rpp_io_write32(struct rpp_dev *pdev, uint32_t data, uint32_t addr);
uint32_t rpp_io_read32(struct rpp_dev *pdev, uint32_t addr);
#if 0
void rpp_io_write16(struct rpp_dev *pdev, uint16_t data, uint32_t addr);
uint16_t rpp_io_read16(struct rpp_dev *pdev, uint32_t addr);
void rpp_io_write8(struct rpp_dev *pdev, uint8_t data, uint32_t addr);
uint8_t rpp_io_read8(struct rpp_dev *pdev, uint32_t addr);
#endif
int rpp_pcie_init(struct rpp_dev *pdev);
void rpp_pcie_exit(struct rpp_dev *pdev);
int rpp_remap(struct rpp_dev *pdev, uint32_t bar, struct vm_area_struct *vma);
struct rpp_dev *xdev_find_by_iss_sock(struct sock *iss_sk);
void rpp_snps_mpu_write32(struct rpp_dev *pdev, uint32_t addr, uint32_t data);
void rpp_snps_mpu_read32(struct rpp_dev *pdev, uint32_t addr, uint32_t *data);

struct hal_pcie_dev * snps_pcie_hal_init(void);
/* void snps_pcie_hal_takedown(struct hal_pcie_dev *hpdev); */

#endif /* __RPP_HAL_PCIE_H__ */
