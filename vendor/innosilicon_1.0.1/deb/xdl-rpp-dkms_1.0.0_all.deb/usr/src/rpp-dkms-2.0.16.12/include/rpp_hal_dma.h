/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright (c) 2018 Synopsys, Inc. and/or its affiliates.
 * Synopsys DesignWare eDMA controller driver.
 */

#ifndef __RPP_HAL_DMA_H__
#define __RPP_HAL_DMA_H__

/*******************************************************************************
 *
 *  HEADER FILE INCLUDES
 *
 ******************************************************************************/

#include "rpp_dma.h"
#include "rpp_dfx.h"

#include <linux/spinlock.h>

/*******************************************************************************
 *
 *  MACRO DEFINITIONS
 *
 ******************************************************************************/
/**
 * Maximum element number of DMA linked list descriptor.
 * Maximum transfer size = MAX_LLELEMENT_NUM * PAGE_SIZE = 2048*4k = 8M
 */
#if 0
#define MAX_LLELEMENT_NUM   2048
#else // 16k * 4k = 64MB, fix 2 channel for llama2
#define MAX_LLELEMENT_NUM   16 * 1024
#endif
/**
 * Maximum block size for a DMA transfer, in unit of byte.
 */
#define MAX_BLOCK_SIZE     (MAX_LLELEMENT_NUM * 4096) // (4 * 1024 * 1024 * 1024 - 1)   // 4G bytes
/**
 * Minimum block size for a DMA transfer, in unit of byte.
 */
#define MIN_BLOCK_SIZE      1   // 1 byte
/**
 * Minimum element number of DMA linked list descriptor.
 */
#define MIN_LLELEMENT_NUM   1
/**
 * Maximum length of linked list in unit of dword
 */
#define MAX_LL_LEN          (MAX_LLELEMENT_NUM * 6)     // dwords
/**
 * Maximum weight value a channel can be specified.
 */
#define MAX_WEIGHT          31
/**
 * Minimum weight value a channel can be specified.
 */
#define MIN_WEIGHT          0

/*******************************************************************************
 *
 *  CALLBACK DECLARATIONS
 *
 ******************************************************************************/
/**
 * Linked list producer callback function that the DMA HAL user need to
 * provide when multi block transfer is requested. Whenever the HAL tries
 * to update the linked list element, it will call this function to get next
 * SAR/DAR/XferSize. If the linked list has N data elements and it will be
 * recycled M times, then user must guarantee that this callback function can
 * return meaningful data (N * M) times.
 *
 * @note Because this callback is called during ISR, user must guarantee that
 * it can return as soon as possible.
 *
 * @param[in,out] src   The source physical address.
 * @param[in,out] dst   The destination physical address.
 * @param[in,out] size  The transfer size.
 * @param[in] dirc      The direction of current channel.
 * @param[in] chan      The number of current channel.
 * @param[in] context   The context the user need to know.
 * @return True if new data is provided; False if no more data need to be
 * transferred.
 */
typedef BOOLEAN (*PRODUCER_FUNC)(PHYADDR *src, PHYADDR *dst, UINT32 *size,
        DMA_DIRC dirc, UINT8 chan, PVOID context);

/**
 * Linked list producer callback function that the DMA HAL user need to
 * provide when multi block transfer is requested. Whenever the HAL tries
 * to update the linked list element, it will call this function to get next
 * SAR/DAR/XferSize. If the linked list has N data elements and it will be
 * recycled M times, then user must guarantee that this callback function can
 * return meaningful data (N * M) times.
 *
 * @note Because this callback is called during ISR, user must guarantee that
 * it can return as soon as possible.
 *
 * @param[in,out] src   The source physical address.
 * @param[in,out] dst   The destination physical address.
 * @param[in,out] size  The transfer size.
 * @param[in] dirc      The direction of current channel.
 * @param[in] index     The index of element dma block.
 * @param[in] offset    The offset of device address.
 * @param[in] context   The context the user need to know.
 * @return True if new data is provided; False if no more data need to be
 * transferred.
 */
typedef BOOLEAN(*PRODUCER_CB)(PHYADDR *src, PHYADDR *dst, UINT32* size,
        DMA_DIRC dirc, UINT32* index, UINT64* offset, PVOID context);

/**
 * This is a callback that will be called every time the transfer on specified
 * DMA channel get finished. User can set this callback in DMA_SRC struct to
 * do something they need to do as a post-transfer process.
 *
 * @note Because this callback is called during ISR, user must guarantee that
 * it can return as soon as possible. For heavy tasks, user should schedule DPC
 * to do the job outside ISR.
 *
 * @param[in] dirc      The direction of the channel that transfer is done.
 * @param[in] chan      The number of the channel that transfer is done.
 * @param[in] context   The context the callback need to know.
 */
typedef void (*XFER_DONE_FUNC)(DMA_DIRC dirc, UINT8 chan, PVOID context);

/*******************************************************************************
 *
 *  DATA STRUCTURE DEFINITIONS
 *
 ******************************************************************************/
/**
 * DMA Channel related information. This data struct is designed for HAL
 * internal use. User should NOT modify the value of any data memeber.
 */
typedef struct {
    // Initialized by user request
    UINT64 FeedSize;    /**< Total size of DMA transfer. */
    UINT32 LLElements;   /**< Number of linked list elements */
    UINT8 WaterMark;    /**< Index of watermark element */
    UINT8 Weight;       /**< The weight of this channel */
    UINT32 Recycle;     /**< How many times to recycle to linked list */
    PRODUCER_FUNC ProducerFunc;
                        /**< Linked list producer function for this channel */
    PVOID ProducerContext;
                        /**< The context used by ProducerFunc */
    // Updated by HW
    UINT32 XferSize;    /**< The data size have not been xferred in one block.*/
    PHYADDR ElementPos; /**< The element the DMA is currently transferring */
    DMA_CHAN_STATUS Status;
                        /**< Channel status, like running, stopped etc. */
    DMA_ERR Error;      /**< DMA hardware error if any */
    // Updated by driver
    UINT8 PCS;          /**< PCS flag. Used in multi block transfer mode. */
    UINT8 ElementIdx;   /**< Index of data element the DMA is currently working
                         *   on during linked list update. It's for multi block
                         *   transfer use. */
    PHYADDR SrcPos;     /**< The source address the DMA is working on. */
    PHYADDR DstPos;     /**< The destination address the DMA is working on. */
    UINT32 FirstElementXferSize;    /**< The data size of the first element.*/
    UINT32 DoneIntrCnt;
                        /**< DONE interrupt count */
    UINT32 AbortIntrCnt;
                        /**< ABORT interrupt count */
} CHAN_INFO, *PCHAN_INFO;

/**
 * The DMA resource data structure. DMA resourse is the primary data structure
 * that HAL works upon. It includes the information of DMA register map, the
 * linked list address, the number enabled channels, the MSI configuration, and
 * the context data for each channel etc.
 */
typedef struct {
    PDMA_REGS DmaRegs;      /**< The pointer to DMA registers */

    PHYADDR LLPhyAddr[16];  /**< */
    PUINT32 LLVirAddr[16];  /**< */
    CHAN_INFO WrChanInfo[8];/**< The information for all write channels */
    CHAN_INFO RdChanInfo[8];/**< The information for all read channels */
    PHYADDR MsiAddr;        /**< MSI address */
    UINT16 MsiData;         /**< MSI data */
    PVOID IntrObj;          /**< The interrupt object, OS-specific */
    INT32 Irq;
    spinlock_t SyncLock;    /**< Protects DMA register and channel info sync sections */
    XFER_DONE_FUNC XferDoneFunc;
                            /**< Callback will be called when xfer is done. */
    PVOID XferDoneContext;  /**< Context for XferDoneFunc callback */
    // Following members are read from DMA register
    UINT8 WrChans;          /**< Enabled write channels */
    UINT8 RdChans;          /**< Enabled read channels */
} DMA_RSC, *PDMA_RSC;

/**
 * HAL DMA return code.
 * @see HalDmaGetErrInfo
 */
typedef enum {
    DMA_SUCCESS = 0,       /**< HAL operation succeed */
    DMA_CHAN_BUSY,         /**< Channel is busy to respond */
    DMA_INVALID_CHAN,      /**< Invalid channel number */
    DMA_INVALID_BLOCK_SIZE,/**< Invalid block size */
    DMA_INVALID_LL_LEN,    /**< Invalid linked list length */
    DMA_INVALID_WM,        /**< Invalid watermark element index */
    DMA_INVALID_WEIGHT,    /**< Invalid weight value */
    DMA_NULL_ARG,          /**< Null arguments are received */
    DMA_UNKNOWN_FAILURE,   /**< Unknown failure */
    DMA_NO_QUEUING_JOBS,   /**< No queuing jobs found */
    DMA_NO_FEED,           /**< No new data are feed to linked list */
    DMA_NO_LL,             /**< No linked list are created */
    DMA_FATAL,             /**< Driver fatal error */

    DMA_ERR_CODE_NUM       /**< HAL return code numbers */

} HAL_DMA_RET;

/**
 *  This struct is only used as a parameter wrapper for protected functions.
 *  Protected functions contains atomic HW operations which must not be
 *  broken off by the interrupt service routine (ISR).
 */
typedef struct {
    PDMA_RSC DmaRsc;
    DMA_DIRC Dirc;
    UINT8 Chan;
    PVOID Data;
} DMA_SYNCRUN_CONTEXT, *PDMA_SYNCRUN_CONTEXT;


/*******************************************************************************
 *
 * EXTERN FUNCTION DECLARATIONS
 *
 ******************************************************************************/
/* See function comments in RPP_hal_dma.c file. */

/**
* @defgroup hal_api_hi High level eDMA HAL APIs.
* @{
* The functions in this group are high level HAL APIs. All of them are defined
* in RPP_hal_dma.c
*/
HAL_DMA_RET HalDmaInit(PDMA_RSC pdrsc);
HAL_DMA_RET HalDmaSingleBlockWrite(PDMA_RSC pdrsc, UINT8 chan, PHYADDR src,
        PHYADDR dst, UINT32 size, UINT8 wei, BOOLEAN queue);
HAL_DMA_RET HalDmaMultiBlockWrite(PDMA_RSC pdrsc, UINT8 chan, UINT32 lle,
        UINT8 wm, UINT32 recyc, UINT8 wei, BOOLEAN queue, PRODUCER_FUNC func,
        PVOID ctx);
HAL_DMA_RET HalDmaMultiBlockWrite2(PDMA_RSC pdrsc, UINT8 ping, UINT8 pong, UINT32 lle,
        UINT8 wm, UINT32 recyc, UINT8 wei, BOOLEAN queue, PRODUCER_CB func,
        PVOID ctx);
HAL_DMA_RET HalDmaMultiBlockWrite2_1(PDMA_RSC pdrsc, UINT8 chan, UINT32 lle,
        UINT8 wm, UINT32 recyc, UINT8 wei, BOOLEAN queue, PRODUCER_CB func,
        PVOID ctx);
HAL_DMA_RET HalDmaSingleBlockRead(PDMA_RSC pdrsc, UINT8 chan, PHYADDR src,
        PHYADDR dst, UINT32 size, UINT8 wei, BOOLEAN queue);
HAL_DMA_RET HalDmaMultiBlockRead(PDMA_RSC pdrsc, UINT8 chan, UINT32 lle,
        UINT8 wm, UINT32 recyc, UINT8 wei, BOOLEAN queue, PRODUCER_FUNC func,
        PVOID ctx);
HAL_DMA_RET HalDmaMultiBlockRead2(PDMA_RSC pdrsc, UINT8 ping, UINT8 pong, UINT32 lle,
        UINT8 wm, UINT32 recyc, UINT8 wei, BOOLEAN queue, PRODUCER_CB func,
        PVOID ctx);
HAL_DMA_RET HalDmaMultiBlockRead2_1(PDMA_RSC pdrsc, UINT8 chan, UINT32 lle,
        UINT8 wm, UINT32 recyc, UINT8 wei, BOOLEAN queue, PRODUCER_CB func,
        PVOID ctx);
HAL_DMA_RET HalDmaAbort(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan);
HAL_DMA_RET HalDmaStop(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan);
HAL_DMA_RET HalDmaResume(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan);
HAL_DMA_RET HalDmaFlushQueue(PDMA_RSC pdrsc);
HAL_DMA_RET HalDmaState(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan,
        DMA_CHAN_STATUS *stat, DMA_ERR *err, UINT64 *xferred,
        UINT32 *intCntDone, UINT32 *intCntAbort);
HAL_DMA_RET HalDmaISR(PDMA_RSC pdrsc);
HAL_DMA_RET HalDmaDumpReg(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan, char *buf);
HAL_DMA_RET HalDmaDumpLL(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan, char *buf);
char * HalDmaGetErrInfo(HAL_DMA_RET code);
/** @}*/

#endif //__RPP_HAL_DMA_H__
