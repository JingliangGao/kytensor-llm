/*
 * This file is part of the Azurengine DMA IP Core driver for Linux
 *
 * Copyright (c) 2016-present,  Azurengine, Inc.
 * All rights reserved.
 *
 * This source code is licensed under both the BSD-style license (found in the
 * LICENSE file in the root directory of this source tree) and the GPLv2 (found
 * in the COPYING file in the root directory of this source tree).
 * You may select, at your option, one of the above-listed licenses.
 */

#ifndef __RPP_SDEV_H__
#define __RPP_SDEV_H__

#include <linux/kernel.h>
#include <linux/types.h>
#include <linux/uaccess.h>
#include <linux/errno.h>

#include "rpp_dev.h"

void switch_dev_init(rpp_switch_t *xsdev);
int rpp_sdev_add_devices(struct rpp_dev *xpdev);
int rpp_sdev_remove_devices(struct rpp_dev *pdev);

int rpp_sdev_info_init(void);
void rpp_sdev_info_exit(void);

int rpp_sdev_dump(rpp_switch_t *xsdev, char *buff, uint32_t size_of_buff);
rpp_switch_t *rpp_sdev_search_by_devices(struct rpp_dev *xpdev);
int rpp_sdev_remap_pci_bar(rpp_switch_t *sdev, struct vm_area_struct *vma);

#endif /* __RPP_SDEV_H__ */
