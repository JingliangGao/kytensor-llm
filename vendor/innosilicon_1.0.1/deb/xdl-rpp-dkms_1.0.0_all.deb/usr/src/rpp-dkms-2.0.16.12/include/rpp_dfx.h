/* SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright (c) 2018 Synopsys, Inc. and/or its affiliates.
 * Synopsys DesignWare eDMA controller driver.
 */

#ifndef __RPP_DFX_H__
#define __RPP_DFX_H__


#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/delay.h>
#include <linux/string.h>
#include <linux/init.h>
#include <linux/interrupt.h>
#include <linux/spinlock.h>
#include <asm/io.h>
#include "rpp_types.h"

#define MAX_MSG_SIZE        2048
#define DEV_ID_MAX_LEN      16

#define WARNING_PRINT(fmt, args...) printk(KERN_WARNING "RPP_WARN  [%s, %d]: " fmt, __FUNCTION__,  __LINE__, ## args)
#define ERROR_PRINT(fmt, args...) printk(KERN_ERR "RPP_ERROR [%s, %d]: " fmt, __FUNCTION__,  __LINE__, ## args)
#define INFO_PRINT(fmt, args...) printk(KERN_INFO "RPP_INFO  [%s, %d]: " fmt, __FUNCTION__,  __LINE__, ## args)

/* #define RPP_DEBUG_ 1 */

#ifdef RPP_DEBUG_
#  define DEBUG_PRINT(fmt, args...) printk(KERN_DEBUG "RPP_DEBUG [%s, %d]: " fmt, __FUNCTION__,  __LINE__, ## args)
#  define DTRACE(fmt,...) \
       do { printk(KERN_DEBUG "RPP_TRACE [%s, %d]: " fmt, \
    	    __FUNCTION__, __LINE__, ##__VA_ARGS__);} while(0)
#else
#  define DEBUG_PRINT(fmt, args...)
#  define DTRACE(fmt,...)
#endif

#define DPRINTF(...) \
    do {snprintf(__VA_ARGS__);} while(0)

#define DSTR_LEN(str,len) ((*len) = strlen(str))

#define DEPRINTF(des,s,fmt,...) \
    do {snprintf(des, s, "[ERR] " fmt, ##__VA_ARGS__);} while(0)

/*
 * RPP_DEV_ID - Get device identifier string
 * @rdev: RPP device structure pointer (must be initialized with RPP_DEV_MAGIC)
 *
 * Returns pre-formatted device prefix if magic is valid, otherwise "UNKNOWN"
 */
#define RPP_DEV_ID(rdev) \
    ((rdev) && ((rdev)->magic == RPP_DEV_MAGIC) ? (rdev)->dev_prefix : "UNKNOWN")

#define DEV_WARN(rdev, fmt, args...) \
    printk(KERN_WARNING "RPP_WARN  [%s] [%s, %d]: " fmt, \
           RPP_DEV_ID(rdev), __FUNCTION__, __LINE__, ## args)

#define DEV_ERROR(rdev, fmt, args...) \
    printk(KERN_ERR "RPP_ERROR [%s] [%s, %d]: " fmt, \
           RPP_DEV_ID(rdev), __FUNCTION__, __LINE__, ## args)

#define DEV_INFO(rdev, fmt, args...) \
    printk(KERN_INFO "RPP_INFO  [%s] [%s, %d]: " fmt, \
           RPP_DEV_ID(rdev), __FUNCTION__, __LINE__, ## args)

#ifdef RPP_DEBUG_
#  define DEV_DEBUG(rdev, fmt, args...) \
    printk(KERN_DEBUG "RPP_DEBUG [%s] [%s, %d]: " fmt, \
           RPP_DEV_ID(rdev), __FUNCTION__,  __LINE__, ## args)
#  define DEV_TRACE(rdev, fmt, ...) \
    do { printk(KERN_DEBUG "RPP_TRACE [%s] [%s, %d]: " fmt, \
           RPP_DEV_ID(rdev), __FUNCTION__,  __LINE__, ##__VA_ARGS__);} while(0)
#else
#  define DEV_DEBUG(rdev, fmt, args...)
#  define DEV_TRACE(rdev, fmt, ...)
#endif

#define DMA_SYNC_LOCK(r, flags) spin_lock_irqsave(&(r)->SyncLock, flags)
#define DMA_SYNC_UNLOCK(r, flags) spin_unlock_irqrestore(&(r)->SyncLock, flags)

#define INT_SYNC_RUN(f,c) \
	do { \
		unsigned long flags; \
		DMA_SYNC_LOCK((c)->DmaRsc, flags); \
		f(c); \
		DMA_SYNC_UNLOCK((c)->DmaRsc, flags); \
	}while(0)

#define KERNEL_WAIT(t) mdelay(t)
#define HW_WAIT() ndelay(100)

#define RtlZeroMemory(Destination,Length) memset((Destination),0,(Length))
#define ZERO_MEM(p,s) RtlZeroMemory((p),(s))

#define RPP_READ_UINT8(_addr)               ioread8((PUINT8)(_addr))
#define RPP_READ_UINT16(_addr)              ioread16((PUINT16)(_addr))
#define RPP_READ_UINT16_SAFE(_addr) \
	((UINT16)((UINT_PTR)_addr & 0x3 ? \
	ioread32((PUINT32)((UINT_PTR)_addr & (~((UINT_PTR)0) << 2))) >> 16  : \
	ioread32(_addr)))
#define RPP_READ_UINT32(_addr)              ioread32((PUINT32)(_addr))
#define RPP_WRITE_UINT8(_addr,Value)        iowrite8(Value, (PUINT8)(_addr))
#define RPP_WRITE_UINT16(_addr,Value)       iowrite16(Value, (PUINT16)(_addr))
#define RPP_WRITE_UINT16_SAFE(_addr,_Value) \
	do { \
		PUINT32 alignedAddr = (PUINT32)((UINT_PTR)_addr & (~((UINT_PTR)0) << 2)); \
		UINT32 oldv = ioread32(alignedAddr); \
		if ((char*)alignedAddr != (char*)_addr) { \
			iowrite32((oldv & 0xFFFF) | (_Value << 16), alignedAddr); \
		} else { \
			iowrite32((oldv & (0xFFFF << 16)) | _Value, alignedAddr); \
		} \
	} while(0)

#if 1
#define RPP_WRITE_UINT32(_addr,Value)       iowrite32(Value, (PUINT32)(_addr))
#else
#define RPP_WRITE_UINT32(_addr,Value) { \
	pr_err("write RPP, addr=0x%llx, value=0x%x\n", (PUINT32)(_addr), Value); \
	iowrite32(Value, (PUINT32)(_addr)); \
}
#endif

#define RPP_DIV64(a, b) \
	({ \
		uint64_t t = a; \
		do_div(t, b); \
		(t); \
	})

/*
* bit operations
* eg:
* [31, 30, 29, ..., 2, 1, 0]
* index is 31, ..., 0 bit
* num count [index, index + num] closed interval.
* SET_BITS(val, index, num) is set index bit to (index + num) bit as 1, include index bit and (index + num) bit.
*/
#define SET_BIT(val, index)			((val |= (0x1 << index)))
#define CLR_BIT(val, index)			((val &= (~(0x1 << index))))
#define SET_BITS(val, index, num)	((val |= ((0x1 << (index + num + 1) - 1) - (0x1 << (index + 1) - 1))))
#define CLR_BITS(val, index, num)	((val &= (~((0x1 << (index + num + 1) - 1) - (0x1 << (index + 1) - 1)))))
#define GET_BIT(val, index)			((val & (0x1 << index)))
#define GET_BITS(val, index, num)	((val & ((0x1 << (index + num + 1) - 1) - (0x1 << (index + 1) - 1))))

#endif /* __RPP_DFX_H__ */
