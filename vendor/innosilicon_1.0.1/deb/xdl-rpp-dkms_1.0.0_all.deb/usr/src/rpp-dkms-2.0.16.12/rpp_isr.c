
#include <linux/ioctl.h>
#include <linux/types.h>
#include <linux/errno.h>
#include <linux/aer.h>
#include <linux/idr.h>
#include <linux/spinlock.h>
#include <linux/pci.h>
#include <linux/msi.h>
#include <linux/cpumask.h>


#include "include/rpp_dev.h"
#include "include/rpp_com.h"
#include "include/rpp_isr.h"
#include "include/rpp_hal_dma.h"
#include "include/rpp_hal_pcie.h"
#include "include/rpp_vdev_ctrl.h"      /*irq for ve*/
#include "include/rpp_dev_list.h"

#define NUM_OF_MSI 5
#define RPP_SCHE              0x0
#define RPP_MPU               0x1

#define MPU_PVT_T_WARNING     0x1
#define MPU_PVT_V_WARNING     0x2
#define MPU_FORCE_SHUTDOWN    0x3
#define MPU_TEM_BACK_NORMAL    0x4
#define MPU_CORE_BLOCK_WARNING 0x5
#define MPU_SCHE_BLOCK_WARNING 0x6
#define MPU_PCIE_BLOCK_WARNING 0x7

#define MAX_INTERRUPT_MSG		1024

void rpp_tasklet_func(unsigned long data)
{
	struct rpp_dev *pdev = (void *)data;
	struct rpp_int_info int_info;
	struct rpp_int_info int_info_out;
	int rlen;
	uint32_t i;
	int_info.int_vector = (pdev->idx << 16) | RPP_SCHE;
	int_info.int_info_1 = rpp_io_read32(pdev, RPP_SCHE_INT_INFO_1);
	int_info.int_info_2 = rpp_io_read32(pdev, RPP_SCHE_INT_INFO_2);
/* sizeof(sche_desc_t) = 32 bytes */

/* 20240412 Don't access sche space use bar for qwen_dev, fix 20241030 */
	if (int_info.int_info_2 < (0x8000000 - 9 * sizeof(UINT32))) {
		for (i = 0; i < 8; i++) {
			RPP_rw_pci_bar(pdev, 0, 0, 4, int_info.int_info_2 + i*4, (UCHAR *)&int_info.int_desc[i]);
		}
	}

	/* FIXME Windows dont clear scheduler interrupt */
	/* write 0x1 to clear the scheduler interrupt */
	rpp_io_write32(pdev, 0x1, RPP_PCIE_INT_CLEAR);
	DEV_DEBUG(pdev, "%s, 0x%x, 0x%x\n", __func__, int_info.int_info_1, int_info.int_info_2);

	/* if (pdev->serv != NULL) */
	if (1) {
		/* isr kernel to user performance test */
		/* struct timespec64 isr_kts; */
		ktime_get_real_ts64(&int_info.isr_kts);
		/* pr_notice("isr at kernel time: %lds, %ldns\n", isr_kts.tv_sec, isr_kts.tv_nsec); */
		/* int_info.isr_kts =  isr_kts; */

		if (kfifo_is_full(&pdev->isr_kfifo)) {
			rlen = kfifo_out(&pdev->isr_kfifo, (void *)&int_info_out, sizeof(struct rpp_int_info));
			if (rlen != sizeof(struct rpp_int_info)) {
				DEV_ERROR(pdev, "%s, kfifo_out failed, rlen 0x%x\n", __func__, rlen);
				/* we don't return error here */
			} else {
				DEV_WARN(pdev, "%s, kfifo is full, pop out the first one, 0x%x, 0x%x\n",
					__func__, int_info_out.int_info_1, int_info_out.int_info_2);
			}
		}

		if (kfifo_in(&pdev->isr_kfifo, (u8 *)&int_info, sizeof(struct rpp_int_info)) != sizeof(struct rpp_int_info)) {
			DEV_ERROR(pdev, "%s, kfifo_in failed\n", __func__);
		}
		wake_up(&pdev->wq);
	}
}

void rpp_mpu_tasklet_func(unsigned long data)
{
	struct rpp_dev *pdev = (void *)data;
	struct rpp_int_info int_info;
	struct rpp_int_info int_info_out;
	int rlen;
	uint32_t pvt,rpp_clk,type = 0;

	if (rpp_mpu_get_interrupt_info(pdev, &type, &pvt, &rpp_clk) != 0) {
		DEV_ERROR(pdev, "%s, get mpu interrupt info failed\n", __func__);
	}

	int_info.int_vector = (pdev->idx << 16) | RPP_MPU;
  	int_info.int_info_1 = (type << 4);
  	int_info.int_info_2 = pvt;
  	int_info.int_info_3 = rpp_clk;
  	switch (type) {
    	case MPU_PVT_T_WARNING:
	    DEV_WARN(pdev, "pvt warning!! -> The temperature has exceeded 97 degrees,Reduced RPP frequency\nPVT_T : %d.%d C\n", (pvt & 0xFFFFF) / 1000, (pvt & 0xFFFFF) % 1000);
			break;
    	case MPU_PVT_V_WARNING:
            DEV_WARN(pdev, "pvt warning!! -> The voltage has been below 720mv,Reduced RPP frequency\nPVT_V : %d.%d V\n", ((pvt >> 20) & 0xFFFF) / 1000, ((pvt >> 20) & 0xFFFF) % 1000);
      		break;
    	case MPU_FORCE_SHUTDOWN:
            DEV_ERROR(pdev, "shut down !!!!!\nPVT_V : %d.%d PVT_T : %d.%d\n",((pvt >> 20) & 0xFFFF) / 1000,((pvt >> 20) & 0xFFFF) % 1000,(pvt & 0xFFFFF) / 1000,(pvt & 0xFFFF) % 1000);
      		break;
        case MPU_TEM_BACK_NORMAL:
            DEV_WARN(pdev, "The core frequency has returned to the normal state\n");
      		break;
        case MPU_CORE_BLOCK_WARNING:
            DEV_WARN(pdev, "warning!! -> The core module is blocked\n");
      		break;
        case MPU_SCHE_BLOCK_WARNING:
            DEV_WARN(pdev, "warning!! -> The sche module is blocked\n");
      		break;
        case MPU_PCIE_BLOCK_WARNING:
            DEV_WARN(pdev, "warning!! -> The pcie module is blocked\n");
      		break;
    	default:
      	break;
	}
	/* if (pdev->serv != NULL) */
	/* Interrupt nesting occurs when mpu interrupts perform pcie read and write operations internally, so it is not handled */
	if (0) {
			/* isr kernel to user performance test */
			/* struct timespec64 isr_kts; */
			ktime_get_real_ts64(&int_info.isr_kts);
			/* pr_notice("isr at kernel time: %lds, %ldns\n", isr_kts.tv_sec, isr_kts.tv_nsec); */
			/* int_info.isr_kts =  isr_kts; */

			if (kfifo_is_full(&pdev->isr_kfifo)) {
				rlen = kfifo_out(&pdev->isr_kfifo, (void *)&int_info_out, sizeof(struct rpp_int_info));
				if (rlen != sizeof(struct rpp_int_info)) {
					DEV_ERROR(pdev, "%s, kfifo_out failed, rlen 0x%x\n", __func__, rlen);
					/* we don't return error here */
				} else {
					DEV_WARN(pdev, "%s, kfifo is full, pop out the first one, 0x%x, 0x%x\n",
						__func__, int_info_out.int_info_1, int_info_out.int_info_2);
				}
			}

			if (kfifo_in(&pdev->isr_kfifo, (u8 *)&int_info, sizeof(struct rpp_int_info)) != sizeof(struct rpp_int_info)) {
				DEV_ERROR(pdev, "%s, kfifo_in failed\n", __func__);
			}
			wake_up(&pdev->wq);
  	}
}

#if VE_ISR_TASKLET
void codec0_tasklet_func(unsigned long data)
{
    codec0_isr_handler(data);
}

void codec1_tasklet_func(unsigned long data)
{
    codec1_isr_handler(data);
}

void codec2_tasklet_func(unsigned long data)
{
    codec2_isr_handler(data);
}

void codec3_tasklet_func(unsigned long data)
{
    codec3_isr_handler(data);
}

void jpeg0_tasklet_func(unsigned long data)
{
    jpeg0_isr_handler(data);
}

void jpeg1_tasklet_func(unsigned long data)
{
    jpeg1_isr_handler(data);
}

void jpeg2_tasklet_func(unsigned long data)
{
    jpeg2_isr_handler(data);
}

void jpeg3_tasklet_func(unsigned long data)
{
    jpeg3_isr_handler(data);
}
#endif

static void rpp_do_tasklet(int irq_vector, void *data) {
	struct rpp_dev *pdev = (struct rpp_dev *)data;
    DEV_DEBUG(pdev, "%s, irq_vector=0x%x\n", __func__, irq_vector);

#if 1
    switch (irq_vector) {
	case RPP_DMA_INT:
		/* TODO */
		break;
	case RPP_SCH_INT:

#if 0
        xdev->int_info_1 = rpp_io_read32(xdev, RPP_SCHE_INT_INFO_1);
        xdev->int_info_2 = rpp_io_read32(xdev, RPP_SCHE_INT_INFO_2);
        DEV_DEBUG(pdev, "[irq] %s, int_info_1=0x%x\n", __func__, xdev->int_info_1);
        DEV_DEBUG(pdev, "[irq] %s, int_info_2=0x%x\n", __func__, xdev->int_info_2);

        tasklet_schedule(&pdev->rpp_tasklet);

        /* write 0x1 to clear the scheduler interrupt */
        rpp_io_write32(xdev, 0x1, RPP_PCIE_INT_CLEAR);
#else
        tasklet_schedule(&pdev->rpp_tasklet);
#endif
        break;
    case RPP_JPEG_INT0:   /*JPEG0*/
#ifdef SUPPORT_MULTI_INST_INTR
    #if VE_ISR_TASKLET
        tasklet_schedule(&pdev->jpeg0_tasklet);
    #else
        jpeg0_isr_handler(pdev);
    #endif
#endif
        break;
    case RPP_JPEG_INT1:   /*JPEG1*/
#ifdef SUPPORT_MULTI_INST_INTR
    #if VE_ISR_TASKLET
         tasklet_schedule(&pdev->jpeg1_tasklet);
    #else
        jpeg1_isr_handler(pdev);
    #endif
#endif
        break;
    case RPP_CODEC_INT0:
#ifdef SUPPORT_MULTI_INST_INTR
    #if VE_ISR_TASKLET
        tasklet_schedule(&pdev->codec0_tasklet);
    #else
        codec0_isr_handler(pdev);
    #endif
#endif
        break;
    case RPP_CODEC_INT1:
#ifdef SUPPORT_MULTI_INST_INTR
    #if VE_ISR_TASKLET
        tasklet_schedule(&pdev->codec1_tasklet);
    #else
        codec1_isr_handler(pdev);
    #endif
#endif
        break;
    case RPP_JPEG_INT2:   /*JPEG2*/
#ifdef SUPPORT_MULTI_INST_INTR
    #if VE_ISR_TASKLET
        tasklet_schedule(&pdev->jpeg2_tasklet);
    #else
        jpeg2_isr_handler(pdev);
    #endif
#endif
        break;
    case RPP_JPEG_INT3:   /*JPEG3*/
#ifdef SUPPORT_MULTI_INST_INTR
    #if VE_ISR_TASKLET
        tasklet_schedule(&pdev->jpeg3_tasklet);
    #else
        jpeg3_isr_handler(pdev);
    #endif
#endif
        break;
    case RPP_CODEC_INT2:
#ifdef SUPPORT_MULTI_INST_INTR
    #if VE_ISR_TASKLET
        tasklet_schedule(&pdev->codec2_tasklet);
    #else
        codec2_isr_handler(pdev);
    #endif
#endif
        break;
    case RPP_CODEC_INT3:
#ifdef SUPPORT_MULTI_INST_INTR
    #if VE_ISR_TASKLET
        tasklet_schedule(&pdev->codec3_tasklet);
    #else
        codec3_isr_handler(pdev);
    #endif
#endif
        break;
    case RPP_MPU_NORMAL_INT0:
        tasklet_schedule(&pdev->rpp_mpu_tasklet);
        break;
    case RPP_MPU_NORMAL_INT1:
    case RPP_MPU_NORMAL_INT2:
    case RPP_MPU_NORMAL_INT3:
        /*  TODO: */
        break;
    case RPP_MPU_DMA_INT:
        /*  TODO: */
    break;
    case RPP_VPU_NORMAL_INT0:
    case RPP_VPU_NORMAL_INT1:
    case RPP_VPU_NORMAL_INT2:
    case RPP_VPU_NORMAL_INT3:
        /*  TODO: */
        break;
    case RPP_VPU_DMA_INT:
        /*  TODO: */
        break;
    case RPP_CORE_INT:
        /*  TODO: */
    break;
    }
#endif

}

#if 1
static irqreturn_t msi_isr(int irq, void *dev_id)
{
    struct rpp_dev *pdev = NULL;

    pdev = (struct rpp_dev *)dev_id;
    if (!pdev)
        return IRQ_NONE;

    DEV_DEBUG(pdev, "IRQ no %d\n", irq);
  #ifndef SUPPORT_ISR_ITSELF
    uint32_t i;
    int irq_data;
    PDMA_RSC pDmaRsc;
	int pcie_irq_vector = 0;

    irq_data = pci_irq_vector(pdev->pdev, 0);

	if (pdev->no_of_msi < 32) {
		/* vector 0, pcie interrupt */
		pcie_irq_vector = 0;
	} else {
		pcie_irq_vector = 22;
	}
	if (irq - irq_data == pcie_irq_vector) {
		/* Call HAL ISR to get interrupt source, clear interrupt,
		 * update linked list elements etc.
		 */
		pDmaRsc = &pdev->RPP_ext.DmaRsc;
		HalDmaISR(pDmaRsc);
	} else {
		for (i = 0; i < pdev->no_of_msi; i++) {
			if (irq == pci_irq_vector(pdev->pdev, i)) {
				pdev->isr(i, pdev->owner);
				break;
			}
		}
	}
  #else
  #endif
    pdev->irq_count++;

    return IRQ_HANDLED;
}

#ifdef SUPPORT_ISR_ITSELF
/*  FIXME: Windows use HalDmaISR2 */
static irqreturn_t dma_isr(int irq, void *dev_id)
{
    struct rpp_dev *pdev = NULL;
    PDMA_RSC pDmaRsc;
    uint8_t chan;
    DMA_DIRC dirc;
    HAL_DMA_RET ret = DMA_SUCCESS;

    pdev = (struct rpp_dev *)dev_id;
    if (!pdev)
        return IRQ_NONE;

    pDmaRsc = &pdev->RPP_ext.DmaRsc;
    ret = HalDmaISR2(pdev, pDmaRsc, &chan, &dirc);
	if (ret != DMA_SUCCESS) {
		DEV_ERROR(pdev, "Failed to HalDmaISR eDMA device: %s\n", HalDmaGetErrInfo(ret));
		return;
	}
    rpp_dma_isr_wakeup(pdev);

    pdev->isr_dma = 1;
    wake_up(&pdev->wq_dma);
    
    pdev->irq_count++;
    return IRQ_HANDLED;
}

static irqreturn_t sch_isr(int irq, void *dev_id)
{
    struct rpp_dev *pdev = NULL;
    PDMA_RSC pDmaRsc;

    pdev = (struct rpp_dev *)dev_id;
    if (!pdev)
        return IRQ_NONE;

    tasklet_schedule(&pdev->rpp_tasklet);

    pdev->irq_count++;
    return IRQ_HANDLED;
}

static irqreturn_t codec_isr0(int irq, void *dev_id)
{
    struct rpp_dev *pdev = NULL;

    pdev = (struct rpp_dev *)dev_id;
    if (!pdev)
    return IRQ_NONE;

  #ifdef SUPPORT_MULTI_INST_INTR
    #if VE_ISR_TASKLET
        tasklet_schedule(&pdev->codec0_tasklet);
    #else
        codec0_isr_handler(pdev);
    #endif
  #endif

    pdev->irq_count++;
    return IRQ_HANDLED;
}

static irqreturn_t codec_isr1(int irq, void *dev_id)
{
    struct rpp_dev *pdev = NULL;

    pdev = (struct rpp_dev *)dev_id;
    if (!pdev)
    return IRQ_NONE;

  #ifdef SUPPORT_MULTI_INST_INTR
    #if VE_ISR_TASKLET
        tasklet_schedule(&pdev->codec1_tasklet);
    #else
        codec1_isr_handler(pdev);
    #endif
  #endif

    pdev->irq_count++;
    return IRQ_HANDLED;
}

static irqreturn_t jpeg_isr0(int irq, void *dev_id)
{
    struct rpp_dev *pdev = NULL;

    pdev = (struct rpp_dev *)dev_id;
    if (!pdev)
    return IRQ_NONE;

  #ifdef SUPPORT_MULTI_INST_INTR
    #if VE_ISR_TASKLET
        tasklet_schedule(&pdev->jpeg0_tasklet);
    #else
        jpeg0_isr_handler(pdev);
    #endif
  #endif

    pdev->irq_count++;
    return IRQ_HANDLED;
}

static irqreturn_t jpeg_isr1(int irq, void *dev_id)
{
    struct rpp_dev *pdev = NULL;

    pdev = (struct rpp_dev *)dev_id;
    if (!pdev)
    return IRQ_NONE;

  #ifdef SUPPORT_MULTI_INST_INTR
    #if VE_ISR_TASKLET
        tasklet_schedule(&pdev->jpeg1_tasklet);
    #else
        jpeg1_isr_handler(pdev);
    #endif
  #endif

    pdev->irq_count++;
    return IRQ_HANDLED;
}

static irqreturn_t codec_isr2(int irq, void *dev_id)
{
    struct rpp_dev *pdev = NULL;

    pdev = (struct rpp_dev *)dev_id;
    if (!pdev)
    return IRQ_NONE;

  #ifdef SUPPORT_MULTI_INST_INTR
    #if VE_ISR_TASKLET
        tasklet_schedule(&pdev->codec2_tasklet);
    #else
        codec2_isr_handler(pdev);
    #endif
  #endif

    pdev->irq_count++;
    return IRQ_HANDLED;
}

static irqreturn_t codec_isr3(int irq, void *dev_id)
{
    struct rpp_dev *pdev = NULL;

    pdev = (struct rpp_dev *)dev_id;
    if (!pdev)
    return IRQ_NONE;

  #ifdef SUPPORT_MULTI_INST_INTR
    #if VE_ISR_TASKLET
        tasklet_schedule(&pdev->codec3_tasklet);
    #else
        codec3_isr_handler(pdev);
    #endif
  #endif

    pdev->irq_count++;
    return IRQ_HANDLED;
}

static irqreturn_t jpeg_isr2(int irq, void *dev_id)
{
    struct rpp_dev *pdev = NULL;

    pdev = (struct rpp_dev *)dev_id;
    if (!pdev)
    return IRQ_NONE;

  #ifdef SUPPORT_MULTI_INST_INTR
    #if VE_ISR_TASKLET
        tasklet_schedule(&pdev->jpeg2_tasklet);
    #else
        jpeg2_isr_handler(pdev);
    #endif
  #endif

    pdev->irq_count++;
    return IRQ_HANDLED;
}

static irqreturn_t jpeg_isr3(int irq, void *dev_id)
{
    struct rpp_dev *pdev = NULL;

    pdev = (struct rpp_dev *)dev_id;
    if (!pdev)
    return IRQ_NONE;

  #ifdef SUPPORT_MULTI_INST_INTR
    #if VE_ISR_TASKLET
        tasklet_schedule(&pdev->jpeg3_tasklet);
    #else
        jpeg3_isr_handler(pdev);
    #endif
  #endif

    pdev->irq_count++;
    return IRQ_HANDLED;
}

static irqreturn_t mpu0_isr(int irq, void *dev_id)
{
    struct rpp_dev *pdev = NULL;

    pdev = (struct rpp_dev *)dev_id;
    if (!pdev)
    return IRQ_NONE;

    tasklet_schedule(&pdev->rpp_mpu_tasklet);

    pdev->irq_count++;
    return IRQ_HANDLED;
}
#endif

#else
static irqreturn_t RPP_isr(int irq, void *dev_id)
{
	PDMA_RSC pDmaRsc;
	struct rpp_dev *pdev = (struct rpp_dev *)dev_id;
	uint32_t data;

	if (!pdev)
		return IRQ_NONE;

	DEV_DEBUG(pdev, "irq no %d\n", irq);
	if (!pdev->small_bar) {
		RPP_rw_pci_bar(pdev, 4, 0, 4, 0x2210c, (UCHAR *)&data);
		DEV_DEBUG(pdev, "status no %x\n", data);
		if (data)
			RPP_rw_pci_bar(pdev, 4, 1, 4, 0x22108, (UCHAR *)&data);
	}

	if (EDMA) {
		pDmaRsc = &pdev->RPP_ext.DmaRsc;

		/* Call HAL ISR to get interrupt source, clear interrupt,
		 * update linked list elements etc.
		 */
		HalDmaISR(pDmaRsc);
	}

	pdev->irq_count++;

	return IRQ_HANDLED;
}

#endif /*  end of #if 1 */

#ifdef SUPPORT_ISR_ITSELF
static const struct rpp_isr isr_table[32] = {
#if IRQ_NUM < 32
	{dma_isr,       "RPP-pciedma"},
#else
    {msi_isr,       "RPP-dma"    },
#endif
    {sch_isr,       "RPP-sch"    },

#if IRQ_NUM > 2
    {jpeg_isr0,     "RPP-jpeg0"  },
    {jpeg_isr1,     "RPP-jpec1"  },
#if IRQ_NUM > 4
    {codec_isr0,    "RPP-codec0" },
    {codec_isr1,    "RPP-codec1" },
    {jpeg_isr2,     "RPP-jpeg2"  },
    {jpeg_isr3,     "RPP-jpeg3"  },
#if IRQ_NUM > 8
    {codec_isr2,    "RPP-codec2" },
    {codec_isr3,    "RPP-codec3" },

    {mpu0_isr,      "RPP-mpuint0"},
    {msi_isr,       "RPP-mpuint1"},
    {msi_isr,       "RPP-mpuint2"},
    {msi_isr,       "RPP-mpuint3"},
    {msi_isr,       "RPP-mpudma" },

    {msi_isr,       "RPP-vpuint0"},
#if IRQ_NUM > 16
    {msi_isr,       "RPP-vpuint1"},
    {msi_isr,       "RPP-vpuint2"},
    {msi_isr,       "RPP-vpuint3"},
    {msi_isr,       "RPP-vpudma" },

    {msi_isr,       "RPP-resv"   },
    {msi_isr,       "RPP-core"   },
    {dma_isr,       "RPP-pciedma"},
    /* dummy */
    {msi_isr,       "RPP-dumy"   },
    {msi_isr,       "RPP-dumy"   },
    {msi_isr,       "RPP-dumy"   },
    {msi_isr,       "RPP-dumy"   },
    {msi_isr,       "RPP-dumy"   },
    {msi_isr,       "RPP-dumy"   },
    {msi_isr,       "RPP-dumy"   },
    {msi_isr,       "RPP-dumy"   },
    {msi_isr,       "RPP-dumy"   }
#endif
#endif
#endif
#endif
};
#endif

int rpp_isr_init(struct rpp_dev *pdev, bool bmisonly, short irq_num)
{
    int rv = 0;
    int rc = 0;
    int i = 0;
    int j = 0;
    int irq = 0;
    int cpu_count = 1;
#ifdef SUPPORT_ISR_ITSELF
    int irq_offset;
    int cpu_index;
    int err;
    cpumask_t mask;
    cpu_count = num_online_cpus();
#endif
#ifdef VPU_HAL_MPU
    int msi_cap;
    uint16_t msg_ctrl;
    uint32_t mask_val;
#endif
    struct pci_dev *pcidev = pdev->pdev;
    struct device *dev = &pcidev->dev;
    struct msi_msg msg;

    /* ped_init */
#ifndef SUPPORT_ISR_ITSELF
    pdev->owner = (void *)pdev;
    pdev->isr = rpp_do_tasklet;
#endif
    rc = kfifo_alloc(&pdev->isr_kfifo, MAX_INTERRUPT_MSG*sizeof(struct rpp_int_info), GFP_KERNEL);
    if (rc < 0) {
        DEV_ERROR(pdev, "Could not alloc kfifo\n");
        rc = -EPERM;
        goto isr_err_out;
    }
    init_waitqueue_head(&pdev->wq);		// for scheduler/mpu interrupt
    init_waitqueue_head(&pdev->wq_dma);	// for dma interrupt
    pdev->isr_dma = 0;

    tasklet_init(&pdev->rpp_tasklet, rpp_tasklet_func, (unsigned long)pdev);
    tasklet_init(&pdev->rpp_mpu_tasklet, rpp_mpu_tasklet_func, (unsigned long)pdev);
#ifdef SUPPORT_MULTI_INST_INTR
    tasklet_init(&pdev->codec0_tasklet, codec0_tasklet_func, (unsigned long)pdev);
    tasklet_init(&pdev->codec1_tasklet, codec1_tasklet_func, (unsigned long)pdev);
    tasklet_init(&pdev->codec2_tasklet, codec2_tasklet_func, (unsigned long)pdev);
    tasklet_init(&pdev->codec3_tasklet, codec3_tasklet_func, (unsigned long)pdev);
    tasklet_init(&pdev->jpeg0_tasklet, jpeg0_tasklet_func, (unsigned long)pdev);
    tasklet_init(&pdev->jpeg1_tasklet, jpeg1_tasklet_func, (unsigned long)pdev);
    tasklet_init(&pdev->jpeg2_tasklet, jpeg2_tasklet_func, (unsigned long)pdev);
    tasklet_init(&pdev->jpeg3_tasklet, jpeg3_tasklet_func, (unsigned long)pdev);
#endif /*  END SUPPORT_MULTI_INST_INTR */

    rc = pci_msi_vec_count(pcidev);
    DEV_DEBUG(pdev, "No of irqs %d\n",rc);
    if (bmisonly)
        rc = pci_alloc_irq_vectors(pcidev, 1, irq_num, PCI_IRQ_MSI);
    else
        rc = pci_alloc_irq_vectors(pcidev, 1, irq_num, PCI_IRQ_MSI | PCI_IRQ_MSIX);
    if (rc < 0) {
        DEV_DEBUG(pdev, "Could not enable interrupt\n");
        rc = -EPERM;
        goto isr_err_out;
    }

    pdev->no_of_msi = rc;
    if (pdev->no_of_msi != irq_num) {
        DEV_WARN(pdev, "Request %d interrupts, got %d interrupts only\n", irq_num, rc);
    }
    DEV_INFO(pdev, "Enable %d interrupts with %d CPU cores\n", rc, cpu_count);

    pdev->irq = pci_irq_vector(pcidev, 0);
    if (bmisonly)
        pdev->RPP_ext.DmaRsc.Irq = pdev->irq;

    for (i = 0; i < pdev->no_of_msi; i++)  /*  ????  can do like many  R8 cards ? */
    {
        irq = pci_irq_vector(pcidev, i);
        if (irq < 0) {
            DEV_ERROR(pdev, "invalid IRQ #%d for pci msi %d, exit isr initial\n", irq, i);
            rc = irq;
            goto isr_request_irq_err_out;
        }
#ifdef SUPPORT_ISR_ITSELF
        DEV_DEBUG(pdev, "msi int No[%d] IRQ #%d, irq affinity check\n", i, irq);
        irq_offset = irq - pdev->irq;
        cpumask_clear(&mask);
        switch(irq_offset) {
            case RPP_CODEC_INT0:
            case RPP_CODEC_INT1:
                cpu_index = (irq_offset - RPP_JPEG_INT1) % cpu_count;
                goto irq_affinity;
            case RPP_JPEG_INT0:
            case RPP_JPEG_INT1:
                cpu_index = (irq_offset - RPP_SCH_INT) % cpu_count;
                goto irq_affinity;
            case RPP_CODEC_INT2:
            case RPP_CODEC_INT3:
                cpu_index = (irq_offset - RPP_CODEC_INT1) % cpu_count;
                goto irq_affinity;
            case RPP_JPEG_INT2:
            case RPP_JPEG_INT3:
                cpu_index = (irq_offset - RPP_JPEG_INT1) % cpu_count;
irq_affinity:
                cpumask_set_cpu(cpu_index, &mask);
                err = irq_set_affinity_hint(irq, &mask);
                if (err) {
                    DEV_ERROR(pdev, "VE %d failed to set IRQ #%d affinity on CPU %d\n",(irq_offset-2), irq, cpu_index);
                }
                else{
                    DEV_DEBUG(pdev, "VE %d success set IRQ #%d affinity on CPU %d\n", (irq_offset-2), irq, cpu_index);
                }
                break;
            case RPP_PCIE_DMA_INT:
            case RPP_SCH_INT:
            case RPP_MPU_NORMAL_INT0:
            /*consider cpu affinity setting or not*/
                break;
            default:
                break;
        }
        rc = devm_request_irq(dev, irq, isr_table[irq_offset].msi_isr, IRQF_TRIGGER_HIGH, isr_table[irq_offset].isr_dev, (void *)pdev);
#else
        rc = devm_request_irq(dev, irq, msi_isr, IRQF_TRIGGER_HIGH, DRVER_NAME, (void *)pdev);
#endif /*  SUPPORT_ISR_ITSELF */
        if (rc) {
            DEV_ERROR(pdev, "IRQ #%d, error %d\n", irq, rc);
            goto isr_request_irq_err_out;
        }
    }

    get_cached_msi_msg(pdev->irq, &msg);

    if (pdev->small_bar) {
        RPP_rw_pci_bar(pdev, 4, 1, 4, 0x54, (UCHAR *)&msg.address_lo);
        RPP_rw_pci_bar(pdev, 4, 1, 4, 0x58, (UCHAR *)&msg.address_hi);
        RPP_rw_pci_bar(pdev, 4, 1, 4, 0x5c, (UCHAR *)&msg.data);
    } else {
        RPP_rw_pci_bar(pdev, 2, 1, 4, 0x7000054, (UCHAR *)&msg.address_lo);
        RPP_rw_pci_bar(pdev, 2, 1, 4, 0x7000058, (UCHAR *)&msg.address_hi);
        RPP_rw_pci_bar(pdev, 2, 1, 4, 0x700005c, (UCHAR *)&msg.data);
    }

#ifdef VPU_HAL_MPU
    if(bmisonly) {
        /*maskable the codec and jpeg msi interruput*/
        msi_cap = pci_find_capability(pcidev, PCI_CAP_ID_MSI);
        if (!msi_cap) {
            WARNING_PRINT("RPP can't find MSI Capability\n");
            goto irq_mask_end;
        }

        pci_read_config_word(pcidev, msi_cap + PCI_MSI_FLAGS, &msg_ctrl);
        if (!(msg_ctrl & PCI_MSI_FLAGS_MASKBIT)) {
            WARNING_PRINT("RPP doesn't support Pre-vector Masking\n");
            goto irq_mask_end;
        }

        if (msg_ctrl & PCI_MSI_FLAGS_64BIT) {
            pci_read_config_dword(pcidev, msi_cap+PCI_MSI_MASK_64, &mask_val);
            DEV_DEBUG(pdev, "before RPP ve interrupt mask64 val %08x\n", mask_val);
            mask_val |= 0x330;  /*codec only*/
            /* mask_val |= 0x0CC;  jpeg only */
            /* mask_val |= 0x3FC;  codec and jpeg */
            pci_write_config_dword(pcidev, msi_cap+PCI_MSI_MASK_64, mask_val);
            DEV_DEBUG(pdev, "after RPP ve interrupt mask64 val %08x\n", mask_val);
        } else {
            pci_read_config_dword(pcidev, msi_cap+PCI_MSI_MASK_32, &mask_val);
            DEV_DEBUG(pdev, "before RPP ve interrupt mask32 val %08x\n", mask_val);
            mask_val |= 0x330;  /*codec only*/
            /* mask_val |= 0x0CC;  jpeg only */
            /* mask_val |= 0x3FC;  codec and jpeg */
            pci_write_config_dword(pcidev, msi_cap+PCI_MSI_MASK_32, mask_val);
            DEV_DEBUG(pdev, "after RPP ve interrupt mask32 val %08x\n", mask_val);
        }
    }
irq_mask_end:
#endif

    return 0;

isr_request_irq_err_out:
    j = i;
    for (i = 0; i < j; i++)
    {
#ifdef SUPPORT_ISR_ITSELF
        irq_set_affinity_hint(pci_irq_vector(pcidev, i), NULL);
#endif
        devm_free_irq(dev, pci_irq_vector(pcidev, i), (void *)pdev);
    }
    pci_free_irq_vectors(pcidev);

isr_err_out:
    return rc;
}


void rpp_isr_exit(struct rpp_dev *pdev)
{
    int i = 0;
    int irq = 0;
    struct pci_dev *pcidev = pdev->pdev;
    struct device *dev = &pcidev->dev;

    for (i = 0; i < pdev->no_of_msi; i++)
    {
        irq = pci_irq_vector(pcidev, i);
        if (irq != 0) {
#ifdef SUPPORT_ISR_ITSELF
            irq_set_affinity_hint(irq, NULL);
#endif
            devm_free_irq(dev, irq, (void *)pdev);
        }
    }

    pci_free_irq_vectors(pcidev);

    kfifo_free(&pdev->isr_kfifo);

    pdev->no_of_msi = 0;
}
