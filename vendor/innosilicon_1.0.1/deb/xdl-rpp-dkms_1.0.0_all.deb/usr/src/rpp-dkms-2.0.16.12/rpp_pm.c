#include <linux/delay.h>
#include <linux/jiffies.h>
#include <linux/moduleparam.h>
#include <linux/msi.h>
#include <linux/pci.h>

#include "include/rpp_debug.h"
#include "include/rpp_dev.h"
#include "include/rpp_hal_dma.h"
#include "include/rpp_pm.h"

#ifndef RPP_IDLE_LOW_POWER_ENABLE
#define RPP_IDLE_LOW_POWER_ENABLE 0
#endif

static int pcie_link_wait_timeout_ms = 5000;
module_param(pcie_link_wait_timeout_ms, int, 0644);
MODULE_PARM_DESC(pcie_link_wait_timeout_ms, "Maximum wait time for PCIe link/config readiness during device online\n");

static int pcie_link_poll_interval_ms = 50;
module_param(pcie_link_poll_interval_ms, int, 0644);
MODULE_PARM_DESC(pcie_link_poll_interval_ms, "Polling interval for PCIe link/config readiness during device online\n");

/*
 * The blocking DMA ioctl uses a 30s transfer timeout. PM prepare must wait
 * longer than that so a bad in-flight transfer can unwind before S3 proceeds.
 */
static int rpp_pm_ioctl_wait_timeout_ms = 35000;
module_param(rpp_pm_ioctl_wait_timeout_ms, int, 0644);
MODULE_PARM_DESC(rpp_pm_ioctl_wait_timeout_ms, "Maximum wait time for active ioctl to finish in PM notifier\n");

int rpp_pm_poll_pcie_link(struct rpp_dev *pdev)
{
	uint32_t temp = 0;
	int wait_ms = 0;
	int poll_ms = (pcie_link_poll_interval_ms > 0) ?
		pcie_link_poll_interval_ms : 50;

	do {
		if (pdev->small_bar)
			RPP_rw_pci_bar(pdev, 4, 0, 4, PCIE_STATUS_REG_SMALL_BAR,
				(UCHAR *)&temp);
		else
			RPP_rw_pci_bar(pdev, 2, 0, 4, PCIE_STATUS_REG_LARGE_BAR,
				(UCHAR *)&temp);

		if (((temp & PCIE_LINK_STATUS_MASK) != 0x0) &&
		    (temp != PCIE_LINK_STATUS_INVALID))
			break;
		if (wait_ms >= pcie_link_wait_timeout_ms)
			break;

		msleep(poll_ms);
		wait_ms += poll_ms;
	} while (1);

	DEV_INFO(pdev, "poll_pcie_link: status=0x%x after %dms\n",
		temp, wait_ms);

	if (((temp & PCIE_LINK_STATUS_MASK) == 0x0) ||
	    (temp == PCIE_LINK_STATUS_INVALID)) {
		DEV_ERROR(pdev, "poll_pcie_link: link failed (0x%x) after %dms\n",
			temp, wait_ms);
		return -EIO;
	}

	return 0;
}

int rpp_pm_wait_config_ready(struct rpp_dev *pdev)
{
	uint32_t vendor_id = 0xffffffff;
	int wait_ms = 0;
	int poll_ms = (pcie_link_poll_interval_ms > 0) ?
		pcie_link_poll_interval_ms : 50;

	do {
		RPP_rw_pci_cfg(pdev->pdev, 0, 4, PCI_VENDOR_ID,
			(UCHAR *)&vendor_id);
		if (vendor_id != 0xffffffff && (vendor_id & 0xffff) != 0xffff)
			break;
		if (wait_ms >= pcie_link_wait_timeout_ms)
			break;

		msleep(poll_ms);
		wait_ms += poll_ms;
	} while (1);

	DEV_INFO(pdev, "pm: config ready after %dms, vendor=0x%x\n",
		wait_ms, vendor_id);

	if (vendor_id == 0xffffffff || (vendor_id & 0xffff) == 0xffff) {
		DEV_ERROR(pdev, "pm: config space not ready after %dms\n",
			wait_ms);
		return -ENODEV;
	}

	return 0;
}

bool rpp_pm_need_restore_cfg(struct rpp_dev *pdev)
{
	uint32_t temp = 0xffffffff;

	RPP_rw_pci_cfg(pdev->pdev, 0, 4, 0x04, (UCHAR *)&temp);
	if (((temp & PCIE_LINK_STATUS_MASK) == 0x0) ||
	    (temp == PCIE_LINK_STATUS_INVALID)) {
		DEV_INFO(pdev, "pm: cfg 0x04 value 0x%x, need restore RTD3 cfg\n",
			temp);
		return true;
	}

	return false;
}

static void rpp_pm_store_restore_cfg(struct rpp_dev *pdev, bool store)
{
	uint32_t temp = 0;
	uint32_t i = 0;

	if (store) {
		for (i = 0; i < RTD3_CFG_NUM_MAX; i++) {
			RPP_rw_pci_cfg(pdev->pdev, 0, 4, pdev->rtd3_regs[i].addr,
					(UCHAR *)&pdev->rtd3_regs[i].value);
		}
		return;
	}

	for (i = 0; i < 7; i++) {
		RPP_rw_pci_cfg(pdev->pdev, 1, 4, pdev->rtd3_regs[i].addr,
				(UCHAR *)&pdev->rtd3_regs[i].value);
	}

	/* 0x3c */
	temp = pdev->rtd3_regs[i].value & 0x000000ff;
	RPP_rw_pci_cfg(pdev->pdev, 1, 1, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);
	i++;

	/* 0x0c */
	temp = pdev->rtd3_regs[i].value & 0x0000ffff;
	RPP_rw_pci_cfg(pdev->pdev, 1, 2, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);
	i++;

	/* 0x04 */
	temp = pdev->rtd3_regs[i].value & 0x0000ff00;
	RPP_rw_pci_cfg(pdev->pdev, 1, 2, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);
	i++;

	/* 0x78 */
	temp = pdev->rtd3_regs[i].value & 0x0000ffff;
	RPP_rw_pci_cfg(pdev->pdev, 1, 2, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);
	i++;

	/* 0x80 */
	temp = pdev->rtd3_regs[i].value & 0x0000ffff;
	RPP_rw_pci_cfg(pdev->pdev, 1, 2, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);
	i++;

	/* 0xa0 */
	temp = pdev->rtd3_regs[i].value & 0x0000ffff;
	RPP_rw_pci_cfg(pdev->pdev, 1, 2, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);
	i++;

	/* 0x98 */
	temp = pdev->rtd3_regs[i].value & 0x0000ffff;
	RPP_rw_pci_cfg(pdev->pdev, 1, 2, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);

	/* 0x04 */
	i = 9;
	RPP_rw_pci_cfg(pdev->pdev, 0, 2, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);
	temp = pdev->rtd3_regs[i].value & 0x0000ffff;
	RPP_rw_pci_cfg(pdev->pdev, 1, 2, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);

	temp = 0xf9000000 | (pdev->rtd3_regs[i].value & 0x0000ffff);
	RPP_rw_pci_cfg(pdev->pdev, 1, 4, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);

	RPP_rw_pci_cfg(pdev->pdev, 0, 2, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);
	temp = pdev->rtd3_regs[i].value & 0x0000ffff;
	RPP_rw_pci_cfg(pdev->pdev, 1, 2, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);

	/* 0x50 */
	i = 14;
	RPP_rw_pci_cfg(pdev->pdev, 0, 4, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);
	temp = 0x018a0000 | (pdev->rtd3_regs[i].value & 0x0000ffff);
	RPP_rw_pci_cfg(pdev->pdev, 1, 4, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);
	RPP_rw_pci_cfg(pdev->pdev, 0, 4, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);
	i++;

	/* 0x54 */
	temp = pdev->rtd3_regs[i].value;
	RPP_rw_pci_cfg(pdev->pdev, 1, 4, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);
	i++;

	/* 0x58 */
	temp = pdev->rtd3_regs[i].value;
	RPP_rw_pci_cfg(pdev->pdev, 1, 4, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);
	i++;

	/* 0x5c */
	temp = pdev->rtd3_regs[i].value & 0x0000ffff;
	RPP_rw_pci_cfg(pdev->pdev, 1, 2, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);
	i++;

	/* 0x60 */
	temp = pdev->rtd3_regs[i].value;
	RPP_rw_pci_cfg(pdev->pdev, 1, 2, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);

	/* 0x50 */
	i = 14;
	temp = pdev->rtd3_regs[i].value;
	RPP_rw_pci_cfg(pdev->pdev, 1, 4, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);

	/* 0x80 */
	i = 19;
	temp = pdev->rtd3_regs[i].value & 0x0000ffff;
	RPP_rw_pci_cfg(pdev->pdev, 1, 2, pdev->rtd3_regs[i].addr, (UCHAR *)&temp);
}

void rpp_pm_restore_cfg(struct rpp_dev *pdev)
{
	uint32_t before[RTD3_CFG_NUM_MAX];
	uint32_t after = 0;
	int i;

	DEV_INFO(pdev, "pm: restore RTD3 cfg\n");

	for (i = 0; i < RTD3_CFG_NUM_MAX; i++)
		RPP_rw_pci_cfg(pdev->pdev, 0, 4, pdev->rtd3_regs[i].addr,
			(UCHAR *)&before[i]);

	rpp_pm_store_restore_cfg(pdev, false);

	for (i = 0; i < RTD3_CFG_NUM_MAX; i++) {
		RPP_rw_pci_cfg(pdev->pdev, 0, 4, pdev->rtd3_regs[i].addr,
			(UCHAR *)&after);
		DEV_INFO(pdev,
			"pm: cfg[%02d] off=0x%02x saved=0x%08x before=0x%08x after=0x%08x\n",
			i, pdev->rtd3_regs[i].addr, pdev->rtd3_regs[i].value,
			before[i], after);
	}
}

int rpp_pm_store_cfg(struct rpp_dev *pdev)
{
	int i;

	if (rpp_pm_need_restore_cfg(pdev)) {
		DEV_WARN(pdev, "pm: cfg needs restore before RTD3 cfg save\n");
		rpp_pm_restore_cfg(pdev);
		if (rpp_pm_need_restore_cfg(pdev)) {
			DEV_ERROR(pdev, "pm: cfg still invalid after restore, skip RTD3 cfg save\n");
			return -EIO;
		}
	}

	rpp_pm_store_restore_cfg(pdev, true);
	DEV_INFO(pdev, "pm: RTD3 cfg saved\n");
	for (i = 0; i < RTD3_CFG_NUM_MAX; i++)
		DEV_INFO(pdev, "pm: store cfg[%02d] off=0x%02x value=0x%08x\n",
			i, pdev->rtd3_regs[i].addr, pdev->rtd3_regs[i].value);

	return 0;
}

void rpp_pm_log_cfg_state(struct rpp_dev *pdev, const char *stage)
{
	uint32_t vendor = 0xffffffff;
	uint32_t command = 0xffffffff;

	RPP_rw_pci_cfg(pdev->pdev, 0, 4, PCI_VENDOR_ID, (UCHAR *)&vendor);
	RPP_rw_pci_cfg(pdev->pdev, 0, 4, 0x04, (UCHAR *)&command);
	DEV_INFO(pdev, "pm: %s cfg vendor=0x%08x command=0x%08x status=0x%x suspending=%d notifier_offline=%d\n",
		stage, vendor, command, READ_ONCE(pdev->status),
		READ_ONCE(pdev->pm_suspending) ? 1 : 0,
		READ_ONCE(pdev->pm_notifier_offline) ? 1 : 0);
}

int rpp_pm_wait_active_ioctl(struct rpp_dev *pdev)
{
	const int poll_ms = 10;
	int waited_ms = 0;
	int rc;

	do {
		rc = down_timeout(&pdev->sem, msecs_to_jiffies(poll_ms));
		if (rc == 0)
			return 0;

		waited_ms += poll_ms;
		rpp_pm_log_cfg_state(pdev, "notifier wait ioctl timeout poll");
		if (rpp_pm_need_restore_cfg(pdev) &&
		    READ_ONCE(pdev->dma_xfer_active) &&
		    !READ_ONCE(pdev->pm_abort_xfer)) {
			WRITE_ONCE(pdev->pm_abort_xfer, true);
			DEV_WARN(pdev,
				"pm: notifier completes active DMA xfer after cfg/link event\n");
			complete(&pdev->xfer_done);
		}
	} while (waited_ms < rpp_pm_ioctl_wait_timeout_ms);

	DEV_ERROR(pdev,
		"pm: notifier timed out waiting active ioctl, timeout=%dms rc=%d\n",
		rpp_pm_ioctl_wait_timeout_ms, rc);
	return rc;
}

void rpp_pm_restore_atu(struct rpp_dev *pdev)
{
	uint32_t temp;

	if (!pdev)
		return;

	if (pdev->small_bar) {
		temp = 0x0;
		RPP_rw_pci_bar(pdev, 4, 1, 4, 0x300114, (UCHAR *)&temp);
		RPP_rw_pci_bar(pdev, 4, 1, 4, 0x300118, (UCHAR *)&temp);
		RPP_rw_pci_bar(pdev, 4, 1, 4, 0x300100, (UCHAR *)&temp);
		temp = 0xc0000000;
		RPP_rw_pci_bar(pdev, 4, 1, 4, 0x300104, (UCHAR *)&temp);
	} else {
		temp = 0x0;
		RPP_rw_pci_bar(pdev, 2, 1, 4, 0x7300114, (UCHAR *)&temp);
		RPP_rw_pci_bar(pdev, 2, 1, 4, 0x7300118, (UCHAR *)&temp);
		RPP_rw_pci_bar(pdev, 2, 1, 4, 0x7300100, (UCHAR *)&temp);
		temp = 0xc0000000;
		RPP_rw_pci_bar(pdev, 2, 1, 4, 0x7300104, (UCHAR *)&temp);
	}
}

static void rpp_pm_restore_msi_phy_regs(struct rpp_dev *pdev)
{
	struct msi_msg msg;
	uint32_t temp;

	/* Restore the PCIe PHY workaround registers programmed during probe. */
	temp = 0xa7000;
	if (pdev->small_bar) {
		RPP_rw_pci_bar(pdev, 2, 1, 4, 0xa1034, (UCHAR *)&temp);
		temp = 0xc9244c92;
		RPP_rw_pci_bar(pdev, 2, 1, 4, 0xa0028, (UCHAR *)&temp);
		RPP_rw_pci_bar(pdev, 2, 1, 4, 0xa4028, (UCHAR *)&temp);
		RPP_rw_pci_bar(pdev, 2, 1, 4, 0xa8028, (UCHAR *)&temp);
		RPP_rw_pci_bar(pdev, 2, 1, 4, 0xac028, (UCHAR *)&temp);
	} else {
		RPP_rw_pci_bar(pdev, 2, 1, 4, 0x20a1034, (UCHAR *)&temp);
		temp = 0xc9244c92;
		RPP_rw_pci_bar(pdev, 2, 1, 4, 0x20a0028, (UCHAR *)&temp);
		RPP_rw_pci_bar(pdev, 2, 1, 4, 0x20a4028, (UCHAR *)&temp);
		RPP_rw_pci_bar(pdev, 2, 1, 4, 0x20a8028, (UCHAR *)&temp);
		RPP_rw_pci_bar(pdev, 2, 1, 4, 0x20ac028, (UCHAR *)&temp);
	}

	/* Restore the endpoint MSI target registers from Linux's cached message. */
	get_cached_msi_msg(pdev->irq, &msg);
	if (pdev->small_bar) {
		RPP_rw_pci_bar(pdev, 4, 1, 4, 0x54, (UCHAR *)&msg.address_lo);
		RPP_rw_pci_bar(pdev, 4, 1, 4, 0x58, (UCHAR *)&msg.address_hi);
		RPP_rw_pci_bar(pdev, 4, 1, 4, 0x5c, (UCHAR *)&msg.data);
	} else {
		RPP_rw_pci_bar(pdev, 2, 1, 4, 0x7000054, (UCHAR *)&msg.address_lo);
		RPP_rw_pci_bar(pdev, 2, 1, 4, 0x7000058, (UCHAR *)&msg.address_hi);
		RPP_rw_pci_bar(pdev, 2, 1, 4, 0x700005c, (UCHAR *)&msg.data);
	}
}

int rpp_pm_restore_pcie_internal_state(struct rpp_dev *pdev)
{
	uint32_t temp;

	if (!pdev || !pdev->pdev)
		return -ENODEV;

	/* Restore the same PCIe internal state initialized during probe. */
	RPP_rw_pci_cfg(pdev->pdev, 0, 4, 0x7c, (UCHAR *)&temp);
	rpp_genx_speed_change(pdev, (uint8_t)(temp & 0xf));
	rpp_pm_restore_atu(pdev);
	rpp_pm_restore_msi_phy_regs(pdev);

	DEV_INFO(pdev, "pm: PCIe speed/PHY/ATU/MSI internal state restored\n");
	return 0;
}

int rpp_pm_reinit_dma(struct rpp_dev *pdev, const char *context)
{
	struct msi_msg msg;

	if (!pdev || !pdev->pdev)
		return -ENODEV;

	if (!rpp_edma_enabled())
		return 0;

	if (pdev->pdev->msi_enabled)
		DEV_DEBUG(pdev, "IRQ MSI selected\n");
	else if (pdev->pdev->msix_enabled)
		DEV_DEBUG(pdev, "IRQ MSI-X selected\n");

	get_cached_msi_msg(pdev->irq, &msg);
	pdev->RPP_ext.DmaRsc.MsiAddr.HighPart = msg.address_hi;
	pdev->RPP_ext.DmaRsc.MsiAddr.LowPart = msg.address_lo;
	pdev->RPP_ext.DmaRsc.MsiData =
		(rpp_irq_num() < 32) ? msg.data : msg.data + 22;

	if (HalDmaInit(&pdev->RPP_ext.DmaRsc) != DMA_SUCCESS) {
		DEV_ERROR(pdev, "%s: HalDmaInit failed\n",
			context ? context : "pm_reinit_dma");
		return -EIO;
	}

	DEV_INFO(pdev, "%s: DMA init ok (msi hi=0x%x lo=0x%x data=0x%x)\n",
		context ? context : "pm_reinit_dma",
		pdev->RPP_ext.DmaRsc.MsiAddr.HighPart,
		pdev->RPP_ext.DmaRsc.MsiAddr.LowPart,
		pdev->RPP_ext.DmaRsc.MsiData);
	return 0;
}

static int rpp_idle_low_power_exit(struct rpp_dev *pdev, const char *reason)
{
	int rc;

	if (!pdev->idle_low_power_suspended)
		return 0;

	DEV_TRACE(pdev,
		"exit begin reason=%s refs=%d pwr_user=0x%x wrk_user=0x%x\n",
		reason ? reason : "unknown",
		atomic_read(&pdev->idle_low_power_refs),
		pdev->hw_state.pwr_user_state,
		pdev->hw_state.wrk_user_state);

	rc = rpp_set_power_mode(pdev, pdev->hw_state.pwr_user_state);
	if (rc != 0) {
		DEV_WARN(pdev,
			"idle_low_power_get restore power failed reason=%s mode=0x%x rc=%d\n",
			reason ? reason : "unknown",
			pdev->hw_state.pwr_user_state, rc);
		return rc;
	}

	pdev->idle_low_power_suspended = false;
	DEV_TRACE(pdev,
		"exit end reason=%s refs=%d pwr_state=0x%x wrk_state=0x%x\n",
		reason ? reason : "unknown",
		atomic_read(&pdev->idle_low_power_refs),
		pdev->hw_state.pwr_state,
		pdev->hw_state.wrk_state);
	// DEV_INFO(pdev, "idle_low_power exit done: dev_idx=%d\n", pdev->idx);
	return 0;
}

static int rpp_idle_low_power_enter(struct rpp_dev *pdev, const char *reason)
{
	int rc;

	if (atomic_read(&pdev->idle_low_power_refs) > 0)
		return 0;

	if (pdev->idle_low_power_suspended) {
		DEV_TRACE(pdev,
			"enter skipped already in idle_low_power reason=%s status=0x%x\n",
			reason ? reason : "unknown", READ_ONCE(pdev->status));
		return 0;
	}

	if (READ_ONCE(pdev->pm_suspending) ||
	    READ_ONCE(pdev->status) != RPP_PCIE_ONLINE) {
		DEV_TRACE(pdev,
			"enter skipped reason=%s refs=%d status=0x%x suspending=%d\n",
			reason ? reason : "unknown",
			atomic_read(&pdev->idle_low_power_refs),
			READ_ONCE(pdev->status),
			READ_ONCE(pdev->pm_suspending) ? 1 : 0);
		DEV_INFO(pdev,
			"idle_low_power enter skipped during system PM/offline: status=0x%x suspending=%d\n",
			READ_ONCE(pdev->status),
			READ_ONCE(pdev->pm_suspending) ? 1 : 0);
		return -EBUSY;
	}

	DEV_TRACE(pdev,
		"enter begin reason=%s refs=%d pwr_state=0x%x wrk_state=0x%x\n",
		reason ? reason : "unknown",
		atomic_read(&pdev->idle_low_power_refs),
		pdev->hw_state.pwr_state,
		pdev->hw_state.wrk_state);

	rc = rpp_set_power_mode(pdev, RPP_PWRMODE_LOW_POWER);
	if (rc != 0) {
		DEV_WARN(pdev, "idle_low_power enter failed reason=%s rc=%d\n",
			reason ? reason : "unknown", rc);
		return rc;
	}

	pdev->idle_low_power_suspended = true;
	DEV_TRACE(pdev,
		"enter end reason=%s refs=%d pwr_state=0x%x\n",
		reason ? reason : "unknown",
		atomic_read(&pdev->idle_low_power_refs),
		pdev->hw_state.pwr_state);
	// DEV_INFO(pdev, "idle_low_power enter done: dev_idx=%d\n", pdev->idx);
	return 0;
}

int rpp_idle_low_power_get(struct rpp_dev *pdev, const char *reason)
{
	int rc;

	if (!pdev || !RPP_IDLE_LOW_POWER_ENABLE)
		return 0;

	DEV_TRACE(pdev,
		"get enter reason=%s refs=%d suspended=%d status=0x%x\n",
		reason ? reason : "unknown",
		atomic_read(&pdev->idle_low_power_refs),
		pdev->idle_low_power_suspended,
		READ_ONCE(pdev->status));

	atomic_inc(&pdev->idle_low_power_refs);

	mutex_lock(&pdev->idle_low_power_lock);
	rc = rpp_idle_low_power_exit(pdev, reason);
	if (rc != 0)
		atomic_dec(&pdev->idle_low_power_refs);
	mutex_unlock(&pdev->idle_low_power_lock);
	if (rc != 0)
		return rc;

	DEV_TRACE(pdev,
		"get exit reason=%s refs=%d suspended=%d status=0x%x\n",
		reason ? reason : "unknown",
		atomic_read(&pdev->idle_low_power_refs),
		pdev->idle_low_power_suspended,
		READ_ONCE(pdev->status));

	return 0;
}

int rpp_idle_low_power_put(struct rpp_dev *pdev, const char *reason)
{
	int rc = 0;

	if (!pdev || !RPP_IDLE_LOW_POWER_ENABLE)
		return 0;

	DEV_TRACE(pdev,
		"put enter reason=%s refs=%d suspended=%d status=0x%x\n",
		reason ? reason : "unknown",
		atomic_read(&pdev->idle_low_power_refs),
		pdev->idle_low_power_suspended,
		READ_ONCE(pdev->status));

	mutex_lock(&pdev->idle_low_power_lock);
	if (atomic_read(&pdev->idle_low_power_refs) > 0)
		atomic_dec(&pdev->idle_low_power_refs);
	rc = rpp_idle_low_power_enter(pdev, reason);
	mutex_unlock(&pdev->idle_low_power_lock);

	DEV_TRACE(pdev,
		"put exit reason=%s refs=%d suspended=%d status=0x%x rc=%d\n",
		reason ? reason : "unknown",
		atomic_read(&pdev->idle_low_power_refs),
		pdev->idle_low_power_suspended,
		READ_ONCE(pdev->status), rc);

	return rc;
}

int rpp_idle_low_power_init(struct rpp_dev *pdev)
{
	if (!pdev || !pdev->pdev)
		return -ENODEV;

	atomic_set(&pdev->idle_low_power_refs, 0);
	pdev->idle_low_power_suspended = false;
	pdev->idle_low_power_system_ref = false;
	mutex_init(&pdev->idle_low_power_lock);
	DEV_TRACE(pdev, "idle_low_power init enable=%d\n", RPP_IDLE_LOW_POWER_ENABLE);

	return 0;
}

void rpp_idle_low_power_deinit(struct rpp_dev *pdev)
{
	if (!pdev || !RPP_IDLE_LOW_POWER_ENABLE)
		return;

	mutex_lock(&pdev->idle_low_power_lock);
	DEV_TRACE(pdev,
		"idle_low_power deinit refs=%d suspended=%d status=0x%x\n",
		atomic_read(&pdev->idle_low_power_refs),
		pdev->idle_low_power_suspended,
		READ_ONCE(pdev->status));
	atomic_set(&pdev->idle_low_power_refs, 0);
	mutex_unlock(&pdev->idle_low_power_lock);
}
