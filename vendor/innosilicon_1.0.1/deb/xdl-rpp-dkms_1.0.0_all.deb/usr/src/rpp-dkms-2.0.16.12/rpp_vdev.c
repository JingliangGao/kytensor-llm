/*
 * This file is part of the Azurengine video engine driver for Linux
 *
 * Copyright (c) 2016-present,  Azurengine, Inc.
 * All rights reserved.
 *
 * This source code is licensed under both the BSD-style license (found in the
 * LICENSE file in the root directory of this source tree) and the GPLv2 (found
 * in the COPYING file in the root directory of this source tree).
 * You may select, at your option, one of the above-listed licenses.
 */

#define pr_fmt(fmt)     KBUILD_MODNAME ":%s: " fmt, __func__



#include <linux/fs.h>
#include <linux/dma-mapping.h>
#include <linux/err.h>

#include "include/rpp_vdev.h"
#include "include/rpp_vdev_ctrl.h"
#include "include/rpp_debug.h"

#define VE_NODE_NAME    "ve"
#define VE_MINOR_BASE   (0)
#define VE_MINOR_COUNT  (255)


struct rpp_vdev_info
{
    struct class *ve_class;

    /* device number info */
    dev_t dev;
    int major;
    int minor_assigned;
    int max_minor_num;
};

int g_rpp_vdev_info_init_flag = 0;
struct rpp_vdev_info  g_rpp_vdev_info;

int rpp_vdev_info_init(void)
{
   int rv = 0;

    /*  already init, return directly. */
    if(g_rpp_vdev_info_init_flag == 1)
         return 0;

#if LINUX_VERSION_CODE < KERNEL_VERSION(6,4,0)
    g_rpp_vdev_info.ve_class = class_create(THIS_MODULE, VE_NODE_NAME);
#else
    g_rpp_vdev_info.ve_class = class_create(VE_NODE_NAME);
#endif
    if (IS_ERR(g_rpp_vdev_info.ve_class)) {
        dbg_init(VE_NODE_NAME ": failed to create vdev class");
        return -1;
    }

    /* allocate a dynamically allocated char device node */
    rv = alloc_chrdev_region(&g_rpp_vdev_info.dev, VE_MINOR_BASE, VE_MINOR_COUNT, VE_NODE_NAME);
    if (rv)
    {
        pr_err("unable to allocate vdev region %d.\n", rv);
        goto class_destroy_err;
    }

    g_rpp_vdev_info.major = MAJOR(g_rpp_vdev_info.dev);
    g_rpp_vdev_info.minor_assigned = 0;
    g_rpp_vdev_info.max_minor_num = VE_MINOR_COUNT;

    g_rpp_vdev_info_init_flag = 1;

    return 0;

class_destroy_err:
    class_destroy(g_rpp_vdev_info.ve_class);
    g_rpp_vdev_info_init_flag = 0;

    return rv;
}


int alloc_vdev_no(dev_t *pdevno)
{
    int rv = 0;
    rv = rpp_vdev_info_init();
    if(rv != 0 )
       return rv;

   if(g_rpp_vdev_info.minor_assigned > g_rpp_vdev_info.max_minor_num)
   {
        pr_err("there is no vdev minor to be allocated\n");
        return -1;
   }

   *pdevno = MKDEV(g_rpp_vdev_info.major, g_rpp_vdev_info.minor_assigned);

    g_rpp_vdev_info.minor_assigned += 1;

    return 0;
}

void rpp_vdev_info_exit(void)
{

    /*  no init , exit directly. */
    if(g_rpp_vdev_info_init_flag == 0)
         return;


    g_rpp_vdev_info_init_flag = 0;

    if (g_rpp_vdev_info.ve_class)
        class_destroy(g_rpp_vdev_info.ve_class);

    if (g_rpp_vdev_info.major)
        unregister_chrdev_region(g_rpp_vdev_info.dev, VE_MINOR_COUNT);

    g_rpp_vdev_info.major =0;
    g_rpp_vdev_info.minor_assigned = 0;
    g_rpp_vdev_info.max_minor_num = 0;

}

enum vdev_type {
    CHAR_ENTIRE_CTRL,
};

static const char * const devnode_names[] = {
    VE_NODE_NAME "%d_entire_ctrl",
};

static inline void xvdev_flag_set(struct rpp_dev *xpdev,
                                    enum xpdev_flags_bits fbit)
{
    xpdev->flags |= 1 << fbit;
}

static inline void xvdev_flag_clear(struct rpp_dev *xpdev,
                                    enum xpdev_flags_bits fbit)
{
	xpdev->flags &= ~(1 << fbit);
}

static inline int xvdev_flag_test(struct rpp_dev *xpdev,
                                    enum xpdev_flags_bits fbit)
{
    return xpdev->flags & (1 << fbit);
}

/*
static int config_kobject(struct rpp_vdev *xvdev)
{
    int rv = -EINVAL;
    struct rpp_dev *xdev = (struct rpp_dev *)(xvdev->prppdev);

    rv = kobject_set_name(&xvdev->cdev.kobj, devnode_names[0], 	xdev->idx);
    if (rv)
        pr_err("%s: , failed %d.\n", __func__, rv);


    pr_err("%s: , xvdev->cdev.kobj.name: %s,  rv: %d.\n", __func__, xvdev->cdev.kobj.name, rv);

    return rv;
}
*/

int xvdev_check(const char *fname, struct rpp_vdev *xvdev, bool check_engine)
{
    struct rpp_dev *xdev;

    if (!xvdev) {
        pr_err("%s, xvdev 0x%p.\n",fname, xvdev);
        return -EINVAL;
    }

    xdev = (struct rpp_dev *)(xvdev->prppdev);
    if (!xdev) {
        pr_err("%s, xdev 0x%p.\n", fname, xdev);
        return -EINVAL;
    }

    return 0;
}

int vchar_open(struct inode *inode, struct file *file)
{
    struct rpp_vdev *xvdev;

    /* pointer to containing structure of the character device inode */
    xvdev = container_of(inode->i_cdev, struct rpp_vdev, vdev);
    /* create a reference to our char device in the opened file */
    file->private_data = xvdev;

    return 0;
}

/*
 * Called when the device goes from used to unused.
 */
int vchar_close(struct inode *inode, struct file *file)
{
    struct rpp_dev *xdev;
    struct rpp_vdev *xvdev = (struct rpp_vdev *)file->private_data;

    BUG_ON(!xvdev);

    /* fetch device specific data stored earlier during open */
    xdev = (struct rpp_dev *)(xvdev->prppdev);
    BUG_ON(!xdev);

    return 0;
}

/* create_xcdev() -- create a character device interface to data or control bus
 *
 * If at least one SG DMA engine is specified, the character device interface
 * is coupled to the SG DMA file operations which operate on the data bus. If
 * no engines are specified, the interface is coupled with the control bus.
 */

static int create_sys_vdevice(struct rpp_vdev *xvdev)
{
    struct rpp_dev *xdev = (struct rpp_dev *)(xvdev->prppdev);
    char name_str[256];

    xvdev->sys_device = device_create(g_rpp_vdev_info.ve_class, &xdev->pdev->dev,
                                    xvdev->vdevno, NULL, devnode_names[0], xdev->idx);
    if (IS_ERR_OR_NULL(xvdev->sys_device)) {
        int rv = xvdev->sys_device ? PTR_ERR(xvdev->sys_device) : -ENODEV;

        pr_err("device_create(%s) failed %d\n", devnode_names[0], rv);
        xvdev->sys_device = NULL;
        return rv;
    }

    /*  pr_info("device_create(%s), index %d success. \n", devnode_names[0], xdev->idx); */
    /*  multi cards swp2539 */
    sprintf(name_str, devnode_names[0], xdev->idx);
    pr_info("device_create(%s), success. \n", name_str);


    return 0;
}

static int destroy_vdev(struct rpp_dev *xpdev, struct rpp_vdev *xvdev)
{
    struct VideoEngine *veEngine;
    struct InterruptManager *veInterrupt;
#ifdef VE_FRAME_BUFFER_CACHE
    int coreIdx;
#endif

    if (!xvdev) {
        pr_warn("vdev NULL.\n");
        return 0;
    }

    if (!xvdev->prppdev)
        pr_warn("destroy_vdev: invalid RPP device pointer\n");

    if (xvdev->veEngine) {
        veEngine = (struct VideoEngine *)xvdev->veEngine;
        if (veEngine->dma) {
            dma_free_coherent(&xpdev->pdev->dev, PAGE_ALIGN(DMA_BUFFER_LENGTH),
                              veEngine->dma, veEngine->dma_handle);
            pr_info("veEngine %p dma buffer free\n", veEngine);
        }
#ifdef VE_FRAME_BUFFER_CACHE
        for (coreIdx = 0; coreIdx < VE_CODEC_NUM; coreIdx++) {
            if (veEngine->dma_user[coreIdx].dma_wuser) {
                dma_free_coherent(&xpdev->pdev->dev, PAGE_ALIGN(WR_USER_DMA_BUFFER_SIZE),
                                  veEngine->dma_user[coreIdx].dma_wuser, veEngine->dma_user[coreIdx].dma_wuser_handle);
                pr_info("veEngine %p wuser[%d] dma buffer free\n", veEngine, coreIdx);
            }
            if (veEngine->dma_user[coreIdx].dma_ruser) {
                dma_free_coherent(&xpdev->pdev->dev, PAGE_ALIGN(WR_USER_DMA_BUFFER_SIZE),
                                  veEngine->dma_user[coreIdx].dma_ruser, veEngine->dma_user[coreIdx].dma_ruser_handle);
                pr_info("veEngine %p ruser[%d] dma buffer free\n", veEngine, coreIdx);
            }
        }
#endif
        rpp_destroy_veEngine(xpdev, veEngine);
        pr_info("veEngine %p destroy suceessful\n", veEngine);
        kfree(veEngine);
        xvdev->veEngine = NULL;
    }

#ifdef SUPPORT_MULTI_INST_INTR
    if (xvdev->veInterrupt) {
        veInterrupt = (struct InterruptManager *)xvdev->veInterrupt;
        rpp_destroy_veInterrupt(xpdev, veInterrupt);
        pr_info("veInterrupt %p destroy suceessful\n", veInterrupt);
        kfree(veInterrupt);
        xvdev->veInterrupt = NULL;
    }
#endif

    if (xvdev->sys_device && g_rpp_vdev_info.ve_class) {
        device_destroy(g_rpp_vdev_info.ve_class, xvdev->vdevno);
        xvdev->sys_device = NULL;
        cdev_del(&xvdev->vdev);
    }

    return 0;
}

static int create_xvdev(struct rpp_dev *xpdev, struct rpp_vdev *xvdev, int bar)
{
    int rv;
    struct VideoEngine *veEngine;
    struct InterruptManager *veInterrupt;
#ifdef VE_FRAME_BUFFER_CACHE
    int coreIdx;
#endif

    dbg_init("create_xvdev enter:  0x%p.\n", xvdev);

    spin_lock_init(&xvdev->lock);
    sema_init(&xvdev->sem, 1);
    mutex_init(&xvdev->vMutex);
    xvdev->nCount = 0;
    xvdev->bInit = 0;
    /*
     * do not register yet, create kobjects and name them,
     */

    xvdev->prppdev = xpdev;
    xvdev->bar = bar;
    xvdev->sys_device = NULL;

    rv = rpp_vdev_info_init();
    if (rv != 0)
        return rv;

    if (xpdev->idx < VE_MINOR_BASE || xpdev->idx >= g_rpp_vdev_info.max_minor_num) {
        pr_err("invalid vdev idx %d, max minor count %d\n",
               xpdev->idx, g_rpp_vdev_info.max_minor_num);
        return -ENOSPC;
    }

    veEngine = (struct VideoEngine *)kzalloc(sizeof(struct VideoEngine), GFP_KERNEL);
    if (veEngine == NULL) {
        pr_err("failed to create veEngine\n");
        return -1;
    }
    xvdev->veEngine = veEngine;

#if defined(__arm__) || defined(__aarch64__)
    veEngine->dma = dma_alloc_attrs(&xpdev->pdev->dev, PAGE_ALIGN(DMA_BUFFER_LENGTH),
                                    (dma_addr_t *)&veEngine->dma_handle, GFP_DMA|GFP_KERNEL, DMA_ATTR_WRITE_COMBINE);
#else
    veEngine->dma = dma_alloc_coherent(&xpdev->pdev->dev, PAGE_ALIGN(DMA_BUFFER_LENGTH),
                                       (dma_addr_t *)&veEngine->dma_handle, GFP_DMA|GFP_KERNEL);
#endif
    if (veEngine->dma == NULL) {
        pr_err("failed to create ve dma buffer\n");
        return -1;
    }
    pr_info("veEngine dma buffer allocte at virt_addr:%llx phys_addr:%llx\n", veEngine->dma, veEngine->dma_handle);

#ifdef VE_FRAME_BUFFER_CACHE
    for (coreIdx = 0; coreIdx < VE_CODEC_NUM; coreIdx++) {
  #if defined(__arm__) || defined(__aarch64__)
          veEngine->dma_user[coreIdx].dma_wuser = dma_alloc_attrs(&xpdev->pdev->dev, PAGE_ALIGN(WR_USER_DMA_BUFFER_SIZE),
                                                                  (dma_addr_t *)&veEngine->dma_user[coreIdx].dma_wuser_handle,
                                                                  GFP_DMA|GFP_KERNEL, DMA_ATTR_WRITE_COMBINE);
          if (veEngine->dma_user[coreIdx].dma_wuser == NULL) {
              pr_err("failed to allocate ve dma_wuser[%d] buffer\n", coreIdx);
              return -1;
          }
          pr_info("veEngine dma_wuser[%d] buffer allocte at virt_addr:%llx phys_addr:%llx\n", coreIdx,
                   veEngine->dma_user[coreIdx].dma_wuser, veEngine->dma_user[coreIdx].dma_wuser_handle);

          veEngine->dma_user[coreIdx].dma_ruser = dma_alloc_attrs(&xpdev->pdev->dev, PAGE_ALIGN(WR_USER_DMA_BUFFER_SIZE),
                                                                  (dma_addr_t *)&veEngine->dma_user[coreIdx].dma_ruser_handle,
                                                                  GFP_DMA|GFP_KERNEL, DMA_ATTR_WRITE_COMBINE);
          if (veEngine->dma_user[coreIdx].dma_ruser == NULL) {
              pr_err("failed to create ve dma_ruser[%d] buffer\n", coreIdx);
              return -1;
          }
          pr_info("veEngine dma_ruser[%d] buffer allocte at virt_addr:%llx phys_addr:%llx\n", coreIdx,
                   veEngine->dma_user[coreIdx].dma_ruser, veEngine->dma_user[coreIdx].dma_ruser_handle);
  #else
        veEngine->dma_user[coreIdx].dma_wuser = dma_alloc_coherent(&xpdev->pdev->dev, PAGE_ALIGN(WR_USER_DMA_BUFFER_SIZE),
                                                                   (dma_addr_t *)&veEngine->dma_user[coreIdx].dma_wuser_handle, GFP_DMA|GFP_KERNEL);
        if (veEngine->dma_user[coreIdx].dma_wuser == NULL) {
            pr_err("failed to allocate ve dma_wuser[%d] buffer\n", coreIdx);
            return -1;
        }
        pr_info("veEngine dma_wuser[%d] buffer allocte at virt_addr:%llx phys_addr:%llx\n", coreIdx,
                 veEngine->dma_user[coreIdx].dma_wuser, veEngine->dma_user[coreIdx].dma_wuser_handle);

        veEngine->dma_user[coreIdx].dma_ruser = dma_alloc_coherent(&xpdev->pdev->dev, PAGE_ALIGN(WR_USER_DMA_BUFFER_SIZE),
                                                                   (dma_addr_t *)&veEngine->dma_user[coreIdx].dma_ruser_handle, GFP_DMA|GFP_KERNEL);
        if (veEngine->dma_user[coreIdx].dma_ruser == NULL) {
            pr_err("failed to create ve dma_ruser[%d] buffer\n", coreIdx);
            return -1;
        }
        pr_info("veEngine dma_ruser[%d] buffer allocte at virt_addr:%llx phys_addr:%llx\n", coreIdx,
                 veEngine->dma_user[coreIdx].dma_ruser, veEngine->dma_user[coreIdx].dma_ruser_handle);
  #endif
    }
#endif

#ifdef VE_DMA_LL_BUFFER
    /* implement, update the dma ll element buffer base with ve dma channel
     * Notice, the ll element buffer should iomapped to system memory space,
     * otherwise can't enable dma link list mode
    */
#endif
    rv = rpp_init_veEngine(xpdev, veEngine);
    if(rv < 0) {
        pr_err("veEngine inital failed %d.\n", rv);
        return rv;
    }
    pr_info("veEngine %p initlal suceessful\n", veEngine);

#ifdef SUPPORT_MULTI_INST_INTR
    veInterrupt = (struct InterruptManager *)kzalloc(sizeof(struct InterruptManager), GFP_KERNEL);
    if (veInterrupt == NULL) {
        pr_err("failed to create veInterrupt\n");
        return -1;
    }
    xvdev->veInterrupt = veInterrupt;

    rv = rpp_init_veInterrupt(xpdev, veInterrupt);
    if(rv < 0) {
        pr_err("veInterrupt inital failed %d.\n", rv);
        return rv;
    }
    pr_info("veInterrupt %p initlal suceessful\n", veInterrupt);
#endif

    vdev_entire_ctrl_init(xvdev);
    xvdev->vdev.owner = THIS_MODULE;

    xvdev->vdevno = MKDEV(g_rpp_vdev_info.major, xpdev->idx);

    /* bring character device live */
    rv = cdev_add(&xvdev->vdev, xvdev->vdevno, 1);
    if (rv < 0) {
        pr_err("vdev_add failed %d.\n", rv);
        return rv;
    }

    /* create device on our class */
    rv = create_sys_vdevice(xvdev);
    if (rv < 0)
        goto del_vdev;

    dbg_init("create_xvdev sucess: 0x%p.\n", xvdev);

    return 0;

del_vdev:
    cdev_del(&xvdev->vdev);

    return rv;
}

static void xpdev_destroy_interfaces(struct rpp_dev * pdev)
{
    /* remove user character device */
    destroy_vdev(pdev, &pdev->entire_ctrl_vdev);
}

static int xpdev_create_interfaces(struct rpp_dev * pdev)
{
    int rv = 0;

    /* entire control */
    rv = create_xvdev(pdev, &pdev->entire_ctrl_vdev, 0);
    if (rv < 0) {
        pr_err("create_vchar(entire control) failed\n");
        goto fail;
    }
    xvdev_flag_set(pdev, XDF_VDEV_ENTIRE_CTRL);

    return 0;

fail:
    rv = -1;
    xpdev_destroy_interfaces(pdev);
    return rv;
}


int rpp_vdev_init(struct rpp_dev *pdev)
{
    return xpdev_create_interfaces(pdev);
}

void rpp_vdev_exit(struct rpp_dev *pdev)
{
    xpdev_destroy_interfaces(pdev);
}
