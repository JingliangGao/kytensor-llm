/*  SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright (c) 2018 Synopsys, Inc. and/or its affiliates.
 * Synopsys DesignWare EDMA controller driver.
 */

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/delay.h>
#include <linux/string.h>
#include <linux/slab.h>
#include <linux/fs.h>
#include <linux/types.h>
#include <linux/cdev.h>
#include <linux/pci.h>
#include <linux/device.h>
#include <linux/jiffies.h>
#include <linux/sched.h>
#include <linux/errno.h>
#include <linux/uaccess.h>
#include <linux/msi.h>
#include <uapi/linux/pci_regs.h>
#include <asm/uaccess.h>
#include <linux/scatterlist.h>
#include <linux/gfp.h>
#include <asm/cacheflush.h>
#include <linux/pci.h>
#include <linux/aer.h>
#include <linux/suspend.h>

#include "include/rpp_dfx.h"

#include "include/rpp_hal_dma.h"
#include "include/rpp_dma.h"

#include "include/rpp_xdata.h"
#include "include/rpp_types.h"

#include "include/rpp_dev.h"

#include "include/rpp_cdev.h"
#include "include/rpp_vdev.h"
#include "include/rpp_isr.h"
#include "include/rpp_dev_list.h"
#include "include/rpp_pm.h"
#include "include/pci-dma-compat.h"

/* Forward declarations */
static void	RPP_priv_init(struct rpp_dev *pdev);
static void	RPP_priv_exit(struct rpp_dev *pdev);
static irqreturn_t RPP_isr(int irq, void *dev_id);
static void dump_rpp_dev(struct rpp_dev *prppdev);
static void dump_pcie_reg(struct rpp_dev *prppdev);
static int RppInitializeStep1(struct rpp_dev *prppdev);

/* Generate/initialize/update device logging prefix */
static void rpp_gen_dev_prefix(struct rpp_dev *pdev, char *prefix_buf, size_t buf_size);
static void rpp_dev_setup_logging(struct rpp_dev *pdev);
static void rpp_dev_update_logging(struct rpp_dev *pdev);

static int  RPP_probe(struct pci_dev *pdev, const struct pci_device_id *pci_id);
static void RPP_remove(struct pci_dev *pci_dev);
static BOOLEAN ParseCommand(CHAR *msg, PCMD_INFO cmdinfo);
static void DumpLocRam(const PUINT32 addr, UINT32 len, PUINT32 res);
static void DumpSysMem(const PUINT32 addr, UINT32 len, PUINT32 res);
static PHYADDR GetBaseDataPAddr(PDEVICE_EXTENSION pDevExt, DMA_DIRC dirc, UINT8 chan, DMA_CHAN_END end);
static PUINT32 GetBaseDataVAddr(PDEVICE_EXTENSION pDevExt, DMA_DIRC dirc, UINT8 chan, DMA_CHAN_END end);
static BOOLEAN CheckData(PDEVICE_EXTENSION pDevExt, DMA_DIRC dirc, UINT8 chan);
void DataCheckDpc(unsigned long arg);
static UINT32 AllocProtocolMem(struct rpp_dev *pdev, UINT32 memSize, PUINT32 *pvaddr, dma_addr_t *dma_bus, PHYADDR *ppaddr);
static VOID FreeProtocolMem(struct rpp_dev *pdev, UINT32 memSize, PUINT32 *vaddr, dma_addr_t *dma_bus);
static UINT32 BatchAllocDmaMem(struct rpp_dev *pdev, int wrChans, int rdChans);
static void RppXferDoneCallback(DMA_DIRC dirc, UINT8 chan, PVOID ctx);
static UINT32 IoctlDmaInit(struct rpp_dev *pdev, PDEVICE_EXTENSION pDevExt, PCMD_INFO pcmd);
static BOOLEAN RppProducerFunc(PHYADDR *src, PHYADDR *dst, UINT32 *size, DMA_DIRC dirc, UINT8 chan, PVOID context);

static const uint8_t rpp_rtd3_cfg_offsets[RTD3_CFG_NUM_MAX] = {
	0x10, 0x14, 0x18, 0x1c, 0x20, 0x24, 0x30, 0x3c, 0x0c, 0x04,
	0x78, 0x80, 0xa0, 0x98, 0x50, 0x54, 0x58, 0x5c, 0x60, 0x80,
};

/* xData feature */
static short int xData = XDATA;
module_param(xData, short, 0644);
MODULE_PARM_DESC(xData, "xData enable\n");

/* eDMA feature */
static short int eDMA = EDMA;
module_param(eDMA, short, 0644);
MODULE_PARM_DESC(eDMA, "eDMA enable\n");

static bool MSI_only = MSI_ONLY;
module_param(MSI_only, bool, 0644);
MODULE_PARM_DESC(MSI_only, "MSI-X disable\n");

/* number of irq */
static short int IRQ_num = IRQ_NUM;
module_param(IRQ_num, short, 0644);
MODULE_PARM_DESC(IRQ_num, "Number of IRQ\n");

bool rpp_edma_enabled(void)
{
	return eDMA;
}

int rpp_irq_num(void)
{
	return IRQ_num;
}

/* xData location */
static short int xData_bar = XDATA_BAR;
module_param(xData_bar, short, 0644);
MODULE_PARM_DESC(xData_bar, "xData BAR location\n");

/* xCfg location */
static short int xCfg_bar = XCFG_BAR;
module_param(xCfg_bar, short, 0644);
MODULE_PARM_DESC(xCfg_bar, "xCfg BAR location\n");

/* xMpu location */
static short int xMpu_bar = XMPU_BAR;
module_param(xMpu_bar, short, 0644);
MODULE_PARM_DESC(xMpu_bar, "xMpu BAR location\n");

/* eDMA memory location */
static short int eDMA_mem_bar = EDMA_MEM_BAR;
module_param(eDMA_mem_bar, short, 0644);
MODULE_PARM_DESC(eDMA_mem_bar, "eDMA memory BAR location\n");

/* VE enable/disable location */
static bool VE_disable = RPP_VE_DISABLE;
module_param(VE_disable, bool, 0644);
MODULE_PARM_DESC(VE_disable, "VE disable\n");

static bool HW_performance_workaround = HW_PERFORMANCE_WORKAROUND;
module_param(HW_performance_workaround, bool, 0644);
MODULE_PARM_DESC(HW_performance_workaround, "Enables HW performance workaround\n");

static long DDR_mem_off = DDR_MEM_OFF;
module_param(DDR_mem_off, long, 0644);
MODULE_PARM_DESC(DDR_mem_off, "DDR memory offset location (in bytes)\n");

static bool rw5_basic_test;
module_param(rw5_basic_test, bool, 0644);
MODULE_PARM_DESC(rw5_basic_test, "Run IoctlDmaRW5(CH0) route basic test at module init\n");

static bool rw5_route_trace;
module_param(rw5_route_trace, bool, 0644);
MODULE_PARM_DESC(rw5_route_trace, "Trace IoctlDmaRW5 route decisions\n");

static bool rw2_route_trace;
module_param(rw2_route_trace, bool, 0644);
MODULE_PARM_DESC(rw2_route_trace, "Trace IoctlDmaRW2 direct DMA calls\n");

static const struct pci_device_id RPP_pci_tbl[] = {
	{ PCI_DEVICE(RPP_TARGET_VENDOR_ID, RPP_TARGET_DEVICE_ID)},
	{ PCI_DEVICE(0x1F2E, 0x00A1)},
	{ PCI_DEVICE(0x1F2E, 0x00B1)},
	{ PCI_DEVICE(0x1F2E, 0x00C1)},
	{ 0, }
};
MODULE_DEVICE_TABLE (pci, RPP_pci_tbl);

int rpp_device_offline(struct rpp_dev *prppdev)
{
	int rc;

	if (!prppdev || !prppdev->pdev)
		return -ENODEV;

	if (READ_ONCE(prppdev->status) != RPP_PCIE_ONLINE) {
		DEV_ERROR(prppdev, "device_offline: already offline (status=0x%x)\n",
			READ_ONCE(prppdev->status));
		return -ENODEV;
	}

	/* Phase 1: RTD3 config save */
	rc = rpp_pm_store_cfg(prppdev);
	if (rc != 0)
		return rc;

	/* Phase 2: mark driver offline */
	WRITE_ONCE(prppdev->status, RPP_PCIE_OFFLINE);
	return 0;
}

int  rpp_suspend(struct pci_dev *dev, pm_message_t state)
{
	struct rpp_dev *prppdev = xdev_find_by_pdev(dev);
	int rc;

	if (!prppdev)
		return -ENODEV;

	if (READ_ONCE(prppdev->pm_notifier_offline) &&
	    READ_ONCE(prppdev->status) == RPP_PCIE_OFFLINE) {
		DEV_INFO(prppdev, "rpp_suspend: device already offline by PM notifier\n");
		return 0;
	}

	if (READ_ONCE(prppdev->status) == RPP_PCIE_ONLINE) {
		DEV_WARN(prppdev,
			"rpp_suspend: device was not offlined by PM notifier, fallback offline\n");
		WRITE_ONCE(prppdev->pm_suspending, true);
		rc = rpp_device_offline(prppdev);
		if (rc != 0) {
			WRITE_ONCE(prppdev->pm_suspending, false);
			DEV_ERROR(prppdev, "rpp_suspend: fallback device_offline failed, rc=%d\n", rc);
			return rc;
		}
		WRITE_ONCE(prppdev->pm_notifier_offline, true);
		return 0;
	}

	DEV_ERROR(prppdev,
		"rpp_suspend: device was not offlined by PM notifier, status=0x%x notifier_offline=%d\n",
		READ_ONCE(prppdev->status),
		READ_ONCE(prppdev->pm_notifier_offline) ? 1 : 0);
	return -EIO;
}

int  rpp_suspend_late(struct pci_dev *dev, pm_message_t state)
{
	INFO_PRINT("%s/n", __func__);

	return 0;
}

int  rpp_resume_early(struct pci_dev *dev)
{
	INFO_PRINT("%s/n", __func__);

	return 0;
}

void rpp_shutdown(struct pci_dev *dev)
{

	INFO_PRINT("%s/n", __func__);

	struct rpp_dev *prppdev = xdev_find_by_pdev(dev);
	if (rpp_set_pmic(prppdev, FALSE) != 0) {
		DEV_ERROR(prppdev, "set pmic off failed\n");
	}

}

int rpp_sriov_configure(struct pci_dev *dev, int num_vfs)
{
	INFO_PRINT("%s/n", __func__);

	return 0;
}

/* PCI bus error detected on this device */
pci_ers_result_t rpp_error_detected(struct pci_dev *dev,
					pci_channel_state_t error)
{
	INFO_PRINT("%s/n", __func__);

	return PCI_ERS_RESULT_CAN_RECOVER;
}

/* MMIO has been re-enabled, but not DMA */
pci_ers_result_t rpp_mmio_enabled(struct pci_dev *dev)
{
	INFO_PRINT("%s/n", __func__);

	return PCI_ERS_RESULT_NEED_RESET;
}

/* PCI slot has been reset */
pci_ers_result_t rpp_slot_reset(struct pci_dev *dev)
{
	INFO_PRINT("%s/n", __func__);

	/*  return PCI_ERS_RESULT_NEED_RESET; */
	return PCI_ERS_RESULT_RECOVERED;
}

/* PCI function reset prepare or completed */
void rpp_reset_prepare(struct pci_dev *dev)
{
	INFO_PRINT("%s/n", __func__);
}

void rpp_reset_done(struct pci_dev *dev)
{
	INFO_PRINT("%s/n", __func__);
}

int rpp_device_online(struct rpp_dev *prppdev)
{
	int rc = -ENODEV;
	bool need_restore_cfg = false;

	if (!prppdev || !prppdev->pdev)
		return -ENODEV;

	if (READ_ONCE(prppdev->status) != RPP_PCIE_OFFLINE) {
		DEV_ERROR(prppdev, "device_online: already online (status=0x%x)\n",
			READ_ONCE(prppdev->status));
		return -ENODEV;
	}

	/* Phase 1: wait for PCIe config space */
	msleep(10);
	rc = rpp_pm_wait_config_ready(prppdev);
	if (rc != 0)
		goto err_out;

	/* Phase 2: restore RTD3 configuration if needed */
	need_restore_cfg = rpp_pm_need_restore_cfg(prppdev);
	if (need_restore_cfg)
		rpp_pm_restore_cfg(prppdev);

	/* Phase 3: restore PCIe speed/PHY/ATU/MSI state and validate the link */
	rc = rpp_pm_restore_pcie_internal_state(prppdev);
	if (rc != 0)
		goto err_out;

	rc = rpp_pm_poll_pcie_link(prppdev);
	if (rc)
		goto err_out;

	/* Phase 4: DMA re-init */
	rc = rpp_pm_reinit_dma(prppdev, "device_online");
	if (rc != 0)
		goto err_out;

	/* Phase 5: settle and restore firmware state */
	msleep(100);
	rc = RppInitializeStep1(prppdev);
	if (rc != 0) {
		DEV_ERROR(prppdev, "device_online: RppInitializeStep1 failed, rc=%d\n", rc);
		goto err_out;
	}

	/* Phase 6: mark driver online.
	 * Hardware/firmware were fully reinitialized above; drop stale idle flag
	 * so software state matches the restored device.
	 */
	WRITE_ONCE(prppdev->status, RPP_PCIE_ONLINE);
	WRITE_ONCE(prppdev->pm_notifier_offline, false);
	WRITE_ONCE(prppdev->pm_suspending, false);
	WRITE_ONCE(prppdev->dma_xfer_active, false);
	WRITE_ONCE(prppdev->pm_abort_xfer, false);
	WRITE_ONCE(prppdev->idle_low_power_suspended, false);
	DEV_INFO(prppdev, "device_online: complete\n");
	return 0;

err_out:
	DEV_ERROR(prppdev, "device_online: failed, rc=%d\n", rc);
	return rc;
}

int rpp_resume(struct pci_dev *dev)
{
	struct rpp_dev *prppdev = xdev_find_by_pdev(dev);
	int rc;

	if (!prppdev)
		return -ENODEV;

	/* System resume uses the common device online flow. */
	rc = rpp_device_online(prppdev);
	if (rc != 0) {
		DEV_ERROR(prppdev, "rpp_resume: device_online failed, rc=%d\n", rc);
		return rc;
	}

	INFO_PRINT("%s/n", __func__);

	return 0;
}

static void rpp_error_resume(struct pci_dev *dev)
{
	(void)rpp_resume(dev);
}

static const struct pci_error_handlers rpp_err_handler = {
	.error_detected = rpp_error_detected,
	.mmio_enabled = rpp_mmio_enabled,
	.slot_reset = rpp_slot_reset,
	.reset_prepare = rpp_reset_prepare,
	.reset_done = rpp_reset_done,
	.resume = rpp_error_resume,
};

static int rpp_pm_suspend(struct device *device)
{
	return rpp_suspend(to_pci_dev(device), PMSG_SUSPEND);
}

static int rpp_pm_suspend_late(struct device *device)
{
	return rpp_suspend_late(to_pci_dev(device), PMSG_SUSPEND);
}

static int rpp_pm_resume_early(struct device *device)
{
	return rpp_resume_early(to_pci_dev(device));
}

static int rpp_pm_resume(struct device *device)
{
	return rpp_resume(to_pci_dev(device));
}

static int rpp_pm_freeze(struct device *device)
{
	return rpp_suspend(to_pci_dev(device), PMSG_FREEZE);
}

static int rpp_pm_freeze_late(struct device *device)
{
	return rpp_suspend_late(to_pci_dev(device), PMSG_FREEZE);
}

static int rpp_pm_thaw_early(struct device *device)
{
	return rpp_resume_early(to_pci_dev(device));
}

static int rpp_pm_thaw(struct device *device)
{
	return rpp_resume(to_pci_dev(device));
}

static int rpp_pm_poweroff(struct device *device)
{
	return rpp_suspend(to_pci_dev(device), PMSG_HIBERNATE);
}

static int rpp_pm_poweroff_late(struct device *device)
{
	return rpp_suspend_late(to_pci_dev(device), PMSG_HIBERNATE);
}

static int rpp_pm_restore_early(struct device *device)
{
	return rpp_resume_early(to_pci_dev(device));
}

static int rpp_pm_restore(struct device *device)
{
	return rpp_resume(to_pci_dev(device));
}

static const struct dev_pm_ops rpp_pm_ops = {
	.suspend = rpp_pm_suspend,
	.suspend_late = rpp_pm_suspend_late,
	.resume_early = rpp_pm_resume_early,
	.resume = rpp_pm_resume,
	.freeze = rpp_pm_freeze,
	.freeze_late = rpp_pm_freeze_late,
	.thaw_early = rpp_pm_thaw_early,
	.thaw = rpp_pm_thaw,
	.poweroff = rpp_pm_poweroff,
	.poweroff_late = rpp_pm_poweroff_late,
	.restore_early = rpp_pm_restore_early,
	.restore = rpp_pm_restore,
};

static struct pci_driver RPP_pci_driver = {
	.name     = DRVER_NAME,
	.id_table = RPP_pci_tbl,
	.probe    = RPP_probe,
	.remove   = RPP_remove,
	.driver   = {
		.pm = &rpp_pm_ops,
	},
	.shutdown = rpp_shutdown,
	.sriov_configure = rpp_sriov_configure,
	.err_handler	= &rpp_err_handler,
};

struct rpp_pm_notifier_ctx {
	unsigned long action;
};

static void rpp_pm_notifier_release_idle_hold(struct rpp_dev *prppdev)
{
	int rc;

	if (!READ_ONCE(prppdev->idle_low_power_system_ref))
		return;

	WRITE_ONCE(prppdev->idle_low_power_system_ref, false);
	rc = rpp_idle_low_power_put(prppdev, "pm_notifier");
	if (rc != 0)
		DEV_WARN(prppdev, "pm: notifier idle_low_power put rc=%d\n", rc);
	else
		DEV_INFO(prppdev, "pm: notifier releases idle_low_power hold\n");
}

static int rpp_pm_notifier_prepare_device(struct rpp_dev *prppdev)
{
	int rc;

	rpp_pm_log_cfg_state(prppdev, "notifier prepare");

	if (READ_ONCE(prppdev->status) != RPP_PCIE_ONLINE) {
		DEV_INFO(prppdev, "pm: notifier skip offline, device status=0x%x\n",
			READ_ONCE(prppdev->status));
		return 0;
	}

	if (READ_ONCE(prppdev->pm_notifier_offline)) {
		DEV_INFO(prppdev, "pm: notifier skip offline, already offline\n");
		return 0;
	}

	/*
	 * Exit idle low power and hold a ref across system PM/S4, matching the
	 * runtime-PM prepare hold on the working branch. Store/offline must not
	 * run while the device remains in RPP_PWRMODE_LOW_POWER.
	 */
	rc = rpp_idle_low_power_get(prppdev, "pm_prepare");
	if (rc != 0) {
		DEV_ERROR(prppdev,
			"pm: notifier failed to exit idle_low_power, rc=%d\n", rc);
		return rc;
	}
	WRITE_ONCE(prppdev->idle_low_power_system_ref, true);
	DEV_INFO(prppdev, "pm: notifier holds idle_low_power active\n");

	WRITE_ONCE(prppdev->pm_suspending, true);
	if (rpp_pm_need_restore_cfg(prppdev) &&
	    READ_ONCE(prppdev->dma_xfer_active) &&
	    !READ_ONCE(prppdev->pm_abort_xfer)) {
		WRITE_ONCE(prppdev->pm_abort_xfer, true);
		DEV_WARN(prppdev,
			"pm: notifier completes active DMA xfer before waiting ioctl\n");
		complete(&prppdev->xfer_done);
	}
	DEV_INFO(prppdev, "pm: notifier blocks new ioctls and waits active ioctl\n");

	rc = rpp_pm_wait_active_ioctl(prppdev);
	if (rc != 0) {
		WRITE_ONCE(prppdev->pm_suspending, false);
		rpp_pm_notifier_release_idle_hold(prppdev);
		return -EBUSY;
	}

	DEV_INFO(prppdev, "pm: notifier active ioctl drained, offline device before freezer\n");
	rc = rpp_device_offline(prppdev);
	up(&prppdev->sem);
	if (rc != 0) {
		WRITE_ONCE(prppdev->pm_suspending, false);
		rpp_pm_notifier_release_idle_hold(prppdev);
		DEV_ERROR(prppdev, "pm: notifier failed to offline device, rc=%d\n", rc);
		return rc;
	}

	WRITE_ONCE(prppdev->pm_notifier_offline, true);
	DEV_INFO(prppdev, "pm: notifier offlined device before freezer\n");
	rpp_pm_log_cfg_state(prppdev, "notifier prepare exit");

	return 0;
}

static int rpp_pm_notifier_complete_device(struct rpp_dev *prppdev)
{
	bool online_ok = false;

	rpp_pm_log_cfg_state(prppdev, "notifier post");
	if (READ_ONCE(prppdev->status) == RPP_PCIE_OFFLINE) {
		DEV_WARN(prppdev, "pm: notifier post ensures offline device is online\n");
		if (rpp_device_online(prppdev) != 0)
			DEV_ERROR(prppdev, "pm: notifier post failed to recover device\n");
	}

	if (READ_ONCE(prppdev->status) == RPP_PCIE_ONLINE) {
		online_ok = true;
		WRITE_ONCE(prppdev->pm_notifier_offline, false);
		WRITE_ONCE(prppdev->dma_xfer_active, false);
		WRITE_ONCE(prppdev->pm_abort_xfer, false);
	}

	/* Clear before idle put so re-enter is allowed. */
	WRITE_ONCE(prppdev->pm_suspending, false);
	rpp_pm_notifier_release_idle_hold(prppdev);

	if (!online_ok)
		DEV_WARN(prppdev,
			"pm: notifier post leaves device offline; userspace may need PCI rescan/reload\n");

	return 0;
}

static int rpp_pm_notifier_device(struct device *device, void *data)
{
	struct rpp_pm_notifier_ctx *ctx = data;
	struct pci_dev *pdev = to_pci_dev(device);
	struct rpp_dev *prppdev = pci_get_drvdata(pdev);

	if (!prppdev)
		return 0;

	if (ctx->action == PM_SUSPEND_PREPARE ||
	    ctx->action == PM_HIBERNATION_PREPARE ||
	    ctx->action == PM_RESTORE_PREPARE)
		return rpp_pm_notifier_prepare_device(prppdev);
	if (ctx->action == PM_POST_SUSPEND ||
	    ctx->action == PM_POST_HIBERNATION ||
	    ctx->action == PM_POST_RESTORE)
		return rpp_pm_notifier_complete_device(prppdev);

	return 0;
}

static int rpp_pm_notifier_call(struct notifier_block *nb, unsigned long action, void *data)
{
	struct rpp_pm_notifier_ctx ctx = {
		.action = action,
	};
	int rc;

	if (action != PM_SUSPEND_PREPARE &&
	    action != PM_POST_SUSPEND &&
	    action != PM_HIBERNATION_PREPARE &&
	    action != PM_POST_HIBERNATION &&
	    action != PM_RESTORE_PREPARE &&
	    action != PM_POST_RESTORE)
		return NOTIFY_OK;

	rc = driver_for_each_device(&RPP_pci_driver.driver, NULL, &ctx,
		rpp_pm_notifier_device);
	if (rc != 0)
		return NOTIFY_BAD;

	return NOTIFY_OK;
}

static struct notifier_block rpp_pm_notifier = {
	.notifier_call = rpp_pm_notifier_call,
};


/*  modified by jgd */

#define XDATA_OFFSET 0x06000000

/**
 * Implements HAL callback function PRODUCER_FUNC().
 *
 * This function is responsible for generating new data for linked list element.
 * The source and destination are wrapped around within the chunk of memory
 * owned by specified channel.
 *
 * @param[in,out] src    The source of the transfer.
 * @param[in,out] dst    The destination of the transfer.
 * @param[in,out] size   The size of the data need to be transferred.
 * @param[in] dirc       The direction of the channel.
 * @param[in] chan       The number of the channel.
 * @param[in] context    The callback context.
 * @return True if new data is generated successfully; False otherwise.
 * @see PRODUCER_FUNC
 * @ingroup hal_caller
 */
static BOOLEAN RppProducerFunc(PHYADDR *src, PHYADDR *dst,
				UINT32 *size, DMA_DIRC dirc,
				UINT8 chan, PVOID context)
{
	BOOLEAN isDdr;
	PHYADDR bsrc;
	PHYADDR bdst;
	PDEVICE_EXTENSION pDevExt = (PDEVICE_EXTENSION)context;
	PCHAN_INFO_EX pChInfEx = (dirc == DMA_WRITE) ? &pDevExt->WrChInfEx[chan]
						     : &pDevExt->RdChInfEx[chan];

	/* We transfer same amount of data each time */
	*size = pChInfEx->BlockSize;
	isDdr = pChInfEx->PatternIncre > 2;

	bsrc = GetBaseDataPAddr(pDevExt, dirc, chan, GET_CHAN_SRC(dirc, isDdr));
	bdst = GetBaseDataPAddr(pDevExt, dirc, chan, GET_CHAN_DST(dirc, isDdr));

	if (src->LowPart == 0 && src->HighPart == 0) {
		*src = bsrc;
		*dst = bdst;
	} else {
		UINT32 boundry = bsrc.LowPart + pDevExt->ChunkLen * 4;
		/* If the address reachs the boundry, wrap it back. The assumption here
		 * is that source and destination chunk of memory have the same size.
		 */
		src->LowPart += *size;
		dst->LowPart += *size;
		if (src->LowPart > boundry - (*size)) {
			*src = bsrc;
			*dst = bdst;
		}
	}

	return TRUE;
}

/**
 * Implements HAL callback function PRODUCER_FUNC().
 *
 * This function is responsible for generating new data for linked list element.
 * The source and destination are wrapped around within the chunk of memory
 * owned by specified channel.
 *
 * @param[in,out] src    The source of the transfer.
 * @param[in,out] dst    The destination of the transfer.
 * @param[in,out] size   The size of the data need to be transferred.
 * @param[in] dirc       The direction of the channel.
 * @param[in] chan       The number of the channel.
 * @param[in] context    The callback context.
 * @return True if new data is generated successfully; False otherwise.
 * @see PRODUCER_FUNC
 * @ingroup hal_caller
 */
static BOOLEAN RppProducerFunc2(PHYADDR *src, PHYADDR *dst,
				UINT32 *size, DMA_DIRC dirc,
				UINT8 chan, PVOID context)
{
	BOOLEAN isDdr;
	PHYADDR bsrc;
	PHYADDR bdst;
	PDEVICE_EXTENSION pDevExt = (PDEVICE_EXTENSION)context;
	PCHAN_INFO_EX pChInfEx = (dirc == DMA_WRITE) ? &pDevExt->WrChInfEx[chan]
						     : &pDevExt->RdChInfEx[chan];
	struct sg_table *sgt = pDevExt->sgt;
	struct scatterlist *sg = sgt->sgl;
	unsigned int i;

	for_each_sg(sgt->sgl, sg, pChInfEx->SgNent, i);

	if (dirc == DMA_WRITE) {
		bsrc.QuadPart = pDevExt->RamPa.QuadPart + pChInfEx->TotalSize;
		bsrc.LowPart = (UINT32)bsrc.QuadPart;
		bsrc.HighPart = (UINT32)(bsrc.QuadPart>>32);
		bdst.QuadPart = sg_dma_address(sg);
		bdst.LowPart = (UINT32)bdst.QuadPart;
		bdst.HighPart = (UINT32)(bdst.QuadPart>>32);

	} else {
		bdst.QuadPart = pDevExt->RamPa.QuadPart + pChInfEx->TotalSize;
		bdst.LowPart = (UINT32)bdst.QuadPart;
		bdst.HighPart = (UINT32)(bdst.QuadPart>>32);
		bsrc.QuadPart = sg_dma_address(sg);
		bsrc.LowPart = (UINT32)bsrc.QuadPart;
		bsrc.HighPart = (UINT32)(bsrc.QuadPart>>32);
	}

	*src = bsrc;
	*dst = bdst;
	*size = sg_dma_len(sg);

	DTRACE("%s: src=0x%llx, dst=0x%llx, size=0x%x\n",
		__func__, src->QuadPart, dst->QuadPart, *size);

	pChInfEx->SgNent++;
	pChInfEx->BlockSize = *size;
	pChInfEx->TotalSize += *size;

	DTRACE("%s: SgNent=0x%x, BlockSize=0x%llx, TotalSize=0x%llx\n",
		__func__, pChInfEx->SgNent, pChInfEx->BlockSize, pChInfEx->TotalSize);

	return TRUE;
}


/**
 * Implements HAL callback function PRODUCER_FUNC().
 *
 * This function is responsible for generating new data for linked list element.
 * The source and destination are wrapped around within the chunk of memory
 * owned by specified channel.
 *
 * @param[in,out] src    The source of the transfer.
 * @param[in,out] dst    The destination of the transfer.
 * @param[in,out] size   The size of the data need to be transferred.
 * @param[in] dirc       The direction of the channel.
 * @param[in] chan       The number of the channel.
 * @param[in] context    The callback context.
 * @return True if new data is generated successfully; False otherwise.
 * @see PRODUCER_FUNC
 * @ingroup hal_caller
 */
static BOOLEAN RppProducerCB(PHYADDR *src, PHYADDR *dst, UINT32* size,
        DMA_DIRC dirc, UINT32* index, UINT64* offset, PVOID context)
{
	BOOLEAN isDdr;
	UINT32 ele_len;
	PHYADDR ele_addr;
	PHYADDR bsrc;
	PHYADDR bdst;
	PDEVICE_EXTENSION pDevExt = (PDEVICE_EXTENSION)context;
	PDMA_BLKS_INFO info = pDevExt->blk_info;
	PBLK_ELEMENT mapped_blk = NULL;

	if(*index >= info->vail_num) {
		ERROR_PRINT("Blocks info index %d >= vaild numbuer %d\n", index, info->vail_num);
		return FALSE;
	}

	if (info->vail_num == 1) { /* the only element is both first and last */
		mapped_blk = info->mapped_blk + info->start;
		ele_len = info->end_size;
		ele_addr.QuadPart = mapped_blk->dma_address + info->start_offs;
	}
	else if (*index == 0) { /* first element */
		mapped_blk = info->mapped_blk + info->start;
		ele_len = mapped_blk->dma_length - info->start_offs;
		ele_addr.QuadPart = mapped_blk->dma_address + info->start_offs;
	}
	else if (*index == (info->vail_num - 1)) {  /* last element */
		mapped_blk = info->mapped_blk + info->start + *index;
		ele_len = info->end_size;
		ele_addr.QuadPart = mapped_blk->dma_address;
	}
	else { /* other elements */
		mapped_blk = info->mapped_blk + info->start + *index;
		ele_len = mapped_blk->dma_length;
		ele_addr.QuadPart = mapped_blk->dma_address;
	}

	if (dirc == DMA_WRITE) {
		bsrc.QuadPart = pDevExt->RamPa.QuadPart + *offset;
		bsrc.LowPart = (UINT32)bsrc.QuadPart;
		bsrc.HighPart = (UINT32)(bsrc.QuadPart>>32);
		bdst.QuadPart = ele_addr.QuadPart;
		bdst.LowPart = (UINT32)bdst.QuadPart;
		bdst.HighPart = (UINT32)(bdst.QuadPart>>32);

	} else {
		bdst.QuadPart = pDevExt->RamPa.QuadPart + *offset;
		bdst.LowPart = (UINT32)bdst.QuadPart;
		bdst.HighPart = (UINT32)(bdst.QuadPart>>32);
		bsrc.QuadPart = ele_addr.QuadPart;
		bsrc.LowPart = (UINT32)bsrc.QuadPart;
		bsrc.HighPart = (UINT32)(bsrc.QuadPart>>32);
	}

	*src = bsrc;
	*dst = bdst;
	*size = ele_len;

	*index += 1;
	*offset += *size;

	DTRACE("%s: SgNent=0x%x, BlockSize=0x%llx, TotalSize=0x%llx, src=0x%llx, dst=0x%llx\n",
		__func__, *index, *size, *offset, bsrc.QuadPart, bdst.QuadPart);

	return TRUE;
}


/**
 * Dump local RAM content, using register access method.
 *
 * @param[in] addr  The address of the local RAM
 * @param[in] len   The length of data
 * @param[out] res  The pointer to an array to hold the returned data. Please
 *                  be sure the array has enough space to hold the data.
 */
static void DumpLocRam(const PUINT32 addr, UINT32 len, PUINT32 res)
{
	while (len) {
		len--;
		res[len] = RPP_READ_UINT32(addr + len);
	}
}

/**
 * Dump system memory content.
 *
 * Similiar to DumpLocRam, but use direct memory access.
 *
 * @param[in] addr  The address of local RAM
 * @param[in] len   The length of data
 * @param[out] res  The pointer to an array to hold the returned data. Please
 *                  be sure the array has enough space to hold the data.
 */
static void DumpSysMem(const PUINT32 addr, UINT32 len, PUINT32 res)
{
	while (len) {
		len--;
		res[len] = addr[len];
	}
}




/**
 * This function is similiar to GetBaseDataVAddr, but it returns the physical
 * address instead of virtual address.
 *
 * @param[in] pDevExt   Device extension object
 * @param[in] dirc      The direction of the channel.
 * @param[in] chan      The number of the channel.
 * @param[in] end       The end of the channel.
 * @return the physical address of starting location for given channel.
 * @see GetBaseDataVAddr
 */
static PHYADDR GetBaseDataPAddr(PDEVICE_EXTENSION pDevExt, DMA_DIRC dirc,
	UINT8 chan, DMA_CHAN_END end)
{
	PHYADDR addr = {{0} };

	if ((dirc == DMA_WRITE && chan >= pDevExt->DmaRsc.WrChans) || (dirc
	    == DMA_READ && chan >= pDevExt->DmaRsc.RdChans))
		return addr;



	if (end == DMA_CHAN_HST) {
		if (dirc == DMA_READ)
			chan += 8;
		addr = pDevExt->IoMemPa[chan];
	} else {
		int baseId = end == DMA_CHAN_DDR ? CHUNK_ID_DDR_W0
						 : CHUNK_ID_W0;
		addr.LowPart = (DDR_MEM_OFF >> 2) << 2;
		addr.LowPart += pDevExt->ChunkLen * (baseId + chan) * 4;
	}

	return addr;
}

/**
 * Get the base data virtual address of given channel.
 *
 * Both the system memory and local memory are segmented to chunks for all
 * channels, so each channel has its unique block of memory as source and
 * unique block of memory as destination. This function returns the starting
 * address of that block of memory for given channel.
 *
 * @param[in] pDevExt   Device extension object
 * @param[in] dirc      The direction of the channel.
 * @param[in] chan      The number of the channel.
 * @param[in] end       The end of the channel.
 * @return the virtual address of starting location for given channel.
 */
static PUINT32 GetBaseDataVAddr(PDEVICE_EXTENSION pDevExt, DMA_DIRC dirc,
				UINT8 chan, DMA_CHAN_END end)
{
	PUINT32 addr = NULL;

	if ((dirc == DMA_WRITE && chan >= pDevExt->DmaRsc.WrChans) || (dirc
	    == DMA_READ && chan >= pDevExt->DmaRsc.RdChans))
		return addr;

/* 	if (dirc == DMA_READ) */
/* 		chan += 8; */

	if (end == DMA_CHAN_HST) {
		if (dirc == DMA_READ)
			chan += 8;
		addr = pDevExt->IoMemVa[chan];
	} else {
		int baseId = end == DMA_CHAN_DDR ? CHUNK_ID_DDR_W0 : CHUNK_ID_W0;
		addr = pDevExt->RamVa + (DDR_MEM_OFF >> 2);
		addr += pDevExt->ChunkLen * (baseId + chan);
	}

    return addr;
}

/**
 * Check data transferred by DMA.
 *
 * This function should only be called after the transfer is finished. Also,
 * since this function takes time to compare the destination data and the
 * expected pattern, it should not be called directly from ISR. Instead,
 * calling it in DPC is appropriate.
 *
 * @param[in] pDevExt   The device extension object.
 * @param[in] dirc      The direction of the channel.
 * @param[in] chan      The number of the channel.
 * @return True if the check passed; False otherwise.
 * @see HalDmaState
 * @ingroup hal_caller
 */
static BOOLEAN CheckData(PDEVICE_EXTENSION pDevExt, DMA_DIRC dirc, UINT8 chan)
{
	UINT64 xferred;
	PCHAN_INFO_EX pChInfEx;
	UINT32 len;
	BOOLEAN isDdr;
	PUINT32 srcAddr;
	PUINT32 dstAddr;
	UINT32 srcData, dstData;
	BOOLEAN ret = TRUE;
	PDMA_RSC pdrsc = &pDevExt->DmaRsc;

	/* Firstly check the state of given channel to see how many data has been
	* transferred. Data check only perform checks on that amount of data.
	*/
	HalDmaState(pdrsc, dirc, chan, NULL, NULL, &xferred, NULL, NULL);

	pChInfEx = (dirc == DMA_WRITE) ? &pDevExt->WrChInfEx[chan]
	    : &pDevExt->RdChInfEx[chan];
	len = ((RPP_DIV64(xferred, 4)) > pDevExt->ChunkLen)
	    ? pDevExt->ChunkLen - (pDevExt->ChunkLen % (pChInfEx->BlockSize/4))
	    : (UINT32)xferred / 4;
	isDdr = pChInfEx->PatternIncre > 2;
	srcAddr = GetBaseDataVAddr(pDevExt, dirc, chan, GET_CHAN_SRC(dirc, isDdr));
	dstAddr = GetBaseDataVAddr(pDevExt, dirc, chan, GET_CHAN_DST(dirc, isDdr));

	printk("RAM data pattern check: len=%lld \n", xferred);

	pChInfEx->DataCheck = DATA_CHECK_SUCCESS;
    if (dirc == DMA_WRITE)
	{
	}
	else
	{
/* /	GenSrcData(pDevExt, dirc, chan, 0x0, 0x0, isDdr, xferred); */
	}
#if 1
	len = xferred / 4;
	if (xferred == 1)
		len = 1;
	while (len) {
		if (dirc == DMA_READ) {
			DumpLocRam(dstAddr, 1, &dstData);
			/* DumpSysMem(dstAddr, 1, &dstData); */
			DumpSysMem(srcAddr, 1, &srcData);
		} else {
			DumpSysMem(dstAddr, 1, &dstData);
			DumpLocRam(srcAddr, 1, &srcData);
			/* DumpSysMem(srcAddr, 1, &srcData); */
		}
		if (srcData != dstData) {
			printk("len=%d [0x%x] %08x != %08x(pat)\n", len,
			    (UINT32) (dstAddr -  GetBaseDataVAddr(pDevExt, dirc, chan, GET_CHAN_DST(dirc, isDdr))),
			    dstData, srcData);
			pChInfEx->DataCheck = DATA_CHECK_FAILURE;
			ret = FALSE;
			break;
		}
		srcAddr++;
		dstAddr++;
		len--;
	}
#endif
	if (ret)
	    printk("Data Check passed\n");
	return ret;
}


void DataCheckDpc(unsigned long arg)
{
	struct rpp_dev *pdev = (struct rpp_dev *)arg;
	PDEVICE_EXTENSION pDevExt = &pdev->RPP_ext;
	PCHAN_INFO_EX pChInfEx;
	DMA_DIRC dirc;
	UINT8 chan;

	/* Traverse all channels to see if need to do data check */
	dirc = DMA_WRITE;
	for (chan = 0; chan < pDevExt->DmaRsc.WrChans; chan++) {
		pChInfEx = &pDevExt->WrChInfEx[chan];
		if (pChInfEx->DataCheck == DATA_CHECK_READY)
			CheckData(pDevExt, dirc, chan);
	}
	dirc = DMA_READ;
	for (chan = 0; chan < pDevExt->DmaRsc.RdChans; chan++) {
		pChInfEx = &pDevExt->RdChInfEx[chan];
		if (pChInfEx->DataCheck == DATA_CHECK_READY)
			CheckData(pDevExt, dirc, chan);
	}
}

static UINT32 AllocProtocolMem(struct rpp_dev *pdev, UINT32 memSize, PUINT32 *pvaddr, dma_addr_t *dma_bus, PHYADDR *ppaddr)
{
	UINT32 status = STATUS_SUCCESS;
	UINT32 i;
	void *dma_buf;
	PUCHAR memVa;

	DEV_DEBUG(pdev, "Allocating memory for I/O buffers\n");

	dma_buf = pci_alloc_consistent(pdev->pdev, memSize, dma_bus);

	if (HW_PERFORMANCE_WORKAROUND)
		*dma_bus = (dma_addr_t)(pdev->bar[EDMA_MEM_BAR] + XDATA_OFFSET);

	if (!dma_buf) {
		DEV_ERROR(pdev, "error pci_alloc_consistent\n");
		status = STATUS_FAIL;
		*pvaddr = 0;
		ppaddr->LowPart = 0;
		ppaddr->HighPart = 0;
		goto CLEANUP;
	}

	*pvaddr = (PUINT32)dma_buf;
	ppaddr->LowPart = cpu_to_le32(pci_dma_l(*dma_bus));
	ppaddr->HighPart = cpu_to_le32(pci_dma_h(*dma_bus));

	/* Initialize the allocated memory */
	memVa = (PUCHAR)dma_buf;
	for (i = 0; i < memSize; i++)
		*memVa++ = 0xcd;

CLEANUP:

	return status;
}

static VOID FreeProtocolMem(struct rpp_dev *pdev, UINT32 memSize, PUINT32 *vaddr, dma_addr_t *dma_bus)
{
	if (*vaddr == NULL)
		return;

	pci_free_consistent(pdev->pdev, memSize, *vaddr, *dma_bus);

}

static UINT32 BatchAllocDmaMem(struct rpp_dev *pdev, int wrChans, int rdChans)
{
	UINT32 status = STATUS_SUCCESS;
	int i = 0;

	for (i = 0; status == STATUS_SUCCESS && i < wrChans; i++) {
		status = AllocProtocolMem(pdev, pdev->RPP_ext.ChunkLen * 4,
					  &pdev->RPP_ext.IoMemVa[i],
					  &pdev->RPP_ext.dma_bus[i],
					  &pdev->RPP_ext.IoMemPa[i]);
		DEV_DEBUG(pdev, "IoMemVa[%d]=0x%x\n", i, pdev->RPP_ext.IoMemVa[i]);
		DEV_DEBUG(pdev, "dma_bus[%d]=0x%lx\n", i, pdev->RPP_ext.dma_bus[i]);
		DEV_DEBUG(pdev, "IoMemPa[%d]=0x%llx\n", i, pdev->RPP_ext.IoMemPa[i].QuadPart);
	}

	DEV_DEBUG(pdev, "Allocating memory for DMA write buffers\n");
	for (i = 8; status == STATUS_SUCCESS && i < 8 + rdChans; i++) 	{
		status = AllocProtocolMem(pdev, pdev->RPP_ext.ChunkLen * 4,
					  &pdev->RPP_ext.IoMemVa[i],
					  &pdev->RPP_ext.dma_bus[i],
					  &pdev->RPP_ext.IoMemPa[i]);
		DEV_DEBUG(pdev, "IoMemVa[%d]=0x%x\n", i, *(pdev->RPP_ext.IoMemVa[i]));
		DEV_DEBUG(pdev, "dma_bus[%d]=0x%lx\n", i, pdev->RPP_ext.dma_bus[i]);
		DEV_DEBUG(pdev, "IoMemPa[%d]=0x%llx\n", i, pdev->RPP_ext.IoMemPa[i].QuadPart);
	}

	/* Free all previously allocated memory if any allocation is failed. */
	if (status != STATUS_SUCCESS) {
		while (--i >= 0)
			FreeProtocolMem(pdev, pdev->RPP_ext.ChunkLen * 4,
				&pdev->RPP_ext.IoMemVa[i], &pdev->RPP_ext.dma_bus[i]);
	}

	return status;
}


static void RppXferDoneCallback(DMA_DIRC dirc, UINT8 chan, PVOID ctx)
{
	PDEVICE_EXTENSION pDevExt = (PDEVICE_EXTENSION)ctx;
	struct rpp_dev *pdev = container_of(pDevExt, struct rpp_dev, RPP_ext);

	PCHAN_INFO_EX pChInfEx = dirc == DMA_WRITE ? &pDevExt->WrChInfEx[chan]
	    : &pDevExt->RdChInfEx[chan];

	pChInfEx->tick_count_stop = jiffies;

	/* if one channel is finished and data check need to be performed, kick off
	* DPC to do that. */
	if (pChInfEx->DataCheck == DATA_CHECK_UNKNOWN) {
		pChInfEx->DataCheck = DATA_CHECK_READY;

		tasklet_schedule(&pdev->tlet);
		DTRACE("Transfer on %s channel %d is finished.",
		       dirc == DMA_WRITE ? "write" : "read", chan);
	}
}




static void sgt_dump(struct sg_table *sgt)
{
	int i;
	struct scatterlist *sg = sgt->sgl;

	INFO_PRINT("sgt 0x%p, sgl 0x%p, nents %u/%u.\n",
		sgt, sgt->sgl, sgt->nents, sgt->orig_nents);

	for (i = 0; i < sgt->orig_nents; i++, sg = sg_next(sg)) {
		INFO_PRINT("%d, 0x%p, pg virt/phys 0x%llx/0x%llx, %u+%u, dma 0x%llx,%u.\n",
			i, sg, (uint64_t)sg_virt(sg), (uint64_t)sg_phys(sg), sg->offset, sg->length,
			sg_dma_address(sg), sg_dma_len(sg));
	}
}

UINT32 IoctlDmaState(struct rpp_dev *pdev, DMA_DIRC dirc, UINT8 chan, DMA_CHAN_STATUS *stat, DMA_ERR *err, UINT64 *xferred,
        UINT32 *intCntDone, UINT32 *intCntAbort)
{
	PDEVICE_EXTENSION pDevExt = &pdev->RPP_ext;
	PDMA_RSC pdrsc = &pDevExt->DmaRsc;
	UINT32 status = STATUS_SUCCESS;
	HAL_DMA_RET ret;

	/* Check channel state.*/
	ret = HalDmaState(pdrsc, dirc, chan, stat, err, xferred, intCntDone, intCntAbort);
	if (ret != DMA_SUCCESS) {
		HalDmaGetErrInfo(ret);
		status = STATUS_UNSUCCESSFUL;
	}

	return status;
}
EXPORT_SYMBOL_GPL(IoctlDmaState);

/**
 * DMA read/write operation with single buffer
 *
 * @param[in] pdev       RPP device structure
 * @param[in] Chan       DMA channel number
 * @param[in] write      DMA direction (DMA_WRITE or DMA_READ)
 * @param[in] ep_addr    Endpoint address
 * @param[in] host_addr  Host DMA address
 * @param[in] size       Transfer size in bytes
 * @param[in] timeout_ms Timeout in milliseconds
 * @return STATUS_SUCCESS on success, error code on failure
 */
UINT32 IoctlDmaRW2(struct rpp_dev *pdev, UINT8 Chan, DMA_DIRC write, u64 ep_addr, dma_addr_t host_addr, u32 size, u32 timeout_ms)
{
	PDEVICE_EXTENSION pDevExt;
	UINT32 status = STATUS_SUCCESS;
	HAL_DMA_RET ret;
	PDMA_RSC pdrsc;
	DMA_DIRC dirc = write;
	UINT8 chan = Chan;
	UINT32 blkSize;
	BOOLEAN queue = 0;
	UINT8 wei = 0;   /* actual weights are 0 to 31 */
	DMA_CHAN_STATUS stat;
	PCHAN_INFO_EX pChInfEx;

	/* Input parameter validation */
	if (!pdev) {
		ERROR_PRINT("Invalid device pointer\n");
		return STATUS_UNSUCCESSFUL;
	}

	pDevExt = &pdev->RPP_ext;
	pdrsc = &pDevExt->DmaRsc;

	/* Validate channel number */
	if ((dirc == DMA_WRITE && chan >= pDevExt->DmaRsc.WrChans) ||
	    (dirc == DMA_READ && chan >= pDevExt->DmaRsc.RdChans)) {
		DEV_ERROR(pdev, "Invalid channel number: %d\n", chan);
		return STATUS_UNSUCCESSFUL;
	}

	/* Validate transfer size */
	if (size == 0) {
		DEV_ERROR(pdev, "Invalid transfer size: 0\n");
		return STATUS_UNSUCCESSFUL;
	}

	if (rw2_route_trace) {
		DEV_INFO(pdev, "%s: chan=%u dirc=%s ep_addr=0x%llx host_addr=0x%llx size=0x%x\n",
			 __func__, chan, dirc == DMA_WRITE ? "DMA_WRITE" : "DMA_READ",
			 ep_addr, (u64)host_addr, size);
	}

	blkSize = size;

	pChInfEx = (dirc == DMA_WRITE) ? &pDevExt->WrChInfEx[chan]
				       : &pDevExt->RdChInfEx[chan];

	/* Check channel state to make sure it's not running, otherwise we can't
	* start a new transfer.
	*/
	ret = HalDmaState(pdrsc, dirc, chan, &stat, NULL, NULL, NULL, NULL);
	if (ret != DMA_SUCCESS) {
		DEV_TRACE(pdev, "Failed to get DMA channel state:\n%s\n",
			 HalDmaGetErrInfo(ret));
			 status = STATUS_UNSUCCESSFUL;
		goto CLEANUP;
	}
	if (stat == CHAN_RUNNING) {
		DEV_TRACE(pdev, "DMA %s channel %d is still running.\n",
			 dirc == DMA_WRITE ? "write" : "read", chan);
		status = STATUS_UNSUCCESSFUL;
		goto CLEANUP;
	}

	pChInfEx->TotalSize = 0;
	pChInfEx->SgNent = 0;

	/* Single block transfer */
	PHYADDR src;
	PHYADDR dst;
	if (dirc == DMA_WRITE) {
		blkSize = size;
		src.QuadPart = ep_addr;
		dst.QuadPart = host_addr;

		DEV_TRACE(pdev, "%s: DMA_WRITE, ep_addr=0x%llx, dma_addr=0x%llx, blkSize=0x%x\n",
			__func__, ep_addr, host_addr, size);

		ret = HalDmaSingleBlockWrite(pdrsc, chan, src, dst, blkSize, wei, queue);
	} else {
		blkSize = size;
		src.QuadPart = host_addr;
		dst.QuadPart = ep_addr;

		DEV_TRACE(pdev, "%s: DMA_READ, ep_addr=0x%llx, dma_addr=0x%llx, blkSize=0x%x\n",
			__func__, ep_addr, host_addr, size);

		ret = HalDmaSingleBlockRead(pdrsc, chan, src, dst, blkSize, wei, queue);
	}

	pChInfEx->tick_count_start = jiffies;

	/* Transfer request is submitted, and we need to check the return value to
	* see if everything goes fine.
	*/
	if (ret == DMA_SUCCESS) {
		if (queue)
		    DEV_TRACE(pdev, "OK! DMA %s on channel %d is queued up.\n",
			    dirc == DMA_WRITE ? "write" : "read", chan);
		else
		    DEV_TRACE(pdev, "OK! DMA %s on channel %d is started.\n",
			    dirc == DMA_WRITE ? "write" : "read", chan);
	} else {
		DEV_TRACE(pdev, "Failed to start DMA %s:\n%s\n",
			dirc == DMA_WRITE ? "write" : "read",
			HalDmaGetErrInfo(ret));
			status = STATUS_UNSUCCESSFUL;
	}

CLEANUP:

	return status;
}
EXPORT_SYMBOL_GPL(IoctlDmaRW2);

/**
 * DMA read/write operation with scatter-gather table
 *
 * @param[in] pdev        RPP device structure
 * @param[in] Chan        DMA channel number
 * @param[in] write       DMA direction (DMA_WRITE or DMA_READ)
 * @param[in] ep_addr     Endpoint address
 * @param[in] sgt         Scatter-gather table
 * @param[in] dma_mapped  Whether sgt is already DMA mapped
 * @param[in] timeout_ms  Timeout in milliseconds
 * @return STATUS_SUCCESS on success, error code on failure
 */
UINT32 IoctlDmaRW3(struct rpp_dev *pdev, UINT8 Chan, DMA_DIRC write, u64 ep_addr, struct sg_table *sgt, bool dma_mapped, u32 timeout_ms)
{
	PDEVICE_EXTENSION pDevExt;
	UINT32 status = STATUS_SUCCESS;
	HAL_DMA_RET ret;
	PDMA_RSC pdrsc;
	DMA_DIRC dirc = write;
	UINT32 lle = 0;
	UINT8 chan = Chan;
	UINT32 blkSize;
	BOOLEAN queue = 0;
	BOOLEAN isDdr = 1;
	UINT8 wm = 0;
	UINT8 wei = 0;   /* actual weights are 0 to 31 */
	UINT32 recyc = 1;
	DMA_CHAN_STATUS stat;
	PCHAN_INFO_EX pChInfEx;
	struct scatterlist *sg;
	int nents;

	/* Input parameter validation */
	if (!pdev) {
		ERROR_PRINT("Invalid device pointer\n");
		return STATUS_UNSUCCESSFUL;
	}

	if (!sgt) {
		ERROR_PRINT("Invalid scatter-gather table\n");
		return STATUS_UNSUCCESSFUL;
	}

	pDevExt = &pdev->RPP_ext;
	pdrsc = &pDevExt->DmaRsc;

	/* Validate channel number */
	if ((dirc == DMA_WRITE && chan >= pDevExt->DmaRsc.WrChans) ||
	    (dirc == DMA_READ && chan >= pDevExt->DmaRsc.RdChans)) {
		DEV_ERROR(pdev, "Invalid channel number: %d\n", chan);
		return STATUS_UNSUCCESSFUL;
	}

	sg = sgt->sgl;

#if 0
	if (pcmd->Len == 0)
		blkSize = 1;
	DEV_TRACE(pdev, "ENTER %d\n", blkSize);
#endif

	/* Input parameter validation already done above */

	pChInfEx = (dirc == DMA_WRITE) ? &pDevExt->WrChInfEx[chan]
				       : &pDevExt->RdChInfEx[chan];

	/* Check channel state to make sure it's not running, otherwise we can't
	* start a new transfer.
	*/
	ret = HalDmaState(pdrsc, dirc, chan, &stat, NULL, NULL, NULL, NULL);
	if (ret != DMA_SUCCESS) {
		DEV_TRACE(pdev, "Failed to get DMA channel state:\n%s\n",
			 HalDmaGetErrInfo(ret));
			 status = STATUS_UNSUCCESSFUL;
		goto CLEANUP;
	}
	if (stat == CHAN_RUNNING) {
		DEV_TRACE(pdev, "DMA %s channel %d is still running.\n",
			 dirc == DMA_WRITE ? "write" : "read", chan);
		status = STATUS_UNSUCCESSFUL;
		goto CLEANUP;
	}

	/* Check if DDR mode is supported by the endpoint. */
	/*  if (isDdr && (pDevExt->ChunkLen != pDevExt->RamSize / 64 / 4)) { */
	if (!isDdr) {
		DEV_TRACE(pdev, "DDR memory is not available on EP.\n");
		status = STATUS_UNSUCCESSFUL;
		goto CLEANUP;
	}

	pChInfEx->TotalSize = 0;
	pChInfEx->SgNent = 0;

	if (!dma_mapped) {
		nents = pci_map_sg(pdev->pdev, sg, sgt->orig_nents, PCI_DMA_BIDIRECTIONAL);
		if (!nents) {
			DEV_TRACE(pdev, "map sgl failed, sgt 0x%p.\n", sgt);
			return -EIO;
		}
		sgt->nents = nents;
		DEV_INFO(pdev, "pdev=%p, orig_nents=0x%x, nents=0x%x\n", pdev->pdev, sgt->orig_nents, sgt->nents);
	} else {
		/* Validate that scatter-gather table is already mapped */
		if (!sgt->nents) {
			DEV_ERROR(pdev, "Invalid scatter-gather table: nents is zero\n");
			return -EINVAL;
		}
	}

	sgt_dump(sgt);

	/* lle = number of data elements + Link list Elements */
	lle = sgt->nents + 1;

	if (sgt->nents == 1) {
		/* Single block transfer */
		PHYADDR src;
		PHYADDR dst;
		if (dirc == DMA_WRITE) {
			blkSize = sg_dma_len(sg);
			src.QuadPart = ep_addr;
			src.LowPart = (UINT32)ep_addr;
			src.HighPart = (UINT32)(ep_addr>>32);
			dst.QuadPart = sg_dma_address(sg);
			dst.LowPart = (UINT32)dst.QuadPart;
			dst.HighPart = (UINT32)(dst.QuadPart>>32);

			DEV_TRACE(pdev, "%s: ep_addr=0x%llx, dma_addr=0x%llx, blkSize=0x%x\n",
				__func__, ep_addr, sg_dma_address(sg), sg_dma_len(sg));

			ret = HalDmaSingleBlockWrite(pdrsc, chan, src, dst, blkSize, wei, queue);
		} else {
			blkSize = sg_dma_len(sg);
			src.QuadPart = sg_dma_address(sg);
			src.LowPart = (UINT32)src.QuadPart;
			src.HighPart = (UINT32)(src.QuadPart>>32);
			dst.QuadPart = ep_addr;
			dst.LowPart = (UINT32)ep_addr;
			dst.HighPart = (UINT32)(ep_addr>>32);

			DEV_TRACE(pdev, "%s: ep_addr=0x%llx, dma_addr=0x%llx, blkSize=0x%x\n",
				__func__, ep_addr, sg_dma_address(sg), sg_dma_len(sg));

			ret = HalDmaSingleBlockRead(pdrsc, chan, src, dst, blkSize, wei, queue);
		}
	} else {
		/* Multi block transfer */
		wm = 0;

		pDevExt->sgt = sgt;
		pDevExt->RamPa.QuadPart = ep_addr;
		pDevExt->RamPa.LowPart = (UINT32)pDevExt->RamPa.QuadPart;
		pDevExt->RamPa.HighPart = (UINT32)(pDevExt->RamPa.QuadPart>>32);
		if (dirc == DMA_WRITE) {
			ret = HalDmaMultiBlockWrite(pdrsc, chan, lle, wm, recyc, wei, queue,
						    RppProducerFunc2, pDevExt);
		} else {
			ret = HalDmaMultiBlockRead(pdrsc, chan, lle, wm, recyc, wei, queue,
						   RppProducerFunc2, pDevExt);
		}
	}

	pChInfEx->tick_count_start = jiffies;

	/* Transfer request is submitted, and we need to check the return value to
	* see if everything goes fine.
	*/
	if (ret == DMA_SUCCESS) {
		if (queue)
		    DEV_TRACE(pdev, "OK! DMA %s on channel %d is queued up.\n",
			    dirc == DMA_WRITE ? "write" : "read", chan);
		else
		    DEV_TRACE(pdev, "OK! DMA %s on channel %d is started.\n",
			    dirc == DMA_WRITE ? "write" : "read", chan);
	} else {
		DEV_TRACE(pdev, "Failed to start DMA %s:\n%s\n",
			dirc == DMA_WRITE ? "write" : "read",
			HalDmaGetErrInfo(ret));
			status = STATUS_UNSUCCESSFUL;
	}

CLEANUP:

	return status;
}
EXPORT_SYMBOL_GPL(IoctlDmaRW3);


/**
 * DMA read/write operation with ping-pong channels and block info
 *
 * @param[in] pdev        RPP device structure
 * @param[in] Chanping    Ping channel number
 * @param[in] Chanpong    Pong channel number
 * @param[in] write       DMA direction (DMA_WRITE or DMA_READ)
 * @param[in] ep_addr     Endpoint address
 * @param[in] info        DMA blocks information
 * @param[in] timeout_ms  Timeout in milliseconds
 * @return STATUS_SUCCESS on success, error code on failure
 */
UINT32 IoctlDmaRW4(struct rpp_dev *pdev, UINT8 Chanping, UINT8 Chanpong, DMA_DIRC write, u64 ep_addr, PDMA_BLKS_INFO info, u32 timeout_ms)
{
	PDEVICE_EXTENSION pDevExt;
	UINT32 status = STATUS_SUCCESS;
	HAL_DMA_RET ret;
	PDMA_RSC pdrsc;
	DMA_DIRC dirc = write;
	UINT32 lle = 0;
	UINT8 ping = Chanping;
	UINT8 pong = Chanpong;
	UINT32 blkSize;
	BOOLEAN queue = 0;
	BOOLEAN isDdr = 1;
	UINT8 wm = 0;
	UINT8 wei = 0;   /* actual weights are 0 to 31 */
	UINT32 recyc = 1;
	DMA_CHAN_STATUS stat;
	PCHAN_INFO_EX pChInfEx_ping;
	PCHAN_INFO_EX pChInfEx_pong;
	PBLK_ELEMENT start_blk;

	/* Input parameter validation */
	if (!pdev) {
		ERROR_PRINT("Invalid device pointer\n");
		return STATUS_UNSUCCESSFUL;
	}

	if (!info) {
		DEV_ERROR(pdev, "%s: Transfer blocks info is invalid.\n", __func__);
		return STATUS_UNSUCCESSFUL;
	}

	if (!info->mapped_blk || info->vail_num == 0) {
		DEV_ERROR(pdev, "%s: Invalid blocks info.\n", __func__);
		return STATUS_UNSUCCESSFUL;
	}

	pDevExt = &pdev->RPP_ext;
	pdrsc = &pDevExt->DmaRsc;

	/* Validate channel numbers */
	if ((dirc == DMA_WRITE && (ping >= pDevExt->DmaRsc.WrChans || pong >= pDevExt->DmaRsc.WrChans)) ||
	    (dirc == DMA_READ && (ping >= pDevExt->DmaRsc.RdChans || pong >= pDevExt->DmaRsc.RdChans))) {
		DEV_ERROR(pdev, "Invalid channel numbers: ping=%d pong=%d\n", ping, pong);
		return STATUS_UNSUCCESSFUL;
	}

	start_blk = info->mapped_blk + info->start;

	/* Check ping channel state to make sure it's not running */
	pChInfEx_ping = (dirc == DMA_WRITE) ? &pDevExt->WrChInfEx[ping]
				       : &pDevExt->RdChInfEx[ping];

	ret = HalDmaState(pdrsc, dirc, ping, &stat, NULL, NULL, NULL, NULL);
	if (ret != DMA_SUCCESS) {
		DEV_ERROR(pdev, "Failed to get DMA ping channel state:\n%s\n",
			 HalDmaGetErrInfo(ret));
		status = STATUS_UNSUCCESSFUL;
		goto CLEANUP;
	}
	if (stat == CHAN_RUNNING) {
		DEV_ERROR(pdev, "DMA %s ping channel %d is still running.\n",
			 dirc == DMA_WRITE ? "write" : "read", ping);
		status = STATUS_UNSUCCESSFUL;
		goto CLEANUP;
	}

	/* Check pong channel state to make sure it's not running */
	pChInfEx_pong = (dirc == DMA_WRITE) ? &pDevExt->WrChInfEx[pong]
				       : &pDevExt->RdChInfEx[pong];

	ret = HalDmaState(pdrsc, dirc, pong, &stat, NULL, NULL, NULL, NULL);
	if (ret != DMA_SUCCESS) {
		DEV_ERROR(pdev, "Failed to get DMA pong channel state:\n%s\n",
			 HalDmaGetErrInfo(ret));
		status = STATUS_UNSUCCESSFUL;
		goto CLEANUP;
	}
	if (stat == CHAN_RUNNING) {
		DEV_ERROR(pdev, "DMA %s pong channel %d is still running.\n",
			 dirc == DMA_WRITE ? "write" : "read", pong);
		status = STATUS_UNSUCCESSFUL;
		goto CLEANUP;
	}

	/* Check if DDR mode is supported by the endpoint */
	if (!isDdr) {
		DEV_ERROR(pdev, "DDR memory is not available on EP.\n");
		status = STATUS_UNSUCCESSFUL;
		goto CLEANUP;
	}

	pChInfEx_ping->TotalSize = 0;
	pChInfEx_ping->SgNent = 0;
	pChInfEx_pong->TotalSize = 0;
	pChInfEx_pong->SgNent = 0;

	/*  lle = number of data elements + Link list Elements */
	lle = info->vail_num + 1;

	if (info->vail_num == 1) {
		/* Single block transfer */
		/*  TODO */
		PHYADDR src;
		PHYADDR dst;
		if (dirc == DMA_WRITE) {
			blkSize = info->end_size;
			src.QuadPart = ep_addr;
			src.LowPart = (UINT32)ep_addr;
			src.HighPart = (UINT32)(ep_addr>>32);
			dst.QuadPart = start_blk->dma_address + info->start_offs;
			dst.LowPart = (UINT32)dst.QuadPart;
			dst.HighPart = (UINT32)(dst.QuadPart>>32);

			DEV_TRACE(pdev, "%s: ep_addr=0x%llx, dma_addr=0x%llx, blkSize=0x%x\n",
				__func__, ep_addr, dst.QuadPart, blkSize);

			ret = HalDmaSingleBlockWrite(pdrsc, ping, src, dst, blkSize, wei, queue);
		} else {
			blkSize = info->end_size;
			src.QuadPart = start_blk->dma_address + info->start_offs;
			src.LowPart = (UINT32)src.QuadPart;
			src.HighPart = (UINT32)(src.QuadPart>>32);
			dst.QuadPart = ep_addr;
			dst.LowPart = (UINT32)ep_addr;
			dst.HighPart = (UINT32)(ep_addr>>32);

			DEV_TRACE(pdev, "%s: ep_addr=0x%llx, dma_addr=0x%llx, blkSize=0x%x\n",
				__func__, ep_addr, src.QuadPart, blkSize);

			ret = HalDmaSingleBlockRead(pdrsc, ping, src, dst, blkSize, wei, queue);
		}
	} else {
		/* Multi block transfer */
		wm = 0;

		pDevExt->blk_info = info;
		pDevExt->RamPa.QuadPart = ep_addr;
		pDevExt->RamPa.LowPart = (UINT32)pDevExt->RamPa.QuadPart;
		pDevExt->RamPa.HighPart = (UINT32)(pDevExt->RamPa.QuadPart>>32);
		if (dirc == DMA_WRITE) {
			ret = HalDmaMultiBlockWrite2(pdrsc, ping, pong, lle, wm, recyc, wei, queue,
						    RppProducerCB, pDevExt);
		} else {
			ret = HalDmaMultiBlockRead2(pdrsc, ping, pong, lle, wm, recyc, wei, queue,
						   RppProducerCB, pDevExt);
		}
	}

	pChInfEx_ping->tick_count_start = jiffies;
	pChInfEx_pong->tick_count_start = jiffies;

	/* Transfer request is submitted, and we need to check the return value to
	* see if everything goes fine.
	*/
	if (ret == DMA_SUCCESS) {
		if (queue)
		    DEV_TRACE(pdev, "OK! DMA %s on ping channel %d pong channel %d is queued up.\n",
			    dirc == DMA_WRITE ? "write" : "read", ping, pong);
		else
		    DEV_TRACE(pdev, "OK! DMA %s on ping channel %d pong channel %d is started.\n",
			    dirc == DMA_WRITE ? "write" : "read", ping, pong);
	} else {
		DEV_TRACE(pdev, "Failed to start DMA %s:\n%s\n",
			dirc == DMA_WRITE ? "write" : "read",
			HalDmaGetErrInfo(ret));
			status = STATUS_UNSUCCESSFUL;
	}

CLEANUP:

	return status;
}
EXPORT_SYMBOL_GPL(IoctlDmaRW4);

UINT32 IoctlDmaRW4_1(struct rpp_dev *pdev, UINT8 ch, DMA_DIRC write, u64 ep_addr, PDMA_BLKS_INFO info, u32 timeout_ms)
{
	PDEVICE_EXTENSION pDevExt = &pdev->RPP_ext;
	UINT32 status = STATUS_SUCCESS;
	HAL_DMA_RET ret;
	PDMA_RSC pdrsc = &pDevExt->DmaRsc;
	DMA_DIRC dirc = write;
	UINT32 lle = 0; // pcmd->LLElements;
	UINT8 chan = ch;
	UINT32 blkSize; //  = pcmd->Len;
	BOOLEAN queue = 0;
	BOOLEAN isDdr = 1;
	UINT8 wm = 0;
	UINT8 wei = 0;   // actual weights are 0 to 31
	UINT32 recyc = 1;
	BOOLEAN chk = FALSE;
	DMA_CHAN_STATUS stat;
	PCHAN_INFO_EX pChInfEx_chan;
	static BOOLEAN flip = TRUE;
	PBLK_ELEMENT start_blk = info->mapped_blk + info->start;

	if (info == NULL) {
		ERROR_PRINT("%s: Transfer sg table is invalid.\n", __func__);
		status = STATUS_UNSUCCESSFUL;
		goto CLEANUP;
	}

	/* Check ping channel state to make sure it's not running, otherwise we can't
	* start a new transfer.
	*/
	pChInfEx_chan = (dirc == DMA_WRITE) ? &pDevExt->WrChInfEx[chan]
				       : &pDevExt->RdChInfEx[chan];

	ret = HalDmaState(pdrsc, dirc, chan, &stat, NULL, NULL, NULL, NULL);
	if (ret != DMA_SUCCESS) {
		ERROR_PRINT("Failed to get DMA channel state:\n%s\n",
			 HalDmaGetErrInfo(ret));
			 status = STATUS_UNSUCCESSFUL;
		goto CLEANUP;
	}
	if (stat == CHAN_RUNNING) {
		ERROR_PRINT("DMA %s channel %d is still running.\n",
			 dirc == DMA_WRITE ? "write" : "read", chan);
		status = STATUS_UNSUCCESSFUL;
		goto CLEANUP;
	}

	/* Check if DDR mode is supported by the endpoint. */
	// if (isDdr && (pDevExt->ChunkLen != pDevExt->RamSize / 64 / 4)) {
	if (!isDdr) {
		ERROR_PRINT("DDR memory is not available on EP.\n");
		status = STATUS_UNSUCCESSFUL;
		goto CLEANUP;
	}

	pChInfEx_chan->TotalSize = 0;
	pChInfEx_chan->SgNent = 0;

	// lle = number of data elements + Link list Elements
	lle = info->vail_num + 1;

	if (info->vail_num == 1) {
		/* Single block transfer */
		// TODO
		PHYADDR src;
		PHYADDR dst;
		if (dirc == DMA_WRITE) {
			blkSize = info->end_size;
			src.QuadPart = ep_addr;
			src.LowPart = (UINT32)ep_addr;
			src.HighPart = (UINT32)(ep_addr>>32);
			dst.QuadPart = start_blk->dma_address + info->start_offs;
			dst.LowPart = (UINT32)dst.QuadPart;
			dst.HighPart = (UINT32)(dst.QuadPart>>32);

			DTRACE("%s: ep_addr=0x%llx, dma_addr=0x%llx, blkSize=0x%x\n",
				__func__, ep_addr, dst.QuadPart, blkSize);

			ret = HalDmaSingleBlockWrite(pdrsc, chan, src, dst, blkSize, wei, queue);
		} else {
			blkSize = info->end_size;
			src.QuadPart = start_blk->dma_address + info->start_offs;
			src.LowPart = (UINT32)src.QuadPart;
			src.HighPart = (UINT32)(src.QuadPart>>32);
			dst.QuadPart = ep_addr;
			dst.LowPart = (UINT32)ep_addr;
			dst.HighPart = (UINT32)(ep_addr>>32);

			DTRACE("%s: ep_addr=0x%llx, dma_addr=0x%llx, blkSize=0x%x\n",
				__func__, ep_addr, src.QuadPart, blkSize);

			ret = HalDmaSingleBlockRead(pdrsc, chan, src, dst, blkSize, wei, queue);
		}
	} else {
		/* Multi block transfer */
		// wm = wm == 0 ? (lle / 2 - 1) : wm;
		wm = 0;

		pDevExt->blk_info = info;
		pDevExt->RamPa.QuadPart = ep_addr;
		pDevExt->RamPa.LowPart = (UINT32)pDevExt->RamPa.QuadPart;
		pDevExt->RamPa.HighPart = (UINT32)(pDevExt->RamPa.QuadPart>>32);
		if (dirc == DMA_WRITE) {
			ret = HalDmaMultiBlockWrite2_1(pdrsc, chan, lle, wm, recyc, wei, queue,
						    RppProducerCB, pDevExt);
		} else {
			ret = HalDmaMultiBlockRead2_1(pdrsc, chan, lle, wm, recyc, wei, queue,
						   RppProducerCB, pDevExt);
		}
	}

	pChInfEx_chan->tick_count_start = jiffies;

	/* Transfer request is submitted, and we need to check the return value to
	* see if everything goes fine.
	*/
	if (ret == DMA_SUCCESS) {
		if (queue)
		    DTRACE("OK! DMA %s on channel %d is queued up.\n",
			    dirc == DMA_WRITE ? "write" : "read", chan);
		else
		    DTRACE("OK! DMA %s on channel %d is started.\n",
			    dirc == DMA_WRITE ? "write" : "read", chan);
	} else {
		DTRACE("Failed to start DMA %s:\n%s\n",
			dirc == DMA_WRITE ? "write" : "read",
			HalDmaGetErrInfo(ret));
			status = STATUS_UNSUCCESSFUL;
	}

CLEANUP:

	return status;
}
EXPORT_SYMBOL_GPL(IoctlDmaRW4_1);

UINT32 rpp_dma_rw5_select_route(UINT8 ch, const DMA_BLKS_INFO *info, UINT8 *chan, UINT8 *pong, RPP_DMA_RW5_ROUTE *route)
{
	if (!info || !info->mapped_blk || info->vail_num == 0 || !chan || !route)
		return STATUS_UNSUCCESSFUL;

	*route = RPP_DMA_RW5_ROUTE_INVALID;
	*chan = ch;
	if (pong)
		*pong = 0;

	switch (ch) {
	case 0:
		if (info->vail_num == 1) {
			*route = RPP_DMA_RW5_ROUTE_SINGLE_DESC;
		} else {
			*route = RPP_DMA_RW5_ROUTE_PINGPONG_DESC;
			if (pong)
				*pong = 1;
		}
		break;
	case 2:
	case 3:
		*route = RPP_DMA_RW5_ROUTE_SINGLE_DESC;
		break;
	default:
		return STATUS_UNSUCCESSFUL;
	}

	return STATUS_SUCCESS;
}
EXPORT_SYMBOL_GPL(rpp_dma_rw5_select_route);

static UINT32 IoctlDmaRW5SingleDesc(struct rpp_dev *pdev, UINT8 ch, DMA_DIRC write, u64 ep_addr, PDMA_BLKS_INFO info, u32 timeout_ms)
{
	PDEVICE_EXTENSION pDevExt;
	UINT32 status = STATUS_SUCCESS;
	HAL_DMA_RET ret;
	PDMA_RSC pdrsc;
	DMA_DIRC dirc = write;
	UINT32 lle;
	UINT8 chan = ch;
	BOOLEAN queue = 0;
	BOOLEAN isDdr = 1;
	UINT8 wm = 0;
	UINT8 wei = 0;
	UINT32 recyc = 1;
	DMA_CHAN_STATUS stat;
	PCHAN_INFO_EX pChInfEx_chan;

	if (!pdev) {
		ERROR_PRINT("Invalid device pointer\n");
		return STATUS_UNSUCCESSFUL;
	}

	if (!info || !info->mapped_blk || info->vail_num == 0) {
		DEV_ERROR(pdev, "%s: Invalid blocks info.\n", __func__);
		return STATUS_UNSUCCESSFUL;
	}

	pDevExt = &pdev->RPP_ext;
	pdrsc = &pDevExt->DmaRsc;

	if ((dirc == DMA_WRITE && chan >= pDevExt->DmaRsc.WrChans) ||
	    (dirc == DMA_READ && chan >= pDevExt->DmaRsc.RdChans)) {
		DEV_ERROR(pdev, "%s: Invalid channel number: chan=%d\n", __func__, chan);
		return STATUS_UNSUCCESSFUL;
	}

	pChInfEx_chan = (dirc == DMA_WRITE) ? &pDevExt->WrChInfEx[chan]
				       : &pDevExt->RdChInfEx[chan];

	ret = HalDmaState(pdrsc, dirc, chan, &stat, NULL, NULL, NULL, NULL);
	if (ret != DMA_SUCCESS) {
		DEV_ERROR(pdev, "Failed to get DMA channel state:\n%s\n",
			 HalDmaGetErrInfo(ret));
		status = STATUS_UNSUCCESSFUL;
		goto CLEANUP;
	}
	if (stat == CHAN_RUNNING) {
		DEV_ERROR(pdev, "DMA %s channel %d is still running.\n",
			 dirc == DMA_WRITE ? "write" : "read", chan);
		status = STATUS_UNSUCCESSFUL;
		goto CLEANUP;
	}

	if (!isDdr) {
		DEV_ERROR(pdev, "DDR memory is not available on EP.\n");
		status = STATUS_UNSUCCESSFUL;
		goto CLEANUP;
	}

	pChInfEx_chan->TotalSize = 0;
	pChInfEx_chan->SgNent = 0;

	lle = info->vail_num + 1;
	pDevExt->blk_info = info;
	pDevExt->RamPa.QuadPart = ep_addr;
	pDevExt->RamPa.LowPart = (UINT32)pDevExt->RamPa.QuadPart;
	pDevExt->RamPa.HighPart = (UINT32)(pDevExt->RamPa.QuadPart >> 32);

	if (dirc == DMA_WRITE) {
		ret = HalDmaMultiBlockWrite2_1(pdrsc, chan, lle, wm, recyc, wei, queue,
					    RppProducerCB, pDevExt);
	} else {
		ret = HalDmaMultiBlockRead2_1(pdrsc, chan, lle, wm, recyc, wei, queue,
					   RppProducerCB, pDevExt);
	}

	pChInfEx_chan->tick_count_start = jiffies;

	if (ret == DMA_SUCCESS) {
		if (queue)
			DEV_TRACE(pdev, "OK! DMA %s on channel %d is queued up by RW5 desc.\n",
				dirc == DMA_WRITE ? "write" : "read", chan);
		else
			DEV_TRACE(pdev, "OK! DMA %s on channel %d is started by RW5 desc.\n",
				dirc == DMA_WRITE ? "write" : "read", chan);
	} else {
		DEV_TRACE(pdev, "Failed to start DMA %s by RW5 desc:\n%s\n",
			dirc == DMA_WRITE ? "write" : "read",
			HalDmaGetErrInfo(ret));
		status = STATUS_UNSUCCESSFUL;
	}

CLEANUP:
	return status;
}

UINT32 IoctlDmaRW5(struct rpp_dev *pdev, UINT8 ch, DMA_DIRC write, u64 ep_addr, PDMA_BLKS_INFO info, u32 timeout_ms)
{
	RPP_DMA_RW5_ROUTE route;
	UINT8 chan;
	UINT8 pong;
	UINT32 status;

	status = rpp_dma_rw5_select_route(ch, info, &chan, &pong, &route);
	if (status != STATUS_SUCCESS)
		return status;

	if (rw5_route_trace) {
		DEV_INFO(pdev, "%s: ch=%u vail_num=%u route=%d chan=%u pong=%u\n",
			 __func__, ch, info->vail_num, route, chan, pong);
	}

	switch (route) {
	case RPP_DMA_RW5_ROUTE_SINGLE_DESC:
		return IoctlDmaRW5SingleDesc(pdev, chan, write, ep_addr, info, timeout_ms);
	case RPP_DMA_RW5_ROUTE_PINGPONG_DESC:
		return IoctlDmaRW4(pdev, chan, pong, write, ep_addr, info, timeout_ms);
	default:
		return STATUS_UNSUCCESSFUL;
	}
}
EXPORT_SYMBOL_GPL(IoctlDmaRW5);

/**
 * Handler for DMA_CMD_INIT IOCTL command.
 *
 * This function allocates the system buffers used by DMA transfer as source
 * and destination, and calls HAL initialization API to set MSI address and
 * data. If the DMA core works in loop back mode, an extra loop back system
 * buffers is allocated too.
 *
 * @param[in,out] pDevExt    The device extension object.
 * @param[in,out] pcmd       The command object containing all arguments of
 *                          requested command. Returning messages are also
 *                          stored in this object.
 * @return NTSTATUS value to indicate success or failure.
 * @see HalDmaInit
 * @ingroup hal_caller
 */
static UINT32 IoctlDmaInit(struct rpp_dev *pdev, PDEVICE_EXTENSION pDevExt, PCMD_INFO pcmd)
{
	UINT32 status = STATUS_SUCCESS;
	UINT32 i;
	HAL_DMA_RET ret;
	UINT32 ddrStatus;
	UINT32 llSlots[4] = {CHUNK_ID_LLA, CHUNK_ID_LLB, CHUNK_ID_LLC, CHUNK_ID_LLD};
	XDATA_RET xret;

	DEV_TRACE(pdev, "ENTER\n");

	if (EDMA) {
		struct msi_msg msg;

		if (pDevExt->ChunkLen) {
			status = STATUS_FAIL;
			DEPRINTF(pcmd->ResMsg, MAX_MSG_SIZE,
				 "Device was already initialized!\n");
			goto CLEANUP;
		}

		if (pdev->pdev->msi_enabled)
			DEV_DEBUG(pdev, "IRQ MSI selected\n");
		else if (pdev->pdev->msix_enabled)
			DEV_DEBUG(pdev, "IRQ MSI-X selected\n");

		get_cached_msi_msg(pci_irq_vector(pdev->pdev, 0), &msg);

		pDevExt->DmaRsc.MsiAddr.HighPart = msg.address_hi;
		pDevExt->DmaRsc.MsiAddr.LowPart = msg.address_lo;
		if (IRQ_NUM < 32) {
				pDevExt->DmaRsc.MsiData = msg.data;
		} else {
				pDevExt->DmaRsc.MsiData = msg.data + 22;
		}

		DEV_DEBUG(pdev, "DmaRsc.MsiAddr_h=0x%.8x DmaRsc.MsiAddr_l=0x%.8x DmaRsc.MsiData=0x%.8x\n",
			   pDevExt->DmaRsc.MsiAddr.HighPart, pDevExt->DmaRsc.MsiAddr.LowPart,
			   pDevExt->DmaRsc.MsiData);

		/* Call HAL init function to reset DMA logic and renew MSI settings.
		 * We can also get the number of enabled write/read channels, which is
		 * used to segment the memory.
		 */
		ret = HalDmaInit(&pDevExt->DmaRsc);
		if (ret != DMA_SUCCESS)	{
			DEPRINTF(pcmd->ResMsg, MAX_MSG_SIZE,
				 "Failed to initial EDMA device:\n%s\n",
				 HalDmaGetErrInfo(ret));
			status = STATUS_FAIL;
			goto CLEANUP;
		}
	}

	/* Calculate IO memory size.
	 * 1) When DDR mode is enabled
	 * The highest 6 bits of available RamSize are used as chunk id, so the
	 * size of each chunk is RamSize/(2^6). That's to say there are 64 chunks.
	 * 2) When DDR mode is NOT enabled
	 * The highest 5 bits of available RamSize are used as chunk id, so the
	 * size of each chunk is RamSize/(2^5). That's to say there are 32 chunks.
	 *
	 * In both cases, we at least use 21 chunks: 4 chunks for linked list space
	 * (local RAM only), 16 chunks for DMA channels, and 1 chunk for XDATA.
	 *
	 * But for 1), we also use 2 additional chunks started from the second half
	 * of the space: 1 chunk for DDR W0 and 1 chunk for DDR R0.
	 * See CHUNK_ID enum.
	 */
	ddrStatus = RPP_READ_UINT32((PUINT8)pdev->bar[XDATA_BAR] + 0x24);
	if ((ddrStatus >> 31))
		pDevExt->ChunkLen = pDevExt->RamSize / 64 / 4;
	else
		pDevExt->ChunkLen = pDevExt->RamSize / 32 / 4;

	DEV_DEBUG(pdev, "ChunkLen=%d RamSize=%d\n", pDevExt->ChunkLen, pDevExt->RamSize);

	if (EDMA) {
		DEV_DEBUG(pdev, "DmaRsc.WrChans=%d DmaRsc.RdChans=%d\n", pDevExt->DmaRsc.WrChans, pDevExt->DmaRsc.RdChans);

		status = BatchAllocDmaMem(pdev, pDevExt->DmaRsc.WrChans, pDevExt->DmaRsc.RdChans);

		if (status != STATUS_SUCCESS) {
			DEPRINTF(pcmd->ResMsg, MAX_MSG_SIZE,
				"Failed to allocate continuous system memory for DMA!\n");
			goto CLEANUP;
		}

		/* Set linked list addresses */
		for (i = 0; i < 16; i++) {
			if (i % 4 == 0) {
				pDevExt->DmaRsc.LLPhyAddr[i].QuadPart =
					pDevExt->RamPa.QuadPart +
					llSlots[i/4] * pDevExt->ChunkLen * 4;
				pDevExt->DmaRsc.LLVirAddr[i] =
					pDevExt->RamVa + llSlots[i/4] * pDevExt->ChunkLen;
				DEV_DEBUG(pdev, "pDevExt->RamPa.QuadPart=0x%llx, llSlots[%d]=0x%x\n",
					pDevExt->RamPa.QuadPart, i, llSlots[i/4]);
				DEV_DEBUG(pdev, "pDevExt->DmaRsc.LLPhyAddr[%d].QuadPart=0x%llx\n",
					i, pDevExt->DmaRsc.LLPhyAddr[i].QuadPart);
				DEV_DEBUG(pdev, "pDevExt->DmaRsc.LLVirAddr[%d]=0x%llx\n",
					i, pDevExt->DmaRsc.LLVirAddr[i]);
			} else {
				pDevExt->DmaRsc.LLPhyAddr[i].QuadPart =
					pDevExt->DmaRsc.LLPhyAddr[i-1].QuadPart + MAX_LL_LEN * 4;
				pDevExt->DmaRsc.LLVirAddr[i] =
					pDevExt->DmaRsc.LLVirAddr[i-1] + MAX_LL_LEN;
				DEV_DEBUG(pdev, "MAX_LL_LEN=0x%x\n", MAX_LL_LEN);
				DEV_DEBUG(pdev, "pDevExt->DmaRsc.LLPhyAddr[%d].QuadPart=0x%llx\n",
					i, pDevExt->DmaRsc.LLPhyAddr[i].QuadPart);
				DEV_DEBUG(pdev, "pDevExt->DmaRsc.LLVirAddr[%d]=0x%llx\n",
					i, pDevExt->DmaRsc.LLVirAddr[i]);
			}
		}
	}

	/* Set xfer done callback */
	pDevExt->DmaRsc.XferDoneFunc = RppXferDoneCallback;
	pDevExt->DmaRsc.XferDoneContext = pDevExt;

	/* XDATA init */
	if (XDATA) {
		pDevExt->xDataRsc.xDataLocMemSize = pDevExt->ChunkLen * 4;
		pDevExt->xDataRsc.xDataLocMemPa.QuadPart = pDevExt->RamPa.QuadPart +
			CHUNK_ID_XDATA * pDevExt->ChunkLen * 4;
		pDevExt->xDataRsc.xDataLocMemVa = pDevExt->RamVa + CHUNK_ID_XDATA
			* pDevExt->ChunkLen;
		pDevExt->xDataRsc.xDataMemSize = XDATA_BUF_SIZE;

		status = AllocProtocolMem(pdev, XDATA_BUF_SIZE, &pDevExt->xDataRsc.xDataMemVa, &pDevExt->xDataRsc.xDataBus, &pDevExt->xDataRsc.xDataMemPa);

		if (status != STATUS_SUCCESS) {
			DEPRINTF(pcmd->ResMsg, MAX_MSG_SIZE,
				"Failed to allocate contiguous system memory for XDATA!\n");
			goto CLEANUP;
		}
		xret = xDataInit(&pDevExt->xDataRsc, pDevExt->ReadMTU, pDevExt->WriteMTU);

		if (xret != XDATA_SUCCESS) {
			DEPRINTF(pcmd->ResMsg, MAX_MSG_SIZE,
				 "Failed to initialize XDATA engine\n");
			status = STATUS_FAIL;
			goto CLEANUP;
		}
	}

	DPRINTF(pcmd->ResMsg, MAX_MSG_SIZE, "OK! RPP is initialized.\n");

CLEANUP:
	return status;
}


UINT32 IoctlDmaInit2(struct rpp_dev *pdev, PDEVICE_EXTENSION pDevExt, PCMD_INFO pcmd, XFER_DONE_FUNC func)
{
	UINT32 status = STATUS_SUCCESS;
	UINT32 i;
	HAL_DMA_RET ret;
	UINT32 ddrStatus;
	UINT32 llSlots[4] = {CHUNK_ID_LLA, CHUNK_ID_LLB, CHUNK_ID_LLC, CHUNK_ID_LLD};
	XDATA_RET xret;

	DEV_TRACE(pdev, "ENTER\n");

	if (EDMA) {
		struct msi_msg msg;

		if (pdev->dma_initialized == 1) {
			status = STATUS_FAIL;
			DEV_DEBUG(pdev, "Device was already initialized!\n");
			goto CLEANUP;
		}

		if (pdev->pdev->msi_enabled)
			DEV_DEBUG(pdev, "IRQ MSI selected\n");
		else if (pdev->pdev->msix_enabled)
			DEV_DEBUG(pdev, "IRQ MSI-X selected\n");

		get_cached_msi_msg(pci_irq_vector(pdev->pdev, 0), &msg);

		pDevExt->DmaRsc.MsiAddr.HighPart = msg.address_hi;
		pDevExt->DmaRsc.MsiAddr.LowPart = msg.address_lo;
		if (IRQ_NUM < 32) {
				pDevExt->DmaRsc.MsiData = msg.data;
		} else {
				pDevExt->DmaRsc.MsiData = msg.data + 22;
		}
		DEV_DEBUG(pdev, "DmaRsc.MsiAddr_h=0x%.8x DmaRsc.MsiAddr_l=0x%.8x DmaRsc.MsiData=0x%.8x\n",
			   pDevExt->DmaRsc.MsiAddr.HighPart, pDevExt->DmaRsc.MsiAddr.LowPart,
			   pDevExt->DmaRsc.MsiData);

		/* Call HAL init function to reset DMA logic and renew MSI settings.
		 * We can also get the number of enabled write/read channels, which is
		 * used to segment the memory.
		 */
		ret = HalDmaInit(&pDevExt->DmaRsc);
		if (ret != DMA_SUCCESS)	{
			DEV_TRACE(pdev, "Failed to initial EDMA device:\n%s\n",
				 HalDmaGetErrInfo(ret));
			status = STATUS_FAIL;
			goto CLEANUP;
		}
	}

	/* Calculate IO memory size.
	 * 1) When DDR mode is enabled
	 * The highest 6 bits of available RamSize are used as chunk id, so the
	 * size of each chunk is RamSize/(2^6). That's to say there are 64 chunks.
	 * 2) When DDR mode is NOT enabled
	 * The highest 5 bits of available RamSize are used as chunk id, so the
	 * size of each chunk is RamSize/(2^5). That's to say there are 32 chunks.
	 *
	 * In both cases, we at least use 21 chunks: 4 chunks for linked list space
	 * (local RAM only), 16 chunks for DMA channels, and 1 chunk for XDATA.
	 *
	 * But for 1), we also use 2 additional chunks started from the second half
	 * of the space: 1 chunk for DDR W0 and 1 chunk for DDR R0.
	 * See CHUNK_ID enum.
	 */

	/* ddrStatus = RPP_READ_UINT32((PUINT8)pdev->bar[XDATA_BAR] + 0x24);
	if ((ddrStatus >> 31))
		pDevExt->ChunkLen = pDevExt->RamSize / 64 / 4;
	else
		pDevExt->ChunkLen = pDevExt->RamSize / 32 / 4; */

	/*  pDevExt->ChunkLen = pDevExt->RamSize / 32 / 4; */

	/*  DEV_DEBUG(pdev, "ChunkLen=%d RamSize=%d\n", pDevExt->ChunkLen, pDevExt->RamSize); */

	if (EDMA) {
		DEV_DEBUG(pdev, "DmaRsc.WrChans=%d DmaRsc.RdChans=%d\n", pDevExt->DmaRsc.WrChans, pDevExt->DmaRsc.RdChans);

		/* Set linked list addresses */
		for (i = 0; i < 16; i++) {
			pDevExt->DmaRsc.LLPhyAddr[i].QuadPart = pDevExt->RamPa.QuadPart + i*MAX_LL_LEN*4;
			pDevExt->DmaRsc.LLVirAddr[i] = pDevExt->RamVa +  i*MAX_LL_LEN;
			DEV_DEBUG(pdev, "MAX_LL_LEN=0x%x\n", MAX_LL_LEN);
			DEV_DEBUG(pdev, "pDevExt->DmaRsc.LLPhyAddr[%d].QuadPart=0x%llx\n",
				i, pDevExt->DmaRsc.LLPhyAddr[i].QuadPart);
			DEV_DEBUG(pdev, "pDevExt->DmaRsc.LLVirAddr[%d]=0x%llx\n",
				i, pDevExt->DmaRsc.LLVirAddr[i]);
		}
	}

	/* Set xfer done callback */
	pDevExt->DmaRsc.XferDoneFunc = func; /*  RppXferDoneCallback; */
	pDevExt->DmaRsc.XferDoneContext = pDevExt;

	pdev->dma_initialized = 1;

	DEV_TRACE(pdev, "OK! RPP is initialized.\n");

CLEANUP:
	return status;
}
EXPORT_SYMBOL_GPL(IoctlDmaInit2);


void RPP_Read_Header(struct pci_dev *pdev, PCI_COMMON_CONFIG *data)
{
	pci_read_config_word(pdev, PCI_VENDOR_ID, &data->VendorID);
	pci_read_config_word(pdev, PCI_DEVICE_ID, &data->DeviceID);
	pci_read_config_word(pdev, PCI_COMMAND, &data->Command);
	pci_read_config_word(pdev, PCI_STATUS, &data->Status);
	pci_read_config_byte(pdev, PCI_REVISION_ID, &data->RevisionID);
	pci_read_config_byte(pdev, PCI_CLASS_PROG, &data->ProgIf);
	pci_read_config_byte(pdev, 0xa, &data->SubClass);
	pci_read_config_byte(pdev, 0xb, &data->BaseClass);
	pci_read_config_byte(pdev, PCI_CACHE_LINE_SIZE, &data->CacheLineSize);
	pci_read_config_byte(pdev, PCI_LATENCY_TIMER, &data->LatencyTimer);
	pci_read_config_byte(pdev, PCI_HEADER_TYPE, &data->HeaderType);
	pci_read_config_byte(pdev, PCI_BIST, &data->BIST);

	pci_read_config_dword(pdev, PCI_BASE_ADDRESS_0, (u32 *)&data->u.type0.BaseAddresses[0]);
	pci_read_config_dword(pdev, PCI_BASE_ADDRESS_1, (u32 *)&data->u.type0.BaseAddresses[1]);
	pci_read_config_dword(pdev, PCI_BASE_ADDRESS_2, (u32 *)&data->u.type0.BaseAddresses[2]);
	pci_read_config_dword(pdev, PCI_BASE_ADDRESS_3, (u32 *)&data->u.type0.BaseAddresses[3]);
	pci_read_config_dword(pdev, PCI_BASE_ADDRESS_4, (u32 *)&data->u.type0.BaseAddresses[4]);
	pci_read_config_dword(pdev, PCI_BASE_ADDRESS_5, (u32 *)&data->u.type0.BaseAddresses[5]);

	pci_read_config_word(pdev, PCI_SUBSYSTEM_VENDOR_ID, &data->u.type0.SubVendorID);
	pci_read_config_word(pdev, PCI_SUBSYSTEM_ID, &data->u.type0.SubSystemID);
	pci_read_config_dword(pdev, PCI_ROM_ADDRESS, (u32 *)&data->u.type0.ROMBaseAddress);
	pci_read_config_byte(pdev, PCI_CAPABILITY_LIST, &data->u.type0.CapabilitiesPtr);

	pci_read_config_byte(pdev, PCI_INTERRUPT_LINE, &data->u.type0.InterruptLine);
	pci_read_config_byte(pdev, PCI_INTERRUPT_PIN, &data->u.type0.InterruptPin);
	pci_read_config_byte(pdev, PCI_MIN_GNT, &data->u.type0.MinimumGrant);
	pci_read_config_byte(pdev, PCI_MAX_LAT, &data->u.type0.MaximumLatency);

}

void RPP_rw_pci_cfg(struct pci_dev *pdev, INT d, UINT32 length, UINT32 offset, UCHAR *val)
{
	UINT32 i;

	if (d == 0) {/* 0 for read, 1 for write */
		switch (length)	{
		case 1:
			pci_read_config_byte(pdev, offset, val);
			break;
		case 2:
			pci_read_config_byte(pdev, offset, val);
			pci_read_config_byte(pdev, (offset+1), (val+1));
			break;
		case 4:
			pci_read_config_byte(pdev, offset, val);
			pci_read_config_byte(pdev, (offset+1), (val+1));
			pci_read_config_byte(pdev, (offset+2), (val+2));
			pci_read_config_byte(pdev, (offset+3), (val+3));
			break;
		default:
			for (i = 0; i < length; i++)
				pci_read_config_byte(pdev, (offset+i), (val+i));
		}
	} else {
		switch (length) {
		case 1:
			pci_write_config_byte(pdev, offset, *val);
			break;
		case 2:
			pci_write_config_byte(pdev, offset, *val);
			pci_write_config_byte(pdev, (offset+1), *(val+1));
			break;
		case 4:
			pci_write_config_byte(pdev, offset, *val);
			pci_write_config_byte(pdev, (offset+1), *(val+1));
			pci_write_config_byte(pdev, (offset+2), *(val+2));
			pci_write_config_byte(pdev, (offset+3), *(val+3));
			break;
		default:
			for (i = 0; i < length; i++)
				pci_write_config_byte(pdev, (offset+i), *(val+i));
		}
	}
}

inline void RPP_rw_pci_bar(struct rpp_dev *priv, UINT32 bar, INT dir, UINT32 length, UINT32 offset, UCHAR *val)
{
    void *bar_addr = priv->bar[bar];

    if (!bar_addr) {
        DEV_ERROR(priv, "BAR #%d is not present, can't read\n", bar);
        return ;
    }

    if (dir == 0) { /* 0 for read, 1 for write */
        switch (length) {
        case 1:
            *(PUINT8)val = *(volatile PCHAR)((PCHAR)bar_addr + offset);
            break;
        case 2:
            *(PUINT16)val = *(volatile PUINT16)((PCHAR)bar_addr + offset);
            break;
        case 4:
            *(PUINT32)val = *(volatile PUINT32)((PCHAR)bar_addr + offset);
            break;
        default:
            DEV_ERROR(priv, "wrong read length\n");
            break;
        }
    } else {
        switch (length) {
        case 1:
            *(volatile PUINT8)((PCHAR)bar_addr + offset) = *(PUINT8)val;
            break;
        case 2:
            *(volatile PUINT16)((PCHAR)bar_addr + offset) = *(PUINT16)val;
            break;
        case 4:
            *(volatile PUINT32)((PCHAR)bar_addr + offset) = *(PUINT32)val;
            break;
        default:
            DEV_ERROR(priv, "wrong write length\n");
            break;
        }
    }
}

void RPP_rw_pci_iobar(struct rpp_dev *pdev, UINT32 bar, INT d, UINT32 length, UINT32 offset, UCHAR *val)
{
	void *bar_addr = pdev->bar[bar];

	if (!bar_addr) {
		DEV_ERROR(pdev, "BAR #%d is not present, can't read\n", bar);
		return ;
	}

	if (d == 0) { /* 0 for read, 1 for write */
		switch (length) {
		case 1:
			*(PUINT8)val = RPP_READ_UINT8((PCHAR)bar_addr + offset);
			break;
		case 2:
			*(PUINT16)val = RPP_READ_UINT16((PCHAR)bar_addr + offset);
			break;
		case 4:
			*(PUINT32)val = RPP_READ_UINT32((PCHAR)bar_addr + offset);
			break;
		default:
			DEV_ERROR(pdev, "wrong read length\n");
		}
	} else {
		switch (length) {
		case 1:
			RPP_WRITE_UINT8((PCHAR)bar_addr + offset, *(PUINT8)val);
			break;
		case 2:
			RPP_WRITE_UINT16((PCHAR)bar_addr + offset, *(PUINT16)val);
			break;
		case 4:
			RPP_WRITE_UINT32((PCHAR)bar_addr + offset, *(PUINT32)val);
			break;
		default:
			DEV_ERROR(pdev, "wrong write length\n");
		}
	}
}

int RPP_remap_pci_bar(struct rpp_dev *pdev, UINT32 bar, struct vm_area_struct *vma)
{
	unsigned long off;
	unsigned long phys;
	unsigned long vsize;
	unsigned long psize;
	void *bar_addr = pdev->bar[bar];
	int rv;

	if (!bar_addr) {
		DEV_ERROR(pdev, "BAR #%d is not present, can't read\n", bar);
		return -ENOTTY;
	}

	if (pdev->small_bar) {
		switch (bar) {
			case 0:
				off = (vma->vm_pgoff<<PAGE_SHIFT) - BAR0_MAP_OFFSET_SMALL_BAR;
				break;
			case 2:
				off = (vma->vm_pgoff<<PAGE_SHIFT) - BAR2_MAP_OFFSET_SMALL_BAR;
				break;
			case 4:
				off = (vma->vm_pgoff<<PAGE_SHIFT) - BAR4_MAP_OFFSET_SMALL_BAR;
				break;
			default:
				return -EINVAL;
		}
	} else {
		switch (bar) {
			case 0:
				off = (vma->vm_pgoff<<PAGE_SHIFT) - BAR0_MAP_OFFSET_LARGE_BAR;
				break;
			case 2:
				off = (vma->vm_pgoff<<PAGE_SHIFT) - BAR2_MAP_OFFSET_LARGE_BAR;
				break;
			case 4:
				off = (vma->vm_pgoff<<PAGE_SHIFT) - BAR4_MAP_OFFSET_LARGE_BAR;
				break;
			default:
				return -EINVAL;
		}
	}

	/* BAR physical address */
	phys = pci_resource_start(pdev->pdev, bar) + off;
	vsize = vma->vm_end - vma->vm_start;
	/* complete resource */
	psize = pci_resource_end(pdev->pdev, bar) -
		pci_resource_start(pdev->pdev, bar) + 1 - off;

	/*  DEBUG_PRINT("mmap(): bar = %d\n", bar); */
	/*  DEBUG_PRINT("mmap(): rpp_dev = 0x%p\n", pdev); */
	/*  DEBUG_PRINT("mmap(): pci_dev = 0x%08lx\n", (unsigned long)pdev->pdev); */

	/*  DEBUG_PRINT("off = 0x%lx\n", off); */
	/*  DEBUG_PRINT("start = 0x%llx\n", */
	/*  	(unsigned long long)pci_resource_start(pdev->pdev, bar)); */
	/*  DEBUG_PRINT("phys = 0x%lx\n", phys); */

	if (vsize > psize)
		return -EINVAL;
	/*
	 * pages must not be cached as this would result in cache line sized
	 * accesses to the end point
	 */
	vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
	/*
	 * prevent touching the pages (byte access) for swap-in,
	 * and prevent the pages from being swapped out
	 */
#if LINUX_VERSION_CODE < KERNEL_VERSION(6,3,0)
	vma->vm_flags |= (VM_IO | VM_DONTEXPAND | VM_DONTDUMP);
#else
	vm_flags_set(vma, VM_IO | VM_DONTEXPAND | VM_DONTDUMP);
#endif
	/* make MMIO accessible to user space */
	rv = io_remap_pfn_range(vma, vma->vm_start, phys >> PAGE_SHIFT,
			vsize, vma->vm_page_prot);
	/*  DEBUG_PRINT("vma=0x%p, vma->vm_start=0x%lx, phys=0x%lx, size=0x%x\n", */
	/*  	vma, vma->vm_start, phys >> PAGE_SHIFT, vsize); */

	if (rv)
		return -EAGAIN;
	return 0;
}
EXPORT_SYMBOL_GPL(RPP_remap_pci_bar);

int RPP_rw_pci_hdr(struct pci_dev *pdev, INT rc, INT d, UINT32 length, UINT32 offset, UCHAR *val)
{
	struct pci_dev *rc_dev = pci_get_device(RC_SNPS_VENDOR_ID, RC_SNPS_DEVICE_ID, NULL);

	if (!rc) {
		RPP_rw_pci_cfg(pdev, d, length, offset, val);
		return STATUS_SUCCESS;
	}

	if (!rc_dev) {
		ERROR_PRINT("Can't find rc\n");
		return STATUS_UNSUCCESSFUL;
	}

	RPP_rw_pci_cfg(rc_dev, d, length, offset, val);
	return STATUS_SUCCESS;
}

void RPP_unmap_bars(struct rpp_dev *pdev, struct pci_dev *pcidev)
{
	int i;

	for (i = 0; i < RPP_BAR_NUM; i++) {
		/* is this BAR mapped? */
		if (pdev->bar[i]) {
			/* unmap BAR */
			pci_iounmap(pcidev, pdev->bar[i]);
			pdev->bar[i] = NULL;
		}
	}
}

int RPP_map_bars(struct rpp_dev *pdev, struct pci_dev *pcidev)
{
	int rc = 0;
	int i;

	resource_size_t bar_start, bar_end, bar_length;

	/* iterate through all the BARs */
	for (i = 0; i < RPP_BAR_NUM; i++) {
		bar_start = pci_resource_start(pcidev, i);
		bar_end = pci_resource_end(pcidev, i);

		pdev->bar[i] = NULL;
		pdev->bar_len[i] = 0;

		/* do not map BARs with address 0 */
		if (!bar_start || !bar_end) {
			rc = -1;
			continue;
		}
		/* bar_length = bar_end - bar_start + 1; */
		bar_length = pci_resource_len(pcidev, i);

		/* map the device memory or IO region into kernel virtual address space */
		pdev->bar[i] = pci_iomap(pcidev, i, bar_length);
		pdev->bar_len[i] = bar_length;
		pdev->RegSpacePa[i].QuadPart = bar_start;
		pdev->RegSpacePa[i].HighPart = pci_dma_h(bar_start);
		pdev->RegSpacePa[i].LowPart = pci_dma_l(bar_start);
		if (!pdev->bar[i]) {
			DEV_ERROR(pdev, "Could not map BAR #%d.\n", i);
			rc = -1;
			goto fail;
		}
		DEV_INFO(pdev, "BAR[%d]/RegSpacePa[%d] mapped at 0x%llx/0x%llx with length 0x%lx.\n", i, i, pdev->bar[i], pdev->RegSpacePa[i].QuadPart, (unsigned long)bar_length);
	}

	if (pdev->bar_len[2] == 0x200000) {
		pdev->small_bar = true;
	} else {
		pdev->small_bar = false;
	}

	/* succesfully mapped all required BAR regions */
	rc = 0;
	goto success;
fail:
	/* unmap any BARs that we did map */
	RPP_unmap_bars(pdev, pcidev);
success:
	return rc;
}



static void RPP_priv_init(struct rpp_dev *pdev)
{
	PDEVICE_EXTENSION pDevExt;
	UINT32 dcr;
	short int EDMA_regs_bar;
	long EDMA_regs_off;

	pDevExt = &pdev->RPP_ext;
	tasklet_init(&pdev->tlet, DataCheckDpc, (unsigned long)pdev);

	/* initialize the RPP data
	 */

	RtlZeroMemory(&pDevExt->DmaRsc, sizeof(DMA_RSC));
	RtlZeroMemory(&pDevExt->xDataRsc, sizeof(XDATA_RSC));

	/* Get DMA registers */
	if (EDMA || XDATA) {
		if (pdev->small_bar) {
			EDMA_regs_bar = 4;
			EDMA_regs_off = 0x380000;
		} else {
			EDMA_regs_bar = 2;
			EDMA_regs_off = 0x7380000;
		}

		void __iomem *tmp = (void __iomem *) pdev->bar[EDMA_regs_bar];
        DEV_DEBUG(pdev, "before pcie dma regsiter addr 0x%llx\n", tmp);
		tmp += EDMA_regs_off;
		pDevExt->DmaRsc.DmaRegs = (PDMA_REGS)tmp;
        DEV_DEBUG(pdev, "after pcie dma regsiter addr 0x%llx\n", tmp);
	}

	/* Get local RAM addresses
	 * Note: in latest prototype (02/15/2014), the onboard RAM space is
	 * changed. It's splitted to two parts, and we only use the second part.
	 */
	if (EDMA || XDATA) {
		pDevExt->RamSize = (UINT32)pdev->bar_len[EDMA_MEM_BAR];
		/*  Just a restriction, because the maximum RAM size that EDMA would even use is 64MB */
		if (pDevExt->RamSize > (64 * 1024 * 1024))
			pDevExt->RamSize = 64 * 1024 * 1024;
#if TEST_DESC_IN_SRAM
               pDevExt->RamVa = (PUINT32)(pdev->bar[XCFG_BAR] + SRAM_DESC_BAR_OFFS);
               /*  Invecas: DDR starts at 0x0 and bar expose this address to another address using translator. */
               pDevExt->RamPa.QuadPart = SRAM_DESC_PHYS;
#else
		pDevExt->RamVa = (PUINT32)(pdev->bar[EDMA_MEM_BAR] + 0x10000);
		/*  Invecas: DDR starts at 0x0 and bar expose this address to another address using translator. */
		pDevExt->RamPa.QuadPart = 0x10000;
#endif
		DEV_DEBUG(pdev, "size 0x%x\n", pDevExt->RamSize);
		DEV_DEBUG(pdev, "pDevExt->RamVa=0x%llx, pDevExt->RamPa.QuadPart=0x%llx\n", pDevExt->RamSize, pDevExt->RamPa.QuadPart);
	}

	/* Get local XDATA addresses */
	if (XDATA)
		pDevExt->xDataRsc.xDataRegs = pdev->bar[XDATA_BAR];

#if 0
	/* Get interrupt object */
	if (pDEC->MessageInterruptCount == 1) {
		PIO_INTERRUPT_MESSAGE_INFO msgInfo =
				(PIO_INTERRUPT_MESSAGE_INFO) pDEC->IntConnectionContext;
		pDevExt->DmaRsc.IntrObj
				= msgInfo->MessageInfo[0].InterruptObject;
	} else {
		LWDM_ERROR(pDEC, "Failed to obtain MSI interrupt object");
		goto CLEANUP;
	}
#endif

	/* Reset other device extension members */
	RtlZeroMemory(&pDevExt->IoMemVa, 16 * sizeof(PUINT32));
	RtlZeroMemory(&pDevExt->IoMemPa, 16 * sizeof(PHYADDR));
	RtlZeroMemory(&pDevExt->WrChInfEx, 8 * sizeof(CHAN_INFO_EX));
	RtlZeroMemory(&pDevExt->RdChInfEx, 8 * sizeof(CHAN_INFO_EX));
	pDevExt->ChunkLen = 0;

	/* Max PCI packet payload size */
	RPP_rw_pci_cfg(pdev->pdev, 0, 4, 0x78, (CHAR *)&dcr);

	pDevExt->WriteMTU = 128;
	pDevExt->WriteMTUBits = 0xFE000000;
	switch ((dcr >> 5) & 0x07) {
		case 0:
			pDevExt->WriteMTU = 128;
			pDevExt->WriteMTUBits = 0xFE000000;
			break;
		case 1:
			pDevExt->WriteMTU = 256;
			pDevExt->WriteMTUBits = 0xFF000000;
			break;
		case 2:
			pDevExt->WriteMTU = 512;
			pDevExt->WriteMTUBits = 0xFF800000;
			break;
		case 3:
			pDevExt->WriteMTU = 1024;
			pDevExt->WriteMTUBits = 0xFFC00000;
			break;
		case 4:
			pDevExt->WriteMTU = 2048;
			pDevExt->WriteMTUBits = 0xFFE00000;
			break;
		case 5:
			pDevExt->WriteMTU = 4096;
			pDevExt->WriteMTUBits = 0xFFF00000;
			break;
	}
	pDevExt->ReadMTU = 128;
	pDevExt->ReadMTUBits = 0xFE000000;
	switch ((dcr >> 12) & 0x07) {
		case 0:
			pDevExt->ReadMTU = 128;
			pDevExt->ReadMTUBits = 0xFE000000;
			break;
		case 1:
			pDevExt->ReadMTU = 256;
			pDevExt->ReadMTUBits = 0xFF000000;
			break;
		case 2:
			pDevExt->ReadMTU = 512;
			pDevExt->ReadMTUBits = 0xFF800000;
			break;
		case 3:
			pDevExt->ReadMTU = 1024;
			pDevExt->ReadMTUBits = 0xFFC00000;
			break;
		case 4:
			pDevExt->ReadMTU = 2048;
			pDevExt->ReadMTUBits = 0xFFE00000;
			break;
		case 5:
			pDevExt->ReadMTU = 4096;
			pDevExt->ReadMTUBits = 0xFFF00000;
			break;
	}

}

static void RPP_priv_exit(struct rpp_dev *pdev)
{
	PDEVICE_EXTENSION pDevExt;
	int i;

	pDevExt = &pdev->RPP_ext;

	/* Free EDMA system memory */
	for (i = 0; i < 16; i++)
		FreeProtocolMem(pdev, pDevExt->ChunkLen * 4,
				&pDevExt->IoMemVa[i],
				&pDevExt->dma_bus[i]);

	/* Free XDATA memory */
	if (pDevExt->xDataRsc.xDataMemVa)
		FreeProtocolMem(pdev, pDevExt->xDataRsc.xDataMemSize,
				&pDevExt->xDataRsc.xDataMemVa,
				&pDevExt->xDataRsc.xDataBus);
}


/* ---------------------------------------------------------------------------------------------- */
/*  jgd 2022.0928 */
/* ---------------------------------------------------------------------------------------------- */
const char *mname = "rpp";

static void RPP_on_probe(struct rpp_dev *pdev)
{
    DEV_DEBUG(pdev, "RPP_on_probe 0x%p\n", pdev);

	spin_lock_init(&pdev->lock);

	/* Initialize the semaphore to 0 devices (locked state) */
	sema_init(&pdev->sem, 1);

	spin_lock_init(&pdev->idr_lock);
	idr_init(&pdev->idr);


	if(idr_alloc(&pdev->idr, NULL, 1, 0, GFP_NOWAIT) != PHY_ADDRESS_XFER_MODE) {
		DEV_ERROR(pdev, "first ID != %d\n", PHY_ADDRESS_XFER_MODE);
	}

	/* allocate zeroed device book keeping structure */
	pdev->mod_name = mname;


    /*  must be 1st called. */
    rpp_dev_list_add(pdev);

    DEV_DEBUG(pdev, "rpp_vdev_init\n");
    rpp_vdev_init(pdev);

	DEV_DEBUG(pdev, "rpp_cdev_init\n");
	rpp_cdev_init(pdev);
}

static void RPP_on_remove(struct rpp_dev *pdev)
{
    DEV_DEBUG(pdev, "RPP_on_remove 0x%p\n", pdev);

	idr_remove(&pdev->idr, PHY_ADDRESS_XFER_MODE);

    rpp_cdev_exit(pdev);
    rpp_vdev_exit(pdev);


    rpp_dev_list_remove(pdev);
}
/* ---------------------------------------------------------------------------------------------- */
/*  jgd 2022.0928 */
/* ---------------------------------------------------------------------------------------------- */


static void dump_pcie_reg(struct rpp_dev *prppdev)
{
	uint8_t buf[0x200];
	void *pcie_reg_base;
	uint32_t pcie_offs = 0;
	uint32_t i, j;

	if(prppdev->small_bar){
		pcie_reg_base = prppdev->bar[4];
	}else{
		pcie_reg_base = prppdev->bar[2];
		pcie_reg_base = (PCHAR)pcie_reg_base + 0x7000000;
	}

	/* 0x0 ~ 0x200 */
	DEV_INFO(prppdev, "pcie_reg_base=0x%llx\n", pcie_reg_base);
	memcpy(buf, pcie_reg_base, 0x200);
	for (i = 0; i < 0x200/4; i++ ) {
		if (((i % 8) == 0) && (i != 0)) {
			DEV_INFO(prppdev, "\n");
		}
		if ((i % 8) == 0) {
			DEV_INFO(prppdev, "[0x%x]:", i*4);
		}

		DEV_INFO(prppdev, "0x%08x, ", *((uint32_t *)buf + i));

	}
	DEV_INFO(prppdev, "\n");

	/* 0x200 ~ 0x220, 0x300 ~ 0x320, 0x400 ~ 0x420, 0x500 ~ 0x520, */
	/* 0x600 ~ 0x620, 0x700 ~ 0x720, 0x800 ~ 0x820, 0x900 ~ 0x920, */
	for (j = 0; j < 8; j++ ) {
		pcie_offs = 0x200 + 0x100*j;
		memcpy(buf, pcie_reg_base + 0x380000 + pcie_offs, 0x20);

		DEV_INFO(prppdev, "[0x%x]:", pcie_offs);
		for (i = 0; i < 0x20/4; i++ ) {
			DEV_INFO(prppdev, "0x%08x, ", *((uint32_t *)buf + i));
		}
		DEV_INFO(prppdev, "\n");
	}

	return;
}

static void dump_rpp_dev(struct rpp_dev *prppdev)
{
	DEV_INFO(prppdev, "prppdev=0x%p\n", prppdev);
	DEV_INFO(prppdev, "prppdev->pdev=0x%p\n", prppdev->pdev);
	DEV_INFO(prppdev, "prppdev->dma_mask=0x%llx\n", prppdev->dma_mask);

	DEV_INFO(prppdev, "prppdev->mmio_addr=0x%p\n", prppdev->mmio_addr);
	DEV_INFO(prppdev, "prppdev->mmio_start=0x%p\n", prppdev->mmio_start);
	DEV_INFO(prppdev, "prppdev->mmio_len=0x%llx\n", prppdev->mmio_len);
	DEV_INFO(prppdev, "prppdev->irq=0x%x\n", prppdev->irq);

	DEV_INFO(prppdev, "prppdev->small_bar=0x%x\n", prppdev->small_bar);
	DEV_INFO(prppdev, "prppdev->open_flag=0x%x\n", prppdev->open_flag);
	DEV_INFO(prppdev, "prppdev->in_use=0x%x\n", prppdev->in_use);
	DEV_INFO(prppdev, "prppdev->got_regions=0x%x\n", prppdev->got_regions);
	DEV_INFO(prppdev, "prppdev->dma_initialized=0x%x\n", prppdev->dma_initialized);

	DEV_INFO(prppdev, "prppdev->revision=0x%x\n", prppdev->revision);
	DEV_INFO(prppdev, "prppdev->irq_pin=0x%x\n", prppdev->irq_pin);
	DEV_INFO(prppdev, "prppdev->irq_line=0x%x\n", prppdev->irq_line);
	DEV_INFO(prppdev, "prppdev->no_of_msi=0x%x\n", prppdev->no_of_msi);
	DEV_INFO(prppdev, "prppdev->sub_vendor_id=0x%x\n", prppdev->sub_vendor_id);
	DEV_INFO(prppdev, "prppdev->sub_system_id=0x%x\n", prppdev->sub_system_id);
	DEV_INFO(prppdev, "prppdev->vendor_id=0x%x\n", prppdev->vendor_id);
	DEV_INFO(prppdev, "prppdev->device_id=0x%x\n", prppdev->device_id);

	DEV_INFO(prppdev, "prppdev->drv_cls=0x%p\n", prppdev->drv_cls);

	DEV_INFO(prppdev, "prppdev->irq_count=0x%x\n", prppdev->irq_count);
	DEV_INFO(prppdev, "prppdev->status=0x%x\n", prppdev->status);

	DEV_INFO(prppdev, "prppdev->idx=0x%x\n", prppdev->idx);
	DEV_INFO(prppdev, "prppdev->mod_name=0x%s\n", prppdev->mod_name);

	return;
}


void set_default_workmode(struct rpp_dev *prppdev)
{
	if (prppdev == NULL) {
		DEV_ERROR(prppdev, "set_1w_workmode input err prppdev NULL\n");
		goto set_mode_end;
	}

	if (prppdev->init_dev_count == 0) {
		/*  probe */
		prppdev->hw_state.pwr_state = RPP_PWRMODE_WORKING;
		prppdev->hw_state.wrk_state = RPP_WORKMODE_BOOST_DISABLE | RPP_WORKMODE_DFS_DISABLE | RPP_WORKMODE_VE_ENABLE;
		prppdev->hw_state.wrk_user_state = RPP_WORKMODE_BOOST_DISABLE | RPP_WORKMODE_DFS_DISABLE | RPP_WORKMODE_VE_ENABLE;

		if ((((prppdev->bl_config_info.board_mn >> 28) & 0xf) == RPP_CHIP_R8_MPW) && (prppdev->bl_config_info.board_info != RPP_BOARD_A9_V2)) {
			/* M3/M5/A8 */
			prppdev->hw_state.wrk_user_state = RPP_WORKMODE_BOOST_DISABLE | RPP_WORKMODE_DFS_DISABLE | RPP_WORKMODE_VE_ENABLE;
		} else {
			/* R8 A9V2, R9 A9V2 */
			prppdev->hw_state.wrk_user_state = RPP_WORKMODE_MODE2 | RPP_WORKMODE_BOOST_ENABLE | RPP_WORKMODE_DFS_ENABLE | RPP_WORKMODE_VE_ENABLE;
		}

		if (rpp_set_worker_mode(prppdev, prppdev->hw_state.wrk_user_state) != 0) {
			DEV_ERROR(prppdev, "set worker state error, mode 0x%x\n", prppdev->hw_state.wrk_user_state);
			goto set_mode_end;
		}
	} else {
		/* Resume: restore power and worker mode */
		if (rpp_set_power_mode(prppdev, prppdev->hw_state.pwr_user_state) != 0) {
			DEV_ERROR(prppdev, "set power state error, mode 0x%x\n", prppdev->hw_state.pwr_user_state);
			goto set_mode_end;
		}

		if (rpp_set_worker_mode(prppdev, prppdev->hw_state.wrk_user_state) != 0) {
			DEV_ERROR(prppdev, "set worker state error, mode 0x%x\n", prppdev->hw_state.wrk_user_state);
			goto set_mode_end;
		}
	}

set_mode_end:
	 /*  set 1w mode fail should not block driver init */
	DEV_DEBUG(prppdev, "now set to default mode: pwr_user_state 0x%x, wrk_user_state 0x%x, pwr_state 0x%x, wrk_state 0x%x",
				prppdev->hw_state.pwr_user_state,
				prppdev->hw_state.wrk_user_state,
				prppdev->hw_state.pwr_state,
				prppdev->hw_state.wrk_state);
	return;
}

static int RppInitializeStep1(struct rpp_dev *prppdev)
{
    uint32_t temp = 0;
	int rc = -ENODEV, i;

	if (!prppdev->small_bar) {
		temp = 0;
		RPP_rw_pci_bar(prppdev, 4, 0, 4, 0x21018, (UCHAR *)&temp);
		if ((temp & 0x000f0000) != 0x00070000) {
			/*  For FPGA, reset rpptop, vcpu_sch_pcie_rpptop_rst */
			temp = 0x0707071f;
			RPP_rw_pci_bar(prppdev, 4, 1, 4, 0x21018, (UCHAR *)&temp);
		}
	}

	/* Load MPU firmware */
	rc = rpp_firmware_load(prppdev, true);
	if (rc != 0) {
		DEV_ERROR(prppdev, "rpp_firmware_load failed\n");
		return rc;
	}

	/* Check PCIe link status */
	if (prppdev->small_bar) {
		RPP_rw_pci_bar(prppdev, 4, 0, 4, PCIE_STATUS_REG_SMALL_BAR, (UCHAR *)&temp);
	} else {
		RPP_rw_pci_bar(prppdev, 2, 0, 4, PCIE_STATUS_REG_LARGE_BAR, (UCHAR *)&temp);
	}
	/* Fix operator precedence: == has higher precedence than & */
	if (((temp & PCIE_LINK_STATUS_MASK) == 0x0) || (temp == PCIE_LINK_STATUS_INVALID)) {
		DEV_ERROR(prppdev, "PCIe Link failed(0x%x)! Try to remove pcie, then rescan pcie\n", temp);
		return -EIO;
	}

	/* Get device info */
	rc = rpp_get_devinfo(prppdev);
	if (rc != 0) {
		DEV_ERROR(prppdev, "rpp_get_devinfo failed\n");
		return rc;
	}

	/* Enable MPU interrupt if IRQ number >= 16 */
	if (IRQ_NUM >= 16) {
		rc = rpp_mpu_isr_enable(prppdev);
		if (rc != 0) {
			DEV_ERROR(prppdev, "mpu isr enable failed\n");
			return rc;
		}
	}
    /* Get memory and register configuration from firmware
     * 0xbeef is the boot status of MPU
    */
	if (prppdev->init_dev_count == 0) {
		temp = 0;
		if (!prppdev->small_bar) {
			RPP_rw_pci_bar(prppdev, 4, 0, 4, 0x22210, (UCHAR *)&temp);
		} else {
			temp = (prppdev->dev_info.mpu_external_ctrl_0 & 0x1) << 8;
		}
		if (!RPP_VE_DISABLE) {
			prppdev->ve_disable = 0;
			if ((prppdev->bl_config_info.magic_number != 0xcafd) || (prppdev->bl_config_info.version < MPUARCHV2)) {
				/* Legacy firmware: determine memory configuration based on DDR count */
				if (((temp & (0x1 << 8)) != 0)) {
					/* 1 DDR: 2GB for VE memory usage */
					prppdev->ve_info.ve_mem.size = VE_FRAME_BUFFER_SIZE_2G;
					prppdev->ve_info.ve_mem.phys_addr = VE_MEM_PHYS_ADDR_2GB;
					prppdev->ve_info.ve_mem.virt_addr = VE_MEM_PHYS_ADDR_2GB;
				} else {
					/* 4 DDR: 4GB for VE memory usage */
					prppdev->ve_info.ve_mem.size = VE_FRAME_BUFFER_SIZE;
					prppdev->ve_info.ve_mem.phys_addr = VE_MEM_PHYS_ADDR_4GB_4DDR;
					prppdev->ve_info.ve_mem.virt_addr = VE_MEM_PHYS_ADDR_4GB_4DDR;
				}
			} else {
				/* New firmware: determine memory configuration based on board model */
				switch((prppdev->bl_config_info.board_mn >> 4) & 0xff) {
					case 4:
						prppdev->ve_info.ve_mem.size = VE_FRAME_BUFFER_SIZE_2G;
						prppdev->ve_info.ve_mem.phys_addr = VE_MEM_PHYS_ADDR_2GB;
						prppdev->ve_info.ve_mem.virt_addr = VE_MEM_PHYS_ADDR_2GB;
						break;
					case 8:
						prppdev->ve_info.ve_mem.size = VE_FRAME_BUFFER_SIZE;
						prppdev->ve_info.ve_mem.phys_addr = VE_MEM_PHYS_ADDR_4GB_1DDR;
						prppdev->ve_info.ve_mem.virt_addr = VE_MEM_PHYS_ADDR_4GB_1DDR;
						break;
					case 16:
					case 32:
					case 64:
						prppdev->ve_info.ve_mem.size = VE_FRAME_BUFFER_SIZE;
						prppdev->ve_info.ve_mem.phys_addr = VE_MEM_PHYS_ADDR_4GB_4DDR;
						prppdev->ve_info.ve_mem.virt_addr = VE_MEM_PHYS_ADDR_4GB_4DDR;
						break;
					default:
						DEV_ERROR(prppdev, "Get memory and register configuration from firmware failed\n");
						return -EINVAL;
				}
			}
		} else {
			prppdev->ve_disable = 1;
			prppdev->ve_info.ve_mem.size = 0;
			prppdev->ve_info.ve_mem.phys_addr = 0x0;
			prppdev->ve_info.ve_mem.virt_addr = 0x0;
		}

		/* pcie bar configuration seting */
		if (prppdev->small_bar) {
			prppdev->ve_info.ve_register.size = 0x80000;
			prppdev->ve_info.ve_register.phys_addr = 0x00000000;
			prppdev->ve_info.ve_register.virt_addr = 0x00000000;
		} else {
			prppdev->ve_info.ve_register.size = 0x80000;
			prppdev->ve_info.ve_register.phys_addr = 0x02000000;
			prppdev->ve_info.ve_register.virt_addr = 0x00000000;
		}
	}

	/*  for finally release code */
	/*  for old version software temporary stash */

	set_default_workmode(prppdev);

	/* Clear all DMA interrupts before enabling IRQ */
	temp = 0x000f000f;
	if (prppdev->small_bar) {
		RPP_rw_pci_bar(prppdev, 4, 1, 4, 0x380058, (uint8_t*)&temp);
		RPP_rw_pci_bar(prppdev, 4, 1, 4, 0x3800ac, (uint8_t*)&temp);
	} else {
		RPP_rw_pci_bar(prppdev, 2, 1, 4, 0x7380058, (uint8_t*)&temp);
		RPP_rw_pci_bar(prppdev, 2, 1, 4, 0x73800ac, (uint8_t*)&temp);
	}

	return 0;
}

/* Internal helper: Generate device prefix string */
static void rpp_gen_dev_prefix(struct rpp_dev *pdev, char *prefix_buf, size_t buf_size) {
    if (!pdev || !prefix_buf) return;

    if (pdev->switch_idx != SWITCH_IDX_INVALID) {
        snprintf(prefix_buf, buf_size, "C%02dD%02d-RPP%03d",
                pdev->switch_idx, pdev->idx_in_switch, pdev->idx);
    } else {
        snprintf(prefix_buf, buf_size, "CxxDxx-RPP%03d", pdev->idx);
    }

    return;
}

/* Initialize device logging prefix */
static void rpp_dev_setup_logging(struct rpp_dev *pdev) {
    if (!pdev) {
        WARNING_PRINT("rpp_dev_setup_logging: pdev is NULL\n");
        return;
    }

    /* Set magic to identify initialized device */
    pdev->magic = RPP_DEV_MAGIC;

    /* Generate initial prefix */
    rpp_gen_dev_prefix(pdev, pdev->dev_prefix, sizeof(pdev->dev_prefix));

    pdev->reserved = NULL;

    return;
}

int configure_pci_switch_multicast(rpp_switch_t *sdev, uint32_t size)
{
	int ret = 0;
	uint32_t i = 0;
	uint64_t mc_base_addr = 0;
	struct pci_dev *switch_pdev;
	uint32_t size_n = 0;  /* size 的指数，即 log2(size) */
	uint32_t temp_size = size;
	rpp_pcie_switch_reg_t regs[] = {
		{0x168,0x00000fff},
		{0x15c,0x8001803f},
		{0x184,0x00000000},
		{0x16c,0x00000000},
	};

	if (sdev == NULL) {
		ERROR_PRINT(" no such a switch device%p!\n", sdev);
		return -ENODEV;
	}

	switch_pdev = sdev->pdev;
	if (switch_pdev == NULL) {
		ERROR_PRINT(" switch device has no pci_dev!\n");
		return -ENODEV;
	}

	mc_base_addr = sdev->bar_mem_start + MC_BASE_ADDR_OFFSET;
	if (mc_base_addr <= 0) {
		ERROR_PRINT(" no such a switch memory addr %llx\n", mc_base_addr);
		return -ENOSPC;
	}

	/* 计算 size 是 2 的几次方（即 log2(size)），用于设置 0x160 寄存器的低 6 位 */
	if (temp_size == 0) {
		ERROR_PRINT("Invalid size value: 0\n");
		return -EINVAL;
	}
	while (temp_size > 1) {
		temp_size >>= 1;
		size_n++;
	}

	for (i = 0; i < (sizeof(regs)/sizeof(regs[0])); i++) {
		if (regs[i].addr != 0) {
			/* read original valud, these code for debug */
			// uint32_t tmp = 0;
			// ret = pci_read_config_dword(switch_pdev, regs[i].addr, &tmp);
			// if (ret) {
			//     ERROR_PRINT("Failed to read switch config space at regs[i].addr = 0x%4x, error %d\n", regs[i].addr, ret);
			//     goto out_put_swc_dev;
			// } else {
			//     if (tmp == regs[i].val) {
			//         DTRACE("current reg 0x%04x already set value: 0x%08x, continue set next reg\n", regs[i].addr, tmp);
			//         continue;
			//     }
			// }
			// DTRACE("Current switch multicast reg 0x%04x value: 0x%08x  targetval 0x%08x\n", regs[i].addr, tmp,  regs[i].val);

			/* write expacted value */
			ret = pci_write_config_dword(switch_pdev, regs[i].addr, regs[i].val);
			if (ret)
			{
				ERROR_PRINT("Failed to write switch config space at regs[i].addr = 0x%04x, error %d\n", regs[i].addr, ret);
				goto out_put_swc_dev;
			}

			// /* verify write check succ, these code for debug */
			// ret = pci_read_config_dword(switch_pdev, regs[i].addr, &tmp);
			// if (ret) {
			//     ERROR_PRINT("Failed to verify switch config space, error %d\n", ret);
			//     goto out_put_swc_dev;
			// } else {
			//     DTRACE(" Verified switch multicast reg 0x%04x value: 0x%08x\n", regs[i].addr, tmp);
			// }
		} else {
			DTRACE("input reg group have 0 addr reg\n");
		}
	}

	// {0x160,0xd8000014}, /* MC_Base_Address[31:12], MC_Index_Position (5:0) */
	// {0x164,0x00000000}, /* MC_Base_Address[63:32] */
	/* 0x160 寄存器的低 6 位设置为 size_n */
	ret = pci_write_config_dword(switch_pdev, 0x160, (mc_base_addr & 0xFFFFFFC0) | (size_n & 0x3F));
	if (ret) {
		ERROR_PRINT("Failed to write bridge config space at 0x160, error %d\n", ret);
		goto out_put_swc_dev;
	}

	ret = pci_write_config_dword(switch_pdev, 0x164, mc_base_addr >> 32);
	if (ret) {
		ERROR_PRINT("Failed to write bridge config space at 0x164, error %d\n", ret);
		goto out_put_swc_dev;
	}

out_put_swc_dev:

    return ret;
}

int configure_pci_brigde_multicast(struct rpp_dev *pdev, uint32_t dev_offs, uint32_t size)
{
	int ret = 0;
	uint32_t i = 0;
	uint64_t mc_base_addr = 0;
	struct pci_dev *brigde_pdev;
	rpp_pcie_switch_reg_t bridge_regs[] = {
		{0x15c,0x8001803f},
		{0x168,0x00000fff}, /* MC_Receive Register[31:0] */
		{0x16c,0x00000000}, /* MC_Receive  Register[63:32] */
	};

	if (pdev == NULL) {
		ERROR_PRINT(" no such a device%p!\n", pdev);
		return -ENODEV;
	}

	brigde_pdev = pdev->bridge_pcidev;
	if (brigde_pdev == NULL) {
		DEV_ERROR(pdev, " no such a bridge device!\n");
		return -ENODEV;
	}

	mc_base_addr = pdev->parent_switch->bar_mem_start + MC_BASE_ADDR_OFFSET;
	if (mc_base_addr <= 0) {
		ERROR_PRINT(" get mc baseaddr failed. no such a switch memory addr %llx\n", mc_base_addr);
		return -ENOSPC;
	}

	for (i = 0; i < (sizeof(bridge_regs)/sizeof(bridge_regs[0])); i++) {
		if (bridge_regs[i].addr != 0) {
			// /* reg read original value  these code for debug */
			// uint32_t tmp = 0;
			// ret = pci_read_config_dword(brigde_pdev, bridge_regs[i].addr, &tmp);
			// if (ret) {
			//     ERROR_PRINT("Failed to read bridge config space at bridge_regs[i].addr = 0x%4x, error %d\n", bridge_regs[i].addr, ret);
			//     goto out_put_dev;
			// }
			// DTRACE("Current bridge multicast reg 0x%04x value: 0x%08x  targetval 0x%08x\n", bridge_regs[i].addr, tmp,  bridge_regs[i].val);

			/* write expacted value */
			ret = pci_write_config_dword(brigde_pdev, bridge_regs[i].addr, bridge_regs[i].val);
			if (ret) {
				DEV_ERROR(pdev, "Failed to write bridge config space at bridge_regs[i].addr = 0x%04x, error %d\n", bridge_regs[i].addr, ret);
				goto out_put_dev;
			}

			// /* verify write check succ, these code for debug */
			// ret = pci_read_config_dword(brigde_pdev, bridge_regs[i].addr, &tmp);
			// if (ret) {
			//     ERROR_PRINT("Failed to verify bridge config space, error %d\n", ret);
			// } else {
			//     DTRACE("Verified bridge multicast reg 0x%04x value: 0x%08x\n", bridge_regs[i].addr, tmp);
			// }
		} else {
			DEV_TRACE(pdev, "input reg group have 0 addr reg\n");
		}
	}

	/* 计算 size 是 2 的几次方（即 log2(size)），用于设置 0x180 和 0x160 寄存器的低 6 位 */
	uint32_t size_n = 0;  /* size 的指数，即 log2(size) */
	uint32_t temp_size = size;
	
	if (temp_size == 0) {
		DEV_ERROR(pdev, "Invalid size value: 0\n");
		ret = -EINVAL;
		goto out_put_dev;
	}
	while (temp_size > 1) {
		temp_size >>= 1;
		size_n++;
	}

	/* reg 0x180: MC_Overlay_BAR[31:6], MC_Overlay_Size (5:0) */
	/*  MC_OVERLAY_CTRL 0x180 set this reg val to dev BAR[0] + offset | Overlay size (0x14:1M, 0x18:16M, 0x19:32M, 0x1A:64M) */
	/* dev_offs 和 size 从 IOCTL 参数传入，size 是 2 的 n 次方，需要转换为指数 n */
	{
		uint64_t overlay_addr = pdev->RegSpacePa[0].QuadPart + dev_offs;
		
		/* [31:6] 地址，[5:0] size 指数 */
		uint32_t reg_180_val = (overlay_addr & 0xFFFFFFC0) | (size_n & 0x3F);
		ret = pci_write_config_dword(brigde_pdev, 0x180, reg_180_val);
		if (ret) {
			DEV_ERROR(pdev, "Failed to write bridge config space at 0x180, error %d\n", ret);
			goto out_put_dev;
		}
		/* reg 0x184: MC_Overlay_BAR[63:32] */
		ret = pci_write_config_dword(brigde_pdev, 0x184, overlay_addr >> 32);
		if (ret) {
			DEV_ERROR(pdev, "Failed to write bridge config space at 0x184,  error %d\n", ret);
			goto out_put_dev;
		}
	}
	// {0x160,0xd8000014}, /* MC_Base_Address[31:12], MC_Index_Position (5:0) */
	// {0x164,0x00000000}, /* MC_Base_Address[63:32] */
	/* 0x160 寄存器的低 6 位也要设置为 size_n */
	ret = pci_write_config_dword(brigde_pdev, 0x160, (mc_base_addr & 0xFFFFFFC0) | (size_n & 0x3F));
	if (ret) {
		DEV_ERROR(pdev, "Failed to write bridge config space at 0x160, error %d\n", ret);
		goto out_put_dev;
	}

	ret = pci_write_config_dword(brigde_pdev, 0x164, mc_base_addr >> 32);
	if (ret) {
		DEV_ERROR(pdev, "Failed to write bridge config space at 0x164, error %d\n", ret);
		goto out_put_dev;
	}
out_put_dev:
	return ret;
}

/* Update device logging prefix */
static void rpp_dev_update_logging(struct rpp_dev *pdev) {
    if (!pdev) {
        WARNING_PRINT("rpp_dev_update_logging: pdev is NULL\n");
        return;
    }

    if (pdev->magic != RPP_DEV_MAGIC) {
        WARNING_PRINT("rpp_dev_update_logging: device not initialized (magic=0x%08x)\n",
                pdev->magic);
        /* Optionally initialize it now */
        pdev->magic = RPP_DEV_MAGIC;
    }

    rpp_gen_dev_prefix(pdev, pdev->dev_prefix, sizeof(pdev->dev_prefix));

    return;
}

static int RPP_probe(struct pci_dev *pdev, const struct pci_device_id *pci_id)
{

	unsigned long mmio_flags;
	resource_size_t mmio_start, mmio_end, mmio_len;
	struct msi_msg msg;
	void *mmio_addr = NULL;
	/*  struct rpp_dev *pdev = NULL; */
	struct rpp_dev *prppdev = NULL;
    uint32_t temp = 0;
	int rc = -ENODEV, i;
	struct device *dev = &pdev->dev;

	DEV_DEBUG(prppdev, "RPP_probe EDMA %sabled by parameter\n", EDMA ? "en" : "dis");

	/* Allocate device private data structure using devm for automatic cleanup */
	prppdev = devm_kzalloc(dev, sizeof(*prppdev), GFP_KERNEL);
	if (!prppdev) {
		dev_err(dev, "Failed to allocate device private data\n");
		return -ENOMEM;
	}
	DEV_DEBUG(prppdev, "RPP_probe rpp_dev: 0x%p,  pci_dev:  0x%p\n", prppdev, pdev);

	for (i = 0; i < RTD3_CFG_NUM_MAX; i++)
		prppdev->rtd3_regs[i].addr = rpp_rtd3_cfg_offsets[i];

    prppdev->switch_idx = SWITCH_IDX_INVALID;
    prppdev->idx_in_switch = 0;

	if (EDMA) {
		DEV_DEBUG(prppdev, "PED driver with DMA Unroll support\n");
		DEV_DEBUG(prppdev, "EDMA mem BAR: %d\n", EDMA_MEM_BAR);
	}

	DEV_DEBUG(prppdev, "XDATA %sabled by parameter\n", XDATA ? "en" : "dis");
	if (XDATA) {
		DEV_DEBUG(prppdev, "XDATA BAR configured: %d\n", XDATA_BAR);
	}

	DEV_DEBUG(prppdev, "HW performance workaround %sabled by parameter\n",
		  HW_PERFORMANCE_WORKAROUND ? "en" : "dis");


	prppdev->pdev = pdev;
	pci_set_drvdata(pdev, prppdev);

	/* Enable device - managed by devm */
	rc = pci_enable_device(pdev);
	if (rc) {
		DEV_ERROR(prppdev, "%s cannot enable device\n", pci_name(pdev));
		return rc;
	}

	/* enable bus master capability on device */
	pci_set_master(pdev);

	mmio_start = pci_resource_start(pdev, BAR_MEM);
	mmio_end   = pci_resource_end(pdev, BAR_MEM);
	mmio_flags = pci_resource_flags(pdev, BAR_MEM);
	mmio_len   = pci_resource_len(pdev, BAR_MEM);

	if (!(mmio_flags & IORESOURCE_MEM)) {
		DEV_ERROR(prppdev, "cannot find proper PCI device base address\n");
		return -ENODEV;
	}
	rc = pci_request_regions(pdev, DRVER_NAME);
	if (rc) {
		prppdev->in_use = 1;
		DEV_ERROR(prppdev, "Cannot request PCI regions\n");
		goto err_request_region;
	}
	prppdev->got_regions = 1;
	prppdev->dma_initialized = 0;

	mmio_addr = ioremap(mmio_start, mmio_len);
	if (!mmio_addr) {
		DEV_ERROR(prppdev, "%s:cannot remap mmio, aborting\n", pci_name(pdev));
		rc = -EIO;
		goto err_request_region;
	}

	DEV_DEBUG(prppdev, "mmio_addr = 0x%p\n", (void *)mmio_addr);

	if (!pci_set_dma_mask(pdev, DMA_BIT_MASK(64))) {
		prppdev->dma_mask = DMA_BIT_MASK(64);
		pci_set_consistent_dma_mask(pdev, DMA_BIT_MASK(64));
		DEV_DEBUG(prppdev, "Using a 64-bit DMA mask\n");
	} else {
		if (!pci_set_dma_mask(pdev, DMA_BIT_MASK(32))) {
			prppdev->dma_mask = DMA_BIT_MASK(32);
			pci_set_consistent_dma_mask(pdev, DMA_BIT_MASK(32));
			DEV_DEBUG(prppdev, "Using a 32-bit DMA mask\n");
		} else {
			DEV_ERROR(prppdev, "No suitable DMA possible\n");
			prppdev->dma_mask = 0;
			rc = -EIO;
			goto err_request_region;
		}
	}

	pci_read_config_byte(pdev, PCI_REVISION_ID, &prppdev->revision);
	pci_read_config_byte(pdev, PCI_INTERRUPT_PIN, &prppdev->irq_pin);
	pci_read_config_byte(pdev, PCI_INTERRUPT_LINE, &prppdev->irq_line);
	pci_read_config_word(pdev, PCI_SUBSYSTEM_VENDOR_ID, &prppdev->sub_vendor_id);
	pci_read_config_word(pdev, PCI_SUBSYSTEM_ID, &prppdev->sub_system_id);
	pci_read_config_word(pdev, PCI_VENDOR_ID, &prppdev->vendor_id);
	pci_read_config_word(pdev, PCI_DEVICE_ID, &prppdev->device_id);

	prppdev->mmio_addr = mmio_addr;
	prppdev->mmio_start = (void *)mmio_start;
	prppdev->mmio_len = mmio_len;

	RPP_map_bars(prppdev, pdev);

	/*  MPU firmware Gen1 -> Gen3 workaroud */
	RPP_rw_pci_cfg(pdev, 0, 4, 0x7c, (uint8_t *)&temp);
	rpp_genx_speed_change(prppdev, (uint8_t)(temp & 0xf));

	if (prppdev->small_bar) {
		/* workaround, reconfig the inbound ATU for BAR0 for expansion ROM issue, 20230223, willjiang. */
		temp = 0x0;
		RPP_rw_pci_bar(prppdev, 4, 1, 4, 0x300114, (UCHAR *)&temp);
		temp = 0x0;
		RPP_rw_pci_bar(prppdev, 4, 1, 4, 0x300118, (UCHAR *)&temp);
		temp = 0x0;
		RPP_rw_pci_bar(prppdev, 4, 1, 4, 0x300100, (UCHAR *)&temp);
		temp = 0xc0000000;
		RPP_rw_pci_bar(prppdev, 4, 1, 4, 0x300104, (UCHAR *)&temp);
	} else {
		/* workaround, reconfig the inbound ATU for BAR0 for expansion ROM issue, 20230223, willjiang. */
		temp = 0x0;
		RPP_rw_pci_bar(prppdev, 2, 1, 4, 0x7300114, (UCHAR *)&temp);
		temp = 0x0;
		RPP_rw_pci_bar(prppdev, 2, 1, 4, 0x7300118, (UCHAR *)&temp);
		temp = 0x0;
		RPP_rw_pci_bar(prppdev, 2, 1, 4, 0x7300100, (UCHAR *)&temp);
		temp = 0xc0000000;
		RPP_rw_pci_bar(prppdev, 2, 1, 4, 0x7300104, (UCHAR *)&temp);
	}

	if (prppdev->small_bar) {
		/* workaround, enhance pcie eye diagram, 20260122, willjiang. */
		temp = 0xa7000;
		RPP_rw_pci_bar(prppdev, 2, 1, 4, 0xa1034, (UCHAR *)&temp);
		temp = 0xc9244c92;
		RPP_rw_pci_bar(prppdev, 2, 1, 4, 0xa0028, (UCHAR *)&temp);
		temp = 0xc9244c92;
		RPP_rw_pci_bar(prppdev, 2, 1, 4, 0xa4028, (UCHAR *)&temp);
		temp = 0xc9244c92;
		RPP_rw_pci_bar(prppdev, 2, 1, 4, 0xa8028, (UCHAR *)&temp);
		temp = 0xc9244c92;
		RPP_rw_pci_bar(prppdev, 2, 1, 4, 0xac028, (UCHAR *)&temp);
	} else {
		/* workaround, enhance pcie eye diagram, 20260122, willjiang. */
		temp = 0xa7000;
		RPP_rw_pci_bar(prppdev, 2, 1, 4, 0x20a1034, (UCHAR *)&temp);
		temp = 0xc9244c92;
		RPP_rw_pci_bar(prppdev, 2, 1, 4, 0x20a0028, (UCHAR *)&temp);
		temp = 0xc9244c92;
		RPP_rw_pci_bar(prppdev, 2, 1, 4, 0x20a4028, (UCHAR *)&temp);
		temp = 0xc9244c92;
		RPP_rw_pci_bar(prppdev, 2, 1, 4, 0x20a8028, (UCHAR *)&temp);
		temp = 0xc9244c92;
		RPP_rw_pci_bar(prppdev, 2, 1, 4, 0x20ac028, (UCHAR *)&temp);
	}



	/* Check PCIe link status */
	if (prppdev->small_bar) {
		RPP_rw_pci_bar(prppdev, 4, 0, 4, PCIE_STATUS_REG_SMALL_BAR, (UCHAR *)&temp);
	} else {
		RPP_rw_pci_bar(prppdev, 2, 0, 4, PCIE_STATUS_REG_LARGE_BAR, (UCHAR *)&temp);
	}
	if (((temp & PCIE_LINK_STATUS_MASK) == 0x0) || (temp == PCIE_LINK_STATUS_INVALID)) {
		DEV_ERROR(prppdev, "PCIe Link failed(0x%x)! Try to remove pcie, then rescan pcie\n", temp);
		rc = -EIO;
		goto err_request_region;
	}

	RPP_priv_init(prppdev);

    DEV_DEBUG(prppdev, "before rpp_isr_init\n");
	rc = rpp_isr_init(prppdev, MSI_ONLY, IRQ_NUM);
	if(rc != 0)  {
		DEV_ERROR(prppdev, "device %s cannot init interrupt. \n", pci_name(pdev));
		goto err_request_region;
	}

	/* Note: pci_alloc_irq_vectors has already enabled interrupts */
	/* MSI masking is handled by the PCI subsystem */

	get_cached_msi_msg(prppdev->irq, &msg);
	if (EDMA) {
		if (prppdev->pdev->msi_enabled)
			DEV_DEBUG(prppdev, "IRQ MSI selected\n");
		else if (prppdev->pdev->msix_enabled)
			DEV_DEBUG(prppdev, "IRQ MSI-X selected\n");

		prppdev->RPP_ext.DmaRsc.MsiAddr.HighPart = msg.address_hi;
		prppdev->RPP_ext.DmaRsc.MsiAddr.LowPart = msg.address_lo;
		if (IRQ_NUM < 32) {
				prppdev->RPP_ext.DmaRsc.MsiData = msg.data;
		} else {
				prppdev->RPP_ext.DmaRsc.MsiData = msg.data + 22;
		}
		DEV_DEBUG(prppdev, "DmaRsc.MsiAddr_h=0x%.8x DmaRsc.MsiAddr_l=0x%.8x DmaRsc.MsiData=0x%.8x\n",
			   prppdev->RPP_ext.DmaRsc.MsiAddr.HighPart, prppdev->RPP_ext.DmaRsc.MsiAddr.LowPart,
			   prppdev->RPP_ext.DmaRsc.MsiData);

		/* Call HAL init function to reset DMA logic and renew MSI settings.
		 * We can also get the number of enabled write/read channels, which is
		 * used to segment the memory.
		 */
		if (HalDmaInit(&prppdev->RPP_ext.DmaRsc) != DMA_SUCCESS)	{
			DEV_ERROR(prppdev, "Failed to initial EDMA device\n");
            goto err_hal_dma_init;
		}
	}

	temp = 0x0;
	pci_read_config_dword(pdev, 0x78, &temp);
	pci_write_config_dword(pdev, 0x78, temp);
#if LINUX_VERSION_CODE < KERNEL_VERSION(6,6,0)
	pci_enable_pcie_error_reporting(pdev);
#endif
	rc = RppInitializeStep1(prppdev);
	if (rc != 0) {
		DEV_ERROR(prppdev, "RppInitializeStep1 failed\n");
		goto err_hal_dma_init;
	}

	rc = rpp_idle_low_power_init(prppdev);
	if (rc != 0) {
		DEV_ERROR(prppdev, "idle_low_power init failed, rc=%d\n", rc);
		return rc;
	}

	RPP_on_probe(prppdev);

	prppdev->status = RPP_PCIE_ONLINE;
	prppdev->init_dev_count = 1;

	/* Initialize device object itself for DEV_LOG */
	rpp_dev_setup_logging(prppdev);
	DEV_DEBUG(prppdev, "rpp_sdev_add_devices\n");
	rpp_sdev_add_devices(prppdev);

	rpp_dev_semaphore_init(prppdev);

	rpp_dev_update_logging(prppdev);

	if(rpp_dump_devinfo(prppdev) != 0) {
		DEV_ERROR(prppdev, "dump devinfo failed\n");
		return -1;
	}

	rc = rpp_idle_low_power_put(prppdev, "init");
	if (rc != 0) {
		DEV_ERROR(prppdev, "idle_low_power init suspend failed, rc=%d\n", rc);
		return rc;
	}

	DEV_DEBUG(prppdev, "RPP_probe end. rpp_dev: 0x%p,  pci_dev:  0x%p\n", prppdev, pdev);

	return 0;

err_devinfo:
	/* Cleanup subsystems on devinfo failure */
	rpp_sdev_remove_devices(prppdev);
	RPP_on_remove(prppdev);

err_hal_dma_init:
	/* Cleanup interrupt handling */
	if (prppdev)
		rpp_isr_exit(prppdev);

err_request_region:
	/* Resources managed by devm_* will be auto-freed */
	/* Only need to disable device if not using devm */

	if (prppdev && !prppdev->in_use)
		pci_disable_device(pdev);
	if (prppdev && prppdev->got_regions)
		pci_release_regions(pdev);

	return rc;
}

/**
 * Remove function for RPP PCIe device
 *
 * This function is called when the PCIe device is being removed.
 * It performs cleanup of resources and device state.
 *
 * @param pdev PCI device structure
 */
static void RPP_remove(struct pci_dev *pdev)
{
	struct rpp_dev *prppdev = pci_get_drvdata(pdev);
    uint32_t temp = 0;

	/* Check for NULL pointer before using it */
	if (!prppdev) {
		dev_err(&pdev->dev, "RPP_remove: prppdev is NULL\n");
		return;
	}

	DEV_DEBUG(prppdev, "RPP_remove rpp_dev: 0x%p, pci_dev: 0x%p\n", prppdev, pdev);

	if (prppdev->status != RPP_PCIE_ONLINE) {
		DEV_WARN(prppdev, "RPP probe not successful\n");
		return;
	}

	rpp_idle_low_power_deinit(prppdev);

	prppdev->status = RPP_PCIE_OFFLINE;

	/*  check pcie status */
	if(prppdev->small_bar){
		RPP_rw_pci_bar(prppdev, 4, 0, 4, 0x0, (UCHAR *)&temp);
	}else{
		RPP_rw_pci_bar(prppdev, 2, 0, 4, 0x7000000, (UCHAR *)&temp);
	}
	if(temp == 0xffffffff){
		DEV_WARN(prppdev, "PCIe Link failed(0x%x)\n", temp);
	}

	/* Clean up private resources */
	RPP_priv_exit(prppdev);

	DEV_DEBUG(prppdev, "rpp_sdev_remove_devices\n");
	rpp_sdev_remove_devices(prppdev);

	/* Disable PCIe error reporting */
#if LINUX_VERSION_CODE < KERNEL_VERSION(6,6,0)
	pci_disable_pcie_error_reporting(pdev);
#endif
	RPP_unmap_bars(prppdev, pdev);

	iounmap(prppdev->mmio_addr);

	pci_release_regions(pdev);

	pci_set_drvdata(pdev, NULL);

	pci_disable_device(pdev);

	/* Stop interrupt handling */
	rpp_isr_exit(prppdev);

    RPP_on_remove(prppdev);

	DEV_DEBUG(prppdev, "RPP_remove end. rpp_dev: 0x%p, pci_dev: 0x%p\n", prppdev, pdev);
}

static int rpp_dma_rw5_basic_test_run(void)
{
	BLK_ELEMENT blks[2];
	DMA_BLKS_INFO info;
	RPP_DMA_RW5_ROUTE route;
	UINT8 chan;
	UINT8 pong;
	UINT32 status;

	memset(blks, 0, sizeof(blks));
	memset(&info, 0, sizeof(info));
	info.mapped_num = 2;
	info.mapped_blk = blks;
	info.start = 0;
	info.start_offs = 0;
	info.end_size = 0x1000;

	info.vail_num = 1;
	status = rpp_dma_rw5_select_route(0, &info, &chan, &pong, &route);
	if (status != STATUS_SUCCESS || route != RPP_DMA_RW5_ROUTE_SINGLE_DESC ||
	    chan != 0) {
		pr_err("rpp: IoctlDmaRW5(CH0) single block route basic test failed, status=%u route=%d chan=%u pong=%u\n",
		       status, route, chan, pong);
		return -EINVAL;
	}

	info.vail_num = 2;
	status = rpp_dma_rw5_select_route(0, &info, &chan, &pong, &route);
	if (status != STATUS_SUCCESS || route != RPP_DMA_RW5_ROUTE_PINGPONG_DESC ||
	    chan != 0 || pong != 1) {
		pr_err("rpp: IoctlDmaRW5(CH0) multiple block route basic test failed, status=%u route=%d chan=%u pong=%u\n",
		       status, route, chan, pong);
		return -EINVAL;
	}

	pr_info("rpp: IoctlDmaRW5(CH0) route basic test passed\n");
	return 0;
}

int  RPP_init(void)
{
	int rc;

	if (rw5_basic_test) {
		rc = rpp_dma_rw5_basic_test_run();
		if (rc != 0)
			return rc;
	}

	rc = register_pm_notifier(&rpp_pm_notifier);
	if (rc != 0)
		return rc;

	rc = pci_register_driver(&RPP_pci_driver);
	if (rc != 0)
		unregister_pm_notifier(&rpp_pm_notifier);

	return rc;
}
EXPORT_SYMBOL_GPL(RPP_init);

void RPP_cleanup(void)
{
	pci_unregister_driver(&RPP_pci_driver);
	unregister_pm_notifier(&rpp_pm_notifier);
}
EXPORT_SYMBOL_GPL(RPP_cleanup);
