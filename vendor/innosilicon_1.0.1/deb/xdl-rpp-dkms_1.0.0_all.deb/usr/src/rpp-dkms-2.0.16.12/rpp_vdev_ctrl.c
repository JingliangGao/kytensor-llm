/*
 * This file is part of the Azurengine video engine driver for Linux
 *
 * Copyright (c) 2016-present,  Azurengine, Inc.
 * All rights reserved.
 *
 * This source code is licensed under both the BSD-style license (found in the
 * LICENSE file in the root directory of this source tree) and the GPLv2 (found
 * in the COPYING file in the root directory of this source tree).
 * You may select, at your option, one of the above-listed licenses.
 */

#include <linux/ioctl.h>
#include <linux/mm.h>
#include <linux/idr.h>
#include <asm/cacheflush.h>
#include <linux/delay.h>
#include <linux/sched/signal.h>
#include <linux/poll.h>
#include <linux/dma-mapping.h>
#include <linux/list.h>

#include "include/version.h"
#include "include/rpp_vdev.h"
#include "include/rpp_vdev_ctrl.h"
#include "include/rpp_cdev_ctrl.h"
#include "include/rpp_hal_pcie.h"
#include "include/rpp_pages.h"
#include "include/rpp_debug.h"
#include "include/rpp_dev.h"
#include "include/rpp_com.h"
#include "include/rpp_dma.h"
#include "include/rpp_pm.h"

#define SUPPORT_INSTANCE_BALANCE    1       /* enable instance balance feature */

#define ENABLE_ALL_CORES            1       /* enable all cores or half cores, depend device setting*/

#define MAX_INSTANCES_BY_VEMEM      1       /* maximum instance setting by ve memory size, reference by FHD video stream */

#define ENABLE_VMEM_CHECK           0       /* support vmem check while instance request */
#if ENABLE_VMEM_CHECK
#define MIN_VMEM_REQUEST            (36*1024*1024)
#endif

#define SUPPORT_WAVE_W_VPU          0       /* interrupt support wave serial, 1 w serial, 0 wave511 only */

#define SUPPORT_MULTI_OPEN_CLOSE            /* support mulit client open/close request same time */

/* VE memeory management in multi client mode
 * vmem block, use for vmem alloc/free, and it will add to memory list for crash check
 * inst block, use for open/close instance, and it will add to inst list for crash check
 * dma block, use for alloc/free dma buffer and will add to dma list for crash
 * codec inst block, use for alloc/free codec instance and will add to codec inst lis for crash check
*/
struct vmem_block{
    struct list_head list;
    struct Vmem_DmaMemory vmem;
    struct file *filp;
};

struct inst_block{
    struct list_head list;
    struct InstRequest inst;
    struct file *filp;
};

typedef struct vpu_crash_t {
    int count;                      /* how many instances crashed */
    int cause;                      /* root cause id */
    int filp;                       /* file header for open device */
    int coreIdx;                    /* process id for crash */
    int codecStd;                   /* codec standar for this instance */
    uint64_t lastWrPtr;             /* last bit stream write pointer */
} vpu_crash_t;

#define MAX_INST_HANDLE_SIZE            48          /* !!!DO NOT CHANGE THIS VALUE, otherwise sync with vdi.h */

/* !!!Any change should sync with vdi.h */
struct ve_instance_pool_t {
    unsigned char   codecInstPool[VE_CODEC_INSTANCE_NUM][MAX_INST_HANDLE_SIZE];
#ifdef SUPPORT_CRASH_REPAIRED
    vpu_crash_t     vpu_crash_status[VE_CODEC_INSTANCE_NUM];
#endif
    int             unTouch[VE_CODEC_INSTANCE_NUM]; /* untouch count for cmd_serial */
    int             vpu_instance_num;
    int             instance_pool_inited;
    void*           pendingInst;
    int             pendingInstIdxPlus1;
    uint32_t        lastPerformanceCycles;          /* v1.12.12 new feature */
    int             cmd_serial;                     /* vpu decoding comand turn */
#ifdef SUPPORT_CRASH_REPAIRED
    int             crash_state;
#endif
};

/* !!!Any change should sync with jdi.h */
struct ve_jpeg_pool_t {
    unsigned char   jpgInstPool[VE_JPEG_INSTANCE_NUM][MAX_INST_HANDLE_SIZE];
    void*           instPendingInst[VE_JPEG_INSTANCE_NUM];
    int             unTouch[VE_JPEG_INSTANCE_NUM];  /* untouch count for cmd_serial */
    int             jpu_instance_num;
    int             instance_pool_inited;
    int             cmd_serial;                     /* jpu decoding comand turn */
};

struct dma_block{
    struct list_head list;
    int32_t dma_offset;
    struct file *filp;
};

struct codec_inst_block{
    struct list_head list;
    struct CodecInstance codec_inst;
    struct file *filp;
};

#ifdef SUPPORT_CRASH_REPAIRED
struct instance_crash_block{
    struct list_head list;
    int core_index;
    int inst_index;
    int codecStd;
    uint64_t lastWrPtr;
    struct ve_instance_pool_t *vip;
    struct file *filp;
};
#else
struct codec_crash_block{
    struct list_head list;
    int8_t core_index;
    struct file *filp;
};
#endif

static struct list_head s_vmem_block_head           = LIST_HEAD_INIT(s_vmem_block_head);
#ifdef SUPPORT_MULTI_INST_INTR
static struct list_head s_inst_block_head           = LIST_HEAD_INIT(s_inst_block_head);
#endif
static struct list_head s_dma_block_head            = LIST_HEAD_INIT(s_dma_block_head);
static struct list_head s_codec_inst_block_head     = LIST_HEAD_INIT(s_codec_inst_block_head);
static struct list_head s_jpeg_inst_block_head      = LIST_HEAD_INIT(s_jpeg_inst_block_head);
#ifdef SUPPORT_CRASH_REPAIRED
static struct list_head s_instance_crash_block_head = LIST_HEAD_INIT(s_instance_crash_block_head);
#else
static struct list_head s_codec_crash_block_head    = LIST_HEAD_INIT(s_codec_crash_block_head);
static struct list_head s_jpeg_crash_block_head     = LIST_HEAD_INIT(s_jpeg_crash_block_head);
#endif

/* VE interrupt process block start
 * ve interrupt pend list for multi instance mode
 * v(j)int_flag-> instance interrupt flag
 * v(j)int_wait-> waiting queue for query instance interrupt
 * v(j)int_queue-> kfifo for instance interrupt storeage
 * v(j)int_lock-> kfifo read/write lock
 * MAX_INTERRUPT_QUEUE, maxiume interrupt for instance
*/
#define MAX_INTERRUPT_VQUEUE            (16)    /* should be 2^n */
#define MAX_INTERRUPT_JQUEUE            (16)    /* should be 2^n */

/*Coda serial codec definition*/
#define BIT_INT_CLEAR                   0x00C
#define BIT_INT_STS                     0x010
#define BIT_INT_REASON                  0x174

#define BODA950_CODE                    0x9500
#define CODA960_CODE                    0x9600
#define CODA980_CODE                    0x9800

#define PRODUCT_CODE_NOT_W_SERIES(x) (x == BODA950_CODE || x == CODA960_CODE || x == CODA980_CODE)

/*Wave5xx serial codec definition*/
#define WAVE512_CODE                    0x5120
#define WAVE515_CODE                    0x5150
#define WAVE511_CODE                    0x5110
#define WAVE521_CODE                    0x5210
#define WAVE521C_CODE                   0x521c
#define WAVE521C_DUAL_CODE              0x521d

#define PRODUCT_CODE_W_SERIES(x) (x == WAVE512_CODE || x == WAVE515_CODE || x == WAVE511_CODE || x == WAVE521_CODE || x == WAVE521C_CODE || x == WAVE521C_DUAL_CODE)

typedef enum {
    INT_WAVE5_INIT_VPU          = 0,
    INT_WAVE5_WAKEUP_VPU        = 1,
    INT_WAVE5_SLEEP_VPU         = 2,
    INT_WAVE5_CREATE_INSTANCE   = 3,
    INT_WAVE5_FLUSH_INSTANCE    = 4,
    INT_WAVE5_DESTORY_INSTANCE  = 5,
    INT_WAVE5_INIT_SEQ          = 6,
    INT_WAVE5_SET_FRAMEBUF      = 7,
    INT_WAVE5_DEC_PIC           = 8,
    INT_WAVE5_ENC_PIC           = 8,
    INT_WAVE5_ENC_SET_PARAM     = 9,
#ifdef SUPPORT_SOURCE_RELEASE_INTERRUPT
    INT_WAVE5_ENC_SRC_RELEASE   = 10,
#endif
    INT_WAVE5_ENC_LOW_LATENCY   = 13,
    INT_WAVE5_DEC_QUERY         = 14,
    INT_WAVE5_BSBUF_EMPTY       = 15,
    INT_WAVE5_BSBUF_FULL        = 15,
} Wave5InterruptBit;

#define VPU_PRODUCT_CODE_REGISTER       0x1044
#define W5_VPU_VPU_INT_STS              0x0044
#define W5_VPU_INT_REASON               0x004C
#define W5_VPU_INT_REASON_CLEAR         0x0034
#define W5_VPU_VINT_CLEAR               0x003C
#define W5_VPU_INT_USER_REASON          0x0030
#define W5_VPU_REMAP_PADDR              0x0068

#define W5_RET_BS_EMPTY_INST            0x01E4
#define W5_RET_QUEUE_CMD_DONE_INST      0x01E8
#define W5_RET_SEQ_DONE_INSTANCE_INFO   0x01FC

#define W5_CMD_INSTANCE_INFO            0x0110

#define W5_BS_OPTION                    0x0120
#define W5_BS_WR_PTR                    0x011C

#define W5_VPU_HOST_INT_REQ             0x0038
#define W5_VPU_BUSY_STATUS              0x0070
#define W5_VPU_HALT_STATUS              0x0074
#define W5_VPU_VCPU_STATUS              0x0078

#define W5_COMMAND                      0x0100
#define W5_RET_SUCCESS                  0x0108
#define W5_RET_FAIL_REASON              0x010C

#define W5_CMD_DEC_SET_DISP_IDC         0x0118
#define W5_CMD_DEC_CLR_DISP_IDC         0x011C

#define W5_QUERY_OPTION                 0x0104
#define W5_RET_DEC_DISPLAY_INDEX        0x0174

#define W5_VPU_FIO_CTRL_ADDR            0x0020
#define W5_VPU_FIO_DATA                 0x0024
#define W5_COMBINED_BACKBONE_BUS_CTRL   0xFE10
#define W5_COMBINED_BACKBONE_BUS_STATUS 0xFE14

#define W5_PO_CONF                      0x0000
#define W5_VCPU_CUR_PC                  0x0004
#define W5_VPU_RESET_REQ                0x0050
#define W5_VPU_CLK_MASK                 0x005C
#define W5_VPU_RESET_STATUS             0x0054
#define W5_RST_BLOCK_ALL                0x3FFFFFF


/*MJPEG serial codec reg definition*/
#define NPT_REG_SIZE                    0x300
#define NPT_BASE                        0x00
#define NPT_PROC_BASE                   (NPT_BASE + (4*NPT_REG_SIZE))

#define MJPEG_PIC_START_REG             0x000  /*instance picture start register*/
                                        /* [3] - start partial encoding
                                         * [2] - pic stop en/decoding
                                         * [1] - pic init en/decoding
                                         * [0] - pic start en/decoding
                                        */
typedef enum {
    JPG_START_PIC               = 0,
    JPG_START_INIT              = 1,
    JPG_START_PARTIAL           = 2,
    JPG_ENABLE_START_PIC        = 4,
    JPG_DEC_SLICE_ENABLE_START_PIC = 5
}JpuStartCmd;

#define MJPEG_PIC_STATUS_REG            0x004  /*instance picture status register*/
                                        /* [9] - slice done
                                         * [8] - stop
                                         * [7:4] - partial buffer interrupt
                                         * [3] - overflow
                                         * [2] - bbc interrupt
                                         * [1] - error
                                         * [0] - done
                                         */
/*picture interrupt statuts*/
typedef enum {
    INT_JPU_DONE                = 0,    /* completion of encoding/decoding a frame. */
    INT_JPU_ERROR               = 1,    /* occurrence of error. */
    INT_JPU_BIT_BUF_OVERFLOW    = 2,    /* JPU bit buffer encounters empty while decoding and full while encoding. */
    INT_JPU_SLICE_DONE          = 9,    /* completion of encoding a slice. */
}JpuInterruptBit;

#define JPEG_INTRRUPT_ID_VERIFY   0     /* support interrupt instance check */

#define MJPEG_INST_CTRL_START_REG       (NPT_PROC_BASE + 0x000)
#define MJPEG_INST_CTRL_STATUS_REG      (NPT_PROC_BASE + 0x004)
                                        /* [8:4] - FSM status of instance controller
                                         * 0-IDLE, 1-Load, 2-Run, 3-Pause, 4-Enc, 5-Pic don, 6-Slice done
                                         * [3:0] - instance controller statuts(interrupt) registers
                                         * 0-instance 0 interrupt pending
                                         * 1-instance 1 interrupt pending
                                         * 2-instance 2 interrupt pending
                                         * 3-instance 3 interrupt pending
                                         */
/*FSM status*/
typedef enum {
    INST_CTRL_IDLE              = 0,
    INST_CTRL_LOAD              = 1,
    INST_CTRL_RUN               = 2,
    INST_CTRL_PAUSE             = 3,
    INST_CTRL_ENC               = 4,
    INST_CTRL_PIC_DONE          = 5,
    INST_CTRL_SLC_DONE          = 6
}InstCtrlStates;

/*video engine common definition*/
#define VE_BAR                          2
#define VE_READ                         0
#define VE_WRITE                        1
#define VE_CODEC0                       0
#define VE_CODEC1                       1
#define VE_CODEC2                       2
#define VE_CODEC3                       3
#define VE_JPEG0                        0
#define VE_JPEG1                        1
#define VE_JPEG2                        2
#define VE_JPEG3                        3

#define VE_REG_BASE_LARGE_BAR           0x2000000
#define VE_REG_BASE_SMALL_BAR           0x0
#define VE_REG_SIZE                     0x10000

/* offset base on bar2 */
const uint32_t CodecRegOffset[4] = {0x02000000, 0x02010000, 0x02040000, 0x02050000};
const uint32_t JpegRegOffset[4]  = {0x02020000, 0x02030000, 0x02060000, 0x02070000};
/*
 * VE interrupt process block end
*/


#define MPU0_GLOBAL_ADDR            0x1010000000
#define MPU1_GLOBAL_ADDR            0x1011000000


#ifdef SUPPORT_MULTI_INST_INTR
static inline int32_t get_vpu_inst_idx(uint32_t *reason, uint32_t empty_inst, uint32_t done_inst, uint32_t seq_inst);
#endif

#ifdef SUPPORT_CRASH_REPAIRED
static int ve_updateBitstream(struct rpp_dev *dev, int coreIdx, int instIdx, int codecStd, uint64_t wrPtr)
{
    uint32_t vpuStatus, hostReq;
    uint32_t bsOpt, bsWrPtr;
    uint32_t instInfo, command;
    uint32_t waiting, result;
    uint32_t regOffset = CodecRegOffset[coreIdx];
    int ret = -1;

    if(dev->small_bar) {
        regOffset -= VE_REG_BASE_LARGE_BAR;
    }

    bsOpt = 3;                                          /* end of stream, explicit end */
    bsWrPtr = (uint32_t)wrPtr;                          /* last stream write pointer */
    instInfo = codecStd <<16 | instIdx & 0xffff;        /* instance info, codec standard and index */
    vpuStatus = 1;                                      /* vpu busy status for take ownership of host register */
    command = 0x8000;                                   /* command for update stream */
    hostReq = 1;                                        /* host interrupt request */
    /* bs option write */
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_BS_OPTION, (uint8_t *)&bsOpt);
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_BS_WR_PTR, (uint8_t *)&bsWrPtr);
    /* issue bit stream update command */
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_CMD_INSTANCE_INFO, (uint8_t *)&instInfo);
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_VPU_BUSY_STATUS, (uint8_t *)&vpuStatus);
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_COMMAND, (uint8_t *)&command);
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_VPU_HOST_INT_REQ, (uint8_t *)&hostReq);

    waiting = 100;
    while(waiting) {
        vpuStatus = 1;
        RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regOffset+W5_VPU_BUSY_STATUS, (uint8_t *)&vpuStatus);
        if (vpuStatus == 0) {
            ret = 0;
            break;
        }
        udelay(200);
        waiting--;
    }

    if (ret == 0) {
        result = 1;
        RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regOffset+W5_RET_SUCCESS, (uint8_t *)&result);
        if (result == 0)                    /* command not success */
        {pr_info("coreIdx %d inst %d failed to end stream command\n", coreIdx, instIdx); ret = -2;}
    }

    return ret;
}

static int ve_stopInstance(struct rpp_dev *dev, int coreIdx, int instIdx, int codecStd)
{
    uint32_t vpuStatus, hostReq;
    uint32_t instInfo, command;
    uint32_t waiting, result;
    uint32_t regOffset = CodecRegOffset[coreIdx];
    int ret = -1;

    if(dev->small_bar) {
        regOffset -= VE_REG_BASE_LARGE_BAR;
    }

    instInfo = codecStd <<16 | instIdx & 0xffff;        /* instance info, codec standard and index */
    vpuStatus = 1;                                      /* vpu busy status for take ownership of host register */
    command = 0x0020;                                   /* command for destroy instance */
    hostReq = 1;                                        /* host interrupt request */
    /* issue destroy instance command */
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_CMD_INSTANCE_INFO, (uint8_t *)&instInfo);
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_VPU_BUSY_STATUS, (uint8_t *)&vpuStatus);
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_COMMAND, (uint8_t *)&command);
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_VPU_HOST_INT_REQ, (uint8_t *)&hostReq);

    waiting = 100;
    while(waiting) {
        vpuStatus = 1;
        RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regOffset+W5_VPU_BUSY_STATUS, (uint8_t *)&vpuStatus);
        if (vpuStatus == 0) {
            ret = 0;
            break;
        }
        udelay(200);
        waiting--;
    }

    if (ret == 0) {
        result = 1;
        RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regOffset+W5_RET_SUCCESS, (uint8_t *)&result);
        if (result == 0) {
            RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regOffset+W5_RET_FAIL_REASON, (uint8_t *)&result);
            if (result == 0x1000)               /* still running */
            { pr_debug("coreIdx %d inst %d still running\n", coreIdx, instIdx); ret = -2; }
            else if (result == 0x2000)          /* watchdog timeout */
            { pr_info("coreIdx %d inst %d wtdog timeout\n", coreIdx, instIdx); ret = -3; }
            else                                /* system error */
            { pr_info("coreIdx %d inst %d systems error\n", coreIdx, instIdx); ret = -4; }
        }
    }

    return ret;
}

static int ve_checkInterrupt(struct rpp_dev *dev, int coreIdx, int instIdx)
{
    uint32_t intStatus;
    uint32_t intReason, clrReason, intr_clr;
    uint32_t empty_inst, done_inst, seq_inst;
    int32_t intr_inst_index;
    int ret = 0;

    uint32_t regOffset = CodecRegOffset[coreIdx];

    if(dev->small_bar) {
        regOffset -= VE_REG_BASE_LARGE_BAR;
    }

    intStatus = 0xffffffff;
    RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regOffset+W5_VPU_VPU_INT_STS, (uint8_t *)&intStatus);
    if (!intStatus) {
        /*no any interrupt happened*/
        pr_debug("coreIdx %d hans't interrupt report\n", coreIdx);
        return 0;
    }
    /*read interrupt reason*/
    RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regOffset+W5_VPU_INT_REASON, (uint8_t *)&intReason);
    /*read interrupt done*/
    RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regOffset+W5_RET_BS_EMPTY_INST, (uint8_t *)&empty_inst);
    RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regOffset+W5_RET_QUEUE_CMD_DONE_INST, (uint8_t *)&done_inst);
    RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regOffset+W5_RET_SEQ_DONE_INSTANCE_INFO, (uint8_t *)&seq_inst);
    if (0 == empty_inst && 0 == done_inst && 0 == seq_inst) {
        pr_info("coreIdx %d interrupt wrong report\n", coreIdx);
        return -1;
    }
    /*check interrupt owner*/
    intr_inst_index = get_vpu_inst_idx(&intReason, empty_inst, done_inst, seq_inst);
    if (intr_inst_index == instIdx) {
        clrReason = 0;

        if (intReason == (1 << INT_WAVE5_BSBUF_EMPTY)) {
            empty_inst = empty_inst & ~(1 << intr_inst_index);
            RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_RET_BS_EMPTY_INST, (uint8_t *)&empty_inst);
            if (0 == empty_inst) {
                clrReason |= 1<<INT_WAVE5_BSBUF_EMPTY;
                ret = 1;
                pr_info("coreIdx %d inst %d bs emptied interrupt report\n", coreIdx, instIdx);
            }
        }

        if (intReason == (1 << INT_WAVE5_DEC_PIC)) {
            done_inst = done_inst & ~(1 << intr_inst_index);
            RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_RET_QUEUE_CMD_DONE_INST, (uint8_t *)&done_inst);
            if (0 == done_inst) {
                clrReason |= 1<<INT_WAVE5_DEC_PIC;
                ret = 2;
                pr_info("coreIdx %d inst %d DEC_PIC interrupt report\n", coreIdx, instIdx);
            }
        }

        if ((intReason == (1 << INT_WAVE5_INIT_SEQ)) || (intReason == (1 << INT_WAVE5_ENC_SET_PARAM))) {
            seq_inst = seq_inst & ~(1 << intr_inst_index);
            RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_RET_SEQ_DONE_INSTANCE_INFO, (uint8_t *)&seq_inst);
            if (0 == seq_inst) {
                clrReason |= (1<<INT_WAVE5_INIT_SEQ | 1<<INT_WAVE5_ENC_SET_PARAM);
                ret = 3;
                pr_info("coreIdx %d inst %d SEQinit interrupt report\n", coreIdx, instIdx);
            }
        }

        if (intReason == (1 << INT_WAVE5_ENC_LOW_LATENCY)) {
            done_inst = (done_inst >> 16);
            done_inst = done_inst & ~(1 << intr_inst_index);
            done_inst = (done_inst << 16);
            RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_RET_QUEUE_CMD_DONE_INST, (uint8_t *)&done_inst);
            if (0 == done_inst) {
                clrReason |= ~(1 << INT_WAVE5_ENC_LOW_LATENCY);
                ret = 4;
                pr_info("coreIdx %d inst %d enc low latency interrupt report\n", coreIdx, instIdx);
            }
        }
        /*clear interrupt reason from coreIdx and instIdx*/
        if (clrReason) {
            RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_VPU_INT_REASON_CLEAR, (uint8_t *)&clrReason);
            intr_clr = 1;
            RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_VPU_VINT_CLEAR, (uint8_t *)&intr_clr);
            /*read user interrut reason and clear by clrReason flag*/
            RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regOffset+W5_VPU_INT_USER_REASON, (uint8_t *)&intReason);
            intReason &= ~clrReason;
            RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_VPU_INT_USER_REASON, (uint8_t *)&intReason);
        }
    }

    return ret;
}

static uint32_t ve_getOutputInfo(struct rpp_dev *dev, int coreIdx, int instIdx, int codecStd)
{
    uint32_t vpuStatus, hostReq;
    uint32_t queryOpt, instInfo, command;
    uint32_t waiting, result, indexFrameDisplay;
    uint32_t regOffset = CodecRegOffset[coreIdx];
    int ret = -1;

    if(dev->small_bar) {
        regOffset -= VE_REG_BASE_LARGE_BAR;
    }

    queryOpt = 2;                                       /* query option for get result */
    instInfo = codecStd <<16 | instIdx & 0xffff;        /* instance info, codec standard and index */
    vpuStatus = 1;                                      /* vpu busy status for take ownership of host register */
    command = 0x4000;                                   /* command for query */
    hostReq = 1;                                        /* host interrupt request */
    /* prepare query option */
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_QUERY_OPTION, (uint8_t *)&queryOpt);
    /* issue query command */
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_CMD_INSTANCE_INFO, (uint8_t *)&instInfo);
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_VPU_BUSY_STATUS, (uint8_t *)&vpuStatus);
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_COMMAND, (uint8_t *)&command);
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_VPU_HOST_INT_REQ, (uint8_t *)&hostReq);

    waiting = 100;
    while(waiting) {
        vpuStatus = 1;
        RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regOffset+W5_VPU_BUSY_STATUS, (uint8_t *)&vpuStatus);
        if (vpuStatus == 0) {
            ret = 0;
            break;
        }
        udelay(100);
        waiting--;
    }

    indexFrameDisplay = 16;
    if (ret == 0) {
        result = 1;
        RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regOffset+W5_RET_SUCCESS, (uint8_t *)&result);
        if (result == 0) {
            pr_info("coreIdx %d inst %d failed to GetOutputInfo command\n", coreIdx, instIdx);
        }else{
            RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regOffset+W5_RET_DEC_DISPLAY_INDEX, (uint8_t *)&indexFrameDisplay);
        }
    }

    return indexFrameDisplay;
}

static int ve_clearFramebuffer(struct rpp_dev *dev, int coreIdx, int instIdx, int codecStd, int indexDisplay)
{
    uint32_t vpuStatus, hostReq;
    uint32_t queryOpt, instInfo, command;
    uint32_t clrIdc, setIdc;
    uint32_t waiting, result;
    uint32_t regOffset = CodecRegOffset[coreIdx];
    int ret = -1;

    if(dev->small_bar) {
        regOffset -= VE_REG_BASE_LARGE_BAR;
    }

    clrIdc = 1 << indexDisplay;                         /* frame buffer 0~31 */
    setIdc = 0;
    queryOpt = 3;                                       /* query option for update display flag */
    instInfo = codecStd <<16 | instIdx & 0xffff;        /* instance info, codec standard and index */
    vpuStatus = 1;                                      /* vpu busy status for take ownership of host register */
    command = 0x4000;                                   /* command for query */
    hostReq = 1;                                        /* host interrupt request */
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_CMD_DEC_CLR_DISP_IDC, (uint8_t *)&clrIdc);
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_CMD_DEC_SET_DISP_IDC, (uint8_t *)&setIdc);
    /* prepare query option */
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_QUERY_OPTION, (uint8_t *)&queryOpt);
    /* issue query command */
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_CMD_INSTANCE_INFO, (uint8_t *)&instInfo);
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_VPU_BUSY_STATUS, (uint8_t *)&vpuStatus);
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_COMMAND, (uint8_t *)&command);
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regOffset+W5_VPU_HOST_INT_REQ, (uint8_t *)&hostReq);

    waiting = 100;
    while(waiting) {
        vpuStatus = 1;
        RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regOffset+W5_VPU_BUSY_STATUS, (uint8_t *)&vpuStatus);
        if (vpuStatus == 0) {
            ret = 0;
            break;
        }
        udelay(100);
        waiting--;
    }

    if (ret == 0) {
        result = 1;
        RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regOffset+W5_RET_SUCCESS, (uint8_t *)&result);
        if (result == 0) {
            ret = -2;      /* command not success */
            pr_info("coreIdx, %d inst %d failed to clear frame buffer command\n", coreIdx, instIdx);
        }
    }

    return ret;
}

static int ve_hotReset(struct rpp_dev *dev, int coreIdx)
{
    static const uint32_t veResetValue[VE_CODEC_NUM]={
    /* reset vpu of bpu and main only, except the apb/axi/2axi*/
        ((1<< 5) | (1<< 3)),
        ((1<< 6) | (1<< 4)),
        ((1<<21) | (1<<19)),
        ((1<<22) | (1<<20))
    };

    uint32_t regVal, regVE;
    uint32_t regCodec = CodecRegOffset[coreIdx];
    int ret, cnt;

    regVal = veResetValue[coreIdx];

    if(dev->small_bar) {
        uint32_t *buf;
        uint32_t *pRegClk, *pRegRst;

        buf = (uint32_t *)kzalloc(2*sizeof(uint32_t), GFP_KERNEL);
        if(buf == NULL) {
            pr_err("failed to kazalloc for hot reset\n");
            return -1;
        }
        pRegRst = buf;
        pRegClk = buf + 1;

        regCodec -= VE_REG_BASE_LARGE_BAR;

        ret = rpp_xfer_single(dev, pRegRst, MPU0_GLOBAL_ADDR + 0x21010, sizeof(uint32_t), 0, 0, 10);
        if(ret != sizeof(uint32_t)) {
            pr_err("failed to read ve reset control register\n");
            return -1;
        }
        ret = rpp_xfer_single(dev, pRegClk, MPU0_GLOBAL_ADDR + 0x20004, sizeof(uint32_t), 0, 0, 10);
        if(ret != sizeof(uint32_t)) {
            pr_err("failed to read ve clk gate control register\n");
            return -1;
        }
        pr_debug("reset value 0x%08x, clk gate value 0x%08x of ve control register\n", *pRegRst, *pRegClk);

        *pRegRst &= ~regVal;
        *pRegClk &= ~regVal;
        pr_debug("update reset value 0x%08x, clk gate value 0x%08x of ve control register\n", *pRegRst, *pRegClk);

        ret = rpp_xfer_single(dev, pRegClk, MPU0_GLOBAL_ADDR + 0x20004, sizeof(uint32_t), 1, 0, 10);
        if(ret != sizeof(uint32_t)) {
            pr_err("failed to write 0x%08x to ve clk gate control register\n", *pRegClk);
        }
        udelay(200);
        ret = rpp_xfer_single(dev, pRegRst, MPU0_GLOBAL_ADDR + 0x21010, sizeof(uint32_t), 1, 0, 10);
        if(ret != sizeof(uint32_t)) {
            pr_err("failed to write 0x%08x to ve reset control register\n", *pRegRst);
        }
        udelay(200);

        *pRegRst |= regVal;
        *pRegClk |= regVal;
        pr_debug("restore reset value 0x%08x, clk gate value 0x%08x of ve control register\n", *pRegRst, *pRegClk);

        ret = rpp_xfer_single(dev, pRegRst, MPU0_GLOBAL_ADDR + 0x21010, sizeof(uint32_t), 1, 0, 10);
        if(ret != sizeof(uint32_t)) {
            pr_err("failed to restore 0x%08x to ve reset control register\n", *pRegRst);
        }
        udelay(200);
        ret = rpp_xfer_single(dev, pRegClk, MPU0_GLOBAL_ADDR + 0x20004, sizeof(uint32_t), 1, 0, 10);
        if(ret != sizeof(uint32_t)) {
            pr_err("failed to restore 0x%08x to ve clk gate control register\n", *pRegClk);
        }
        kfree(buf);
    }
    else{
        uint32_t regClk, regRst;

        RPP_rw_pci_bar(dev, 4, 0, 4, 0x21010, (uint8_t *)&regRst);
        RPP_rw_pci_bar(dev, 4, 0, 4, 0x20004, (uint8_t *)&regClk);
        pr_debug("reset value 0x%08x, clk gate value 0x%08x of ve control register\n", regRst, regClk);

        regRst &= ~regVal;
        regClk &= ~regVal;
        pr_debug("update reset value 0x%08x, clk gate value 0x%08x of ve control register\n", regRst, regClk);

        RPP_rw_pci_bar(dev, 4, 1, 4, 0x20004, (uint8_t *)&regClk);
        udelay(200);
        RPP_rw_pci_bar(dev, 4, 1, 4, 0x21010, (uint8_t *)&regRst);
        udelay(200);

        regRst |= regVal;
        regClk |= regVal;
        pr_debug("restore reset value 0x%08x, clk gate value 0x%08x of ve control register\n", regRst, regClk);

        RPP_rw_pci_bar(dev, 4, 1, 4, 0x21010, (uint8_t *)&regRst);
        udelay(200);
        RPP_rw_pci_bar(dev, 4, 1, 4, 0x20004, (uint8_t *)&regClk);
    }
#if 1 /* enable vpu bus status check */
    /* check vpu bus lock issue */
    regVE = W5_COMBINED_BACKBONE_BUS_STATUS;
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regCodec+W5_VPU_FIO_CTRL_ADDR, (uint8_t *)&regVE);
    cnt = 100;
    ret = -1;
    do{
        udelay(200);
        RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regCodec+W5_VPU_FIO_CTRL_ADDR, (uint8_t *)&regVal);
        if (regVal & 0x80000000) {
            RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regCodec+W5_VPU_FIO_DATA, (uint8_t *)&regVal);
            ret = 0;
            break;
        }
        cnt--;
    }while(cnt != 0);
    if (ret == -1) {
        pr_info("fail to get coreIdx 0x%08x vpu bus status\n", coreIdx);
        return -1;
    }
    if (regVal == 0x3F) {
        pr_info("coreIdx 0x%08x bus free run\n", coreIdx);
        return 0;
    }
#endif
    /* reset vpu bus matrix */
    regVE = 0x07;
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regCodec+W5_VPU_FIO_DATA, (uint8_t *)&regVE);
    regVE = W5_COMBINED_BACKBONE_BUS_CTRL | (1 <<16);
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regCodec+W5_VPU_FIO_CTRL_ADDR, (uint8_t *)&regVE);
    cnt = 100;
    ret = -1;
    do{
        udelay(200);
        RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regCodec+W5_VPU_FIO_CTRL_ADDR, (uint8_t *)&regVal);
        if (regVal & 0x80000000) {
            ret = 0;
            break;
        }
        cnt--;
    }while(cnt != 0);
    if (ret == -1) {
        pr_info("failed to reset coreIdx 0x%08x backbone\n", coreIdx);
        return -1;
    }

    /* check vpu bus status */
    regVE = W5_COMBINED_BACKBONE_BUS_STATUS;
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regCodec+W5_VPU_FIO_CTRL_ADDR, (uint8_t *)&regVE);
    cnt = 100;
    ret = -1;
    do{
        udelay(200);
        RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regCodec+W5_VPU_FIO_CTRL_ADDR, (uint8_t *)&regVal);
        if (regVal & 0x80000000) {
            RPP_rw_pci_bar(dev, VE_BAR, VE_READ, 4, regCodec+W5_VPU_FIO_DATA, (uint8_t *)&regVal);
            ret = 0;
            break;
        }
        cnt--;
    }while(cnt != 0);
    regVE = 0;
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regCodec+W5_VPU_FIO_DATA, (uint8_t *)&regVE);
    regVE = W5_COMBINED_BACKBONE_BUS_CTRL | (1 <<16);
    RPP_rw_pci_bar(dev, VE_BAR, VE_WRITE, 4, regCodec+W5_VPU_FIO_CTRL_ADDR, (uint8_t *)&regVE);

    if (ret != 0 || regVal != 0x3F)
        return -1;
    else
        return 0;
}
#endif

static int ve_ioctl_load_vdi_param(struct file* filp, struct rpp_dev *pdev, void *data)
{
    int command, ret;
    void *buf;

    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    uint64_t* param = (uint64_t *)data;

    if (vdev == NULL || veEngine == NULL) {
        pr_err("failed to find veEngine instance\n");
        return -ENODEV;
    }

    buf = (uint32_t *)kzalloc(sizeof(uint32_t), GFP_KERNEL);
    if(buf == NULL) {
        pr_err("failed to kazalloc for hot reset\n");
        return -ENOMEM;
    }
    /*read 0x20008 for vcpu clk, timeout 100ms*/
    ret = rpp_xfer_single(pdev, buf, MPU0_GLOBAL_ADDR + 0x20008, sizeof(uint32_t), 0, 0, 100);
    if(ret != sizeof(uint32_t)) {
        pr_err("veEngine %p failed to read vcpu clk reg 0x20008\n", veEngine);
        kfree(buf);
        return -ENODEV;
    }
    if (((*(uint32_t *)buf>>24) & 0x03) != 0x03) {
        pr_err("veEngine %p vcpu clk gate off now, can't write vdi param\n", veEngine);
        kfree(buf);
        return -ENODEV;
    }
    kfree(buf);

    command = (int)*param;
    if (veEngine->vdi_param_status != command) {
        buf = kzalloc(sizeof(struct vdi_buffer_t), GFP_KERNEL);
        if(buf == NULL) {
            pr_err("veEngine %p failed allocate buf of mpu vdi memory\n", veEngine);
            return -ENOMEM;
        }

        if (command == 1) { /*request allocate*/
            memcpy(buf, &veEngine->common_memory, sizeof(struct vdi_buffer_t));
        }else/* if (command == 2)*/ {/*requeset release*/
            memset(buf, 0x0, sizeof(struct vdi_buffer_t));
        }
        ret = rpp_xfer_single(pdev, buf, MPU1_GLOBAL_ADDR + MPU_VDI_MEMORY_OFFSET, sizeof(struct vdi_buffer_t), 1, 0, 100);
        if (ret != sizeof(struct vdi_buffer_t)) {
            ret = -ENODEV;
            pr_err("veEngine %p failed transfer common memory to mpu\n", veEngine);
        }
        else{
            veEngine->vdi_param_status = command;
            pr_info("veEngine %p success %s vdi param for rpc command\n", veEngine, (command==1)?"allocate":"release");
        }
        kfree(buf);
    }else{
        pr_info("veEngine %p already %s vdi param for rpc command\n", veEngine, (command==1)?"allocate":"release");
    }

    if (command == 1) {
        *param = veEngine->common_memory.phys_addr;
    }else /* if (command == 2)*/{
        *param = 0x0;
    }

    return 0;
}

#ifdef SUPPORT_MULTI_INST_INTR
int rpp_init_veInterrupt(struct rpp_dev *xpdev, struct InterruptManager *veInterrupt)
{
    int res;
    int i,j;

    if (xpdev == NULL|| veInterrupt == NULL) {
        pr_err("ERR!!!, %s can't initial veInterrupt\n", __func__);
        return -1;
    }

    for (i=0; i<VE_CODEC_NUM; i++) {
        for (j=0; j<VE_CODEC_INSTANCE_NUM; j++) {
            init_waitqueue_head(&veInterrupt->vint_wait[i][j]);
            spin_lock_init(&veInterrupt->vint_lock[i][j]);
            res = kfifo_alloc(&veInterrupt->vint_queue[i][j], MAX_INTERRUPT_VQUEUE*sizeof(uint32_t), GFP_KERNEL);
            if (res) {
                pr_err("[VE-DRIVER] codec interrupt queue alloc failed 0x%x\n", res);
                return -1;
            }
        }
    }

    for (i=0; i<VE_JPEG_NUM; i++) {
        for (j=0; j<VE_JPEG_INSTANCE_NUM; j++) {
            init_waitqueue_head(&veInterrupt->jint_wait[i][j]);
            spin_lock_init(&veInterrupt->jint_lock[i][j]);
            res = kfifo_alloc(&veInterrupt->jint_queue[i][j], MAX_INTERRUPT_JQUEUE*sizeof(uint32_t), GFP_KERNEL);
            if (res) {
                pr_err("[VE-DRIVER] jpeg interrupt queue alloc failed 0x%x\n", res);
                return -1;
            }
        }
    }
    return 0;
}

int rpp_destroy_veInterrupt(struct rpp_dev *xpdev, struct InterruptManager *veInterrupt)
{
    int i,j;

    if (xpdev == NULL|| veInterrupt == NULL) {
        pr_err("ERR!!!, %s can't destroy veInterrupt\n", __func__);
        return -1;
    }

    for (i=0; i<VE_CODEC_NUM; i++) {
        for (j=0; j<VE_CODEC_INSTANCE_NUM; j++) {
            kfifo_free(&veInterrupt->vint_queue[i][j]);
        }
    }

    for (i=0; i<VE_JPEG_NUM; i++) {
        for (j=0; j<VE_JPEG_INSTANCE_NUM; j++) {
            kfifo_free(&veInterrupt->jint_queue[i][j]);
        }
    }

    return 0;
}

static inline uint32_t get_inst_idx(uint32_t reg_val, uint32_t insNum)
{
    uint32_t i;

    for (i=0; i < insNum; i++) {
        if(((reg_val >> i)&0x01) == 1)
            break;
    }
    return i;
}

static inline int32_t get_vpu_inst_idx(uint32_t *reason, uint32_t empty_inst, uint32_t done_inst, uint32_t seq_inst)
{
    int32_t  inst_idx;
    uint32_t reg_val;
    uint32_t int_reason;

    int_reason = *reason;

    if (int_reason & (1 << INT_WAVE5_BSBUF_EMPTY)) {
        reg_val = (empty_inst & 0xffff);
        inst_idx = get_inst_idx(reg_val, VE_CODEC_INSTANCE_NUM);
        *reason = (1 << INT_WAVE5_BSBUF_EMPTY);
        goto GET_VPU_INST_IDX_HANDLED;
    }

    if (int_reason & (1 << INT_WAVE5_INIT_SEQ)) {
        reg_val = (seq_inst & 0xffff);
        inst_idx = get_inst_idx(reg_val, VE_CODEC_INSTANCE_NUM);
        *reason  = (1 << INT_WAVE5_INIT_SEQ);
        goto GET_VPU_INST_IDX_HANDLED;
    }

    if (int_reason & (1 << INT_WAVE5_DEC_PIC)) {
        reg_val = (done_inst & 0xffff);
        inst_idx = get_inst_idx(reg_val, VE_CODEC_INSTANCE_NUM);
        *reason  = (1 << INT_WAVE5_DEC_PIC);

        if (int_reason & (1 << INT_WAVE5_ENC_LOW_LATENCY)) {
            uint32_t ll_inst_idx;
            reg_val = (done_inst >> 16);
            ll_inst_idx = get_inst_idx(reg_val, VE_CODEC_INSTANCE_NUM);
            if (ll_inst_idx == inst_idx)
            *reason = ((1 << INT_WAVE5_DEC_PIC) | (1 << INT_WAVE5_ENC_LOW_LATENCY));
        }
        goto GET_VPU_INST_IDX_HANDLED;
    }

    if (int_reason & (1 << INT_WAVE5_ENC_SET_PARAM)) {
        reg_val = (seq_inst & 0xffff);
        inst_idx = get_inst_idx(reg_val, VE_CODEC_INSTANCE_NUM);
        *reason  = (1 << INT_WAVE5_ENC_SET_PARAM);
        goto GET_VPU_INST_IDX_HANDLED;
    }

#ifdef SUPPORT_SOURCE_RELEASE_INTERRUPT
    if (int_reason & (1 << INT_WAVE5_ENC_SRC_RELEASE)) {
        reg_val = (done_inst & 0xffff);
        inst_idx = get_inst_idx(reg_val, VE_CODEC_INSTANCE_NUM);
        *reason  = (1 << INT_WAVE5_ENC_SRC_RELEASE);
        goto GET_VPU_INST_IDX_HANDLED;
    }
#endif

    if (int_reason & (1 << INT_WAVE5_ENC_LOW_LATENCY)) {
        reg_val = (done_inst >> 16);
        inst_idx = get_inst_idx(reg_val, VE_CODEC_INSTANCE_NUM);
        *reason  = (1 << INT_WAVE5_ENC_LOW_LATENCY);
        goto GET_VPU_INST_IDX_HANDLED;
    }

    /*if interrupt is not for empty and dec_pic and init_seq.*/
    inst_idx = -1;
    *reason  = 0;
    pr_err("[VE-INT], unknow interrupt: 0x%08x, empty_inst: 0x%08x, done_inst: 0x%08x, seq_inst: 0x%08x\n",
                      int_reason, empty_inst, done_inst, seq_inst);

GET_VPU_INST_IDX_HANDLED:
    return inst_idx;
}

void codec0_isr_handler(void *dev)
{
    struct rpp_dev *pdev;
    struct InterruptManager *veInterrupt;
    uint32_t product_code;
    int32_t intr_inst_index;

    uint32_t intr_status, intr_clr;
    uint32_t intr_reason, reason;
    uint32_t empty_inst, done_inst, seq_inst;
    uint32_t i, reason_clr;
    uint32_t regOffset = CodecRegOffset[VE_CODEC0];

    pdev = (struct rpp_dev *)dev;
    veInterrupt = (struct InterruptManager *)pdev->entire_ctrl_vdev.veInterrupt;

    if(veInterrupt == NULL) {
        pr_err("[VE0-INT] current rpp deviec %p doesn't initial ve interrupt manager\n", pdev);
        return;
    }
#ifdef VPU_HAL_MPU
    /*respond the driver remove*/
    return;
#endif

    if(pdev->small_bar) {
        regOffset -= VE_REG_BASE_LARGE_BAR;
    }

#if SUPPORT_WAVE_W_VPU
    RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+VPU_PRODUCT_CODE_REGISTER, (uint8_t *)&product_code);
    if (PRODUCT_CODE_W_SERIES(product_code)) {
#endif
        RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_VPU_VPU_INT_STS, (uint8_t *)&intr_status);
        if (intr_status) {
            reason = 0;
            RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_VPU_INT_REASON, (uint8_t *)&reason);
            reason_clr = reason;

            /*get instance info with difference interrupt type*/
            RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_RET_BS_EMPTY_INST, (uint8_t *)&empty_inst);
            RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_RET_QUEUE_CMD_DONE_INST, (uint8_t *)&done_inst);
            RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_RET_SEQ_DONE_INSTANCE_INFO, (uint8_t *)&seq_inst);
            pr_debug("[VE0-INT], interrupt: 0x%08x, empty_inst: 0x%08x, done_inst: 0x%08x, seq_inst: 0x%08x\n",
                      reason, empty_inst, done_inst, seq_inst);

            for (i=0; i <VE_CODEC_INSTANCE_NUM; i++) {
                intr_reason = reason;
                if (0 == empty_inst && 0 == done_inst && 0 == seq_inst) {
                    pr_debug("[VE0_INT] turn %d has't remain any instance interrupt\n", i);
                    break;
                }

                /* new interrupt happen during ISR, should update interrupt reason */
                if (i > 0 && 0 == intr_reason) {
                /* 1) refresh interrupt reason
                 * 2) update current interrupt source
                 * 3) update current interrupt reason
                 * !!! Don't change the order
                 */
                    RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_VPU_INT_REASON, (uint8_t *)&reason);
                    pr_info("[VE0_INT] get new interrupt reason 0x%08x, old reason 0x%08x\n", reason, reason_clr);
                    intr_reason = reason & ~(reason_clr);
                    reason_clr = reason;
                    reason = intr_reason;
                    pr_info("[VE0_INT] interrupt source: empty: 0x%08x, done: 0x%08x, seq: 0x%08x\n", empty_inst, done_inst, seq_inst);
                }

                intr_inst_index = get_vpu_inst_idx(&intr_reason, empty_inst, done_inst, seq_inst);
                if (intr_inst_index >= 0 && intr_inst_index < VE_CODEC_INSTANCE_NUM) {
                    if (intr_reason == (1 << INT_WAVE5_BSBUF_EMPTY)) {
                        empty_inst = empty_inst & ~(1 << intr_inst_index);
                        RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_RET_BS_EMPTY_INST, (uint8_t *)&empty_inst);
                        if (0 == empty_inst) {
                            reason &= ~(1<<INT_WAVE5_BSBUF_EMPTY);
                        }
                    }

                    if (intr_reason == (1 << INT_WAVE5_DEC_PIC)) {
                        done_inst = done_inst & ~(1 << intr_inst_index);
                        RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_RET_QUEUE_CMD_DONE_INST, (uint8_t *)&done_inst);
                        if (0 == done_inst) {
                            reason &= ~(1<<INT_WAVE5_DEC_PIC);
                        }
                    }

                    if ((intr_reason == (1 << INT_WAVE5_INIT_SEQ)) || (intr_reason == (1 << INT_WAVE5_ENC_SET_PARAM))) {
                        seq_inst = seq_inst & ~(1 << intr_inst_index);
                        RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_RET_SEQ_DONE_INSTANCE_INFO, (uint8_t *)&seq_inst);
                        if (0 == seq_inst) {
                            reason &= ~(1<<INT_WAVE5_INIT_SEQ | 1<<INT_WAVE5_ENC_SET_PARAM);
                        }
                    }

                    if (intr_reason == (1 << INT_WAVE5_ENC_LOW_LATENCY)) {
                        done_inst = (done_inst >> 16);
                        done_inst = done_inst & ~(1 << intr_inst_index);
                        done_inst = (done_inst << 16);
                        RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_RET_QUEUE_CMD_DONE_INST, (uint8_t *)&done_inst);
                        if (0 == done_inst) {
                            reason &= ~(1 << INT_WAVE5_ENC_LOW_LATENCY);
                        }
                    }

                    pr_debug("[VE0_INT] turn %d get instance %d interrupt 0x%08x\n", i, intr_inst_index, intr_reason);

                    if (!kfifo_is_full(&veInterrupt->vint_queue[VE_CODEC0][intr_inst_index])) {
                        if (intr_reason == ((1 << INT_WAVE5_ENC_PIC) | (1 << INT_WAVE5_ENC_LOW_LATENCY))) {
                            uint32_t ll_intr_reason = (1 << INT_WAVE5_ENC_PIC);
                            kfifo_in_spinlocked(&veInterrupt->vint_queue[VE_CODEC0][intr_inst_index], &ll_intr_reason,
                                                sizeof(uint32_t), &veInterrupt->vint_lock[VE_CODEC0][intr_inst_index]);
                        }
                        else
                            kfifo_in_spinlocked(&veInterrupt->vint_queue[VE_CODEC0][intr_inst_index], &intr_reason,
                                                sizeof(uint32_t), &veInterrupt->vint_lock[VE_CODEC0][intr_inst_index]);
                    }
                    else {
                        pr_err("[VE0_INT] instance: %d kfifo_is_full kfifo_count=%d \n",
                                intr_inst_index, kfifo_len(&veInterrupt->vint_queue[VE_CODEC0][intr_inst_index]));
                    }
                }
                else {
                    pr_err("[VE0_INT] %d turn, intr_inst_index is wrong, intr_inst_index=%d, intr_reason=0x%08x inital reason=0x%08x\n",
                            i, intr_inst_index, intr_reason, reason_clr);
                }
            }

            if (0 != reason){
                pr_err("[VE0_INT] INTERRUPT REASON REMAINED: %08x\n", reason);
            }

            RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_VPU_INT_REASON_CLEAR, (uint8_t *)&reason_clr);
            intr_clr = 1;
            RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_VPU_VINT_CLEAR, (uint8_t *)&intr_clr);
        }
        else{
            pr_err("[VE0_INT] isr error report without ve interrupt status\n");
        }
#if SUPPORT_WAVE_W_VPU
    }
    else if (PRODUCT_CODE_NOT_W_SERIES(product_code)) {
        RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+BIT_INT_STS, (uint8_t *)&intr_status);
        if (intr_status) {
            RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+BIT_INT_REASON, (uint8_t *)&intr_reason);
            intr_inst_index = 0; /*  in case of coda seriese. treats intr_inst_index is already 0 */
            kfifo_in_spinlocked(&veInterrupt->vint_queue[VE_CODEC0][intr_inst_index], &intr_reason,
                                sizeof(uint8_t), &veInterrupt->vint_lock[VE_CODEC0][intr_inst_index]);
            intr_clr = 1;
            RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+BIT_INT_CLEAR, (uint8_t *)&intr_clr);
        }
    }
    else {
        pr_err("[VE0_INT] Unknown product id : %08x\n", product_code);
    }
#endif

    /*send the responding while get availabe interrupt*/
    for (i = 0; i < VE_CODEC_INSTANCE_NUM; i++) {
        if (kfifo_len(&veInterrupt->vint_queue[VE_CODEC0][i])) {
            veInterrupt->vint_flag[VE_CODEC0][i] = 1;
            wake_up_interruptible(&veInterrupt->vint_wait[VE_CODEC0][i]);
            pr_debug("[VE0_INT] instance %d interrupt happend\n", i);
        }
    }
}

void codec1_isr_handler(void *dev)
{
    struct rpp_dev *pdev;
    struct InterruptManager *veInterrupt;
    uint32_t product_code;
    int32_t intr_inst_index;

    uint32_t intr_status, intr_clr;
    uint32_t intr_reason, reason;
    uint32_t empty_inst, done_inst, seq_inst;
    uint32_t i, reason_clr;
    uint32_t regOffset = CodecRegOffset[VE_CODEC1];

    pdev = (struct rpp_dev *)dev;
    veInterrupt = (struct InterruptManager *)pdev->entire_ctrl_vdev.veInterrupt;

    if(veInterrupt == NULL) {
        pr_err("[VE1-INT] current rpp deviec %p doesn't initial ve interrupt manager\n", pdev);
        return;
    }
#ifdef VPU_HAL_MPU
    /*respond the driver remove*/
    return;
#endif

    if(pdev->small_bar) {
        regOffset -= VE_REG_BASE_LARGE_BAR;
    }

#if SUPPORT_WAVE_W_VPU
    RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+VPU_PRODUCT_CODE_REGISTER, (uint8_t *)&product_code);
    if (PRODUCT_CODE_W_SERIES(product_code)) {
#endif
        RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_VPU_VPU_INT_STS, (uint8_t *)&intr_status);
        if (intr_status) {
            reason = 0;
            RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_VPU_INT_REASON, (uint8_t *)&reason);
            reason_clr = reason;

            /*get instance info with difference interrupt type*/
            RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_RET_BS_EMPTY_INST, (uint8_t *)&empty_inst);
            RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_RET_QUEUE_CMD_DONE_INST, (uint8_t *)&done_inst);
            RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_RET_SEQ_DONE_INSTANCE_INFO, (uint8_t *)&seq_inst);
            pr_debug("[VE1-INT], interrupt: 0x%08x, empty_inst: 0x%08x, done_inst: 0x%08x, seq_inst: 0x%08x\n",
                      reason, empty_inst, done_inst, seq_inst);

            for (i=0; i <VE_CODEC_INSTANCE_NUM; i++) {
                intr_reason = reason;
                if (0 == empty_inst && 0 == done_inst && 0 == seq_inst) {
                    pr_debug("[VE1_INT] turn %d has't remain any instance interrupt\n", i);
                    break;
                }

                /* new interrupt happen during ISR, should update interrupt reason */
                if (i > 0 && 0 == intr_reason) {
                /* 1) refresh interrupt reason
                 * 2) update current interrupt source
                 * 3) update current interrupt reason
                 * !!! Don't change the order
                 */
                    RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_VPU_INT_REASON, (uint8_t *)&reason);
                    pr_info("[VE1_INT] get new interrupt reason 0x%08x, old reason 0x%08x\n", reason, reason_clr);
                    intr_reason = reason & ~(reason_clr);
                    reason_clr = reason;
                    reason = intr_reason;
                    pr_info("[VE1_INT] interrupt source: empty: 0x%08x, done: 0x%08x, seq: 0x%08x\n", empty_inst, done_inst, seq_inst);
                }

                intr_inst_index = get_vpu_inst_idx(&intr_reason, empty_inst, done_inst, seq_inst);
                if (intr_inst_index >= 0 && intr_inst_index < VE_CODEC_INSTANCE_NUM)
                {
                    if (intr_reason == (1 << INT_WAVE5_BSBUF_EMPTY)) {
                        empty_inst = empty_inst & ~(1 << intr_inst_index);
                        RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_RET_BS_EMPTY_INST, (uint8_t *)&empty_inst);
                        if (0 == empty_inst) {
                            reason &= ~(1<<INT_WAVE5_BSBUF_EMPTY);
                        }
                    }

                    if (intr_reason == (1 << INT_WAVE5_DEC_PIC)) {
                        done_inst = done_inst & ~(1 << intr_inst_index);
                        RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_RET_QUEUE_CMD_DONE_INST, (uint8_t *)&done_inst);
                        if (0 == done_inst) {
                            reason &= ~(1<<INT_WAVE5_DEC_PIC);
                        }
                    }

                    if ((intr_reason == (1 << INT_WAVE5_INIT_SEQ)) || (intr_reason == (1 << INT_WAVE5_ENC_SET_PARAM))) {
                        seq_inst = seq_inst & ~(1 << intr_inst_index);
                        RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_RET_SEQ_DONE_INSTANCE_INFO, (uint8_t *)&seq_inst);
                        if (0 == seq_inst) {
                            reason &= ~(1<<INT_WAVE5_INIT_SEQ | 1<<INT_WAVE5_ENC_SET_PARAM);
                        }
                    }

                    if (intr_reason == (1 << INT_WAVE5_ENC_LOW_LATENCY)) {
                        done_inst = (done_inst >> 16);
                        done_inst = done_inst & ~(1 << intr_inst_index);
                        done_inst = (done_inst << 16);
                        RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_RET_QUEUE_CMD_DONE_INST, (uint8_t *)&done_inst);
                        if (0 == done_inst) {
                            reason &= ~(1 << INT_WAVE5_ENC_LOW_LATENCY);
                        }
                    }

                    pr_debug("[VE1_INT] turn %d get instance %d interrupt 0x%08x\n", i, intr_inst_index, intr_reason);

                    if (!kfifo_is_full(&veInterrupt->vint_queue[VE_CODEC1][intr_inst_index])) {
                        if (intr_reason == ((1 << INT_WAVE5_ENC_PIC) | (1 << INT_WAVE5_ENC_LOW_LATENCY))) {
                            uint32_t ll_intr_reason = (1 << INT_WAVE5_ENC_PIC);
                            kfifo_in_spinlocked(&veInterrupt->vint_queue[VE_CODEC1][intr_inst_index], &ll_intr_reason,
                                                sizeof(uint32_t), &veInterrupt->vint_lock[VE_CODEC1][intr_inst_index]);
                        }
                        else
                            kfifo_in_spinlocked(&veInterrupt->vint_queue[VE_CODEC1][intr_inst_index], &intr_reason,
                                                sizeof(uint32_t), &veInterrupt->vint_lock[VE_CODEC1][intr_inst_index]);
                    }
                    else {
                        pr_err("[VE1_INT] instance: %d kfifo_is_full kfifo_count=%d \n",
                                intr_inst_index, kfifo_len(&veInterrupt->vint_queue[VE_CODEC1][intr_inst_index]));
                    }
                }
                else {
                    pr_err("[VE1_INT] %d turn, intr_inst_index is wrong, intr_inst_index=%d, intr_reason=0x%08x inital reason=0x%08x\n",
                            i, intr_inst_index, intr_reason, reason_clr);
                }
            }

            if (0 != reason){
                pr_err("[VE1_INT] INTERRUPT REASON REMAINED: %08x\n", reason);
            }

            RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_VPU_INT_REASON_CLEAR, (uint8_t *)&reason_clr);
            intr_clr = 1;
            RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_VPU_VINT_CLEAR, (uint8_t *)&intr_clr);
        }
        else{
            pr_err("[VE1_INT] isr error report without ve interrupt status\n");
        }
#if SUPPORT_WAVE_W_VPU
    }
    else if (PRODUCT_CODE_NOT_W_SERIES(product_code)) {
        RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+BIT_INT_STS, (uint8_t *)&intr_status);
        if (intr_status) {
            RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+BIT_INT_REASON, (uint8_t *)&intr_reason);
            intr_inst_index = 0; /*  in case of coda seriese. treats intr_inst_index is already 0 */
            kfifo_in_spinlocked(&veInterrupt->vint_queue[VE_CODEC1][intr_inst_index], &intr_reason,
                                sizeof(uint8_t), &veInterrupt->vint_lock[VE_CODEC1][intr_inst_index]);
            intr_clr = 1;
            RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+BIT_INT_CLEAR, (uint8_t *)&intr_clr);
        }
    }
    else {
        pr_err("[VE1_INT] Unknown product id : %08x\n", product_code);
    }
#endif

    /*send the responding while get availabe interrupt*/
    for (i = 0; i < VE_CODEC_INSTANCE_NUM; i++) {
        if (kfifo_len(&veInterrupt->vint_queue[VE_CODEC1][i])) {
            veInterrupt->vint_flag[VE_CODEC1][i] = 1;
            wake_up_interruptible(&veInterrupt->vint_wait[VE_CODEC1][i]);
            pr_debug("[VE1_INT] instance %d interrupt happend\n", i);
        }
    }
}

void codec2_isr_handler(void *dev)
{
    struct rpp_dev *pdev;
    struct InterruptManager *veInterrupt;
    uint32_t product_code;
    int32_t intr_inst_index;

    uint32_t intr_status, intr_clr;
    uint32_t intr_reason, reason;
    uint32_t empty_inst, done_inst, seq_inst;
    uint32_t i, reason_clr;
    uint32_t regOffset = CodecRegOffset[VE_CODEC2];

    pdev = (struct rpp_dev *)dev;
    veInterrupt = (struct InterruptManager *)pdev->entire_ctrl_vdev.veInterrupt;

    if(veInterrupt == NULL) {
        pr_err("[VE2-INT] current rpp deviec %p doesn't initial ve interrupt manager\n", pdev);
        return;
    }
#ifdef VPU_HAL_MPU
    /*respond the driver remove*/
    return;
#endif

    if(pdev->small_bar) {
        regOffset -= VE_REG_BASE_LARGE_BAR;
    }

#if SUPPORT_WAVE_W_VPU
    RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+VPU_PRODUCT_CODE_REGISTER, (uint8_t *)&product_code);
    if (PRODUCT_CODE_W_SERIES(product_code)) {
#endif
        RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_VPU_VPU_INT_STS, (uint8_t *)&intr_status);
        if (intr_status) {
            reason = 0;
            RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_VPU_INT_REASON, (uint8_t *)&reason);
            reason_clr = reason;

            /*get instance info with difference interrupt type*/
            RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_RET_BS_EMPTY_INST, (uint8_t *)&empty_inst);
            RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_RET_QUEUE_CMD_DONE_INST, (uint8_t *)&done_inst);
            RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_RET_SEQ_DONE_INSTANCE_INFO, (uint8_t *)&seq_inst);
            pr_debug("[VE2-INT], interrupt: 0x%08x, empty_inst: 0x%08x, done_inst: 0x%08x, seq_inst: 0x%08x\n",
                      reason, empty_inst, done_inst, seq_inst);

            for (i=0; i <VE_CODEC_INSTANCE_NUM; i++) {
                intr_reason = reason;
                if (0 == empty_inst && 0 == done_inst && 0 == seq_inst) {
                    pr_debug("[VE2_INT] turn %d has't remain any instance interrupt\n", i);
                    break;
                }

                /* new interrupt happen during ISR, should update interrupt reason */
                if (i > 0 && 0 == intr_reason) {
                /* 1) refresh interrupt reason
                 * 2) update current interrupt source
                 * 3) update current interrupt reason
                 * !!! Don't change the order
                 */
                    RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_VPU_INT_REASON, (uint8_t *)&reason);
                    pr_info("[VE2_INT] get new interrupt reason 0x%08x, old reason 0x%08x\n", reason, reason_clr);
                    intr_reason = reason & ~(reason_clr);
                    reason_clr = reason;
                    reason = intr_reason;
                    pr_info("[VE2_INT] interrupt source: empty: 0x%08x, done: 0x%08x, seq: 0x%08x\n", empty_inst, done_inst, seq_inst);
                }

                intr_inst_index = get_vpu_inst_idx(&intr_reason, empty_inst, done_inst, seq_inst);
                if (intr_inst_index >= 0 && intr_inst_index < VE_CODEC_INSTANCE_NUM)
                {
                    if (intr_reason == (1 << INT_WAVE5_BSBUF_EMPTY)) {
                        empty_inst = empty_inst & ~(1 << intr_inst_index);
                        RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_RET_BS_EMPTY_INST, (uint8_t *)&empty_inst);
                        if (0 == empty_inst) {
                            reason &= ~(1<<INT_WAVE5_BSBUF_EMPTY);
                        }
                    }

                    if (intr_reason == (1 << INT_WAVE5_DEC_PIC)) {
                        done_inst = done_inst & ~(1 << intr_inst_index);
                        RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_RET_QUEUE_CMD_DONE_INST, (uint8_t *)&done_inst);
                        if (0 == done_inst) {
                            reason &= ~(1<<INT_WAVE5_DEC_PIC);
                        }
                    }

                    if ((intr_reason == (1 << INT_WAVE5_INIT_SEQ)) || (intr_reason == (1 << INT_WAVE5_ENC_SET_PARAM))) {
                        seq_inst = seq_inst & ~(1 << intr_inst_index);
                        RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_RET_SEQ_DONE_INSTANCE_INFO, (uint8_t *)&seq_inst);
                        if (0 == seq_inst) {
                            reason &= ~(1<<INT_WAVE5_INIT_SEQ | 1<<INT_WAVE5_ENC_SET_PARAM);
                        }
                    }

                    if (intr_reason == (1 << INT_WAVE5_ENC_LOW_LATENCY)) {
                        done_inst = (done_inst >> 16);
                        done_inst = done_inst & ~(1 << intr_inst_index);
                        done_inst = (done_inst << 16);
                        RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_RET_QUEUE_CMD_DONE_INST, (uint8_t *)&done_inst);
                        if (0 == done_inst) {
                            reason &= ~(1 << INT_WAVE5_ENC_LOW_LATENCY);
                        }
                    }

                    pr_debug("[VE2_INT] turn %d get instance %d interrupt 0x%08x\n", i, intr_inst_index, intr_reason);

                    if (!kfifo_is_full(&veInterrupt->vint_queue[VE_CODEC2][intr_inst_index])) {
                        if (intr_reason == ((1 << INT_WAVE5_ENC_PIC) | (1 << INT_WAVE5_ENC_LOW_LATENCY))) {
                            uint32_t ll_intr_reason = (1 << INT_WAVE5_ENC_PIC);
                            kfifo_in_spinlocked(&veInterrupt->vint_queue[VE_CODEC2][intr_inst_index], &ll_intr_reason,
                                                sizeof(uint32_t), &veInterrupt->vint_lock[VE_CODEC2][intr_inst_index]);
                        }
                        else
                            kfifo_in_spinlocked(&veInterrupt->vint_queue[VE_CODEC2][intr_inst_index], &intr_reason,
                                                sizeof(uint32_t), &veInterrupt->vint_lock[VE_CODEC2][intr_inst_index]);
                    }
                    else {
                        pr_err("[VE2_INT] instance: %d kfifo_is_full kfifo_count=%d \n",
                                intr_inst_index, kfifo_len(&veInterrupt->vint_queue[VE_CODEC2][intr_inst_index]));
                    }
                }
                else {
                    pr_err("[VE2_INT] %d turn, intr_inst_index is wrong, intr_inst_index=%d, intr_reason=0x%08x inital reason=0x%08x\n",
                            i, intr_inst_index, intr_reason, reason_clr);
                }
            }

            if (0 != reason){
                pr_err("[VE2_INT] INTERRUPT REASON REMAINED: %08x\n", reason);
            }

            RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_VPU_INT_REASON_CLEAR, (uint8_t *)&reason_clr);
            intr_clr = 1;
            RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_VPU_VINT_CLEAR, (uint8_t *)&intr_clr);
        }
        else{
            pr_err("[VE2_INT] isr error report without ve interrupt status\n");
        }
#if SUPPORT_WAVE_W_VPU
    }
    else if (PRODUCT_CODE_NOT_W_SERIES(product_code)) {
        RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+BIT_INT_STS, (uint8_t *)&intr_status);
        if (intr_status) {
            RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+BIT_INT_REASON, (uint8_t *)&intr_reason);
            intr_inst_index = 0; /*  in case of coda seriese. treats intr_inst_index is already 0 */
            kfifo_in_spinlocked(&veInterrupt->vint_queue[VE_CODEC2][intr_inst_index], &intr_reason,
                                sizeof(uint8_t), &veInterrupt->vint_lock[VE_CODEC2][intr_inst_index]);
            intr_clr = 1;
            RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+BIT_INT_CLEAR, (uint8_t *)&intr_clr);
        }
    }
    else {
        pr_err("[VE2_INT] Unknown product id : %08x\n", product_code);
    }
#endif

    /*send the responding while get availabe interrupt*/
    for (i = 0; i < VE_CODEC_INSTANCE_NUM; i++) {
        if (kfifo_len(&veInterrupt->vint_queue[VE_CODEC2][i])) {
            veInterrupt->vint_flag[VE_CODEC2][i] = 1;
            wake_up_interruptible(&veInterrupt->vint_wait[VE_CODEC2][i]);
            pr_debug("[VE2_INT] instance %d interrupt happend\n", i);
        }
    }
}

void codec3_isr_handler(void *dev)
{
    struct rpp_dev *pdev;
    struct InterruptManager *veInterrupt;
    uint32_t product_code;
    int32_t intr_inst_index;

    uint32_t intr_status, intr_clr;
    uint32_t intr_reason, reason;
    uint32_t empty_inst, done_inst, seq_inst;
    uint32_t i, reason_clr;
    uint32_t regOffset = CodecRegOffset[VE_CODEC3];

    pdev = (struct rpp_dev *)dev;
    veInterrupt = (struct InterruptManager *)pdev->entire_ctrl_vdev.veInterrupt;

    if(veInterrupt == NULL) {
        pr_err("[VE3-INT] current rpp deviec %p doesn't initial ve interrupt manager\n", pdev);
        return;
    }
#ifdef VPU_HAL_MPU
    /*respond the driver remove*/
    return;
#endif

    if(pdev->small_bar) {
        regOffset -= VE_REG_BASE_LARGE_BAR;
    }

#if SUPPORT_WAVE_W_VPU
    RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+VPU_PRODUCT_CODE_REGISTER, (uint8_t *)&product_code);
    if (PRODUCT_CODE_W_SERIES(product_code)) {
#endif
        RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_VPU_VPU_INT_STS, (uint8_t *)&intr_status);
        if (intr_status) {
            reason = 0;
            RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_VPU_INT_REASON, (uint8_t *)&reason);
            reason_clr = reason;

            /*get instance info with difference interrupt type*/
            RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_RET_BS_EMPTY_INST, (uint8_t *)&empty_inst);
            RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_RET_QUEUE_CMD_DONE_INST, (uint8_t *)&done_inst);
            RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_RET_SEQ_DONE_INSTANCE_INFO, (uint8_t *)&seq_inst);
            pr_debug("[VE3-INT], interrupt: 0x%08x, empty_inst: 0x%08x, done_inst: 0x%08x, seq_inst: 0x%08x\n",
                      reason, empty_inst, done_inst, seq_inst);

            for (i=0; i <VE_CODEC_INSTANCE_NUM; i++) {
                intr_reason = reason;
                if (0 == empty_inst && 0 == done_inst && 0 == seq_inst) {
                    pr_debug("[VE3_INT] turn %d has't remain any instance interrupt\n", i);
                    break;
                }

                /* new interrupt happen during ISR, should update interrupt reason */
                if (i > 0 && 0 == intr_reason) {
                /* 1) refresh interrupt reason
                 * 2) update current interrupt source
                 * 3) update current interrupt reason
                 * !!! Don't change the order
                 */
                    RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+W5_VPU_INT_REASON, (uint8_t *)&reason);
                    pr_info("[VE3_INT] get new interrupt reason 0x%08x, old reason 0x%08x\n", reason, reason_clr);
                    intr_reason = reason & ~(reason_clr);
                    reason_clr = reason;
                    reason = intr_reason;
                    pr_info("[VE3_INT] interrupt source: empty: 0x%08x, done: 0x%08x, seq: 0x%08x\n", empty_inst, done_inst, seq_inst);
                }

                intr_inst_index = get_vpu_inst_idx(&intr_reason, empty_inst, done_inst, seq_inst);
                if (intr_inst_index >= 0 && intr_inst_index < VE_CODEC_INSTANCE_NUM)
                {
                    if (intr_reason == (1 << INT_WAVE5_BSBUF_EMPTY)) {
                        empty_inst = empty_inst & ~(1 << intr_inst_index);
                        RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_RET_BS_EMPTY_INST, (uint8_t *)&empty_inst);
                        if (0 == empty_inst) {
                            reason &= ~(1<<INT_WAVE5_BSBUF_EMPTY);
                        }
                    }

                    if (intr_reason == (1 << INT_WAVE5_DEC_PIC)) {
                        done_inst = done_inst & ~(1 << intr_inst_index);
                        RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_RET_QUEUE_CMD_DONE_INST, (uint8_t *)&done_inst);
                        if (0 == done_inst) {
                            reason &= ~(1<<INT_WAVE5_DEC_PIC);
                        }
                    }

                    if ((intr_reason == (1 << INT_WAVE5_INIT_SEQ)) || (intr_reason == (1 << INT_WAVE5_ENC_SET_PARAM))) {
                        seq_inst = seq_inst & ~(1 << intr_inst_index);
                        RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_RET_SEQ_DONE_INSTANCE_INFO, (uint8_t *)&seq_inst);
                        if (0 == seq_inst) {
                            reason &= ~(1<<INT_WAVE5_INIT_SEQ | 1<<INT_WAVE5_ENC_SET_PARAM);
                        }
                    }

                    if (intr_reason == (1 << INT_WAVE5_ENC_LOW_LATENCY)) {
                        done_inst = (done_inst >> 16);
                        done_inst = done_inst & ~(1 << intr_inst_index);
                        done_inst = (done_inst << 16);
                        RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_RET_QUEUE_CMD_DONE_INST, (uint8_t *)&done_inst);
                        if (0 == done_inst) {
                            reason &= ~(1 << INT_WAVE5_ENC_LOW_LATENCY);
                        }
                    }

                    pr_debug("[VE3_INT] turn %d get instance %d interrupt 0x%08x\n", i, intr_inst_index, intr_reason);

                    if (!kfifo_is_full(&veInterrupt->vint_queue[VE_CODEC3][intr_inst_index])) {
                        if (intr_reason == ((1 << INT_WAVE5_ENC_PIC) | (1 << INT_WAVE5_ENC_LOW_LATENCY))) {
                            uint32_t ll_intr_reason = (1 << INT_WAVE5_ENC_PIC);
                            kfifo_in_spinlocked(&veInterrupt->vint_queue[VE_CODEC3][intr_inst_index], &ll_intr_reason,
                                                sizeof(uint32_t), &veInterrupt->vint_lock[VE_CODEC3][intr_inst_index]);
                        }
                        else
                            kfifo_in_spinlocked(&veInterrupt->vint_queue[VE_CODEC3][intr_inst_index], &intr_reason,
                                                sizeof(uint32_t), &veInterrupt->vint_lock[VE_CODEC3][intr_inst_index]);
                    }
                    else {
                        pr_err("[VE3_INT] instance: %d kfifo_is_full kfifo_count=%d \n",
                                intr_inst_index, kfifo_len(&veInterrupt->vint_queue[VE_CODEC3][intr_inst_index]));
                    }
                }
                else {
                    pr_err("[VE3_INT] %d turn, intr_inst_index is wrong, intr_inst_index=%d, intr_reason=0x%08x inital reason=0x%08x\n",
                            i, intr_inst_index, intr_reason, reason_clr);
                }
            }

            if (0 != reason){
                pr_err("[VE3_INT] INTERRUPT REASON REMAINED: %08x\n", reason);
            }

            RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_VPU_INT_REASON_CLEAR, (uint8_t *)&reason_clr);
            intr_clr = 1;
            RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+W5_VPU_VINT_CLEAR, (uint8_t *)&intr_clr);
        }
        else{
            pr_err("[VE3_INT] isr error report without ve interrupt status\n");
        }
#if SUPPORT_WAVE_W_VPU
    }
    else if (PRODUCT_CODE_NOT_W_SERIES(product_code)) {
        RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+BIT_INT_STS, (uint8_t *)&intr_status);
        if (intr_status) {
            RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+BIT_INT_REASON, (uint8_t *)&intr_reason);
            intr_inst_index = 0; /*  in case of coda seriese. treats intr_inst_index is already 0 */
            kfifo_in_spinlocked(&veInterrupt->vint_queue[VE_CODEC3][intr_inst_index], &intr_reason, sizeof(uint8_t),
                                &veInterrupt->vint_lock[VE_CODEC3][intr_inst_index]);
            intr_clr = 1;
            RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+BIT_INT_CLEAR, (uint8_t *)&intr_clr);
        }
    }
    else {
        pr_err("[VE3_INT] Unknown product id : %08x\n", product_code);
    }
#endif

    /*send the responding while get availabe interrupt*/
    for (i = 0; i < VE_CODEC_INSTANCE_NUM; i++) {
        if (kfifo_len(&veInterrupt->vint_queue[VE_CODEC3][i])) {
            veInterrupt->vint_flag[VE_CODEC3][i] = 1;
            wake_up_interruptible(&veInterrupt->vint_wait[VE_CODEC3][i]);
            pr_debug("[VE3_INT] instance %d interrupt happend\n", i);
        }
    }
}

void jpeg0_isr_handler(void *dev)
{
    struct rpp_dev *pdev;
    struct InterruptManager *veInterrupt;

    int i;
    uint32_t inst_pic_reg, intr_inst_ctrl;
    uint32_t reason;
    uint32_t regOffset = JpegRegOffset[VE_JPEG0];

    pdev = (struct rpp_dev *)dev;
    veInterrupt = (struct InterruptManager *)pdev->entire_ctrl_vdev.veInterrupt;

    if(veInterrupt == NULL) {
        pr_err("[JPEG0_INT] current rpp deviec %p doesn't initial ve interrupt manager\n", pdev);
        return;
    }

    if(pdev->small_bar) {
        regOffset -= VE_REG_BASE_LARGE_BAR;
    }

#if JPEG_INTRRUPT_ID_VERIFY
    RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+MJPEG_INST_CTRL_STATUS_REG, (uint8_t *)&intr_inst_ctrl);
    intr_inst_ctrl &= 0x0f;
#endif

    for (i=0; i < VE_JPEG_INSTANCE_NUM; i++) {
        inst_pic_reg = regOffset + JPEG_INSTANCE_CORE * NPT_REG_SIZE + MJPEG_PIC_STATUS_REG;
        RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, inst_pic_reg, (uint8_t *)&reason);
        reason &= 0x3ff;

        if (reason == 0) continue;
#if JPEG_INTRRUPT_ID_VERIFY
        if (i != intr_inst_ctrl) {
            pr_warn("[JPEG0_INT] inttrupt from instance %d, intst_ID=%d, check hardware\n", i, intr_inst_ctrl);
        }
#endif
        pr_debug("[JPEG0_INT] get instance %d interrupt reason 0x%08x\n", i, reason);

        if (kfifo_is_full(&veInterrupt->jint_queue[VE_JPEG0][i])) {
            pr_debug("[JPEG0_INT] instance: %d kfifo_is_full kfifo_count=%d \n",
                      i, kfifo_len(&veInterrupt->jint_queue[VE_JPEG0][i]));
            kfifo_reset(&veInterrupt->jint_queue[VE_JPEG0][i]);
        }
        kfifo_in_spinlocked(&veInterrupt->jint_queue[VE_JPEG0][i], &reason,
                            sizeof(uint32_t), &veInterrupt->jint_lock[VE_JPEG0][i]);
    }

    /*send the responding while get availabe interrupt*/
    for (i = 0; i < VE_JPEG_INSTANCE_NUM; i++) {
        if (kfifo_len(&veInterrupt->jint_queue[VE_JPEG0][i])) {
            veInterrupt->jint_flag[VE_JPEG0][i] = 1;
            wake_up_interruptible(&veInterrupt->jint_wait[VE_JPEG0][i]);
            pr_debug("[JPEG0_INT] instance %d interrupt happend\n", i);
        }
    }
}

void jpeg1_isr_handler(void *dev)
{
    struct rpp_dev *pdev;
    struct InterruptManager *veInterrupt;

    int i;
    uint32_t inst_pic_reg, intr_inst_ctrl;
    uint32_t reason;
    uint32_t regOffset = JpegRegOffset[VE_JPEG1];

    pdev = (struct rpp_dev *)dev;
    veInterrupt = (struct InterruptManager *)pdev->entire_ctrl_vdev.veInterrupt;

    if(veInterrupt == NULL) {
        pr_err("[JPEG1_INT] current rpp deviec %p doesn't initial ve interrupt manager\n", pdev);
        return;
    }

    if(pdev->small_bar) {
        regOffset -= VE_REG_BASE_LARGE_BAR;
    }

#if JPEG_INTRRUPT_ID_VERIFY
    RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+MJPEG_INST_CTRL_STATUS_REG, (uint8_t *)&intr_inst_ctrl);
    intr_inst_ctrl &= 0x0f;
#endif

    for (i=0; i < VE_JPEG_INSTANCE_NUM; i++) {
        inst_pic_reg = regOffset + JPEG_INSTANCE_CORE * NPT_REG_SIZE + MJPEG_PIC_STATUS_REG;
        RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, inst_pic_reg, (uint8_t *)&reason);
        reason &= 0x3ff;

        if (reason == 0) continue;
#if JPEG_INTRRUPT_ID_VERIFY
        if (i != intr_inst_ctrl) {
            pr_warn("[JPEG1_INT] inttrupt from instance %d, intst_ID=%d, check hardware\n", i, intr_inst_ctrl);
        }
#endif
        pr_debug("[JPEG1_INT] get instance %d interrupt reason 0x%08x\n", i, reason);

        if (kfifo_is_full(&veInterrupt->jint_queue[VE_JPEG1][i])) {
            pr_debug("[JPEG1_INT] instance: %d kfifo_is_full kfifo_count=%d \n",
                    i, kfifo_len(&veInterrupt->jint_queue[VE_JPEG1][i]));
            kfifo_reset(&veInterrupt->jint_queue[VE_JPEG1][i]);
        }
        kfifo_in_spinlocked(&veInterrupt->jint_queue[VE_JPEG1][i], &reason,
                            sizeof(uint32_t), &veInterrupt->jint_lock[VE_JPEG1][i]);
    }

    /*send the responding while get availabe interrupt*/
    for (i = 0; i < VE_JPEG_INSTANCE_NUM; i++) {
        if (kfifo_len(&veInterrupt->jint_queue[VE_JPEG1][i])) {
            veInterrupt->jint_flag[VE_JPEG1][i] = 1;
            wake_up_interruptible(&veInterrupt->jint_wait[VE_JPEG1][i]);
            pr_debug("[JPEG1_INT] instance %d interrupt happend\n", i);
        }
    }
}

void jpeg2_isr_handler(void *dev)
{
    struct rpp_dev *pdev;
    struct InterruptManager *veInterrupt;

    int i;
    uint32_t inst_pic_reg, intr_inst_ctrl;
    uint32_t reason;
    uint32_t regOffset = JpegRegOffset[VE_JPEG2];

    pdev = (struct rpp_dev *)dev;
    veInterrupt = (struct InterruptManager *)pdev->entire_ctrl_vdev.veInterrupt;

    if(veInterrupt == NULL) {
        pr_err("[JPEG2_INT] current rpp deviec %p doesn't initial ve interrupt manager\n", pdev);
        return;
    }

    if(pdev->small_bar) {
        regOffset -= VE_REG_BASE_LARGE_BAR;
    }

#if JPEG_INTRRUPT_ID_VERIFY
    RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+MJPEG_INST_CTRL_STATUS_REG, (uint8_t *)&intr_inst_ctrl);
    intr_inst_ctrl &= 0x0f;
#endif

    for (i=0; i < VE_JPEG_INSTANCE_NUM; i++) {
        inst_pic_reg = regOffset + JPEG_INSTANCE_CORE * NPT_REG_SIZE + MJPEG_PIC_STATUS_REG;
        RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, inst_pic_reg, (uint8_t *)&reason);
        reason &= 0x3ff;

        if (reason == 0) continue;
#if JPEG_INTRRUPT_ID_VERIFY
        if (i != intr_inst_ctrl) {
            pr_warn("[JPEG2_INT] inttrupt from instance %d, intst_ID=%d, check hardware\n", i, intr_inst_ctrl);
        }
#endif
        pr_debug("[JPEG2_INT] get instance %d interrupt reason 0x%08x\n", i, reason);

        if (kfifo_is_full(&veInterrupt->jint_queue[VE_JPEG2][i])) {
            pr_debug("[JPEG2_INT] instance: %d kfifo_is_full kfifo_count=%d \n",
                      i, kfifo_len(&veInterrupt->jint_queue[VE_JPEG2][i]));
            kfifo_reset(&veInterrupt->jint_queue[VE_JPEG2][i]);
        }
        kfifo_in_spinlocked(&veInterrupt->jint_queue[VE_JPEG2][i], &reason,
                            sizeof(uint32_t), &veInterrupt->jint_lock[VE_JPEG2][i]);
    }

    /*send the responding while get availabe interrupt*/
    for (i = 0; i < VE_JPEG_INSTANCE_NUM; i++) {
        if (kfifo_len(&veInterrupt->jint_queue[VE_JPEG2][i])) {
            veInterrupt->jint_flag[VE_JPEG2][i] = 1;
            wake_up_interruptible(&veInterrupt->jint_wait[VE_JPEG2][i]);
            pr_debug("[JPEG2_INT] instance %d interrupt happend\n", i);
        }
    }
}

void jpeg3_isr_handler(void *dev)
{
    struct rpp_dev *pdev;
    struct InterruptManager *veInterrupt;

    int i;
    uint32_t inst_pic_reg, intr_inst_ctrl;
    uint32_t reason;
    uint32_t regOffset = JpegRegOffset[VE_JPEG3];

    pdev = (struct rpp_dev *)dev;
    veInterrupt = (struct InterruptManager *)pdev->entire_ctrl_vdev.veInterrupt;

    if(veInterrupt == NULL) {
        pr_err("[JPEG3_INT] current rpp deviec %p doesn't initial ve interrupt manager\n", pdev);
        return;
    }

    if(pdev->small_bar) {
        regOffset -= VE_REG_BASE_LARGE_BAR;
    }

#if JPEG_INTRRUPT_ID_VERIFY
    RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+MJPEG_INST_CTRL_STATUS_REG, (uint8_t *)&intr_inst_ctrl);
    intr_inst_ctrl &= 0x0f;
#endif

    for (i=0; i < VE_JPEG_INSTANCE_NUM; i++) {
        inst_pic_reg = regOffset + JPEG_INSTANCE_CORE * NPT_REG_SIZE + MJPEG_PIC_STATUS_REG;
        RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, inst_pic_reg, (uint8_t *)&reason);
        reason &= 0x3ff;

        if (reason == 0) continue;
#if JPEG_INTRRUPT_ID_VERIFY
        if (i != intr_inst_ctrl) {
            pr_warn("[JPEG3_INT] inttrupt from instance %d, intst_ID=%d, check hardware\n", i, intr_inst_ctrl);
        }
#endif
        pr_debug("[JPEG3_INT] get instance %d interrupt reason 0x%08x\n", i, reason);

        if (kfifo_is_full(&veInterrupt->jint_queue[VE_JPEG3][i])) {
            pr_debug("[JPEG3_INT] instance: %d kfifo_is_full kfifo_count=%d \n",
                      i, kfifo_len(&veInterrupt->jint_queue[VE_JPEG3][i]));
            kfifo_reset(&veInterrupt->jint_queue[VE_JPEG3][i]);
        }
        kfifo_in_spinlocked(&veInterrupt->jint_queue[VE_JPEG3][i], &reason,
                            sizeof(uint32_t), &veInterrupt->jint_lock[VE_JPEG3][i]);
    }

    /*send the responding while get availabe interrupt*/
    for (i = 0; i < VE_JPEG_INSTANCE_NUM; i++) {
        if (kfifo_len(&veInterrupt->jint_queue[VE_JPEG3][i])) {
            veInterrupt->jint_flag[VE_JPEG3][i] = 1;
            wake_up_interruptible(&veInterrupt->jint_wait[VE_JPEG3][i]);
            pr_debug("[JPEG3_INT] instance %d interrupt happend\n", i);
        }
    }
}
#endif

/* ve driver loading when device probe */
int rpp_init_veEngine(struct rpp_dev *xpdev, struct VideoEngine *veEngine)
{
#ifdef VE_FRAME_BUFFER_CACHE
const uint64_t WUSER_TABLE[VE_CODEC_NUM] = {
    WUSR0_BUFFER_MAP_ADDR_START,
    WUSR1_BUFFER_MAP_ADDR_START,
    WUSR2_BUFFER_MAP_ADDR_START,
    WUSR3_BUFFER_MAP_ADDR_START
};

const uint64_t RUSER_TABLE[VE_CODEC_NUM] = {
    RUSR0_BUFFER_MAP_ADDR_START,
    RUSR1_BUFFER_MAP_ADDR_START,
    RUSR2_BUFFER_MAP_ADDR_START,
    RUSR3_BUFFER_MAP_ADDR_START
};
#endif

    int i, j;
    int ret = 0;
#ifdef VE_FRAME_BUFFER_CACHE
    int coreIdx;
#endif

    if (xpdev == NULL|| veEngine == NULL) {
        pr_err("ERR!!!, %s can't initial veEngine\n", __func__);
        return -1;
    }

    /* Get memory and register configuration from firmware
    */
    veEngine->memInfo.ve_mem.size      = xpdev->ve_info.ve_mem.size;
    veEngine->memInfo.ve_mem.phys_addr = xpdev->ve_info.ve_mem.phys_addr;
    veEngine->memInfo.ve_mem.virt_addr = xpdev->ve_info.ve_mem.virt_addr;
    /* pcie bar configuration seting */
    veEngine->memInfo.ve_register.size      = xpdev->ve_info.ve_register.size;
    veEngine->memInfo.ve_register.phys_addr = xpdev->ve_info.ve_register.phys_addr;
    veEngine->memInfo.ve_register.virt_addr = xpdev->ve_info.ve_register.virt_addr;

    veEngine->codec.populated = 0;
    veEngine->codec.codec_min = 0;
#if ENABLE_ALL_CORES
    veEngine->codec.codec_max = VE_CODEC_NUM;
#else
    veEngine->codec.codec_max = VE_CODEC_NUM/2;
#endif

#if MAX_INSTANCES_BY_VEMEM
    int8_t ins_max;
    switch (xpdev->ve_info.ve_mem.size)
    {
        /* Notice, maxiume instances less equal than VE_CODEC_INSTANCE_NUM,
         * never over than this definition, otherwise all propteries of
         * instance are wrong
        */
        case VE_FRAME_BUFFER_SIZE_2G:
            ins_max = 4;    /* 4 instances per core */
            break;
        case VE_FRAME_BUFFER_SIZE_1G:
            ins_max = 2;    /* 2 instances per core */
            break;
        case VE_FRAME_BUFFER_SIZE_512M:
            ins_max = 1;    /* 1 instance only per core */
            break;
        default:
            ins_max = 8;    /* 8 instances per core */
            break;
    }
    if (ins_max > DECODER_INSTANCE_NUM) {
        ins_max = DECODER_INSTANCE_NUM;
    }
    veEngine->codec.ins_max   = ins_max;
    veEngine->codec.avail_ins = veEngine->codec.codec_max*ins_max;
#else
    veEngine->codec.ins_max   = DECODER_INSTANCE_NUM;
    veEngine->codec.avail_ins = veEngine->codec.codec_max*veEngine->codec.ins_max;
#endif

    for (i= veEngine->codec.codec_min; i < veEngine->codec.codec_max; i++) {
        veEngine->codec.codecs[i].index    = i;
        veEngine->codec.codecs[i].ref      = 0;
        for (j = 0; j < veEngine->codec.ins_max; j++ ) {
            veEngine->codec.dbInst[i].used[j] = 0;
            veEngine->codec.dbInst[i].ref[j] = j + 1;
        }
    }

    veEngine->jpeg.populated = 0;
    veEngine->jpeg.codec_min = 0;
#if ENABLE_ALL_CORES
    veEngine->jpeg.codec_max = VE_JPEG_NUM;
#else
    veEngine->jpeg.codec_max = VE_JPEG_NUM / 2;
#endif
    veEngine->jpeg.ins_max   = MJPEG_INSTANCE_NUM;
    veEngine->jpeg.avail_ins = veEngine->jpeg.codec_max*veEngine->jpeg.ins_max;

    for (i= veEngine->jpeg.codec_min; i < veEngine->jpeg.codec_max; i++) {
        veEngine->jpeg.codecs[i].index    = i;
        veEngine->jpeg.codecs[i].ref      = 0;
        for (j = 0; j < veEngine->jpeg.ins_max; j++ ) {
            veEngine->jpeg.dbInst[i].used[j] = 0;
            veEngine->jpeg.dbInst[i].ref[j] = j + 1;
        }
    }

    for (i = 0; i < DMA_POOL_SIZE; i++) {
        veEngine->dmapool[i].index = i;
        veEngine->dmapool[i].used = 0;
    }
    veEngine->avali_dma = DMA_POOL_SIZE;

#ifdef VE_DMA_LL_BUFFER
    veEngine->dma_ll_base = GetBaseLLPAddr();   /* dummy implement*/
#endif

#ifdef VE_FRAME_BUFFER_CACHE
    for (coreIdx = 0; coreIdx < VE_CODEC_NUM; coreIdx++) {
        if (veEngine->dma_user[coreIdx].dma_wuser) {
            veEngine->memInfo.m_dma_user[coreIdx].wusersize = WR_USER_DMA_BUFFER_SIZE;
            veEngine->memInfo.m_dma_user[coreIdx].wuser     = WUSER_TABLE[coreIdx];
        }
        if (veEngine->dma_user[coreIdx].dma_ruser) {
            veEngine->memInfo.m_dma_user[coreIdx].rusersize = WR_USER_DMA_BUFFER_SIZE;
            veEngine->memInfo.m_dma_user[coreIdx].ruser     = RUSER_TABLE[coreIdx];
        }
    }
#endif

    /* intial dma and mmio map information */
    if (veEngine->dma) {
        veEngine->memInfo.m_dma_size = DMA_BUFFER_LENGTH;
        veEngine->memInfo.m_dma_addr = DMA_BUFFER_MAP_ADDR_START;
    }
    veEngine->memInfo.m_mio_size = RPP_MAP_VECFG_SIZE;
    veEngine->memInfo.m_mio_addr = RPP_MAP_VECFG_ADDR;

#ifdef VPU_HAL_MPU
    veEngine->memInfo.m_vpu_addr = VPU_RPC_MEMORY_START;
    veEngine->memInfo.m_vpu_size = VPU_RPC_MEMORY_LENGTH;
#else
    veEngine->memInfo.m_vpu_addr = 0;
    veEngine->memInfo.m_vpu_size = 0;
#endif

#ifdef VE_SUPPORT_MULTI_CLIENT
    /* inital instance pool, it allocted by by user request */
    veEngine->instance_pool.size = 0;
    veEngine->memInfo.m_instance_pool_size = 0;
    veEngine->memInfo.m_instance_pool_addr = 0;

    veEngine->jpeg_pool.size = 0;
    veEngine->memInfo.m_jpeg_pool_size = 0;
    veEngine->memInfo.m_jpeg_pool_addr = 0;

#endif

    /* intial common memory, it's fix memory space(begin of video memory) */
    veEngine->common_memory.size = SIZE_COMMON * VE_CODEC_NUM;
    veEngine->common_memory.phys_addr = veEngine->memInfo.ve_mem.phys_addr;
    veEngine->common_memory.virt_addr = veEngine->memInfo.ve_mem.virt_addr;
    veEngine->common_memory.base = 0;

    /* initial ve memory manage for dynamic allocate and free */
    ret = vmem_init(&veEngine->vmem, (veEngine->memInfo.ve_mem.phys_addr+veEngine->common_memory.size),
                    veEngine->memInfo.ve_mem.size-veEngine->common_memory.size);
    if (ret < 0) {
        veEngine->vmem.mem_size  = 0;
        veEngine->memInfo.total_pages = 0;
        veEngine->memInfo.alloc_pages = 0;
        veEngine->memInfo.free_pages  = 0;
        veEngine->memInfo.page_size   = 0;
        pr_err("veEngine %p can't intial vmem database\n", veEngine);
    }
    else{
        veEngine->memInfo.total_pages = veEngine->vmem.num_pages;
        veEngine->memInfo.alloc_pages = veEngine->vmem.alloc_page_count;
        veEngine->memInfo.free_pages  = veEngine->vmem.free_page_count;
        veEngine->memInfo.page_size   = veEngine->vmem.page_size;
    }

    return ret;
}

/* ve driver destroy when device remove */
int rpp_destroy_veEngine(struct rpp_dev *xpdev, struct VideoEngine *veEngine)
{
#ifdef VE_FRAME_BUFFER_CACHE
    int coreIdx;
#endif

    if (xpdev == NULL|| veEngine == NULL) {
        pr_err("ERR!!!, %s can't destroy veEngine\n", __func__);
        return -1;
    }

    veEngine->memInfo.ve_mem.size = 0;

    memset(&veEngine->codec, 0x00, sizeof(struct CodecEngine));
    memset(&veEngine->jpeg, 0x00, sizeof(struct CodecEngine));

    veEngine->avali_dma = 0;
    memset(&veEngine->dmapool, 0x00, sizeof(struct DmaPool)*DMA_POOL_SIZE);

#ifdef VE_DMA_LL_BUFFER
    veEngine->dma_ll_base = NULL;
#endif

#ifdef VE_FRAME_BUFFER_CACHE
    for (coreIdx = 0; coreIdx < VE_CODEC_NUM; coreIdx++) {
        veEngine->dma_user[coreIdx].dma_wuser           = NULL;
        veEngine->dma_user[coreIdx].dma_wuser_handle    = 0;
        veEngine->memInfo.m_dma_user[coreIdx].wusersize = 0;
        veEngine->memInfo.m_dma_user[coreIdx].wuser     = 0;

        veEngine->dma_user[coreIdx].dma_ruser            = NULL;
        veEngine->dma_user[coreIdx].dma_ruser_handle    = 0;
        veEngine->memInfo.m_dma_user[coreIdx].rusersize = 0;
        veEngine->memInfo.m_dma_user[coreIdx].ruser     = 0;
    }
#endif

    /* intial dma and mmio map information */
    veEngine->dma                = NULL;
    veEngine->dma_handle         = 0;
    veEngine->memInfo.m_dma_size = 0;
    veEngine->memInfo.m_dma_addr = 0;

    veEngine->memInfo.m_mio_size = 0;
    veEngine->memInfo.m_mio_addr = 0;

    /* vpu rpc buffer and dma initial */
    veEngine->memInfo.m_vpu_addr = 0;
    veEngine->memInfo.m_vpu_size = 0;

#ifdef VE_SUPPORT_MULTI_CLIENT
    /* instance pool memory(dma) for vdi */
    if (veEngine->instance_pool.base != NULL && veEngine->instance_pool.size > 0) {
        kfree(veEngine->instance_pool.base);
        veEngine->instance_pool.size = 0;
        veEngine->instance_pool.base = NULL;
    }

    if (veEngine->jpeg_pool.base != NULL && veEngine->jpeg_pool.size > 0) {
        kfree(veEngine->jpeg_pool.base);
        veEngine->jpeg_pool.size = 0;
        veEngine->jpeg_pool.base = NULL;
    }
#endif

    /* ve memory database (virtual database) */
    if (veEngine->vmem.mem_size) {
        vmem_exit(&veEngine->vmem);
    }
    veEngine->memInfo.total_pages = 0;
    veEngine->memInfo.alloc_pages = 0;
    veEngine->memInfo.free_pages  = 0;
    veEngine->memInfo.page_size   = 0;
#ifdef VE_SUPPORT_MULTI_CLIENT
    veEngine->memInfo.m_instance_pool_size = 0;
    veEngine->memInfo.m_instance_pool_addr = 0;

    veEngine->memInfo.m_jpeg_pool_size = 0;
    veEngine->memInfo.m_jpeg_pool_addr = 0;
#endif

    /* vpu common memory for firmware and temp buf */
    if(veEngine->common_memory.size) {
        veEngine->common_memory.size = 0;
    }

    /* ve driver release more Todo */

    return 0;
}

static struct CodecInstance *ve_instance_new(struct rpp_vdev *xvdev, struct CodecEngine *codec_eng, struct file* filp, int IsCodec)
{
    int8_t i, j, inst_ref;
    unsigned long flags;
    struct CodecInstance codec;
    struct DataInstance *kdbInst = NULL;
    struct codec_inst_block *codecBlk;
    struct VideoEngine *veEngine;

    codecBlk = kzalloc(sizeof(struct codec_inst_block), GFP_KERNEL);
    if (!codecBlk) {
        pr_err("vdev %p can't allocation codec block memory\n", xvdev->vdev);
        return NULL;
    }

    veEngine = (struct VideoEngine *)xvdev->veEngine;

    spin_lock_irqsave(&xvdev->lock, flags);
    inst_ref = codec_eng->ins_max + 1;
#if SUPPORT_INSTANCE_BALANCE
    int8_t ref, engine_index, last_index;
    if (codec_eng->avail_ins > 0) {
        /*step1, find first availabe vpu*/
        engine_index = codec_eng->codec_max;
        for (i = codec_eng->codec_min; i < codec_eng->codec_max; i++) {
            if (!IsCodec || ((veEngine->vpu_info >> 8*i) & 0xFF) == 0) {
                engine_index = i;
                break;
            }
        }
        if (engine_index == codec_eng->codec_max) {
            pr_warn("veEngine %p doesn't has any availabe %s\n", veEngine, IsCodec?"vpu":"jpu");
            goto INST_CHK;
        }

        /*step 2, find mininum engine index*/
        if (engine_index != (codec_eng->codec_max-1)) {
            last_index = engine_index;
            pr_info("veEngine %p find first allocator, coreIdx %d\n", veEngine, last_index);
            for (i = engine_index; i < codec_eng->codec_max; i++) {
                if (IsCodec && ((veEngine->vpu_info >> 8*i) & 0xFF)) {
                    pr_info("veEngine %p vpu coreIdx %d has error, try allocate to next\n", veEngine, i);
                    continue;
                }
                ref = codec_eng->codecs[last_index].ref;
                if (ref > codec_eng->codecs[i].ref) {
                    last_index = i;
                    pr_debug("veEngine %p next instance will allocate to coreIdx %d\n", veEngine, last_index);
                }
                pr_debug("veEngine %p skip, current allocator, coreIdx %d, total inst %d\n", veEngine, i, codec_eng->codecs[i].ref);
            }
            engine_index = last_index;
        }

        /*step 3, return instance reference*/
        if (codec_eng->codecs[engine_index].ref < codec_eng->ins_max) {
            codec_eng->codecs[engine_index].ref++;
            codec_eng->avail_ins--;
            if (codec_eng->populated == 0) {
                codec_eng->populated = 1;
            }
            kdbInst = &codec_eng->dbInst[engine_index];
            codec.index = codec_eng->codecs[engine_index].index;
            for(j = 0; j < codec_eng->ins_max; j++) {
                if (kdbInst->used[j] == 0) {
                    kdbInst->used[j] = 1;
                    inst_ref  = kdbInst->ref[j];
                    codec.ref = kdbInst->ref[j];
                    break;
                }
            }
        }
    }
#else
    for (i = codec_eng->codec_min; i < codec_eng->codec_max; i++) {
        if (codec_eng->codecs[i].ref < codec_eng->ins_max) {
            if (IsCodec && ((veEngine->vpu_info >> 8*i) & 0xFF)) {
                pr_info("veEngine %p vpu coreIdx %d has error, try allocate to next\n", veEngine, i);
                continue;
            }

            codec_eng->codecs[i].ref++;
            codec_eng->avail_ins--;
            if (codec_eng->populated == 0) {
                codec_eng->populated = 1;
            }
            kdbInst = &codec_eng->dbInst[i];
            codec.index = codec_eng->codecs[i].index;
            for(j = 0; j < codec_eng->ins_max; j++) {
                if (kdbInst->used[j] == 0) {
                    kdbInst->used[j] = 1;
                    inst_ref  = kdbInst->ref[j];
                    codec.ref = kdbInst->ref[j];
                    break;
                }
            }
            break;
        }
    }
#endif

INST_CHK:
    if (inst_ref > codec_eng->ins_max) {
        spin_unlock_irqrestore(&xvdev->lock, flags);
        kfree(codecBlk);
        pr_err("veEngine %p Codec: Out of codecs list\n", veEngine);
        return NULL;
    } else {
        codecBlk->codec_inst.index = codec.index;
        codecBlk->codec_inst.ref   = codec.ref;
        codecBlk->filp             = filp;
        if (IsCodec) {
            list_add(&codecBlk->list, &s_codec_inst_block_head);
        }else{
            list_add(&codecBlk->list, &s_jpeg_inst_block_head);
        }
        spin_unlock_irqrestore(&xvdev->lock, flags);
        return &codecBlk->codec_inst;
    }
}

static int ve_instance_free(struct rpp_vdev *xvdev, struct CodecEngine *codec_eng, struct CodecInstance *kcodec, struct file* filp, int IsCodec)
{
    int8_t i, j;
    unsigned long flags;
    struct DataInstance *kdbInst = NULL;
    struct codec_inst_block *codecBlk, *next;

    if ((kcodec->index < codec_eng->codec_min) ||
        (kcodec->index >= codec_eng->codec_max)) {
        pr_err("invalid codec index 0x%x\n", kcodec->index);
        return -EINVAL;
    }

    if ((kcodec->ref < 1) ||
        (kcodec->ref > codec_eng->ins_max)) {
        pr_err("invalid codec instance 0x%x\n", kcodec->ref);
        return -EINVAL;
    }

    spin_lock_irqsave(&xvdev->lock, flags);
    for (i = codec_eng->codec_min; i< codec_eng->codec_max; i++) {
        /*step1, find engine index*/
        if (kcodec->index == i) {
            codec_eng->codecs[i].ref--;

            kdbInst = &codec_eng->dbInst[i];
            for(j = 0; j < codec_eng->ins_max; j++) {
                if(kdbInst->ref[j] == kcodec->ref &&
                   kdbInst->used[j] == 1)
                {
                    kdbInst->used[j] = 0;
                    break;
                }
            }
            break;
        }
    }
    codec_eng->avail_ins++;
    if(codec_eng->avail_ins == (codec_eng->codec_max - codec_eng->codec_min) * codec_eng->ins_max) {
        codec_eng->populated = 0;
    }

    if (IsCodec) {
        list_for_each_entry_safe(codecBlk, next, &s_codec_inst_block_head, list)
        {
            if (codecBlk->codec_inst.index == kcodec->index &&
                codecBlk->codec_inst.ref   == kcodec->ref   &&
                codecBlk->filp             == filp)
            {
                list_del(&codecBlk->list);
                kfree(codecBlk);
                break;
            }
        }
    }else{
        list_for_each_entry_safe(codecBlk, next, &s_jpeg_inst_block_head, list)
        {
            if (codecBlk->codec_inst.index == kcodec->index &&
                codecBlk->codec_inst.ref   == kcodec->ref   &&
                codecBlk->filp             == filp)
            {
                list_del(&codecBlk->list);
                kfree(codecBlk);
                break;
            }
        }
    }
    spin_unlock_irqrestore(&xvdev->lock, flags);

    pr_info("veEngine %p free %s with core index %d instance %d, remained %d for open client %p\n",
             xvdev->veEngine, IsCodec?"codec":"jpeg", kcodec->index, kcodec->ref, codec_eng->avail_ins, filp);
    return 0;
}

static void ve_mem_config_init(struct rpp_vdev *xvdev, struct VideoEngine *veEngine)
{
    uint64_t phys_addr;
    uint32_t size;
    uint32_t offset, value;
    struct rpp_dev *pdev;

    phys_addr = veEngine->memInfo.ve_mem.phys_addr;
    size      = veEngine->memInfo.ve_mem.size;
    if (phys_addr >= 0x100000000 && (phys_addr+size) <= 0x200000000) {
        offset = 0x11;
    }else if (phys_addr >= 0x200000000 && (phys_addr+size) <= 0x300000000) {
        offset = 0x22;
    }else if (phys_addr >= 0x300000000 && (phys_addr+size) <= 0x400000000) {
        offset = 0x33;
    }else {
        offset = 0x00;
    }

    pdev = xvdev->prppdev;
    RPP_rw_pci_bar(pdev, 4, 0, 4, 0x22210, (uint8_t *)&value);
    value &= 0xffffff00;     /* b8 for 4 ddr, b19/20 for ve upsize */
    value |= offset;
    RPP_rw_pci_bar(pdev, 4, 1, 4, 0x22210, (uint8_t *)&value);
}

/*
 * Transfer the data between VE device memory and host memory by CH3 descriptor
 * mode. VE keeps the historical direction naming:
 *   DMA_WRITE: device -> host
 *   DMA_READ:  host -> device
 */
static int rpp_dma_transfer_desc_single(struct rpp_dev *pdev, DMA_DIRC dirc, uint8_t chan, struct DmaElement *Element)
{
    BLK_ELEMENT blk;
    DMA_BLKS_INFO blk_info;
    ssize_t res;
    bool write;

    if (Element == NULL || pdev == NULL) {
        return -EINVAL;
    }

    if (chan != VE_PCIE_DMA_CH) {
        pr_err("%s, unsupported VE DMA channel %u\n", __func__, chan);
        return -EINVAL;
    }

    if (Element->size == 0) {
        pr_err("%s, invalid transfer size 0\n", __func__);
        return -EINVAL;
    }

    if (dirc == DMA_WRITE) {
        write = false;
    } else if (dirc == DMA_READ) {
        write = true;
    } else {
        pr_err("%s, invalid DMA direction %d\n", __func__, dirc);
        return -EINVAL;
    }

    blk.dma_address = Element->dmahost;
    blk.dma_length = Element->size;

    blk_info.mapped_num = 1;
    blk_info.mapped_blk = &blk;
    blk_info.vail_num = 1;
    blk_info.start = 0;
    blk_info.start_offs = 0;
    blk_info.end_size = Element->size;

    res = rpp_xfer_blks_ch(pdev, CH3, &blk_info, Element->dmacodec,
                            Element->size, write, 30000);
    if (res != Element->size) {
        pr_err("%s, CH3 desc transfer failed, dirc %d, host 0x%llx, dev 0x%llx, size 0x%x, res %zd\n",
               __func__, dirc, Element->dmahost, Element->dmacodec,
               Element->size, res);
        return -EIO;
    }

    return 0;
}

/*
 * Transfer the data between VE device memory and host mapped blocks by CH3
 * descriptor mode.
 * pdev, rpp device instance
 * dirc, direction setting, 0-write;1-read
 * chan, dma channel selected
 * dmacodec, device address of ve frame buffer
 * mapped_blk, dma block entry
 * mapped_num, num of dma block
*/
static int rpp_dma_transfer_desc_multi(struct rpp_dev *pdev, DMA_DIRC dirc, uint8_t chan, uint64_t dmacodec, struct dma_mapped_blk *mapped_blk, uint32_t mapped_num)
{
    DMA_BLKS_INFO blk_info;
    uint64_t total_size = 0;
    uint32_t i;
    ssize_t res;
    bool write;

    if (pdev == NULL || mapped_blk == NULL || mapped_num == 0) {
        pr_err("%s, invailed input paramter\n", __func__);
        return -EINVAL;
    }

    if (chan != VE_PCIE_DMA_CH) {
        pr_err("%s, unsupported VE DMA channel %u\n", __func__, chan);
        return -EINVAL;
    }

    if (dirc == DMA_WRITE) {
        write = false;
    } else if (dirc == DMA_READ) {
        write = true;
    } else {
        pr_err("%s, invalid DMA direction %d\n", __func__, dirc);
        return -EINVAL;
    }

    for (i = 0; i < mapped_num; i++)
        total_size += mapped_blk[i].dma_length;

    if (total_size == 0 || total_size > U32_MAX) {
        pr_err("%s, invalid transfer size 0x%llx\n", __func__, total_size);
        return -EINVAL;
    }

    blk_info.mapped_num = mapped_num;
    blk_info.mapped_blk = (PBLK_ELEMENT)mapped_blk;
    blk_info.vail_num = mapped_num;
    blk_info.start = 0;
    blk_info.start_offs = 0;
    blk_info.end_size = mapped_blk[mapped_num - 1].dma_length;

    res = rpp_xfer_blks_ch(pdev, CH3, &blk_info, dmacodec,
                            total_size, write, 30000);
    if (res != total_size) {
        pr_err("%s, CH3 desc transfer failed, dirc %d, dev 0x%llx, size 0x%llx, blocks %u, res %zd\n",
               __func__, dirc, dmacodec, total_size, mapped_num, res);
        return -EIO;
    }

    pr_debug("CH3 desc transfer start 0x%llx end 0x%llx, total %u dma block\n",
             dmacodec, dmacodec + total_size, mapped_num);

    return 0;
}

static int ve_free_residual_instances(struct file *filp, struct rpp_dev *pdev)
{
    struct vmem_block *vmemBlk, *vmemNext;
    struct inst_block *instBlk, *instNext;
    struct dma_block *dmaBlk, *dmaNext;
    struct codec_inst_block *codec_instBlk, *codec_instNext;
    struct DataInstance *kdbInst = NULL;

    int8_t i, j, index;
    int32_t nCnt;
#ifndef SUPPORT_MULTI_OPEN_CLOSE
    unsigned long flags;
#endif
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct InterruptManager *veInterrupt = (struct InterruptManager *)vdev->veInterrupt;

    /* instance pool reset & destroy ops */
    struct ve_instance_pool_t *vip;
    struct ve_jpeg_pool_t *jip;
    unsigned char *vdi_mutexes_base;
    unsigned char *jdi_mutexes_base;
    unsigned char *instance_pool_addr;
    int instance_pool_size_per_core, pthread_mutex_offset;
    int8_t vdi_mutex_dead_mode[VE_CODEC_NUM] = {0,0,0,0};
    int8_t jdi_mutex_dead_mode[VE_JPEG_NUM] = {0,0,0,0};
    const int PTHREAD_MUTEX_T_DESTROY_VALUE = 0xdead10cc; /* don't change this value */

    pr_debug("[VE_RESIDAUL] ve free residual instance while driver crash close\n");

    if (!vdev || !veEngine || !veInterrupt) {
        pr_err(
"[VE_RESIDAUL] vdev %p or veEngine %p or veInterrupt %p invalid\n", vdev, veEngine, veInterrupt);
        return -EINVAL;
    }

    /* step1, free vmem for current process(all instance request) */
    nCnt = 0;
    list_for_each_entry_safe(vmemBlk, vmemNext, &s_vmem_block_head, list)
    {
        if (vmemBlk->filp == filp) {
#ifndef SUPPORT_MULTI_OPEN_CLOSE
            mutex_lock(&vdev->vMutex);
#endif
            vmem_free(&veEngine->vmem, vmemBlk->vmem.phys_addr, 0);
            list_del(&vmemBlk->list);
            kfree(vmemBlk);
            nCnt++;
#ifndef SUPPORT_MULTI_OPEN_CLOSE
            mutex_unlock(&vdev->vMutex);
#endif
        }
    }
    if (nCnt) {
        pr_info("[VE_RESIDAUL] veEngine %p release %d vmem block for open client %p\n", veEngine, nCnt, filp);
    }

    /* step2, free all instance for current process request */
#ifdef SUPPORT_MULTI_INST_INTR
    nCnt = 0;
    list_for_each_entry_safe(instBlk, instNext, &s_inst_block_head, list)
    {   /* instance combine with open client and process ID */
        if (instBlk->filp == filp)
        {
    #ifndef SUPPORT_MULTI_OPEN_CLOSE
            spin_lock_irqsave(&vdev->lock, flags);
    #endif
            /* start,instance pool->inUse & inst reset, vdi mutex crash setting */
        #ifdef VE_SUPPORT_MULTI_CLIENT
            if (instBlk->inst.IsCodec) {
                if (veEngine->instance_pool.size) {
                    instance_pool_size_per_core = (veEngine->instance_pool.size/VE_CODEC_NUM);
                    pthread_mutex_offset = instance_pool_size_per_core - (veEngine->instance_pool.sizePMutex*veEngine->instance_pool.nPMutex);

                    instance_pool_addr = ((unsigned char *)veEngine->instance_pool.base) + instance_pool_size_per_core*(instBlk->inst.inst_core_index & 0xffff);
                    vdi_mutexes_base = instance_pool_addr + pthread_mutex_offset;
                    vip = (struct ve_instance_pool_t *)instance_pool_addr;

                    pr_info("[VE_RESIDAUL] veEngine %p detect instance crash core index=%d, instIdx=%d, instance_pool_size_per_core=%d vdi_mutex_addr=%p vip=%p\n",
                             veEngine, instBlk->inst.inst_core_index, instBlk->inst.inst_inst_index, instance_pool_size_per_core, vdi_mutexes_base, vip);
                    if (vip) {
                        memset(&vip->codecInstPool[instBlk->inst.inst_inst_index][0], 0x00, 4); /*fixme*/
                        pr_info("coreIdx 0x%08x inst %d reset OK\n", (instBlk->inst.inst_core_index & 0xffff), instBlk->inst.inst_inst_index);

                        /* crash status save and share with user space */
                        vip->vpu_crash_status[instBlk->inst.inst_inst_index].count++;
                        vip->vpu_crash_status[instBlk->inst.inst_inst_index].cause = 0x5555;
                        vip->vpu_crash_status[instBlk->inst.inst_inst_index].filp = (int)filp;
                        pr_info("[VE_RESIDAUL] veEngine %p detect instance crash %d times with core index=%d instance index=%d\n",
                                 veEngine, vip->vpu_crash_status[instBlk->inst.inst_inst_index].count, instBlk->inst.inst_core_index, instBlk->inst.inst_inst_index);
            #if ENABLE_MUTEX_T_RESTORE
                        /* mutex restore configuration, be care of */
                        if (vdi_mutexes_base) {
                #ifdef SUPPORT_CRASH_REPAIRED
                            /*if app do crash repaired, don't restore*/
                            /*if (vip->crash_state == INSTANCE_CORRECT_RESET) */ {
                #endif
                            if (vdi_mutex_dead_mode[instBlk->inst.inst_core_index & 0xffff] == 0) {
                                for (i = 0; i < veEngine->instance_pool.nPMutex; i++) {
                                    memcpy(vdi_mutexes_base, &PTHREAD_MUTEX_T_DESTROY_VALUE, sizeof(PTHREAD_MUTEX_T_DESTROY_VALUE));
                                    vdi_mutexes_base += veEngine->instance_pool.sizePMutex;
                                }
                                vdi_mutex_dead_mode[instBlk->inst.inst_core_index & 0xffff] = 1;
                                pr_info("coreIdx 0x%08x vdi mutex base reset OK\n", (instBlk->inst.inst_core_index & 0xffff));
                            }
                #ifdef SUPPORT_CRASH_REPAIRED
                            }
                #endif
                        }
            #endif

            #ifdef SUPPORT_CRASH_REPAIRED
                        /*crash request setting for app*/
                        if (vip->crash_state) {
                            pr_info("[VE_RESIDAUL] core index %d instance %d crash state=%x, don't set request again\n",
                                     instBlk->inst.inst_core_index, instBlk->inst.inst_inst_index, vip->crash_state);
                        }
                        else{
                            vip->crash_state = INSTANCE_CORRECT_REQUEST;
                        }
            #endif
                        /*instance count decrease and update command turn*/
                        vip->vpu_instance_num--;
                        if (vip->cmd_serial > 0) {
                            /* tailor instance destroied */
                            if (vip->cmd_serial >= vip->vpu_instance_num) {
                                vip->cmd_serial = 0;
                            }
                            /* nothing to do for other instance destroied
                            else{
                                vip->cmd_serial--;
                            }*/
                        }
                    }
                }
            }
            else{
                if (veEngine->jpeg_pool.size) {
                    instance_pool_size_per_core = (veEngine->jpeg_pool.size/VE_JPEG_NUM);
                    pthread_mutex_offset = instance_pool_size_per_core - (veEngine->jpeg_pool.sizePMutex*veEngine->jpeg_pool.nPMutex);

                    instance_pool_addr = ((unsigned char *)veEngine->jpeg_pool.base) + instance_pool_size_per_core*(instBlk->inst.inst_core_index & 0xffff);
                    jdi_mutexes_base = instance_pool_addr + pthread_mutex_offset;
                    jip = (struct ve_jpeg_pool_t *)instance_pool_addr;

                    pr_info("[VE_RESIDAUL] veEngine %p detect jpeg crash instIdx=%d, core index=%d, jpeg_pool_size_per_core=%d jdi_mutex_addr=%p jip=%p\n",
                             veEngine, instBlk->inst.inst_inst_index, instBlk->inst.inst_core_index, instance_pool_size_per_core, jdi_mutexes_base, jip);
                    if (jip) {
                        memset(&jip->jpgInstPool[instBlk->inst.inst_inst_index][0], 0x00, 4);/*fixme used flag*/
                        memset(&jip->instPendingInst[instBlk->inst.inst_inst_index], 0x00, sizeof(void *)); /*pending instance*/
                        pr_info("coreIdx 0x%08x inst %d reset OK\n", (instBlk->inst.inst_core_index & 0xffff), instBlk->inst.inst_inst_index);
            #if ENABLE_MUTEX_T_RESTORE
                        /* mutex restore configuration, be care of */
                        if (jdi_mutexes_base) {
                            if (jdi_mutex_dead_mode[instBlk->inst.inst_core_index & 0xffff] == 0) {
                                for (i = 0; i < veEngine->jpeg_pool.nPMutex; i++) {
                                    memcpy(jdi_mutexes_base, &PTHREAD_MUTEX_T_DESTROY_VALUE, sizeof(PTHREAD_MUTEX_T_DESTROY_VALUE));
                                    jdi_mutexes_base += veEngine->jpeg_pool.sizePMutex;
                                }
                                jdi_mutex_dead_mode[instBlk->inst.inst_core_index & 0xffff] = 1;
                                pr_info("coreIdx 0x%08x jdi mutex base reset OK\n", (instBlk->inst.inst_core_index & 0xffff));
                            }
                        }
            #endif
                        /*instance count decrease and update command turn*/
                        jip->jpu_instance_num--;
                        if (jip->cmd_serial > 0) {
                            /* tailor instance destroied */
                            if (jip->cmd_serial >= jip->jpu_instance_num) {
                                jip->cmd_serial = 0;
                            }
                        }
                        if (jip->jpu_instance_num == 0) {
                            /*ToDo*/
                        }
                    }
                }
            }
        #endif
    #ifndef SUPPORT_MULTI_OPEN_CLOSE
            spin_unlock_irqrestore(&vdev->lock, flags);
    #endif

    #ifdef SUPPORT_CRASH_REPAIRED
            /*codec remove from instance list and add to crash list*/
            if (instBlk->inst.IsCodec) {
                list_del(&instBlk->list);
                list_add(&instBlk->list, &s_instance_crash_block_head);
            }
            /*jpeg remove from instance list and release*/
            else{
                list_del(&instBlk->list);
                kfree(instBlk);
            }
    #else
            list_del(&instBlk->list);
            kfree(instBlk);
    #endif
            nCnt++;
        }
    }
    if (nCnt) {
        pr_info("[VE_RESIDAUL] veEngine %p release %d instance for open client %p\n", veEngine, nCnt, filp);
    }
#endif

    /* step3, free dma buffer for app request */
    nCnt = 0;
    list_for_each_entry_safe(dmaBlk, dmaNext, &s_dma_block_head, list)
    {
        if (dmaBlk->filp == filp)
        {
            /* start, release the dma buffer for current process */
#ifndef SUPPORT_MULTI_OPEN_CLOSE
            spin_lock_irqsave(&vdev->lock, flags);
#endif
            if(veEngine->dma && veEngine->dma_handle) {
                index = dmaBlk->dma_offset / DMA_BUFFER_SIZE;
                for(i=0; i < DMA_POOL_SIZE; i++) {
                    if (veEngine->dmapool[i].used == 0) continue;

                    if (veEngine->dmapool[i].index == index) {
                        veEngine->dmapool[i].used = 0;
                        veEngine->avali_dma++;
                        break;
                    }
                }
                if (i >= DMA_POOL_SIZE ) {
                    pr_err("%s, invalid dma offset %x\n", __func__, dmaBlk->dma_offset);
                }
            }
#ifndef SUPPORT_MULTI_OPEN_CLOSE
            spin_unlock_irqrestore(&vdev->lock, flags);
#endif

            list_del(&dmaBlk->list);
            kfree(dmaBlk);
            nCnt++;
        }
    }
    if (nCnt) {
        pr_info("[VE_RESIDAUL] veEngine %p release %d dma block for open client %p\n", veEngine, nCnt, filp);
    }

    /* step4, free codec instance for app request */
    nCnt = 0;
    list_for_each_entry_safe(codec_instBlk, codec_instNext, &s_codec_inst_block_head, list)
    {
        if (codec_instBlk->filp == filp)
        {
            /* start, check codec coreIdx and instance no. */
            if ((codec_instBlk->codec_inst.index < veEngine->codec.codec_min) ||
                (codec_instBlk->codec_inst.index >= veEngine->codec.codec_max)) {
                pr_err("%s, invalid codec coreIdx 0x%x\n", __func__, codec_instBlk->codec_inst.index);
                continue;
            }

            if ((codec_instBlk->codec_inst.ref < 1) ||
                (codec_instBlk->codec_inst.ref > veEngine->codec.ins_max)) {
                pr_err("%s, invalid codec instance 0x%x\n", codec_instBlk->codec_inst.ref);
                continue;
            }

#ifndef SUPPORT_MULTI_OPEN_CLOSE
            spin_lock_irqsave(&vdev->lock, flags);
#endif
            for (i=veEngine->codec.codec_min; i< veEngine->codec.codec_max; i++) {
                if (codec_instBlk->codec_inst.index == i) {
                    veEngine->codec.codecs[i].ref--;
                    veEngine->codec.avail_ins++;
                    if(veEngine->codec.avail_ins == (veEngine->codec.codec_max - veEngine->codec.codec_min) * veEngine->codec.ins_max) {
                        veEngine->codec.populated = 0;
                    }
                    kdbInst = &veEngine->codec.dbInst[i];
                    for(j = 0; j < veEngine->codec.ins_max; j++) {
                        if(kdbInst->ref[j] == codec_instBlk->codec_inst.ref &&
                           kdbInst->used[j] == 1)
                        {
                            kdbInst->used[j] = 0;
                            pr_info("[VE_RESIDAUL] veEngine %p free codec with core index %d instance %d, remained %d for client %p\n",
                                     veEngine, codec_instBlk->codec_inst.index, codec_instBlk->codec_inst.ref,veEngine->codec.avail_ins, filp);
                            break;
                        }
                    }
                    break;
                }
            }
#ifndef SUPPORT_MULTI_OPEN_CLOSE
            spin_unlock_irqrestore(&vdev->lock, flags);
#endif

#ifndef SUPPORT_CRASH_REPAIRED
            /* add the coreIdx to codec crash list */
            list_del(&codec_instBlk->list);
            list_add(&codec_instBlk->list, &s_codec_crash_block_head);
#else
            list_del(&codec_instBlk->list);
            kfree(codec_instBlk);
#endif
            nCnt++;
            /* end, remove codec instance info */
        }
    }
    if (nCnt) {
        pr_info("[VE_RESIDAUL] veEngine %p free %d codec for open client %p\n", veEngine, nCnt, filp);
    }

    /* step5, free jpeg instance for app request */
    nCnt = 0;
    list_for_each_entry_safe(codec_instBlk, codec_instNext, &s_jpeg_inst_block_head, list)
    {
        if (codec_instBlk->filp == filp)
        {
            /* start, check jpeg coreIdx and instance no. */
            if ((codec_instBlk->codec_inst.index < veEngine->jpeg.codec_min) ||
                (codec_instBlk->codec_inst.index >= veEngine->jpeg.codec_max)) {
                pr_err("%s, invalid jpeg coreIdx 0x%x\n", __func__, codec_instBlk->codec_inst.index);
                continue;
            }

            if ((codec_instBlk->codec_inst.ref < 1) ||
                (codec_instBlk->codec_inst.ref > veEngine->jpeg.ins_max)) {
                pr_err("%s, invalid jpeg instance 0x%x\n", codec_instBlk->codec_inst.ref);
                continue;
            }

#ifndef SUPPORT_MULTI_OPEN_CLOSE
            spin_lock_irqsave(&vdev->lock, flags);
#endif
            for (i=veEngine->jpeg.codec_min; i< veEngine->jpeg.codec_max; i++) {
                if (codec_instBlk->codec_inst.index == i) {
                    veEngine->jpeg.codecs[i].ref--;
                    veEngine->jpeg.avail_ins++;
                    if(veEngine->jpeg.avail_ins == (veEngine->jpeg.codec_max - veEngine->jpeg.codec_min) * veEngine->jpeg.ins_max) {
                        veEngine->jpeg.populated = 0;
                    }
                    kdbInst = &veEngine->jpeg.dbInst[i];
                    for(j = 0; j < veEngine->jpeg.ins_max; j++) {
                        if(kdbInst->ref[j] == codec_instBlk->codec_inst.ref &&
                           kdbInst->used[j] == 1)
                        {
                            kdbInst->used[j] = 0;
                            pr_info("[VE_RESIDAUL] veEngine %p free jpeg with core index %d instance %d, remained %d for client %p\n",
                                     veEngine, codec_instBlk->codec_inst.index, codec_instBlk->codec_inst.ref,veEngine->jpeg.avail_ins, filp);
                            break;
                        }
                   }
                    break;
                }
            }
#ifndef SUPPORT_MULTI_OPEN_CLOSE
            spin_unlock_irqrestore(&vdev->lock, flags);
#endif

#ifndef SUPPORT_CRASH_REPAIRED
            /* add the coreIdx to jpeg crash list */
            list_del(&codec_instBlk->list);
            list_add(&codec_instBlk->list, &s_jpeg_crash_block_head);
#else
            list_del(&codec_instBlk->list);
            kfree(codec_instBlk);
#endif
            nCnt++;
            /* end, remove jpeg instance info */
        }
    }
    if (nCnt) {
        pr_info("[VE_RESIDAUL] veEngine %p free %d jpeg for open client %p\n", veEngine, nCnt, filp);
    }

    return 0;
}

static int ve_ioctl_get_mem_info(struct file* filp, struct rpp_dev *pdev, void *data)
{
    struct MemoryInfo *meminfo = (struct MemoryInfo *)data;
    struct VideoEngine *veEngine = (struct VideoEngine *)pdev->entire_ctrl_vdev.veEngine;
    struct InterruptManager *veInterrupt = (struct InterruptManager *)pdev->entire_ctrl_vdev.veInterrupt;
#ifdef VE_FRAME_BUFFER_CACHE
    int coreIdx;
#endif

    if (pdev && veEngine && veInterrupt) {
        if (veEngine->vmem.mem_size == 0) {
            pr_err("veEnigne %p doesn't initial vmem database\n", veEngine);
            return -ENOMEM;
        }
        meminfo->total_pages = veEngine->memInfo.total_pages;
        meminfo->alloc_pages = veEngine->memInfo.alloc_pages;
        meminfo->free_pages  = veEngine->memInfo.free_pages;
        meminfo->page_size   = veEngine->memInfo.page_size;

#ifdef VE_SUPPORT_MULTI_CLIENT
        meminfo->m_instance_pool_addr = veEngine->memInfo.m_instance_pool_addr;
        meminfo->m_instance_pool_size = veEngine->memInfo.m_instance_pool_size;

        meminfo->m_jpeg_pool_addr = veEngine->memInfo.m_jpeg_pool_addr;
        meminfo->m_jpeg_pool_size = veEngine->memInfo.m_jpeg_pool_size;
#endif

        meminfo->m_dma_addr = veEngine->memInfo.m_dma_addr;
        meminfo->m_dma_size = veEngine->memInfo.m_dma_size;

        meminfo->m_mio_addr = veEngine->memInfo.m_mio_addr;
        meminfo->m_mio_size = veEngine->memInfo.m_mio_size;

        meminfo->m_vpu_addr = veEngine->memInfo.m_vpu_addr;
        meminfo->m_vpu_size = veEngine->memInfo.m_vpu_size;

#ifdef VE_FRAME_BUFFER_CACHE
        for (coreIdx = 0; coreIdx < VE_CODEC_NUM; coreIdx++) {
            meminfo->m_dma_user[coreIdx].wuser      = veEngine->memInfo.m_dma_user[coreIdx].wuser;
            meminfo->m_dma_user[coreIdx].wusersize  = veEngine->memInfo.m_dma_user[coreIdx].wusersize;
            meminfo->m_dma_user[coreIdx].ruser      = veEngine->memInfo.m_dma_user[coreIdx].ruser;
            meminfo->m_dma_user[coreIdx].rusersize  = veEngine->memInfo.m_dma_user[coreIdx].rusersize;
        }
#endif

        meminfo->ve_mem.phys_addr = veEngine->memInfo.ve_mem.phys_addr;
        meminfo->ve_mem.virt_addr = veEngine->memInfo.ve_mem.virt_addr;
        meminfo->ve_mem.size      = veEngine->memInfo.ve_mem.size;

        meminfo->ve_register.phys_addr = veEngine->memInfo.ve_register.phys_addr;
        meminfo->ve_register.virt_addr = veEngine->memInfo.ve_register.virt_addr;
        meminfo->ve_register.size      = veEngine->memInfo.ve_register.size;
        return 0;
    }

    pr_err("rpp dev %p or veEngine %p or veInterrupt %p not available\n", pdev, veEngine, veInterrupt);
    return -EINVAL;

}

static int ve_ioctl_alloc_dma_buf(struct file* filp, struct rpp_dev *pdev, void *data)
{
    int32_t offset;
    int8_t i;
    unsigned long flags;
    struct dma_block *dmb;
    struct rpp_vdev *vdev= &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct DmaBufRequest *dmaBufReq = (struct DmaBufRequest *)data;

    if(veEngine->dma && veEngine->dma_handle && veEngine->avali_dma) {
        dmb = kzalloc(sizeof(struct dma_block), GFP_KERNEL);
        if (!dmb) {
            pr_err("vdev %p can't allocate dma block\n", vdev);
            return -ENOMEM;
        }

        spin_lock_irqsave(&vdev->lock, flags);
        for(i=0; i < DMA_POOL_SIZE; i++) {
            if (veEngine->dmapool[i].used) continue;
            offset = veEngine->dmapool[i].index * DMA_BUFFER_SIZE;
            veEngine->dmapool[i].used = 1;
            dmaBufReq->offset = offset;
            dmaBufReq->size   = DMA_BUFFER_SIZE;
            veEngine->avali_dma--;
            break;
        }
        spin_unlock_irqrestore(&vdev->lock, flags);

        if (i >= DMA_POOL_SIZE) {
            *(int32_t *)data = -1;
            kfree(dmb);
            pr_err("veEngine %p dma buffer emptied,can't allocate more\n", veEngine);
            return -ENOMEM;
        }

        spin_lock_irqsave(&vdev->lock, flags);
        dmb->dma_offset = dmaBufReq->offset;
        dmb->filp       = filp;
        list_add(&dmb->list, &s_dma_block_head);
        spin_unlock_irqrestore(&vdev->lock, flags);

        pr_info("veEngine %p allocate dma buffer index %d, remain %d buffer for open client %p\n",
                 veEngine, i, veEngine->avali_dma, filp);
        return 0;
    }
    else{
        pr_err("can't allocate dma buffer by veEngine %p with %d buffer remain\n",
                veEngine, veEngine->avali_dma);
        return -ENOMEM;
    }
}

static int ve_ioctl_free_dma_buf(struct file* filp, struct rpp_dev *pdev, void *data)
{
    int8_t i, index;
    unsigned long flags;
    struct dma_block *dmb, *next;
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct DmaBufRequest *dmaBufReq = (struct DmaBufRequest *)data;

    if(veEngine->dma && veEngine->dma_handle) {
        if (dmaBufReq->size != DMA_BUFFER_SIZE) {
            pr_err("%s can't free dma buffer by %p, size overflow\n", __func__, veEngine);
            return -EINVAL;
        }

        spin_lock_irqsave(&vdev->lock, flags);
        index = dmaBufReq->offset / DMA_BUFFER_SIZE;
        for(i=0; i < DMA_POOL_SIZE; i++) {
            if (veEngine->dmapool[i].used == 0) continue;

            if (veEngine->dmapool[i].index == index) {
                veEngine->dmapool[i].used = 0;
                veEngine->avali_dma++;
                break;
            }
        }
        spin_unlock_irqrestore(&vdev->lock, flags);

        if (i >= DMA_POOL_SIZE ) {
            pr_err("invalid dma offset %x\n", dmaBufReq->offset);
            return -EINVAL;
        }

        spin_lock_irqsave(&vdev->lock, flags);
        list_for_each_entry_safe(dmb, next, &s_dma_block_head, list)
        {
            if (dmb->dma_offset == dmaBufReq->offset && dmb->filp == filp) {
                list_del(&dmb->list);
                kfree(dmb);
                break;
            }
        }
        spin_unlock_irqrestore(&vdev->lock, flags);

        pr_info("veEngine %p success free dma buffer index %d keep %d block buffers for open client %p\n",
                 veEngine, index, veEngine->avali_dma, filp);
        return 0;
   }else{
        pr_err("%s can't free dma buffer by %p\n", __func__, veEngine);
        return -ENOMEM;
    }
}

/* Transfer data from ve device buffer to host dma buffer
 * dmaReq->offset, offset of host dma buffer
 * dmaReq->devaddr, ve buffer addrss of device side
 * dmaReq->size, transfer length(bytes)
*/
static int ve_ioctl_write_dma_buf(struct file* filp, struct rpp_dev *pdev, void *data)
{
    int status;
    struct DmaElement Element;

    struct rpp_vdev *vdev= &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct DmaRequest *dmaReq = (struct DmaRequest *)data;

    if(veEngine->dma && veEngine->dma_handle) {
        if ((dmaReq->offset + dmaReq->size) > DMA_BUFFER_LENGTH) {
            pr_err("veEngine %p dma offset %x and reqest size %x over dma buf length\n", veEngine, dmaReq->offset, dmaReq->size);
            return -ENOMEM;
        }
        Element.size    = dmaReq->size;
        Element.dmahost = veEngine->dma_handle + dmaReq->offset;
        Element.dmacodec= dmaReq->device;
        status = rpp_dma_transfer_desc_single(pdev, DMA_WRITE, VE_PCIE_DMA_CH, &Element);
        return status;
    }else{
        pr_err("veEngine %p doesn't alloc dma buffer\n", veEngine);
        return -ENOMEM;
    }
}

/* Transfer data from host dma buffer to ve device buffer
 * dmaReq->offset, offset of host dma buffer
 * dmaReq->devaddr, ve buffer addrss of device side
 * dmaReq->size, transfer length(bytes)
*/
static int ve_ioctl_read_dma_buf(struct file* filp, struct rpp_dev *pdev, void *data)
{
    int status;
    struct DmaElement Element;

    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct DmaRequest *dmaReq = (struct DmaRequest *)data;

    if(veEngine->dma && veEngine->dma_handle) {
        if ((dmaReq->offset + dmaReq->size) > DMA_BUFFER_LENGTH) {
            pr_err("veEngine %p dma offset %x and reqest size %x over dma buf length\n", veEngine, dmaReq->offset, dmaReq->size);
            return -ENOMEM;
        }
        Element.size    = dmaReq->size;
        Element.dmahost = veEngine->dma_handle + dmaReq->offset;
        Element.dmacodec= dmaReq->device;
        status = rpp_dma_transfer_desc_single(pdev, DMA_READ, VE_PCIE_DMA_CH, &Element);
        return status;
    }else{
        pr_err("veEngine %p doesn't alloc dma buffer\n", veEngine);
        return -ENOMEM;
    }
}

/* Transfer data from ve device buffer to host(dma) buffer
 * pdev, rpp deive instance
 * dmaReq->devaddr, ve frame buffer addrss of device side
 * dmaReq->host, host buffer address of user data
 * dmaReq->size, transfer length(bytes)
*/
static int ve_ioctl_write_user_buf(struct file* filp, struct rpp_dev *pdev, void *data)
{
#ifdef VE_FRAME_BUFFER_CACHE
    int status;
    struct DmaElement Element;

    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct DmaRequest *dmaReq = (struct DmaRequest *)data;

    if (dmaReq->offset >= VE_CODEC_NUM) {
        pr_err("veEngine %p dma offset %d over max coreIdx \n", veEngine, dmaReq->offset);
        return -EINVAL;
    }

    if(veEngine->dma_user[dmaReq->offset].dma_wuser && veEngine->dma_user[dmaReq->offset].dma_wuser_handle) {
        if (dmaReq->size > WR_USER_DMA_BUFFER_SIZE) {
            pr_err("dmaReq->offset %p dma[%] write size %x over write buffer size\n", veEngine, dmaReq->offset, dmaReq->size);
            return -ENOMEM;
        }
        Element.size    = dmaReq->size;
        Element.dmahost = veEngine->dma_user[dmaReq->offset].dma_wuser_handle;
        Element.dmacodec= dmaReq->device;
        status = rpp_dma_transfer_desc_single(pdev, DMA_WRITE, VE_PCIE_DMA_CH, &Element);
        return status;
    }else{
        pr_err("vdev %p doesn't alloc dma write user buffer\n", vdev);
        return -ENOMEM;
    }
#else
    int status;
    rpp_pages_t *rpp_pages;

    struct DmaRequest *dmaReq = (struct DmaRequest *)data;
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;

    /*step1, map user buffer(host) to dma pages*/
    rpp_pages = rpp_map_user_buf(pdev, dmaReq->host, (uint64_t)dmaReq->size);
    if (rpp_pages == NULL || (rpp_pages->mapped_nents == 0)) {
        pr_err("%s, failed map host buffer %llx, size %x\n", __func__, dmaReq->host, dmaReq->size);
        return -ENOMEM;
    }

    /*step2, stich each dma block(physicall address continued and length)*/
    struct dma_mapped_blk *mapped_blk = NULL;
    struct scatterlist *sg, *start;
    uint64_t prev_dma_address;
    uint32_t prev_dma_length;
    uint32_t i, mapped_num;
    void *pmapped;

    pmapped = kmalloc(rpp_pages->mapped_nents * sizeof(struct dma_mapped_blk), GFP_KERNEL);
    if (pmapped == NULL) {
        pr_err("%s, failed allocate dam mapped memory\n", __func__);
        status = -ENOMEM;
        goto err_wmappled;
    }
    mapped_blk = (struct dma_mapped_blk *)pmapped;
    prev_dma_address = 0;
    prev_dma_length = 0;
    mapped_num = 0;
    start = rpp_pages->sgt.sgl;

    for_each_sg(start, sg, rpp_pages->mapped_nents, i) {
            if ((prev_dma_address + (uint64_t)prev_dma_length) == cpu_to_le64((u64)sg_dma_address(sg))) {
            /*  continued dma address */
            prev_dma_address = cpu_to_le64((u64)sg_dma_address(sg));
            prev_dma_length = cpu_to_le32((u32)sg_dma_len(sg));
            mapped_blk--;
            pr_debug("pre dma block %d, dma_address=0x%llx, dma_length=0x%x, new sg %d dma_address=0x%llx, dma_length=0x%x\n",
                     mapped_num, mapped_blk->dma_address, mapped_blk->dma_length, i, prev_dma_address, prev_dma_length);
            mapped_blk->dma_length += prev_dma_length;
            mapped_blk++;
        }else{
            /*  non-continued dma address */
            mapped_blk->dma_address = cpu_to_le64((u64)sg_dma_address(sg));
            mapped_blk->dma_length = cpu_to_le32((u32)sg_dma_len(sg));
            prev_dma_address = mapped_blk->dma_address;
            prev_dma_length = mapped_blk->dma_length;
            pr_debug("new dma block %d, dma_address=0x%llx, dma_length=0x%x offset=0x%x\n",
                      mapped_num, mapped_blk->dma_address, mapped_blk->dma_length, sg->offset);
            mapped_blk++;
            mapped_num++;
        }
    }

    /*step3, send the dma link list*/
    status = rpp_dma_transfer_desc_multi(pdev, DMA_WRITE, VE_PCIE_DMA_CH, dmaReq->device, (struct dma_mapped_blk *)pmapped, mapped_num);

    /*step4, free mapped blk and unmap user buffer*/
    kfree(pmapped);
err_wmappled:
    rpp_unmap_user_buf(pdev, rpp_pages);
    return status;
#endif
}
/* Transfer data from host(dma) buffer to ve device buffer
 * pdev, rpp deive instance
 * dmaReq->devaddr, ve buffer addrss of device side
 * dmaReq->host, host buffer address of user data
 * dmaReq->size, transfer length(bytes)
*/
static int ve_ioctl_read_user_buf(struct file* filp, struct rpp_dev *pdev, void *data)
{
#ifdef VE_FRAME_BUFFER_CACHE
    int status;
    struct DmaElement Element;

    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct DmaRequest *dmaReq = (struct DmaRequest *)data;

    if (dmaReq->offset >= VE_CODEC_NUM) {
        pr_err("veEngine %p dma offset %d over max coreIdx \n", veEngine, dmaReq->offset);
        return -EINVAL;
    }

    if(veEngine->dma_user[dmaReq->offset].dma_ruser && veEngine->dma_user[dmaReq->offset].dma_ruser_handle) {
        if (dmaReq->size > WR_USER_DMA_BUFFER_SIZE) {
            pr_err("veEngine % dma[%d] read size %x over read buffer size\n", veEngine, dmaReq->offset, dmaReq->size);
            return -ENOMEM;
        }
        Element.size    = dmaReq->size;
        Element.dmahost = veEngine->dma_user[dmaReq->offset].dma_ruser_handle;
        Element.dmacodec= dmaReq->device;
        status = rpp_dma_transfer_desc_single(pdev, DMA_READ, VE_PCIE_DMA_CH, &Element);
        return status;
    }else{
        pr_err("veEngine %p doesn't alloc dma read user buffer\n", veEngine);
        return -ENOMEM;
    }
#else
    int status;
    rpp_pages_t *rpp_pages;

    struct DmaRequest *dmaReq = (struct DmaRequest *)data;
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;

    /*step1, map user buffer(host) to dma pages*/
    rpp_pages = rpp_map_user_buf(pdev, dmaReq->host, (uint64_t)dmaReq->size);
    if (rpp_pages == NULL || (rpp_pages->mapped_nents == 0)) {
        pr_err("%s, failed map host buffer 0x%llx, size 0x%x\n", __func__, dmaReq->host, dmaReq->size);
        return -ENOMEM;
    }

    /*step2, stich each dma block(physicall address continued and length)*/
    struct dma_mapped_blk *mapped_blk = NULL;
    struct scatterlist *sg, *start;
    uint64_t prev_dma_address;
    uint32_t prev_dma_length;
    uint32_t i, mapped_num;
    void *pmapped;

    pmapped = kmalloc(rpp_pages->mapped_nents * sizeof(struct dma_mapped_blk), GFP_KERNEL);
    if (pmapped == NULL) {
        pr_err("%s, failed allocate dam mapped memory\n", __func__);
        status = ENOMEM;
        goto err_rmappled;
    }
    mapped_blk = (struct dma_mapped_blk *)pmapped;
    prev_dma_address = 0;
    prev_dma_length = 0;
    mapped_num = 0;
    start = rpp_pages->sgt.sgl;

    for_each_sg(start, sg, rpp_pages->mapped_nents, i) {
        if ((prev_dma_address + (uint64_t)prev_dma_length) == cpu_to_le64((u64)sg_dma_address(sg))) {
            /*  continued dma address */
            prev_dma_address = cpu_to_le64((u64)sg_dma_address(sg));
            prev_dma_length = cpu_to_le32((u32)sg_dma_len(sg));
            mapped_blk--;
            pr_debug("pre dma block %d, dma_address=0x%llx, dma_length=0x%x, new sg %d dma_address=0x%llx, dma_length=0x%x\n",
                     mapped_num, mapped_blk->dma_address, mapped_blk->dma_length, i, prev_dma_address, prev_dma_length);
            mapped_blk->dma_length += prev_dma_length;
            mapped_blk++;
        }else{
            /*  non-continued dma address */
            mapped_blk->dma_address = cpu_to_le64((u64)sg_dma_address(sg));
            mapped_blk->dma_length = cpu_to_le32((u32)sg_dma_len(sg));
            prev_dma_address = mapped_blk->dma_address;
            prev_dma_length = mapped_blk->dma_length;
            pr_debug("dma block %d, dma_address=0x%llx, dma_length=0x%x offset=0x%x\n",
                      mapped_num, mapped_blk->dma_address, mapped_blk->dma_length, sg->offset);
            mapped_blk++;
            mapped_num++;
        }
    }

    /*step3, transfer the dma link list*/
    status = rpp_dma_transfer_desc_multi(pdev, DMA_READ, VE_PCIE_DMA_CH, dmaReq->device, (struct dma_mapped_blk *)pmapped, mapped_num);

    /*step4, free mapped blk and unmap user buffer*/
    kfree(pmapped);
err_rmappled:
    rpp_unmap_user_buf(pdev, rpp_pages);
    return status;
#endif
}

static int ve_ioctl_get_codec_intr(struct file* filp, struct rpp_dev *pdev, void *data)
{
#ifdef SUPPORT_MULTI_INST_INTR
    int ret;
    uint32_t intr_inst_index;
    uint32_t intr_core_index;
    uint32_t intr_reason_in_q, intr_reason;
    uint32_t interrupt_flag_in_q;

    struct IntrRequest *intReq = (struct IntrRequest *)data;
    struct InterruptManager *veInterrupt = pdev->entire_ctrl_vdev.veInterrupt;

    if (!pdev || !veInterrupt || !intReq ||
        intReq->intr_core_index >= VE_CODEC_NUM ||
        intReq->intr_inst_index >= VE_CODEC_INSTANCE_NUM)
    {
        pr_err("[VE_INT] veInterrupt %p get interrupt with invailed paramter\n", veInterrupt);
        return -EINVAL;
    }

    intr_inst_index = intReq->intr_inst_index;
    intr_core_index = intReq->intr_core_index;
    pr_debug("[VE_INT], veInterrupt %p coreIdx %d instance %d get interrupt entry\n",
              veInterrupt, intr_core_index, intr_inst_index);

    intr_reason         = 0;
    intr_reason_in_q    = 0;
    interrupt_flag_in_q = kfifo_out_spinlocked(&veInterrupt->vint_queue[intr_core_index][intr_inst_index],
                          &intr_reason_in_q, sizeof(uint32_t), &veInterrupt->vint_lock[intr_core_index][intr_inst_index]);
    if (interrupt_flag_in_q > 0)
    {
        intr_reason = intr_reason_in_q;
        pr_debug("[VE_INT], veInterrupt %p coreIdx %d instance %d get interrupt: 0x%08x without waiting\n",
                  veInterrupt, intr_core_index, intr_inst_index, intr_reason);
        goto INTERRUPT_REMAIN_IN_VQUEUE;
    }

    if (intReq->timeout <= 0) {
        pr_debug("[VE_INT] veInterrupt %p coreIdx %d instance %d to get interrupt\n",
                  veInterrupt, intr_core_index, intr_inst_index);
        return -ETIME;
    }

#ifdef SUPPORT_TIMEOUT_RESOLUTION
    kt =  ktime_set(0, intReq->timeout*1000*1000);
    ret = wait_event_interruptible_hrtimeout(veInterrupt->vint_wait[intr_core_index][intr_inst_index],
          veInterrupt->vint_flag[intr_core_index][intr_inst_index] != 0, kt);
#else
    ret = wait_event_interruptible_timeout(veInterrupt->vint_wait[intr_core_index][intr_inst_index],
          veInterrupt->vint_flag[intr_core_index][intr_inst_index] != 0, msecs_to_jiffies(intReq->timeout));
#endif

#ifdef SUPPORT_TIMEOUT_RESOLUTION
    if (ret == -ETIME) {
        pr_err("[VE_INT], veInterrupt %p timeout coreIdx %d instance %d get interrup\n",
                veInterrupt, intr_core_index, intr_inst_index);
        return -ETIME;
    }
#else
    if (!ret) {
        pr_err("[VE_INT], veInterrupt %p timeout coreIdx %d instance %d get interrupt\n",
                veInterrupt, intr_core_index, intr_inst_index);
        return -ETIME;
    }
#endif
    if (signal_pending(current)) {
        pr_err("[VE_INT], veInterrupt %p sytem pending coreIdx %d instance %d get interrupt\n",
                veInterrupt, intr_core_index, intr_inst_index);
        return -ERESTARTSYS;
    }
    intr_reason_in_q    = 0;
    interrupt_flag_in_q = kfifo_out_spinlocked(&veInterrupt->vint_queue[intr_core_index][intr_inst_index],
                          &intr_reason_in_q, sizeof(uint32_t), &veInterrupt->vint_lock[intr_core_index][intr_inst_index]);
    if (interrupt_flag_in_q > 0) {
        intr_reason = intr_reason_in_q;
        pr_debug("[VE_INT], veInterrupt %p coreIdx %d instance %d get interrupt: 0x%08x wait %d ms\n",
                  veInterrupt ,intr_core_index, intr_inst_index, intr_reason, intReq->timeout);
    }else{
        intr_reason = 0;
        pr_debug("[VE_INT], veInterrupt %p coreIdx %d instance %d doen't get interrupt wait %d ms\n",
                  veInterrupt, intr_core_index, intr_inst_index, intReq->timeout);
    }

INTERRUPT_REMAIN_IN_VQUEUE:
    intReq->intr_reason = intr_reason;
    veInterrupt->vint_flag[intr_core_index][intr_inst_index] = 0;
    pr_debug("[VE_INT], veInterrupt %p coreIdx %d instance %d get interrupt 0x%08x\n",
              veInterrupt, intr_core_index, intr_inst_index, intr_reason);
#endif
    return 0;
}

static int ve_ioctl_get_jpeg_intr(struct file* filp, struct rpp_dev *pdev, void *data)
{
#ifdef SUPPORT_MULTI_INST_INTR
    int ret;
    uint32_t intr_inst_index;
    uint32_t intr_core_index;
    uint32_t intr_reason_in_q, intr_reason;
    uint32_t interrupt_flag_in_q;

    struct IntrRequest *intReq = (struct IntrRequest *)data;
    struct InterruptManager *veInterrupt = pdev->entire_ctrl_vdev.veInterrupt;

    if (!pdev || !veInterrupt || !intReq ||
        intReq->intr_core_index >= VE_JPEG_NUM ||
        intReq->intr_inst_index >= VE_JPEG_INSTANCE_NUM)
    {
        return -EINVAL;
    }

    intr_inst_index = intReq->intr_inst_index;
    intr_core_index = intReq->intr_core_index;
    intr_reason         = 0;
    intr_reason_in_q    = 0;
    interrupt_flag_in_q = kfifo_out_spinlocked(&veInterrupt->jint_queue[intr_core_index][intr_inst_index],
                          &intr_reason_in_q, sizeof(uint32_t), &veInterrupt->jint_lock[intr_core_index]);
    if (interrupt_flag_in_q > 0)
    {
        intr_reason = intr_reason_in_q;
       goto INTERRUPT_REMAIN_IN_JQUEUE;
    }

#ifdef SUPPORT_TIMEOUT_RESOLUTION
    kt =  ktime_set(0, intReq->timeout*1000*1000);
    ret = wait_event_interruptible_hrtimeout(veInterrupt->jint_wait[intr_core_index][intr_inst_index],
          veInterrupt->jint_flag[intr_core_index][intr_inst_index] != 0, kt);
#else
    ret = wait_event_interruptible_timeout(veInterrupt->jint_wait[intr_core_index][intr_inst_index],
          veInterrupt->jint_flag[intr_core_index][intr_inst_index] != 0, msecs_to_jiffies(intReq->timeout));
#endif

    if (!ret) {
        return -ETIME;
    }

    if (signal_pending(current)) {
        return -ERESTARTSYS;
    }

    intr_reason_in_q    = 0;
    interrupt_flag_in_q = kfifo_out_spinlocked(&veInterrupt->jint_queue[intr_core_index][intr_inst_index],
                          &intr_reason_in_q, sizeof(uint32_t), &veInterrupt->jint_lock[intr_core_index]);
    if (interrupt_flag_in_q > 0) {
        intr_reason = intr_reason_in_q;
    }

INTERRUPT_REMAIN_IN_JQUEUE:
    intReq->intr_reason = intr_reason;
    veInterrupt->jint_flag[intr_core_index][intr_inst_index] = 0;
#endif
    return 0;
}

static int ve_ioctl_alloc_inst(struct file* filp, struct rpp_dev *pdev, void *data)
{
#ifdef SUPPORT_MULTI_INST_INTR
    unsigned long flags;
    struct inst_block *instBlk, *next;
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct InterruptManager *veInterrupt = (struct InterruptManager *)vdev->veInterrupt;
    struct InstRequest *instReq = (struct InstRequest *)data;

    if (!vdev || !veInterrupt || !veEngine || !instReq) {
        pr_err("%s, vdev %p or veEngine %p or veInterrupt %p or instReq %p isn't avaliable.\n",
                __func__, vdev, veEngine, veInterrupt, instReq);
        return -EINVAL;
    }

    /* instReq->inst_core_index include the device id(H16) and core index(L16)*/
    if (instReq->IsCodec) {
        if ((instReq->inst_core_index & 0xffff) >= VE_CODEC_NUM || instReq->inst_inst_index >= VE_CODEC_INSTANCE_NUM)
            return -EINVAL;
    }else{
        if ((instReq->inst_core_index & 0xffff) >= VE_JPEG_NUM || instReq->inst_inst_index >= VE_JPEG_INSTANCE_NUM)
            return -EINVAL;
    }

    /* add the instance to instance list head for crash check */
    instBlk = kzalloc(sizeof(struct inst_block), GFP_KERNEL);
    if (!instBlk) {
        pr_err("vdev %p can't allocation instance list memory", vdev);
        return -ENOMEM;
    }

    spin_lock_irqsave(&vdev->lock, flags);
    instBlk->inst.inst_core_index = instReq->inst_core_index;
    instBlk->inst.inst_inst_index = instReq->inst_inst_index;
    instBlk->inst.IsCodec         = instReq->IsCodec;
    instBlk->filp                 = filp;
    list_add(&instBlk->list, &s_inst_block_head);

    instReq->inst_count  = 0;
    list_for_each_entry_safe(instBlk, next, &s_inst_block_head, list)
    {
        if (instBlk->inst.inst_core_index == instReq->inst_core_index &&
            instBlk->inst.IsCodec         == instReq->IsCodec)
            instReq->inst_count++;
    }
    spin_unlock_irqrestore(&vdev->lock, flags);

    /* reset the hardware interrupt queue list */
    if (instReq->IsCodec) {
        kfifo_reset(&veInterrupt->vint_queue[instReq->inst_core_index & 0xffff][instReq->inst_inst_index]);
    }else{
        kfifo_reset(&veInterrupt->jint_queue[instReq->inst_core_index & 0xffff][instReq->inst_inst_index]);
    }

    pr_info("veEngine %p allocate instance:type %s with coreIdx 0x%08x inst index %d for open client %p, current coreIdx remain user %d\n",
             veEngine, instReq->IsCodec?"codec":"jpeg", instReq->inst_core_index, instReq->inst_inst_index, filp, instReq->inst_count);
#endif
    return 0;
}

static int ve_ioctl_free_inst(struct file* filp, struct rpp_dev *pdev, void *data)
{
#ifdef SUPPORT_MULTI_INST_INTR
    unsigned long flags;
    struct inst_block *instBlk, *next;
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct InterruptManager *veInterrupt = vdev->veInterrupt;
    struct InstRequest *instReq = (struct InstRequest *)data;

    if (!vdev || !veInterrupt || !veEngine || !instReq) {
        pr_err("%s, vdev %p or veEngine %p or veInterrupt %p or instReq %p isn't avaliable. \n",
                __func__, vdev, veEngine, veInterrupt, instReq);
        return -EINVAL;
    }

    /* instReq->inst_core_index include the device id(H16) and core index(L16)*/
    if (instReq->IsCodec) {
        if ((instReq->inst_core_index & 0xffff) >= VE_CODEC_NUM || instReq->inst_inst_index >= VE_CODEC_INSTANCE_NUM)
            return -EINVAL;
    }else{
        if ((instReq->inst_core_index & 0xffff) >= VE_JPEG_NUM || instReq->inst_inst_index >= VE_JPEG_INSTANCE_NUM)
            return -EINVAL;
    }

    /* remove current instance from instance list */
    spin_lock_irqsave(&vdev->lock, flags);
    list_for_each_entry_safe(instBlk, next, &s_inst_block_head, list)
    {
        if (instBlk->inst.inst_core_index == instReq->inst_core_index &&
            instBlk->inst.inst_inst_index == instReq->inst_inst_index &&
            instBlk->inst.IsCodec         == instReq->IsCodec         &&
            instBlk->filp                 == filp)
        {
            list_del(&instBlk->list);
            kfree(instBlk);
            break;
        }
    }

    instReq->inst_count = 0;
    list_for_each_entry_safe(instBlk, next, &s_inst_block_head, list)
    {
        if (instBlk->inst.inst_core_index == instReq->inst_core_index &&
            instBlk->inst.IsCodec         == instReq->IsCodec)
            instReq->inst_count++;
    }
    spin_unlock_irqrestore(&vdev->lock, flags);

    /* reset the hardware interrupt queue list */
    if (instReq->IsCodec) {
        kfifo_reset(&veInterrupt->vint_queue[instReq->inst_core_index & 0xffff][instReq->inst_inst_index]);
    }else{
        kfifo_reset(&veInterrupt->jint_queue[instReq->inst_core_index & 0xffff][instReq->inst_inst_index]);
    }

    pr_info("veEngine %p free instance:type %s with coreIdx 0x%08x inst index %d for open client %p, current coreIdx remain user %d\n",
             veEngine, instReq->IsCodec?"codec":"jpeg", instReq->inst_core_index, instReq->inst_inst_index, filp, instReq->inst_count);
#endif
    return 0;
}

static int ve_ioctl_alloc_codec(struct file* filp, struct rpp_dev *pdev, void *data)
{
    struct CodecInstance *kcodec;
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct CodecInstance *codecReq = (struct CodecInstance *)data;

    if (!vdev || !veEngine || !codecReq) {
        pr_err("%s, handler isn't avaliable. vdev %p veEngine %p codecReq %p\n",
                __func__, vdev, veEngine, codecReq);
        return -EINVAL;
    }

    kcodec = ve_instance_new(vdev, &veEngine->codec, filp, 1);
    if (kcodec) {
        codecReq->index = kcodec->index;
        codecReq->ref   = kcodec->ref;
        pr_info("veEngine %p allocate codec with core index %d instance %d for open client %p\n",
                 veEngine, codecReq->index, codecReq->ref, filp);
        return 0;
    }else{
        codecReq->index = -1;
        codecReq->ref   = -1;
        return -EBUSY;
    }
}

static int ve_ioctl_free_codec(struct file* filp, struct rpp_dev *pdev, void *data)
{
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct CodecInstance *kcodec = (struct CodecInstance *)data;

    if (!vdev || !veEngine || !kcodec) {
        pr_err("%s, hander isn't avaliable. vdev %p veEngine %p kcodec %p\n",
                __func__, vdev, veEngine, kcodec);
        return -EINVAL;
    }

    return ve_instance_free(vdev, &veEngine->codec, kcodec, filp, 1);
}

static int ve_ioctl_get_codec_info(struct file* filp, struct rpp_dev *pdev, void *data)
{
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct CodecInfo *info = (struct CodecInfo *)data;

    if (!vdev || !veEngine || !info) {
        pr_err("%s, hander isn't avaliable. vdev %p veEngine %p info %p\n",
                __func__, vdev, veEngine, info);
        return -EINVAL;
    }

    if (veEngine->state_flag) {
        pr_info("%s, veEngine %p workloading heavely, it can't allocate any more instances, current state %x\n",
                __func__, veEngine, veEngine->state_flag);
        return -EBUSY;
    }

#if ENABLE_VMEM_CHECK
    if ((veEngine->memInfo.free_pages * veEngine->memInfo.page_size) < MIN_VMEM_REQUEST) {
        pr_info("%s, veEngine %p vmem is not enough, current vmem stats: total %ld pages, free %ld pages, page size %x\n",
                __func__, veEngine, veEngine->memInfo.total_pages, veEngine->memInfo.free_pages, veEngine->memInfo.page_size);
        return -ENOMEM;
    }
#endif

    info->avali_ins = veEngine->codec.avail_ins;
    info->populated = veEngine->codec.populated;

    return 0;
}

static int ve_ioctl_alloc_jpeg(struct file* filp, struct rpp_dev *pdev, void *data)
{
    struct CodecInstance *kcodec;
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct CodecInstance *jpegReq = (struct CodecInstance *)data;

    if (!vdev || !veEngine) {
        pr_err("%s, hander isn't avaliable. vdev %p veEngine %p jpegReq %p\n",
                __func__, vdev, veEngine, jpegReq);
        return -EINVAL;
    }

    kcodec = ve_instance_new(vdev, &veEngine->jpeg , filp, 0);
    if (kcodec) {
        jpegReq->index = kcodec->index;
        jpegReq->ref   = kcodec->ref;
        pr_info("veEngine %p allocate jpeg with core index %d instance %d for open client %p\n",
                 veEngine, jpegReq->index, jpegReq->ref, filp);
        return 0;
    }else{
        jpegReq->index = -1;
        jpegReq->ref   = -1;
        return -EBUSY;
    }
}

static int ve_ioctl_free_jpeg(struct file* filp, struct rpp_dev *pdev, void *data)
{
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct CodecInstance *kjpeg = (struct CodecInstance *)data;

    if (!vdev || !veEngine || !kjpeg) {
        pr_err("%s, hander isn't avaliable. vdev %p veEngine %p kjpeg %p\n",
                __func__, vdev, veEngine, kjpeg);
        return -EINVAL;
    }

    return ve_instance_free(vdev, &veEngine->jpeg, kjpeg , filp, 0);
}

static int ve_ioctl_get_jpeg_info(struct file* filp, struct rpp_dev *pdev, void *data)
{
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct CodecInfo *info = (struct CodecInfo *)data;

    if (!vdev || !veEngine || !info) {
        pr_err("%s, hander isn't avaliable. vdev %p veEngine %p info %p\n",
                __func__, vdev, veEngine, info);
        return -EINVAL;
    }

    info->avali_ins = veEngine->jpeg.avail_ins;
    info->populated = veEngine->jpeg.populated;

    return 0;
}

static int ve_ioctl_get_common_memory(struct file* filp, struct rpp_dev *pdev, void *data)
{
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct Vmem_DmaMemory *common_memory = (struct Vmem_DmaMemory *)data;

    if (!vdev || !veEngine) {
        pr_err(" %s, device isn't avaliable. vdev %p veEngine %p\n", __func__, vdev, veEngine);
        return -EINVAL;
    }

    if(veEngine->common_memory.size) {
        common_memory->size      = veEngine->common_memory.size;
        common_memory->phys_addr = (unsigned long)veEngine->common_memory.phys_addr;
        common_memory->virt_addr = (unsigned long)veEngine->common_memory.virt_addr;
        common_memory->base      = (unsigned long)veEngine->common_memory.base;
        return 0;
    }
    else{
        pr_err("veEngine %p doesn't allocate common memory\n", veEngine);
        return -ENOMEM;
    }
}

static int ve_ioctl_alloc_dma_memory(struct file* filp, struct rpp_dev *pdev, void *data)
{
    unsigned long flags;
    struct vmem_block *vmb;
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct Vmem_DmaMemory *app_vmem = (struct Vmem_DmaMemory *)data;

    if (!vdev || !veEngine) {
        pr_err(" %s, device isn't avaliable. vdev %p veEngine %p\n", __func__, vdev, veEngine);
        return -EINVAL;
    }

    if (veEngine->vmem.mem_size == 0) {
        pr_err("veEngine %p doesn't initial vmem database\n", veEngine);
        return -ENOMEM;
    }

    vmb = kzalloc(sizeof(struct vmem_block), GFP_KERNEL);
    if (!vmb) {
        pr_err("veEngine %p can't allocation vmem block memory\n", veEngine);
        return -ENOMEM;
    }

    mutex_lock(&vdev->vMutex);
    app_vmem->phys_addr = vmem_alloc(&veEngine->vmem, app_vmem->size, 0);
    mutex_unlock(&vdev->vMutex);
    if (app_vmem->phys_addr == (unsigned long)-1) {
        kfree(vmb);
        mutex_unlock(&vdev->vMutex);
        pr_err("veEngine %p not enough memory with request size=%x\n", veEngine, app_vmem->size);
        return -ENOMEM;
    }
    /* update veEngine memory info */
    veEngine->memInfo.alloc_pages = veEngine->vmem.alloc_page_count;
    veEngine->memInfo.free_pages  = veEngine->vmem.free_page_count;

    app_vmem->base      = app_vmem->phys_addr - veEngine->memInfo.ve_mem.phys_addr;
    app_vmem->virt_addr = app_vmem->phys_addr;      /*virtual from physcal*/

    vmb->vmem.phys_addr = app_vmem->phys_addr;
    vmb->vmem.size      = app_vmem->size;
    vmb->vmem.base      = app_vmem->base;
  #ifdef SUPPORT_CUSTOMER_INFO_VMEM
    vmb->vmem.coreIdx   = app_vmem->coreIdx;
    vmb->vmem.instIdx   = app_vmem->instIdx;
  #endif
    vmb->filp           = filp;
    spin_lock_irqsave(&vdev->lock, flags);
    list_add(&vmb->list, &s_vmem_block_head);
    spin_unlock_irqrestore(&vdev->lock, flags);

    return 0;
}

static int ve_ioctl_free_dma_memory(struct file* filp, struct rpp_dev *pdev, void *data)
{
    unsigned long flags;
    struct vmem_block *vmb, *next;
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct Vmem_DmaMemory *app_vmem = (struct Vmem_DmaMemory *)data;

    if (!vdev || !veEngine) {
        pr_err("%s, device isn't avaliable. vdev %p veEngine %p\n", __func__, vdev, veEngine);
        return -EINVAL;
    }

    if (veEngine->vmem.mem_size == 0) {
        pr_err("veEngine %p vmem database closed, can't free vmem %lx\n", veEngine, app_vmem->phys_addr);
        return -ENOMEM;
    }

    if (app_vmem->phys_addr) {
        mutex_lock(&vdev->vMutex);
        vmem_free(&veEngine->vmem, app_vmem->phys_addr, 0);
        mutex_unlock(&vdev->vMutex);
        /* update veEngine memory info */
        veEngine->memInfo.alloc_pages = veEngine->vmem.alloc_page_count;
        veEngine->memInfo.free_pages  = veEngine->vmem.free_page_count;
        spin_lock_irqsave(&vdev->lock, flags);
        list_for_each_entry_safe(vmb, next, &s_vmem_block_head, list)
        {
          if ((vmb->vmem.base      == app_vmem->base)     &&
              (vmb->vmem.phys_addr == app_vmem->phys_addr)&&
              (vmb->vmem.size      == app_vmem->size)     &&
#ifdef SUPPORT_CUSTOMER_INFO_VMEM
              (vmb->vmem.coreIdx   == app_vmem->coreIdx)  &&
              (vmb->vmem.instIdx   == app_vmem->instIdx)  &&
#endif
              (vmb->filp           == filp)) {
              list_del(&vmb->list);
              kfree(vmb);
              break;
          }
        }
        spin_unlock_irqrestore(&vdev->lock, flags);
        return 0;
    }
    else {
        pr_err("illegal vmem address from user\n");
        return -EINVAL;
    }
}

static int ve_ioctl_read_register(struct file* filp, struct rpp_dev *pdev, void *data)
{
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct InstRegRequest *read_req = (struct InstRegRequest *)data;
    uint32_t regOffset;

    if (!vdev || !veEngine) {
        pr_err(" %s, device isn't avaliable. vdev %p veEngine %p\n", __func__, vdev, veEngine);
        return -EINVAL;
    }

    if (read_req->IsCodec) {
        if (read_req->coreIdx >= VE_CODEC_NUM || (read_req->regAddr >= 0x200 && read_req->regAddr != 0x1040 && read_req->regAddr != 0x1044)) {
            pr_err(" %s, invalid codec read param coreIdx %08x regAddr %08x\n", __func__, read_req->coreIdx, read_req->regAddr);
            return -EINVAL;
        }

        regOffset = CodecRegOffset[read_req->coreIdx];
        if(pdev->small_bar) {
            regOffset -= VE_REG_BASE_LARGE_BAR;
        }
        RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+read_req->regAddr, (uint8_t *)&read_req->regData);
    }
    else{
        if (read_req->coreIdx >= VE_JPEG_NUM || read_req->regAddr > 0xc04) {
            pr_err(" %s, invalid codec read param coreIdx %08x regAddr %08x\n", __func__, read_req->coreIdx, read_req->regAddr);
            return -EINVAL;
        }

        regOffset = JpegRegOffset[read_req->coreIdx];
        if(pdev->small_bar) {
            regOffset -= VE_REG_BASE_LARGE_BAR;
        }
        RPP_rw_pci_bar(pdev, VE_BAR, VE_READ, 4, regOffset+read_req->regAddr, (uint8_t *)&read_req->regData);
    }

    return 0;
}

static int ve_ioctl_write_register(struct file* filp, struct rpp_dev *pdev, void *data)
{
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct InstRegRequest *write_req = (struct InstRegRequest *)data;
    uint32_t regOffset;

    if (!vdev || !veEngine) {
        pr_err(" %s, device isn't avaliable. vdev %p veEngine %p\n", __func__, vdev, veEngine);
        return -EINVAL;
    }

    if (write_req->IsCodec) {
        if (write_req->coreIdx >= VE_CODEC_NUM || write_req->regAddr >= 0x200) {
            pr_err(" %s, invalid codec read param coreIdx %08x regAddr %08x\n", __func__, write_req->coreIdx, write_req->regAddr);
            return -EINVAL;
        }

        regOffset = CodecRegOffset[write_req->coreIdx];
        if(pdev->small_bar) {
            regOffset -= VE_REG_BASE_LARGE_BAR;
        }
        RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+write_req->regAddr, (uint8_t *)&write_req->regData);
    }
    else{
        if (write_req->coreIdx >= VE_JPEG_NUM || write_req->regAddr > 0xc04) {
            pr_err(" %s, invalid codec read param coreIdx %08x regAddr %08x\n", __func__, write_req->coreIdx, write_req->regAddr);
            return -EINVAL;
        }

        regOffset = JpegRegOffset[write_req->coreIdx];
        if(pdev->small_bar) {
            regOffset -= VE_REG_BASE_LARGE_BAR;
        }
        RPP_rw_pci_bar(pdev, VE_BAR, VE_WRITE, 4, regOffset+write_req->regAddr, (uint8_t *)&write_req->regData);
    }

    return 0;
}

static int ve_ioctl_get_codec_pool(struct file* filp, struct rpp_dev *pdev, void *data)
{
#ifdef VE_SUPPORT_MULTI_CLIENT
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct InstPool_t *instpoolReq = (struct InstPool_t *)data;

    if (!vdev || !veEngine) {
        pr_err("%s, device isn't avaliable. vdev %p veEngine %p\n", __func__, vdev, veEngine);
        return -EINVAL;
    }

    if (instpoolReq->size == 0 || instpoolReq->sizePMutex <= 0 || instpoolReq->nPMutex <= 0) {
        pr_err("%s, illegal request argument size=%d sizePMutex=%d nPMutex=%d\n", __func__,
                instpoolReq->size, instpoolReq->sizePMutex, instpoolReq->nPMutex);
        return -EINVAL;
    }

    if (veEngine->instance_pool.size == 0) {
        veEngine->instance_pool.size       = instpoolReq->size;
        veEngine->instance_pool.nPMutex    = instpoolReq->nPMutex;
        veEngine->instance_pool.sizePMutex = instpoolReq->sizePMutex;
        veEngine->instance_pool.base = kzalloc(PAGE_ALIGN(veEngine->instance_pool.size), GFP_KERNEL);
        if (veEngine->instance_pool.base == NULL) {
            veEngine->instance_pool.size = 0;
            pr_err("veEngine %p failed to create instance pool buffer\n", veEngine);
            return -ENOMEM;
        }
        veEngine->instance_pool.phys_addr = virt_to_phys(veEngine->instance_pool.base);

        veEngine->memInfo.m_instance_pool_size = instpoolReq->size;
        veEngine->memInfo.m_instance_pool_addr = INSTANCE_POOL_MAP_ADDR_START;
    }

    if(veEngine->instance_pool.size != instpoolReq->size) {
        pr_warn("try to reallocate the instance pool memory, refused! old size=%x, new size=%x\n",
                 veEngine->instance_pool.size, instpoolReq->size);
        instpoolReq->size = veEngine->instance_pool.size;
    }

    instpoolReq->phys_addr = (unsigned long)veEngine->instance_pool.phys_addr;
    instpoolReq->base      = (unsigned long)veEngine->instance_pool.base;

    pr_info("veEngine %p instance pool size=%d, pthread mutex size=%d pthread mutex num=%d phys_addr:%llx kernel addr:%llx\n",
            veEngine, veEngine->instance_pool.size, veEngine->instance_pool.sizePMutex, veEngine->instance_pool.nPMutex,
            veEngine->instance_pool.phys_addr, veEngine->instance_pool.base);
#endif
    return 0;
}

static int ve_ioctl_get_jpeg_pool(struct file* filp, struct rpp_dev *pdev, void *data)
{
#ifdef VE_SUPPORT_MULTI_CLIENT
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct InstPool_t *instpoolReq = (struct InstPool_t *)data;

    if (!vdev || !veEngine) {
        pr_err("%s, device isn't avaliable. vdev %p veEngine %p\n", __func__, vdev, veEngine);
        return -EINVAL;
    }

    if (instpoolReq->size == 0 || instpoolReq->sizePMutex <= 0 || instpoolReq->nPMutex <= 0) {
        pr_err("%s, illegal request argument size=%d sizePMutex=%d nPMutex=%d\n", __func__,
                instpoolReq->size, instpoolReq->sizePMutex, instpoolReq->nPMutex);
        return -EINVAL;
    }

    if (veEngine->jpeg_pool.size == 0) {
        veEngine->jpeg_pool.size       = instpoolReq->size;
        veEngine->jpeg_pool.nPMutex    = instpoolReq->nPMutex;
        veEngine->jpeg_pool.sizePMutex = instpoolReq->sizePMutex;
        veEngine->jpeg_pool.base = kzalloc(PAGE_ALIGN(veEngine->jpeg_pool.size), GFP_KERNEL);
        if (veEngine->jpeg_pool.base == NULL) {
            veEngine->jpeg_pool.size = 0;
            pr_err("veEngine %p failed to create jpeg pool buffer\n", veEngine);
            return -ENOMEM;
        }
        veEngine->jpeg_pool.phys_addr = virt_to_phys(veEngine->jpeg_pool.base);

        veEngine->memInfo.m_jpeg_pool_size = instpoolReq->size;
        veEngine->memInfo.m_jpeg_pool_addr = JPEG_POOL_MAP_ADDR_START;
    }

    if(veEngine->jpeg_pool.size != instpoolReq->size) {
        pr_warn("try to reallocate the jpeg pool memory, refused! old size=%x, new size=%x\n",
                 veEngine->jpeg_pool.size, instpoolReq->size);
        instpoolReq->size = veEngine->jpeg_pool.size;
    }

    instpoolReq->phys_addr = (unsigned long)veEngine->jpeg_pool.phys_addr;
    instpoolReq->base      = (unsigned long)veEngine->jpeg_pool.base;

    pr_info("veEngine %p jpeg pool size=%d, pthread mutex size=%d pthread mutex num=%d phys_addr:%llx kernel addr:%llx\n",
            veEngine, veEngine->jpeg_pool.size, veEngine->jpeg_pool.sizePMutex, veEngine->jpeg_pool.nPMutex,
            veEngine->jpeg_pool.phys_addr, veEngine->jpeg_pool.base);
#endif
    return 0;
}

static int ve_ioctl_read_vpuinfo(struct file* filp, struct rpp_dev *pdev, void *data)
{
    unsigned long flags;
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct VpuInfoRequest *read_req = (struct VpuInfoRequest *)data;

    if (!vdev || !veEngine) {
        pr_err(" %s, device isn't avaliable. vdev %p veEngine %p\n", __func__, vdev, veEngine);
        return -EINVAL;
    }

    if (read_req->coreIdx >= VE_CODEC_NUM) {
        pr_err(" %s, invalid vpu core index[%d]\n", __func__, read_req->coreIdx);
        return -EINVAL;
    }

    spin_lock_irqsave(&vdev->lock, flags);
    read_req->vpuInfo = (veEngine->vpu_info >> (8*read_req->coreIdx)) & 0xff;
    spin_unlock_irqrestore(&vdev->lock, flags);

    return 0;
}

static int ve_ioctl_write_vpuinfo(struct file* filp, struct rpp_dev *pdev, void *data)
{
    unsigned long flags;
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct VpuInfoRequest *write_req = (struct VpuInfoRequest *)data;

    if (!vdev || !veEngine) {
        pr_err(" %s, device isn't avaliable. vdev %p veEngine %p\n", __func__, vdev, veEngine);
        return -EINVAL;
    }

    if (write_req->coreIdx >= VE_CODEC_NUM) {
        pr_err(" %s, invalid vpu core index[%d]\n", __func__, write_req->coreIdx);
        return -EINVAL;
    }

    spin_lock_irqsave(&vdev->lock, flags);
    veEngine->vpu_info |= write_req->vpuInfo << (8*write_req->coreIdx);
    spin_unlock_irqrestore(&vdev->lock, flags);
    pr_info("veEngine %p update core index %08x error status %08x\n", veEngine, write_req->coreIdx, veEngine->vpu_info);

    if (vdev->async_queue)
        kill_fasync(&vdev->async_queue, SIGIO, POLL_IN); /* notify the vpu info to user space */
    return 0;
}

/* VE state flag use for codec info check, example workload heavely or other state.
 * external ioctl with new state to update state flag, such as rpp server set workloading heavly
 * while rpp module workloading heavely
*/
static int ve_ioctl_write_stateflag(struct file* filp, struct rpp_dev *pdev, void *data)
{
    unsigned long flags;
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    int8_t state_flag = *(int8_t *)data;

    if (!vdev || !veEngine) {
        pr_err(" %s, device isn't avaliable. vdev %p veEngine %p\n", __func__, vdev, veEngine);
        return -EINVAL;
    }

    spin_lock_irqsave(&vdev->lock, flags);
    veEngine->state_flag = state_flag;
    spin_unlock_irqrestore(&vdev->lock, flags);

    return 0;
}

/* coreIdx crash state read and write by app to support crash repaire.
 *
*/
static int ve_ioctl_get_crash_state(struct file* filp, struct rpp_dev *pdev, void *data)
{
    unsigned long flags;
    int instance_pool_size_per_core;
    struct ve_instance_pool_t *vip;
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct VpuCrashReqest *read_req = (struct VpuCrashReqest *)data;

    if (!vdev || !veEngine) {
        pr_err(" %s, device isn't avaliable. vdev %p veEngine %p\n", __func__, vdev, veEngine);
        return -EINVAL;
    }

    if (read_req->coreIdx > VE_CODEC_NUM) {
        pr_err(" %s, invalid vpu core index[%d]\n", __func__, read_req->coreIdx);
    }

#ifdef SUPPORT_CRASH_REPAIRED
    if (veEngine->instance_pool.size == 0) {
        pr_err(" %s, veEngine %p instance pool isn't avaliable, \n", __func__, veEngine);
        return -EINVAL;
    }
    instance_pool_size_per_core = (veEngine->instance_pool.size/VE_CODEC_NUM);
    vip = (struct ve_instance_pool_t *)((unsigned char *)veEngine->instance_pool.base + instance_pool_size_per_core*read_req->coreIdx);

    spin_lock_irqsave(&vdev->lock, flags);
    read_req->state = vip->crash_state;
    spin_unlock_irqrestore(&vdev->lock, flags);
    return 0;
#else
    return -EINVAL;
#endif
}

static int ve_ioctl_set_crash_state(struct file* filp, struct rpp_dev *pdev, void *data)
{
    int instance_pool_size_per_core;
    struct ve_instance_pool_t *vip;
    struct rpp_vdev *vdev = &pdev->entire_ctrl_vdev;
    struct VideoEngine *veEngine = (struct VideoEngine *)vdev->veEngine;
    struct VpuCrashReqest *write_req = (struct VpuCrashReqest *)data;

    if (!vdev || !veEngine) {
        pr_err(" %s, device isn't avaliable. vdev %p veEngine %p\n", __func__, vdev, veEngine);
        return -EINVAL;
    }

    if (write_req->coreIdx > VE_CODEC_NUM) {
        pr_err(" %s, invalid vpu core index[%d]\n", __func__, write_req->coreIdx);
    }

#ifdef SUPPORT_CRASH_REPAIRED
    unsigned long flags;

    if (veEngine->instance_pool.size == 0) {
        pr_err(" %s, veEngine %p instance pool isn't avaliable, \n", __func__, veEngine);
        return -EINVAL;
    }
    instance_pool_size_per_core = (veEngine->instance_pool.size/VE_CODEC_NUM);
    vip = (struct ve_instance_pool_t *)((unsigned char *)veEngine->instance_pool.base + instance_pool_size_per_core*write_req->coreIdx);

    spin_lock_irqsave(&vdev->lock, flags);
    vip->crash_state = write_req->state;
    spin_unlock_irqrestore(&vdev->lock, flags);
    return 0;
#else
    return -EINVAL;
#endif
}


#define VE_IOCTL_DEF(ioctl, _func) \
    [_IOC_NR(ioctl)] = {.cmd = ioctl, .func = _func, \
            .cmd_drv = 0, .name = #ioctl}

struct ve_ioctl_desc ve_ioctls[] = {
    VE_IOCTL_DEF(VE_IOCTL_GET_MEMINFO,          ve_ioctl_get_mem_info),
    VE_IOCTL_DEF(VE_IOCTL_ALLOC_DMA_BUF,        ve_ioctl_alloc_dma_buf),
    VE_IOCTL_DEF(VE_IOCTL_FREE_DMA_BUF,         ve_ioctl_free_dma_buf),
    VE_IOCTL_DEF(VE_IOCTL_WRITE_DMA_BUF,        ve_ioctl_write_dma_buf),
    VE_IOCTL_DEF(VE_IOCTL_READ_DMA_BUF,         ve_ioctl_read_dma_buf),
    VE_IOCTL_DEF(VE_IOCTL_ALLOC_CODEC,          ve_ioctl_alloc_codec),
    VE_IOCTL_DEF(VE_IOCTL_FREE_CODEC,           ve_ioctl_free_codec),
    VE_IOCTL_DEF(VE_IOCTL_GET_CODECINFO,        ve_ioctl_get_codec_info),
    VE_IOCTL_DEF(VE_IOCTL_ALLOC_JPEG,           ve_ioctl_alloc_jpeg),
    VE_IOCTL_DEF(VE_IOCTL_FREE_JPEG,            ve_ioctl_free_jpeg),
    VE_IOCTL_DEF(VE_IOCTL_GET_JPEGINFO,         ve_ioctl_get_jpeg_info),
    VE_IOCTL_DEF(VE_IOCTL_WRITE_USER_BUF,       ve_ioctl_write_user_buf),
    VE_IOCTL_DEF(VE_IOCTL_READ_USER_BUF,        ve_ioctl_read_user_buf),
    VE_IOCTL_DEF(VE_IOCTL_GET_CODEC_INTR,       ve_ioctl_get_codec_intr),
    VE_IOCTL_DEF(VE_IOCTL_GET_JPEG_INTR,        ve_ioctl_get_jpeg_intr),
    VE_IOCTL_DEF(VE_IOCTL_ALLOC_INST,           ve_ioctl_alloc_inst),
    VE_IOCTL_DEF(VE_IOCTL_FREE_INST,            ve_ioctl_free_inst),
    VE_IOCTL_DEF(VE_IOCTL_GET_COMMON_MEMORY,    ve_ioctl_get_common_memory),
    VE_IOCTL_DEF(VE_IOCTL_ALLOC_DMA_MEMORY,     ve_ioctl_alloc_dma_memory),
    VE_IOCTL_DEF(VE_IOCTL_FREE_DMA_MEMORY,      ve_ioctl_free_dma_memory),
    VE_IOCTL_DEF(VE_IOCTL_GET_CODEC_POOL,       ve_ioctl_get_codec_pool),
    VE_IOCTL_DEF(VE_IOCTL_READ_REG,             ve_ioctl_read_register),
    VE_IOCTL_DEF(VE_IOCTL_WRITE_REG,            ve_ioctl_write_register),
    VE_IOCTL_DEF(VE_IOCTL_READ_VPU_INFO,        ve_ioctl_read_vpuinfo),
    VE_IOCTL_DEF(VE_IOCTL_WRITE_VPU_INFO,       ve_ioctl_write_vpuinfo),
    VE_IOCTL_DEF(VE_IOCTL_WRITE_STATE_FLAG,     ve_ioctl_write_stateflag),
    VE_IOCTL_DEF(VE_IOCTL_GET_JPEG_POOL,        ve_ioctl_get_jpeg_pool),
    VE_IOCTL_DEF(VE_IOCTL_GET_CRASH_STATE,      ve_ioctl_get_crash_state),
    VE_IOCTL_DEF(VE_IOCTL_SET_CRASH_STATE,      ve_ioctl_set_crash_state),
    VE_IOCTL_DEF(VE_IOCTL_VPU_VDI_PARAM,        ve_ioctl_load_vdi_param),
};

#define VE_IOCTL_COUNT  ARRAY_SIZE(ve_ioctls)

/*
 * character device file operations for control bus (through control bridge)
 */
static ssize_t ve_entire_ctrl_read(struct file *file, char __user *buf, size_t count, loff_t *pos)
{
    struct rpp_vdev *xvdev = (struct rpp_vdev *)file->private_data;
    struct rpp_dev *xdev;
    u32 w;
    int rv;

    rv = xvdev_check(__func__, xvdev, 0);
    if (rv < 0)
        return rv;
    xdev = (struct rpp_dev *)xvdev->prppdev;

    /* only 32-bit aligned and 32-bit multiples */
    if (*pos & 3)
        return -EPROTO;
    /* first address is BAR base plus file position offset */
    w = rpp_io_read32(xdev, *pos);
    pr_info("char_ctrl_read(count=%ld, pos=%d) value = 0x%08x\n", (long)count, (int)*pos, w);
    rv = copy_to_user(buf, &w, 4);
    if (rv)
        pr_err("Copy to userspace failed but continuing\n");

    *pos += 4;
    return 4;
}

static ssize_t ve_entire_ctrl_write(struct file *file, const char __user *buf,size_t count, loff_t *pos)
{
    struct rpp_vdev *xvdev = (struct rpp_vdev *)file->private_data;
    struct rpp_dev *xdev;
    u32 w;
    int rv;

    rv = xvdev_check(__func__, xvdev, 0);
    if (rv < 0)
        return rv;
    xdev = (struct rpp_dev *)xvdev->prppdev;

    /* only 32-bit aligned and 32-bit multiples */
    if (*pos & 3)
        return -EPROTO;

    /* first address is BAR base plus file position offset */
    rv = copy_from_user(&w, buf, 4);
    if (rv) {
        pr_err("copy from user failed %d/4, but continuing.\n", rv);
    }

    pr_info("char_ctrl_write(0x%08x count=%ld, pos=%d)\n", w, (long)count, (int)*pos);
    rpp_io_write32(xdev, w, *pos);
    *pos += 4;
    return 4;
}

/*
 * character device file operations for SG DMA engine
 */
static loff_t ve_entire_ctrl_llseek(struct file *file, loff_t off, int whence)
{
    return 0;
}

static int ve_entire_bridge_mmap(struct file *filp, struct vm_area_struct *vma)
{
    struct rpp_vdev *xvdev = (struct rpp_vdev *)filp->private_data;
    struct VideoEngine *veEngine = (struct VideoEngine *)xvdev->veEngine;
    struct rpp_dev *xdev;
    int rv = 0;

    rv = xvdev_check(__func__, xvdev, 0);
    if (rv < 0) return rv;

    xdev = (struct rpp_dev *)xvdev->prppdev;

    pr_debug("vma->vm_pgoff 0x%lx vm_start 0x%llx, vm_end 0x%llx\n", vma->vm_pgoff, vma->vm_start, vma->vm_end);

    /* remap dma buffer to user space */
    if (vma->vm_pgoff * PAGE_SIZE < DMA_BUFFER_MAP_ADDR_END) {
  #if defined(__arm__) || defined(__aarch64__)
        rv = dma_mmap_attrs(&xdev->pdev->dev, vma, veEngine->dma, veEngine->dma_handle,
                            (vma->vm_start-vma->vm_end), DMA_ATTR_WRITE_COMBINE);
  #else
        rv = dma_mmap_coherent(&xdev->pdev->dev, vma, veEngine->dma, veEngine->dma_handle,
                                (vma->vm_start-vma->vm_end));
    /* below can't compatiable linux kernel version 8.0 or above
        vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
        rv = remap_pfn_range(vma, vma->vm_start, virt_to_phys(veEngine->dma)>>PAGE_SHIFT,
                             (vma->vm_end-vma->vm_start), vma->vm_page_prot);
    */
  #endif
        if (rv < 0) {
            pr_err("could not map the dma address area\n");
            return -EIO;
        }
        return 0;

#ifdef VE_FRAME_BUFFER_CACHE
    }else if (vma->vm_pgoff * PAGE_SIZE >= WUSR0_BUFFER_MAP_ADDR_START  &&
              vma->vm_pgoff * PAGE_SIZE < WUSR0_BUFFER_MAP_ADDR_END) {
  #if defined(__arm__) || defined(__aarch64__)
        rv = dma_mmap_attrs(&xdev->pdev->dev, vma, veEngine->dma_user[0].dma_wuser, veEngine->dma_user[0].dma_wuser_handle,
                            (vma->vm_start-vma->vm_end), DMA_ATTR_WRITE_COMBINE);
  #else
        vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
        rv = remap_pfn_range(vma, vma->vm_start,  virt_to_phys(veEngine->dma_user[0].dma_wuser)>>PAGE_SHIFT,
                             (vma->vm_end-vma->vm_start), vma->vm_page_prot);
  #endif
        if (rv < 0) {
            pr_err("could not map the wuser for coreIdx 0 dma address area\n");
            return -EIO;
        }
        return 0;

    }else if (vma->vm_pgoff * PAGE_SIZE >= RUSR0_BUFFER_MAP_ADDR_START  &&
              vma->vm_pgoff * PAGE_SIZE < RUSR0_BUFFER_MAP_ADDR_END) {
        vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
#if defined(__arm__) || defined(__aarch64__)
        rv = dma_mmap_attrs(&xdev->pdev->dev, vma, veEngine->dma_user[0].dma_ruser, veEngine->dma_user[0].dma_ruser_handle,
                            (vma->vm_start-vma->vm_end), DMA_ATTR_WRITE_COMBINE);
#else
        rv = remap_pfn_range(vma, vma->vm_start,  virt_to_phys(veEngine->dma_user[0].dma_ruser)>>PAGE_SHIFT,
                             (vma->vm_end-vma->vm_start), vma->vm_page_prot);
  #endif
        if (rv < 0) {
            pr_err("could not map the ruser for coreIdx 0 dma address area\n");
            return -EIO;
        }
        return 0;

    }else if (vma->vm_pgoff * PAGE_SIZE >= WUSR1_BUFFER_MAP_ADDR_START  &&
              vma->vm_pgoff * PAGE_SIZE < WUSR1_BUFFER_MAP_ADDR_END) {
  #if defined(__arm__) || defined(__aarch64__)
        rv = dma_mmap_attrs(&xdev->pdev->dev, vma, veEngine->dma_user[1].dma_wuser, veEngine->dma_user[1].dma_wuser_handle,
                            (vma->vm_start-vma->vm_end), DMA_ATTR_WRITE_COMBINE);
  #else
        vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
        rv = remap_pfn_range(vma, vma->vm_start,  virt_to_phys(veEngine->dma_user[1].dma_wuser)>>PAGE_SHIFT,
                             (vma->vm_end-vma->vm_start), vma->vm_page_prot);
  #endif
        if (rv < 0) {
            pr_err("could not map the wuser for coreIdx 1 dma address area\n");
            return -EIO;
        }
        return 0;

    }else if (vma->vm_pgoff * PAGE_SIZE >= RUSR1_BUFFER_MAP_ADDR_START  &&
              vma->vm_pgoff * PAGE_SIZE < RUSR1_BUFFER_MAP_ADDR_END) {
  #if defined(__arm__) || defined(__aarch64__)
        rv = dma_mmap_attrs(&xdev->pdev->dev, vma, veEngine->dma_user[1].dma_ruser, veEngine->dma_user[1].dma_ruser_handle,
                            (vma->vm_start-vma->vm_end), DMA_ATTR_WRITE_COMBINE);
  #else
        vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
        rv = remap_pfn_range(vma, vma->vm_start, virt_to_phys(veEngine->dma_user[1].dma_ruser)>>PAGE_SHIFT,
                             (vma->vm_end-vma->vm_start), vma->vm_page_prot);
  #endif
        if (rv < 0) {
            pr_err("could not map the ruser for coreIdx 1 dma address area\n");
            return -EIO;
        }
        return 0;

    }else if (vma->vm_pgoff * PAGE_SIZE >= WUSR2_BUFFER_MAP_ADDR_START  &&
              vma->vm_pgoff * PAGE_SIZE < WUSR2_BUFFER_MAP_ADDR_END) {
  #if defined(__arm__) || defined(__aarch64__)
        rv = dma_mmap_attrs(&xdev->pdev->dev, vma, veEngine->dma_user[2].dma_wuser, veEngine->dma_user[2].dma_wuser_handle,
                            (vma->vm_start-vma->vm_end), DMA_ATTR_WRITE_COMBINE);
  #else
        vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
        rv = remap_pfn_range(vma, vma->vm_start, virt_to_phys(veEngine->dma_user[2].dma_wuser)>>PAGE_SHIFT,
                             (vma->vm_end-vma->vm_start), vma->vm_page_prot);
  #endif
        if (rv < 0) {
            pr_err("could not map the wuser for coreIdx 2 dma address area\n");
            return -EIO;
        }
        return 0;

    }else if (vma->vm_pgoff * PAGE_SIZE >= RUSR2_BUFFER_MAP_ADDR_START  &&
              vma->vm_pgoff * PAGE_SIZE < RUSR2_BUFFER_MAP_ADDR_END) {
  #if defined(__arm__) || defined(__aarch64__)
        rv = dma_mmap_attrs(&xdev->pdev->dev, vma, veEngine->dma_user[2].dma_ruser, veEngine->dma_user[2].dma_ruser_handle,
                            (vma->vm_start-vma->vm_end), DMA_ATTR_WRITE_COMBINE);
  #else
        vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
        rv = remap_pfn_range(vma, vma->vm_start, virt_to_phys(veEngine->dma_user[2].dma_ruser)>>PAGE_SHIFT,
                             (vma->vm_end-vma->vm_start), vma->vm_page_prot);
  #endif
        if (rv < 0) {
            pr_err("could not map the ruser for coreIdx 2 dma address area\n");
            return -EIO;
        }
        return 0;

    }else if (vma->vm_pgoff * PAGE_SIZE >= WUSR3_BUFFER_MAP_ADDR_START  &&
              vma->vm_pgoff * PAGE_SIZE < WUSR3_BUFFER_MAP_ADDR_END) {
  #if defined(__arm__) || defined(__aarch64__)
        rv = dma_mmap_attrs(&xdev->pdev->dev, vma, veEngine->dma_user[3].dma_wuser, veEngine->dma_user[3].dma_wuser_handle,
                            (vma->vm_start-vma->vm_end), DMA_ATTR_WRITE_COMBINE);
  #else
        vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
        rv = remap_pfn_range(vma, vma->vm_start, virt_to_phys(veEngine->dma_user[3].dma_wuser)>>PAGE_SHIFT,
                             (vma->vm_end-vma->vm_start), vma->vm_page_prot);
  #endif
        if (rv < 0) {
            pr_err("could not map the wuser for coreIdx 3 dma address area\n");
            return -EIO;
        }
        return 0;

    }else if (vma->vm_pgoff * PAGE_SIZE >= RUSR3_BUFFER_MAP_ADDR_START  &&
              vma->vm_pgoff * PAGE_SIZE < RUSR3_BUFFER_MAP_ADDR_END) {
  #if defined(__arm__) || defined(__aarch64__)
        rv = dma_mmap_attrs(&xdev->pdev->dev, vma, veEngine->dma_user[3].dma_ruser, veEngine->dma_user[3].dma_ruser_handle,
                            (vma->vm_start-vma->vm_end), DMA_ATTR_WRITE_COMBINE);
  #else
        vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
        rv = remap_pfn_range(vma, vma->vm_start,  virt_to_phys(veEngine->dma_user[3].dma_ruser)>>PAGE_SHIFT,
                             (vma->vm_end-vma->vm_start), vma->vm_page_prot);
  #endif
        if (rv < 0) {
            pr_err("could not map the ruser for coreIdx 3 dma address area\n");
            return -EIO;
        }
        return 0;
#endif

#ifdef VE_SUPPORT_MULTI_CLIENT
    }else if (vma->vm_pgoff * PAGE_SIZE >= INSTANCE_POOL_MAP_ADDR_START  &&
              vma->vm_pgoff * PAGE_SIZE < INSTANCE_POOL_MAP_ADDR_END) {
  #if defined(__arm__) || defined(__aarch64__)
        vma->vm_page_prot = PAGE_SHARED;
  #else
        vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
  #endif

  #if LINUX_VERSION_CODE < KERNEL_VERSION(3,7,0)
        vma->vm_flags |= (VM_DONTEXPAND);
  #else
    #if LINUX_VERSION_CODE < KERNEL_VERSION(6,3,0)
        vma->vm_flags |= (VM_DONTEXPAND | VM_DONTDUMP);
    #else
        vm_flags_set(vma, VM_DONTEXPAND | VM_DONTDUMP);
    #endif
  #endif

        rv = remap_pfn_range(vma, vma->vm_start, virt_to_phys(veEngine->instance_pool.base)>>PAGE_SHIFT,
                             (vma->vm_end-vma->vm_start), vma->vm_page_prot);
        if (rv < 0) {
            pr_err("could not map the ve instance address area\n");
            return -EIO;
        }
        return 0;

  }else if (vma->vm_pgoff * PAGE_SIZE >= JPEG_POOL_MAP_ADDR_START  &&
            vma->vm_pgoff * PAGE_SIZE < JPEG_POOL_MAP_ADDR_END) {
  #if defined(__arm__) || defined(__aarch64__)
        vma->vm_page_prot = PAGE_SHARED;
  #else
        vma->vm_page_prot = pgprot_noncached(vma->vm_page_prot);
  #endif
  #if LINUX_VERSION_CODE < KERNEL_VERSION(3,7,0)
        vma->vm_flags |= (VM_DONTEXPAND);
  #else
    #if LINUX_VERSION_CODE < KERNEL_VERSION(6,3,0)
        vma->vm_flags |= (VM_DONTEXPAND | VM_DONTDUMP);
    #else
        vm_flags_set(vma, VM_DONTEXPAND | VM_DONTDUMP);
    #endif
  #endif
      rv = remap_pfn_range(vma, vma->vm_start, virt_to_phys(veEngine->jpeg_pool.base)>>PAGE_SHIFT,
                           (vma->vm_end-vma->vm_start), vma->vm_page_prot);
      if (rv < 0) {
          pr_err("could not map the ve jpeg instance address area\n");
          return -EIO;
      }
      return 0;

#endif

    } else {
        /*  remap pci bar 0/2/4 */
        if (xdev->small_bar) {
#ifdef VPU_HAL_MPU
            /* remap bar0 0x0 ~ 0x800 0000 (128M) */
            if (vma->vm_pgoff * PAGE_SIZE >= VPU_RPC_MEMORY_START &&
                vma->vm_pgoff * PAGE_SIZE < VPU_RPC_MEMORY_END) {
                return rpp_remap(xdev, 0, vma);
            }else
#endif
            /* remap bar2 0x10 00000000 ~ 0x10 10000000 (cfg) space */
            /*  small bar */
            if (vma->vm_pgoff * PAGE_SIZE >= BAR2_MAP_OFFSET_SMALL_BAR &&
                vma->vm_pgoff * PAGE_SIZE < (BAR2_MAP_OFFSET_SMALL_BAR + xdev->bar_len[2])) {
                /*  0x10 02000000 ~ 0x10 02200000, bar 2 */
                return rpp_remap(xdev, 2, vma);
            } else {
                return 0;
            }
        } else {
#ifdef VPU_HAL_MPU
            /* remap bar0 0x0 ~ 0x2000 0000 (512M) */
            if (vma->vm_pgoff * PAGE_SIZE >= VPU_RPC_MEMORY_START &&
                vma->vm_pgoff * PAGE_SIZE < VPU_RPC_MEMORY_END) {
                return rpp_remap(xdev, 0, vma);
            }else
#endif
            /* remap bar2 0x10 00000000 ~ 0x10 10000000 (cfg) space */
            /*  large bar */
            if (vma->vm_pgoff * PAGE_SIZE >= BAR2_MAP_OFFSET_LARGE_BAR &&
                vma->vm_pgoff * PAGE_SIZE < (BAR2_MAP_OFFSET_LARGE_BAR + xdev->bar_len[2])) {
                /*  0x10 00000000 ~ 0x10 08000000, bar 2 */
                return rpp_remap(xdev, 2, vma);
            } else {
                return 0;
            }
        }
    }
}

/**
 * drm_ioctl - ioctl callback implementation for DRM drivers
 * @filp: file this ioctl is called on
 * @cmd: ioctl cmd number
 * @arg: user argument
 *
 * Looks up the ioctl function in the DRM core and the driver dispatch table,
 * stored in &drm_driver.ioctls. It checks for necessary permission by calling
 * drm_ioctl_permit(), and dispatches to the respective function.
 *
 * Returns:
 * Zero on success, negative error code on failure.
 */
static long ve_entire_ctrl_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
    struct rpp_vdev *xvdev = (struct rpp_vdev *)filp->private_data;
    struct rpp_dev *xdev;
    const struct ve_ioctl_desc *ioctl = NULL;
    ve_ioctl_t *func;
    unsigned int nr = VE_IOCTL_NR(cmd);
    int retcode = -EINVAL;
    char stack_kdata[128];
    char *kdata = NULL;
    unsigned int in_size, out_size, ksize;
    int rv = 0;

    rv = xvdev_check(__func__, xvdev, 0);
    if (rv < 0)
    return rv;
    xdev = (struct rpp_dev *)xvdev->prppdev;

    if (nr >= VE_IOCTL_COUNT)
        goto err_i1;
    ioctl = &ve_ioctls[nr];

    rv = down_interruptible(&xvdev->sem);
    if (rv) {
        pr_err("%s, interrupted ret=%d\n", __func__, rv);
        retcode = rv;
        goto err_i1;  /* Interrupted */
    }

    out_size = in_size = _IOC_SIZE(cmd);
    if ((cmd & IOC_IN) == 0)
        in_size = 0;
    if ((cmd & IOC_OUT) == 0)
        out_size = 0;
    ksize = max(in_size, out_size);

    /*
    pr_err("cmd 0x%x, arg 0x%lx, nr 0x%x, ksize 0x%x, pid=%d, ioctl_name %s\n",
              cmd, arg, nr, ksize, task_pid_nr(current), ioctl->name);
    */

    /* Do not trust userspace, use our own definition */
    func = ioctl->func;

    if (unlikely(!func)) {
        pr_err("no function\n");
        retcode = -EINVAL;
        goto err_i1;
    }

    if (ksize <= sizeof(stack_kdata)) {
        kdata = stack_kdata;
    } else {
        kdata = kmalloc(ksize, GFP_KERNEL);
        if (!kdata) {
            retcode = -ENOMEM;
            goto err_i1;
        }
    }

    if (copy_from_user(kdata, (void __user *)arg, in_size) != 0) {
        retcode = -EFAULT;
        goto err_i1;
    }

    if (ksize > in_size)
        memset(kdata + in_size, 0, ksize - in_size);

    retcode = func(filp, xdev, kdata);
    if (copy_to_user((void __user *)arg, kdata, out_size) != 0)
        retcode = -EFAULT;

err_i1:
    if (!ioctl)
        pr_err("%s, invalid ioctl: pid=%d, cmd=0x%02x, nr=0x%02x\n", __func__, task_pid_nr(current), cmd, nr);

    if (kdata != stack_kdata)
        kfree(kdata);

    up(&xvdev->sem);
    return retcode;
}

static int ve_entire_ctrl_open(struct inode *inode, struct file *file)
{
    struct rpp_vdev *xvdev;
    struct rpp_dev *xdev;
    struct VideoEngine *veEngine;
#ifdef SUPPORT_CRASH_REPAIRED
    int ret, index;
    uint32_t vpuData;
#endif
    unsigned long flags;
    int bOpenEnable = 0;
    int rv;

    /* pointer to containing structure of the character device inode */
    xvdev = container_of(inode->i_cdev, struct rpp_vdev, vdev);
    xdev = (struct rpp_dev *)xvdev->prppdev;
    BUG_ON(!xdev);

    rv = rpp_idle_low_power_get(xdev, "ve_entire_ctrl_open");
    if (rv != 0)
        return rv;

    veEngine = (struct VideoEngine *)xvdev->veEngine;
#ifdef SUPPORT_MULTI_OPEN_CLOSE
    spin_lock_irqsave(&xvdev->lock, flags);
#endif
#ifdef VE_SUPPORT_MULTI_CLIENT
    /* check the resource recycle status */
    if (veEngine->avali_dma <= 0) {
        bOpenEnable |= 0x01;
        pr_info("[VE_DRV] veEngine %p dma buffers emptied\n", veEngine);
    }

    if (veEngine->codec.avail_ins <= 0) {
        bOpenEnable |= 0x02;
        pr_info("[VE_DRV] veEngine %p codecs emptied\n", veEngine);
    }

    if (veEngine->jpeg.avail_ins <= 0) {
        bOpenEnable |= 0x04;
        pr_info("[VE_DRV] veEngine %p jpegs emptied\n", veEngine);
    }

    if(bOpenEnable == 0x07) {
  #ifdef SUPPORT_MULTI_OPEN_CLOSE
        spin_unlock_irqrestore(&xvdev->lock, flags);
  #endif
        pr_info("[VE_DRV] veEngine %p insufficence source for user\n", veEngine);
        rpp_idle_low_power_put(xdev, "ve_entire_ctrl_open_fail");
        return -1;
    }

    if (xvdev->bInit == 0) {
        /* config the ve memory segment when normal bar configuration */
        xvdev->bInit = 1;
        if (!xdev->small_bar) {
            ve_mem_config_init(xvdev, xvdev->veEngine);
        }
    }

    /* create a reference to ve char device in the opened file */
    file->private_data = xvdev;

    xvdev->nCount++;
    pr_info("[VE_DRV] veEngine %p open with %dth client[%p]\n", veEngine, xvdev->nCount, file);

  #ifdef SUPPORT_MULTI_OPEN_CLOSE
    spin_unlock_irqrestore(&xvdev->lock, flags);
  #endif

  #ifdef SUPPORT_CRASH_REPAIRED
    for (index=0; index<VE_CODEC_NUM; index++) {
        if ((veEngine->vpu_info >> 8*index) & 0xFF) {
            pr_info("[VE_REPAIRED] coreIdx %d found hardware issue\n", index);
            if (veEngine->codec.codecs[index].ref == 0) {
                pr_debug("[VE_REPAIRED] coreIdx %d doesn't has any instance, try to repared\n", index);
                ret = ve_hotReset(xdev, index);
                if (ret == 0) {
                    vpuData = ~(0xFF << 8*index);
                    veEngine->vpu_info &= vpuData;
                    pr_info("[VE_REPAIRED] coreIdx %d repared success\n", index);
                }
            }
        }
    }
  #endif

    return 0;

#else
    if (veEngine->avali_dma != DMA_POOL_SIZE) {
        pr_info("[VE_DRV] veEngine %p dma buffers don't full recycle, only %d back\n", veEngine, veEngine->avali_dma);
        bOpenEnable |= 0x01;
    }

    if (veEngine->codec.avail_ins != ((veEngine->codec.codec_max - veEngine->codec.codec_min)*veEngine->codec.ins_max)) {
        pr_info("[VE_DRV] veEngine %p codecs don't full recycle, only %d back\n", veEngine, veEngine->codec.avail_ins);
        bOpenEnable |= 0x02;
    }

    if (veEngine->jpeg.avail_ins != ((veEngine->jpeg.codec_max - veEngine->jpeg.codec_min)*veEngine->jpeg.ins_max)) {
        pr_info("[VE_DRV] veEngine %p jpegs don't full recycle, only %d back\n", veEngine, veEngine->jpeg.avail_ins);
        bOpenEnable |= 0x04;
    }

    if(bOpenEnable != 0) {
        pr_info("[VE_DRV] veEngine %p insufficence source, can't open for new client %p\n", veEngine, file);
  #ifdef SUPPORT_MULTI_OPEN_CLOSE
        spin_unlock_irqrestore(&xvdev->lock, flags);
  #endif
        rpp_idle_low_power_put(xdev, "ve_entire_ctrl_open_fail");
        return -1;
    }

    /* create a reference to our char device in the opened file */
    file->private_data = xvdev;
    /*config the ve memory segment*/
    if (xvdev->bInit == 0) {
        xvdev->bInit = 1;
        if (!xdev->small_bar) {
            ve_mem_config_init(xvdev, xvdev->veEngine);
        }
    }

  #ifdef SUPPORT_MULTI_OPEN_CLOSE
    spin_unlock_irqrestore(&xvdev->lock, flags);
  #endif

  #ifdef SUPPORT_CRASH_REPAIRED
    for (index=0; index<VE_CODEC_NUM; index++) {
      if ((veEngine->vpu_info >> 8*index) & 0xFF) {
          pr_info("[VE_REPAIRED] coreIdx %d found hardware issue\n", index`);
          if (veEngine->codec.codecs[index].ref == 0) {
              pr_info("[VE_REPAIRED] coreIdx %d doesn't has any instance, try to repared\n", index);
              ret = ve_hotReset(xdev, index);
              if (ret == 0) {
                  vpuData = ~(0xFF << 8*index);
                  veEngine->vpu_info &= vpuData;
                  pr_info("[VE_REPAIRED] coreIdx %d repared success\n", index);
              }
          }
      }
    }
  #endif

    return 0;
#endif
}

/*
 * Called when the device goes from used to unused.
 */
static int ve_entire_ctrl_close(struct inode *inode, struct file *file)
{
#ifdef SUPPORT_CRASH_REPAIRED
    struct instance_crash_block instanceIdxBlk;
    struct inst_block *instBlk, *instNext;
    int ret, cnt, intflag;
    uint32_t indexFrameDisplay;
    struct ve_instance_pool_t *vip;
    int instance_pool_size_per_core;
#else
    struct codec_crash_block codecIdxBlk;
    struct codec_inst_block *codecInstBlk, *next;
#endif
    struct rpp_dev *xdev;
    struct rpp_vdev *xvdev = (struct rpp_vdev *)file->private_data;
    struct VideoEngine *veEngine;
    unsigned long flags;
    int bCloseEnable = 0;

    BUG_ON(!xvdev);
    /* fetch device specific data stored earlier during open */
    xdev = (struct rpp_dev *)xvdev->prppdev;
    BUG_ON(!xdev);

    veEngine = (struct VideoEngine *)xvdev->veEngine;
#ifdef SUPPORT_MULTI_OPEN_CLOSE
    spin_lock_irqsave(&xvdev->lock, flags);
#endif
#ifdef VE_SUPPORT_MULTI_CLIENT
    if (xvdev->nCount == 0) {
        pr_err("[VE_DRV] no any client connect with ve driver, invalid close\n");
#ifdef SUPPORT_MULTI_OPEN_CLOSE
        spin_unlock_irqrestore(&xvdev->lock, flags);
#endif
        rpp_idle_low_power_put(xdev, "ve_entire_ctrl_close_invalid");
        return -1;
    }
    if (veEngine->avali_dma != DMA_POOL_SIZE) {
        bCloseEnable |= 0x01;
        pr_info("[VE_DRV] veEngine %p dma buffers don't full recycle, current %d back\n", veEngine, veEngine->avali_dma);
    }

    if (veEngine->codec.avail_ins != ((veEngine->codec.codec_max-veEngine->codec.codec_min)*veEngine->codec.ins_max)) {
        bCloseEnable |= 0x02;
        pr_info("[VE_DRV] veEngine %p codecs don't full recycle, current %d back\n", veEngine, veEngine->codec.avail_ins);
    }

    if (veEngine->jpeg.avail_ins != ((veEngine->jpeg.codec_max-veEngine->jpeg.codec_min)*veEngine->jpeg.ins_max)) {
        bCloseEnable |= 0x04;
        pr_info("[VE_DRV] veEngine %p jpegs don't full recycle, current %d back\n", veEngine, veEngine->jpeg.avail_ins);
    }

    xvdev->nCount--;
    pr_info("[VE_DRV] veEngine %p close request by client %p, veEngine resource status=%x\n", veEngine, file, bCloseEnable);

    if (bCloseEnable) {
        ve_free_residual_instances(file, xdev);
    }
    file->private_data = 0;
  #ifdef SUPPORT_MULTI_OPEN_CLOSE
    spin_unlock_irqrestore(&xvdev->lock, flags);
  #endif

    /* hardware reset check while no client connect with ve driver
     * 1)codec hardware reset
     * 2)jpeg hardware reset
    */
  #ifdef SUPPORT_CRASH_REPAIRED
    list_for_each_entry_safe(instBlk, instNext, &s_instance_crash_block_head, list)
    {
        /* for all corrupted instance if (instBlk->filp == file)*/
        {
            instanceIdxBlk.core_index = instBlk->inst.inst_core_index & 0xffff;
            instanceIdxBlk.inst_index = instBlk->inst.inst_inst_index;

            if (instanceIdxBlk.core_index >= veEngine->codec.codec_max ||
                instanceIdxBlk.inst_index >= veEngine->codec.ins_max)
            {
                pr_err("[VE_REPAIRED] Illegal coreIdx %08x or instance %d\n", instanceIdxBlk.core_index, instanceIdxBlk.inst_index);
                goto INSTANCE_INVALID;
            }
            if(veEngine->instance_pool.size == 0 || veEngine->instance_pool.base == NULL) {
                pr_err("[VE_REPAIRED] cordIdx %08x instance %d instance pool invalid\n", instanceIdxBlk.core_index, instanceIdxBlk.inst_index);
                goto INSTANCE_INVALID;
            }
            /*get the vip base on instance coreIdx and instance index*/
            instance_pool_size_per_core = (veEngine->instance_pool.size/VE_CODEC_NUM);
            vip = (struct ve_instance_pool_t *)((unsigned char *)veEngine->instance_pool.base + instance_pool_size_per_core*instanceIdxBlk.core_index);

            instanceIdxBlk.codecStd  = vip->vpu_crash_status[instanceIdxBlk.inst_index].codecStd;
            instanceIdxBlk.lastWrPtr = vip->vpu_crash_status[instanceIdxBlk.inst_index].lastWrPtr;
            instanceIdxBlk.vip       = vip;
            do {
                /* step 0, check instance condition, high priority first
                 * condition 1, current device without any client connected
                 * condition 2, all instances of current core index are free
                 * condition 3, instance of core index still running, wait
                 * user app respond with correcting request and change state
                 * to INSTANCE_CORRECT_START
                */
                cnt = 0;
                ret = -1;
                while (1) {
                    if (xvdev->nCount == 0) {
                        pr_info("[VE_REPAIRED] check %d time trig, no client connected, crash state=%x\n",
                                 cnt, instanceIdxBlk.vip->crash_state);
                        break;
                    }
                    if (instanceIdxBlk.vip->vpu_instance_num == 0) {
                        pr_info("[VE_REPAIRED] check %d time trig by no instances, crash state=%x\n",
                                 cnt, instanceIdxBlk.vip->crash_state);
                        break;
                    }
                    if (INSTANCE_CORRECT_START == instanceIdxBlk.vip->crash_state) {
                        pr_info("[VE_REPAIRED] check %d time, coreIdx 0x%08x instance %d trig by app start request\n",
                                 cnt, instanceIdxBlk.core_index, instanceIdxBlk.inst_index);
                        break;
                    }
                    if (cnt >= CORRECT_RESPONDING_WAIT) {
                        /* TDF
                        if ((xvdev->nCount == 1) && (INSTANCE_CORRECT_REQUEST == instanceIdxBlk.vip->crash_state)) {
                            pr_info("[VE_REPAIRED] check %d time, coreIdx 0x%08x inst %d trig last app waiting start request\n",
                                     cnt, instanceIdxBlk.core_index, instanceIdxBlk.inst_index);
                            break;
                        }
                        */
                        pr_err("[VE_REPAIRED] %d app doesn't respond corrected request %x for coreIdx 0x%08x instance %d with veEngine %p, hardware reset\n",
                                xvdev->nCount, instanceIdxBlk.vip->crash_state, instanceIdxBlk.core_index, instanceIdxBlk.inst_index, veEngine);
                        goto INSTANCE_DESTRORY;
                    }
                    if (INSTANCE_CORRECT_CLOSE == instanceIdxBlk.vip->crash_state) {
                        pr_info("[VE_REPAIRED] check %d time, coreIdx 0x%08x instance %d close request\n",
                                 cnt, instanceIdxBlk.core_index, instanceIdxBlk.inst_index);
                    }
                    if (INSTANCE_CORRECT_REQUEST == instanceIdxBlk.vip->crash_state) {
                        pr_info("[VE_REPAIRED] check %d time, coreIdx 0x%08x instance %d wait app start\n",
                                 cnt, instanceIdxBlk.core_index, instanceIdxBlk.inst_index);
                    }
                    udelay(500);
                    cnt++;
                }
                /* step1, write end stream flag with last write pointer */
                ret = ve_updateBitstream(xdev, instanceIdxBlk.core_index, instanceIdxBlk.inst_index, instanceIdxBlk.codecStd, instanceIdxBlk.lastWrPtr);
                if (ret) {
                    pr_err("[VE_REPAIRED] failed set end stream for coreIdx 0x%08x instance %d codec mode %d with veEngine %p\n",
                            instanceIdxBlk.core_index, instanceIdxBlk.inst_index, instanceIdxBlk.codecStd, veEngine);
                    break;
                }
                /* step2, stop current crashed codec instance */
                cnt = 0;
                while(1) {
                    ret = ve_stopInstance(xdev, instanceIdxBlk.core_index, instanceIdxBlk.inst_index, instanceIdxBlk.codecStd);
                    if (ret == 0) {
                        pr_info("[VE_REPAIRED] success stop instance try %d times for coreIdx 0x%08x instance %d codec mode %d wrPtr %llx with vip %p\n",
                                 cnt, instanceIdxBlk.core_index, instanceIdxBlk.inst_index, instanceIdxBlk.codecStd, instanceIdxBlk.lastWrPtr, instanceIdxBlk.vip);
                        break;
                    }
                    if (ret == -2 /*still running*/) {
                        intflag = ve_checkInterrupt(xdev, instanceIdxBlk.core_index, instanceIdxBlk.inst_index);
                        if (intflag == 2 /*DEC_PIC output*/) {
                            /*should get output and clear indexFrameDisplay*/
                            indexFrameDisplay = ve_getOutputInfo(xdev, instanceIdxBlk.core_index, instanceIdxBlk.inst_index, instanceIdxBlk.codecStd);
                            if (indexFrameDisplay < 16) {
                                ve_clearFramebuffer(xdev, instanceIdxBlk.core_index, instanceIdxBlk.inst_index, instanceIdxBlk.codecStd, indexFrameDisplay);
                            }
                        }
                    }else{
                        pr_err("[VE_REPAIRED] failed=%d to stop instance for coreIdx 0x%08x instance %d with veEngine %p, hardware reset\n",
                                ret, instanceIdxBlk.core_index, instanceIdxBlk.inst_index, veEngine);
                        break;
                    }
                    cnt++;
                    if (cnt >= CORRECT_STOPING_WAIT) {
                        pr_err("[VE_REPAIRED] try %d times to stop instance for coreIdx 0x%08x instance %d with veEngine %p, still running, hardware reset\n",
                                cnt, instanceIdxBlk.core_index, instanceIdxBlk.inst_index, veEngine);
                        break;
                    }
                }
            }while(0);
INSTANCE_DESTRORY:
            if (ret) {
                /* 00000010 ->instance corrupted, should cold reset */
                if (instanceIdxBlk.core_index < veEngine->codec.codec_max) {
                    veEngine->vpu_info |= (0x02 << 8*instanceIdxBlk.core_index);
                    if (xvdev->async_queue)
                        kill_fasync(&xvdev->async_queue, SIGIO, POLL_IN); /* notify the vpu info to user space */
                }
            }
INSTANCE_INVALID:
            list_del(&instBlk->list);
            kfree(instBlk);
        }
    }

    /* Notice, doesn't change below const value "VE_CODEC_NUM" replace by other value */
    if (veEngine->instance_pool.size > 0 && veEngine->instance_pool.base != NULL) {
        instance_pool_size_per_core = (veEngine->instance_pool.size/VE_CODEC_NUM);
        spin_lock_irqsave(&xvdev->lock, flags);
        for (cnt=0; cnt<VE_CODEC_NUM; cnt++) {
            vip = (struct ve_instance_pool_t *)((unsigned char *)veEngine->instance_pool.base + instance_pool_size_per_core*cnt);
            pr_debug("core index %d instances num=%d serial cmd=%d crash state=%x\n", cnt, vip->vpu_instance_num, vip->cmd_serial, vip->crash_state);
            /* doesn't change the prioiry of if statement */
            if (INSTANCE_CORRECT_START == vip->crash_state) {
                vip->crash_state = INSTANCE_CORRECT_CLOSE;
                pr_debug("core index %d close request\n", cnt );
            }
            else if (vip->vpu_instance_num == 0 && vip->crash_state) {
                vip->crash_state = INSTANCE_CORRECT_RESET;
                pr_debug("core index %d clear request by no instance\n", cnt );
            }
            else if (INSTANCE_CORRECT_REQUEST == vip->crash_state) {
                vip->crash_state = INSTANCE_CORRECT_RESET;
                pr_debug("core index %d clear request\n", cnt );
            }
        }
        spin_unlock_irqrestore(&xvdev->lock, flags);
    }

  #else
    /* non SUPPORT_CRASH_REPAIRED, recording only */
    if (xvdev->nCount == 0) {
        list_for_each_entry_safe(codecInstBlk, next, &s_codec_crash_block_head, list)
        {
            codecIdxBlk.core_index = codecInstBlk->codec_inst.index
            if ((codecIdxBlk.core_index >= veEngine->codec.codec_min) ||
                (codecIdxBlk.core_index < veEngine->codec.codec_max)) {
                /*current codec coreIdx release all instances, reset start*/
                if (veEngine->codec.codecs[codecIdxBlk.core_index].ref == 0) {
                    pr_info("[VE_REPAIRED] veEngine %p codec core index %d hardware reset request for open client %p\n",
                             veEngine, codecIdxBlk.core_index, file);
                    list_del(&codecInstBlk->list);
                    kfree(codecInstBlk);
                }
            }
        }

        list_for_each_entry_safe(codecInstBlk, next, &s_jpeg_crash_block_head, list)
        {
            codecIdxBlk.core_index = codecInstBlk->codec_inst.index
            if ((codecIdxBlk.core_index >= veEngine->jpeg.codec_min) ||
                (codecIdxBlk.core_index < veEngine->jpeg.codec_max)) {
                /*current jpeg coreIdx release all instances, reset start*/
                if (veEngine->jpeg.codecs[codecIdxBlk.core_index].ref == 0) {
                    pr_info("[VE_REPAIRED] veEngine %p jpeg core index %d hardware reset request for open client %p\n",
                             veEngine, codecIdxBlk.core_index, file);
                    list_del(&codecInstBlk->list);
                    kfree(codecInstBlk);
                }
            }
        }
    }
  #endif

#else
    /* non multi client mode, it should non support crash repaired */
    if (veEngine->avali_dma != DMA_POOL_SIZE) {
        bCloseEnable |= 0x01;
        pr_info("[VE_DRV] ve dma buffers don't full recycle, only %d back\n", veEngine->avali_dma);
    }

    if (veEngine->codec.avail_ins != ((veEngine->codec.codec_max-veEngine->codec.codec_min)*veEngine->codec.ins_max)) {
        bCloseEnable |= 0x02;
        pr_info("[VE_DRV] ve codecs don't full recycle, only %d back\n", veEngine->codec.avail_ins);
    }

    if (veEngine->jpeg.avail_ins != ((veEngine->jpeg.codec_max-veEngine->jpeg.codec_min)*veEngine->jpeg.ins_max)) {
        bCloseEnable |= 0x04;
        pr_info("[VE_DRV] ve jpegs don't full recycle, only %d back\n", veEngine->jpeg.avail_ins);
    }
    if (bCloseEnable) {
        ve_free_residual_instances(file, xdev);
    }
    file->private_data = 0;
  #ifdef SUPPORT_MULTI_OPEN_CLOSE
    spin_unlock_irqrestore(&xvdev->lock, flags);
  #endif

  #ifndef SUPPORT_CRASH_REPAIRED
    list_for_each_entry_safe(codecInstBlk, next, &s_codec_crash_block_head, list)
    {
        codecIdxBlk.core_index = codecInstBlk->codec_inst.index

        if ((codecIdxBlk.core_index >= veEngine->codec.codec_min) ||
            (codecIdxBlk.core_index < veEngine->codec.codec_max)) {
            /*current codec coreIdx release all instances, reset start*/
            if (veEngine->codec.codecs[codecIdxBlk->core_index].ref == 0) {
                pr_info("[VE_REPAIRED] veEngine %p codec core index %d hardware reset request for open client %p\n",
                         veEngine, codecIdxBlk.core_index, file);
                list_del(&codecInstBlk->list);
                kfree(codecInstBlk);
            }
        }
    }

    list_for_each_entry_safe(codecInstBlk, next, &s_jpeg_crash_block_head, list)
    {
        codecIdxBlk.core_index = codecInstBlk->codec_inst.index

        if ((codecIdxBlk.core_index >= veEngine->jpeg.codec_min) ||
            (codecIdxBlk.core_index < veEngine->jpeg.codec_max)) {
            /*current jpeg coreIdx release all instances, reset start*/
            if (veEngine->jpeg.codecs[codecIdxBlk.core_index].ref == 0) {
                pr_info("[VE_REPAIRED] veEngine %p jpeg core index %d hardware reset request for open client %p\n",
                         veEngine, codecIdxBlk.core_index, file);
                list_del(&codecInstBlk->list);
                kfree(codecInstBlk);
            }
        }
    }
  #endif
#endif

#ifdef VPU_HAL_MPU
    /*When application terminate by Ctrl+Z, doesn't release vdi param*/
    uint64_t commond;
    if ((xvdev->nCount == 0) && (veEngine->vdi_param_status == 1)) {
        commond = 2;   /*release request*/
        ret = ve_ioctl_load_vdi_param(file, xdev, &commond);
        if (ret == 0 && commond == 0) {
            pr_info("[VE_REPAIRED] veEngine %p release vpu vdi common memory\n", veEngine);
        }else{
            pr_warn("[VE_REPAIRED] veEngine %p fail release vpu vdi common memory\n", veEngine);
        }
    }
#endif

    rpp_idle_low_power_put(xdev, "ve_entire_ctrl_close");
    return 0;
}

static __poll_t ve_entire_ctrl_poll(struct file *file, struct poll_table_struct *wait)
{
#ifdef SUPPORT_MULTI_INST_INTR
/* Event specification for ve interrupt
 * poll schem normal can't support monitor same event from multi hardware trig, so we use
 * differenct event to represent it
 * bit0->POLLIN, interrupt comdes from ve codec0
 * bit1->POLLPRI, interrupt comes from ve codec1
 * bit2->POLLOUT, interrupt comes from ve codec2
 * bit3->POLLERR, interrupt comdes from ve codec3
*/
static const uint32_t POLL_TABELE[VE_CODEC_NUM]={
    POLLIN,     /*codec0 interrupt event*/
    POLLPRI,    /*codec1 interrupt event*/
    POLLOUT,    /*codec2 interrupt event*/
    POLLERR,    /*codec3 interrupt event*/
};
    struct rpp_vdev *xvdev = (struct rpp_vdev *)file->private_data;
    struct InterruptManager *veInterrupt;

    uint32_t i, j;
    __poll_t mask = 0;

    if (!veInterrupt) {
        pr_err("vdev %p veInterrupt not initial", xvdev);
        return 0;
    }

    for (i=0; i < VE_CODEC_NUM; i++) {
        for (j=0; j < VE_CODEC_INSTANCE_NUM; j++)
            poll_wait(file, &veInterrupt->vint_wait[i][j], wait);
    }

    for (i=0; i < VE_CODEC_NUM; i++) {
        for (j=0; j < VE_CODEC_INSTANCE_NUM; j++) {
            if (veInterrupt->vint_flag[i][j]) {
                pr_debug("coreIdx %d instance %d interrupt happen\n", i ,j);
                mask |= POLL_TABELE[i];
                veInterrupt->vint_flag[i][j] = 0;
            }
        }
    }
    return mask;
#else
    return 0;
#endif
}

static int ve_entire_ctrl_fasync(int fd, struct file *file, int mode)
{
    struct rpp_vdev *xvdev = (struct rpp_vdev *)file->private_data;
    return fasync_helper(fd, file, mode, &xvdev->async_queue);
}


/*
 * character device file operations for entire control
 */
static const struct file_operations ve_entire_ctrl_fops = {
    .owner = THIS_MODULE,
    .open = ve_entire_ctrl_open,
    .release = ve_entire_ctrl_close,
    .read = ve_entire_ctrl_read,
    .write = ve_entire_ctrl_write,
    .mmap = ve_entire_bridge_mmap,
    .llseek = ve_entire_ctrl_llseek,
    .unlocked_ioctl = ve_entire_ctrl_ioctl,
    .poll = ve_entire_ctrl_poll,
    .fasync = ve_entire_ctrl_fasync,
};

void vdev_entire_ctrl_init(struct rpp_vdev *xvdev)
{
    cdev_init(&xvdev->vdev, &ve_entire_ctrl_fops);
}

