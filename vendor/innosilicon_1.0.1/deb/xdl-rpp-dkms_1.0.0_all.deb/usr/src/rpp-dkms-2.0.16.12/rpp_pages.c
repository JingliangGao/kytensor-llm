/*
 * CDDL HEADER START
 *
 * The contents of this file are subject to the terms of the
 * Common Development and Distribution License (the "License").
 * You may not use this file except in compliance with the License.
 *
 * You can obtain a copy of the license at usr/src/OPENSOLARIS.LICENSE
 * or http://www.opensolaris.org/os/licensing.
 * See the License for the specific language governing permissions
 * and limitations under the License.
 *
 * When distributing Covered Code, include this CDDL HEADER in each
 * file and include the License file at usr/src/OPENSOLARIS.LICENSE.
 * If applicable, add the following below this CDDL HEADER, with the
 * fields enclosed by brackets "[]" replaced with your own identifying
 * information: Portions Copyright [yyyy] [name of copyright owner]
 *
 * CDDL HEADER END
 */

/*
 * Copyright 2010 PathScale Inc.  All rights reserved.
 * Use is subject to license terms.
 */

#include <linux/list.h>
#include <linux/kernel.h>
#include <linux/version.h>
#include <linux/mutex.h>
#include <linux/mm.h>
#include <linux/errno.h>
#include <linux/slab.h>
#include <linux/mutex.h>
#include <linux/gfp.h>
#include <linux/pci.h>
#include <linux/cache.h>
#include <linux/dma-mapping.h>
#include <asm/io.h>
#include <linux/pagemap.h>
#include <linux/uaccess.h>
#include <asm/cache.h>
#include <asm/cacheflush.h>
#include <linux/highmem.h>

/* #include "include/rpp_cdev_ctrl.h" */
#include "include/rpp_pages.h"
#include "include/rpp_cdev_ctrl.h"
#include "include/pci-dma-compat.h"

void rpp_sync_sgt_for_cpu(struct rpp_dev *pdev, rpp_pages_t *rpp_pages)
{
	int i;

	if (!rpp_pages)
		return;

	pci_dma_sync_sg_for_cpu(pdev->pdev, rpp_pages->sgt.sgl, rpp_pages->sgt.nents, PCI_DMA_BIDIRECTIONAL);
}

void rpp_sync_sgt_for_device(struct rpp_dev *pdev, rpp_pages_t *rpp_pages)
{
	int i;

	if (!rpp_pages)
		return;

	pci_dma_sync_sg_for_device(pdev->pdev, rpp_pages->sgt.sgl, rpp_pages->sgt.nents, PCI_DMA_BIDIRECTIONAL);
}

void rpp_unmap_user_buf(struct rpp_dev *pdev, rpp_pages_t *rpp_pages)
{
	int i = 0;

	if (!rpp_pages->pages || !rpp_pages->pages_nr)
		return;

#if 0
	struct scatterlist *sg, *start;
	start = rpp_pages->sgt.sgl;
	for_each_sg(start, sg, rpp_pages->mapped_nents, i) {
		DEV_DEBUG(pdev, "[mm] Unmap %d/%d numpages, %d, pages/dmapages 0x%llx/0x%llx, dma_length 0x%x\n", rpp_pages->sgt.nents, rpp_pages->sgt.orig_nents, i, \
			(uint64_t)page_address(sg_page(sg)), cpu_to_le64((u64)sg_dma_address(sg)), cpu_to_le32((u32)sg_dma_len(sg)));
	}
#endif

	if (rpp_pages->mapped_nents > 0) {
		pci_unmap_sg(pdev->pdev, rpp_pages->sgt.sgl, rpp_pages->sgt.nents, PCI_DMA_BIDIRECTIONAL);
		rpp_pages->mapped_nents = 0;
	}

	sg_free_table(&rpp_pages->sgt);

	for (i = 0; i < rpp_pages->pages_nr; i++) {
		if (rpp_pages->pages[i]) {
			set_page_dirty_lock(rpp_pages->pages[i]);
			put_page(rpp_pages->pages[i]);
		} else {
			break;
		}
	}

	if (rpp_pages->pages_nr * sizeof *rpp_pages->pages > MAX_KMALLOC_SIZE) {
		vfree(rpp_pages->pages);
	} else {
		kfree(rpp_pages->pages);
	}
	kfree(rpp_pages);
}

rpp_pages_t *rpp_map_user_buf(struct rpp_dev *pdev, uint64_t addr, uint64_t size)
{
	static int serial = 0;
	unsigned long lockflags;
	rpp_pages_t *rpp_pages;
	struct scatterlist *sg, *start;
	uint32_t offset;
	int i, j;
	int rv;

	/* avoid all sorts of integer overflows possible otherwise. */
	if (size >= (1ULL << 36))
		return NULL;
	if (!size)
		return NULL;

	rpp_pages = kzalloc(sizeof(rpp_pages_t), GFP_KERNEL);
	if (!rpp_pages)
		return NULL;

	rpp_pages->idr_type = RPP_IDR_OBJ_PAGES;
	rpp_pages->size = PAGE_ALIGN(addr + size) - (addr & PAGE_MASK);

	/* XXX: another mutex? */
	spin_lock_irqsave(&pdev->lock, lockflags);
	rpp_pages->serial = serial++;
	spin_unlock_irqrestore(&pdev->lock, lockflags);

	rpp_pages->pages_nr = rpp_pages->size >> PAGE_SHIFT;

	if (rpp_pages->pages_nr * sizeof *rpp_pages->pages > MAX_KMALLOC_SIZE) {
		rpp_pages->pages = vmalloc(rpp_pages->pages_nr * sizeof *rpp_pages->pages);
	} else {
		rpp_pages->pages = kmalloc(rpp_pages->pages_nr * sizeof *rpp_pages->pages, GFP_KERNEL);
	}
	if (!rpp_pages->pages) {
		goto err_out;
	}

	rv = get_user_pages_fast((unsigned long)addr, rpp_pages->pages_nr, 1/* write */,
				rpp_pages->pages);
	/* No pages were pinned */
	if (rv < 0) {
		ERROR_PRINT("unable to pin down %u user pages, %d.\n",
			rpp_pages->pages_nr, rv);
		goto err_out;
	}
	/* Less pages pinned than wanted */
	if (rv != rpp_pages->pages_nr) {
		ERROR_PRINT("unable to pin down all %u user pages, %d.\n",
			rpp_pages->pages_nr, rv);
		goto err_out2;
	}

	offset = addr & ~PAGE_MASK;
	if (sg_alloc_table_from_pages(&rpp_pages->sgt, rpp_pages->pages, rpp_pages->pages_nr, offset, size, GFP_KERNEL)) {
		ERROR_PRINT("sgl OOM.\n");
		goto err_out2;
	}

	sg = rpp_pages->sgt.sgl;
	rv = pci_map_sg(pdev->pdev, sg, rpp_pages->sgt.orig_nents, PCI_DMA_BIDIRECTIONAL);
	if (rv < 0) {
		ERROR_PRINT("unable to pin down %u user pages, %d.\n",
			rpp_pages->pages_nr, rv);
		goto err_out2;
	}
	rpp_pages->mapped_nents = rv;

#if 0
	start = rpp_pages->sgt.sgl;
	for_each_sg(start, sg, rpp_pages->mapped_nents, i) {
		DEV_DEBUG(pdev, "[mm] Map %d/%d numpages, %d, pages/dmapages 0x%llx/0x%llx, dma_length 0x%x\n", rpp_pages->sgt.nents, rpp_pages->sgt.orig_nents, i, \
			(uint64_t)page_address(sg_page(sg)), cpu_to_le64((u64)sg_dma_address(sg)), cpu_to_le32((u32)sg_dma_len(sg)));
	}
#endif

	return rpp_pages;

err_out2:
	for (i = 0; i < rpp_pages->pages_nr; i++) {
		if (rpp_pages->pages[i]) {
			set_page_dirty_lock(rpp_pages->pages[i]);
			put_page(rpp_pages->pages[i]);
		} else {
			break;
		}
	}
err_out:
	if (rpp_pages->pages) {
		if (rpp_pages->pages_nr * sizeof *rpp_pages->pages > MAX_KMALLOC_SIZE) {
			vfree(rpp_pages->pages);
		} else {
			kfree(rpp_pages->pages);
		}
	}
	kfree(rpp_pages);
	return NULL;
}

void rpp_unmap_user_buf_2(struct rpp_dev *pdev, rpp_pages_t *rpp_pages)
{
	int i = 0;
	dma_addr_t dmapages;
	uint32_t dma_length;
	struct scatterlist *sg, *start;

	if (!rpp_pages->pages || !rpp_pages->pages_nr)
		return;

#if 0
	start = rpp_pages->sgt.sgl;
	for_each_sg(start, sg, rpp_pages->mapped_nents, i) {
		DEV_DEBUG(pdev, "[mm] Unmap %d/%d numpages, %d, pages/dmapages 0x%llx/0x%llx, dma_length 0x%x\n", rpp_pages->sgt.nents, rpp_pages->sgt.orig_nents, i, \
			(uint64_t)page_address(sg_page(sg)), cpu_to_le64((u64)sg_dma_address(sg)), cpu_to_le32((u32)sg_dma_len(sg)));
	}
#endif

	start = rpp_pages->sgt.sgl;
	for_each_sg(start, sg, rpp_pages->mapped_nents, i) {
		dmapages = sg_dma_address(sg);
		dma_length = sg_dma_len(sg);
		pci_unmap_page(pdev->pdev, dmapages, dma_length, DMA_BIDIRECTIONAL);
	}
	rpp_pages->mapped_nents = 0;

	sg_free_table(&rpp_pages->sgt);

	for (i = 0; i < rpp_pages->pages_nr; i++) {

		if (rpp_pages->pages[i]) {
			set_page_dirty_lock(rpp_pages->pages[i]);
			put_page(rpp_pages->pages[i]);
		} else {
			break;
		}
	}
	
	if (rpp_pages->pages_nr * sizeof *rpp_pages->pages > MAX_KMALLOC_SIZE) {
		vfree(rpp_pages->pages);
	} else {
		kfree(rpp_pages->pages);
	}
	kfree(rpp_pages);
}

rpp_pages_t *rpp_map_user_buf_2(struct rpp_dev *pdev, uint64_t addr, uint64_t size)
{
	static int serial = 0;
	unsigned long lockflags;
	rpp_pages_t *rpp_pages;
	dma_addr_t dmapages;
	struct scatterlist *sg, *start;
	uint32_t offset;
	uint32_t len;
	int i, j;
	int rv;


	/* avoid all sorts of integer overflows possible otherwise. */
	if (size >= (1ULL << 36))
		return NULL;
	if (!size)
		return NULL;

	rpp_pages = kzalloc(sizeof(rpp_pages_t), GFP_KERNEL);
	if (!rpp_pages)
		return NULL;

	rpp_pages->idr_type = RPP_IDR_OBJ_PAGES;
	rpp_pages->size = PAGE_ALIGN(addr + size) - (addr & PAGE_MASK);

	/* XXX: another mutex? */
	spin_lock_irqsave(&pdev->lock, lockflags);
	rpp_pages->serial = serial++;
	spin_unlock_irqrestore(&pdev->lock, lockflags);

	rpp_pages->pages_nr = rpp_pages->size >> PAGE_SHIFT;

	if (rpp_pages->pages_nr * sizeof *rpp_pages->pages > MAX_KMALLOC_SIZE) {
		rpp_pages->pages = vmalloc(rpp_pages->pages_nr * sizeof *rpp_pages->pages);
	} else {
		rpp_pages->pages = kmalloc(rpp_pages->pages_nr * sizeof *rpp_pages->pages, GFP_KERNEL);
	}

	if (!rpp_pages->pages) {
		goto err_out;
	}

	rv = get_user_pages_fast((unsigned long)addr, rpp_pages->pages_nr, 1/* write */,
				rpp_pages->pages);
	/* No pages were pinned */
	if (rv < 0) {
		ERROR_PRINT("unable to pin down %u user pages, %d.\n",
			rpp_pages->pages_nr, rv);
		goto err_out;
	}
	/* Less pages pinned than wanted */
	if (rv != rpp_pages->pages_nr) {
		ERROR_PRINT("unable to pin down all %u user pages, %d.\n",
			rpp_pages->pages_nr, rv);
		goto err_out2;
	}

	offset = addr & ~PAGE_MASK;
	if (sg_alloc_table(&rpp_pages->sgt, rpp_pages->pages_nr, GFP_KERNEL)) {
		ERROR_PRINT("sgl OOM.\n");
		goto err_out2;
	}

	sg = rpp_pages->sgt.sgl;
	len = rpp_pages->size;
	for (i = 0; i < rpp_pages->pages_nr; i++, sg = sg_next(sg)) {
		/* unsigned int offset = (uintptr_t)buf & ~PAGE_MASK; */
		unsigned int nbytes = min_t(unsigned int, PAGE_SIZE - offset, len);
		get_page(rpp_pages->pages[i]);
		flush_dcache_page(rpp_pages->pages[i]);
		dmapages = pci_map_page(pdev->pdev, rpp_pages->pages[i], offset, nbytes, PCI_DMA_BIDIRECTIONAL);
		if (pci_dma_mapping_error(pdev->pdev, dmapages)) {
			goto err_out3;
		}

		sg_set_page(sg, rpp_pages->pages[i], nbytes, offset);
		sg_dma_address(sg) = dmapages;
		sg_dma_len(sg) = nbytes;

		INFO_PRINT("%d, 0x%p, pg virt/phys 0x%llx/0x%llx, %u+%u, dma 0x%llx,%u.\n",
			i, sg, (uint64_t)sg_virt(sg), (uint64_t)sg_phys(sg), sg->offset, sg->length,
			sg_dma_address(sg), sg_dma_len(sg));

#if 0
		INFO_PRINT("data: 0x%08x, 0x%08x, 0x%08x, 0x%08x\n",
					*(uint32_t *)sg_virt(sg),
					*(uint32_t *)(sg_virt(sg) + 0x4),
					*(uint32_t *)(sg_virt(sg) + 0x8),
					*(uint32_t *)(sg_virt(sg) + 0xc));
#endif
		offset = 0;
		len -= nbytes;
	}

	rpp_pages->mapped_nents = rpp_pages->pages_nr;

#if 0
	start = rpp_pages->sgt.sgl;
	for_each_sg(start, sg, rpp_pages->mapped_nents, i) {
		DEV_DEBUG(pdev, "[mm] Map %d/%d numpages, %d, pages/dmapages 0x%llx/0x%llx, dma_length 0x%x\n", rpp_pages->sgt.nents, rpp_pages->sgt.orig_nents, i, \
			(uint64_t)page_address(sg_page(sg)), cpu_to_le64((u64)sg_dma_address(sg)), cpu_to_le32((u32)sg_dma_len(sg)));
	}
#endif

	return rpp_pages;

err_out3:
err_out2:
	for (i = 0; i < rpp_pages->pages_nr; i++) {
		if (rpp_pages->pages[i]) {
			set_page_dirty_lock(rpp_pages->pages[i]);
			put_page(rpp_pages->pages[i]);
		} else {
			break;
		}
	}
err_out:
	if (rpp_pages->pages) {
		if (rpp_pages->pages_nr * sizeof *rpp_pages->pages > MAX_KMALLOC_SIZE) {
			vfree(rpp_pages->pages);
		} else {
			kfree(rpp_pages->pages);
		}
	}
		
	kfree(rpp_pages);
	return NULL;
}

/*
 * Host pages memory
 */
rpp_pages_t *rpp_pages_alloc(struct rpp_dev *pdev, uint64_t size)
{
	static int serial = 0;
	unsigned long lockflags;
	rpp_pages_t *rpp_pages;
	void *dma_buf;
	int numpages, i, j;

	/* avoid all sorts of integer overflows possible otherwise. */
	if (size >= (1ULL << 36))
		return NULL;
	if (!size)
		return NULL;

	rpp_pages = kzalloc(sizeof(rpp_pages_t), GFP_KERNEL);
	if (!rpp_pages)
		return NULL;

	rpp_pages->idr_type = RPP_IDR_OBJ_PAGES;
	size = ALIGN(size, RPP_PAGES_SIZE);
	size = ALIGN(size, PAGE_SIZE);

	rpp_pages->size = size;

	/* XXX: another mutex? */
	spin_lock_irqsave(&pdev->lock, lockflags);
	rpp_pages->serial = serial++;
	spin_unlock_irqrestore(&pdev->lock, lockflags);

	numpages = rpp_pages->size >> PAGE_SHIFT;

	if (numpages * sizeof *rpp_pages->pages > MAX_KMALLOC_SIZE) {
		rpp_pages->pages = vmalloc(numpages * sizeof *rpp_pages->pages);
		if (!rpp_pages->pages)
			return NULL;

		rpp_pages->dmapages = vmalloc(numpages * sizeof *rpp_pages->dmapages);
		if (!rpp_pages->dmapages) {
			vfree(rpp_pages->pages);
			return NULL;
		}
	} else {
		rpp_pages->pages = kmalloc(numpages * sizeof *rpp_pages->pages, GFP_KERNEL);
		if (!rpp_pages->pages)
			return NULL;
			
		rpp_pages->dmapages = kmalloc(numpages * sizeof *rpp_pages->dmapages, GFP_KERNEL);
		if (!rpp_pages->dmapages) {
			kfree(rpp_pages->pages);
			return NULL;
		}
	}


#if 0 /*  def ISS_SERVER */
	if (rpp_pages->dev->dma_mask == DMA_BIT_MASK(64))
		gfp_flags = GFP_KERNEL;
	else
		gfp_flags = GFP_DMA32;

	for (i = 0; i < numpages; i++) {
		rpp_pages->pages[i] = alloc_pages(gfp_flags, 0);
		if (!rpp_pages->pages[i]) {
			for (j = 0; j < i; j++)
				put_page(rpp_pages->pages[j]);
			if (numpages * sizeof *rpp_pages->pages > MAX_KMALLOC_SIZE) {
				vfree(rpp_pages->pages);
				vfree(rpp_pages->dmapages);
			} else {
				kfree(rpp_pages->pages);
				kfree(rpp_pages->dmapages);
			}

			return -ENOMEM;
		}
		/*  INFO_PRINT("%s, bo->pages[%d] 0x%lx\n", __func__, i, (unsigned long)page_address(bo->pages[i])); */
	}
#else
	for (i = 0; i < numpages; i++) {
		dma_buf = pci_alloc_consistent(pdev->pdev, PAGE_SIZE, &rpp_pages->dmapages[i]);
		if (!dma_buf) {
			DEV_ERROR(pdev, "%s, error pci_alloc_consistent\n", __func__);
			for (j = 0; j < i; j++)
				pci_free_consistent(pdev->pdev, PAGE_SIZE, page_address(rpp_pages->pages[j]), rpp_pages->dmapages[j]);
			if (numpages * sizeof *rpp_pages->pages > MAX_KMALLOC_SIZE) {
				vfree(rpp_pages->pages);
				vfree(rpp_pages->dmapages);
			} else {
				kfree(rpp_pages->pages);
				kfree(rpp_pages->dmapages);
			}
			return NULL;
		}
		rpp_pages->pages[i] = virt_to_page(dma_buf);

		/* INFO_PRINT("Alloc the %d numpages, pages/dmapages 0x%llx/0x%llx\n", i, \
			(uint64_t)page_address(rpp_pages->pages[i]), rpp_pages->dmapages[i]); */
	}

	/* DEBUG_PRINT("[mm] "Alloc %d numpages, pages/dmapages 0x%llx/0x%llx\n", numpages, \
		(uint64_t)page_address(rpp_pages->pages[0]), rpp_pages->dmapages[0]); */
#endif
	return rpp_pages;
}

void rpp_pages_free(struct rpp_dev *pdev, rpp_pages_t *rpp_pages)
{
	int numpages, i;

	numpages = rpp_pages->size >> PAGE_SHIFT;
	/* DEBUG_PRINT("[mm] "Free %d numpages, pages/dmapages 0x%llx/0x%llx\n", numpages, \
		(uint64_t)page_address(rpp_pages->pages[0]), rpp_pages->dmapages[0]); */

#if 0 /*  def ISS_SERVER */
	/*  for (i = 0; i < numpages; i++) */
	/* 	pci_unmap_page(dev->pdev, rpp_page->dmapages[i], PAGE_SIZE, PCI_DMA_BIDIRECTIONAL); */
	for (i = 0; i < numpages; i++)
		put_page(rpp_page->pages[i]);
#else
	for (i = 0; i < numpages; i++)
		pci_free_consistent(pdev->pdev, PAGE_SIZE, page_address(rpp_pages->pages[i]), rpp_pages->dmapages[i]);
#endif

	if (numpages * sizeof *rpp_pages->pages > MAX_KMALLOC_SIZE) {
		vfree(rpp_pages->pages);
		vfree(rpp_pages->dmapages);
	} else {
		kfree(rpp_pages->pages);
		kfree(rpp_pages->dmapages);
	}

	vfree(rpp_pages);
}

static int rpp_single_map_dir(uint32_t flags)
{
	uint32_t dir = flags & RPP_SINGLE_DIR_MASK;

	if (dir == RPP_SINGLE_DIR_TO_DEV)
		return PCI_DMA_TODEVICE;
	if (dir == RPP_SINGLE_DIR_FROM_DEV)
		return PCI_DMA_FROMDEVICE;
	if (dir == RPP_SINGLE_DIR_BIDIR)
		return PCI_DMA_BIDIRECTIONAL;
	return -EINVAL;
}

static bool rpp_pages_phys_contiguous(struct page **pages, unsigned int nr)
{
	phys_addr_t prev;
	unsigned int i;

	if (nr <= 1)
		return true;

	prev = page_to_phys(pages[0]);
	for (i = 1; i < nr; i++) {
		if (page_to_phys(pages[i]) != prev + PAGE_SIZE)
			return false;
		prev = page_to_phys(pages[i]);
	}
	return true;
}

static void rpp_single_unmap_user_pages(rpp_single_map_t *single)
{
	unsigned int i;

	if (!single->pages || !single->pages_nr)
		return;

	for (i = 0; i < single->pages_nr; i++) {
		if (single->pages[i]) {
			set_page_dirty_lock(single->pages[i]);
			put_page(single->pages[i]);
		}
	}

	if (single->pages_nr * sizeof(*single->pages) > MAX_KMALLOC_SIZE)
		vfree(single->pages);
	else
		kfree(single->pages);
	single->pages = NULL;
	single->pages_nr = 0;
}

void rpp_unmap_single_buf(struct rpp_dev *pdev, rpp_single_map_t *single)
{
	if (!single)
		return;

	if (single->dma_addr) {
		pci_unmap_single(pdev->pdev, single->dma_addr, single->map_len,
				 single->dma_dir);
		single->dma_addr = 0;
	}

	if (single->is_vmapped && single->vmap_base) {
		vunmap(single->vmap_base);
		single->vmap_base = NULL;
		single->is_vmapped = false;
	}
	single->kvirt = NULL;

	rpp_single_unmap_user_pages(single);
	kfree(single);
}

static rpp_single_map_t *rpp_map_single_user_va(struct rpp_dev *pdev,
					      struct rpp_single_map_info *info)
{
	static int serial;
	unsigned long lockflags;
	rpp_single_map_t *single;
	uint64_t addr = info->addr;
	uint64_t size = info->size;
	uint32_t offset;
	void *map_base = NULL;
	int rv;
	int dir;

	single = kzalloc(sizeof(*single), GFP_KERNEL);
	if (!single)
		return NULL;

	single->idr_type = RPP_IDR_OBJ_SINGLE;
	spin_lock_irqsave(&pdev->lock, lockflags);
	single->serial = serial++;
	spin_unlock_irqrestore(&pdev->lock, lockflags);

	dir = rpp_single_map_dir(info->flags);
	if (dir < 0) {
		kfree(single);
		return NULL;
	}
	single->dma_dir = dir;
	single->flags = info->flags;
	single->map_addr = addr;
	single->map_len = size;
	single->size = PAGE_ALIGN(addr + size) - (addr & PAGE_MASK);
	single->pages_nr = single->size >> PAGE_SHIFT;

	if (single->pages_nr * sizeof(*single->pages) > MAX_KMALLOC_SIZE)
		single->pages = vmalloc(single->pages_nr * sizeof(*single->pages));
	else
		single->pages = kmalloc(single->pages_nr * sizeof(*single->pages),
					GFP_KERNEL);
	if (!single->pages)
		goto err_out;

	rv = get_user_pages_fast((unsigned long)addr, single->pages_nr, 1,
				 single->pages);
	if (rv < 0 || rv != (int)single->pages_nr) {
		ERROR_PRINT("unable to pin down %u user pages, %d.\n",
		       single->pages_nr, rv);
		goto err_out;
	}

	if (!rpp_pages_phys_contiguous(single->pages, single->pages_nr)) {
		ERROR_PRINT("user buffer not physically contiguous, use MAP_SHM\n");
		goto err_out2;
	}

	offset = addr & ~PAGE_MASK;
	single->host_phys = page_to_phys(single->pages[0]) + offset;

	if (single->pages_nr == 1) {
		map_base = page_address(single->pages[0]);
	} else {
		map_base = vmap(single->pages, single->pages_nr, VM_MAP,
				PAGE_KERNEL);
		if (!map_base)
			goto err_out2;
		single->is_vmapped = true;
		single->vmap_base = map_base;
	}
	single->kvirt = map_base + offset;

	single->dma_addr = pci_map_single(pdev->pdev, single->kvirt, size, dir);
	if (pci_dma_mapping_error(pdev->pdev, single->dma_addr)) {
		ERROR_PRINT("pci_map_single failed for user VA 0x%llx\n", addr);
		goto err_out3;
	}

	return single;

err_out3:
	if (single->is_vmapped && map_base) {
		vunmap(map_base);
		single->vmap_base = NULL;
		single->is_vmapped = false;
	}
	single->kvirt = NULL;
err_out2:
	rpp_single_unmap_user_pages(single);
err_out:
	kfree(single);
	return NULL;
}

static rpp_single_map_t *rpp_map_single_phys(struct rpp_dev *pdev,
					     struct rpp_single_map_info *info)
{
	static int serial;
	unsigned long lockflags;
	rpp_single_map_t *single;
	int dir;

	single = kzalloc(sizeof(*single), GFP_KERNEL);
	if (!single)
		return NULL;

	single->idr_type = RPP_IDR_OBJ_SINGLE;
	spin_lock_irqsave(&pdev->lock, lockflags);
	single->serial = serial++;
	spin_unlock_irqrestore(&pdev->lock, lockflags);

	dir = rpp_single_map_dir(info->flags);
	if (dir < 0) {
		kfree(single);
		return NULL;
	}

	single->dma_dir = dir;
	single->flags = info->flags;
	single->map_addr = info->addr;
	single->map_len = info->size;
	single->size = info->size;
	single->host_phys = info->addr;
	single->kvirt = phys_to_virt(info->addr);

	single->dma_addr = pci_map_single(pdev->pdev, single->kvirt, single->map_len,
					  dir);
	if (pci_dma_mapping_error(pdev->pdev, single->dma_addr)) {
		ERROR_PRINT("pci_map_single failed for phys 0x%llx\n", info->addr);
		kfree(single);
		return NULL;
	}

	return single;
}

rpp_single_map_t *rpp_map_single_buf(struct rpp_dev *pdev,
				     struct rpp_single_map_info *info)
{
	uint32_t addr_type = info->flags & RPP_SINGLE_ADDR_MASK;

	if (!info->size || info->size >= (1ULL << 36))
		return NULL;

	if (addr_type == RPP_SINGLE_ADDR_USER_VA)
		return rpp_map_single_user_va(pdev, info);
	if (addr_type == RPP_SINGLE_ADDR_PHYS)
		return rpp_map_single_phys(pdev, info);

	ERROR_PRINT("invalid single map addr flags 0x%x\n", info->flags);
	return NULL;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,17,0)
vm_fault_t rpp_single_map_vm_fault(struct vm_fault *vmf)
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,11,0)
int rpp_single_map_vm_fault(struct vm_fault *vmf)
#else
int rpp_single_map_vm_fault(struct vm_area_struct *vma, struct vm_fault *vmf)
#endif
#endif
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,11,0)
	struct vm_area_struct *vma = vmf->vma;
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,10,0)
	uint64_t offset = (uint64_t)vmf->address - vma->vm_start;
#else
	uint64_t offset = (uint64_t)vmf->virtual_address - vma->vm_start;
#endif
	rpp_single_map_t *single = vma->vm_private_data;
	struct page *res;

	if (offset > single->size)
		return VM_FAULT_SIGBUS;

	if (!(single->flags & RPP_SINGLE_ADDR_USER_VA))
		return VM_FAULT_SIGBUS;

	res = single->pages[offset >> PAGE_SHIFT];
	get_page(res);
	vmf->page = res;
	return 0;
}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,17,0)
vm_fault_t rpp_pages_vm_fault(struct vm_fault *vmf)
#else
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,11,0)
int rpp_pages_vm_fault(struct vm_fault *vmf)
#else
int rpp_pages_vm_fault(struct vm_area_struct *vma, struct vm_fault *vmf)
#endif
#endif
{
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,11,0)
	struct vm_area_struct *vma = vmf->vma;
#endif
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,10,0)
	uint64_t offset = (uint64_t)vmf->address - vma->vm_start;
#else
	uint64_t offset = (uint64_t)vmf->virtual_address - vma->vm_start;
#endif
	rpp_pages_t *rpp_pages = vma->vm_private_data;
	struct page *res;

	if (offset > rpp_pages->size)
		return VM_FAULT_SIGBUS;

	res = rpp_pages->pages[offset >> PAGE_SHIFT];
	get_page(res);
	vmf->page = res;
	/* ERROR_PRINT("Get page 0x%llx with offset 0x%llx\n", (uint64_t)page_address(res), offset); */

	return 0;
}
