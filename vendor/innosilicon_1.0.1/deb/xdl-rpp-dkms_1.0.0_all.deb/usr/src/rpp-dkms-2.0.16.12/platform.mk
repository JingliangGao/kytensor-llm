# RPP driver platform + variant configuration.
#
# platform: OS/arch preset (linux, euler, loongson, keyarchos, petalinux, rk3568, rk3588)
#           auto-detected or explicit
# variant:  hardware preset (2irq, vpu) -- explicit only; not a platform
#
# Examples:
#   make                              # auto platform, default variant
#   make platform=euler
#   make platform=rk3568
#   make platform=rk3588
#   make variant=vpu
#   make variant=2irq
#
# Legacy: make platform=2irq|vpu -> variant

_rpp_root := $(if $(topdir),$(topdir),$(PWD))
_rpp_detect_script := $(_rpp_root)/detect_platform.sh
_rpp_detected_platform := $(shell sh $(_rpp_detect_script) 2>/dev/null)

platform ?= $(_rpp_detected_platform)
variant ?= default

ifeq ($(platform),)
platform := linux
endif

ifeq ($(platform),2irq)
variant := 2irq
platform := $(if $(_rpp_detected_platform),$(_rpp_detected_platform),linux)
else ifeq ($(platform),vpu)
variant := vpu
platform := $(if $(_rpp_detected_platform),$(_rpp_detected_platform),linux)
endif

_rpp_platform_valid := linux euler loongson keyarchos petalinux rk3568 rk3588

ifeq ($(filter $(platform),$(_rpp_platform_valid)),)
	$(error Unknown platform '$(platform)'. Valid: $(_rpp_platform_valid))
endif

_rpp_variant_valid := default 2irq vpu
ifeq ($(filter $(variant),$(_rpp_variant_valid)),)
	$(error Unknown variant '$(variant)'. Valid: $(_rpp_variant_valid))
endif

ifeq ($(platform),euler)
_RPP_IRQ_NUM := 2
_RPP_BAR_ACCESS_INLINE := 0
_RPP_IDLE_LOW_POWER_ENABLE := 0
else ifeq ($(platform),loongson)
_RPP_IRQ_NUM := 32
_RPP_BAR_ACCESS_INLINE := 0
_RPP_IDLE_LOW_POWER_ENABLE := 0
else ifeq ($(platform),keyarchos)
_RPP_IRQ_NUM := 32
_RPP_BAR_ACCESS_INLINE := 0
_RPP_IDLE_LOW_POWER_ENABLE := 0
else ifeq ($(platform),petalinux)
_RPP_IRQ_NUM := 2
_RPP_BAR_ACCESS_INLINE := 0
_RPP_IDLE_LOW_POWER_ENABLE := 0
else ifeq ($(platform),rk3568)
_RPP_IRQ_NUM := 32
_RPP_BAR_ACCESS_INLINE := 0
_RPP_IDLE_LOW_POWER_ENABLE := 1
else ifeq ($(platform),rk3588)
_RPP_IRQ_NUM := 32
_RPP_BAR_ACCESS_INLINE := 0
_RPP_IDLE_LOW_POWER_ENABLE := 1
else
# linux (default)
_RPP_IRQ_NUM := 32
_RPP_BAR_ACCESS_INLINE := 1
_RPP_IDLE_LOW_POWER_ENABLE := 1
endif

# Variant overrides platform IRQ/BAR/feature flags.
ifeq ($(variant),2irq)
_RPP_IRQ_NUM := 2
else ifeq ($(variant),vpu)
_RPP_IRQ_NUM := 32
_RPP_EXTRA_CFLAGS := -DVPU_HAL_MPU
endif

_RPP_BUILD_VARIANT := $(variant)

ccflags-y += -D'IRQ_NUM=$(_RPP_IRQ_NUM)'
ccflags-y += -D'BAR_ACCESS_INLINE=$(_RPP_BAR_ACCESS_INLINE)'
ccflags-y += -D'RPP_IDLE_LOW_POWER_ENABLE=$(_RPP_IDLE_LOW_POWER_ENABLE)'
ccflags-y += -D'RPP_BUILD_PLATFORM="$(platform)"'
ccflags-y += -D'RPP_BUILD_VARIANT="$(_RPP_BUILD_VARIANT)"'
ifneq ($(_RPP_EXTRA_CFLAGS),)
	ccflags-y += $(_RPP_EXTRA_CFLAGS)
endif

$(info RPP build config: platform=$(platform) variant=$(_RPP_BUILD_VARIANT) IRQ_NUM=$(_RPP_IRQ_NUM) BAR_ACCESS_INLINE=$(_RPP_BAR_ACCESS_INLINE) IDLE_LOW_POWER=$(_RPP_IDLE_LOW_POWER_ENABLE)$(if $(_RPP_EXTRA_CFLAGS), VPU_HAL_MPU=1,))
