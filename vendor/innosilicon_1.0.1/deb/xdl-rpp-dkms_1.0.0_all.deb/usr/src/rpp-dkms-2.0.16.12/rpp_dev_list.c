/*
 * This file is part of the Azurengine DMA IP Core driver for Linux
 *
 * Copyright (c) 2016-present,  Azurengine, Inc.
 * All rights reserved.
 *
 * This source code is licensed under both the BSD-style license (found in the
 * LICENSE file in the root directory of this source tree) and the GPLv2 (found
 * in the COPYING file in the root directory of this source tree).
 * You may select, at your option, one of the above-listed licenses.
 */


#include <linux/list.h>
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/kthread.h>
#include <linux/mm.h>
#include <linux/smp.h>
#include <linux/delay.h>
#include <linux/slab.h>
#include <linux/vmalloc.h>
#include <linux/spinlock.h>
#include <linux/types.h>
#include <asm/atomic.h>
#include <linux/timekeeping.h>

#include "include/rpp_dev_list.h"
#include "include/rpp_com.h"
#include "include/rpp_types.h"

#include "include/rpp_cdev_ctrl.h"
#include "include/rpp_hal_pcie.h"

/* SECTION: Module licensing */

#include "include/rpp_dev.h"
#include "include/pci-dma-compat.h"
#include "include/rpp_sdev.h"

/*
 * rpp device management
 * maintains a list of the rpp devices
 */
static LIST_HEAD(rpp_dev_list);
static DEFINE_MUTEX(rpp_dev_mutex);
#define _DEV_MAX	256
static uint32_t rpp_dev_id_tbl[256] = {0}; /*  0 - not allocated, 1 - allocated */

#ifndef list_last_entry
#define list_last_entry(ptr, type, member) \
		list_entry((ptr)->prev, type, member)
#endif

typedef struct rpp_queues_perf_s {
	struct timespec64 start_wch01;
	struct timespec64 end_wch01;
	struct timespec64 start_rch01;
	struct timespec64 end_rch01;
	
	struct timespec64 start_wch2;
	struct timespec64 end_wch2;
	struct timespec64 start_rch2;
	struct timespec64 end_rch2;

	struct timespec64 start_wch3;
	struct timespec64 end_wch3;
	struct timespec64 start_rch3;
	struct timespec64 end_rch3;
} rpp_queues_perf_t;

rpp_queues_perf_t gqueues_perf;

static int rpp_dev_queues_buf_alloc(struct rpp_dev *pdev)
{	
	unsigned long size = sizeof(rpp_dev_dma_queues_t) + RPP_DEV_PER_CHANNEL_BUFFER_SIZE * RPP_DEV_CHANNEL_COUNT;
	rpp_dev_dma_queues_t* pdma_queues = NULL;
	void* pchxx_queue_base = NULL;

	// align 4k
	size = (size + PAGE_SIZE - 1) / PAGE_SIZE * PAGE_SIZE;

	pdma_queues =(rpp_dev_dma_queues_t*)vmalloc_user(size);
	if (pdma_queues == NULL) {
		ERROR_PRINT("%s, out of memory...\n", __func__);
		return -ENODEV;
	}
	memset(pdma_queues, 0, size);
	
	// initialize
	pchxx_queue_base = (void*)pdma_queues + sizeof(rpp_dev_dma_queues_t);

	pdma_queues->wch0_ch1.size = RPP_DEV_PER_CHANNEL_BUFFER_SIZE;
	pdma_queues->wch0_ch1.buf = pchxx_queue_base;
	pdma_queues->wch0_ch1.qcfg.head = 0;
	pdma_queues->wch0_ch1.qcfg.tail = 0;
	pdma_queues->wch0_ch1.qcfg.max_ne = RPP_DEV_PER_CHANNEL_BUFFER_SIZE / sizeof(rpp_xfer_task_info_t);
	pdma_queues->wch0_ch1.sta = QUEUE_READY;

	pdma_queues->rch0_ch1.size = RPP_DEV_PER_CHANNEL_BUFFER_SIZE;
	pdma_queues->rch0_ch1.buf = pchxx_queue_base + RPP_DEV_PER_CHANNEL_BUFFER_SIZE;
	pdma_queues->rch0_ch1.qcfg.head = 0;
	pdma_queues->rch0_ch1.qcfg.tail = 0;
	pdma_queues->rch0_ch1.qcfg.max_ne = RPP_DEV_PER_CHANNEL_BUFFER_SIZE / sizeof(rpp_xfer_task_info_t);
	pdma_queues->rch0_ch1.sta = QUEUE_READY;

	pdma_queues->wch2.size = RPP_DEV_PER_CHANNEL_BUFFER_SIZE;
	pdma_queues->wch2.buf = pchxx_queue_base + 2 * RPP_DEV_PER_CHANNEL_BUFFER_SIZE;
	pdma_queues->wch2.qcfg.head = 0;
	pdma_queues->wch2.qcfg.tail = 0;
	pdma_queues->wch2.qcfg.max_ne = RPP_DEV_PER_CHANNEL_BUFFER_SIZE / sizeof(rpp_xfer_task_info_t);
	pdma_queues->wch2.sta = QUEUE_READY;

	pdma_queues->rch2.size = RPP_DEV_PER_CHANNEL_BUFFER_SIZE;
	pdma_queues->rch2.buf = pchxx_queue_base + 3 * RPP_DEV_PER_CHANNEL_BUFFER_SIZE;
	pdma_queues->rch2.qcfg.head = 0;
	pdma_queues->rch2.qcfg.tail = 0;
	pdma_queues->rch2.qcfg.max_ne = RPP_DEV_PER_CHANNEL_BUFFER_SIZE / sizeof(rpp_xfer_task_info_t);
	pdma_queues->rch2.sta = QUEUE_READY;

	pdma_queues->wch3.size = RPP_DEV_PER_CHANNEL_BUFFER_SIZE;
	pdma_queues->wch3.buf = pchxx_queue_base + 4 * RPP_DEV_PER_CHANNEL_BUFFER_SIZE;
	pdma_queues->wch3.qcfg.head = 0;
	pdma_queues->wch3.qcfg.tail = 0;
	pdma_queues->wch3.qcfg.max_ne = RPP_DEV_PER_CHANNEL_BUFFER_SIZE / sizeof(rpp_xfer_task_info_t);
	pdma_queues->wch3.sta = QUEUE_READY;

	pdma_queues->rch3.size = RPP_DEV_PER_CHANNEL_BUFFER_SIZE;
	pdma_queues->rch3.buf = pchxx_queue_base + 5 * RPP_DEV_PER_CHANNEL_BUFFER_SIZE;
	pdma_queues->rch3.qcfg.head = 0;
	pdma_queues->rch3.qcfg.tail = 0;
	pdma_queues->rch3.qcfg.max_ne = RPP_DEV_PER_CHANNEL_BUFFER_SIZE / sizeof(rpp_xfer_task_info_t);
	pdma_queues->rch3.sta = QUEUE_READY;

	pdma_queues->size = size;
	pdev->dma_queues = pdma_queues;
	pdev->dma_sem_status = SEMA_POST;

	DEV_INFO(pdev, "vmalloc_user size 0x%lx addr 0x%lx\n", size, pdma_queues);

	return 0;
}

static void rpp_dev_queues_buf_free(struct rpp_dev *pdev)
{	
	DEV_INFO(pdev, "vfree addr 0x%lx\n", pdev->dma_queues);

	if (pdev->dma_queues) {
		vfree((void*)pdev->dma_queues);
		pdev->dma_queues = NULL;
	}
}

void rpp_dev_list_add(struct rpp_dev *pdev)
{
	uint32_t i = 0;
	mutex_lock(&rpp_dev_mutex);
	for (i = 0; i < _DEV_MAX; i++) {
		if (rpp_dev_id_tbl[i] == 0) {
			pdev->idx = i;
			rpp_dev_id_tbl[i] = 1; /*  allocated the id */
			break;
		}
	}

	if (i >= _DEV_MAX) {
		ERROR_PRINT("%s, out of device id\n", __func__, i);
		return;
	}

	list_add_tail(&pdev->list_head, &rpp_dev_list);

	if (rpp_dev_queues_buf_alloc(pdev) != 0) {
		ERROR_PRINT("%s, rpp_drv_tasks_buf_alloc failed\n", __func__);
	}

	mutex_unlock(&rpp_dev_mutex);
}

static int rpp_get_parent_pci_info(struct rpp_dev *pdev, rpp_pcie_link_t *lnk_attr)
{
	uint32_t lnkcap, lnksta;
	struct pci_bus *parent_bus = NULL;
	rpp_switch_t *rpp_switch;

	if (pdev == NULL || pdev->pdev == NULL) {
		ERROR_PRINT("%s input pdev or pdev->pdev NULL\n", __func__);
		return -EINVAL;
	}

	/* 优先使用 parent_switch，避免跨 .o 函数返回时可能的指针截断 */
	rpp_switch = pdev->parent_switch;
	if (rpp_switch == NULL)
		rpp_switch = rpp_sdev_search_by_devices(pdev);
	if (rpp_switch != NULL) {
		lnk_attr->cap_width = (rpp_switch->lnkcap & PCI_EXP_LNKCAP_MLW) >> 4;  // capability width
		lnk_attr->cap_speed = rpp_switch->lnkcap & PCI_EXP_LNKCAP_SLS;         // capability speed

		lnk_attr->sta_width = (rpp_switch->lnksta & PCI_EXP_LNKSTA_NLW) >> 4;  // current width
		lnk_attr->sta_speed = rpp_switch->lnksta & PCI_EXP_LNKSTA_CLS;         // current speed

		DEV_DEBUG(pdev, "Parent Cap max: width: %d speed: %d \n", lnk_attr->cap_width, lnk_attr->cap_speed);
		DEV_DEBUG(pdev, "Parent Cur sta: width: %d speed: %d \n", lnk_attr->sta_width, lnk_attr->sta_speed);

		INFO_PRINT("Parent Cap max: width: %d speed: %d \n", lnk_attr->cap_width, lnk_attr->cap_speed);
		INFO_PRINT("Parent Cur sta: width: %d speed: %d \n", lnk_attr->sta_width, lnk_attr->sta_speed);
	}
	else {
		// DEV_ERROR(pdev, "get switch info failed\n");
		return -EINVAL;
	}

	return 0;
}

static void rpp_get_this_pci_info(struct rpp_dev *pdev, rpp_pcie_link_t *lnk_attr)
{
	uint32_t lnkcap;
	uint16_t lnksta;

	// get parent pci bus link attr
	pcie_capability_read_dword(pdev->pdev, PCI_EXP_LNKCAP, &lnkcap);
	lnk_attr->cap_width = (lnkcap & PCI_EXP_LNKCAP_MLW) >> 4;  // capability width
	lnk_attr->cap_speed = lnkcap & PCI_EXP_LNKCAP_SLS;         // capability speed

	pcie_capability_read_word(pdev->pdev, PCI_EXP_LNKSTA, &lnksta);
	lnk_attr->sta_width = (lnksta & PCI_EXP_LNKSTA_NLW) >> 4;  // current width
	lnk_attr->sta_speed = lnksta & PCI_EXP_LNKSTA_CLS;         // current speed

	INFO_PRINT("Cap max: width: %d speed: %d \n", lnk_attr->cap_width, lnk_attr->cap_speed);
	INFO_PRINT("Cur sta: width: %d speed: %d \n", lnk_attr->sta_width, lnk_attr->sta_speed);
}

/* idx = 0 ~ xxx */
static struct rpp_dev *rpp_get_device_with_idx(int idx)
{
	struct rpp_dev *RPPdev, *tmp;

	if(idx >= RPP_DEV_MAX_COUNT){
		return NULL;
	}

	mutex_lock(&rpp_dev_mutex);
	if (list_empty(&rpp_dev_list)) {
		mutex_unlock(&rpp_dev_mutex);
		return NULL;
	}

	list_for_each_entry_safe(RPPdev, tmp, &rpp_dev_list, list_head) {
		// INFO_PRINT("%s, list device id 0x%x\n", __func__, RPPdev->idx);
		if(RPPdev->idx >= RPP_DEV_MAX_COUNT){
			DEV_ERROR(RPPdev, "%s, the number of devices 0x%x out of max count 0x%x\n", RPPdev->idx, RPP_DEV_MAX_COUNT);
			RPPdev = NULL;
			break;
		}

		if (RPPdev->idx == idx) {
			break;
		}
	}
	mutex_unlock(&rpp_dev_mutex);

	return RPPdev;
}

static int rpp_get_max_device_idx(void) 
{
	struct rpp_dev *last;
	int idx = 0;

	mutex_lock(&rpp_dev_mutex);
	if (list_empty(&rpp_dev_list)) {
		mutex_unlock(&rpp_dev_mutex);
		return 0;
	}

	last = list_last_entry(&rpp_dev_list, struct rpp_dev, list_head);
	idx = last->idx;
	mutex_unlock(&rpp_dev_mutex);

	return idx;
}

#undef list_last_entry

void rpp_dev_list_remove(struct rpp_dev *pdev)
{
	mutex_lock(&rpp_dev_mutex);
	rpp_dev_id_tbl[pdev->idx] = 0; /*  release the id */
	list_del(&pdev->list_head);
	rpp_dev_queues_buf_free(pdev);

	mutex_unlock(&rpp_dev_mutex);

}

struct rpp_dev *xdev_find_by_pdev(struct pci_dev *pdev)
{
        struct rpp_dev *RPPdev, *tmp;

        mutex_lock(&rpp_dev_mutex);
        list_for_each_entry_safe(RPPdev, tmp, &rpp_dev_list, list_head) {
                if (RPPdev->pdev == pdev) {
                        mutex_unlock(&rpp_dev_mutex);
                        return RPPdev;
                }
        }
        mutex_unlock(&rpp_dev_mutex);
        return NULL;
}

struct rpp_dev *xdev_find_by_cdev_devno(dev_t devno)
{
        struct rpp_dev *RPPdev, *tmp;

        mutex_lock(&rpp_dev_mutex);
        list_for_each_entry_safe(RPPdev, tmp, &rpp_dev_list, list_head) {
		DEV_ERROR(RPPdev, "%s, rdev=0x%p, size=0x%x, xcdev=0x%p, cdev=0x%p\n", __func__, RPPdev, sizeof(struct rpp_dev), &RPPdev->entire_ctrl_cdev, &RPPdev->entire_ctrl_cdev.cdev);
                if (RPPdev->entire_ctrl_cdev.cdevno == devno) {
                        mutex_unlock(&rpp_dev_mutex);
                        return RPPdev;
                }
        }
        mutex_unlock(&rpp_dev_mutex);
        return NULL;
}



static inline int debug_check_dev_hndl(const char *fname, struct pci_dev *pdev,
				 void *hndl)
{
	struct rpp_dev *RPPdev;

	if (!pdev)
		return -EINVAL;

	RPPdev = xdev_find_by_pdev(pdev);
	if (!RPPdev) {
		INFO_PRINT("%s pdev 0x%p, hndl 0x%p, NO match found!\n",
			fname, pdev, hndl);
		return -EINVAL;
	}
	if (RPPdev != hndl) {
		DEV_ERROR(RPPdev, "%s pdev 0x%p, hndl 0x%p != 0x%p!\n",
			fname, pdev, hndl, RPPdev);
		return -EINVAL;
	}

	return 0;
}

/*******************************************************************************
 * @brief rpp_pcie_dma_tasks
 *******************************************************************************/
#define PCIE_DMA_KTHREAD_ONLINE					0x0
#define PCIE_DMA_KTHREAD_OFFLINE				0x1

static struct task_struct *pcie_dma_kthread = NULL; 
static wait_queue_head_t pcie_dma_wq;
static volatile int pcie_dma_flag = 0;
struct semaphore pcie_dma_sem;
static int pcie_dma_sem_is_valid = 0;  						// 0 - not init, 1 - init
static int pcie_lane_speed[5] = {0, 25, 50, 80, 160};   	// per lane speed atgen 1 ~ 4 * 10 avoid float

// void rpp_sync_sgt_for_cpu(struct rpp_dev *pdev, rpp_pages_t *rpp_pages);
// void rpp_sync_sgt_for_device(struct rpp_dev *pdev, rpp_pages_t *rpp_pages);
rpp_pages_t *rpp_pages_dma_alloc(struct rpp_dev *pdev, uint64_t size, rpp_xfer_done_ctx_t *ctx) 
{
	rpp_pages_t *rpp_pages;
	unsigned int i;
	void *virt_addr = NULL;
	int rv;
	struct dma_mapped_blk *mapped_blk = NULL;
	struct scatterlist *sg, *start;
	uint64_t prev_dma_address;
	uint32_t prev_dma_length;
	void *kdata = NULL;
	uint32_t ksize;

	/* avoid all sorts of integer overflows possible otherwise. */
	if (size >= (1ULL << 36))
		return NULL;
	if (!size)
		return NULL;

	if (ctx == NULL) 
		return NULL;

	rpp_pages = kzalloc(sizeof(rpp_pages_t), GFP_KERNEL);
	if (!rpp_pages)
		return NULL;

	rpp_pages->idr_type = RPP_IDR_OBJ_PAGES;
	virt_addr = vmalloc(size);
    if (!virt_addr)
        goto err_out;

	// align PAGE_SIZE, calc page number
	rpp_pages->size =  (size + PAGE_SIZE - 1) / PAGE_SIZE * PAGE_SIZE;
	rpp_pages->pages_nr = rpp_pages->size >> PAGE_SHIFT;

	if (rpp_pages->pages_nr * sizeof *rpp_pages->pages > MAX_KMALLOC_SIZE) {
		rpp_pages->pages = vmalloc(rpp_pages->pages_nr * sizeof *rpp_pages->pages);
	} else {
		rpp_pages->pages = kmalloc(rpp_pages->pages_nr * sizeof *rpp_pages->pages, GFP_KERNEL);
	}
	if (!rpp_pages->pages) {
		goto err_out;
	}

	// fill the page array
	for (i = 0; i < rpp_pages->pages_nr; i++) {
        rpp_pages->pages[i] = vmalloc_to_page(virt_addr + (i << PAGE_SHIFT));
        if (!rpp_pages->pages[i]) {
            goto err_out;
        }
    }

	if (sg_alloc_table_from_pages(&rpp_pages->sgt, rpp_pages->pages, rpp_pages->pages_nr, 0, size, GFP_KERNEL)) {
		ERROR_PRINT("sgl OOM.\n");
		goto err_out;
	}

	sg = rpp_pages->sgt.sgl;
	rv = pci_map_sg(pdev->pdev, sg, rpp_pages->sgt.orig_nents, PCI_DMA_BIDIRECTIONAL);
	if (rv < 0) {
		ERROR_PRINT("unable to pin down %u user pages, %d.\n",
			rpp_pages->pages_nr, rv);
		goto err_out;
	}
	rpp_pages->mapped_nents = rv;
	
	// fill dma_mapped_blk for rpp_pages
	ksize = rpp_pages->mapped_nents * sizeof(struct dma_mapped_blk);
	if (ksize > MAX_KMALLOC_SIZE) {
		// large block, use vmalloc
		kdata = vmalloc(ksize);
	} else {
		kdata = kmalloc(ksize, GFP_KERNEL);
	}
	if (!kdata) {
		goto err_out;
	}

	mapped_blk = (struct dma_mapped_blk *)kdata;
	prev_dma_address = 0;
	prev_dma_length = 0;
	start = rpp_pages->sgt.sgl;
	i = 0;

	for_each_sg(start, sg, rpp_pages->mapped_nents, i) {
		if ((prev_dma_address + (uint64_t)prev_dma_length) == cpu_to_le64((u64)sg_dma_address(sg))) {
			// continued dma address
			prev_dma_address = cpu_to_le64((u64)sg_dma_address(sg));
			prev_dma_length = cpu_to_le32((u32)sg_dma_len(sg));

			mapped_blk--;
			mapped_blk->dma_length += prev_dma_length;
			mapped_blk++;

			// ERROR_PRINT("%d, dma_address=0x%llx, dma_length=0x%x\n", rpp_pages->mapped_num, prev_dma_address, prev_dma_length);
			continue;
		} else {
			// non-continued dma address
			mapped_blk->dma_address = cpu_to_le64((u64)sg_dma_address(sg));
			mapped_blk->dma_length = cpu_to_le32((u32)sg_dma_len(sg));
			prev_dma_address = mapped_blk->dma_address;
			prev_dma_length = mapped_blk->dma_length;
			// ERROR_PRINT("%d, dma_address=0x%llx, dma_length=0x%x\n", rpp_pages->mapped_num, mapped_blk->dma_address, mapped_blk->dma_length);
			rpp_pages->mapped_num++;
        	mapped_blk++;
		}
    }

	if ((rpp_pages->mapped_num * sizeof(struct dma_mapped_blk)) > MAX_KMALLOC_SIZE) {
		rpp_pages->mapped_blk = (PBLK_ELEMENT)vmalloc(rpp_pages->mapped_num * sizeof(struct dma_mapped_blk));
	} else {
		rpp_pages->mapped_blk = (PBLK_ELEMENT)kmalloc(rpp_pages->mapped_num * sizeof(struct dma_mapped_blk), GFP_KERNEL);
	}
	if (!rpp_pages->mapped_blk) {
		goto err_out;
	}
	memcpy((void *)rpp_pages->mapped_blk, (void *)kdata, rpp_pages->mapped_num * sizeof(struct dma_mapped_blk));

	// set id from idr
#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,9,0)
	idr_preload(GFP_KERNEL);
	spin_lock(&pdev->idr_lock);
	ctx->khost_handle = idr_alloc(&pdev->idr, rpp_pages, 1, 0, GFP_NOWAIT);
	spin_unlock(&pdev->idr_lock);
	idr_preload_end();
#else
	int ret;
retry:
	if (!idr_pre_get(&pdev->idr, GFP_KERNEL)) {
		goto err_out;
	}

	spin_lock(&pdev->idr_lock);
	ret = idr_get_new(&pdev->idr, rpp_pages, &ctx->khost_handle);
	spin_unlock(&pdev->idr_lock);

	if (ret == -EAGAIN)
		goto retry;

	if (ret < 0)
		return 0;
#endif

	if (ctx->khost_handle < 0)
		goto err_out;
	ctx->virt_addr = virt_addr;
	ctx->sta = 1;
		
	return rpp_pages;

err_out:
	if (ksize > MAX_KMALLOC_SIZE) {
		vfree(kdata);
	} else {
		kfree(kdata);
	}

	if (rpp_pages->pages) {
		if (rpp_pages->pages_nr * sizeof *rpp_pages->pages > MAX_KMALLOC_SIZE) {
			vfree(rpp_pages->pages);
		} else {
			kfree(rpp_pages->pages);
		}
	}

	if (virt_addr)
		vfree(virt_addr);

	if (rpp_pages)
		kfree(rpp_pages);

	return NULL;
}

void rpp_pages_dma_free(struct rpp_dev *pdev, rpp_xfer_done_ctx_t *ctx)
{
	rpp_pages_t *rpp_pages;
	unsigned long rv = 0;

	if (ctx == NULL)
		ERROR_PRINT("%s, invalid parameter ctx null\n", __func__);

	if (ctx->sta == 1) {
		if (ctx->dirc == DMA_WRITE) { 
			// DtoH
			rv = copy_to_user((void __user *)ctx->uhost_addr, ctx->virt_addr, 0x10);
			if (rv != 0) {
				ERROR_PRINT("%s, copy_to_user failed rv 0x%llx size 0x%llx\n", __func__, rv, ctx->size);
			} 
		}

		spin_lock(&pdev->idr_lock);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,11,0)
		rpp_pages = (rpp_pages_t *)idr_remove(&pdev->idr, ctx->khost_handle);
#else
		rpp_pages = (rpp_pages_t *)idr_find(&pdev->idr, info->handle);
		idr_remove(&pdev->idr, info->handle);
#endif
		spin_unlock(&pdev->idr_lock);
		if (NULL == rpp_pages)
			return ;

		if ((rpp_pages->mapped_num * sizeof(struct dma_mapped_blk)) > MAX_KMALLOC_SIZE) {
			vfree(rpp_pages->mapped_blk);
		} else {
			kfree(rpp_pages->mapped_blk);
		}

		if (rpp_pages->pages_nr * sizeof *rpp_pages->pages > MAX_KMALLOC_SIZE) {
			vfree(rpp_pages->pages);
		} else {
			kfree(rpp_pages->pages);
		}

		kfree(rpp_pages);

		memset((void*)ctx, 0, sizeof(rpp_xfer_done_ctx_t));
	}
}

int rpp_xfer_task(struct rpp_dev *pdev, rpp_xfer_task_info_t *info)
{
	rpp_pages_t *rpp_pages;
	struct scatterlist *start, *sg;
    uint32_t dma_offs = 0;
	uint32_t xfered = 0;
	uint32_t xfer_size = 0;
	uint64_t dev_addr = 0;
	uint32_t offs_in_sg = 0;
	unsigned long len;
	uint32_t i = 0;
	ssize_t res = 0;
	unsigned long rv = 0;
	// bool write = 0; // 0, DtoH; 1, HtoD

	PBLK_ELEMENT temp_blk;
	uint32_t offs_in_blk = 0;
	uint8_t rewrite_cnt = 0;
	unsigned int dma_length = 0;
	DMA_BLKS_INFO blk_info;

	rpp_dev_semaphore_wait(pdev);

	// FIXME check PCIE status 0x04 reg on windows
	// INFO_PRINT("info: mapped 0x%x, dirc 0x%x, chan %d, host_addr 0x%llx, host_handle 0x%x, host_offs 0x%llx, dev_addr 0x%llx, size 0x%x\n", 
	// 	info->mapped, info->dirc, info->chan, info->host_addr, info->host_handle, info->host_offs, info->dev_addr, info->size);

#ifdef __LIBRPP_PROFILING__
	uint64_t n;

	if (info->dirc == DMA_WRITE) { 
		// DtoH
		if (info->chan == CH0_CH1) {
			ktime_get_real_ts64(&gqueues_perf.start_rch01);
			n = gqueues_perf.start_rch01.tv_sec*1000000000 + gqueues_perf.start_rch01.tv_nsec;
		} 
		else if (info->chan == CH2) {
			ktime_get_real_ts64(&gqueues_perf.start_rch2);
			n = gqueues_perf.start_rch2.tv_sec*1000000000 + gqueues_perf.start_rch2.tv_nsec;
		}
		else if (info->chan == CH3) {
			ktime_get_real_ts64(&gqueues_perf.start_rch3);
			n = gqueues_perf.start_rch3.tv_sec*1000000000 + gqueues_perf.start_rch3.tv_nsec;
		}
	} 
	else {
		// HtoD
		if (info->chan == CH0_CH1) {
			ktime_get_real_ts64(&gqueues_perf.start_wch01);
			n = gqueues_perf.start_wch01.tv_sec*1000000000 + gqueues_perf.start_wch01.tv_nsec;
		} 
		else if (info->chan == CH2) {
			ktime_get_real_ts64(&gqueues_perf.start_wch2);
			n = gqueues_perf.start_wch2.tv_sec*1000000000 + gqueues_perf.start_wch2.tv_nsec;
		}
		else if (info->chan == CH3) {
			ktime_get_real_ts64(&gqueues_perf.start_wch3);
			n = gqueues_perf.start_wch3.tv_sec*1000000000 + gqueues_perf.start_wch3.tv_nsec;
		}
	}
	DEV_DEBUG(pdev, "%s, %s chan %d start_in_us %lld\n", __func__, info->dirc == DMA_WRITE ? "DtoH" : "HtoD", info->chan, n);
#endif

	if (info->mapped == MAPPED) {
		spin_lock(&pdev->idr_lock);
		rpp_pages = (rpp_pages_t *)idr_find(&pdev->idr, info->host_handle);
		spin_unlock(&pdev->idr_lock);
		if (NULL == rpp_pages) {
			DEV_ERROR(pdev, "%s, can't find pages, info->host_handle=0x%x\n", __func__, info->host_handle);
			return -EINVAL;
		}

		if ((info->size == 0) || \
			((info->host_offs + info->size) > rpp_pages->size)) {
			ERROR_PRINT("Size error, bo_size 0x%x, host_offs 0x%x, trans_size 0x%x, \n", rpp_pages->size, info->host_offs, info->size);
			return -EPROTO;
		}
	} 
	else {
		ERROR_PRINT("Not support unmapped memory async copy\n");
		return -EINVAL;
	}	

	// PCIe dma copy
	dev_addr = info->dev_addr;

#if 0
		start = rpp_pages->sgt.sgl;
		for_each_sg(start, sg, rpp_pages->mapped_nents, i) {
			unsigned int dma_length = cpu_to_le32((u32)sg_dma_len(sg));

			if ((dma_offs+dma_length) < info->host_offs) {
				continue;
			}

			offs_in_sg = xfered + info->host_offs - dma_offs;
			xfer_size = ((info->size - xfered) < (dma_length - offs_in_sg) ?
				(info->size - xfered) : (dma_length - offs_in_sg));
			//DEBUG_PRINT("%d, offs_in_sg=0x%x, xfer_size=0x%x, dev_addr=0x%llx\n", i, offs_in_sg, xfer_size, dev_addr);
			res = rpp_xfer_single(pdev, sg_dma_address(sg) + offs_in_sg, dev_addr, xfer_size, write, 1, 0);

			xfered += xfer_size;
			dev_addr += xfer_size;
			dma_offs += dma_length;

			if (xfered >= info->size) {
				break;
			}
		}
#else
		if(rpp_pages->mapped_blk == NULL) {
			DEV_ERROR(pdev, "%s, mapped block failed: mapped_blk(0x%llx)\n", __func__, rpp_pages->mapped_blk);
			return -EINVAL;
		}

		blk_info.start = 0;
		blk_info.vail_num = 0;
		blk_info.start_offs = 0;
		blk_info.end_size = 0;
		blk_info.mapped_blk = rpp_pages->mapped_blk;
		blk_info.mapped_num = rpp_pages->mapped_num;
		temp_blk = blk_info.mapped_blk;

		for(i = 0; i < blk_info.mapped_num; i++) {
			dma_length = temp_blk->dma_length;
			temp_blk++;

			dma_offs += dma_length;
			if (dma_offs < info->host_offs) {
				blk_info.start++;
				continue;
			}

			// for first dma_offs >= info->host_offs
			// case 1 dma_offs > info->host_offs
			// case 2 dma_offs = info->host_offs
			if(rewrite_cnt == 0) {
				rewrite_cnt++;
				if(dma_offs > info->host_offs) {
					blk_info.start_offs = info->host_offs - (dma_offs - dma_length);
					offs_in_blk = blk_info.start_offs;
				}
				else {
					blk_info.start++;
					continue;
				}
			}

			xfer_size = ((info->size - xfered) < (dma_length - offs_in_blk) ?
				(info->size - xfered) : (dma_length - offs_in_blk));

			offs_in_blk = 0;
			xfered += xfer_size;
			blk_info.vail_num++;

			if(xfered >= info->size) {
				blk_info.end_size = xfer_size;
				break;
			}
		}

		DTRACE("%s, blk info: num 0x%x, start 0x%x, vail_num 0x%x, start_offs 0x%x, end_size 0x%x\n",
			__func__, blk_info.mapped_num, blk_info.start, blk_info.vail_num, blk_info.start_offs, blk_info.end_size);
			
		res = rpp_xfer_blks_async(pdev, info->chan, &blk_info, dev_addr, info->size, info->dirc, 0);
#endif

	// if (info->mapped == UNMAPPED) {
	// 	// copy to user
	// 	rpp_pages_dma_free(pdev, &xfer_done);
	// }

	return 0;
}

void rpp_wch0_ch1_xfer_done(struct rpp_dev *pdev, void *cb_ctx)
{
	rpp_dev_dma_queue_t *pque = NULL;

	if (pdev->dma_queues == NULL) {
		return;
	}

#ifdef __LIBRPP_PROFILING__
	uint64_t n;
	ktime_get_real_ts64(&gqueues_perf.end_wch01);
	n = gqueues_perf.end_wch01.tv_sec*1000000000 + gqueues_perf.end_wch01.tv_nsec;
	DEV_DEBUG(pdev, "%s, end_in_us %lld\n", __func__, n);

	n = (gqueues_perf.end_wch01.tv_sec - gqueues_perf.start_wch01.tv_sec)*1000000000 + (gqueues_perf.end_wch01.tv_nsec - gqueues_perf.start_wch01.tv_nsec);
	DEV_DEBUG(pdev, "%s, total %lldns\n", __func__, n);
#endif	

	// channel 0/1
	pque = &pdev->dma_queues->wch0_ch1;

	// pque->qcfg.head++;
	// rpp_pages_dma_free(pdev, &pque->xctx);
	pque->sta = QUEUE_READY;

	DEBUG_PRINT("isr HtoD channel 0/1\n");
}

void rpp_rch0_ch1_xfer_done(struct rpp_dev *pdev, void *cb_ctx)
{
	rpp_dev_dma_queue_t *pque = NULL;

	if (pdev->dma_queues == NULL) {
		return;
	}

#ifdef __LIBRPP_PROFILING__
	uint64_t n;
	ktime_get_real_ts64(&gqueues_perf.end_rch01);
	n = gqueues_perf.end_rch01.tv_sec*1000000000 + gqueues_perf.end_rch01.tv_nsec;
	DEV_DEBUG(pdev, "%s, end_in_us %lld\n", __func__, n);

	n = (gqueues_perf.end_rch01.tv_sec - gqueues_perf.start_rch01.tv_sec)*1000000000 + (gqueues_perf.end_rch01.tv_nsec - gqueues_perf.start_rch01.tv_nsec);
	DEV_DEBUG(pdev, "%s, total %lldns\n", __func__, n);
#endif		

	// channel 0/1
	pque = &pdev->dma_queues->rch0_ch1;

	// pque->qcfg.head++;
	// rpp_pages_dma_free(pdev, &pque->xctx);
	pque->sta = QUEUE_READY;

	DEBUG_PRINT("isr DtoH channel 0/1\n");
}

void rpp_wch2_xfer_done(struct rpp_dev *pdev, void *cb_ctx)
{
	rpp_dev_dma_queue_t *pque = NULL;

	if (pdev->dma_queues == NULL) {
		return;
	}

#ifdef __LIBRPP_PROFILING__
	uint64_t n;
	ktime_get_real_ts64(&gqueues_perf.end_wch2);
	n = gqueues_perf.end_wch2.tv_sec*1000000000 + gqueues_perf.end_wch2.tv_nsec;
	DEV_DEBUG(pdev, "%s, end_in_us %lld\n", __func__, n);

	n = (gqueues_perf.end_wch2.tv_sec - gqueues_perf.start_wch2.tv_sec)*1000000000 + (gqueues_perf.end_wch2.tv_nsec - gqueues_perf.start_wch2.tv_nsec);
	DEV_DEBUG(pdev, "%s, total %lldns\n", __func__, n);
#endif

	// channel 2
	pque = &pdev->dma_queues->wch2;

	// pque->qcfg.head++;
	// rpp_pages_dma_free(pdev, &pque->xctx);
	pque->sta = QUEUE_READY;

	DEBUG_PRINT("isr HtoD channel 2\n");
}

void rpp_rch2_xfer_done(struct rpp_dev *pdev, void *cb_ctx)
{
	rpp_dev_dma_queue_t *pque = NULL;

	if (pdev->dma_queues == NULL) {
		return;
	}

#ifdef __LIBRPP_PROFILING__
	uint64_t n;
	ktime_get_real_ts64(&gqueues_perf.end_rch2);
	n = gqueues_perf.end_rch2.tv_sec*1000000000 + gqueues_perf.end_rch2.tv_nsec;
	DEV_DEBUG(pdev, "%s, end_in_us %lld\n", __func__, n);

	n = (gqueues_perf.end_rch2.tv_sec - gqueues_perf.start_rch2.tv_sec)*1000000000 + (gqueues_perf.end_rch2.tv_nsec - gqueues_perf.start_rch2.tv_nsec);
	DEV_DEBUG(pdev, "%s, total %lldns\n", __func__, n);
#endif

	// channel 2
	pque = &pdev->dma_queues->rch2;

	// pque->qcfg.head++;
	// rpp_pages_dma_free(pdev, &pque->xctx);
	pque->sta = QUEUE_READY;

	DEBUG_PRINT("isr DtoH channel 2\n");
}

void rpp_wch3_xfer_done(struct rpp_dev *pdev, void *cb_ctx)
{
	rpp_dev_dma_queue_t *pque = NULL;

	if (pdev->dma_queues == NULL) {
		return;
	}

#ifdef __LIBRPP_PROFILING__
	uint64_t n;
	ktime_get_real_ts64(&gqueues_perf.end_wch3);
	n = gqueues_perf.end_wch3.tv_sec*1000000000 + gqueues_perf.end_wch3.tv_nsec;
	DEV_DEBUG(pdev, "%s, end_in_us %lld\n", __func__, n);

	n = (gqueues_perf.end_wch3.tv_sec - gqueues_perf.start_wch3.tv_sec)*1000000000 + (gqueues_perf.end_wch3.tv_nsec - gqueues_perf.start_wch3.tv_nsec);
	DEV_DEBUG(pdev, "%s, total %lldns\n", __func__, n);
#endif

	// channel 3
	pque = &pdev->dma_queues->wch3;

	// pque->qcfg.head++;
	// rpp_pages_dma_free(pdev, &pque->xctx);
	pque->sta = QUEUE_READY;

	DEBUG_PRINT("isr DtoH channel 3\n");
}

void rpp_rch3_xfer_done(struct rpp_dev *pdev, void *cb_ctx)
{
	rpp_dev_dma_queue_t *pque = NULL;

	if (pdev->dma_queues == NULL) {
		return;
	}

#ifdef __LIBRPP_PROFILING__
	uint64_t n;
	ktime_get_real_ts64(&gqueues_perf.end_rch3);
	n = gqueues_perf.end_rch3.tv_sec*1000000000 + gqueues_perf.end_rch3.tv_nsec;
	DEV_DEBUG(pdev, "%s, end_in_us %lld\n", __func__, n);

	n = (gqueues_perf.end_rch3.tv_sec - gqueues_perf.start_rch3.tv_sec)*1000000000 + (gqueues_perf.end_rch3.tv_nsec - gqueues_perf.start_rch3.tv_nsec);
	DEV_DEBUG(pdev, "%s, total %lldns\n", __func__, n);
#endif	

	// channel 3
	pque = &pdev->dma_queues->rch3;

	// pque->qcfg.head++;
	// rpp_pages_dma_free(pdev, &pque->xctx);
	pque->sta = QUEUE_READY;

	DEBUG_PRINT("isr DtoH channel 3\n");
}

void rpp_dev_semaphore_init(struct rpp_dev *pdev)
{	
	rpp_pcie_link_t parent_lnk_attr;
	rpp_pcie_link_t lnk_attr;
	int val = 1;

	if (pcie_dma_sem_is_valid == 1) {
		return;
	}

	if(rpp_get_parent_pci_info(pdev, &parent_lnk_attr) == 0) {
		rpp_get_this_pci_info(pdev, &lnk_attr);
		val = (int)((pcie_lane_speed[parent_lnk_attr.sta_speed] * parent_lnk_attr.sta_width) / 
			  (pcie_lane_speed[lnk_attr.sta_speed] * lnk_attr.sta_width));
		sema_init(&pcie_dma_sem, val);
		pcie_dma_sem_is_valid = 1;

		ERROR_PRINT("semaphore val %d\n", val);
	} 
}

void rpp_dev_semaphore_destroy(void)
{
	if (pcie_dma_sem_is_valid) {
		// sema_destroy(&pcie_dma_sem);
		pcie_dma_sem_is_valid = 0;
	}
}

void rpp_dev_semaphore_wait(struct rpp_dev *pdev)
{
	if (pcie_dma_sem_is_valid == 0) {
		return;
	}

	if (pdev->dma_sem_status != SEMA_WAIT) {
		pdev->dma_sem_status = SEMA_WAIT;
		down_interruptible(&pcie_dma_sem);
	}
}

void rpp_dev_semaphore_post(struct rpp_dev *pdev)
{
	rpp_dev_dma_queue_t *pque1 = NULL;
	rpp_dev_dma_queue_t *pque2 = NULL;
	rpp_dev_dma_queue_t *pque3 = NULL;
	rpp_dev_dma_queue_t *pque4 = NULL;
	rpp_dev_dma_queue_t *pque5 = NULL;
	rpp_dev_dma_queue_t *pque6 = NULL;

	if (pcie_dma_sem_is_valid == 0) {
		return;
	}

	if (pdev->dma_queues == NULL) {
		return;
	}

	// all tasks is done for this device
	pque1 = &pdev->dma_queues->wch0_ch1;
	pque2 = &pdev->dma_queues->rch0_ch1;
	pque3 = &pdev->dma_queues->wch2;
	pque4 = &pdev->dma_queues->rch2;
	pque5 = &pdev->dma_queues->wch3;
	pque6 = &pdev->dma_queues->rch3;
	if (pque1->sta == QUEUE_READY && pque2->sta == QUEUE_READY &&
		pque3->sta == QUEUE_READY && pque4->sta == QUEUE_READY &&
		pque5->sta == QUEUE_READY && pque6->sta == QUEUE_READY) {
		if (pdev->dma_sem_status != SEMA_POST) {
			pdev->dma_sem_status = SEMA_POST;
			up(&pcie_dma_sem);
		}
	}
}

int rpp_xfer_dev_queues_running(struct rpp_dev *pdev, uint8_t *flag)
{
	rpp_dev_dma_queue_t *pque = NULL;
	rpp_xfer_task_info_t *ptask_base = NULL;
	rpp_xfer_task_info_t *ptask = NULL;
	uint8_t empty_flag = 0;
	int ret = 0;

	// channel 0/1
	pque = &pdev->dma_queues->wch0_ch1;
	ptask_base = (rpp_xfer_task_info_t*)pque->buf;
	if (pque->qcfg.head < pque->qcfg.tail) {
		if (pque->sta == QUEUE_READY) {
			// INFO_PRINT("wch0_ch1 head %lld, tail %lld\n", pque->qcfg.head, pque->qcfg.tail);
			pque->sta = QUEUE_IN_USE;

			ptask = &ptask_base[pque->qcfg.head % pque->qcfg.max_ne];
			ret = rpp_xfer_task(pdev, ptask);
			if (ret != 0) {
				DEV_ERROR(pdev, "%s, channel 0/1 H2D failed\n", __func__);
			}

			pque->qcfg.head++;
		}
		SET_BIT(empty_flag, 0);
	}

	pque = &pdev->dma_queues->rch0_ch1;
	ptask_base = (rpp_xfer_task_info_t*)pque->buf;
	if (pque->qcfg.head < pque->qcfg.tail) {
		if (pque->sta == QUEUE_READY) {
			// INFO_PRINT("rch0_ch1 head %lld, tail %lld\n", pque->qcfg.head, pque->qcfg.tail);
			pque->sta = QUEUE_IN_USE;

			ptask = &ptask_base[pque->qcfg.head % pque->qcfg.max_ne];
			ret = rpp_xfer_task(pdev, ptask);
			if (ret != 0) {
				DEV_ERROR(pdev, "%s, channel 0/1 D2H failed\n", __func__);
			}

			pque->qcfg.head++;
		}
		SET_BIT(empty_flag, 1);
	}

	// channel 2
	pque = &pdev->dma_queues->wch2;
	ptask_base = (rpp_xfer_task_info_t*)pque->buf;
	if (pque->qcfg.head < pque->qcfg.tail) {
		if (pque->sta == QUEUE_READY) {
			// INFO_PRINT("wch2 head %lld, tail %lld\n", pque->qcfg.head, pque->qcfg.tail);
			pque->sta = QUEUE_IN_USE;

			ptask = &ptask_base[pque->qcfg.head % pque->qcfg.max_ne];
			ret = rpp_xfer_task(pdev, ptask);
			if (ret != 0) {
				DEV_ERROR(pdev, "%s, channel 2 H2D failed\n", __func__);
			}

			pque->qcfg.head++;
		}
		SET_BIT(empty_flag, 2);
	}

	pque = &pdev->dma_queues->rch2;
	ptask_base = (rpp_xfer_task_info_t*)pque->buf;
	if (pque->qcfg.head < pque->qcfg.tail) {
		if (pque->sta == QUEUE_READY) {
			// INFO_PRINT("rch2 head %lld, tail %lld\n", pque->qcfg.head, pque->qcfg.tail);
			pque->sta = QUEUE_IN_USE;

			ptask = &ptask_base[pque->qcfg.head % pque->qcfg.max_ne];
			ret = rpp_xfer_task(pdev, ptask);
			if (ret != 0) {
				DEV_ERROR(pdev, "%s, channel 2 D2H failed\n", __func__);
			}

			pque->qcfg.head++;
		}
		SET_BIT(empty_flag, 3);
	}

	// channel 3
	pque = &pdev->dma_queues->wch3;
	ptask_base = (rpp_xfer_task_info_t*)pque->buf;
	if (pque->qcfg.head < pque->qcfg.tail) {
		if (pque->sta == QUEUE_READY) {
			// INFO_PRINT("wch3 head %lld, tail %lld\n", pque->qcfg.head, pque->qcfg.tail);
			pque->sta = QUEUE_IN_USE;
			
			ptask = &ptask_base[pque->qcfg.head % pque->qcfg.max_ne];
			ret = rpp_xfer_task(pdev, ptask);
			if (ret != 0) {
				DEV_ERROR(pdev, "%s, channel 3 H2D failed\n", __func__);
			}

			pque->qcfg.head++;
		}
		SET_BIT(empty_flag, 4);
	}

	pque = &pdev->dma_queues->rch3;
	ptask_base = (rpp_xfer_task_info_t*)pque->buf;
	if (pque->qcfg.head < pque->qcfg.tail) {
		if (pque->sta == QUEUE_READY) {
			// INFO_PRINT("rch3 head %lld, tail %lld\n", pque->qcfg.head, pque->qcfg.tail);
			pque->sta = QUEUE_IN_USE;

			ptask = &ptask_base[pque->qcfg.head % pque->qcfg.max_ne];
			ret = rpp_xfer_task(pdev, ptask);
			if (ret != 0) {
				DEV_ERROR(pdev, "%s, channel 3 D2H failed\n", __func__);
			}

			pque->qcfg.head++;
		}
		SET_BIT(empty_flag, 5);
	}

	*flag = empty_flag & 0x3f;

	return 0;
}

static int rpp_dma_kthread_func(void *list) 
{
	struct list_head *plist = (struct list_head *)list;
	struct rpp_dev *RPPdev = NULL, *tmp;
	uint8_t flag_tmp = 0; 	// 0 one device tasks is empty, 1 has tasks
	uint8_t flag = 0; 		// 0 all device tasks is empty, n devices has tasks
	int i = 0, idx_max = 0;


	while (!kthread_should_stop()) {
        // INFO_PRINT("%s, kthread doing 0x%x\n", __func__, PAGE_SIZE);
		// msleep(1000);

		// list all device
		flag = 0;
		idx_max = rpp_get_max_device_idx();
		for (i = 0; i <= idx_max; i++) {
			RPPdev = rpp_get_device_with_idx(i);
			if (RPPdev != NULL) {
				rpp_xfer_dev_queues_running(RPPdev, &flag_tmp);

				if (flag_tmp != 0) {
					flag++;
				}
			}
		}

		// reduce cpu loading, need larger than 100us, 
		// and 100us ~ 1000us the performance of asyc PCIe DMA is not changed
		// fsleep(100);

		// if (flag == 0) {
		// 	wait_event_interruptible(pcie_dma_wq, pcie_dma_flag != 0);
		// 	pcie_dma_flag = 0;
		// }

		wait_event_interruptible(pcie_dma_wq, pcie_dma_flag != 0 || kthread_should_stop());
		pcie_dma_flag = 0;
	}
	return 0;
}

int rpp_dev_queues_buf_mmap(struct rpp_dev *pdev, struct vm_area_struct *vma)
{
	unsigned long offset = vma->vm_pgoff << PAGE_SHIFT; // get mmap offset
    unsigned long length = vma->vm_end - vma->vm_start;
	unsigned long pfn;
	rpp_dev_dma_queues_t* pdma_queues = pdev->dma_queues;
    int ret = 0;

	offset &= 0xffffffff;
    if (offset >= pdma_queues->size || 
		length > (pdma_queues->size - offset)) {
		ERROR_PRINT("%s, offset 0x%lx, length 0x%lx\n", __func__, offset, length);	
        return -EINVAL;
    }

	if ((offset & 0xFFF) != 0) {
		ERROR_PRINT("%s, offset 0x%lx length 0x%lx need PAGE_SIZE align\n", __func__, offset, length);	
        return -EINVAL;
	}

	ret = remap_vmalloc_range(vma, (void *)pdma_queues + offset, 0);
    if (ret) {
        ERROR_PRINT("remap_vmalloc_range failed: %d\n", ret);
        return ret;
    }

	// INFO_PRINT("successfully mapped: offset=0x%lx, length=0x%lx\n", offset, length);

	return 0;
}

int rpp_dma_kthread_init(void)
{	
	init_waitqueue_head(&pcie_dma_wq);
	
    pcie_dma_kthread = kthread_run(rpp_dma_kthread_func, &rpp_dev_list, "rpp_pcie_dma_kthread"); 
    if (!pcie_dma_kthread) {
        ERROR_PRINT("%s, kthread run fail\n", __func__);
        return -ECHILD;
    }
	

    return 0;
}

void rpp_dma_kthread_exit(void)
{	
	rpp_dev_semaphore_destroy();

	rpp_dma_wakeup();

    if (pcie_dma_kthread) {
		kthread_stop(pcie_dma_kthread); 
		pcie_dma_kthread = NULL;
	}
}

void rpp_dma_wakeup(void) 
{
	pcie_dma_flag = 1;
	wake_up_interruptible(&pcie_dma_wq);
}

void rpp_dma_isr_wakeup(struct rpp_dev *pdev) 
{
	rpp_dev_dma_queue_t *pque = NULL;
	rpp_xfer_task_info_t *ptask_base = NULL;
	rpp_xfer_task_info_t *ptask = NULL;
	uint8_t empty_flag = 0;
	int ret = 0;

	if (pdev->dma_queues == NULL) {
		return;
	}

	// channel 0/1
	pque = &pdev->dma_queues->wch0_ch1;
	ptask_base = (rpp_xfer_task_info_t*)pque->buf;
	if (pque->qcfg.head < pque->qcfg.tail) {
		if (pque->sta == QUEUE_READY) {
			SET_BIT(empty_flag, 0);
		}
	}

	pque = &pdev->dma_queues->rch0_ch1;
	ptask_base = (rpp_xfer_task_info_t*)pque->buf;
	if (pque->qcfg.head < pque->qcfg.tail) {
		if (pque->sta == QUEUE_READY) {
			SET_BIT(empty_flag, 1);
		}
	}

	// channel 2
	pque = &pdev->dma_queues->wch2;
	ptask_base = (rpp_xfer_task_info_t*)pque->buf;
	if (pque->qcfg.head < pque->qcfg.tail) {
		if (pque->sta == QUEUE_READY) {
			SET_BIT(empty_flag, 2);
		}
	}

	pque = &pdev->dma_queues->rch2;
	ptask_base = (rpp_xfer_task_info_t*)pque->buf;
	if (pque->qcfg.head < pque->qcfg.tail) {
		if (pque->sta == QUEUE_READY) {
			SET_BIT(empty_flag, 3);
		}
	}

	// channel 3
	pque = &pdev->dma_queues->wch3;
	ptask_base = (rpp_xfer_task_info_t*)pque->buf;
	if (pque->qcfg.head < pque->qcfg.tail) {
		if (pque->sta == QUEUE_READY) {
			SET_BIT(empty_flag, 4);
		}
	}

	pque = &pdev->dma_queues->rch3;
	ptask_base = (rpp_xfer_task_info_t*)pque->buf;
	if (pque->qcfg.head < pque->qcfg.tail) {
		if (pque->sta == QUEUE_READY) {
			SET_BIT(empty_flag, 5);
		}
	}

	if ((empty_flag & 0x3f) != 0) {
		pcie_dma_flag = 1;
		wake_up_interruptible(&pcie_dma_wq);
	}
}
