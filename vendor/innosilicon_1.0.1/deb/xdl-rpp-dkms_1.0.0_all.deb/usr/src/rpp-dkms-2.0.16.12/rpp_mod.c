/*
 * This file is part of the Azurengine DMA IP Core driver for Linux
 *
 * Copyright (c) 2016-present,  Azurengine, Inc.
 * All rights reserved.
 *
 * This source code is licensed under both the BSD-style license (found in the
 * LICENSE file in the root directory of this source tree) and the GPLv2 (found
 * in the COPYING file in the root directory of this source tree).
 * You may select, at your option, one of the above-listed licenses.
 */


#include <linux/module.h>
#include <linux/ioctl.h>
#include <linux/types.h>
#include <linux/errno.h>
#include <linux/aer.h>
#include <linux/idr.h>
#include <linux/spinlock.h>
#include <linux/version.h>

#include <linux/fs_struct.h>
#include <linux/limits.h>

#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/slab.h>

#if LINUX_VERSION_CODE < KERNEL_VERSION(4,14,0)
#include <asm/segment.h>
#include <asm/uaccess.h>
#else
#include <linux/uaccess.h>
#endif

#include "include/rpp_cdev.h"
#include "include/rpp_vdev.h"
#include "include/rpp_sdev.h"
#include "include/version.h"
#include "include/rpp_hal_pcie.h"

#include "include/rpp_dev.h"
#include "include/rpp_dev_list.h"

static char version[] =
	DRV_MODULE_DESC " " DRV_MODULE_NAME " v" DRV_MODULE_VERSION "\n";

#define MPU0_GLOBAL_ADDR 0x1010000000
#define MPU1_GLOBAL_ADDR 0x1011000000       /* iccm 0x100000, version 0x4fd48, attribute 0x4fd00 */

#define DEVICE_NAME_AREA_ADDR   0x4ff80
#define DEVICE_NAME_MAGIC       0xcbaa

/* command for MPU1 */
#define RPP_INITIALIZE_MPU1_CMD     0x20
#define RPP_START_MPU1_CMD          0x21
#define RPP_TERMINATE_MPU1_CMD      0x22
#define RPP_ENTERLOWPOWER_MPU1_CMD  0x23
#define RPP_ENTERWORKING_MPU1_CMD   0x24

#define RPP_MPU1_TYPE_NEED_TERMINATED   0
#define RPP_MPU1_TYPE_KEEP_RUNNING      1

static void rpp_format_mcu_version(char *buf, size_t buf_len, uint32_t mcu_version)
{
	snprintf(buf, buf_len, "v%u.%u.%u.%u",
		(mcu_version >> 24) & 0xff,
		(mcu_version >> 16) & 0xff,
		(mcu_version >> 8) & 0xff,
		mcu_version & 0xff);
}

int rpp_refresh_mcu_version(struct rpp_dev *pdev)
{
	int version_ret;
	char mcu_version_str[32];

	if (!pdev)
		return -ENODEV;

	if (pdev->hw_state.pwr_state == RPP_PWRMODE_LOW_POWER) {
		DEV_INFO(pdev, "skip MCU version refresh in LOW_POWER\n");
		return 0;
	}

	pdev->mcu_version = 0;
	version_ret = rpp_get_mcu_version(pdev, &pdev->mcu_version);
	if (version_ret != 0) {
		if (version_ret == -ETIMEDOUT)
			DEV_WARN(pdev, "Read MCU version timeout, cache as 0\n");
		else
			DEV_WARN(pdev, "Read MCU version failed, cache as 0\n");
		pdev->mcu_version = 0;
	} else if (pdev->mcu_version == 0xffffffff) {
		DEV_WARN(pdev, "MCU version read back is all 0xff, cache as 0\n");
		pdev->mcu_version = 0;
	}

	rpp_format_mcu_version(mcu_version_str, sizeof(mcu_version_str), pdev->mcu_version);
	DEV_INFO(pdev, "MCU: %s\n", mcu_version_str);
	return version_ret;
}

/* /sys/module/rpp/parameters/WorkingModeConfig */
static uint WorkingModeConfig = 0xffffffff;
module_param(WorkingModeConfig, uint, S_IRUGO);
MODULE_PARM_DESC(WorkingModeConfig, "WorkingModeConfig of mpu firmware config.");

#if LINUX_VERSION_CODE >= KERNEL_VERSION(6, 13, 0)
MODULE_IMPORT_NS("VFS_internal_I_am_really_a_filesystem_and_am_NOT_a_driver");
#else
MODULE_IMPORT_NS(VFS_internal_I_am_really_a_filesystem_and_am_NOT_a_driver);
#endif
static char firmware_path[PATH_MAX] = {0};
module_param_string(firmware_path, firmware_path, sizeof(firmware_path), S_IRUGO);
MODULE_PARM_DESC(firmware_path,
    "Absolute path of the rpp firmware directory. "
    "If unset, search /lib/firmware/rpp/, "
    "/usr/lib/xpu/xdl/firmware/rpp/, then /usr/local/rpp/mpu/.");

struct rpp_fw_basic_header {
	uint32_t magic_number;
	uint32_t crc32;           /* file reverse crc32-mpeg2 value (not include magic_number). */
	uint32_t version;         /* header version */
	uint32_t size;            /* header size */
	uint32_t fw_size;         /* mpu firmware size */
	uint32_t config_id;       /* change firmware config id write into here */
	uint32_t offset;          /* mpu1 firmware offset in the firmware.bin file */
	uint32_t fw_version;      /* current mpu0 firmware version */
	uint32_t reserved[8];     /* not use (0x20bytes) */
};

struct rpp_fw_data_link {
	uint32_t next;        /* the offset of next element in the file */
	uint32_t size;        /* the size of current element */
	uint64_t addr;        /* the global address of current element to write */
};

struct rpp_mpu1_fw_link {
	uint32_t next;              /* the offset of next element in the file */
	uint32_t size;              /* the size of current element */
	uint64_t addr;              /* the global address of current element to write */
	uint32_t type;              /* 0 - need to terminate, 1 - keep running */
	uint32_t reserved[11];      /* not use (0x2cbytes) */
};

struct rpp_mpu1_info {
	uint32_t version;       /* the version of mpu1 */
	uint32_t attribute;     /* the attribute of mpu1 */
};

struct rpp_gpio_error_string {
	uint32_t value;
	uint8_t name[128];
};

struct rpp_fw_error_string {
	uint32_t value;
	uint8_t name[128];
};

typedef enum {
    MPU1_READY = 1,
    MPU1_RUNNING = 2,
    MPU1_WAITING = 3,
    MPU1_TERMINATED = 4,
    MPU1_MAX
} rpp_mpu1_status_e;

/*
 * GPIO values are LED hints. SEMA handshake/auth status uses existing values
 * such as 0xbeef, 0xdcba, 0xabcd, 0xbac*, 0xabc* and 0xdcb*. 0xHHSS is a
 * firmware stage code: HH is the major stage and SS is the sub-stage.
 */
#define GPIO_ERROR_MAX_NUM  14
#define FW_ERROR_MAX_NUM    36

struct rpp_gpio_error_string gpio_error_status[GPIO_ERROR_MAX_NUM] = {
    {0x23, "Main code in progress(normal)"},
    {0x33, "Instruction received from the host(normal)"},
    {0x43, "Timer enable initialization failed"},
    {0x44, "PMIC I2C access failed"},
    {0x53, "Clock initialization failed"},
    {0x63, "Pcie init failed(only jtag)"},
    {0x73, "DDR init failed"},
    {0x83, "Device info init failed"},
    {0x93, "Failed to upgrade the flag setting"},
    {0xa3, "Failed to initialize dynamic data update"},
    {0xb3, "External module initialization failed"},
    {0xc3, "Temperature warning on and trigger frequency reduction(warning)"},
    {0xd3, "Temperature warning on and force shutting down"},
    {0xe3, "Instruction execution failed"}
};

struct rpp_fw_error_string fw_error_status[FW_ERROR_MAX_NUM] = {
    {0xbeef, "The firmware is already in place, but not run"},
    {0xabcd, "The firmware is successfully loaded"},
    {0xdcba, "The firmware loaded failure(success)"},
    {0xbac0, "The config signature verification is beginning"},
    {0xbac1, "The config signature verification done"},
    {0xbac2, "The firmware signature verification is beginning"},
    {0xbac3, "The firmware signature verification done"},
    {0xabc0, "The config signature verification succeeded"},
    {0xabc1, "The firmware signature verification succeeded"},
    {0xdcb0, "The config signature verification failed"},
    {0xdcb1, "The firmware signature verification failed"},
    {0xdcb2, "The firmware header authentication failed"},
    {0x0101, "BOOT: firmware entry"},
    {0x0201, "EARLY_CLK: early PLL/timer init"},
    {0x0301, "FW_PRECHECK: firmware metadata read"},
    {0x0302, "FW_PRECHECK: firmware compatibility check"},
    {0x0401, "EEPROM_LOAD: I2C access"},
    {0x0402, "EEPROM_LOAD: basic header read"},
    {0x0501, "CONFIG_LOAD: header validation"},
    {0x0502, "CONFIG_LOAD: full header load"},
    {0x0503, "CONFIG_LOAD: config select/check"},
    {0x0601, "OTP: read/check"},
    {0x0701, "PMIC: I2C bus init"},
    {0x0702, "PMIC: I2C access/open channel"},
    {0x0703, "PMIC: power config"},
    {0x0704, "PMIC: status check"},
    {0x0801, "CLOCK_INIT: clock source config"},
    {0x0802, "CLOCK_INIT: module clock/reset enable"},
    {0x0901, "DDR: clock/reset init"},
    {0x0902, "DDR: controller init"},
    {0x0903, "DDR: PHY init"},
    {0x0904, "DDR: training"},
    {0x0905, "DDR: final status check"},
    {0x0a01, "MODULE_CFG: RPP core interleaver/idle config"},
    {0x0a02, "MODULE_CFG: CDMA/AXI config"},
    {0x0a03, "MODULE_CFG: VE memory/config"}
};

/* mpeg2 crc-32 check table */
const unsigned int crc_mpeg2_table[256] = {
    0x00000000, 0x04c11db7, 0x09823b6e, 0x0d4326d9, 0x130476dc, 0x17c56b6b, 0x1a864db2, 0x1e475005,
    0x2608edb8, 0x22c9f00f, 0x2f8ad6d6, 0x2b4bcb61, 0x350c9b64, 0x31cd86d3, 0x3c8ea00a, 0x384fbdbd,
    0x4c11db70, 0x48d0c6c7, 0x4593e01e, 0x4152fda9, 0x5f15adac, 0x5bd4b01b, 0x569796c2, 0x52568b75,
    0x6a1936c8, 0x6ed82b7f, 0x639b0da6, 0x675a1011, 0x791d4014, 0x7ddc5da3, 0x709f7b7a, 0x745e66cd,
    0x9823b6e0, 0x9ce2ab57, 0x91a18d8e, 0x95609039, 0x8b27c03c, 0x8fe6dd8b, 0x82a5fb52, 0x8664e6e5,
    0xbe2b5b58, 0xbaea46ef, 0xb7a96036, 0xb3687d81, 0xad2f2d84, 0xa9ee3033, 0xa4ad16ea, 0xa06c0b5d,
    0xd4326d90, 0xd0f37027, 0xddb056fe, 0xd9714b49, 0xc7361b4c, 0xc3f706fb, 0xceb42022, 0xca753d95,
    0xf23a8028, 0xf6fb9d9f, 0xfbb8bb46, 0xff79a6f1, 0xe13ef6f4, 0xe5ffeb43, 0xe8bccd9a, 0xec7dd02d,
    0x34867077, 0x30476dc0, 0x3d044b19, 0x39c556ae, 0x278206ab, 0x23431b1c, 0x2e003dc5, 0x2ac12072,
    0x128e9dcf, 0x164f8078, 0x1b0ca6a1, 0x1fcdbb16, 0x018aeb13, 0x054bf6a4, 0x0808d07d, 0x0cc9cdca,
    0x7897ab07, 0x7c56b6b0, 0x71159069, 0x75d48dde, 0x6b93dddb, 0x6f52c06c, 0x6211e6b5, 0x66d0fb02,
    0x5e9f46bf, 0x5a5e5b08, 0x571d7dd1, 0x53dc6066, 0x4d9b3063, 0x495a2dd4, 0x44190b0d, 0x40d816ba,
    0xaca5c697, 0xa864db20, 0xa527fdf9, 0xa1e6e04e, 0xbfa1b04b, 0xbb60adfc, 0xb6238b25, 0xb2e29692,
    0x8aad2b2f, 0x8e6c3698, 0x832f1041, 0x87ee0df6, 0x99a95df3, 0x9d684044, 0x902b669d, 0x94ea7b2a,
    0xe0b41de7, 0xe4750050, 0xe9362689, 0xedf73b3e, 0xf3b06b3b, 0xf771768c, 0xfa325055, 0xfef34de2,
    0xc6bcf05f, 0xc27dede8, 0xcf3ecb31, 0xcbffd686, 0xd5b88683, 0xd1799b34, 0xdc3abded, 0xd8fba05a,
    0x690ce0ee, 0x6dcdfd59, 0x608edb80, 0x644fc637, 0x7a089632, 0x7ec98b85, 0x738aad5c, 0x774bb0eb,
    0x4f040d56, 0x4bc510e1, 0x46863638, 0x42472b8f, 0x5c007b8a, 0x58c1663d, 0x558240e4, 0x51435d53,
    0x251d3b9e, 0x21dc2629, 0x2c9f00f0, 0x285e1d47, 0x36194d42, 0x32d850f5, 0x3f9b762c, 0x3b5a6b9b,
    0x0315d626, 0x07d4cb91, 0x0a97ed48, 0x0e56f0ff, 0x1011a0fa, 0x14d0bd4d, 0x19939b94, 0x1d528623,
    0xf12f560e, 0xf5ee4bb9, 0xf8ad6d60, 0xfc6c70d7, 0xe22b20d2, 0xe6ea3d65, 0xeba91bbc, 0xef68060b,
    0xd727bbb6, 0xd3e6a601, 0xdea580d8, 0xda649d6f, 0xc423cd6a, 0xc0e2d0dd, 0xcda1f604, 0xc960ebb3,
    0xbd3e8d7e, 0xb9ff90c9, 0xb4bcb610, 0xb07daba7, 0xae3afba2, 0xaafbe615, 0xa7b8c0cc, 0xa379dd7b,
    0x9b3660c6, 0x9ff77d71, 0x92b45ba8, 0x9675461f, 0x8832161a, 0x8cf30bad, 0x81b02d74, 0x857130c3,
    0x5d8a9099, 0x594b8d2e, 0x5408abf7, 0x50c9b640, 0x4e8ee645, 0x4a4ffbf2, 0x470cdd2b, 0x43cdc09c,
    0x7b827d21, 0x7f436096, 0x7200464f, 0x76c15bf8, 0x68860bfd, 0x6c47164a, 0x61043093, 0x65c52d24,
    0x119b4be9, 0x155a565e, 0x18197087, 0x1cd86d30, 0x029f3d35, 0x065e2082, 0x0b1d065b, 0x0fdc1bec,
    0x3793a651, 0x3352bbe6, 0x3e119d3f, 0x3ad08088, 0x2497d08d, 0x2056cd3a, 0x2d15ebe3, 0x29d4f654,
    0xc5a92679, 0xc1683bce, 0xcc2b1d17, 0xc8ea00a0, 0xd6ad50a5, 0xd26c4d12, 0xdf2f6bcb, 0xdbee767c,
    0xe3a1cbc1, 0xe760d676, 0xea23f0af, 0xeee2ed18, 0xf0a5bd1d, 0xf464a0aa, 0xf9278673, 0xfde69bc4,
    0x89b8fd09, 0x8d79e0be, 0x803ac667, 0x84fbdbd0, 0x9abc8bd5, 0x9e7d9662, 0x933eb0bb, 0x97ffad0c,
    0xafb010b1, 0xab710d06, 0xa6322bdf, 0xa2f33668, 0xbcb4666d, 0xb8757bda, 0xb5365d03, 0xb1f740b4,
};

/* working mode table */
const unsigned int A9_V2_freq_mode[16] = { 1000, 1000, 960, 920, 880, 820, 780, 735, 700, 600, 500, 400, 400, 400, 400, 400};
const unsigned int A9_V2_DFT_freq_mode[16] = { 800, 800, 800, 800, 750, 700, 650, 600, 550, 500, 450, 400, 400, 400, 400, 400};
const unsigned int A10_freq_mode[16] = { 1000, 1000, 920, 800, 750, 700, 650, 600, 550, 500, 450, 400, 400, 400, 400, 400};
const unsigned int A9_V2_PLUS_freq_mode[16] = { 1000, 1000, 960, 920, 880, 850, 800, 750, 700, 600, 500, 400, 400, 400, 400, 400};
const unsigned int A15_freq_mode[16] = { 1000, 1000, 960, 920, 880, 820, 780, 735, 700, 600, 500, 400, 400, 400, 400, 400};
const unsigned int DEFAULT_freq_mode[16] = { 800, 800, 800, 800, 750, 700, 650, 600, 550, 500, 450, 400, 400, 400, 400, 400};

const unsigned int A9_V2_vol_mode[16] = { 85, 85, 85, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78};
const unsigned int A9_V2_DFT_vol_mode[16] = { 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80};
const unsigned int A10_vol_mode[16] = { 85, 85, 85, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80};
const unsigned int A9_V2_PLUS_vol_mode[16] = { 85, 85, 85, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80};
const unsigned int A15_vol_mode[16] = { 85, 85, 85, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78, 78};
const unsigned int DEFAULT_vol_mode[16] = { 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80, 80};

unsigned int do_mpeg2_crc32_table(unsigned char *ptr, int len)
{
    unsigned int crc = 0xFFFFFFFF;

    while(len--)
    {
        crc = (crc << 8) ^ crc_mpeg2_table[(crc >> 24 ^ *ptr++) & 0xff];
    }

    return crc;
}

unsigned int do_mpeg2_crc32_table_reverse(unsigned char* ptr_end, int len)
{
    unsigned int crc = 0xFFFFFFFF;

    while (len--)
    {
        crc = (crc << 8) ^ crc_mpeg2_table[(crc >> 24 ^ *ptr_end--) & 0xff];
    }

    return crc;
}

/**
 * Read or write data to/from device via PCIe
 *
 * This function provides a simple interface to transfer data between
 * host memory and device memory via PCIe.
 *
 * @param pdev RPP device structure
 * @param dev_addr Device address to read/write
 * @param len Length of data to transfer
 * @param buf Host buffer for data transfer
 * @param write True for write operation, false for read
 * @return 0 on success, negative error code on failure
 */
int rpp_pcie_read_write(struct rpp_dev *pdev, uint64_t dev_addr, uint32_t len, void *buf, bool write){
    void *temp = NULL;
    int ret = 0;

    if(len >= KMALLOC_MAX_SIZE){
        DEV_ERROR(pdev, "oversize than kmalloc maxsize");
        ret = -ENODEV;
        goto dev_error;
    }

    temp = kmalloc(len, GFP_ATOMIC | __GFP_NOWARN | __GFP_ZERO);
    if(temp == NULL){
        ret = -ENODEV;
        goto dev_error;
    }

    ret = rpp_xfer_single(pdev, temp, dev_addr, len, write, 0, 1000);
    if(ret != sizeof(unsigned int)){
        ret = -ENODEV;
        goto dev_error;
    }

    memcpy(buf, temp, len);
    ret = 0;

dev_error:
    if(temp){
        kfree(temp);
        temp = NULL;
    }

    return ret;
}

static const char * const rpp_firmware_default_paths[] = {
    "/lib/firmware/rpp/",
    "/usr/lib/xpu/xdl/firmware/rpp/",
    "/usr/local/rpp/mpu/",
    NULL,
};

static bool rpp_firmware_file_exists(const char *dir, const char *name)
{
    char path[PATH_MAX];
    struct file *fp;
    int n;

    n = snprintf(path, sizeof(path), "%s%s", dir, name);
    if (n < 0 || n >= (int)sizeof(path))
        return false;

    fp = filp_open(path, O_RDONLY, 0);
    if (IS_ERR(fp))
        return false;

    filp_close(fp, NULL);
    return true;
}

static bool rpp_firmware_dir_valid(const char *dir)
{
    char dir_slash[PATH_MAX];
    size_t len;

    if (!dir || dir[0] == '\0')
        return false;

    len = strlen(dir);
    if (len >= sizeof(dir_slash) - 2)
        return false;

    if (dir[len - 1] == '/')
        snprintf(dir_slash, sizeof(dir_slash), "%s", dir);
    else
        snprintf(dir_slash, sizeof(dir_slash), "%s/", dir);

    return rpp_firmware_file_exists(dir_slash, FIRMWARE) &&
           rpp_firmware_file_exists(dir_slash, FW_CONFIG);
}

static void rpp_normalize_firmware_dir(char *buf, size_t buflen, const char *dir)
{
    size_t len;

    if (!buf || buflen == 0 || !dir || dir[0] == '\0') {
        if (buf && buflen > 0)
            buf[0] = '\0';
        return;
    }

    len = strlen(dir);
    if (len >= buflen - 2) {
        buf[0] = '\0';
        return;
    }

    memcpy(buf, dir, len);
    buf[len] = '\0';
    if (buf[len - 1] != '/')
        strcat(buf, "/");
}

char *rpp_get_firmware_path(void)
{
    static char resolved_firmware_path[PATH_MAX];
    const char * const *p;

    if (firmware_path[0] != '\0') {
        if (firmware_path[strlen(firmware_path) - 1] != '/')
            strcat(firmware_path, "/");
        return firmware_path;
    }

    for (p = rpp_firmware_default_paths; *p != NULL; p++) {
        if (rpp_firmware_dir_valid(*p)) {
            rpp_normalize_firmware_dir(resolved_firmware_path,
                sizeof(resolved_firmware_path), *p);
            INFO_PRINT("using firmware path: %s\n", resolved_firmware_path);
            return resolved_firmware_path;
        }
    }

    rpp_normalize_firmware_dir(resolved_firmware_path,
        sizeof(resolved_firmware_path), "/usr/local/rpp/mpu/");
    return resolved_firmware_path;
}

#if LINUX_VERSION_CODE < KERNEL_VERSION(4,14,0)
ssize_t kernel_read(struct file *file, void *buf, size_t count, loff_t *pos)
{
    int ret = 0;
    mm_segment_t oldfs;

    oldfs = get_fs();
    set_fs(get_ds());
    ret = vfs_read(file, buf, count, &pos);
    set_fs(oldfs);

    return ret;
}

ssize_t kernel_write(struct file *file, const void *buf, size_t count, loff_t *pos)
{
    int ret = 0;
    mm_segment_t oldfs;

    oldfs = get_fs();
    set_fs(get_ds());
    ret = vfs_write(file, buf, count, &pos);
    vfs_fsync(file, 0);
    set_fs(oldfs);

    return ret;
}
#endif

void rpp_get_config(struct rpp_dev *pdev)
{
    pdev->hw_config_id = WorkingModeConfig;
}

void rpp_check_error_type(struct rpp_dev *pdev, uint32_t status) 
{
    uint8_t i, j;
    int ret = 0;
    void *temp_status = NULL;

    temp_status = kmalloc(sizeof(unsigned int), GFP_ATOMIC | __GFP_NOWARN | __GFP_ZERO);
    if(temp_status == NULL){
        goto dev_error;
    }

    if(status != 0xabcd){
        ret = rpp_xfer_single(pdev, temp_status, MPU0_GLOBAL_ADDR + 0x26000, sizeof(unsigned int), 0, 0, 10);
        if(ret != sizeof(unsigned int)){
            goto dev_error;
        }

        for(j = 0; j < GPIO_ERROR_MAX_NUM; j++){
            if((*(unsigned int *)temp_status & 0x00ff) == gpio_error_status[j].value){
                DEV_ERROR(pdev, "gpio info 0x%x, %s\n", gpio_error_status[j].value, gpio_error_status[j].name);
                break;
            }
        }
    }

    for(i = 0; i < FW_ERROR_MAX_NUM; i++){
        if(status == fw_error_status[i].value){
            if (status < 0x1000) {
                DEV_ERROR(pdev, "firmware status 0x%x: firmware loading failed, current stage is %s\n",
                          fw_error_status[i].value, fw_error_status[i].name);
            } else {
                DEV_ERROR(pdev, "firmware status 0x%x: %s\n",
                          fw_error_status[i].value, fw_error_status[i].name);
            }
            break;
        }
    }

dev_error:
    if(temp_status){
        kfree(temp_status);
        temp_status = NULL;
    }    
}

int rpp_send_cmd_for_mpu1_opt(struct rpp_dev *pdev, uint32_t cmd) 
{
    struct rpp_dev *prppdev = pdev;
    uint8_t *buf = NULL;
    int ret = 0;
    unsigned char timeout;

    buf = (uint8_t*)kzalloc(0x44, GFP_KERNEL);
    if(buf == NULL){
        return -ENOMEM;
    }

    *((uint32_t*)(buf)) = 0xabcd7c01;
    *((uint32_t*)(buf + 0x4)) = cmd;
    *((uint32_t*)(buf + 0x40)) = 0x89abcdef;

    ret = rpp_xfer_single(prppdev, (void*)buf, MPU0_GLOBAL_ADDR + prppdev->cmd_base_addr + 0x90, 0x44, 1, 0, 10);
    if(ret != 0x44){
        DEV_ERROR(prppdev, "%s, failed to send 0x%x to mpu0\n", __func__, cmd);
        return -ENODEV;
    }

    // recv ack
    for (timeout = 0; timeout < 100; timeout++) { // 10ms * 100
        KERNEL_WAIT(10);
        ret = rpp_xfer_single(prppdev, (void*)buf, MPU0_GLOBAL_ADDR + prppdev->cmd_base_addr + 0x90, sizeof(unsigned int), 0, 0, 10);
        if(ret != sizeof(unsigned int)){
            ret = -ENODEV;
        }
        INFO_PRINT("read mpu cmd status: 0x%x\n", *(unsigned int *)buf);
        if(*(unsigned int *)buf == 0xbeeffc01) break;
    }

    if(timeout >= 100){
        ret = -ENODEV;
    }

    kfree(buf);

    return ret;
}


void rpp_get_mpu1_info(struct rpp_dev *pdev, struct rpp_mpu1_info *info)
{
    struct rpp_dev *prppdev = pdev;
    uint8_t *buf = NULL;
    int ret = 0;

    buf = (uint8_t *)kzalloc(sizeof(struct rpp_mpu1_info), GFP_KERNEL);
    if(buf == NULL){
        return;
    }

    /*  version */
    ret = rpp_xfer_single(prppdev, (void*)buf, MPU1_GLOBAL_ADDR + 0x4fd48, sizeof(uint32_t), 0, 0, 10);
    if(ret != (sizeof(uint32_t))){
        DEV_ERROR(prppdev, "%s, failed to send command to mpu0\n", __func__);
        return;
    }

    /*  attribute */
    ret = rpp_xfer_single(prppdev, (void*)(buf + 0x4), MPU1_GLOBAL_ADDR + 0x4fd00, sizeof(uint32_t), 0, 0, 10);
    if(ret != (sizeof(uint32_t))){
        DEV_ERROR(prppdev, "%s, failed to send command to mpu0\n", __func__);
        return;
    }

    memcpy(info, buf, sizeof(struct rpp_mpu1_info));

    kfree(buf);
}

int rpp_firmware_load(struct rpp_dev *pdev, bool refresh_mcu_version)
{
    int ret = 0;
    char *cwd = NULL;
    char *fp_path = NULL;
    struct file *fp = NULL;
    loff_t size, pos = 0;
    void *buf = NULL;
    void *buf_tmp = NULL;
/*
 * device dma address 0x4fffc (32bit)
 * 0xfeeb bootloader done(firmware ready)
 * 0xbeef firmware fill into the dma address of iccm(0x100000) done
 * 0xdcba firmware start run
 * 0xabcd firmware loader done
 */

    /* for sign mpu firmware and config */
    struct rpp_fw_basic_header *pheader = NULL;
    struct rpp_fw_data_link *plink = NULL;           /* for origin data */
    struct rpp_fw_data_link *plink_next = NULL;      /* for signature */
    struct rpp_mpu1_fw_link *pmpu1_link = NULL;      /* for origin data */
    struct rpp_mpu1_info mpu1_info;
    uint32_t public_key_crc32 = 0;
    uint8_t public_key_is_vaild = 0; 
    uint32_t config_mn = 0;
    uint32_t i = 0;
    uint32_t ti = 0;

    FW_CONTROL_HDR *fw_chd = NULL;
    void *firmware_status = NULL;
    unsigned char timeout;
    unsigned int config_count = 0;
    unsigned int config_id = 0;
    unsigned int config_max_num = 0;
    unsigned int config_value[4] = { 0 };

    if (!pdev) {
        ret = -ENODEV;
	    goto dev_error;
    }

    /* config information get */
    rpp_get_config(pdev);

#if PCIE_DMA_PHYS_ADDR_EN
    void *ptr = NULL;
	ptr = phys_to_virt(PCIE_DMA_PHYS_ADDR);
	buf = ptr;
	DEV_DEBUG(pdev, "%s, phys_to_virt 0x%llx to virt 0x%llx\n", __func__, PCIE_DMA_PHYS_ADDR, ptr);
    size = sizeof(pdev->bl_config_info);
#else

    /* check old mpu version */
    size = sizeof(pdev->bl_config_info);
    buf = kmalloc(size, GFP_ATOMIC | __GFP_NOWARN | __GFP_ZERO);
    if(buf == NULL){
        ret = -ENODEV;
        goto dev_error;
    }
#endif
    ret = rpp_xfer_single(pdev, buf, MPU0_GLOBAL_ADDR + 0x4fe00, size, 0, 0, 1000);
    if(ret != size){
        ret = -ENODEV;
        goto dev_error;
    }

    DEV_DEBUG(pdev, "mpu code flag 0x%x\n", *((unsigned int *)buf));
    memcpy(&pdev->bl_config_info, buf, size);
    if((*((unsigned int *)buf) & 0x0000ffff) != 0xcafd){
        ret = -0;
        DEV_DEBUG(pdev, "old version mpu code 0x%x, not support load firmware\n", *((unsigned int *)buf));
        goto dev_error;
    }
    pdev->hw_state.max_pll1_freq = (uint16_t)(((pdev->bl_config_info.freq >> 12) & 0x00000fff) * 2);
#if PCIE_DMA_PHYS_ADDR_EN
    buf = NULL;
#else
    kfree(buf);
    buf = NULL;
#endif
    size = 0;

    /*  if(rpp_genx_speed_change(pdev, (uint8_t)((pdev->bl_config_info.board_mn >> 12) & 0xf))){ */
    /*      goto dev_error; */
    /*  } */

    /* get cwd of firmware */
    cwd = rpp_get_firmware_path();
    if(cwd == NULL){
        ret = -ENODEV;
        goto dev_error;
    }

    fp_path = vmalloc(PATH_MAX);
    if(fp_path == NULL){
        ret = -ENODEV;
        goto dev_error;
    }

#if PCIE_DMA_PHYS_ADDR_EN
    firmware_status = ptr;
#else
    firmware_status = kmalloc(sizeof(unsigned int), GFP_ATOMIC | __GFP_NOWARN | __GFP_ZERO);
    if(firmware_status == NULL){
        ret = -ENODEV;
        goto dev_error;
    }
#endif
    ret = rpp_xfer_single(pdev, firmware_status, MPU0_GLOBAL_ADDR + 0x4fffc, sizeof(unsigned int), 0, 0, 10);
    if(ret != sizeof(unsigned int)){
        ret = -ENODEV;
        goto dev_error;
    }
    DEV_DEBUG(pdev, "firmware status:0x%x \n", *((unsigned int*)firmware_status));

    if(*((unsigned int *)firmware_status) == 0xfeeb){
        /* check version if signature verifier enable and public key crc32/mpeg-2 */
        ret = rpp_xfer_single(pdev, firmware_status, MPU0_GLOBAL_ADDR +  0x4fe04, sizeof(unsigned int), 0, 0, 10);
        if(ret != sizeof(unsigned int)){
            ret = -ENODEV;
            goto dev_error;
        }

        if ((*((unsigned int *)firmware_status) & 0x0000ffff) >= 0x4) {
            ret = rpp_xfer_single(pdev, firmware_status, MPU0_GLOBAL_ADDR + 0x4fe34, sizeof(unsigned int), 0, 0, 10);
            if(ret != sizeof(unsigned int)){
                ret = -ENODEV;
                goto dev_error;
            }

            /*  (1) signature verifier enable, (0) signature verifier disable   */
            /*  oem.bin crc32/mpeg-2 0x489f4e64  */
            /*  ssid_0x380117AA.bin crc32/mpeg-2 0x91d65e63  */
            DEV_INFO(pdev, "signature verifier enable: 0x%x \n", *((unsigned int *)firmware_status));
            if (*((unsigned int *)firmware_status) == 0x1) {
                size = 256;
#if PCIE_DMA_PHYS_ADDR_EN
                buf = ptr;
#else
                buf = kzalloc(size, GFP_KERNEL);
                if(buf == NULL){
                    ret = -ENODEV;
                    goto dev_error;
                }
#endif

                ret = rpp_xfer_single(pdev, buf, MPU0_GLOBAL_ADDR + 0x41140, size, 0, 0, 1000);
                if(ret != size){
                    ret = -ENODEV;
                    goto dev_error;
                }

                public_key_crc32 = do_mpeg2_crc32_table(buf, size);
                if(public_key_crc32 == 0x489f4e64) {
                    public_key_is_vaild |= 0x1;
                    DEV_INFO(pdev, "public key type: %s\n", "oem");
                }
                else if(public_key_crc32 == 0x91d65e63) {
                    public_key_is_vaild |= 0x1;
                    DEV_INFO(pdev, "public key type: %s\n", "0x380117AA");
                } 
                else {
                    DEV_INFO(pdev, "public key type: %s(0x%x)\n", "Unknown", public_key_crc32);
                }

#if PCIE_DMA_PHYS_ADDR_EN
                buf = NULL;
#else
                kfree(buf);
                buf = NULL;
#endif
                size = 0;
            }   
        }

        /* open control haeder 2 file and write into mpu */
        sprintf(fp_path, "%s%s", cwd, FW_CONFIG);
        DEV_DEBUG(pdev, "control haeder 2: %s \n", fp_path);

        fp = filp_open(fp_path, O_RDWR, 0);
        if (IS_ERR(fp)) {
            ret = PTR_ERR(fp);
            DEV_ERROR(pdev, "%s open failed, err = %d\n", fp_path, ret);
            goto dev_error;
        }

        size = fp->f_inode->i_size;
#if PCIE_DMA_PHYS_ADDR_EN
        buf = ptr;
#else
        buf = kzalloc(size, GFP_KERNEL);
        if(buf == NULL){
            ret = -ENODEV;
            goto dev_error;
        }
#endif
        ret = kernel_read(fp, buf, size, &pos);
        DEV_DEBUG(pdev, "read size %d, file size %d end pos %d\n", ret, size, pos);

        pheader = (struct rpp_fw_basic_header *)buf;
        if (pheader->magic_number == 0xcacc) {
            /*  sign && fw_version > 0x3 */
            ret = do_mpeg2_crc32_table_reverse(((unsigned char*)buf + size - 1), (int)(size - sizeof(uint32_t)));
            if (ret != 0) {
                DEV_ERROR(pdev, "config.bin damage(0x%x)\n", ret);
                ret = -ENODEV;
                goto dev_error;
            }

            FW_CONTROL_HDR* fw_chd = NULL;
            plink = (struct rpp_fw_data_link *)((char *)buf + sizeof(uint64_t));
            plink_next = (struct rpp_fw_data_link *)((char *)buf + plink->next);
            for (i = 0; i < 100; i++) {
                /*  DEV_INFO(pdev, "addr 0x%llx size 0x%x\n", plink->addr, plink->size); */
                /*  DEV_INFO(pdev, "next addr 0x%llx size 0x%x\n", plink_next->addr, plink_next->size); */

                /*  only for power management */
                fw_chd = (FW_CONTROL_HDR *)((char *)plink + sizeof(struct rpp_fw_data_link));
                if ((UINT16)((fw_chd->config_mn >> 16) & 0xffff) == pdev->bl_config_info.board_info) {
                    break;
                }

                if (plink_next->next == 0xffffffff) {
                    break;
                }

                plink = (struct rpp_fw_data_link *)((char *)buf + plink_next->next);
                plink_next = (struct rpp_fw_data_link *)((char *)buf + plink->next);
            }

            /*  config information */
            pdev->fw_version = fw_chd->version;
            pdev->cmd_base_addr = fw_chd->cmd_base_addr;
            config_mn = fw_chd->config_mn;
            config_value[0] = fw_chd->config0;
            config_value[1] = fw_chd->config1;
            config_value[2] = fw_chd->config2;
            config_value[3] = fw_chd->config3;

            if (pdev->hw_config_id > 0x3) {
                /*  DWARNING("WorkingModeConfig not set or unavailable value 0x%x, set default value\n", devContext->hw_config_id); */
            }
            else {
                config_mn = (config_mn & 0xfffffff0) | pdev->hw_config_id;
            }

            if ((ROLLBACK_PROTECTION_V == 0) || ((public_key_is_vaild & 0x1) == 0)) {
                config_mn &= 0xffff7fff;
            }

            if ((public_key_is_vaild & 0x1) == 0) {
                fw_chd->config_mn &= 0xffff7fff;
            }
            
            DEV_INFO(pdev, "%-20s 0x%x\n", "RollBack PT Value:", ROLLBACK_PROTECTION_V);
            pdev->hw_state.max_pll1_freq = (uint16_t)(((config_value[config_mn & 0x0000000f] >> 21) & 0x000007ff) * 2);
            DEV_INFO(pdev, "%-20s 0x%x %dMHz\n", "Config Id/MaxFreq:", (config_mn & 0x0000000f), pdev->hw_state.max_pll1_freq);
            DEV_INFO(pdev, "%-20s 0x%x 0x%x\n", "Config Mn/BroadInfo:", config_mn, pdev->bl_config_info.board_info);
            
            buf_tmp = (void *)((char *)buf + ((uint64_t)(plink) - (uint64_t)(buf)) + sizeof(struct rpp_fw_data_link));
            size = plink->size;
            ret = rpp_xfer_single(pdev, buf_tmp, (uint64_t)(plink->addr), size, 1, 0, 100);
            if(ret != size){
                DEV_ERROR(pdev, "xfer config to mpu failed\n");
                ret = -ENODEV;
                goto dev_error;
            }

            buf_tmp = (void *)((char *)buf + ((uint64_t)(plink_next) - (uint64_t)(buf)) + sizeof(struct rpp_fw_data_link));
            size = plink_next->size;
            ret = rpp_xfer_single(pdev, buf_tmp, (uint64_t)(plink_next->addr), size, 1, 0, 100);
            if(ret != size){
                DEV_ERROR(pdev, "xfer config signature failed\n");
                ret = -ENODEV;
                goto dev_error;
            }
        }
        else {
            /*  no sign */
            ret = do_mpeg2_crc32_table(buf, size);
            if(ret != 0){
                DEV_ERROR(pdev, "config.bin damage(0x%x)\n", ret);
                ret = -ENODEV;
                goto dev_error;
            }

            /*  only for power management */
            fw_chd = (FW_CONTROL_HDR*)buf;
            pdev->fw_version = fw_chd->version;
            if(pdev->fw_version >= 0x3) {
                if(pdev->fw_version == 0x3){
                    if((size = fp->f_inode->i_size) > 0x100){
                        WARNING_PRINT("%s size 0x%x exceeds control haeder 2 space\n", fp_path, size);
                        size = 0x100;
                    }
                }
                else{
                    config_max_num = (unsigned int)(size - sizeof(unsigned int)) / sizeof(FW_CONTROL_HDR);
                    for (config_count = 0; config_count < config_max_num; config_count++) {
                        fw_chd = (FW_CONTROL_HDR*)((uint8_t*)(buf) + config_count * sizeof(FW_CONTROL_HDR));
                        if ((unsigned short)((fw_chd->config_mn >> 16) & 0xffff) == pdev->bl_config_info.board_info) {
                            break;
                        }
                    }

                    config_value[0] = fw_chd->config0;
                    config_value[1] = fw_chd->config1;
                    config_value[2] = fw_chd->config2;
                    config_value[3] = fw_chd->config3;

                    if (pdev->hw_config_id > 0x3) {
                        /*  WARNING_PRINT("WorkingModeConfig not set or unavailable value 0x%x, set default value\n", pdev->hw_config_id); */
                    }
                    else {
                        fw_chd->config_mn = (fw_chd->config_mn & 0xfffffff0) | pdev->hw_config_id;
                    }

                    if ((public_key_is_vaild & 0x1) == 0) {
                        fw_chd->config_mn &= 0xffff7fff;
                    }

                    config_id = fw_chd->config_mn & 0x0000000f;
                    pdev->hw_state.max_pll1_freq = (uint16_t)(((config_value[config_id] >> 21) & 0x000007ff) * 2);

                    size = sizeof(FW_CONTROL_HDR);
                    DEV_INFO(pdev, "%-20s 0x%x 0x%x\n", "Config Max/Index:", config_max_num, config_count);
                    DEV_INFO(pdev, "%-20s 0x%x %dMHz\n", "Config Id/MaxFreq:", config_id, pdev->hw_state.max_pll1_freq);
                    DEV_INFO(pdev, "%-20s 0x%x 0x%x\n", "Config Mn/BroadInfo:", fw_chd->config_mn, pdev->bl_config_info.board_info);
                }
                pdev->cmd_base_addr = fw_chd->cmd_base_addr;
            }

            ret = rpp_xfer_single(pdev, fw_chd, MPU0_GLOBAL_ADDR + 0x4fd00, size, 1, 0, 100);
            if(ret != size){
                ret = -ENODEV;
                goto dev_error;
            }
        }

        /* close control haeder 2 file and release resources */
        memset(fp_path, 0, PATH_MAX);
        filp_close(fp, NULL);
        fp = NULL;
#if PCIE_DMA_PHYS_ADDR_EN
        buf = NULL;
#else
        kfree(buf);
        buf = NULL;
#endif
        size = 0;
        pos = 0;
        pheader = NULL;
        plink = NULL;
        plink_next = NULL;


        /* open firmware file and write into mpu */
        sprintf(fp_path, "%s%s", cwd, FIRMWARE);
        DEV_DEBUG(pdev, "firmware: %s \n", fp_path);

        fp = filp_open(fp_path, O_RDWR, 0);
        if (IS_ERR(fp)) {
            ret = PTR_ERR(fp);
            DEV_ERROR(pdev, "%s open failed, err = %d\n", fp_path, ret);
            goto dev_error;
        }
        size = fp->f_inode->i_size;
#if PCIE_DMA_PHYS_ADDR_EN
        buf = ptr;
#else
        buf = kzalloc(size, GFP_KERNEL);
        if(buf == NULL){
            ret = -ENODEV;
            goto dev_error;
        }
#endif
        ret = kernel_read(fp, buf, size, &pos);
        DEV_DEBUG(pdev, "read size %d, file size %d end pos %d\n", ret, size, pos);

        pheader = (struct rpp_fw_basic_header *)buf;
        if (pheader->magic_number == 0xcacc) {
            /*  sign */
            if (pheader->fw_size > 0x10000) {  /*  64kB */
                DEV_ERROR(pdev, "firmware.bin size 0x%llx exceeds ICCM space\n", size);
                ret = -ENODEV;
                goto dev_error;
            }

            ret = do_mpeg2_crc32_table_reverse(((unsigned char*)buf + size - 1), (int)(size - sizeof(UINT32)));
            if (ret != 0) {
                DEV_ERROR(pdev, "firmware.bin damage(0x%x)\n", ret);
                ret = -ENODEV;
                goto dev_error;
            }

            /** mpu0 firmware rollback protection */
            if(ROLLBACK_PROTECTION_V && (pheader->fw_version != 0) && (config_mn & 0x00008000) && ((public_key_is_vaild & 0x1) == 0x1)){
                ret = rpp_xfer_single(pdev, firmware_status, MPU0_GLOBAL_ADDR + 0x41244, sizeof(unsigned int), 0, 0, 10);
                if(ret != sizeof(unsigned int)){
                    DEV_ERROR(pdev, "old firmware version get failed(0x%x)\n", ret);
                    ret = -ENODEV;
                    goto dev_error;
                }

                // compare current mpu0 firmware version and old firmware version
                // fix: jtag upgrade bootloader cause 0xffffffff version, kuanghl
                if(*(unsigned int *)firmware_status > pheader->fw_version && (*(unsigned int *)firmware_status != 0xffffffff)){
                    DEV_ERROR(pdev, "Current firmware version(%d) is older than the previous one(%d), do not load\n", pheader->fw_version, *(unsigned int *)firmware_status);
                    ret = -ENODEV;
                    goto dev_error;
                }
            }
            
            pheader->config_id = config_mn;
            buf_tmp = buf;
            size = pheader->size;
            ret = rpp_xfer_single(pdev, buf_tmp, MPU0_GLOBAL_ADDR +  0x410c0, size, 1, 0, 100);
            if(ret != size){
                DEV_ERROR(pdev, "xfer sign firmware.bin header failed\n");
                ret = -ENODEV;
                goto dev_error;
            }

            plink = (struct rpp_fw_data_link *)((char *)buf + pheader->size);
            plink_next = (struct rpp_fw_data_link *)((char *)buf + plink->next);
            for (i = 0; i < 100; i++) {
                /*  DEV_INFO(pdev, "addr 0x%llx size 0x%x\n", plink->addr, plink->size); */
                /*  DEV_INFO(pdev, "next addr 0x%llx size 0x%x\n", plink_next->addr, plink_next->size); */

                buf_tmp = (void *)((char *)buf + ((uint64_t)(plink) - (uint64_t)(buf)) + sizeof(struct rpp_fw_data_link));
                size = plink->size;
                ret = rpp_xfer_single(pdev, buf_tmp, (uint64_t)(plink->addr), size, 1, 0, 1000);
                if(ret != size){
                    DEV_ERROR(pdev, "xfer firmware element failed\n");
                    ret = -ENODEV;
                    goto dev_error;
                }

                buf_tmp = (void *)((char *)buf + ((uint64_t)(plink_next) - (uint64_t)(buf)) + sizeof(struct rpp_fw_data_link));
                size = plink_next->size;
                ret = rpp_xfer_single(pdev, buf_tmp, (uint64_t)(plink_next->addr), size, 1, 0, 1000);
                if(ret != size){
                    DEV_ERROR(pdev, "xfer firmware element signature failed\n");
                    ret = -ENODEV;
                    goto dev_error;
                }

                if (plink_next->next == 0xffffffff) {
                    break;
                }

                plink = (struct rpp_fw_data_link *)((char *)buf + plink_next->next);
                plink_next = (struct rpp_fw_data_link *)((char *)buf + plink->next);
            }
        }
        else {
            /*  no sign */
            if(size > 0x10000){  /*  64kB */
                DEV_ERROR(pdev, "%s size 0x%x exceeds ICCM space\n", fp_path, size);
                ret = -ENODEV;
                goto dev_error;
            }

            ret = do_mpeg2_crc32_table(buf, size);
            if(ret != 0){
                    DEV_ERROR(pdev, "firmware.bin damage(0x%x)\n", ret);
                    ret = -ENODEV;
                    goto dev_error;
            }

            ret = rpp_xfer_single(pdev, buf, MPU0_GLOBAL_ADDR + 0x100000, size, 1, 0, 1000);
            if(ret != size){
                ret = -ENODEV;
                goto dev_error;
            }
        }

        /* set firmware_status */
        *((unsigned int *)firmware_status)= 0xbeef;
        ret = rpp_xfer_single(pdev, firmware_status, MPU0_GLOBAL_ADDR + 0x4fffc, sizeof(unsigned int), 1, 0, 10);
        if(ret != sizeof(unsigned int)){
            ret = -ENODEV;
            goto dev_error;
        }
        DEV_DEBUG(pdev, "write firmware_status: 0x%x\n", *(unsigned int *)firmware_status);

        /*  get firmware_status */
        for(timeout = 0; timeout < 10; timeout++){  /*  10 * 100ms = 1s */
            KERNEL_WAIT(100);
            ret = rpp_xfer_single(pdev, firmware_status, MPU0_GLOBAL_ADDR + 0x4fffc, sizeof(unsigned int), 0, 0, 10);
            if(ret != sizeof(unsigned int)){
                ret = -ENODEV;
                goto dev_error;
            }
            DEV_DEBUG(pdev, "read firmware_status: 0x%x\n", *(unsigned int *)firmware_status);
            if(*(unsigned int *)firmware_status == 0xabcd) break;
        }

        if(timeout >= 10){
            DEV_ERROR(pdev, "read firmware_status: 0x%x (timeout)\n", *(unsigned int *)firmware_status);
            rpp_check_error_type(pdev, *(unsigned int *)firmware_status);
            ret = 1;
        }else{
            DEV_INFO(pdev, "read firmware_status: 0x%x (success)\n", *(unsigned int *)firmware_status);
            ret = 0;
        }

        /* vcpu enable */ 
        if(ret == 0 && pheader->offset != 0 && pheader->magic_number == 0xcacc){
            pmpu1_link = (struct rpp_mpu1_fw_link *)((char *)buf + pheader->offset);

            for (i = 0; i < 100; i++) {
                /*  DEV_INFO(pdev, "addr 0x%llx size 0x%x\n", pmpu1_link->addr, pmpu1_link->size); */
                DEV_INFO(pdev, "mpu1 type: %s(%d)\n", pmpu1_link->type == 0 ? "terminated": "keep running", i);
                rpp_send_cmd_for_mpu1_opt(pdev, RPP_INITIALIZE_MPU1_CMD);

                buf_tmp = (void *)((char *)buf + ((uint64_t)(pmpu1_link) - (uint64_t)(buf)) + sizeof(struct rpp_mpu1_fw_link));
                size = pmpu1_link->size;
                ret = rpp_xfer_single(pdev, buf_tmp, (uint64_t)(pmpu1_link->addr), size, 1, 0, 1000);
                if(ret != size){
                    DEV_ERROR(pdev, "xfer mpu1 firmware element failed\n");
                    ret = -ENODEV;
                    goto dev_error;
                }

                if(pmpu1_link->type == 0) {
                    rpp_send_cmd_for_mpu1_opt(pdev, RPP_START_MPU1_CMD);

                    /*  get state */
                    while (true) {
                        ret = rpp_xfer_single(pdev, firmware_status, MPU1_GLOBAL_ADDR + 0x4fd50, sizeof(unsigned int), 0, 0, 10);
                        if(ret != sizeof(unsigned int)){
                            ret = -ENODEV;
                            goto dev_error;
                        }
                        
                        if((*(unsigned int *)firmware_status) == MPU1_TERMINATED) {
                            rpp_send_cmd_for_mpu1_opt(pdev, RPP_TERMINATE_MPU1_CMD);
                            break;
                        }

                        /*  5s */
                        KERNEL_WAIT(10);
                        ti++;
                        if(ti > 500) {
                            DEV_ERROR(pdev, "xfer mpu1 firmware element failed\n");
                            ret = -ENODEV;
                            goto dev_error;
                        }
                    }
                }
                else if(pmpu1_link->type == 1) {
                    rpp_send_cmd_for_mpu1_opt(pdev, RPP_START_MPU1_CMD);
                    break;
                }

                if (pmpu1_link->next == 0xffffffff) {
                    break;
                }

                pmpu1_link = (struct rpp_mpu1_fw_link *)((char *)buf + pmpu1_link->next);
            }
            ret = 0;
        }
    } else if (*((unsigned int *)firmware_status) == 0xabcd){
        /* open control haeder 2 file get fw_version */
        DEV_DEBUG(pdev, "control haeder 2 reading\n");

        size = sizeof(FW_CONTROL_HDR);
#if PCIE_DMA_PHYS_ADDR_EN
        buf = ptr;
#else
        buf = kzalloc(size, GFP_KERNEL);
        if(buf == NULL){
            ret = -ENODEV;
            goto dev_error;
        }
#endif
        ret = rpp_xfer_single(pdev, buf, MPU0_GLOBAL_ADDR + 0x4fd00, size, 0, 0, 100);
        if(ret != size){
            ret = -ENODEV;
            goto dev_error;
        }

        /*  only for power management */
        fw_chd = (FW_CONTROL_HDR*)buf;
        pdev->fw_version = fw_chd->version;
        if(pdev->fw_version >= 0x3) {
            config_value[0] = fw_chd->config0;
            config_value[1] = fw_chd->config1;
            config_value[2] = fw_chd->config2;
            config_value[3] = fw_chd->config3;
	    config_id = fw_chd->config_mn & 0x0000000f;
	    if (config_id > 3) {
	        config_id = 0;
	    }
            pdev->hw_state.max_pll1_freq = (uint16_t)(((config_value[config_id] >> 21) & 0x000007ff) * 2);
            pdev->cmd_base_addr = fw_chd->cmd_base_addr;
            DEV_INFO(pdev, "%-20s 0x%x %dMHz\n", "Config Id/MaxFreq:", config_id, pdev->hw_state.max_pll1_freq);
            DEV_INFO(pdev, "%-20s 0x%x 0x%x\n", "Config Mn/BroadInfo:", fw_chd->config_mn, pdev->bl_config_info.board_info);
        }

        /* close control haeder 2 file and release resources */
#if PCIE_DMA_PHYS_ADDR_EN
        buf = NULL;
#else
        kfree(buf);
        buf = NULL;
#endif
        size = 0;

        DEV_INFO(pdev, "firmware already loader.\n");
        ret = 0;
    }else{
        DEV_ERROR(pdev, "unknown firmware status 0x%x\n", *((unsigned int *)firmware_status));
        ret = -ENODEV;
    }

    if(ret == 0 && firmware_status != NULL && refresh_mcu_version)
        rpp_refresh_mcu_version(pdev);

dev_error:
    if(fp_path){
        vfree(fp_path);
        fp_path = NULL;
    }

#ifndef PCIE_DMA_PHYS_ADDR_EN
    if(buf){
        kfree(buf);
        buf = NULL;
		size = 0;
    }

    if(firmware_status){
        kfree(firmware_status);
        firmware_status = NULL;
    }
#endif

    if (fp && !IS_ERR(fp)) {
        filp_close(fp, NULL);
        fp = NULL;
    }

    return ret;
}

int rpp_get_devinfo(struct rpp_dev *pdev)
{
    int ret = 0;
    void *buf = NULL;
    uint32_t buf_size = 0;
    struct rpp_dev *prppdev = pdev;
    char board_name_area[0x40];

    if(prppdev->fw_version >= 0x3) {
	buf_size = (sizeof(struct rpp_dev_info) > sizeof(board_name_area)) ? sizeof(struct rpp_dev_info) : sizeof(board_name_area);
        buf = kzalloc(buf_size, GFP_KERNEL);
        if(buf == NULL){
            return -ENODEV;
        }
        ret = rpp_xfer_single(prppdev, buf, MPU0_GLOBAL_ADDR + prppdev->cmd_base_addr, sizeof(struct rpp_dev_info), 0, 0, 1000);
        if(ret != sizeof(struct rpp_dev_info)){
            kfree(buf);
            return -ENODEV;
        }
        memcpy(&prppdev->dev_info, buf, sizeof(prppdev->dev_info));
        kfree(buf);
    }
    else {
        /*  device info get with bar 0. */
	    memcpy(&prppdev->dev_info, (void *)prppdev->bar[0], sizeof(prppdev->dev_info));
    }

    return 0;
}

int rpp_dump_devinfo(struct rpp_dev *pdev)
{
    uint32_t temp = 0;
    char *board_version[] = {"Dudi", "V4", "M3", "M5", "A4", "A8", "A9_V1", "A9_V2", "A9_V2_DFT", "A10", "A9_V2_PLUS", "A15", "N/A"};
	uint32_t board_num = sizeof(board_version) / sizeof(board_version[0]);
	char *boot_mode[] = {"JTAG", "EEPROM", "PCIe", "N/A"};
	char board_name_area[0x40];
	char * pboard_name;
	uint32_t boot_mode_num = sizeof(boot_mode) / sizeof(boot_mode[0]);
	uint32_t board_id;
	uint32_t boot_mode_id;
    int ret = 0;
    void *buf = NULL;
    struct rpp_dev *prppdev = pdev;

    /* Get board_name_area if needed */
    if(prppdev->fw_version >= 0x3) {
        buf = kzalloc(sizeof(board_name_area), GFP_KERNEL);
        if(buf == NULL){
            return -ENODEV;
        }
	    ret = rpp_xfer_single(prppdev, buf, MPU0_GLOBAL_ADDR + DEVICE_NAME_AREA_ADDR, sizeof(board_name_area), 0, 0, 1000);
        if(ret != sizeof(board_name_area)){
            kfree(buf);
            return -ENODEV;
        }
        memcpy(board_name_area, buf, sizeof(board_name_area));
        kfree(buf);
    } else {
        /* For old firmware, board_name_area is not available, will use board_version array */
        memset(board_name_area, 0, sizeof(board_name_area));
    }

    /*  analysis */
	temp = prppdev->dev_info.platform_version;
	pboard_name = board_name_area;
	if (*(uint32_t *)pboard_name != DEVICE_NAME_MAGIC) {
		board_id = (temp & 0xffff0000)>>16;
		if (board_id >= (board_num - 1)) {
			board_id = board_num - 1;
		}
		pboard_name = board_version[board_id];
	} else {
		pboard_name = board_name_area + 4;
	}
	boot_mode_id = (temp & 0x0000ff00)>>8;
	if (boot_mode_id >= (boot_mode_num - 1)) {
		boot_mode_id = boot_mode_num - 1;
	}
	DEV_INFO(prppdev, "%-20s %s %s\n", "Platform Version:", pboard_name, boot_mode[boot_mode_id]);
	DEV_INFO(prppdev, "%-20s %s %s\n", "Rpp Driver Version:", DRV_MODULE_VERSION, SOFTWARE_VERSION2);
	DEV_INFO(prppdev, "%-20s 0x%d %x\n", "Mpu Version:", prppdev->dev_info.sw_version_1, prppdev->dev_info.sw_version_2);
	DEV_INFO(prppdev, "%-20s %s %s\n", "Mpu Firmware:", FIRMWARE, FW_CONFIG);
	if(prppdev->dev_info.self_check == 0x2){
		DEV_INFO(prppdev, "%-20s 0x%x", "Bootloader Config:", prppdev->dev_info.bl_config_version);
		DEV_INFO(prppdev, "%-20s 0x%x 0x%x", "Firmware Config:", prppdev->dev_info.fw_config_version, prppdev->fw_version);
		DEV_INFO(prppdev, "%-20s 0x%x", "Bootloader version:", prppdev->dev_info.bootloader_version);
	}else{
		DEV_INFO(prppdev, "%-20s 0x%x", "Bootloader version:", prppdev->dev_info.bl_config_version);
		/*  DEV_INFO(prppdev, "boot_status=0x%x\n", prppdev->dev_info.boot_status); */
		/*  DEV_INFO(prppdev, "self_check=0x%x\n", prppdev->dev_info.self_check); */
	}
	DEV_INFO(prppdev, "%-20s 0x%x\n", "Mpu External Ctrl 0:", prppdev->dev_info.mpu_external_ctrl_0);
	DEV_INFO(prppdev, "%-20s %dMHz %dMHz %dMHz\n", "Clk(Rpp/Sche/Ddr):", prppdev->dev_info.rpp_clk, prppdev->dev_info.sche_clk, prppdev->dev_info.ddr_clk);

    return 0;
}

int rpp_set_pmic(struct rpp_dev *pdev, bool state)
{
    int ret = 0;
    uint32_t *buf = NULL;
    struct rpp_dev *prppdev = pdev;
    uint8_t timeout = 0;
    uint64_t size = sizeof(uint32_t) * 4;

    if(prppdev->fw_version >= 0x3) {
        buf = (uint32_t*)kzalloc(size, GFP_KERNEL);
        if(buf == NULL){
            return -ENODEV;
        }

        /*  start [8:13] length */
        /*  |-- start --|-- parameter --|-- end --| */
        /*  |-- 0xabcd4001 --|-- mode --|-- 0x89abcdef --| */
        buf[0] = 0xabcd4001 | (0x4<<8);
        buf[1] = 0x9; /*  0x80000009 on 0x9 off */
        buf[2] = 0x89abcdef;
        buf[3] = 0xffffffff;

        /*  send to mpu sram */
        ret = rpp_xfer_single(prppdev, (void*)buf, MPU0_GLOBAL_ADDR + prppdev->cmd_base_addr + 0x90, (size - sizeof(uint32_t)), 1, 0, 100);
        if(ret != (size - sizeof(uint32_t))){
            DEV_ERROR(prppdev, "%s, set pmic failed\n", __func__);
            kfree(buf);
            return -ENODEV;
        }

        /*  get pmic state set status */
        for(timeout = 0; timeout < 30; timeout++){  /*  30 * 30ms = 900ms */
            ret = rpp_xfer_single(prppdev, (void*)&buf[3], MPU0_GLOBAL_ADDR + prppdev->cmd_base_addr + 0x90, sizeof(uint32_t), 0, 0, 10);
            if(ret != sizeof(uint32_t)){
                DEV_ERROR(prppdev, "%s, get pmic status failed\n", __func__);
                kfree(buf);
                return -ENODEV;
            }

            if((((buf[3] >> 16) & 0xffff) == 0xbeef) && (((buf[3] >> 14) & 0x3) == 0x3)) {
                break;
            }
            KERNEL_WAIT(30);
        }

        if(timeout >= 30){
            DEV_ERROR(pdev, "pmic state: 0x%x status: 0x%x (timeout)\n", state, buf[3]);
            kfree(buf);
            return -ENODEV;
        }

        kfree(buf);
    }
    else{
        uint32_t temp=0, i = 0;

        temp = 0x9;
        RPP_rw_pci_bar(prppdev, 0, 1, 4, 0x94, (UCHAR *)&temp);
        temp = (uint32_t)state;
        RPP_rw_pci_bar(prppdev, 0, 1, 4, 0xdc, (UCHAR *)&temp);

        temp=0xabcd4001;
        RPP_rw_pci_bar(prppdev, 0, 1, 4, 0x90, (UCHAR *)&temp);

        for(timeout = 0; timeout < 30; timeout++){  /*  30 * 1ms = 30ms */
            RPP_rw_pci_bar(prppdev, 0, 0, 4, 0x90, (UCHAR *)&temp);
            if ((((temp >> 16) & 0xffff) == 0xbeef) || (((temp >> 14) & 0x3) == 0x3)) {
                break;
            }
            KERNEL_WAIT(1);
        }

        if(timeout >= 30){
            DEV_ERROR(pdev, "pmic state: 0x%x status: 0x%x (timeout)\n", state, temp);
            return -ENODEV;
        }
    }

    return 0;
}


int rpp_set_power_mode_to_mpu(struct rpp_dev *pdev, uint32_t mode)
{
    int ret = 0;
    uint32_t *buf = NULL;
    struct rpp_dev *prppdev = pdev;
    uint8_t timeout = 0;
    uint64_t size = sizeof(uint32_t) * 4;

    if(prppdev->fw_version >= 0x3) {
        buf = (uint32_t*)kzalloc(size, GFP_KERNEL);
        if(buf == NULL){
            return -ENODEV;
        }

        /*  start [8:13] length */
        /*  |-- start --|-- parameter --|-- end --| */
        /*  |-- 0xabcd4005 --|-- mode --|-- 0x89abcdef --| */
        buf[0] = 0xabcd4005 | (0x4<<8);
        buf[1] = mode;
        buf[2] = 0x89abcdef;
        buf[3] = 0xffffffff;

        /*  send to mpu sram */
        ret = rpp_xfer_single_uninterruptible(prppdev, (void*)buf, MPU0_GLOBAL_ADDR + prppdev->cmd_base_addr + 0x90, (size - sizeof(uint32_t)), 1, 0, 10);
        if(ret != (size - sizeof(uint32_t))){
            DEV_ERROR(prppdev, "%s, set power mode failed\n", __func__);
            kfree(buf);
            return -ENODEV;
        }

        /*  get power mode set status */
        for(timeout = 0; timeout < 30; timeout++){  /*  30 * 30ms = 900ms */
            ret = rpp_xfer_single_uninterruptible(pdev, (void*)&buf[3], MPU0_GLOBAL_ADDR + 0x40034, sizeof(uint32_t), 0, 0, 10);
            if(ret != sizeof(uint32_t)){
                DEV_ERROR(prppdev, "%s, get power mode status failed\n", __func__);
                kfree(buf);
                return -ENODEV;
            }
            DEV_DEBUG(pdev, "power mode: 0x%x status: 0x%x\n", mode, buf[3]);

            if((buf[3] == 0x1) && mode == RPP_PWRMODE_LOW_POWER) break;
            if((buf[3] == 0x0) && mode == RPP_PWRMODE_WORKING) break;

            KERNEL_WAIT(30);
        }

        if(timeout >= 30){
            DEV_ERROR(pdev, "power mode: 0x%x status: 0x%x (timeout)\n", mode, buf[3]);
            kfree(buf);
            return -ENODEV;
        }

        kfree(buf);
    }
    else{
        DEV_ERROR(prppdev, "The firmware config version is not 0x3 (0x%x), Not support\n", prppdev->fw_version);
        return -ENODEV;
    }

    return 0;
}

int rpp_set_power_mode(struct rpp_dev *pdev, uint32_t mode)
{
    if(mode == pdev->hw_state.pwr_state) {
        return 0;
    }

    if(rpp_set_power_mode_to_mpu(pdev, mode) != 0) {
        DEV_ERROR(pdev, "set power state error, mode 0x%x\n", mode);
        return -EINVAL;
    }
    pdev->hw_state.pwr_state = mode;

    return 0;
}

int rpp_set_worker_mode_to_mpu(struct rpp_dev *pdev, uint32_t mode)
{
    int ret = 0;
    uint32_t *buf = NULL;
    struct rpp_dev *prppdev = pdev;
    uint8_t timeout = 0;
    uint64_t size = sizeof(uint32_t) * 4;

    if(prppdev->fw_version >= 0x3) {
        buf = (uint32_t*)kzalloc(size, GFP_KERNEL);
        if(buf == NULL){
            return -ENODEV;
        }

        /*  start [8:13] length */
        /*  |-- start --|-- parameter --|-- end --| */
        /*  |-- 0xabcd4006 --|-- mode --|-- 0x89abcdef --| */
        buf[0] = 0xabcd4006 | (0x4<<8);
        buf[1] = mode;
        buf[2] = 0x89abcdef;
        buf[3] = 0xffffffff;

        /*  send to mpu sram */
        ret = rpp_xfer_single_uninterruptible(prppdev, (void*)buf, MPU0_GLOBAL_ADDR + prppdev->cmd_base_addr + 0x90, (size - sizeof(uint32_t)), 1, 0, 10);
        if(ret != (size - sizeof(uint32_t))){
            DEV_ERROR(prppdev, "%s, set work mode failed\n", __func__);
            kfree(buf);
            return -ENODEV;
        }

        /*  get power mode set status */
        for(timeout = 0; timeout < 30; timeout++){  /*  30 * 30ms = 900ms */
            ret = rpp_xfer_single_uninterruptible(pdev, (void*)&buf[3], MPU0_GLOBAL_ADDR + 0x40038, sizeof(uint32_t), 0, 0, 10);
            if(ret != sizeof(uint32_t)){
                DEV_ERROR(prppdev, "%s, get work mode status failed\n", __func__);
                kfree(buf);
                return -ENODEV;
            }
           DEV_DEBUG(prppdev, "work mode: 0x%x status: 0x%x\n", mode, buf[3]);

            if(buf[3] == mode) break;

            KERNEL_WAIT(30);
        }

        if(timeout >= 30){
            DEV_ERROR(prppdev, "work mode: 0x%x status: 0x%x (timeout)\n", mode, buf[3]);
            kfree(buf);
            return -ENODEV;
        }

        kfree(buf);
    }
    else{
        DEV_ERROR(prppdev, "The firmware config version is not 0x3 (0x%x), Not support\n", prppdev->fw_version);
        return -ENODEV;
    }

    return 0;
}

int rpp_set_worker_mode(struct rpp_dev *pdev, uint32_t mode)
{
    int ret = 0;
    uint32_t workmode = 0;
    /*  pll 1 ~ 3 */
    /*  freq 3200 - 800 */
    uint8_t pll = 1;
    /*  uint16_t freq[8] = { 1840, 1840, 1656, 1472, 1288, 1104, 920, 920 }; */
    rpp_hw_states_t* phw_state = &pdev->hw_state;
    uint32_t pwrmode = phw_state->pwr_state;

    /*
     * Early return removed to fix resume issue.
     * When system resumes from suspend, hardware resets to MPU default (0x0A),
     * but wrk_user_state keeps the user's setting (e.g., 0x7F).
     */
    // if (phw_state->wrk_user_state == mode)
    //     return 0;

    /* from user
    * bit 0     DFS
    * bit 1     VE
    * bit 2     BOOST/BOOST_NEW -- (clear BOOST 0 send to mpu)
    * bit 3:5   PERF_MODE(0~7)
    */

    /* to mpu
    * bit 0     DFS
    * bit 1     VE
    * bit 2     BOOST
    * bit 3     SPECIAL
    * bit 4:6   PLL_TYPE
    * bit 7     reserved0
    * bit 8:15  vol
    * bit 16:31 freq
    */

    /*  */
    /*  support pll1 and new workmode */
    /*  */
    if (pdev->dev_info.sw_version_1 > 20241018) {
        /*  */
        /*  set pll frequency */
        /*  */
        if (((mode >> WORKMODE_PERF_BIT) & 0x0000000f) == 0) {
            /*  preferentially use the value that was set last time */
            if (((mode >> WORKMODE_BOOST_BIT) & 0x00000001)) {
                /*  old chip R8 and not A9V2 set BOOST_EN -- 2GHz pll1 */
                if ((((pdev->bl_config_info.board_mn >> 28) & 0xf) == RPP_CHIP_R8_MPW) && (pdev->bl_config_info.board_info != RPP_BOARD_A9_V2)) {
                    workmode = mode;
                }
                else {
                    workmode = (mode & 0x00000003) | ((UINT32)pll << 0x4) | (phw_state->wrk_state & 0xfffffff8);
                    SET_BIT(workmode, 3);

                }
            }
            else {
                workmode = mode;
            }
        }
        else {
            if ((((pdev->bl_config_info.board_mn >> 28) & 0xf) == RPP_CHIP_R8_MPW) && (pdev->bl_config_info.board_info != RPP_BOARD_A9_V2)) {
                DEV_ERROR(pdev, "RPP_CHIP_R8 and not RPP_BOARD_A9_V2 broad is not supprt set pll\n");
                return -ENODEV;
            }
            else{
                if(pdev->bl_config_info.board_info == RPP_BOARD_A9_V2) {
                    workmode = (mode & 0x00000003) | ((UINT32)pll << 0x4) | ((UINT32)(A9_V2_vol_mode[((mode >> WORKMODE_PERF_BIT) & 0x0000000f)] & 0xff) << 8) | ((UINT32)(A9_V2_freq_mode[((mode >> WORKMODE_PERF_BIT) & 0x0000000f)] * 2) << 16);
                } else if(pdev->bl_config_info.board_info == RPP_BOARD_A9_V2_DFT) {
                    workmode = (mode & 0x00000003) | ((UINT32)pll << 0x4) | ((UINT32)(A9_V2_DFT_vol_mode[((mode >> WORKMODE_PERF_BIT) & 0x0000000f)] & 0xff) << 8) | ((UINT32)(A9_V2_DFT_freq_mode[((mode >> WORKMODE_PERF_BIT) & 0x0000000f)] * 2) << 16);
                } else if(pdev->bl_config_info.board_info == RPP_BOARD_A10) {
                    workmode = (mode & 0x00000003) | ((UINT32)pll << 0x4) | ((UINT32)(A10_vol_mode[((mode >> WORKMODE_PERF_BIT) & 0x0000000f)] & 0xff) << 8) | ((UINT32)(A10_freq_mode[((mode >> WORKMODE_PERF_BIT) & 0x0000000f)] * 2) << 16);
                } else if(pdev->bl_config_info.board_info == RPP_BOARD_A9_V2_PLUS) {
                    workmode = (mode & 0x00000003) | ((UINT32)pll << 0x4) | ((UINT32)(A9_V2_PLUS_vol_mode[((mode >> WORKMODE_PERF_BIT) & 0x0000000f)] & 0xff) << 8) | ((UINT32)(A9_V2_PLUS_freq_mode[((mode >> WORKMODE_PERF_BIT) & 0x0000000f)] * 2) << 16);
                } else if(pdev->bl_config_info.board_info == RPP_BOARD_A15) {
                    workmode = (mode & 0x00000003) | ((UINT32)pll << 0x4) | ((UINT32)(A15_vol_mode[((mode >> WORKMODE_PERF_BIT) & 0x0000000f)] & 0xff) << 8) | ((UINT32)(A15_freq_mode[((mode >> WORKMODE_PERF_BIT) & 0x0000000f)] * 2) << 16);
                } else {
                    workmode = (mode & 0x00000003) | ((UINT32)pll << 0x4) | ((UINT32)(DEFAULT_vol_mode[((mode >> WORKMODE_PERF_BIT) & 0x0000000f)] & 0xff) << 8) | ((UINT32)(DEFAULT_freq_mode[((mode >> WORKMODE_PERF_BIT) & 0x0000000f)] * 2) << 16);
                }
                SET_BIT(workmode, 3);
            }
        }

        /*  set powermode woking */
        if (rpp_set_power_mode(pdev, (uint32_t)RPP_PWRMODE_WORKING) != 0) {
            DEV_ERROR(pdev, "set power state error, mode 0x%x\n", (uint32_t)RPP_PWRMODE_WORKING);
            return -ENODEV;
        }

        /*  send to mpu workmode, set pll need working mode to support */
        if (rpp_set_worker_mode_to_mpu(pdev, workmode) != 0) {
            DEV_ERROR(pdev, "set worker state error, mode 0x%x\n", workmode);
            ret = -ENODEV;
        }
        else {
            phw_state->wrk_state = workmode;
            phw_state->wrk_user_state = mode;
        }

        /*  restore powermode */
        if (rpp_set_power_mode(pdev, pwrmode) != 0) {
            DEV_ERROR(pdev, "set power state error, mode 0x%x\n", pwrmode);
            return ret;
        }
    }
    else { /*  not support pll1 and old workmode */
        workmode = mode;
        if (rpp_set_worker_mode_to_mpu(pdev, workmode) != 0) {
            DEV_ERROR(pdev, "set worker state error, mode 0x%x\n", workmode);
            ret = -ENODEV;
        }
        else {
            phw_state->wrk_state = workmode;
            phw_state->wrk_user_state = mode;
        }
    }

    return 0;
}

int rpp_genx_speed_change(struct rpp_dev *pdev, uint8_t genx)
{
    uint32_t temp = 0;
    uint32_t temp2 = 0;
    uint8_t count = 3;

    RPP_rw_pci_cfg(pdev->pdev, 0, 4, 0x80, (UCHAR*)&temp);
        if (genx == (uint8_t)((temp & 0x000f0000) >> 16)) {
        return 0;
    }

    DEV_INFO(pdev, "Enter Gen%d\n", genx);

    while (count--) {
        /* workaround, Link state to gen2 */
        temp = 0x0;
        RPP_rw_pci_cfg(pdev->pdev, 0, 4, 0xa0, (UCHAR*)&temp);
        temp = temp & 0xfffffff0;
        temp = temp | genx;
        RPP_rw_pci_cfg(pdev->pdev, 1, 4, 0xa0, (UCHAR*)&temp);

        temp = 0x0;
        RPP_rw_pci_cfg(pdev->pdev, 0, 4, 0x80c, (UCHAR*)&temp);
        temp = temp & 0xfffdffff; /*  0b1101 --> 0xd */
        RPP_rw_pci_cfg(pdev->pdev, 1, 4, 0x80c, (UCHAR*)&temp);

        temp = 0x0;
        RPP_rw_pci_cfg(pdev->pdev, 0, 4, 0x80c, (UCHAR*)&temp);
        temp = temp | 0x00020000; /*  0b0010 --> 0x2 */
        RPP_rw_pci_cfg(pdev->pdev, 1, 4, 0x80c, (UCHAR*)&temp);

        temp = 0xffffffff;
        temp2 = 0xffffffff;
        KERNEL_WAIT(100);
        RPP_rw_pci_cfg(pdev->pdev, 0, 4, 0x80c, (UCHAR*)&temp);
        RPP_rw_pci_cfg(pdev->pdev, 0, 4, 0x80, (UCHAR*)&temp2);

        /*  genx ok? */
        DEV_INFO(pdev, "Cfg read 0x80c value 0x%x 0x80 value 0x%x\n", temp, temp2);
        /* if (!(temp & 0x00020000)) { 0b0010 --> 0x2 */
        if (((temp2 & 0x000f0000) >> 16) == genx) { /*  _PCI_EXPRESS_CAPABILITY */
            RPP_rw_pci_cfg(pdev->pdev, 0, 4, 0x04, (UCHAR*)&temp);
            if (((temp & 0x00000006) != 0x0) && (temp != 0xffffffff)) {
                DEV_INFO(pdev, "Success change to Gen%d\n", genx);
                break;
            } else {
                /*  PCIe Link Reset */
                DEV_ERROR(pdev, "Failed to change Gen%d, cfg read 0x4 is 0x%x\n", genx, temp);
                return -ENODEV;
            }
        }
    }

    return 0;
}

int rpp_mpu_isr_enable(struct rpp_dev *pdev)
{
    int ret = 0;
    uint32_t data = 0;
    struct rpp_dev *prppdev = pdev;
    void *buf = NULL;

    if(prppdev->fw_version >= 0x3) {
        buf = kzalloc(sizeof(uint32_t), GFP_KERNEL);
        if(buf == NULL){
            return -ENODEV;
        }
        if (prppdev->cmd_base_addr == 0xfffffffe) {
            RPP_rw_pci_bar(prppdev, 0, 0, 4, 0x64, (PUCHAR)&data);
            data &= 0x3fff;
            data |= ((0xabcd << 16) | (0x1 << 14));
            RPP_rw_pci_bar(prppdev, 0, 1, 4, 0x64, (PUCHAR)&data);
            DEV_INFO(pdev, "MPU interrupt data 0x%x\n", data);
        } else {
            *(uint32_t*)buf = 0;
            ret = rpp_xfer_single(prppdev, buf, MPU0_GLOBAL_ADDR + prppdev->cmd_base_addr + 0x64, sizeof(uint32_t), 0, 0, 10);
            if(ret != sizeof(uint32_t)){
                kfree(buf);
                return -ENODEV;
            }

            (*(uint32_t*)buf) &= 0x3fff;
            (*(uint32_t*)buf) |= ((0xabcd << 16) | (0x1 << 14));
            ret = rpp_xfer_single(prppdev, buf, MPU0_GLOBAL_ADDR + prppdev->cmd_base_addr + 0x64, sizeof(uint32_t), 1, 0, 10);
            if(ret != sizeof(uint32_t)){
                kfree(buf);
                return -ENODEV;
            }

            kfree(buf);
        }
    }
    else {
        /*  enable MPU interrupt */
        RPP_rw_pci_bar(prppdev, 0, 0, 4, 0x64, (UCHAR *)&data);
        data &= 0x3fff;
        data |= ((0xabcd << 16) | (0x1 << 14));
        RPP_rw_pci_bar(prppdev, 0, 1, 4, 0x64, (UCHAR *)&data);
    }

    return 0;
}

int rpp_mpu_get_interrupt_info(struct rpp_dev *pdev, uint32_t *type, uint32_t *pvt, uint32_t *clk)
{
    int ret = 0;
    struct rpp_dev *prppdev = pdev;
    void *buf = NULL;

    if(prppdev->fw_version >= 0x3) {
        /* If the base addr is 0xfffffffe, it will be stored in the ddr and can be accessed using bar to obtain interrupt information */
        if (prppdev->cmd_base_addr == 0xfffffffe) {
            RPP_rw_pci_bar(prppdev, 0, 0, 4, 0x60, (UCHAR *)type);
            RPP_rw_pci_bar(prppdev, 0, 0, 4, 0x70, (UCHAR *)pvt);
            RPP_rw_pci_bar(prppdev, 0, 0, 4, 0x18, (UCHAR *)clk);
        } else {
        /* The interrupt information of the new architecture is stored in the mpu sram and cannot be accessed through the bar */
            /*  buf = kzalloc(sizeof(uint32_t), GFP_KERNEL); */
            /*  if(buf == NULL){ */
            /*      return -ENODEV; */
            /*  } */

            /*  ret = rpp_xfer_single(prppdev, buf, MPU0_GLOBAL_ADDR + prppdev->cmd_base_addr + 0x60, sizeof(uint32_t), 0, 0, 10); */
            /*  if(ret != sizeof(uint32_t)){ */
            /*      kfree(buf); */
            /*      return -ENODEV; */
            /*  } */
            /*  *type = *(uint32_t*)buf; */


            /*  ret = rpp_xfer_single(prppdev, buf, MPU0_GLOBAL_ADDR + prppdev->cmd_base_addr + 0x70, sizeof(uint32_t), 0, 0, 10); */
            /*  if(ret != sizeof(uint32_t)){ */
            /*      kfree(buf); */
            /*      return -ENODEV; */
            /*  } */
            /*  *pvt = *(uint32_t*)buf; */

            /*  ret = rpp_xfer_single(prppdev, buf, MPU0_GLOBAL_ADDR + prppdev->cmd_base_addr + 0x18, sizeof(uint32_t), 0, 0, 10); */
            /*  if(ret != sizeof(uint32_t)){ */
            /*      kfree(buf); */
            /*      return -ENODEV; */
            /*  } */
            /*  *clk = *(uint32_t*)buf; */

            /*  kfree(buf); */
            DEV_INFO(prppdev, "firmware version 0x%x, can not get MPU interrupt info\n", prppdev->fw_version);
        }
    }
    else {
        /*  get MPU interrupt info */
        RPP_rw_pci_bar(pdev, 0, 0, 4, 0x60, (UCHAR *)type);
	    RPP_rw_pci_bar(pdev, 0, 0, 4, 0x70, (UCHAR *)pvt);
	    RPP_rw_pci_bar(pdev, 0, 0, 4, 0x18, (UCHAR *)clk);
        DEV_INFO(prppdev, "MPU interrupt info type 0x%x, pvt 0x%x, clk 0x%x\n", *type, *pvt, *clk);
    }
    return 0;
}


static void rpp_rc_bdf_init(void)
{
	/*  202240222, willjiang, set the BDF table */
#if PETALINUX_FPGA_SUPPORT
	void __iomem *reg_base;
	void __iomem *ptr;
    uint32_t i = 0;
	uint32_t j = 0;
    uint32_t temp = 0;
	int data;

    for (i = 0; i < S_AXI_LITE_NUM; i++) {
        DEBUG_PRINT("%s, config the S_AXI_LITE %d.\n", __func__, i);
        reg_base = ioremap(S_AXI_LITE_ADDR + i*S_AXI_LITE_OFFS, sizeof(u32));
        if (!reg_base) {
            ERROR_PRINT("Failed to map register\n");
            return -ENOMEM;
        }

        temp = 0x0;
        temp = ioread32(reg_base);
        DEBUG_PRINT("%s, read result 0x%8x.\n", __func__, temp);
        iounmap(reg_base);

        reg_base = ioremap(S_AXI_LITE_CSR_ADDR + i*S_AXI_LITE_OFFS, 0x3000);
        if (!reg_base) {
            ERROR_PRINT("Failed to map register\n");
            return -ENOMEM;
        }
        temp = ioread32((void __iomem *)((uint8_t *)reg_base + 0xe00));
        DEBUG_PRINT("%s, 0xe00 read result 0x%08x.\n", __func__, temp);
        temp = ioread32((void __iomem *)((uint8_t *)reg_base + 0xe24));
        DEBUG_PRINT("%s, 0xe24 read result 0x%08x.\n", __func__, temp);
        temp = ioread32((void __iomem *)((uint8_t *)reg_base + 0xe28));
        DEBUG_PRINT("%s, 0xe28 read result 0x%08x.\n", __func__, temp);

        for (j = 0; j < 8; j++) {
            temp = ioread32((void __iomem *)((uint8_t *)reg_base + 0x2420 + j*0x20));
            DEBUG_PRINT("%s, 0x%x read result 0x%08x.\n", __func__, 0x2420+j*0x20, temp);
            temp = ioread32((void __iomem *)((uint8_t *)reg_base + 0x2424 + j*0x20));
            DEBUG_PRINT("%s, 0x%x read result 0x%08x.\n", __func__, 0x2424+j*0x20, temp);
            temp = ioread32((void __iomem *)((uint8_t *)reg_base + 0x2428 + j*0x20));
            DEBUG_PRINT("%s, 0x%x read result 0x%08x.\n", __func__, 0x2428+j*0x20, temp);
            temp = ioread32((void __iomem *)((uint8_t *)reg_base + 0x242c + j*0x20));
            DEBUG_PRINT("%s, 0x%x read result 0x%08x.\n", __func__, 0x242c+j*0x20, temp);
            temp = ioread32((void __iomem *)((uint8_t *)reg_base + 0x2430 + j*0x20));
            DEBUG_PRINT("%s, 0x%x read result 0x%08x.\n", __func__, 0x2430+j*0x20, temp);
        }

        for (j = 0; j < 8; j++) {
            ptr = (void __iomem *)((uint8_t *)reg_base + 0x2420 + j*0x20);
            iowrite32(PCIE_BUS_ADDR + i*PCIE_BUS_TOTALSIZE + j*PCIE_BUS_ENTRY_SIZE, ptr);
            ptr = (void __iomem *)((uint8_t *)reg_base + 0x2424 + j*0x20);
            iowrite32(0x0, ptr);
                ptr = (void __iomem *)((uint8_t *)reg_base + 0x2428 + j*0x20);
            iowrite32(0x0, ptr);
            ptr = (void __iomem *)((uint8_t *)reg_base + 0x242c + j*0x20);
            iowrite32(0x0, ptr);
            ptr = (void __iomem *)((uint8_t *)reg_base + 0x2430 + j*0x20);
            temp = 0xc0000000 | PCIE_BUS_WIN_SIZE;
            iowrite32(temp, ptr);
            ptr = (void __iomem *)((uint8_t *)reg_base + 0x2434 + j*0x20);
            iowrite32(0x0, ptr);
            DEBUG_PRINT("%s, after write the bdf.\n", __func__);
            temp = ioread32((void __iomem *)((uint8_t *)reg_base + 0x2420 + j*0x20));
            DEBUG_PRINT("%s, 0x%x read result 0x%08x.\n", __func__, 0x2420+j*0x20, temp);
            temp = ioread32((void __iomem *)((uint8_t *)reg_base + 0x2430 + j*0x20));
            DEBUG_PRINT("%s, 0x%x read result 0x%08x.\n", __func__, 0x2430+j*0x20, temp);
        }

        iounmap(reg_base);
    }
#endif
}


#if 1
/**
 * Module initialization function
 *
 * This function initializes the RPP module by:
 * 1. Setting up RC BDF mapping (FPGA support)
 * 2. Initializing subsystem devices (stream, char, virtual)
 * 3. Registering the PCI driver
 *
 * @return 0 on success, negative error code on failure
 */
#ifndef RPP_BUILD_PLATFORM
#define RPP_BUILD_PLATFORM "unknown"
#endif
#ifndef RPP_BUILD_VARIANT
#define RPP_BUILD_VARIANT "default"
#endif
#ifndef RPP_IDLE_LOW_POWER_ENABLE
#define RPP_IDLE_LOW_POWER_ENABLE 0
#endif

static void rpp_log_build_config(void)
{
	INFO_PRINT("RPP build config: platform=%s variant=%s IRQ_NUM=%d BAR_ACCESS_INLINE=%d IDLE_LOW_POWER=%d",
		   RPP_BUILD_PLATFORM, RPP_BUILD_VARIANT, IRQ_NUM,
		   BAR_ACCESS_INLINE, RPP_IDLE_LOW_POWER_ENABLE);
#ifdef VPU_HAL_MPU
	INFO_PRINT("RPP build config: VPU_HAL_MPU=1");
#endif
}

static int __init rpp_mod_init(void)
{
	int rv = 0;

	rpp_log_build_config();
	INFO_PRINT("%s", version);

    DEBUG_PRINT("before rpp_rc_bdf_init");
    rpp_rc_bdf_init();

    DEBUG_PRINT("before rpp_dma_kthread_init\n");
    rv = rpp_dma_kthread_init();
	if (rv != 0)
		return rv;

    DEBUG_PRINT("before rpp_sdev_info_init");
	rv = rpp_sdev_info_init();
	if (rv != 0)
		return rv;

    DEBUG_PRINT("before rpp_cdev_info_init");
	rv = rpp_cdev_info_init();
	if (rv != 0)
		return rv;

    DEBUG_PRINT("before rpp_vdev_info_init");
    rv = rpp_vdev_info_init();
    if (rv != 0)
        return rv;

    DEBUG_PRINT("before RPP_init");
    rv =  RPP_init();
	if (rv != 0)
		return rv;

    DEBUG_PRINT("rpp_mod_init end.");

	return 0;
}

static void __exit rpp_mod_exit(void)
{

   	/* unregister this driver from the PCI bus driver */
    DEBUG_PRINT("rpp_mod_exit.\n");

    RPP_cleanup();

    DEBUG_PRINT("rpp_sdev_info_exit.\n");
    rpp_sdev_info_exit();

	DEBUG_PRINT("rpp_cdev_info_exit.\n");
	rpp_cdev_info_exit();

	DEBUG_PRINT("rpp_vdev_info_exit.\n");
    rpp_vdev_info_exit();

    DEBUG_PRINT("rpp_dma_kthread_exit.\n");
    rpp_dma_kthread_exit();

	INFO_PRINT("rpp_mod_exit end.\n");
}
#endif


module_init(rpp_mod_init);
module_exit(rpp_mod_exit);
