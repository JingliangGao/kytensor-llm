
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/version.h>
#include <linux/string.h>
#include <linux/mm.h>
#include <linux/io.h>
#include <linux/errno.h>
#include <linux/sched.h>
#include <linux/vmalloc.h>
#include <linux/idr.h>
#include <asm/cacheflush.h>
#include <linux/delay.h>
#include "include/rpp_hal_pcie.h"
#include "include/pci-dma-compat.h"

static void rpp_dma_abort_channels(struct rpp_dev *pdev, DMA_DIRC dirc, bool two_channels)
{
	HAL_DMA_RET ret;

	ret = HalDmaAbort(&pdev->RPP_ext.DmaRsc, dirc, 0);
	if (ret != DMA_SUCCESS)
		DEV_WARN(pdev, "abort DMA ch0 failed: %s\n", HalDmaGetErrInfo(ret));

	if (two_channels) {
		ret = HalDmaAbort(&pdev->RPP_ext.DmaRsc, dirc, 1);
		if (ret != DMA_SUCCESS)
			DEV_WARN(pdev, "abort DMA ch1 failed: %s\n", HalDmaGetErrInfo(ret));
	}
}

void rpp_snps_xfer_done_callback(DMA_DIRC dirc, UINT8 chan, PVOID ctx)
{
	PDEVICE_EXTENSION pDevExt = (PDEVICE_EXTENSION)ctx;
	struct rpp_dev *priv = container_of(pDevExt, struct rpp_dev, RPP_ext);
	PCHAN_INFO_EX pChInfEx = dirc == DMA_WRITE ? &pDevExt->WrChInfEx[chan]
	    : &pDevExt->RdChInfEx[chan];

	DEBUG_PRINT("%s\n", __func__);

	if (!completion_done(&priv->xfer_done))
		complete(&priv->xfer_done);
}


int rpp_xfer_sgt(struct rpp_dev *pdev,
						struct sg_table *sgt,
						uint64_t dev_addr,
						uint64_t size,
						bool write,
						uint32_t timeout_ms)
{
	struct rpp_dev *priv = (struct rpp_dev *)pdev;
	PDEVICE_EXTENSION pDevExt = &priv->RPP_ext;
	CMD_INFO cmdinfo;
	UINT32 status = STATUS_SUCCESS;
	ssize_t rsize = 0;
	long time_left = timeout_ms;
	DMA_CHAN_STATUS stat;
	DMA_ERR err;
	UINT64 xferred;
	UINT32 intCntDone;
	UINT32 intCntAbort;

	/* dma init */
	cmdinfo.Cmd = DMA_CMD_INIT;
	cmdinfo.Chan = 0;
	cmdinfo.Dirc = DMA_WRITE;
	cmdinfo.End = DMA_CHAN_HST;
	cmdinfo.LLElements = 0;
	cmdinfo.WaterMark = 0;
	cmdinfo.Weight = 1;
	cmdinfo.Len = 0x200;
	cmdinfo.Recyc = 1;
	cmdinfo.Offset = 0;
	cmdinfo.Chk = 0;
	cmdinfo.Queue = 0;
	cmdinfo.Ddr = 0;
	cmdinfo.Upstream = 0x1;
	IoctlDmaInit2(priv, pDevExt, &cmdinfo, rpp_snps_xfer_done_callback);

	init_completion(&priv->xfer_done);

	/* write means DMA_READ at DMA engine */
	status = IoctlDmaRW3(priv, 0, (write ? DMA_READ : DMA_WRITE), dev_addr, sgt, 1, 0);

	if (status == STATUS_SUCCESS) {
		time_left = wait_for_completion_interruptible_timeout(&priv->xfer_done, msecs_to_jiffies(timeout_ms));
		if (time_left == 0) {
			DEV_ERROR(pdev, "%s, ch %d, wait for xfer %s dev 0x%llx timeout\n", __func__, 0, (write ? "to" : "from"), dev_addr);
			rsize = 0;
			return rsize;
		}
		DEV_DEBUG(pdev, "%s, wait_for_completion_interruptible\n", __func__);

		status = IoctlDmaState(priv, (write ? DMA_READ : DMA_WRITE), 0, &stat, &err, NULL, NULL, NULL);
		if (status == STATUS_SUCCESS) {
			if ((stat == CHAN_STOPPED) && (err == DMA_ERR_NONE)) {
				rsize = size;
			} else {
				DEV_ERROR(pdev, "%s, ch %d, xfer %s dev 0x%llx failed, stat %d, err %d\n", __func__, 0, (write ? "to" : "from"), dev_addr, stat, err);
				rsize = 0;	
			}
		} else {
			rsize = 0;
		}

	} else {
		rsize = 0;
	}

	return rsize;
}


EXPORT_SYMBOL_GPL(rpp_xfer_sgt);


int rpp_xfer_blks_ch(struct 	rpp_dev *pdev,
							DMA_CHANNEL ch,
							PDMA_BLKS_INFO info,
							uint64_t dev_addr,
							uint64_t size,
							bool write,
							uint32_t timeout_ms)
{
	struct rpp_dev *priv = (struct rpp_dev *)pdev;
	PDEVICE_EXTENSION pDevExt = &priv->RPP_ext;
	CMD_INFO cmdinfo;
	UINT32 status = STATUS_SUCCESS;
	ssize_t rsize = 0;
	long time_left = timeout_ms;
	DMA_CHAN_STATUS stat;
	DMA_ERR err;
	UINT64 xferred;
	UINT32 intCntDone;
	UINT32 intCntAbort;
	DMA_DIRC dirc = write ? DMA_READ : DMA_WRITE;
	bool pm_abort = false;
	RPP_DMA_RW5_ROUTE route;
	UINT8 chan;
	UINT8 pong;
	UINT8 rw5_ch;

	if (READ_ONCE(priv->pm_suspending)) {
		DEV_WARN(pdev,
			"%s, skip DMA xfer %s dev 0x%llx due to PM suspend\n",
			__func__, (write ? "to" : "from"), dev_addr);
		return 0;
	}

	// dma init
	cmdinfo.Cmd = DMA_CMD_INIT;
	cmdinfo.Chan = 0;
	cmdinfo.Dirc = DMA_WRITE;
	cmdinfo.End = DMA_CHAN_HST;
	cmdinfo.LLElements = 0;
	cmdinfo.WaterMark = 0;
	cmdinfo.Weight = 1;
	cmdinfo.Len = 0x200;
	cmdinfo.Recyc = 1;
	cmdinfo.Offset = 0;
	cmdinfo.Chk = 0;
	cmdinfo.Queue = 0;
	cmdinfo.Ddr = 0;
	cmdinfo.Upstream = 0x1;
	IoctlDmaInit2(priv, pDevExt, &cmdinfo, rpp_snps_xfer_done_callback);

	init_completion(&priv->xfer_done);

	if (READ_ONCE(priv->pm_suspending)) {
		DEV_WARN(pdev,
			"%s, skip DMA xfer %s dev 0x%llx after PM suspend started\n",
			__func__, (write ? "to" : "from"), dev_addr);
		return 0;
	}
	WRITE_ONCE(priv->pm_abort_xfer, false);
	WRITE_ONCE(priv->dma_xfer_active, true);

	if (ch == CH0_CH1) {
		rw5_ch = 0;
	} else if (ch == CH2) {
		rw5_ch = 2;
	} else if (ch == CH3) {
		rw5_ch = 3;
	} else {
		WRITE_ONCE(priv->dma_xfer_active, false);
		return 0;
	}

	status = rpp_dma_rw5_select_route(rw5_ch, info, &chan, &pong, &route);
	if (status != STATUS_SUCCESS) {
		WRITE_ONCE(priv->dma_xfer_active, false);
		return 0;
	}

	// write means DMA_READ at DMA engine
	status = IoctlDmaRW5(priv, rw5_ch, dirc, dev_addr, info, 0);

	if (status == STATUS_SUCCESS) {
		time_left = wait_for_completion_interruptible_timeout(&priv->xfer_done,
			msecs_to_jiffies(timeout_ms));
		WRITE_ONCE(priv->dma_xfer_active, false);
		pm_abort = READ_ONCE(priv->pm_abort_xfer);
		WRITE_ONCE(priv->pm_abort_xfer, false);
		if (pm_abort || time_left <= 0) {
			DEV_WARN(pdev,
				"%s, wait for xfer %s dev 0x%llx failed, pm_abort=%d time_left=%ld\n",
				__func__, (write ? "to" : "from"), dev_addr,
				pm_abort ? 1 : 0, time_left);
			rsize = 0;
			return rsize;
		}
		DEV_TRACE(pdev, "%s, wait_for_completion_interruptible\n", __func__);

		// Check primary channel state
		DMA_CHAN_STATUS stat0;
		DMA_ERR err0;
		UINT64 xferred0;
		UINT32 intCntDone0;
		UINT32 intCntAbort0;
		
		status = IoctlDmaState(priv, dirc, chan, &stat0, &err0, NULL, NULL, NULL);
		if (status != STATUS_SUCCESS) {
			DEV_ERROR(pdev, "%s, ch %d, failed to get state, status %d\n", __func__, chan, status);
			rsize = 0;
			return rsize;
		}
		
		// Check primary channel error
		if (err0 != DMA_ERR_NONE) {
			DEV_ERROR(pdev, "%s, ch %d, xfer %s dev 0x%llx failed, err %d\n", __func__, chan, (write ? "to" : "from"), dev_addr, err0);
			rsize = 0;
			return rsize;
		}
		
		// Poll primary channel until CHAN_STOPPED
		if (stat0 != CHAN_STOPPED) {
			int retry_count = 0;
			const int max_retries = 1000; // 100ms total (1000 * 100us)
			
			DEV_WARN(pdev, "%s, ch %d, stat is %d, polling it\n", __func__, chan, stat0);
			while (retry_count < max_retries) {
				udelay(100);
				status = IoctlDmaState(priv, dirc, chan, &stat0, &err0, NULL, NULL, NULL);
				if (status != STATUS_SUCCESS) {
					DEV_ERROR(pdev, "%s, ch %d, failed to get state during polling, status %d\n", __func__, chan, status);
					rsize = 0;
					return rsize;
				}
				if (err0 != DMA_ERR_NONE) {
					DEV_ERROR(pdev, "%s, ch %d, err %d during polling\n", __func__, chan, err0);
					rsize = 0;
					return rsize;
				}
				if (stat0 == CHAN_STOPPED) {
					DEV_DEBUG(pdev, "%s, ch %d, completed after %d polls\n", __func__, chan, retry_count);
					break;
				}
				retry_count++;
			}
			
			if (retry_count >= max_retries) {
				DEV_ERROR(pdev, "%s, ch %d, timeout after polling %d times (100ms), final stat %d, err %d\n", 
					__func__, chan, max_retries, stat0, err0);
				rsize = 0;
				return rsize;
			}
		}
		
		// Only CH0 multiple-block route uses the secondary ping-pong channel.
		if (route != RPP_DMA_RW5_ROUTE_PINGPONG_DESC) {
			rsize = size;
			return rsize;
		}
		
		// For two channels, check secondary channel
		DMA_CHAN_STATUS stat1;
		DMA_ERR err1;
		UINT64 xferred1;
		UINT32 intCntDone1;
		UINT32 intCntAbort1;
		
		status = IoctlDmaState(priv, dirc, pong, &stat1, &err1, NULL, NULL, NULL);
		if (status != STATUS_SUCCESS) {
			DEV_ERROR(pdev, "%s, ch %d, failed to get state, status %d\n", __func__, pong, status);
			rsize = 0;
			return rsize;
		}
		
		// Check secondary channel error
		if (err1 != DMA_ERR_NONE) {
			DEV_ERROR(pdev, "%s, ch %d, xfer %s dev 0x%llx failed, err %d\n", __func__, pong, (write ? "to" : "from"), dev_addr, err1);
			rsize = 0;
			return rsize;
		}
		
		// Poll secondary channel until CHAN_STOPPED
		if (stat1 != CHAN_STOPPED) {
			int retry_count = 0;
			const int max_retries = 1000; // 100ms total (1000 * 100us)
	
			DEV_WARN(pdev, "%s, ch %d, stat is %d, polling it\n", __func__, pong, stat1);
			while (retry_count < max_retries) {
				udelay(100);
				status = IoctlDmaState(priv, dirc, pong, &stat1, &err1, NULL, NULL, NULL);
				if (status != STATUS_SUCCESS) {
					DEV_ERROR(pdev, "%s, ch %d, failed to get state during polling, status %d\n", __func__, pong, status);
					rsize = 0;
					return rsize;
				}
				if (err1 != DMA_ERR_NONE) {
					DEV_ERROR(pdev, "%s, ch %d, err %d during polling\n", __func__, pong, err1);
					rsize = 0;
					return rsize;
				}
				if (stat1 == CHAN_STOPPED) {
					DEV_DEBUG(pdev, "%s, ch %d, completed after %d polls\n", __func__, pong, retry_count);
					break;
				}
				retry_count++;
			}
			
			if (retry_count >= max_retries) {
				DEV_ERROR(pdev, "%s, ch %d, timeout after polling %d times (100ms), final stat %d, err %d\n", 
					__func__, pong, max_retries, stat1, err1);
				rsize = 0;
				return rsize;
			}
		}
		
		// Both channels completed successfully
		rsize = size;
	} else {
		WRITE_ONCE(priv->dma_xfer_active, false);
		WRITE_ONCE(priv->pm_abort_xfer, false);
		rsize = 0;
	}

	return rsize;

}


EXPORT_SYMBOL_GPL(rpp_xfer_blks_ch);

int rpp_xfer_blks(struct 	rpp_dev *pdev,
							PDMA_BLKS_INFO info,
							uint64_t dev_addr,
							uint64_t size,
							bool write,
							uint32_t timeout_ms)
{
	return rpp_xfer_blks_ch(pdev, CH0_CH1, info, dev_addr, size, write, timeout_ms);
}

EXPORT_SYMBOL_GPL(rpp_xfer_blks);


int rpp_xfer_blks_async(struct 	rpp_dev *pdev,
							DMA_CHANNEL ch,
							PDMA_BLKS_INFO info,
							uint64_t dev_addr,
							uint64_t size,
							bool write,
							uint32_t timeout_ms)
{
	struct rpp_dev *priv = (struct rpp_dev *)pdev;
	PDEVICE_EXTENSION pDevExt = &priv->RPP_ext;
	CMD_INFO cmdinfo;
	UINT32 status = STATUS_SUCCESS;
	ssize_t rsize = 0;

	// dma init
	cmdinfo.Cmd = DMA_CMD_INIT;
	cmdinfo.Chan = 0;
	cmdinfo.Dirc = DMA_WRITE;
	cmdinfo.End = DMA_CHAN_HST;
	cmdinfo.LLElements = 0;
	cmdinfo.WaterMark = 0;
	cmdinfo.Weight = 1;
	cmdinfo.Len = 0x200;
	cmdinfo.Recyc = 1;
	cmdinfo.Offset = 0;
	cmdinfo.Chk = 0;
	cmdinfo.Queue = 0;
	cmdinfo.Ddr = 0;
	cmdinfo.Upstream = 0x1;
	IoctlDmaInit2(priv, pDevExt, &cmdinfo, rpp_snps_xfer_done_callback);

	// init_completion(&priv->xfer_done);

	// write means DMA_READ at DMA engine
	if (ch == CH0_CH1) {
		status = IoctlDmaRW4(priv, 0, 1, (write ? DMA_READ : DMA_WRITE), dev_addr, info, 0);
	} 
	else if (ch == CH2) {
		status = IoctlDmaRW4_1(priv, 2, (write ? DMA_READ : DMA_WRITE), dev_addr, info, 0);
	}
	else if (ch == CH3) {
		status = IoctlDmaRW4_1(priv, 3, (write ? DMA_READ : DMA_WRITE), dev_addr, info, 0);
	}
	else {
		ERROR_PRINT("%s: invalid channel %d.\n", __func__, ch);

		rsize = 0;
		return rsize;
	}
	
	if (status == STATUS_SUCCESS) {
		// wait_for_completion_interruptible(&priv->xfer_done);
		DTRACE("%s, wait_for_completion_interruptible\n", __func__);
		rsize = size;
	} else {
		rsize = 0;
	}

	return rsize;
}

EXPORT_SYMBOL_GPL(rpp_xfer_blks_async);


static int __rpp_xfer_single(struct rpp_dev *pdev,
						void *buf,
						uint64_t dev_addr,
						uint64_t size,
						bool write,
						bool dma_mapped,
						uint32_t timeout_ms,
						bool interruptible)
{
	struct rpp_dev *priv = (struct rpp_dev *)pdev;
	PDEVICE_EXTENSION pDevExt = &priv->RPP_ext;
	CMD_INFO cmdinfo;
	dma_addr_t dma_addr;
	UINT32 status = STATUS_SUCCESS;
	ssize_t rsize = 0;
	long time_left = timeout_ms;
	DMA_CHAN_STATUS stat;
	DMA_ERR err;
	UINT64 xferred;
	UINT32 intCntDone;
	UINT32 intCntAbort;

	/*  dma init */
	cmdinfo.Cmd = DMA_CMD_INIT;
	cmdinfo.Chan = 0;
	cmdinfo.Dirc = DMA_WRITE;
	cmdinfo.End = DMA_CHAN_HST;
	cmdinfo.LLElements = 0;
	cmdinfo.WaterMark = 0;
	cmdinfo.Weight = 1;
	cmdinfo.Len = 0x200;
	cmdinfo.Recyc = 1;
	cmdinfo.Offset = 0;
	cmdinfo.Chk = 0;
	cmdinfo.Queue = 0;
	cmdinfo.Ddr = 0;
	cmdinfo.Upstream = 0x1;
	IoctlDmaInit2(priv, pDevExt, &cmdinfo, rpp_snps_xfer_done_callback);

	if (!dma_mapped) {
		/*  map the host */
		if (write)
			dma_addr = pci_map_single(priv->pdev, buf, size, PCI_DMA_TODEVICE);
		else
			dma_addr = pci_map_single(priv->pdev, buf, size, PCI_DMA_FROMDEVICE);

		DEV_TRACE(pdev, "rpp_xfer_single dma_addr 0x%llx, virt 0x%llx\n", dma_addr, buf);
	} else {
		dma_addr = (dma_addr_t)buf;
	}

	init_completion(&priv->xfer_done);
	/*  write means DMA_READ at DMA engine */
	status = IoctlDmaRW2(priv, 0, (write ? DMA_READ : DMA_WRITE), dev_addr, dma_addr, size, timeout_ms);

	if (status == STATUS_SUCCESS) {
		if (interruptible)
			time_left = wait_for_completion_interruptible_timeout(
				&priv->xfer_done, msecs_to_jiffies(timeout_ms));
		else
			time_left = wait_for_completion_timeout(
				&priv->xfer_done, msecs_to_jiffies(timeout_ms));
		if (time_left == 0) {
			DEV_ERROR(pdev, "%s, ch %d, wait for xfer %s dev 0x%llx timeout\n", __func__, 0, (write ? "to" : "from"), dev_addr);
			rsize = 0;
			return rsize;
		}
		DEV_DEBUG(pdev, "%s, wait_for_completion_interruptible\n", __func__);

		status = IoctlDmaState(priv, (write ? DMA_READ : DMA_WRITE), 0, &stat, &err, NULL, NULL, NULL);
		if (status == STATUS_SUCCESS) {
			if ((stat == CHAN_STOPPED) && (err == DMA_ERR_NONE)) {
				rsize = size;
			} else {
				DEV_ERROR(pdev, "%s, ch %d, xfer %s dev 0x%llx failed, stat %d, err %d\n", __func__, 0, (write ? "to" : "from"), dev_addr, stat, err);
				rsize = 0;	
			}
		} else {
			rsize = 0;
		}
	} else {
		rsize = 0;
	}

	if (!dma_mapped) {
		/*  Unmap the host */
		if (write)
			pci_unmap_single(priv->pdev, dma_addr, size, PCI_DMA_TODEVICE);
		else
			pci_unmap_single(priv->pdev, dma_addr, size, PCI_DMA_FROMDEVICE);
	}

	return rsize;
}

int rpp_xfer_single(struct rpp_dev *pdev,
						void *buf,
						uint64_t dev_addr,
						uint64_t size,
						bool write,
						bool dma_mapped,
						uint32_t timeout_ms)
{
	return __rpp_xfer_single(pdev, buf, dev_addr, size, write,
		dma_mapped, timeout_ms, true);
}

EXPORT_SYMBOL_GPL(rpp_xfer_single);

int rpp_xfer_single_uninterruptible(struct rpp_dev *pdev,
						void *buf,
						uint64_t dev_addr,
						uint64_t size,
						bool write,
						bool dma_mapped,
						uint32_t timeout_ms)
{
	return __rpp_xfer_single(pdev, buf, dev_addr, size, write,
		dma_mapped, timeout_ms, false);
}

EXPORT_SYMBOL_GPL(rpp_xfer_single_uninterruptible);

void rpp_io_write32(struct rpp_dev *pdev, uint32_t data, uint32_t addr)
{
	uint32_t new_offs = addr;

	if (pdev->small_bar) {
		if (new_offs > 0x7000000) {
			new_offs -= 0x7000000;
			RPP_rw_pci_bar(pdev, XMPU_BAR, 1, 4, new_offs, (UCHAR *)&data);
		} else if ((new_offs >= 0x2000000) & (new_offs < 0x7000000)) {
			new_offs -= 0x2000000;
			RPP_rw_pci_bar(pdev, XCFG_BAR, 1, 4, new_offs, (UCHAR *)&data);
		} else {
		    DEV_ERROR(pdev, "%s, unsupported address 0x%x at small bar solution.\n", __func__, new_offs);
		}
	} else {
		RPP_rw_pci_bar(pdev, XCFG_BAR, 1, 4, new_offs, (UCHAR *)&data);
	}
}

EXPORT_SYMBOL_GPL(rpp_io_write32);


uint32_t rpp_io_read32(struct rpp_dev *pdev, uint32_t addr)
{
	uint32_t data;
	uint32_t new_offs = addr;

	if (pdev->small_bar) {
		if (new_offs >= 0x7000000) {
			new_offs -= 0x7000000;
			RPP_rw_pci_bar(pdev, XMPU_BAR, 0, 4, new_offs, (UCHAR *)&data);
		} else if ((new_offs >= 0x2000000) & (new_offs < 0x7000000)) {
			new_offs -= 0x2000000;
			RPP_rw_pci_bar(pdev, XCFG_BAR, 0, 4, new_offs, (UCHAR *)&data);
		} else {
		    DEV_ERROR(pdev, "%s, unsupported address 0x%x at small bar solution.\n", __func__, new_offs);
		}
	} else {
		RPP_rw_pci_bar(pdev, XCFG_BAR, 0, 4, new_offs, (UCHAR *)&data);
	}

	return data;
}

EXPORT_SYMBOL_GPL(rpp_io_read32);

#if 0
void rpp_io_write16(struct rpp_dev *pdev, uint16_t data, uint32_t addr)
{
	RPP_rw_pci_bar(pdev, XCFG_BAR, 1, 2, addr, (UCHAR *)&data);
}

EXPORT_SYMBOL_GPL(rpp_io_write16);

uint16_t rpp_io_read16(struct rpp_dev *pdev, uint32_t addr)
{
	uint16_t data;
	RPP_rw_pci_bar(pdev, XCFG_BAR, 0, 2, addr, (UCHAR *)&data);
	return data;
}

EXPORT_SYMBOL_GPL(rpp_io_read16);

void rpp_io_write8(struct rpp_dev *pdev, uint8_t data, uint32_t addr)
{
	RPP_rw_pci_bar(pdev, XCFG_BAR, 1, 1, addr, (UCHAR *)&data);
}

EXPORT_SYMBOL_GPL(rpp_io_write8);

uint8_t rpp_io_read8(struct rpp_dev *pdev, uint32_t addr)
{
	uint8_t data;
	RPP_rw_pci_bar(pdev, XCFG_BAR, 0, 1, addr, (UCHAR *)&data);
	return data;
}

EXPORT_SYMBOL_GPL(rpp_io_read8);
#endif

int rpp_pcie_init(struct rpp_dev *pdev)
{
	struct rpp_pcie_cfg cfg;

	cfg.owner = (void *)pdev;
	/*  cfg.probe = rpp_reg_init; */
	/* cfg.isr = rpp_do_tasklet; */


   /* RPP_init(&cfg); */

	return 0;
}
EXPORT_SYMBOL_GPL(rpp_pcie_init);

void rpp_pcie_exit(struct rpp_dev *pdev)
{
	/* RPP_cleanup(pdev); */
}
EXPORT_SYMBOL_GPL(rpp_pcie_exit);

int rpp_remap(struct rpp_dev *pdev, uint32_t bar, struct vm_area_struct *vma)
{
	return RPP_remap_pci_bar(pdev, bar, vma);
}
EXPORT_SYMBOL_GPL(rpp_remap);
