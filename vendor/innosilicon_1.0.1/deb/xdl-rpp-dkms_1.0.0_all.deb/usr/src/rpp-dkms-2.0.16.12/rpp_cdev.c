/*
 * This file is part of the Azurengine DMA IP Core driver for Linux
 *
 * Copyright (c) 2016-present,  Azurengine, Inc.
 * All rights reserved.
 *
 * This source code is licensed under both the BSD-style license (found in the
 * LICENSE file in the root directory of this source tree) and the GPLv2 (found
 * in the COPYING file in the root directory of this source tree).
 * You may select, at your option, one of the above-listed licenses.
 */




#include <linux/fs.h>
#include <linux/sched.h>
#include <linux/err.h>

#include "include/rpp_cdev.h"
#define RPP_NODE_NAME	"rpp"
#define RPP_MINOR_BASE (0)
#define RPP_MINOR_COUNT_MAX (1023)
#define RPP_MINOR_COUNT (255)


struct rpp_cdev_info
{
	struct class *rpp_class;

/* device number info */
	dev_t dev;
	int major;
	int minor_assigned;
	int max_minor_num;
};



int g_rpp_cdev_info_init_flag = 0;
struct rpp_cdev_info  g_rpp_cdev_info;

int rpp_cdev_info_init(void)
{
	int rv = 0;

	/* already init, return directly. */
	if (g_rpp_cdev_info_init_flag == 1)
		return 0;

#if LINUX_VERSION_CODE < KERNEL_VERSION(6,4,0)
	g_rpp_cdev_info.rpp_class = class_create(THIS_MODULE, RPP_NODE_NAME);
#else
	g_rpp_cdev_info.rpp_class = class_create(RPP_NODE_NAME);
#endif
	if (IS_ERR(g_rpp_cdev_info.rpp_class)) {
		 ERROR_PRINT(RPP_NODE_NAME ": failed to create class");
		 return -1;
	}

	/* allocate a dynamically allocated char device node */
	rv = alloc_chrdev_region(&g_rpp_cdev_info.dev, RPP_MINOR_BASE, RPP_MINOR_COUNT_MAX, RPP_NODE_NAME);
	if (rv) {
		rv = alloc_chrdev_region(&g_rpp_cdev_info.dev, RPP_MINOR_BASE, RPP_MINOR_COUNT, RPP_NODE_NAME);
		if (rv) {
			ERROR_PRINT("unable to allocate cdev region %d.\n", rv);
			goto class_destroy_err;
		}
		g_rpp_cdev_info.major = MAJOR(g_rpp_cdev_info.dev);
		g_rpp_cdev_info.minor_assigned = 0;
		g_rpp_cdev_info.max_minor_num = RPP_MINOR_COUNT;
	} else {
		g_rpp_cdev_info.major = MAJOR(g_rpp_cdev_info.dev);
		g_rpp_cdev_info.minor_assigned = 0;
		g_rpp_cdev_info.max_minor_num = RPP_MINOR_COUNT_MAX;
	}

	DEBUG_PRINT("%s, max_minor_num=%d\n", __func__, g_rpp_cdev_info.max_minor_num);
	g_rpp_cdev_info_init_flag = 1;

	return 0;


class_destroy_err:
	class_destroy(g_rpp_cdev_info.rpp_class);
	g_rpp_cdev_info_init_flag = 0;

	return rv;
}


int alloc_cdev_no(dev_t *pdevno)
{
    int rv = 0;
	rv = rpp_cdev_info_init();
    if(rv != 0 )
       return rv;

   if(g_rpp_cdev_info.minor_assigned > g_rpp_cdev_info.max_minor_num)
   {
		ERROR_PRINT("there is no dev minor to be allocated\n");
		return -1;
   }

   *pdevno = MKDEV(g_rpp_cdev_info.major, g_rpp_cdev_info.minor_assigned);

    g_rpp_cdev_info.minor_assigned += 1;

	return 0;
}

void rpp_cdev_info_exit()
{

	/* no init , exit directly. */
	if (g_rpp_cdev_info_init_flag == 0)
		return;


	g_rpp_cdev_info_init_flag = 0;

	if (g_rpp_cdev_info.rpp_class)
		class_destroy(g_rpp_cdev_info.rpp_class);

	if (g_rpp_cdev_info.major)
		unregister_chrdev_region(g_rpp_cdev_info.dev, g_rpp_cdev_info.max_minor_num);

	g_rpp_cdev_info.major =0;
	g_rpp_cdev_info.minor_assigned = 0;
	g_rpp_cdev_info.max_minor_num = 0;


}


enum cdev_type {
	CHAR_ENTIRE_CTRL,
};

static const char * const devnode_names[] = {
	RPP_NODE_NAME "%d_entire_ctrl",
};


static inline void xpdev_flag_set(struct rpp_dev *xpdev,
				enum xpdev_flags_bits fbit)
{
	xpdev->flags |= 1 << fbit;
}

static inline void xcdev_flag_clear(struct rpp_dev *xpdev,
				enum xpdev_flags_bits fbit)
{
	xpdev->flags &= ~(1 << fbit);
}

static inline int xpdev_flag_test(struct rpp_dev *xpdev,
				enum xpdev_flags_bits fbit)
{
	return xpdev->flags & (1 << fbit);
}

/*
static int config_kobject(struct rpp_cdev *xcdev)
{
	int rv = -EINVAL;
	struct rpp_dev *xdev = (struct rpp_dev *)(xcdev->prppdev);

	rv = kobject_set_name(&xcdev->cdev.kobj, devnode_names[0], 	xdev->idx);
	if (rv)
		ERROR_PRINT("%s: , failed %d.\n", __func__, rv);


	ERROR_PRINT("%s: , xcdev->cdev.kobj.name: %s,  rv: %d.\n", __func__, xcdev->cdev.kobj.name, rv);

	return rv;
}
*/

int xcdev_check(const char *fname, struct rpp_cdev *xcdev, bool check_engine)
{
	struct rpp_dev *xdev;

	if (!xcdev) {
		DEV_INFO(xdev, "%s, xcdev 0x%p.\n",
			fname, xcdev);
		return -EINVAL;
	}

	xdev = (struct rpp_dev *)(xcdev->prppdev);
	if (!xdev) {
		DEV_INFO(xdev, "%s, xdev 0x%p.\n",
			fname, xdev);
		return -EINVAL;
	}

	if(xdev->status != RPP_PCIE_ONLINE){
		pid_t current_pid = task_pid_nr(current);

		/* Only print error once per process for the same status */
		if (xdev->last_error_pid != current_pid ||
		    xdev->last_error_status != xdev->status) {
			DEV_ERROR(xdev, "PID: %d, xdev status: RPP_PCIE_OFFLINE\n", current_pid);
			xdev->last_error_pid = current_pid;
			xdev->last_error_status = xdev->status;
		}
		return -EINVAL;
	}

	return 0;
}

int char_open(struct inode *inode, struct file *file)
{
	struct rpp_cdev *xcdev;

	/* pointer to containing structure of the character device inode */
	xcdev = container_of(inode->i_cdev, struct rpp_cdev, cdev);
	/* create a reference to our char device in the opened file */
	file->private_data = xcdev;

	return 0;
}

/*
 * Called when the device goes from used to unused.
 */
int char_close(struct inode *inode, struct file *file)
{
	struct rpp_dev *xdev;
	struct rpp_cdev *xcdev = (struct rpp_cdev *)file->private_data;

	if (!xcdev) {
		ERROR_PRINT("entire_ctrl_close: invalid character device\n");
		return -ENODEV;
	}

	/* fetch device specific data stored earlier during open */
	xdev = (struct rpp_dev *)(xcdev->prppdev);
	if (!xdev) {
		ERROR_PRINT("entire_ctrl_close: invalid RPP device\n");
		return -ENODEV;
	}

	return 0;
}

/* create_xcdev() -- create a character device interface to data or control bus
 *
 * If at least one SG DMA engine is specified, the character device interface
 * is coupled to the SG DMA file operations which operate on the data bus. If
 * no engines are specified, the interface is coupled with the control bus.
 */

static int create_sys_device(struct rpp_cdev *xcdev)
{
        struct rpp_dev *xdev = (struct rpp_dev *)(xcdev->prppdev);
		char name_str[256];
	/* int last_param = xcdev->bar; */

        xcdev->sys_device = device_create(g_rpp_cdev_info.rpp_class, &xdev->pdev->dev,
	                xcdev->cdevno, NULL, devnode_names[0], xdev->idx);

        if (IS_ERR_OR_NULL(xcdev->sys_device)) {
                int rv = xcdev->sys_device ? PTR_ERR(xcdev->sys_device) : -ENODEV;

                ERROR_PRINT("device_create(%s) failed %d\n", devnode_names[0], rv);
                xcdev->sys_device = NULL;
                return rv;
        }

		/* DEV_INFO(xdev, "device_create(%s), index %d success. \n", devnode_names[0], xdev->idx); */
		/* multi cards swp2539 */
		sprintf(name_str, devnode_names[0], xdev->idx);
		DEV_INFO(xdev, "device_create(%s), success.\n", name_str);

        return 0;
}

static int destroy_xcdev(struct rpp_cdev *cdev)
{
	if (!cdev) {
		WARNING_PRINT("cdev NULL.\n");
		return 0;
	}

	if (!cdev->prppdev) {
		ERROR_PRINT("destroy_xcdev: invalid RPP device pointer\n");
		return -EINVAL;
	}
	if (!g_rpp_cdev_info.rpp_class) {
		ERROR_PRINT("destroy_xcdev: invalid device class\n");
		return -EINVAL;
	}
	if (!cdev->sys_device) {
		ERROR_PRINT("destroy_xcdev: invalid sys device\n");
		return -EINVAL;
	}

	if (cdev->sys_device)
		device_destroy(g_rpp_cdev_info.rpp_class, cdev->cdevno);

	cdev_del(&cdev->cdev);

	return 0;
}

static int create_xcdev(struct rpp_dev *xpdev, struct rpp_cdev *xcdev, int bar)
{
	int rv;

    DEBUG_PRINT("create_xcdev enter:  0x%p.\n",	xcdev);

	spin_lock_init(&xcdev->lock);

	/*
	 * do not register yet, create kobjects and name them,
	 */

	xcdev->prppdev = xpdev;
	xcdev->bar = bar;
	xcdev->sys_device = NULL;

	cdev_entire_ctrl_init(xcdev);
	xcdev->cdev.owner = THIS_MODULE;

	rv = rpp_cdev_info_init();
	if (rv != 0)
		return rv;

	if (xpdev->idx < RPP_MINOR_BASE || xpdev->idx >= g_rpp_cdev_info.max_minor_num) {
		ERROR_PRINT("invalid cdev idx %d, max minor count %d\n",
		       xpdev->idx, g_rpp_cdev_info.max_minor_num);
		return -ENOSPC;
	}

	xcdev->cdevno = MKDEV(g_rpp_cdev_info.major, xpdev->idx);

	/* bring character device live */
	rv = cdev_add(&xcdev->cdev, xcdev->cdevno, 1);
	if (rv < 0) {
		ERROR_PRINT("cdev_add failed %d.\n", rv);
		return rv;
	}


	/* create device on our class */
	rv = create_sys_device(xcdev);
	if (rv < 0)
		goto del_cdev;



   	DEBUG_PRINT("create_xcdev sucess: 0x%p.\n",	xcdev);

	return 0;

del_cdev:
	cdev_del(&xcdev->cdev);

	return rv;
}

static void xpdev_destroy_interfaces(struct rpp_dev * pdev)
{
	/* remove user character device */
	destroy_xcdev(&pdev->entire_ctrl_cdev);
}

static int xpdev_create_interfaces(struct rpp_dev * pdev)
{
	int rv = 0;

	/* entire control */
	rv = create_xcdev(pdev, &pdev->entire_ctrl_cdev, 0);
	if (rv < 0) {
		ERROR_PRINT("create_char(entire control) failed\n");
		goto fail;
	}
	xpdev_flag_set(pdev, XDF_CDEV_ENTIRE_CTRL);

	return 0;

fail:
	rv = -1;
	xpdev_destroy_interfaces(pdev);
	return rv;
}


int rpp_cdev_init(struct rpp_dev * pdev)
{

    return xpdev_create_interfaces(pdev);
}

void rpp_cdev_exit(struct rpp_dev * pdev)
{

	xpdev_destroy_interfaces(pdev);
}
