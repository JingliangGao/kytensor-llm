/*
 * This file is part of the Azurengine DMA IP Core driver for Linux
 *
 * Copyright (c) 2016-present,  Azurengine, Inc.
 * All rights reserved.
 *
 * This source code is licensed under both the BSD-style license (found in the
 * LICENSE file in the root directory of this source tree) and the GPLv2 (found
 * in the COPYING file in the root directory of this source tree).
 * You may select, at your option, one of the above-listed licenses.
 */


#include <linux/types.h>
#include <linux/errno.h>
#include <linux/slab.h>

#include "include/rpp_hal_pcie.h"
#include "include/rpp_dev.h"

#define MPU0_GLOBAL_ADDR             0x1010000000
#define RPP_MPU_CMD_ADDR             0x90
#define RPP_MPU_CMD_MAGIC_HOST       0xabcd
#define RPP_MPU_CMD_MAGIC_MPU        0xbeef
#define RPP_MPU_CMD_MAGIC_DONE       0x89abcdef
#define RPP_MPU_CMD_STATE_SHIFT      14
#define RPP_MPU_CMD_STATE_MASK       0x3
#define RPP_MPU_CMD_PARAM_LEN_SHIFT  8
#define RPP_MPU_CMD_PARAM_LEN_MASK   0x3f
#define MCU_SLAVE_ADDR               0x50
#define MCU_VERSION_ADDR             0x10
#define RPP_DDR_BUF_ADDR             0x4000
#define RPP_MPU_DDR_BUF_ADDR         (0x40000000 + RPP_DDR_BUF_ADDR)
#define RPP_MPU_CMD_POLL_INTERVAL_MS 8
#define RPP_MPU_CMD_POLL_TIMEOUT_MS  40

typedef enum {
    CMD_INVALID = 0x0,
    CMD_DEV_CTRL,
    CMD_EEPROM,
    CMD_REBOOT,
    CMD_INTERNAL,
    CMD_POWER_MODE,
    CMD_WORKING_MODE,
    CMD_MAX,
} mpu_cmd_e;

typedef enum {
    I2C_UNKNOW = 0,
    I2C_READ = 2,
    I2C_WRITE = 3,
    REBOOT = 4,
} i2c_mode_e;

typedef enum {
    MPU_CMD_STATE_EMPTY = 0,
    MPU_CMD_STATE_RECV_SUCCESS = 1,
    MPU_CMD_STATE_DONE = 2,
    MPU_CMD_STATE_RECV_DONE = 3,
} mpu_cmd_state_e;

typedef union {
    struct {
        uint32_t mode          : 3;
        uint32_t iic_id        : 1;
        uint32_t addr_type     : 2;
        uint32_t slave_address : 8;
        uint32_t reserved0     : 2;
        uint32_t freq          : 16;
    };
    uint32_t val;
} iic_command_ctrl;

typedef union {
    struct {
        iic_command_ctrl command_ctrl;
        uint32_t addr;
        uint32_t ddr_addr;
        uint32_t size;
        uint32_t command_ctrl_magic_number;
    };
} cmd_params_u;

typedef union {
    struct {
        uint16_t ctrl;
        uint16_t magic;
    };
    uint32_t header;
} cmd_header_u;

typedef struct mpu_cmd_s {
    cmd_header_u header;
    cmd_params_u params;
} mpu_cmd_t;

static void rpp_mpu_ctrl_cmd_pre(mpu_cmd_e cmd, mpu_cmd_t *mpu_cmd)
{
    memset(mpu_cmd, 0, sizeof(*mpu_cmd));

    mpu_cmd->header.magic = RPP_MPU_CMD_MAGIC_HOST;
    mpu_cmd->header.ctrl = (cmd & 0xff) |
        (MPU_CMD_STATE_RECV_SUCCESS << RPP_MPU_CMD_STATE_SHIFT);
    mpu_cmd->params.command_ctrl_magic_number = RPP_MPU_CMD_MAGIC_DONE;
    mpu_cmd->header.ctrl |=
        (16 & RPP_MPU_CMD_PARAM_LEN_MASK) << RPP_MPU_CMD_PARAM_LEN_SHIFT;
}

static int rpp_mpu_ctrl_cmd_post(struct rpp_dev *pdev, mpu_cmd_e cmd,
    mpu_cmd_t *mpu_cmd)
{
    int ret;
    int params_ret;
    uint32_t elapsed_ms;
    uint8_t timeout = 100;
    uint64_t cmd_addr = MPU0_GLOBAL_ADDR + pdev->cmd_base_addr + RPP_MPU_CMD_ADDR;
    uint64_t params_addr = cmd_addr + sizeof(mpu_cmd->header);
    void *xfer_buf = NULL;
    size_t xfer_size = sizeof(*mpu_cmd);

    xfer_buf = kzalloc(xfer_size, GFP_KERNEL);
    if (xfer_buf == NULL) {
        return -ENOMEM;
    }

    if (pdev->fw_version >= 0x3) {
        memcpy(xfer_buf, &mpu_cmd->params, sizeof(mpu_cmd->params));
        params_ret = rpp_xfer_single(pdev, xfer_buf, params_addr,
            sizeof(mpu_cmd->params), 1, 0, timeout);
        if (params_ret == sizeof(mpu_cmd->params)) {
            memcpy(xfer_buf, &mpu_cmd->header, sizeof(mpu_cmd->header));
            ret = rpp_xfer_single(pdev, xfer_buf, cmd_addr,
                sizeof(mpu_cmd->header), 1, 0, timeout);
            if (ret != sizeof(mpu_cmd->header)) {
                DEV_WARN(pdev, "%s, write MPU cmd header failed, addr=0x%llx, ret=%d\n",
                    __func__, cmd_addr, ret);
                ret = -ENODEV;
                goto out;
            }
        } else {
            DEV_WARN(pdev, "%s, write MPU cmd params failed, addr=0x%llx, ret=%d\n",
                __func__, params_addr, params_ret);
            ret = -ENODEV;
            goto out;
        }
    } else {
        memcpy(xfer_buf, mpu_cmd, sizeof(*mpu_cmd));
        ret = rpp_xfer_single(pdev, xfer_buf, cmd_addr,
            sizeof(*mpu_cmd), 1, 0, timeout);
        if (ret != sizeof(*mpu_cmd)) {
            DEV_WARN(pdev, "%s, write MPU cmd failed, addr=0x%llx, ret=%d\n",
                __func__, cmd_addr, ret);
            ret = -ENODEV;
            goto out;
        }
    }

    for (elapsed_ms = 0; elapsed_ms < RPP_MPU_CMD_POLL_TIMEOUT_MS;
        elapsed_ms += RPP_MPU_CMD_POLL_INTERVAL_MS) {
        KERNEL_WAIT(RPP_MPU_CMD_POLL_INTERVAL_MS);

        ret = rpp_xfer_single(pdev, xfer_buf, cmd_addr,
            sizeof(mpu_cmd->header), 0, 0, timeout);
        if (ret != sizeof(mpu_cmd->header)) {
            DEV_WARN(pdev, "%s, read MPU cmd header failed, addr=0x%llx, ret=%d\n",
                __func__, cmd_addr, ret);
            ret = -ENODEV;
            goto out;
        }
        memcpy(&mpu_cmd->header, xfer_buf, sizeof(mpu_cmd->header));

        if ((mpu_cmd->header.magic == RPP_MPU_CMD_MAGIC_MPU) &&
            (((mpu_cmd->header.ctrl >> RPP_MPU_CMD_STATE_SHIFT) &
            RPP_MPU_CMD_STATE_MASK) == MPU_CMD_STATE_RECV_DONE)) {
            ret = 0;
            goto out;
        }
    }

    DEV_WARN(pdev, "%s, MPU cmd timeout, header=0x%08x\n",
        __func__, mpu_cmd->header.header);
    ret = -ETIMEDOUT;

out:
    kfree(xfer_buf);
    return ret;
}

int rpp_get_mcu_version(struct rpp_dev *pdev, uint32_t *version)
{
    int ret = 0;
    mpu_cmd_t mpu_cmd;
    uint8_t *version_tmp = NULL;

    if (!pdev || !version) {
        return -EINVAL;
    }

    version_tmp = kzalloc(sizeof(uint32_t), GFP_KERNEL);
    if (version_tmp == NULL) {
        return -ENOMEM;
    }

    rpp_mpu_ctrl_cmd_pre(CMD_EEPROM, &mpu_cmd);
    mpu_cmd.params.command_ctrl.mode = I2C_READ;
    mpu_cmd.params.command_ctrl.slave_address = MCU_SLAVE_ADDR & 0xff;
    mpu_cmd.params.command_ctrl.iic_id = 1;
    mpu_cmd.params.command_ctrl.addr_type = 1;
    mpu_cmd.params.command_ctrl.freq = 90;
    mpu_cmd.params.addr = MCU_VERSION_ADDR;
    mpu_cmd.params.ddr_addr = RPP_MPU_DDR_BUF_ADDR;
    mpu_cmd.params.size = 4;
    ret = rpp_mpu_ctrl_cmd_post(pdev, CMD_EEPROM, &mpu_cmd);
    if (ret != 0) {
        goto out;
    }

    ret = rpp_xfer_single(pdev, version_tmp, RPP_DDR_BUF_ADDR,
        sizeof(uint32_t), 0, 0, 100);
    if (ret != sizeof(uint32_t)) {
        DEV_WARN(pdev, "%s, read MCU version DDR buffer failed, addr=0x%x, ret=%d\n",
            __func__, RPP_DDR_BUF_ADDR, ret);
        ret = -ENODEV;
        goto out;
    }

    *version = ((uint32_t)version_tmp[0] << 24) |
        ((uint32_t)version_tmp[1] << 16) |
        ((uint32_t)version_tmp[2] << 8) |
        (uint32_t)version_tmp[3];

    if (*version == 0) {
        DEV_WARN(pdev, "%s, MCU version read back is zero, raw=%02x %02x %02x %02x\n",
            __func__, version_tmp[0], version_tmp[1], version_tmp[2], version_tmp[3]);
        ret = -ENODEV;
        goto out;
    }

    ret = 0;

out:
    kfree(version_tmp);
    return ret;
}
