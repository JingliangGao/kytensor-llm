/*  SPDX-License-Identifier: GPL-2.0 */
/*
 * RPP xData Engine Implementation
 *
 * Copyright (c) 2016-present, XDL Technology Inc.
 * All rights reserved.
 *
 * This source code is licensed under GPL-2.0-or-later.
 */

/*******************************************************************************
 *
 * HEADER FILES INCLUDED
 *
 ******************************************************************************/

#include <linux/stddef.h>
#include <linux/kthread.h>
#include <linux/err.h>
#include "include/rpp_xdata.h"
#include "include/rpp_dfx.h"


/*******************************************************************************
 *
 * XDATA STATIC FUNCTIONS
 *
 ******************************************************************************/

static void xDataHalt( PXDATA_RSC rsc, BOOLEAN nocomplain, char *ResMsg );
static XDATA_RET startUpstreamXfer( PXDATA_RSC rsc, BOOLEAN isWrite,
        char *ResMsg );

#ifdef LWDM
static XDATA_RET startDownstreamXfer(PXDATA_RSC rsc, BOOLEAN isWrite,
        char *ResMsg);
static void startDownstreamWrite(PXDATA_RSC rsc);
static void startDownstreamRead(PXDATA_RSC rsc);

#else
static XDATA_RET startDownstreamXfer(PXDATA_RSC rsc, BOOLEAN isWrite,
        char *ResMsg);
static int startDownstreamWrite(void *rsc);
static int startDownstreamRead(void *rsc);
#endif

static struct task_struct *ts_read;
static struct task_struct *ts_write;

/*******************************************************************************
 *
 * XDATA ENGINE API FUNCTIONS
 *
 ******************************************************************************/

/**
 * Initialize the xData Engine
 *
 * @param[in] rsc          xData resource parameters
 *
 * @return XDATA_RET       status
 */
XDATA_RET xDataInit( PXDATA_RSC rsc, UINT32 ReadMTU, UINT32 WriteMTU )
{
  rsc->xDataMaxWriteLen = WriteMTU / 4;
  rsc->xDataMaxReadLen  = ReadMTU / 4;
  rsc->xDataDownstreamRun = false;

   /*  LOIK */
   XDATA_WRITE_RAM_ADDR(rsc,0x0);
   XDATA_WRITE_RAM_PORT(rsc,0x0);  /*  LOIK - can we get rid of this? */

   /* Set system mem buf addr */
   XDATA_WRITE_ADDR_LO( rsc, rsc->xDataMemPa.LowPart );
   XDATA_WRITE_ADDR_HI( rsc, rsc->xDataMemPa.HighPart );

   DTRACE("Memsize=%d Va=0x%p Pa=0x%08X %08X WLen=%d RLen=%d",
            rsc->xDataMemSize, rsc->xDataMemVa,
            rsc->xDataMemPa.HighPart,
            rsc->xDataMemPa.LowPart,
            (rsc->xDataMaxWriteLen * 4), (rsc->xDataMaxReadLen * 4) );

   return XDATA_SUCCESS;
}


/**
 * Start xData Transfer
 *
 * @param[in] rsc          xData resource parameters
 * @param[in] isWrite      Data direction
 * @param[in/out] ResMsg   Result message
 *
 * @return XDATA_RET       status
 */
XDATA_RET xDataStartXfer( PXDATA_RSC rsc, BOOLEAN isWrite, BOOLEAN isUpstream,
        char *ResMsg )
{
    if (isUpstream) {
        return startUpstreamXfer(rsc, isWrite, ResMsg);
    }
    return startDownstreamXfer(rsc, isWrite, ResMsg);

}


/**
 * Stop xData Transfer
 *
 * @param[in] rsc          xData resource parameters
 * @param[in/out] ResMsg   Result message
 *
 * @return XDATA_RET       status
 */
XDATA_RET xDataStopXfer( PXDATA_RSC rsc, BOOLEAN isUpstream, char *ResMsg )
{
    if (isUpstream) {
        xDataHalt(rsc, FALSE, ResMsg);
    } else {
        rsc->xDataDownstreamRun = false;
    }
    return XDATA_SUCCESS;
}



/**
 * Get xData Status
 *
 * @param[in] rsc          xData resource parameters
 * @param[in/out] ResMsg   Result message
 *
 * @return XDATA_RET       status
 */
XDATA_RET xDataStatus( PXDATA_RSC rsc, char *ResMsg )
{
   XDATA_STATUS  stat;
   XDATA_CTRL    ctrl;
   UINT32        burst_cnt;
   UINT32        bursts;

   stat.AsUint32 = XDATA_READ_STATUS(rsc);
   ctrl.AsUint32 = XDATA_READ_CTRL(rsc);
   burst_cnt     = XDATA_READ_BURST_CNT(rsc);
   bursts        = XDATA_READ_BURSTS(rsc);

   DTRACE("CTRL=0x%08X  db=%d w=%d l=%d pinc=%d nainc=%d t=%d",
      ctrl.AsUint32, ctrl.DBELL, ctrl.IS_WRITE, ctrl.LENGTH,
      ctrl.PATINC, ctrl.NOADDRINC, ctrl.TRIGGER );
   DTRACE("STAT=0x%08X  done=%d v=0x%04x",
      stat.AsUint32, stat.DONE, stat.VERSION );
   DTRACE("BURST_CNT=0x%08X BURSTS=0x%08X", burst_cnt, bursts );

   /* msg back up to calling app */
   DPRINTF(ResMsg, MAX_MSG_SIZE, "DONE=%d BURST_CNT=%d BURSTS=%d",
      stat.DONE, burst_cnt, bursts );

   return XDATA_SUCCESS;
}



/**
 * Halt
 *
 * @param[in] rsc          xData resource parameters
 * @param[in/out] ResMsg   Result message
 *
 * @return XDATA_RET       status
 */
static void xDataHalt( PXDATA_RSC rsc, BOOLEAN nocomplain, char *ResMsg )
{
   UINT32        burst_cnt;
   UINT32        bursts;
   char         *msg;

   burst_cnt     = XDATA_READ_BURST_CNT(rsc);
   bursts        = XDATA_READ_BURSTS(rsc);

   DTRACE("BURST_CNT=0x%08X BURSTS=0x%08X", burst_cnt, bursts );

   if (burst_cnt & 0x80000000)
   {
      XDATA_WRITE_BURST_CNT( rsc, (burst_cnt & 0x7fffffff) );
      DTRACE( "XDATA HALT  [0x%08x] <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<", burst_cnt );
      msg = "XDATA HALT DONE";
   }
   else
   {
      msg = "NO XDATA TO HALT";
      if (!nocomplain)
         DTRACE( "%s [0x%08x]", msg, burst_cnt );
   }
   if (ResMsg)
      DPRINTF(ResMsg, MAX_MSG_SIZE, "%s", msg);
}


/**
 * Start an upstream xdata transfer by setting up tgburst registers.
 *
 * @param[in] rsc          xData resource parameters
 * @param[in] isWrite      Write or read.
 * @param[out] ResMsg      Result message
 *
 * @return XDATA_RET       status
 */
static XDATA_RET startUpstreamXfer( PXDATA_RSC rsc, BOOLEAN isWrite,
        char *ResMsg )
{
    UINT32  len;
    XDATA_CTRL ctrl;
	UINT32 i = 0;
    XDATA_STATUS  stat;
    char         *smsg = "OK";

    /*  From pdrw IoctlSysMemWrite/Read */
    /*  check stat.DONE after issue (should be set) */

    /* Stop first if xfer in progress */
    xDataHalt( rsc, TRUE, NULL );

    /* Clear status */
    XDATA_WRITE_STATUS( rsc, 0x0 );

    /* Burst count set for continuous until stopped */
    XDATA_WRITE_BURST_CNT( rsc, 0x80001001 ); /* LOIK ???? */

    /* Burst DWORD length */
    len = isWrite ? rsc->xDataMaxWriteLen :  rsc->xDataMaxReadLen;

    /* Pattern */
    XDATA_WRITE_PATTERN( rsc, 0x00000000 );

    /* CTRL */
    ctrl.AsUint32 = 0x0;
    ctrl.DBELL = 1;           /* start */
    ctrl.IS_WRITE = isWrite;  /* direction */
    ctrl.LENGTH = len;        /* burst length */
    ctrl.PATINC = 1;          /* increment data pattern value */
    ctrl.TRIGGER = 0;         /* LOIK ??? */
    ctrl.IE = FALSE;          /* no interrupts */
    ctrl.NOADDRINC = TRUE;    /* earch burst written to same address */

    /* Execute */
    DTRACE( "XDATA %s START - CTRL=0x%08x  PINC=%d  LEN=%d\n",
            isWrite ? "WRITE" : "READ", ctrl.AsUint32, ctrl.PATINC, ctrl.LENGTH );
    XDATA_WRITE_CTRL( rsc, ctrl.AsUint32 );

    /* Check that we started */
    while (i<100)
    {
        i++ ;
        stat.AsUint32 = XDATA_READ_STATUS(rsc);
    }
    if (!stat.DONE) smsg = "xdata running";

    if (ResMsg)
        DPRINTF(ResMsg, MAX_MSG_SIZE, "XDATA %s START - %s", isWrite ? "WRITE" : "READ", smsg );

    return XDATA_SUCCESS;
}



#ifdef LWDM

/**
 * Start an downstream xdata transfer by kicking off seperate kernel thread.
 *
 * @param[in] rsc          xData resource parameters
 * @param[in] isWrite      Write or read.
 * @param[out] ResMsg      Result message
 *
 * @return XDATA_RET       status
 */
static XDATA_RET startDownstreamXfer(PXDATA_RSC rsc, BOOLEAN isWrite,
        char *ResMsg)
{
    if (rsc->xDataDownstreamRun) {
        DPRINTF(ResMsg, MAX_MSG_SIZE, "xData downstream traffic is running!");
        return XDATA_ERROR;
    }

    HANDLE hDownstreamXfer;
    NTSTATUS status;
    rsc->xDataDownstreamRun = true;
    if (isWrite) {
        status = PsCreateSystemThread(&hDownstreamXfer, 0, NULL, NULL, NULL,
                (PKSTART_ROUTINE) startDownstreamWrite, (PVOID) rsc);
    } else {
        status = PsCreateSystemThread(&hDownstreamXfer, 0, NULL, NULL, NULL,
                (PKSTART_ROUTINE) startDownstreamRead, (PVOID) rsc);
    }
    if (status != STATUS_SUCCESS) {
        DTRACE("Unable to start kernel thread for xData %s! status=%d",
                isWrite ? "Write" : "Read", status);
        DPRINTF(ResMsg, MAX_MSG_SIZE,
                "Failed to start xData downstream thread!");
        return XDATA_ERROR;
    }
    DPRINTF(ResMsg, MAX_MSG_SIZE,
            "xData downstream traffic get started.");
    return XDATA_SUCCESS;
}


/**
 * Start an downstream xdata write transfer.
 *
 * This function should run in a seperate kernel thread.
 *
 * @param[in] rsc          xData resource parameters
 * @return void
 */
static void startDownstreamWrite( PXDATA_RSC rsc)
{
    UINT32 val = 0x0;
    while (rsc->xDataDownstreamRun) {
        RPP_WRITE_UINT32(rsc->xDataLocMemVa, val++);
    }
    DTRACE("XDATA downstream write is terminated.");
    PsTerminateSystemThread(STATUS_SUCCESS);
}


/**
 * Start an downstream xdata read transfer.
 *
 * This function should run in a seperate kernel thread.
 *
 * @param[in] rsc          xData resource parameters
 * @return void
 */
static void startDownstreamRead( PXDATA_RSC rsc)
{
    while (rsc->xDataDownstreamRun) {
        RPP_READ_UINT32(rsc->xDataLocMemVa);
    }
    DTRACE("XDATA downstream read is terminated.");
    PsTerminateSystemThread(STATUS_SUCCESS);
}

#else

static XDATA_RET startDownstreamXfer(PXDATA_RSC rsc, BOOLEAN isWrite,
        char *ResMsg)
{
    struct task_struct *ts;

    if (rsc->xDataDownstreamRun) {
        DPRINTF(ResMsg, MAX_MSG_SIZE, "xData downstream traffic is running!");
        return XDATA_ERROR;
    }

    rsc->xDataDownstreamRun = true;
    if (isWrite) {
        ts_write = kthread_run(startDownstreamWrite, (void*)rsc,"kthread");
		ts = ts_write;
    } else {
        ts_read = kthread_run(startDownstreamRead, (void*)rsc,"kthread");
		ts = ts_read;
    }

    if (!IS_ERR(ts)) {
        DTRACE("Unable to start kernel thread for xData %s! ",
                isWrite ? "Write" : "Read");
        DPRINTF(ResMsg, MAX_MSG_SIZE,
                "Failed to start xData downstream thread!");
        return XDATA_ERROR;
    }
    DPRINTF(ResMsg, MAX_MSG_SIZE,
            "xData downstream traffic get started.");
    return XDATA_SUCCESS;
}

static int startDownstreamWrite( void *rsc_)
{
    UINT32 val = 0x0;
	PXDATA_RSC rsc = (PXDATA_RSC)rsc_;
    while (rsc->xDataDownstreamRun) {
        RPP_WRITE_UINT32(rsc->xDataLocMemVa, val++);
    }
    DTRACE("XDATA downstream write is terminated.");
    return kthread_stop(ts_write);
}

static int startDownstreamRead( void * rsc_)
{
    PXDATA_RSC rsc = (PXDATA_RSC)rsc_;
    while (rsc->xDataDownstreamRun) {
        RPP_READ_UINT32(rsc->xDataLocMemVa);
    }
    DTRACE("XDATA downstream read is terminated.");
    return kthread_stop(ts_read);
}
#endif /* LWDM */
