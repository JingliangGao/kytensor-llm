/*
 * This file is part of the Azurengine RPP IP Core driver for Linux
 *
 * Copyright (c) 2016-present,  Azurengine, Inc.
 * All rights reserved.
 *
 * This source code is licensed under both the BSD-style license (found in the
 * LICENSE file in the root directory of this source tree) and the GPLv2 (found
 * in the COPYING file in the root directory of this source tree).
 * You may select, at your option, one of the above-listed licenses.
 */


#include <linux/ioctl.h>
#include <linux/mm.h>
#include <linux/idr.h>
#include <linux/spinlock.h>
#include <asm/cacheflush.h>
#include <linux/delay.h>
#include <linux/interrupt.h>
#include <linux/kfifo.h>
#include <linux/moduleparam.h>
#include <linux/time.h>

#include "include/version.h"
#include "include/rpp_cdev.h"
#include "include/rpp_pages.h"
#include "include/rpp_cdev_ctrl.h"
#include "include/rpp_vdev_ctrl.h"
#include "include/rpp_dev_list.h"
#include "include/rpp_hal_pcie.h"

#include "include/rpp_dev.h"
#include "include/rpp_sdev.h"
#include "include/rpp_pm.h"

static int rpp_debug_ioctl_delay_ms;
module_param(rpp_debug_ioctl_delay_ms, int, 0644);
MODULE_PARM_DESC(rpp_debug_ioctl_delay_ms, "Debug delay in entire_ctrl_ioctl while holding ioctl semaphore\n");

static long rpp_debug_ioctl_delay_param = -1;
module_param(rpp_debug_ioctl_delay_param, long, 0644);
MODULE_PARM_DESC(rpp_debug_ioctl_delay_param, "Only delay GETPARAM/SETPARAM with this param value, -1 means any param ioctl\n");

int rpp_ioctl_getparam(struct file* filp, struct rpp_dev *pdev, void *data)
{
	struct rpp_param_info *info = data;
	struct pci_bus *parent_bus = NULL;
	int i = 0;
	uint32_t *value32;
	rpp_pcie_link_t lnk_attr = { 0 };
	rpp_switch_t *rpp_switch;
	struct rpp_switch_info switch_info;

	/*  just support busid */
	switch (info->param) {
	case RPP_GETPARAM_BUSID:
		snprintf((char *)info->value, sizeof(info->value), "%s", pci_name(pdev->pdev));
		break;
	case RPP_GETPARAM_BARTYPE:
		info->value[0] = pdev->small_bar ? 1 : 0;
		break;
	case RPP_GETPARAM_VDEV_MEMINFO:
		memcpy((void *)info->value, (void *)&pdev->ve_info, sizeof(struct ve_mem_info));
		break;
	case RPP_GETPARAM_BARSIZE:
		value32 = (uint32_t *)info->value;
		for (i = 0; i < RPP_BAR_NUM; i++) {
			value32[i] = pdev->bar_len[i];
		}
		break;
	case RPP_GETPARAM_BLCONFIG:
		/*  memcpy((void *)info->value, (void *)&pdev->bl_config_info, pdev->bl_config_info.size); */
		memcpy((void *)info->value, (void *)&pdev->bl_config_info, sizeof(pdev->bl_config_info));
		break;
	case RPP_GETPARAM_PWR_MODE:
	{
		memcpy((void *)info->value, (void *)&pdev->hw_state.pwr_state, sizeof(uint32_t));
		break;
	}
	case RPP_GETPARAM_WORK_MODE:
		memcpy((void *)info->value, (void *)&pdev->hw_state.wrk_user_state, sizeof(uint32_t));
		break;
	case RPP_GETPARAM_PARENT_PCI:
		/* 优先使用 parent_switch，避免跨 .o 函数返回时可能的指针截断 */
		rpp_switch = pdev->parent_switch;
		if (rpp_switch == NULL)
			rpp_switch = rpp_sdev_search_by_devices(pdev);
		if (rpp_switch != NULL) {
			snprintf((char *)info->value, sizeof(info->value), "%s\n", rpp_switch->pci_id);
			DEV_DEBUG(pdev, "get param parentpci name:%s\n", rpp_switch->pci_id);
		} else {
			snprintf((char *)info->value, sizeof(info->value), "%s\n", "ROOT-COMPLEX");
			DEV_DEBUG(pdev, "get param parentpci name failed, No parent BUS (may be you are Root Complex)\n");
		}
		break;
	case RPP_GETPARAM_PARENT_PCI_LNK:
		/* 优先使用 parent_switch，避免跨 .o 函数返回时可能的指针截断 */
		rpp_switch = pdev->parent_switch;
		if (rpp_switch == NULL)
			rpp_switch = rpp_sdev_search_by_devices(pdev);
		if (rpp_switch != NULL) {
			lnk_attr.cap_width = (rpp_switch->lnkcap & PCI_EXP_LNKCAP_MLW) >> 4;  /*  capability width */
			lnk_attr.cap_speed = rpp_switch->lnkcap & PCI_EXP_LNKCAP_SLS;         /*  capability speed */

			lnk_attr.sta_width = (rpp_switch->lnksta & PCI_EXP_LNKSTA_NLW) >> 4;  /*  current width */
			lnk_attr.sta_speed = rpp_switch->lnksta & PCI_EXP_LNKSTA_CLS;         /*  current speed */

			DEV_DEBUG(pdev, "Parent Cap max: width: %d speed: %d \n", lnk_attr.cap_width, lnk_attr.cap_speed);
			DEV_DEBUG(pdev, "Parent Cur sta: width: %d speed: %d \n", lnk_attr.sta_width, lnk_attr.sta_speed);
		}
		memcpy((void *)info->value, (void *)&lnk_attr, sizeof(rpp_pcie_link_t));
		break;
	case RPP_GETPARAM_SWITCH_INFO:
		memset(&switch_info, 0, sizeof(switch_info));
		switch_info.switch_id = pdev->switch_idx;
		switch_info.idx_in_switch = pdev->idx_in_switch;
		memcpy((void *)info->value, (void *)&switch_info, sizeof(struct rpp_switch_info));
		DEV_DEBUG(pdev, "get switch info: switch_id=%d idx_in_switch=%d\n", pdev->switch_idx, pdev->idx_in_switch);
		break;
	case RPP_GETPARAM_DRV_VERSION:
		*((uint32_t *)&info->value) = DRV_MOD_VERSION_NUMBER;
		break;
	case RPP_GETPARAM_MCU_VERSION:
		memcpy((void *)info->value, (void *)&pdev->mcu_version,
			sizeof(pdev->mcu_version));
		break;
	default:
		ERROR_PRINT("Unsupported parameter 0x%llx\n", info->param);
		return -EINVAL;
	}

	/* DEBUG_PRINT("[mm] "param 0x%llx, value %s\n", info->param, info->value); */
	return 0;
}

int rpp_ioctl_setparam(struct file* filp, struct rpp_dev *pdev, void *data)
{
	struct rpp_param_info *info = data;

	switch (info->param) {
	case RPP_SETPARAM_PWR_MODE:
	{
		uint32_t mode = *(uint32_t *)info->value;

		if(rpp_set_power_mode(pdev, mode) != 0) {
			DEV_ERROR(pdev, "set power state error, mode 0x%x\n", mode);
			return -EINVAL;
		}
		pdev->hw_state.pwr_user_state = mode;
		break;
	}
	case RPP_SETPARAM_WORK_MODE:
		if(rpp_set_worker_mode(pdev, (*(uint32_t*)info->value)) != 0) {
			DEV_ERROR(pdev, "set worker state error, mode 0x%x\n", (*(uint32_t*)info->value));
			return -EINVAL;
		}
		break;
	default:
		ERROR_PRINT("Unsupported parameter 0x%llx\n", info->param);
		return -EINVAL;
	}

	/* DEBUG_PRINT("[mm] "param 0x%llx, value %s\n", info->param, info->value); */
	return 0;
}

int rpp_ioctl_trigger_dma(struct file* filp, struct rpp_dev *pdev, void *data)
{
	struct rpp_param_info *info = data;

	rpp_dma_wakeup();

	/* DEBUG_PRINT("[mm] "param 0x%llx, value %s\n", info->param, info->value); */
	return 0;
}

int rpp_ioctl_connect(struct file* filp, struct rpp_dev *pdev, void *data)
{
	struct rpp_conn_info *info = data;
	struct rpp_serv *serv;

	DEV_DEBUG(pdev, "[mm] %s, pid=0x%x\n", __func__, info->pid);
#if 0
	if ((dev->serv != NULL) && (dev->serv->pid != info->pid)) {
		DEV_DEBUG(pdev, "[mm] Server 0x%x is exist\n", dev->serv->pid);
		goto fail;
	}
#endif
	if (pdev->serv == NULL) {
		serv = kmalloc(sizeof(struct rpp_serv), GFP_KERNEL);
		if (!serv) {
			goto fail;
		}
	}
	serv->pid = info->pid;
	pdev->serv = serv;

	return 0;
fail:
	return -ENOMEM;
}

int rpp_ioctl_disconnect(struct file* filp, struct rpp_dev *pdev, void *data)
{
	struct rpp_conn_info *info = data;

	DEV_DEBUG(pdev, "[mm] %s, pid=0x%x\n", __func__, info->pid);
#if 0
	if ((dev->serv == NULL) || (dev->serv->pid != info->pid)) {
		DEV_DEBUG(pdev, "[mm] Server 0x%x is exist\n", dev->serv->pid);
		goto fail;
	}
#else
	if (pdev->serv != NULL) {
		kfree(pdev->serv);
		pdev->serv = NULL;
	}
#endif
	return 0;
#if 0
fail:
	return -EINVAL;
#endif
}

int rpp_ioctl_map_shm(struct file* filp, struct rpp_dev *pdev, void *data)
{
	struct rpp_shm_info *info = data;
	rpp_pages_t *rpp_pages;
	char *kdata = NULL;
	uint32_t ksize;
	struct dma_mapped_blk *mapped_blk = NULL;
	struct scatterlist *sg, *start;
	uint64_t prev_dma_address;
	uint32_t prev_dma_length;
	uint32_t i;

	rpp_pages = rpp_map_user_buf(pdev, info->shm_addr, info->size);
	if (!rpp_pages || (rpp_pages->mapped_nents == 0)) {
		return -ENOMEM;
	}

	ksize = rpp_pages->mapped_nents * sizeof(struct dma_mapped_blk);
	if (ksize > MAX_KMALLOC_SIZE) {
		/*  large block, use vmalloc */
		kdata = vmalloc(ksize);
	} else {
		kdata = kmalloc(ksize, GFP_KERNEL);
	}
	if (!kdata) {
		rpp_unmap_user_buf(pdev, rpp_pages);
		return -ENOMEM;
	}

	mapped_blk = (struct dma_mapped_blk *)kdata;
	prev_dma_address = 0;
	prev_dma_length = 0;
	start = rpp_pages->sgt.sgl;

	for_each_sg(start, sg, rpp_pages->mapped_nents, i) {
		if ((prev_dma_address + (uint64_t)prev_dma_length) == cpu_to_le64((u64)sg_dma_address(sg))) {
			/*  continued dma address */
			prev_dma_address = cpu_to_le64((u64)sg_dma_address(sg));
			prev_dma_length = cpu_to_le32((u32)sg_dma_len(sg));

			mapped_blk--;
			mapped_blk->dma_length += prev_dma_length;
			mapped_blk++;
			continue;
		} else {
			/*  non-continued dma address */
			mapped_blk->dma_address = cpu_to_le64((u64)sg_dma_address(sg));
			mapped_blk->dma_length = cpu_to_le32((u32)sg_dma_len(sg));
			prev_dma_address = mapped_blk->dma_address;
			prev_dma_length = mapped_blk->dma_length;
			/*  ERROR_PRINT("%d, dma_address=0x%llx, dma_length=0x%x\n", info->mapped_num, mapped_blk->dma_address, mapped_blk->dma_length); */
			info->mapped_num++;
        	mapped_blk++;
		}
    }

	if ((info->mapped_num * sizeof(struct dma_mapped_blk)) > MAX_KMALLOC_SIZE) {
		rpp_pages->mapped_blk = (PBLK_ELEMENT)vmalloc(info->mapped_num * sizeof(struct dma_mapped_blk));
	} else {
		rpp_pages->mapped_blk = (PBLK_ELEMENT)kmalloc(info->mapped_num * sizeof(struct dma_mapped_blk), GFP_KERNEL);
	}
	if (!rpp_pages->mapped_blk) {
		rpp_unmap_user_buf(pdev, rpp_pages);
		return -ENOMEM;
	}

	rpp_pages->mapped_num = info->mapped_num;
	memcpy((void *)rpp_pages->mapped_blk, (void *)kdata, info->mapped_num * sizeof(struct dma_mapped_blk));

	if (ksize > MAX_KMALLOC_SIZE) {
		vfree(kdata);
	} else {
		kfree(kdata);
	}

	/*  WARN: willjiang, 20250919, use vmalloc as input */
	if (copy_to_user((void __user *)info->mapped_info, rpp_pages->mapped_blk, info->mapped_num * sizeof(struct dma_mapped_blk)) != 0) {
		rpp_unmap_user_buf(pdev, rpp_pages);
		return -EFAULT;
	}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,9,0)
	idr_preload(GFP_KERNEL);
	spin_lock(&pdev->idr_lock);
	info->handle = idr_alloc(&pdev->idr, rpp_pages, 1, 0, GFP_NOWAIT);
	spin_unlock(&pdev->idr_lock);
	idr_preload_end();
#else
	int ret;
retry:
	if (!idr_pre_get(&pdev->idr, GFP_KERNEL)) {
		rpp_unmap_user_buf(pdev, rpp_pages);
		return -ENOMEM;
	}

	spin_lock(&pdev->idr_lock);
	ret = idr_get_new(&pdev->idr, rpp_pages, &info->handle);
	spin_unlock(&pdev->idr_lock);

	if (ret == -EAGAIN)
		goto retry;

	if (ret < 0)
		return 0;
#endif

	if (info->handle < 0)
		return info->handle;

	/* could change due to page size align */
	info->map_handle = rpp_host_map_handle(info->handle);

	/* DEBUG_PRINT("[mm] "MAP PAGES_MEM %d, handle/map 0x%x/0x%llx\n", \
				rpp_pages->serial, info->handle, info->map_handle); */

	return 0;
}

int rpp_ioctl_map_single(struct file *filp, struct rpp_dev *pdev, void *data)
{
	struct rpp_single_map_info *info = data;
	rpp_single_map_t *single;
	uint32_t addr_type;
	int ret;

	addr_type = info->flags & RPP_SINGLE_ADDR_MASK;
	if (addr_type != RPP_SINGLE_ADDR_USER_VA &&
	    addr_type != RPP_SINGLE_ADDR_PHYS)
		return -EINVAL;

	if (!(info->flags & RPP_SINGLE_DIR_MASK))
		return -EINVAL;

	single = rpp_map_single_buf(pdev, info);
	if (!single)
		return -ENOMEM;

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,9,0)
	idr_preload(GFP_KERNEL);
	spin_lock(&pdev->idr_lock);
	info->handle = idr_alloc(&pdev->idr, single, 1, 0, GFP_NOWAIT);
	spin_unlock(&pdev->idr_lock);
	idr_preload_end();
#else
retry_single:
	if (!idr_pre_get(&pdev->idr, GFP_KERNEL)) {
		rpp_unmap_single_buf(pdev, single);
		return -ENOMEM;
	}

	spin_lock(&pdev->idr_lock);
	ret = idr_get_new(&pdev->idr, single, &info->handle);
	spin_unlock(&pdev->idr_lock);

	if (ret == -EAGAIN)
		goto retry_single;

	if (ret < 0) {
		rpp_unmap_single_buf(pdev, single);
		return ret;
	}
#endif

	if (info->handle < 0) {
		rpp_unmap_single_buf(pdev, single);
		return info->handle;
	}

	info->dma_addr = single->dma_addr;
	info->host_phys = single->host_phys;
	info->map_handle = rpp_host_map_handle(info->handle);

	return 0;
}

int rpp_ioctl_unmap_phys(struct file *filp, struct rpp_dev *pdev, void *data)
{
	struct rpp_single_map_info *info = data;
	rpp_single_map_t *single;

	if (info->handle < 0)
		return -EINVAL;

	spin_lock(&pdev->idr_lock);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,11,0)
	single = idr_remove(&pdev->idr, info->handle);
#else
	single = idr_find(&pdev->idr, info->handle);
	idr_remove(&pdev->idr, info->handle);
#endif
	spin_unlock(&pdev->idr_lock);

	if (!single || !rpp_idr_is_single(single))
		return -EINVAL;

	rpp_unmap_single_buf(pdev, single);

	return 0;
}

int rpp_ioctl_unmap_shm(struct file* filp, struct rpp_dev *pdev, void *data)
{
	struct rpp_shm_info *info = data;
	rpp_pages_t *rpp_pages;

	if (info->handle < 0)
		return -EINVAL;

	/* DEBUG_PRINT("[mm] "Unmap handle %d\n", info->handle); */

	spin_lock(&pdev->idr_lock);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,11,0)
	rpp_pages = (rpp_pages_t *)idr_remove(&pdev->idr, info->handle);
#else
	rpp_pages = (rpp_pages_t *)idr_find(&pdev->idr, info->handle);
	idr_remove(&pdev->idr, info->handle);
#endif
	spin_unlock(&pdev->idr_lock);
	if (NULL == rpp_pages || !rpp_idr_is_pages(rpp_pages))
		return -EINVAL;

	if ((rpp_pages->mapped_num * sizeof(struct dma_mapped_blk)) > MAX_KMALLOC_SIZE) {
		vfree(rpp_pages->mapped_blk);
	} else {
		kfree(rpp_pages->mapped_blk);
	}

	/* DEBUG_PRINT("[mm] "Unmap PAGES_MEM %d\n", rpp_pages->serial); */

	rpp_unmap_user_buf(pdev, rpp_pages);

	return 0;
}

int rpp_ioctl_sync_for_cpu(struct file* filp, struct rpp_dev *pdev, void *data)
{
	struct rpp_shm_info *info = data;
	rpp_pages_t *rpp_pages;

	if (info->handle < 0)
		return -EINVAL;

	/* DEBUG_PRINT("[mm] "Sync handle %d for cpu\n", info->handle); */

	spin_lock(&pdev->idr_lock);
	rpp_pages = (rpp_pages_t *)idr_find(&pdev->idr, info->handle);
	spin_unlock(&pdev->idr_lock);
	if (NULL == rpp_pages || !rpp_idr_is_pages(rpp_pages))
		return -EINVAL;

	rpp_sync_sgt_for_cpu(pdev, rpp_pages);

	return 0;
}

int rpp_ioctl_sync_for_device(struct file* filp, struct rpp_dev *pdev, void *data)
{
	struct rpp_shm_info *info = data;
	rpp_pages_t *rpp_pages;

	if (info->handle < 0)
		return -EINVAL;

	/* DEBUG_PRINT("[mm] "Sync handle %d for device\n", info->handle); */

	spin_lock(&pdev->idr_lock);
	rpp_pages = (rpp_pages_t *)idr_find(&pdev->idr, info->handle);
	spin_unlock(&pdev->idr_lock);
	if (NULL == rpp_pages || !rpp_idr_is_pages(rpp_pages))
		return -EINVAL;

	rpp_sync_sgt_for_device(pdev, rpp_pages);

	return 0;
}

static int rpp_xfer(struct file* filp, struct rpp_dev *pdev, struct rpp_xfer_info *info, bool write)
{
	rpp_pages_t *rpp_pages;
	struct scatterlist *start, *sg;
    uint32_t dma_offs = 0;
	uint32_t xfered = 0;
	uint32_t xfer_size = 0;
	uint64_t dev_addr = 0;
	uint32_t offs_in_sg = 0;
	unsigned long len;
	uint32_t i = 0;
	ssize_t res = 0;
	void *virt_addr;

	PBLK_ELEMENT temp_blk;
	uint32_t offs_in_blk = 0;
	uint8_t rewrite_cnt = 0;
	unsigned int dma_length = 0;
	DMA_BLKS_INFO blk_info;


// #define __LIBRPP_PROFILING__

#ifdef __LIBRPP_PROFILING__
	struct timespec64 start_tv, end;
	u64 n;

	ktime_get_real_ts64(&start_tv);
	n = start_tv.tv_sec*1000*1000 + start_tv.tv_nsec/1000;
	// DEV_INFO(pdev,"%s, start_in_us %lld\n", __func__, n);
#endif

	/*  FIXME check PCIE status 0x04 reg on windows */
	DEV_TRACE(pdev, "xfer mode: handle ID %d\n", info->host_handle);
	if(info->host_handle == PHY_ADDRESS_XFER_MODE) { /*  for eb to support host physical address transfer. */
		virt_addr = phys_to_virt(info->host_offs);
		DEV_TRACE(pdev, "rpp_xfer phys 0x%llx, virt 0x%llx\n", info->host_offs, virt_addr);
		res = rpp_xfer_single(pdev, virt_addr, info->dev_addr, info->size, write, 0, 30000);
		if (res != info->size) {
			return -EIO;
		}
	}
	else {
		spin_lock(&pdev->idr_lock);
		rpp_pages = (rpp_pages_t *)idr_find(&pdev->idr, info->host_handle);
		spin_unlock(&pdev->idr_lock);
		if (NULL == rpp_pages || !rpp_idr_is_pages(rpp_pages)) {
			DEV_ERROR(pdev, "%s, can't find pages, info->host_handle=0x%x\n", __func__, info->host_handle);
			return -EINVAL;
		}

		if ((info->size == 0) || \
			((info->host_offs + info->size) > rpp_pages->size)) {
			ERROR_PRINT("Size error, bo_size 0x%x, host_offs 0x%x, trans_size 0x%x, \n", rpp_pages->size, info->host_offs, info->size);
			return -EPROTO;
		}

		dev_addr = info->dev_addr;

#if 0
		start = rpp_pages->sgt.sgl;
		for_each_sg(start, sg, rpp_pages->mapped_nents, i) {
			unsigned int dma_length = cpu_to_le32((u32)sg_dma_len(sg));

			if ((dma_offs+dma_length) < info->host_offs) {
				continue;
			}

			offs_in_sg = xfered + info->host_offs - dma_offs;
			xfer_size = ((info->size - xfered) < (dma_length - offs_in_sg) ?
				(info->size - xfered) : (dma_length - offs_in_sg));
			/* DEBUG_PRINT("%d, offs_in_sg=0x%x, xfer_size=0x%x, dev_addr=0x%llx\n", i, offs_in_sg, xfer_size, dev_addr); */
			res = rpp_xfer_single(pdev, sg_dma_address(sg) + offs_in_sg, dev_addr, xfer_size, write, 1, 0);

			xfered += xfer_size;
			dev_addr += xfer_size;
			dma_offs += dma_length;

			if (xfered >= info->size) {
				break;
			}
		}
#else

	if(rpp_pages->mapped_blk == NULL) {
		DEV_ERROR(pdev, "%s, mapped block failed: mapped_blk(0x%llx)\n", __func__, rpp_pages->mapped_blk);
		return -EINVAL;
	}

	blk_info.start = 0;
	blk_info.vail_num = 0;
	blk_info.start_offs = 0;
	blk_info.end_size = 0;
	blk_info.mapped_blk = rpp_pages->mapped_blk;
	blk_info.mapped_num = rpp_pages->mapped_num;
	temp_blk = blk_info.mapped_blk;

	for(i = 0; i < blk_info.mapped_num; i++) {
		dma_length = temp_blk->dma_length;
		temp_blk++;

		dma_offs += dma_length;
		if (dma_offs < info->host_offs) {
			blk_info.start++;
			continue;
		}

		/*  for first dma_offs >= info->host_offs */
		/*  case 1 dma_offs > info->host_offs */
		/*  case 2 dma_offs = info->host_offs */
		if(rewrite_cnt == 0) {
			rewrite_cnt++;
			if(dma_offs > info->host_offs) {
				blk_info.start_offs = info->host_offs - (dma_offs - dma_length);
				offs_in_blk = blk_info.start_offs;
			}
			else {
				blk_info.start++;
				continue;
			}
		}

		xfer_size = ((info->size - xfered) < (dma_length - offs_in_blk) ?
            (info->size - xfered) : (dma_length - offs_in_blk));

		offs_in_blk = 0;
		xfered += xfer_size;
		blk_info.vail_num++;

		if(xfered >= info->size) {
			blk_info.end_size = xfer_size;
			break;
		}
	}

	DEV_TRACE(pdev, "%s, blk info: num 0x%x, start 0x%x, vail_num 0x%x, start_offs 0x%x, end_size 0x%x\n",
		__func__, blk_info.mapped_num, blk_info.start, blk_info.vail_num, blk_info.start_offs, blk_info.end_size);

	/*  30s * 2GB/s(Gen2*4) = 60GB */
	res = rpp_xfer_blks(pdev, &blk_info, dev_addr, info->size, write, 30000); /*  30s */
	if (res != info->size) {
		return -EIO;
	}
#endif
	}

#ifdef __LIBRPP_PROFILING__
	ktime_get_real_ts64(&end);
	n = end.tv_sec*1000*1000 + end.tv_nsec/1000;
	// DEV_INFO(pdev, "%s, end_in_us %lld\n", __func__, n);

	n = (end.tv_sec - start_tv.tv_sec)*1000*1000 + (end.tv_nsec - start_tv.tv_nsec)/1000;
	DEV_INFO(pdev, "%s, total %lld, throughput=%lu MB/s\n", __func__, n, ((long)(info->size/n)*1000000/(1024*1024)));
#endif


	return 0;
}

int rpp_ioctl_xfer_to_dev(struct file* filp, struct rpp_dev *pdev, void *data)
{
	return rpp_xfer(filp, pdev, data, 1);
}

int rpp_ioctl_xfer_from_dev(struct file* filp, struct rpp_dev *pdev, void *data)
{
	return rpp_xfer(filp, pdev, data, 0);
}

int rpp_ioctl_xfer_desc(struct file* filp, struct rpp_dev *pdev, void *data)
{
	struct rpp_xfer_desc_info *info = data;
	rpp_pages_t *rpp_pages;
	PBLK_ELEMENT temp_blk;
	DMA_BLKS_INFO blk_info;
	uint32_t dma_offs = 0;
	uint32_t xfered = 0;
	uint32_t xfer_size = 0;
	uint32_t offs_in_blk = 0;
	uint8_t rewrite_cnt = 0;
	unsigned int dma_length = 0;
	uint32_t i;
	ssize_t res;
	bool write;

	if (info->dirc != DMA_WRITE && info->dirc != DMA_READ)
		return -EINVAL;

	if (info->host_handle == PHY_ADDRESS_XFER_MODE) {
		DEV_ERROR(pdev, "%s, PHY mode is not supported by desc ioctl\n", __func__);
		return -EINVAL;
	}

	spin_lock(&pdev->idr_lock);
	rpp_pages = (rpp_pages_t *)idr_find(&pdev->idr, info->host_handle);
	spin_unlock(&pdev->idr_lock);
	if (NULL == rpp_pages || !rpp_idr_is_pages(rpp_pages)) {
		DEV_ERROR(pdev, "%s, can't find pages, info->host_handle=0x%x\n",
			  __func__, info->host_handle);
		return -EINVAL;
	}

	if ((info->size == 0) ||
	    ((info->host_offs + info->size) > rpp_pages->size)) {
		ERROR_PRINT("Size error, bo_size 0x%x, host_offs 0x%llx, trans_size 0x%x\n",
			    rpp_pages->size, info->host_offs, info->size);
		return -EPROTO;
	}

	if (rpp_pages->mapped_blk == NULL) {
		DEV_ERROR(pdev, "%s, mapped block failed: mapped_blk(0x%llx)\n",
			  __func__, rpp_pages->mapped_blk);
		return -EINVAL;
	}

	blk_info.start = 0;
	blk_info.vail_num = 0;
	blk_info.start_offs = 0;
	blk_info.end_size = 0;
	blk_info.mapped_blk = rpp_pages->mapped_blk;
	blk_info.mapped_num = rpp_pages->mapped_num;
	temp_blk = blk_info.mapped_blk;

	for (i = 0; i < blk_info.mapped_num; i++) {
		dma_length = temp_blk->dma_length;
		temp_blk++;

		dma_offs += dma_length;
		if (dma_offs < info->host_offs) {
			blk_info.start++;
			continue;
		}

		if (rewrite_cnt == 0) {
			rewrite_cnt++;
			if (dma_offs > info->host_offs) {
				blk_info.start_offs = info->host_offs - (dma_offs - dma_length);
				offs_in_blk = blk_info.start_offs;
			} else {
				blk_info.start++;
				continue;
			}
		}

		xfer_size = ((info->size - xfered) < (dma_length - offs_in_blk) ?
			(info->size - xfered) : (dma_length - offs_in_blk));

		offs_in_blk = 0;
		xfered += xfer_size;
		blk_info.vail_num++;

		if (xfered >= info->size) {
			blk_info.end_size = xfer_size;
			break;
		}
	}

	if (xfered != info->size || blk_info.vail_num == 0) {
		DEV_ERROR(pdev, "%s, invalid desc range: xfered 0x%x, size 0x%x, vail_num 0x%x\n",
			  __func__, xfered, info->size, blk_info.vail_num);
		return -EPROTO;
	}

	DEV_TRACE(pdev, "%s, CH2 desc blk info: num 0x%x, start 0x%x, vail_num 0x%x, start_offs 0x%x, end_size 0x%x\n",
		  __func__, blk_info.mapped_num, blk_info.start, blk_info.vail_num,
		  blk_info.start_offs, blk_info.end_size);

	write = (info->dirc == DMA_WRITE);
	res = rpp_xfer_blks_ch(pdev, CH2, &blk_info, info->dev_addr, info->size, write, 30000);
	if (res != info->size)
		return -EIO;

	return 0;
}

int rpp_ioctl_pages_new(struct file* filp, struct rpp_dev *pdev, void *data)
{
	struct rpp_pages_info *info = data;
	rpp_pages_t *rpp_pages;

	rpp_pages = rpp_pages_alloc(pdev, info->size);
	if (!rpp_pages) {
		return -ENOMEM;
	}

#if LINUX_VERSION_CODE >= KERNEL_VERSION(3,9,0)
	idr_preload(GFP_KERNEL);
	spin_lock(&pdev->idr_lock);
	info->handle = idr_alloc(&pdev->idr, rpp_pages, 1, 0, GFP_NOWAIT);
	spin_unlock(&pdev->idr_lock);
	idr_preload_end();
#else
	int ret;
retry:
	if (!idr_pre_get(&dev->idr, GFP_KERNEL)) {
		return -ENOMEM;
	}

	spin_lock(&pdev->idr_lock);
	ret = idr_get_new(&pdev->idr, rpp_pages, &info->handle);
	spin_unlock(&pdev->idr_lock);

	if (ret == -EAGAIN)
		goto retry;

	if (ret < 0)
		return 0;
#endif
	if (info->handle < 0)
		return info->handle;

	/* could change due to page size align */
	info->size = rpp_pages->size;
	info->map_handle = rpp_host_map_handle(info->handle);

	/* DEBUG_PRINT("[mm] "Alloc PAGES_MEM %d, handle/map 0x%x/0x%llx\n", \
				rpp_pages->serial, info->handle, info->map_handle); */

	return 0;
}

int rpp_ioctl_pages_info(struct file* filp, struct rpp_dev *pdev, void *data)
{
	struct rpp_pages_info *info = data;
	rpp_pages_t *rpp_pages;

	if (info->handle < 0)
		return -EINVAL;


	spin_lock(&pdev->idr_lock);
	rpp_pages = (rpp_pages_t *)idr_find(&pdev->idr, info->handle);
	spin_unlock(&pdev->idr_lock);
	if (NULL == rpp_pages || !rpp_idr_is_pages(rpp_pages))
		return -EINVAL;

	info->size = rpp_pages->size;
	info->map_handle = rpp_host_map_handle(info->handle);

	/* DEBUG_PRINT("[mm] "PAGES_MEM %d, handle/map 0x%x/0x%llx\n", \
		rpp_pages->serial, info->handle, info->map_handle); */

	return 0;
}

int rpp_ioctl_pages_free(struct file* filp, struct rpp_dev *pdev, void *data)
{
	struct rpp_pages_info *info = data;
	rpp_pages_t *rpp_pages;

	if (info->handle < 0)
		return -EINVAL;

	/* DEBUG_PRINT("[mm] "Free handle %d\n", info->handle); */

	spin_lock(&pdev->idr_lock);
#if LINUX_VERSION_CODE >= KERNEL_VERSION(4,11,0)
	rpp_pages = (rpp_pages_t *)idr_remove(&pdev->idr, info->handle);
#else
	rpp_pages = (rpp_pages_t *)idr_find(&pdev->idr, info->handle);
	idr_remove(&pdev->idr, info->handle);
#endif
	spin_unlock(&pdev->idr_lock);
	if (NULL == rpp_pages || !rpp_idr_is_pages(rpp_pages))
		return -EINVAL;

	/* DEBUG_PRINT("[mm] "Free PAGES_MEM %d\n", rpp_pages->serial); */

	rpp_pages_free(pdev, rpp_pages);

	return 0;
}

int rpp_ioctl_get_interrupt_info(struct file* filp, struct rpp_dev *pdev, void *data)
{
	struct rpp_int_info *info = data;
	rpp_pages_t *rpp_pages;
	int rlen = 0;

	if (kfifo_is_empty(&pdev->isr_kfifo)) {
		ERROR_PRINT("%s, kfifo is empty\n", __func__);
		return -ENOMEM;
	}

	rlen = kfifo_out(&pdev->isr_kfifo, (void *)info, sizeof(struct rpp_int_info));
	if (rlen != sizeof(struct rpp_int_info)) {
		ERROR_PRINT("%s, kfifo_out failed, rlen 0x%x\n", __func__, rlen);
		return -ENOMEM;
	}

	return 0;
}

static void rpp_vma_open(struct vm_area_struct *vma)
{
}

static void rpp_vma_close(struct vm_area_struct *vma)
{
}

static struct vm_operations_struct rpp_pages_mem_ops = {
	.open = rpp_vma_open,
	.close = rpp_vma_close,
	.fault = rpp_pages_vm_fault,
};

static struct vm_operations_struct rpp_single_map_mem_ops = {
	.open = rpp_vma_open,
	.close = rpp_vma_close,
	.fault = rpp_single_map_vm_fault,
};

#define RPP_IOCTL_DEF(ioctl, _func) \
	[_IOC_NR(ioctl)] = {.cmd = ioctl, .func = _func, \
			    .cmd_drv = 0, .name = #ioctl}

struct rpp_ioctl_desc rpp_ioctls[] = {
	RPP_IOCTL_DEF(RPP_IOCTL_GETPARAM, rpp_ioctl_getparam),
	RPP_IOCTL_DEF(RPP_IOCTL_CONNECT, rpp_ioctl_connect),
	RPP_IOCTL_DEF(RPP_IOCTL_DISCONNECT, rpp_ioctl_disconnect),
	RPP_IOCTL_DEF(RPP_IOCTL_MAP_SHM, rpp_ioctl_map_shm),
	RPP_IOCTL_DEF(RPP_IOCTL_UNMAP_SHM, rpp_ioctl_unmap_shm),
	RPP_IOCTL_DEF(RPP_IOCTL_SYNC_FOR_CPU, rpp_ioctl_sync_for_cpu),
	RPP_IOCTL_DEF(RPP_IOCTL_SYNC_FOR_DEVICE, rpp_ioctl_sync_for_device),
	RPP_IOCTL_DEF(RPP_IOCTL_MAP_SINGLE, rpp_ioctl_map_single),
	RPP_IOCTL_DEF(RPP_IOCTL_UNMAP_PHYS, rpp_ioctl_unmap_phys),
	RPP_IOCTL_DEF(RPP_IOCTL_XFER_TO_DEV, rpp_ioctl_xfer_to_dev),
	RPP_IOCTL_DEF(RPP_IOCTL_XFER_FROM_DEV, rpp_ioctl_xfer_from_dev),
	RPP_IOCTL_DEF(RPP_IOCTL_PAGES_NEW, rpp_ioctl_pages_new),
	RPP_IOCTL_DEF(RPP_IOCTL_PAGES_INFO, rpp_ioctl_pages_info),
	RPP_IOCTL_DEF(RPP_IOCTL_PAGES_FREE, rpp_ioctl_pages_free),
	RPP_IOCTL_DEF(RPP_IOCTL_GET_INTERRUPT_INFO, rpp_ioctl_get_interrupt_info),
	RPP_IOCTL_DEF(RPP_IOCTL_SETPARAM, rpp_ioctl_setparam),
	RPP_IOCTL_DEF(RPP_IOCTL_TRIGGER_DMA, rpp_ioctl_trigger_dma),
	RPP_IOCTL_DEF(RPP_IOCTL_XFER_DESC, rpp_ioctl_xfer_desc),
};

#define RPP_IOCTL_COUNT	ARRAY_SIZE(rpp_ioctls)

/*
 * character device file operations for control bus (through control bridge)
 */
static ssize_t entire_ctrl_read(struct file *file, char __user *buf, size_t count,
		loff_t *pos)
{
	struct rpp_cdev *xcdev = (struct rpp_cdev *)file->private_data;
	struct rpp_dev *xdev;
	u32 w;
	int rv;

	rv = xcdev_check(__func__, xcdev, 0);
	if (rv < 0)
		return rv;
	xdev = (struct rpp_dev *)xcdev->prppdev;

	/* only 32-bit aligned and 32-bit multiples */
	if (*pos & 3)
		return -EPROTO;
	/* first address is BAR base plus file position offset */
	w = rpp_io_read32(xdev, *pos);
	INFO_PRINT("char_ctrl_read(count=%ld, pos=%d) value = 0x%08x\n", (long)count, (int)*pos, w);
	rv = copy_to_user(buf, &w, 4);
	if (rv)
		INFO_PRINT("Copy to userspace failed but continuing\n");

	*pos += 4;
	return 4;
}

static ssize_t entire_ctrl_write(struct file *file, const char __user *buf,
			size_t count, loff_t *pos)
{
	struct rpp_cdev *xcdev = (struct rpp_cdev *)file->private_data;
	struct rpp_dev *xdev;
	u32 w;
	int rv;

	rv = xcdev_check(__func__, xcdev, 0);
	if (rv < 0)
		return rv;
	xdev = (struct rpp_dev *)xcdev->prppdev;

	/* only 32-bit aligned and 32-bit multiples */
	if (*pos & 3)
		return -EPROTO;

	/* first address is BAR base plus file position offset */
	rv = copy_from_user(&w, buf, 4);
	if (rv) {
		INFO_PRINT("copy from user failed %d/4, but continuing.\n", rv);
	}

	INFO_PRINT("char_ctrl_write(0x%08x count=%ld, pos=%d)\n", w, (long)count, (int)*pos);
	/* write_register(w, reg); */
	rpp_io_write32(xdev, w, *pos);
	*pos += 4;
	return 4;
}

/*
 * character device file operations for SG DMA engine
 */
static loff_t entire_ctrl_llseek(struct file *file, loff_t off, int whence)
{
	return 0;
}

static int entire_bridge_mmap(struct file *filp, struct vm_area_struct *vma)
{
	struct rpp_cdev *xcdev = (struct rpp_cdev *)filp->private_data;
	struct rpp_dev *xdev;

	int rv = 0;

	rv = xcdev_check(__func__, xcdev, 0);
	if (rv < 0)
		return rv;
	xdev = (struct rpp_dev *)xcdev->prppdev;

	/*  DEBUG_PRINT("vma->vm_pgoff 0x%lx\n", vma->vm_pgoff); */
	if (vma->vm_pgoff * PAGE_SIZE < 0x20000000) {
		/*  0x0 ~ 0x20000000, bar 0 */
		return rpp_remap(xdev, 0, vma);
	} else if (vma->vm_pgoff * PAGE_SIZE >= RPP_HOST_MAP_HANDLE_BASE &&
				vma->vm_pgoff * PAGE_SIZE < 0x800000000) {
		/*  0x1 00000000 ~ 0x10 00000000 */
		/*  Mapping to host memory; mmap offset = map_handle from MAP_SHM/MAP_SINGLE. */
		void *idr_obj;
		int32_t handle = (int32_t)((vma->vm_pgoff * PAGE_SIZE) >> PAGE_SHIFT);

		spin_lock(&xdev->idr_lock);
		idr_obj = idr_find(&xdev->idr, handle);
		spin_unlock(&xdev->idr_lock);
		if (!idr_obj)
			return -ENOENT;

#if LINUX_VERSION_CODE < KERNEL_VERSION(3,7,0)
		vma->vm_flags |= (VM_DONTEXPAND);
#else
#if LINUX_VERSION_CODE < KERNEL_VERSION(6,3,0)
		vma->vm_flags |= (VM_DONTEXPAND | VM_DONTDUMP);
#else
		vm_flags_set(vma, VM_DONTEXPAND | VM_DONTDUMP);
#endif
#endif
		vma->vm_file = filp;

		if (rpp_idr_is_single(idr_obj)) {
			rpp_single_map_t *single = idr_obj;
			unsigned long pfn;

			if (vma->vm_end - vma->vm_start > single->size)
				return -EINVAL;

			if (single->flags & RPP_SINGLE_ADDR_PHYS) {
				pfn = __phys_to_pfn(single->host_phys);
				rv = remap_pfn_range(vma, vma->vm_start, pfn,
						vma->vm_end - vma->vm_start,
						vma->vm_page_prot);
				if (rv)
					return rv;
				vma->vm_private_data = single;
				return 0;
			}

			vma->vm_ops = &rpp_single_map_mem_ops;
			vma->vm_private_data = single;
			return 0;
		}

		if (rpp_idr_is_pages(idr_obj)) {
			rpp_pages_t *rpp_pages = idr_obj;

			/* DEBUG_PRINT("[mm] "MAP PAGES_MEM %d\n", rpp_pages->serial); */

			if (vma->vm_end - vma->vm_start > rpp_pages->size)
				return -EINVAL;

			vma->vm_ops = &rpp_pages_mem_ops;
			vma->vm_private_data = rpp_pages;
			return 0;
		}

		return -ENOENT;

	} 
	else if (vma->vm_pgoff * PAGE_SIZE >= 0x800000000 && 
				vma->vm_pgoff * PAGE_SIZE < 0x1000000000) {
		// 	vma->vm_pgoff << PAGE_SHIFT =  0x800000000 + offset, and offset need PAGE_SIZE align.		
		return rpp_dev_queues_buf_mmap(xdev, vma);
	} else {
		/*  bar2 & bar4 */
		if (xdev->small_bar) {
			/*  small bar */
			if (vma->vm_pgoff * PAGE_SIZE >= BAR2_MAP_OFFSET_SMALL_BAR &&
						vma->vm_pgoff * PAGE_SIZE < (BAR2_MAP_OFFSET_SMALL_BAR + xdev->bar_len[2])) {
				/*  0x10 02000000 ~ 0x10 02200000, bar 2 */
				return rpp_remap(xdev, 2, vma);
			} else if (vma->vm_pgoff * PAGE_SIZE >= BAR4_MAP_OFFSET_SMALL_BAR &&
				vma->vm_pgoff * PAGE_SIZE < (BAR4_MAP_OFFSET_SMALL_BAR + xdev->bar_len[4])) {
				/*  0x10 07000000 ~ 0x10 07400000, bar 4 */
				return rpp_remap(xdev, 4, vma);
			} else {
				return 0;
			}
		} else {
			/*  large bar */
			if (vma->vm_pgoff * PAGE_SIZE >= BAR2_MAP_OFFSET_LARGE_BAR &&
						vma->vm_pgoff * PAGE_SIZE < (BAR2_MAP_OFFSET_LARGE_BAR + xdev->bar_len[2])) {
				/*  0x10 00000000 ~ 0x10 08000000, bar 2 */
				return rpp_remap(xdev, 2, vma);
			} else if (vma->vm_pgoff * PAGE_SIZE >= BAR4_MAP_OFFSET_LARGE_BAR &&
						vma->vm_pgoff * PAGE_SIZE < (BAR4_MAP_OFFSET_LARGE_BAR + xdev->bar_len[4])) {
				/*  0x10 10000000 ~ 0x10 12000000, bar 4 */
				return rpp_remap(xdev, 4, vma);
			} else {
				return 0;
			}
		}
	}
}

static unsigned int entire_ctrl_poll(struct file *flip, struct poll_table_struct *table)
{
	struct rpp_cdev *xcdev = (struct rpp_cdev *)flip->private_data;
	struct rpp_dev *xdev;
	unsigned int mask = 0;
	int rv = 0;
static const uint32_t POLL_TABELE[2]={
    POLLIN,     /* mpu and scheduler interrupt event*/
    POLLOUT,    /* dma interrupt event*/
};

	rv = xcdev_check(__func__, xcdev, 0);
	if (rv < 0)
		return rv;
	xdev = (struct rpp_dev *)xcdev->prppdev;

	/* Wait on both waitqueues: wq for scheduler/mpu, wq_dma for dma */
	poll_wait(flip, &xdev->wq, table);
	poll_wait(flip, &xdev->wq_dma, table);

	/* Check kfifo status directly - if kfifo is not empty, there's data to read */
	if (!kfifo_is_empty(&xdev->isr_kfifo)) {
		mask |= POLL_TABELE[0];	
	}

	/* Check isr_dma flag */
	if (xdev->isr_dma) {
		mask |= POLL_TABELE[1];
		xdev->isr_dma = 0;
	}

	return mask;
}

/**
 * drm_ioctl - ioctl callback implementation for DRM drivers
 * @filp: file this ioctl is called on
 * @cmd: ioctl cmd number
 * @arg: user argument
 *
 * Looks up the ioctl function in the DRM core and the driver dispatch table,
 * stored in &drm_driver.ioctls. It checks for necessary permission by calling
 * drm_ioctl_permit(), and dispatches to the respective function.
 *
 * Returns:
 * Zero on success, negative error code on failure.
 */
static long entire_ctrl_ioctl(struct file *filp,
	      unsigned int cmd, unsigned long arg)
{
	struct rpp_cdev *xcdev = (struct rpp_cdev *)filp->private_data;
	struct rpp_dev *xdev;
	const struct rpp_ioctl_desc *ioctl = NULL;
	rpp_ioctl_t *func;
	unsigned int nr = RPP_IOCTL_NR(cmd);
	int retcode = -EINVAL;
	char stack_kdata[128];
	char *kdata = NULL;
	unsigned int in_size, out_size, ksize;
	int rv = 0;
	int sem_locked = 0;

	rv = xcdev_check(__func__, xcdev, 0);
	if (rv < 0)
		return rv;
	xdev = (struct rpp_dev *)xcdev->prppdev;

	if (READ_ONCE(xdev->pm_suspending)) {
		DEV_WARN(xdev, "entire_ctrl_ioctl blocked by PM suspend: comm=%s pid=%d tgid=%d dev_idx=%d cmd=0x%x nr=0x%x status=0x%x\n",
			current->comm, task_pid_nr(current), task_tgid_nr(current),
			xdev->idx, cmd, nr, READ_ONCE(xdev->status));
		return -EBUSY;
	}

	if (nr >= RPP_IOCTL_COUNT)
			goto err_i1;
	ioctl = &rpp_ioctls[nr];

	rv = down_interruptible(&xdev->sem);
	if (rv) {
		ERROR_PRINT("%s, interrupted\n", __func__);
		retcode = rv;
		goto err_i1;  /* Interrupted */
	}
	sem_locked = 1;

	if (READ_ONCE(xdev->pm_suspending)) {
		DEV_WARN(xdev, "entire_ctrl_ioctl blocked after sem by PM suspend: comm=%s pid=%d tgid=%d dev_idx=%d cmd=0x%x nr=0x%x status=0x%x\n",
			current->comm, task_pid_nr(current), task_tgid_nr(current),
			xdev->idx, cmd, nr, READ_ONCE(xdev->status));
		retcode = -EBUSY;
		goto err_i1;
	}

	out_size = in_size = _IOC_SIZE(cmd);
	if ((cmd & IOC_IN) == 0)
		in_size = 0;
	if ((cmd & IOC_OUT) == 0)
		out_size = 0;
	ksize = max(in_size, out_size);

	/* ERROR_PRINT("cmd 0x%x, arg 0x%lx, nr 0x%x, ksize 0x%x, pid=%d, ioctl_name %s\n", \ */
	/* 	cmd, arg, nr, ksize, task_pid_nr(current), ioctl->name); */

	/* Do not trust userspace, use our own definition */
	func = ioctl->func;

	if (unlikely(!func)) {
		ERROR_PRINT("no function\n");
		retcode = -EINVAL;
		goto err_i1;
	}

	if (ksize <= sizeof(stack_kdata)) {
		kdata = stack_kdata;
	} else {
		kdata = kmalloc(ksize, GFP_KERNEL);
		if (!kdata) {
			retcode = -ENOMEM;
			goto err_i1;
		}
	}


	if (copy_from_user(kdata, (void __user *)arg, in_size) != 0) {
		retcode = -EFAULT;
		goto err_i1;
	}

	if ((cmd == RPP_GETPARAM || cmd == RPP_SETPARAM) &&
	    ksize >= sizeof(struct rpp_param_info)) {
		struct rpp_param_info *info = (struct rpp_param_info *)kdata;

		if (rpp_debug_ioctl_delay_ms > 0 &&
		    (rpp_debug_ioctl_delay_param < 0 ||
		     info->param == (uint64_t)rpp_debug_ioctl_delay_param)) {
			DEV_WARN(xdev,
				"entire_ctrl_ioctl debug delay: comm=%s pid=%d ioctl=%s param=0x%llx delay=%dms\n",
				current->comm, task_pid_nr(current), ioctl->name,
				info->param, rpp_debug_ioctl_delay_ms);
			msleep(rpp_debug_ioctl_delay_ms);
		}
	}

	if (ksize > in_size)
		memset(kdata + in_size, 0, ksize - in_size);

	retcode = func(filp, xdev, kdata);
	if (copy_to_user((void __user *)arg, kdata, out_size) != 0)
		retcode = -EFAULT;

err_i1:
	if (!ioctl)
		ERROR_PRINT("%s, invalid ioctl: pid=%d, cmd=0x%02x, nr=0x%02x\n",
				__func__,
			  task_pid_nr(current),
			  cmd, nr);

	if (kdata != stack_kdata)
		kfree(kdata);

	if (sem_locked)
		up(&xdev->sem);
	return retcode;
}

static int entire_ctrl_open(struct inode *inode, struct file *file)
{
	struct rpp_cdev *xcdev;
	struct rpp_dev *xdev;
	int pid;
	int rv;

	/* pointer to containing structure of the character device inode */
	xcdev = container_of(inode->i_cdev, struct rpp_cdev, cdev);
	if (!xcdev) {
		ERROR_PRINT("entire_ctrl_open: invalid character device\n");
		return -ENODEV;
	}
	xdev = (struct rpp_dev *)xcdev->prppdev;
	if (!xdev) {
		ERROR_PRINT("entire_ctrl_open: invalid RPP device\n");
		return -ENODEV;
	}

	if (READ_ONCE(xdev->pm_suspending)) {
		DEV_WARN(xdev,
			"entire_ctrl_open blocked by PM suspend: comm=%s pid=%d tgid=%d dev_idx=%d status=0x%x\n",
			current->comm, task_pid_nr(current), task_tgid_nr(current),
			xdev->idx, READ_ONCE(xdev->status));
		return -EBUSY;
	}

	rv = rpp_idle_low_power_get(xdev, "entire_ctrl_open");
	if (rv != 0)
		return rv;

	/* create a reference to our char device in the opened file */
	file->private_data = xcdev;

	pid = (int)task_pid_nr(current);
	DEV_DEBUG(xdev, "[mm] %s, pid=0x%x\n", __func__, pid);

#if 0
	if ((dev->serv != NULL) && (dev->serv->pid != pid)) {
		ERROR_PRINT("Server 0x%x is exist\n", dev->serv->pid);
		return -EINVAL;
	}

	if (dev->serv == NULL) {
		dev->serv = kmalloc(sizeof(struct rpp_serv), GFP_KERNEL);
		if (!dev->serv) {
			return -ENOMEM;
		}
		dev->serv->pid = pid;
	}
#endif

	return 0;
}

/*
 * Called when the device goes from used to unused.
 */
static int entire_ctrl_close(struct inode *inode, struct file *file)
{
	struct rpp_dev *xdev;
	struct rpp_cdev *xcdev = (struct rpp_cdev *)file->private_data;
	int pid;

	if (!xcdev) {
		ERROR_PRINT("entire_ctrl_close: invalid character device\n");
		return -ENODEV;
	}

	/* fetch device specific data stored earlier during open */
	xdev = (struct rpp_dev *)xcdev->prppdev;
	if (!xdev) {
		ERROR_PRINT("entire_ctrl_close: invalid RPP device\n");
		return -ENODEV;
	}

	pid = (int)task_pid_nr(current);
	DEV_DEBUG(xdev, "[mm] %s, pid=0x%x\n", __func__, pid);
	// DEV_INFO(xdev, "entire_ctrl_close: comm=%s pid=%d tgid=%d dev_idx=%d pci=%s status=0x%x\n",
	// 	current->comm, pid, task_tgid_nr(current), xdev->idx,
	// 	pci_name(xdev->pdev), xdev->status);
	rpp_idle_low_power_put(xdev, "entire_ctrl_close");

#if 0
	if ((dev->serv == NULL) || (dev->serv->pid != pid)) {
		ERROR_PRINT("Server 0x%x is exist\n", dev->serv->pid);
		return -EINVAL;
	}

	kfree(dev->serv);
	dev->serv = NULL;
#else
	if (xdev->serv != NULL) {
		kfree(xdev->serv);
		xdev->serv = NULL;
	}
#endif
	/* if (xdev->async_queue)
		entire_ctrl_fasync(-1, file, 0); */

	return 0;
}

/*
 * character device file operations for entire control
 */
static const struct file_operations entire_ctrl_fops = {
	.owner = THIS_MODULE,
	.open = entire_ctrl_open,
	.release = entire_ctrl_close,
	.read = entire_ctrl_read,
	.write = entire_ctrl_write,
	.mmap = entire_bridge_mmap,
	.llseek = entire_ctrl_llseek,
	.unlocked_ioctl = entire_ctrl_ioctl,
	/* .fasync = entire_ctrl_fasync, */
	.poll = entire_ctrl_poll,
};

void cdev_entire_ctrl_init(struct rpp_cdev *xcdev)
{
	cdev_init(&xcdev->cdev, &entire_ctrl_fops);
}
