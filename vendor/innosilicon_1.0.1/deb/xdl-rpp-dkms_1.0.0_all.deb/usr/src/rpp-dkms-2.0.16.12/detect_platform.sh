#!/bin/sh
# Auto-detect RPP driver build platform.
# Override with: make platform=<name>
#
# POSIX sh for broad compatibility (BusyBox, dash, bash, minimal rootfs).
# Always prints a valid platform name; defaults to "linux" on any failure.

detect_from_os_release() {
	for f in /proc/device-tree/compatible /proc/device-tree/model; do
		if [ -r "$f" ] && tr '\0' '\n' < "$f" | grep -qi 'rk3568'; then
			printf '%s\n' rk3568
			return 0
		fi
		if [ -r "$f" ] && tr '\0' '\n' < "$f" | grep -qi 'rk3588'; then
			printf '%s\n' rk3588
			return 0
		fi
	done

	for f in /etc/issue /etc/issue.net /etc/petalinux-version /etc/petalinux/version; do
		if [ -r "$f" ] && grep -qi 'petalinux' "$f"; then
			printf '%s\n' petalinux
			return 0
		fi
	done

	if [ ! -r /etc/os-release ]; then
		return 1
	fi

	# shellcheck disable=SC1091
	. /etc/os-release 2>/dev/null || return 1

	id_lower=$(printf '%s' "${ID:-}" | tr '[:upper:]' '[:lower:]')
	id_like_lower=$(printf '%s' "${ID_LIKE:-}" | tr '[:upper:]' '[:lower:]')
	name_lower=$(printf '%s %s %s %s' "${NAME:-}" "${PRETTY_NAME:-}" "${VERSION:-}" "${VERSION_ID:-}" | tr '[:upper:]' '[:lower:]')

	case "$id_lower" in
	petalinux)
		printf '%s\n' petalinux
		return 0
		;;
	esac

	case " ${id_like_lower} " in
	*" petalinux "*)
		printf '%s\n' petalinux
		return 0
		;;
	esac

	case "$name_lower" in
	*petalinux*)
		printf '%s\n' petalinux
		return 0
		;;
	esac

	case "$id_lower" in
	openeuler)
		printf '%s\n' euler
		return 0
		;;
	esac

	case " ${id_like_lower} " in
	*" openeuler "*)
		printf '%s\n' euler
		return 0
		;;
	esac

	case "$id_lower" in
	*keyarch*)
		printf '%s\n' keyarchos
		return 0
		;;
	esac

	case " ${id_like_lower} " in
	*" keyarch "*)
		printf '%s\n' keyarchos
		return 0
		;;
	esac

	return 1
}

if detect_from_os_release; then
	exit 0
fi

case "$(uname -m 2>/dev/null)" in
loongarch64)
	printf '%s\n' loongson
	exit 0
	;;
esac

printf '%s\n' linux
exit 0
