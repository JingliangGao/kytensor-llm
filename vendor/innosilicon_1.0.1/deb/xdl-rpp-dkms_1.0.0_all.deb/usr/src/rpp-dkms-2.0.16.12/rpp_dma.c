/*  SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright (c) 2018 Synopsys, Inc. and/or its affiliates.
 * Synopsys DesignWare eDMA controller driver.
 */

#include "include/rpp_dma.h"
#include "include/rpp_dfx.h"
#include "include/rpp_types.h"


/******************************************************************************
 *
 *  EXTERN FUNCTION DEFINITIONS
 *
 ******************************************************************************/
/**
 * Enable or reset DMA read or write.
 *
 * This function sets the eDMA Enable Registers of write or read channels. The
 * ENB bit can be:
 *   - 1 Enable eDMA Write core logic.
 *   - 0 Reset the eDMA Write core logic.
 *
 * You must enable eDMA engine, before any other software setup actions,
 * for normal operation.
 *
 * You should reset the eDMA engine when there is any hardware error
 * is indicated by Error Status Registers.
 *
 * @param[in] pdreg The pointer to DMA register structure.
 * @param[in] dirc  The direction of the channels that need to be enable or
 *                  reset.
 * @param[in] enb   Enable or reset the DMA operation.
 */
void DmaSetOp(PDMA_REGS pdreg, DMA_DIRC dirc, BOOLEAN enb)
{
	UINT32 val = enb ? 0x1 : 0x0;
	PUINT32 reg = dirc == DMA_WRITE ? &pdreg->WrEnb.AsDword
			: &pdreg->RdEnb.AsDword;

	RPP_WRITE_UINT32(reg, val);

	/* Ensure reset propagates to all logic. */
	if (!enb) {
		int i = 200;

		while (RPP_READ_UINT32(reg)) {
			DTRACE("DmaSetOp: Wait 5 ms...reg=0x%x", reg);
			KERNEL_WAIT(5);
			if (i-- == 0) {
				DTRACE("DmaSetOp: Reset propagation time out!");
				break;
			}
		};
	}
}

/**
 * Set the weight of given channel.
 *
 * The weight value is used by the channel weighted round robin arbiter to
 * select the next channel write/read request.
 *
 * @param[in] pdreg The pointer to DMA register structure.
 * @param[in] dirc  The direction of the channel on which the weight will be
 *                  set.
 * @param[in] chan  The number of the channel on which the weight will be set.
 *                  It ranges from 0 to 7 for each transfer direction.
 * @param[in] wei   The weight value, ranged from 0 to 31.
 */
void DmaSetWei(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan, UINT8 wei) {
    PUINT32 reg = dirc == DMA_WRITE
            ? chan < 4 ? &pdreg->WrWeiLo.AsDword : &pdreg->WrWeiHi.AsDword
            : chan < 4 ? &pdreg->RdWeiLo.AsDword : &pdreg->RdWeiHi.AsDword;

    WEIGHT val;
    val.AsDword = RPP_READ_UINT32(reg);
    switch (chan % 4) {
        case 0:
            val.Weight0 = wei;
            break;
        case 1:
            val.Weight1 = wei;
            break;
        case 2:
            val.Weight2 = wei;
            break;
        default:
            val.Weight3 = wei;
            break;
    }
    RPP_WRITE_UINT32(reg, val.AsDword);
}

/**
 * Set DMA Doorbell Register to kick off or stop a transfer of given channel.
 *
 * This function can be used in two scenarios:
 *   - A transfer request need to be performed. After all other DMA Context
 *     Registers are configured, you can call this function to start the
 *     transfer.
 *   - For some reason you want to terminate the transfer. By setting the STOP
 *     bit, the DMA channel stops issuing requests, and sets the Channel status
 *     to 'Stopped', and asserts the 'Abort' interrupt if it is enabled.
 *
 * @param[in] pdreg The pointer to DMA register structure.
 * @param[in] dirc  The direction of the channel on which the doorbell is set.
 * @param[in] chan  The number of the channel on which the doorbell is set. It
 *                  ranges from 0 to 7 for each transfer direction.
 * @param[in] stop  True to stop the transfer; False to start the transfer.
 */
void DmaSetDoorBell(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan, BOOLEAN stop) {
    DOORBELL db = {{0}};
    db.Stop = (UINT32)stop;
    db.Chnl = (UINT32)chan;

    if ( dirc == DMA_READ ) {
        RPP_WRITE_UINT32( &pdreg->RdDb, db.AsDword );
    } else {
        RPP_WRITE_UINT32( &pdreg->WrDb, db.AsDword );
    }
}

/**
 * Set DMA transfer size for given channel.
 *
 * This function is used only for single block transfer, in which case the user
 * must specify the size of the data to be transferred in DMA context register.
 *
 * In multi block transfer mode, the DMA overwrites the Transfer Size Register
 * with the corresponding DWORD of the linked list element, so user doesn't
 * need to call this function.
 *
 * @param[in] pdreg The pointer to DMA register structure.
 * @param[in] dirc  The direction of the channel.
 * @param[in] chan  The number of the channel. It ranges from 0 to 7 for each
 *                  transfer direction.
 * @param[in] size    The DMA transfer size. The maximum DMA transfer size is
 *                  4Gbytes. The minimum transfer size is one byte.
 */
void DmaSetXferSize(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan, UINT32 size) {

	if (dirc == DMA_WRITE) {
        RPP_WRITE_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.XferSize, size);
    } else {
        RPP_WRITE_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.XferSize, size);
    }
}

/**
 * Set DMA transfer source for given channel.
 *
 * This function is used only for single block transfer. The address must be
 * DWORD aligned, indicating the next address to be read from.  The address is
 * always DWORD aligned even if the transfer size is byte aligned.
 *
 * In multi block transfer mode, the DMA overwrites the SAR Register
 * with the corresponding DWORD of the linked list element, so user doesn't
 * need to call this function.
 *
 * @param[in] pdreg The pointer to DMA register structure.
 * @param[in] dirc  The direction of the channel on which the transfer will be
 *                  performed.
 * @param[in] chan  The number of the channel on which the transfer will be
 *                  performed. It ranges from 0 to 7 for each transfer
 *                  direction.
 * @param[in] addr  The physical address of source memory. Caller must gurantee
 *                  the address is in remote memory for DMA read, and in local
 *                  memory for DMA write.
 */
void DmaSetSrc( PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan, PHYADDR addr ) {
    if (dirc == DMA_WRITE) {
        RPP_WRITE_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.SarPtrLo, addr.LowPart);
        RPP_WRITE_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.SarPtrHi, addr.HighPart);
    } else {
        RPP_WRITE_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.SarPtrLo, addr.LowPart);
        RPP_WRITE_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.SarPtrHi, addr.HighPart);
    }

}

/**
 * Set DMA transfer destination for given channel.
 *
 * This function is used only for single block transfer. The address must be
 * DWORD aligned, indicating the next address to be written to.  The address is
 * always DWORD aligned even if the transfer size is byte aligned.
 *
 * In multi block transfer mode, the DMA overwrites the DAR Register
 * with the corresponding DWORD of the linked list element, so user doesn't
 * need to call this function.
 *
 * @param[in] pdreg The pointer to DMA register structure.
 * @param[in] dirc  The direction of the channel on which the transfer will be
 *                  performed.
 * @param[in] chan  The number of the channel on which the transfer will be
 *                  performed. It ranges from 0 to 7 for each transfer
 *                  direction.
 * @param[in] addr  The physical address of destination memory. Caller must
 *                  gurantee the address is in local memory for DMA read, and
 *                  in remote memory for DMA write.
 */
void DmaSetDst( PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan, PHYADDR addr ) {
    if (dirc == DMA_WRITE) {
        RPP_WRITE_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.DarPtrLo, addr.LowPart);
        RPP_WRITE_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.DarPtrHi, addr.HighPart);
    } else {
        RPP_WRITE_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.DarPtrLo, addr.LowPart);
        RPP_WRITE_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.DarPtrHi, addr.HighPart);
    }
}

/**
 * Set the Control Register for given channel.
 *
 * This function is used only for single block transfer. The DMA Write/Read
 * Control Registers contains a variaty of bits that can affect the transfer
 * behavior in different ways. See user mannual for detailed explanation. For
 * this function, user only need to provide the transfer mode, then the
 * register will be configured accordingly.
 *
 * The eDMA core can work in two transfer modes:
 *   - Single block transfer. Only one block of data is transferred.
 *   - Multi block transfer. Arbitrary blocks of data can be transferred based
 *     on the Linked List descriptor.
 *
 * In multi block transfer mode, the DMA overwrites the Control Register
 * with the corresponding DWORD of the linked list element, so user doesn't
 * need to call this function.
 *
 * @param[in] pdreg The pointer to DMA register structure.
 * @param[in] dirc  The direction of the channel on which the transfer will be
 *                  performed.
 * @param[in] chan  The number of the channel on which the transfer will be
 *                  performed. It ranges from 0 to 7 for each transfer
 *                  direction.
 * @param[in] mode  Single block transfer or multi block transfer.
 */
void DmaSetCtrl(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan, DMA_XFER_MODE mode) {
    CHAN_CTRL_LO cctrl;

    cctrl.AsDword = 0x0;

    switch ( mode ) {
        case DMA_SINGLE_BLOCK:
            cctrl.LIE = 1;
            cctrl.RIE = 1;
            cctrl.TD = 1;
            break;
        case DMA_MULTI_BLOCK:
            cctrl.LLEN = 1;
            cctrl.CCS = 1;
            cctrl.TD = 1;
            break;
        default:
            /*  TODO: Not supported */
            break;
    }

    if (dirc == DMA_WRITE) {
        RPP_WRITE_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.CtrlLo, cctrl.AsDword);
        RPP_WRITE_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.CtrlHi, 0x0);
    } else {
        RPP_WRITE_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.CtrlLo, cctrl.AsDword);
        RPP_WRITE_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.CtrlHi, 0x0);
    }
}

/**
 * Set the MSI address for given DMA transfer direction and interrupt type.
 *
 * This function will set the word aligned address of the MWr done/abort message
 * interrupt sent on the DXALI0 interface when an eDMA transfer completes. This
 * function is used only for remote interrupt. It doesn't make sense for local
 * interrupt.
 *
 * For your Endpoint, you can use the IMWr as an MSI or MSIX. For MSI, you must
 * program all IMWRr Address Registers with the same MSI address, as PCI
 * Express only supports a single MSI address per Function.
 *
 * @param[in] pdreg The pointer to DMA register structure.
 * @param[in] dirc  The direction of the channels on which the MSI address is
 *                  set.
 * @param[in] type  The interrupt type that the MSI address is dedicated for.
 *                  It can be "Done" or "Abort".
 * @param[in] addr  The MSI physical address. Generally this value is coming
 *                  from the PCI configuration space when the operation system
 *                  allocates MSI resource for the eDMA device.
 * @see DmaSetMSIData
 */
void DmaSetMSIAddr(PDMA_REGS pdreg, DMA_DIRC dirc, DMA_INT_TYPE type,
        PHYADDR addr) {
    PUINT32 regHi, regLo;
    if (dirc == DMA_WRITE) {
        if (type == DMA_INT_DONE) {
            regLo = &pdreg->WrMsgDonAddrLo;
            regHi = &pdreg->WrMsgDonAddrHi;
        } else {
            regLo = &pdreg->WrMsgAbtAddrLo;
            regHi = &pdreg->WrMsgAbtAddrHi;
        }
    } else {
        if (type == DMA_INT_DONE) {
            regLo = &pdreg->RdMsgDonAddrLo;
            regHi = &pdreg->RdMsgDonAddrHi;
        } else {
            regLo = &pdreg->RdMsgAbtAddrLo;
            regHi = &pdreg->RdMsgAbtAddrHi;
        }
    }
    RPP_WRITE_UINT32( regLo, addr.LowPart );
    RPP_WRITE_UINT32( regHi, addr.HighPart );
}

/**
 * Set the MSI data for given DMA channel.
 *
 * A single IMWr Data Register is used for both types of interrupts (Done or
 * Abort) of each channel. This function is used to specify that data. This
 * function is used only for remote interrupt. It doesn't make sense for local
 * interrupt.
 *
 * @param[in] pdreg The pointer to DMA register structure.
 * @param[in] dirc  The direction of the channel on which the MSI data will be
 *                  set.
 * @param[in] chan  The number of the channel on which the MSI data will be set.
 *                  It ranges from 0 to 7 for each transfer direction.
 * @param[in] data  The MSI data. Generally this value is coming from the PCI
 *                  configuration sapce when the operating system allocates MSI
 *                  resource to the eDMA device.
 */
void DmaSetMSIData(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan, UINT16 data) {
    if (dirc == DMA_WRITE) {
        RPP_WRITE_UINT16_SAFE( &pdreg->WrMsgData[chan], data);
    } else {
        RPP_WRITE_UINT16_SAFE( &pdreg->RdMsgData[chan], data);
    }
}

/**
 * Set Linked List Interrupt Error Enable Registers.
 *
 * This function can:
 * - Enable/disable generation of the local CPU linked list error fetch or
 *   data transfer bridge error interrupt status bits contained in the Error
 *   Status Registers.
 * - Enable/disable generation of the remote CPU Abort interrupt MWr TLP.
 *
 * @param[in] pdreg The pointer to DMA register structure.
 * @param[in] dirc  The direction of the channel on which the linked list error
 *                  enable bit is set.
 * @param[in] chan  The number of the channel on which the linked list error
 *                  enable bit is set. It ranges from 0 to 7 for each transfer
 *                  direction.
 * @param[in] loc   True for local error enable bits; False for remote error
 *                  enable bit.
 * @param[in] enb   Enable or disable error enable bit.
 */
void DmaSetLLIntErr(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan, BOOLEAN loc,
        BOOLEAN enb) {
    LL_ERR_ENB val = {{0}};

    if (loc) {
        val.Leie = 0x1 << chan;
    } else {
        val.Reie = 0x1 << chan;
    }

    if (!enb)
        val.AsDword = ~(val.AsDword);

    if (dirc == DMA_WRITE) {
        if (enb) {
            val.AsDword |= RPP_READ_UINT32(&pdreg->WrIntLLErrEnb);
        } else {
            val.AsDword &= RPP_READ_UINT32(&pdreg->WrIntLLErrEnb);
        }
        RPP_WRITE_UINT32(&pdreg->WrIntLLErrEnb, val.AsDword);
    } else {
        if (enb) {
            val.AsDword |= RPP_READ_UINT32(&pdreg->RdIntLLErrEnb);
        } else {
            val.AsDword &= RPP_READ_UINT32(&pdreg->RdIntLLErrEnb);
        }
        RPP_WRITE_UINT32(&pdreg->RdIntLLErrEnb, val.AsDword);
    }
}

/**
 * Set the linked list for given channel.
 *
 * This function is used only for multi block transfer. It can inform the eDMA
 * core the starting address of the linked list in local memory by setting the
 * DMA Linked List Pointer Register during a multi block transfer
 * initialization.
 *
 * When the transfer get started, the Linked List Pointer Register will be
 * updated by the DMA to point to the next element in the transfer list after
 * the previous element is consumed.
 *
 * @param[in] pdreg The pointer to DMA register structure.
 * @param[in] dirc  The direction of the channel on which the multi block
 *                  transfer is performed.
 * @param[in] chan  The number of the channel on which the multi block transfer
 *                  is performed. It ranges from 0 to 7 for each transfer
 *                  direction.
 * @param[in] addr  The starting physical address of the linked list.
 */
void DmaSetLL(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan, PHYADDR addr) {
    if (dirc == DMA_WRITE) {
        RPP_WRITE_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.ElPtrLo, addr.LowPart);
        RPP_WRITE_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.ElPtrHi, addr.HighPart);
    } else {
        RPP_WRITE_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.ElPtrLo, addr.LowPart);
        RPP_WRITE_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.ElPtrHi, addr.HighPart);
    }
}

/**
 * Set the data element for given linked list.
 *
 * This function is used only for multi block transfer. For each linked list
 * data element, data producer should provide the source address, destination
 * address, the transfer size and the control code. User can utilize this
 * function to build a linked list one element by one element in specified
 * local memory.
 *
 * This function should be called when:
 *   - Initialize the linked list before the multi block transfer get started.
 *   - Update the data element during the multi block transfer.
 *
 * @param[in] lladdr    The virtual address of the linked list.
 * @param[in] idx       The index of data element that you want to create
 *                      content.
 * @param[in] pcs       The PCS flag. The Software and DMA use the
 *                      'PCS-CCS-CB-TCB' Producer-Consumer Synchronization
 *                      mechanism to ensure that software does not recycle
 *                      elements that have not yet been consumed by the DMA,
 *                      and that the DMA correctly recognizes and consumes
 *                      recycled elements. See user mannual for details.
 * @param[in] intr      Specify if the element triggers interrupt. Typically
 *                      there should be a Watermark element and a Done element
 *                      in the linked list that can trigger the interrupt.
 * @param[in] xferSize  The transfer size.
 * @param[in] src       The source physcial address. It should be in system
 *                      memory for DMA read, and local memory for DMA write.
 * @param[in] dst       The destination physical address. It should be in system
 *                      memory for DMA write, and local memory for DMA read.
 */
void DmaSetDataEle(PUINT32 lladdr, UINT32 idx, BOOLEAN pcs, BOOLEAN intr,
        UINT32 xferSize, PHYADDR src, PHYADDR dst) {
    CHAN_CTRL_LO cctrl;
    cctrl.AsDword = 0x0;
    cctrl.CB = pcs;
    cctrl.RIE = intr;
    cctrl.LIE = intr;

    RPP_WRITE_UINT32(lladdr + idx * 6 + 1, xferSize);
	/* DTRACE("%s, xferSize, addr=0x%llx, val=0x%x\n", __func__, lladdr + idx * 6 + 1, xferSize); */
    RPP_WRITE_UINT32(lladdr + idx * 6 + 2, src.LowPart);
	/* DTRACE("%s, src.LowPart, addr=0x%llx, val=0x%x\n", __func__, lladdr + idx * 6 + 2, src.LowPart); */
    RPP_WRITE_UINT32(lladdr + idx * 6 + 3, src.HighPart);
	/* DTRACE("%s, src.HighPart, addr=0x%llx, val=0x%x\n", __func__, lladdr + idx * 6 + 3, src.HighPart); */
	RPP_WRITE_UINT32(lladdr + idx * 6 + 4, dst.LowPart);
	/* DTRACE("%s, dst.LowPart, addr=0x%llx, val=0x%x\n", __func__, lladdr + idx * 6 + 4, dst.LowPart); */
	RPP_WRITE_UINT32(lladdr + idx * 6 + 5, dst.HighPart);
	/* DTRACE("%s, dst.HighPart, addr=0x%llx, val=0x%x\n", __func__, lladdr + idx * 6 + 5, dst.HighPart); */
	RPP_WRITE_UINT32(lladdr + idx * 6, cctrl.AsDword);
	/* DTRACE("%s, cctrl.AsDword, addr=0x%llx, val=0x%x\n", __func__, lladdr + idx * 6, cctrl.AsDword); */
}

/**
 * Get the data element for given linked list.
 *
 * This function can read the content of a specified element in the linked list.
 * It's an utility function that might be helpful when the low level driver code
 * need to know how the user feed the linked list.
 *
 * @param[in] lladdr    The virtual address of the linked list.
 * @param[in] idx       The index of data element that you want to get.
 * @param[out] pcs      The PCS flag. See 'PCS-CCS-CB-TCB' Producer-Consumer
 *                      Synchronization mechanism in user mannual.
 * @param[out] intr     Specify if the element triggers interrupt.
 * @param[out] xferSize The transfer size.
 * @param[out] src      The source physcial address.
 * @param[out] dst      The destination physical address.
 */
void DmaGetDataEle(PUINT32 lladdr, UINT32 idx, BOOLEAN *pcs, BOOLEAN *intr,
        UINT32 *xferSize, PHYADDR *src, PHYADDR *dst) {

    if (xferSize != NULL) {
        *xferSize = RPP_READ_UINT32(lladdr + idx * 6 + 1);
    }
    if (src != NULL) {
        src->LowPart = RPP_READ_UINT32(lladdr + idx * 6 + 2);
        src->HighPart = RPP_READ_UINT32(lladdr + idx * 6 + 3);
    }
    if (dst != NULL) {
        dst->LowPart = RPP_READ_UINT32(lladdr + idx * 6 + 4);
        dst->HighPart = RPP_READ_UINT32(lladdr + idx * 6 + 5);
    }
    if (pcs != NULL || intr != NULL) {
        CHAN_CTRL_LO cctrl;
        cctrl.AsDword = RPP_READ_UINT32(lladdr + idx * 6);
        if (pcs != NULL) *pcs = cctrl.CB;
        if (intr != NULL) *intr = cctrl.RIE;
    }
}

/**
 * Set the link element for given linked list.
 *
 * This function is used only for multi block transfer. The standard linked
 * list is made up with multiple data elements and one link element. The link
 * element contains the pointer to next element structure, informing the DMA
 * core where to go after consuming up current linked list. It can either point
 * to another linked list, or the starting element of current list
 * (called Recycling).
 *
 * Generally this function should be called to initialize the linked list
 * before the multi block transfer get started.
 *
 * @param[in] lladdr    The virtual address of the linked list.
 * @param[in] idx       The index of link element. Link element must be the
 *                      last one in the linked list.
 * @param[in] pcs       The PCS flag. The Software and DMA use the
 *                      'PCS-CCS-CB-TCB' Producer-Consumer Synchronization
 *                      mechanism to ensure that software does not recycle
 *                      elements that have not yet been consumed by the DMA,
 *                      and that the DMA correctly recognizes and consumes
 *                      recycled elements. See user mannual for details.
 * @param[in] nxt       The physcial address of next data element.
 * @param[in] recyc     Recycle current linked list or not. When 'nxt' points
 *                      to the starting data element of current list, this value
 *                      must be True; Otherwise it's False;
 */
void DmaSetLinkEle(PUINT32 lladdr, UINT32 idx, BOOLEAN pcs, PHYADDR nxt,
        BOOLEAN recyc) {
    CHAN_CTRL_LO cctrl;
    cctrl.AsDword = 0x0;
    cctrl.CB = pcs;
    cctrl.TCB = recyc;
    cctrl.LLP = 1;

    RPP_WRITE_UINT32(lladdr + idx * 6 + 2, nxt.LowPart);
	/* DTRACE("%s, nxt.LowPart, addr=0x%llx, val=0x%x\n", __func__, lladdr + idx * 6 + 2, nxt.LowPart); */
    RPP_WRITE_UINT32(lladdr + idx * 6 + 3, nxt.HighPart);
	/* DTRACE("%s, nxt.HighPart, addr=0x%llx, val=0x%x\n", __func__, lladdr + idx * 6 + 3, nxt.HighPart); */
    RPP_WRITE_UINT32(lladdr + idx * 6, cctrl.AsDword);
	/* DTRACE("%s, cctrl.AsDword, addr=0x%llx, val=0x%x\n", __func__, lladdr + idx * 6, cctrl.AsDword); */
}

/**
 * Get the link element for given linked list.
 *
 * This function can read the content of the link element of the linked list.
 * It's an utility function that might be helpful when the low level driver code
 * need to know how the user feed the linked list.
 *
 * @param[in] lladdr    The virtual address of the linked list.
 * @param[in] idx       The index of link element. Link element must be the
 *                      last one in the linked list.
 * @param[out] pcs      The PCS flag.
 * @param[out] nxt      The physcial address of next linked list.
 */
void DmaGetLinkEle(PUINT32 lladdr, UINT32 idx, BOOLEAN *pcs, PHYADDR *nxt) {

    if (nxt != NULL) {
        nxt->LowPart = RPP_READ_UINT32(lladdr + idx * 6 + 2);
        nxt->LowPart = RPP_READ_UINT32(lladdr + idx * 6 + 3);
    }
    if (pcs != NULL) {
        CHAN_CTRL_LO cctrl;
        cctrl.AsDword = RPP_READ_UINT32(lladdr + idx * 6);
        *pcs = cctrl.CB;
    }
}

/**
 * Get the number of enabled channels for both write and read direction.
 *
 * The eDMA core has at most 8 write channels and 8 read channels, but there
 * might be fewer enabled channels according to the static configuration of
 * the core. This function can get the actual enabled channel numbers by reading
 * the dedicated DMA register.
 *
 * @param[in] pdreg The pointer to DMA register structure.
 * @param[out] wrch Enabled write channel number.
 * @param[out] rdch Enabled read channel number.
 */
void DmaGetChanNum(PDMA_REGS pdreg, UINT8 *wrch, UINT8 *rdch) {

    DMA_CTRL ctrl;

    ctrl.AsDword = RPP_READ_UINT32(&pdreg->DmaCtrl);
    *wrch = ctrl.WrChans;
    *rdch = ctrl.RdChans;
}

/**
 * Get the status of given channel.
 *
 * The channel status bits of DMA Channel Control Register identify the current
 * operational state of the DMA write or read channel. The operation state
 * encoding for each DMA Channel is a s follows:
 *   - 00: Reserved
 *   - 01: Running. This channel is active and transferring data.
 *   - 10: Halted. An error condition has been detected, and the DMA has stopped
 *     this channel.
 *   - 11: Stopped. The DMA has transferred all data for this channel.
 *
 * This function gets the channel status bits and converts it to DMA_CHAN_STATUS
 * enumeration.
 *
 * @param[in] pdreg The pointer to DMA register structure.
 * @param[in] dirc  The direction of the channel whose status is fetched.
 * @param[in] chan  The number of the channel whose status is fetched. It
 *                  ranges from 0 to 7 for each transfer direction.
 * @param[out] status The channel status.
 */
void DmaGetChanStatus(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan,
        DMA_CHAN_STATUS *status) {

    CHAN_CTRL_LO ctrllo;

    if (dirc == DMA_WRITE) {
        ctrllo.AsDword = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.CtrlLo);
    } else {
        ctrllo.AsDword = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.CtrlLo);
    }

    *status = (DMA_CHAN_STATUS) ctrllo.DMA_CS;
}


/**
 * Get the transfer size of given channel.
 *
 * The Transfer Size Register is initialized by driver before the transfer is
 * started and automatically decremented by the DMA as the transfer progresses.
 * So by reading that register, this function can return the size of the
 * remaining bytes have not yet been transferred for current block.
 *
 * @note In multi block mode, the DMA overwrites Transfer Size Register with the
 * corresponding DWORD of the linked list element.
 *
 * @param[in] pdreg The pointer to DMA register structure.
 * @param[in] dirc  The direction of the channel on which you get the transfer
 *                  size.
 * @param[in] chan  The number of the channel on which you get the transfer
 *                  size. It ranges from 0 to 7 for each transfer direction.
 * @param[out] size Transfer size.
 */
void DmaGetXferSize( PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan, UINT32 *size) {
    if (dirc == DMA_WRITE) {
        *size = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.XferSize);
    } else {
        *size = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.XferSize);
    }
}

/**
 * Get the element pointer of given channel.
 *
 * When the transfer get started, the Element Pointer Register will be
 * updated by the DMA to point to the next element in the transfer list after
 * the previous element is consumed. So by reading that register, this function
 * can know which element the DMA core is currently working on. This function
 * only makes sense for multi block transfer.
 *
 * @param[in] pdreg The pointer to DMA register structure.
 * @param[in] dirc  The direction of the channel on which you get the element
 *                  pointer.
 * @param[in] chan  The number of the channel on which you get the element
 *                  pointer. It ranges from 0 to 7 for each transfer direction.
 * @param[out] addr The physical address of the element.
 */
void DmaGetElementPtr(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan,
        PHYADDR *addr) {
    if (dirc == DMA_WRITE) {
        addr->LowPart = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.ElPtrLo);
        addr->HighPart = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.ElPtrHi);
    } else {
        addr->LowPart = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.ElPtrLo);
        addr->HighPart = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.ElPtrHi);
    }
}


/**
 * Clear the interrupt.
 *
 * When driver receives a interrupt from eDMA device, it must clear the
 * interrupt source to announce that the interrupt has been handled.
 *
 * @note This function should be called in ISR.
 *
 * @param[in] pdreg The pointer to DMA register structure.
 * @param[in] dirc  The direction of the channel which signals the interrupt.
 * @param[in] chan  The number of the channel which signals the interrupt. It
 *                  ranges from 0 to 7 for each transfer direction.
 * @param[in] type  Specify if it's a "Done" or "Abort" interrupt.
 */
void DmaClrInt(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan, DMA_INT_TYPE type) {
    INT_CLEAR intClr = {{0}};
    if (type == DMA_INT_ABORT) {
        intClr.AbortClr = (0x1 << chan);
    } else {
        intClr.DoneClr = (0x1 << chan);
    }

    if (dirc == DMA_WRITE) {
        RPP_WRITE_UINT32(&pdreg->WrIntClr, intClr.AsDword);
    } else {
        RPP_WRITE_UINT32(&pdreg->RdIntClr, intClr.AsDword);
    }
}

/**
 * Query the interrupt source.
 *
 * This function queries Interrupt Status Registers to tell which channel
 * signals the interrupt. If the DMA read channel has successfully completed
 * the DMA read transfer, the corresponding Done bit of Interrupt Status
 * Register will be set to 1; If the DMA read channel has detected an
 * error, or you manually stopped the transfer, The correspoinding Abort bit
 * of Interrupt Status Register will be set to 1.
 *
 * @note This function should be called in ISR.
 *
 * @param[in] pdreg The pointer to DMA register structure.
 * @param[out] dirc The direction of the channel which signals the interrupt.
 * @param[out] chan The number of the channel which signals the interrupt.
 * @param[out] type Type of the interrupt. "Done" or "Abort" interrupt.
 * @return True if interrupt source is found; False otherwise.
 */
BOOLEAN DmaQueryIntSrc(PDMA_REGS pdreg, DMA_DIRC *dirc, UINT8 *chan,
		       DMA_INT_TYPE *type)
{
	BOOLEAN found = FALSE;
	INT_STATUS wrIntStatus;
	INT_STATUS rdIntStatus;
	INT_STATUS *pIntStatus;
	static UINT8 ch = 0;
	static DMA_DIRC dr = DMA_WRITE;
	UINT8 i;
	UINT8 j;
	UINT8 bitv;

    /*  work arroud: using PCIe send cmd to mpu that set sleep(1w) mode,  */
    /*  PCIe is temporarily unavailable, but read interrupt state will be 0xffffffff. */
    i = 0;
    while (i < 10) {
        wrIntStatus.AsDword = RPP_READ_UINT32(&pdreg->WrIntSta);
	    rdIntStatus.AsDword = RPP_READ_UINT32(&pdreg->RdIntSta);
        if(wrIntStatus.AsDword == 0xffffffff || rdIntStatus.AsDword == 0xffffffff) {
            i++;
        } 
        else {
            break;
        }
        WARNING_PRINT("times %d, wr/rdIntStatus: 0x%x 0x%x\n", i, wrIntStatus.AsDword, rdIntStatus.AsDword);
    }
    
	for (i = 0; i < 2; i++) {
		dr = (dr == DMA_WRITE) ? DMA_READ : DMA_WRITE;
		pIntStatus = (dr == DMA_WRITE) ? &wrIntStatus : &rdIntStatus;

		for (j = 0; j < 8; j++, ch++) {
			if (ch >= 8)
				ch = 0;

			bitv = 1 << ch;
			if (pIntStatus->AbortSta & bitv) {
				*chan = ch;
				*dirc = dr;
				*type = DMA_INT_ABORT;
				found = TRUE;
				break;
			}
			if (pIntStatus->DoneSta & bitv) {
				*chan = ch;
				*dirc = dr;
				*type = DMA_INT_DONE;
				found = TRUE;
				break;
			}
		}
		if (found)
			break;
	}
	return found;
}

/**
 * Query the source of eDMA core error.
 *
 * This function queries Error Status Registers to identify the source of the
 * hardware error. DMA core can possibly generate seven types of errors. Some
 * of them are fatal error and others are non-fatal. For non-fatal errors, the
 * software can request the DMA to continue processing.
 *
 * @param[in] pdreg The pointer to DMA register structure.
 * @param[in] dirc The direction of the channel which possibly has errors.
 * @param[in] chan The number of the channel which possibly has errors.
 * @param[out] type Type of the error. See DMA_ERR for all types of errors.
 * @return True if error source is found; False otherwise.
 */
BOOLEAN DmaQueryErrSrc(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan,
		       DMA_ERR *type)
{
	UINT32 val = (0x1 << chan);

	if (dirc == DMA_WRITE) {
		WR_ERR wrErr;
		wrErr.AsDword = RPP_READ_UINT32(&pdreg->WrErrSta);

	if (wrErr.BrdgErr & val) {
		*type = DMA_ERR_WR;
		return TRUE;
	}
	if (wrErr.LLErr & val) {
		*type = DMA_ERR_FETCH_LL;
		return TRUE;
	}
	} else {
		RD_ERR_LO rdErrLo;
		RD_ERR_HI rdErrHi;

		rdErrLo.AsDword = RPP_READ_UINT32(&pdreg->RdErrStaLo);
		if (rdErrLo.BrdgErr & val) {
			*type = DMA_ERR_RD;
			return TRUE;
		}
		if (rdErrLo.LLErr & val) {
			*type = DMA_ERR_FETCH_LL;
			return TRUE;
		}

		rdErrHi.AsDword = RPP_READ_UINT32(&pdreg->RdErrStaHi);
		if (rdErrHi.UrErr & val) {
			*type = DMA_ERR_UNSUPPORTED_RQST;
			return TRUE;
		}
		if (rdErrHi.CaErr & val) {
			*type = DMA_ERR_COMPLETER_ABORT;
			return TRUE;
		}
		if (rdErrHi.ToErr & val) {
			*type = DMA_ERR_CPL_TIME_OUT;
			return TRUE;
		}
		if (rdErrHi.EpErr & val) {
			*type = DMA_ERR_DATA_POISONING;
			return TRUE;
		}
	}
	return FALSE;
}

/**
 * Dump DMA registers of interest.
 *
 * This function serves as a debug routine to see if all the registers are
 * configured properly.
 *
 * @param[in] pdreg The pointer to DMA register structure.
 * @param[in] dirc  The direction of the channel.
 * @param[in] chan  The number of the channel. It ranges from 0 to 7 for each
 *                  transfer direction.
 * @param[out] str  The char buffer to store messages.
 * @param[in] len   The length of that char buffer.
 */
void DmaDumpReg(PDMA_REGS pdreg, DMA_DIRC dirc, UINT8 chan, char *str, int len)
{
	UINT32 reg[16];
	UINT32 val[16];
	int i = 0;

	if (dirc == DMA_WRITE) {
		reg[i] = (UINT32)((PCHAR)&pdreg->WrEnb - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->WrEnb);
		reg[i] = (UINT32)((PCHAR)&pdreg->WrMsgDonAddrLo - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->WrMsgDonAddrLo);
		reg[i] = (UINT32)((PCHAR)&pdreg->WrMsgDonAddrHi - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->WrMsgDonAddrHi);
		reg[i] = (UINT32)((PCHAR)&pdreg->WrMsgData[0] - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->WrMsgData[0]);
		reg[i] = (UINT32)((PCHAR)&pdreg->WrIntSta - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->WrIntSta);
		reg[i] = (UINT32)((PCHAR)&pdreg->WrErrSta - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->WrErrSta);
		reg[i] = 0xFFFF;
		val[i++] = 0xFFFFFFFF;
	} else {
		reg[i] = (UINT32)((PCHAR)&pdreg->RdEnb - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->RdEnb);
		reg[i] = (UINT32)((PCHAR)&pdreg->RdMsgDonAddrLo - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->RdMsgDonAddrLo);
		reg[i] = (UINT32)((PCHAR)&pdreg->RdMsgDonAddrHi - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->RdMsgDonAddrHi);
		reg[i] = (UINT32)((PCHAR)&pdreg->RdMsgData[0] - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->RdMsgData[0]);
		reg[i] = (UINT32)((PCHAR)&pdreg->RdIntSta - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->RdIntSta);
		reg[i] = (UINT32)((PCHAR)&pdreg->RdErrStaLo - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->RdErrStaLo);
		reg[i] = (UINT32)((PCHAR)&pdreg->RdErrStaHi - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->RdErrStaHi);
	}

	if (dirc == DMA_WRITE) {
		reg[i] = (UINT32)((PCHAR)&pdreg->CtxRegsGrp[chan].CtxRegs_WR.CtrlLo - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.CtrlLo);
		reg[i] = (UINT32)((PCHAR)&pdreg->CtxRegsGrp[chan].CtxRegs_WR.CtrlHi - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.CtrlHi);
		reg[i] = (UINT32)((PCHAR)&pdreg->CtxRegsGrp[chan].CtxRegs_WR.XferSize - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.XferSize);
		reg[i] = (UINT32)((PCHAR)&pdreg->CtxRegsGrp[chan].CtxRegs_WR.SarPtrLo - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.SarPtrLo);
		reg[i] = (UINT32)((PCHAR)&pdreg->CtxRegsGrp[chan].CtxRegs_WR.SarPtrHi - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.SarPtrHi);
		reg[i] = (UINT32)((PCHAR)&pdreg->CtxRegsGrp[chan].CtxRegs_WR.DarPtrLo - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.DarPtrLo);
		reg[i] = (UINT32)((PCHAR)&pdreg->CtxRegsGrp[chan].CtxRegs_WR.DarPtrHi - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.DarPtrHi);
		reg[i] = (UINT32)((PCHAR)&pdreg->CtxRegsGrp[chan].CtxRegs_WR.ElPtrLo - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.ElPtrLo);
		reg[i] = (UINT32)((PCHAR)&pdreg->CtxRegsGrp[chan].CtxRegs_WR.ElPtrHi - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_WR.ElPtrHi);
	} else {
		reg[i] = (UINT32)((PCHAR)&pdreg->CtxRegsGrp[chan].CtxRegs_RD.CtrlLo - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.CtrlLo);
		reg[i] = (UINT32)((PCHAR)&pdreg->CtxRegsGrp[chan].CtxRegs_RD.CtrlHi - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.CtrlHi);
		reg[i] = (UINT32)((PCHAR)&pdreg->CtxRegsGrp[chan].CtxRegs_RD.XferSize - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.XferSize);
		reg[i] = (UINT32)((PCHAR)&pdreg->CtxRegsGrp[chan].CtxRegs_RD.SarPtrLo - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.SarPtrLo);
		reg[i] = (UINT32)((PCHAR)&pdreg->CtxRegsGrp[chan].CtxRegs_RD.SarPtrHi - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.SarPtrHi);
		reg[i] = (UINT32)((PCHAR)&pdreg->CtxRegsGrp[chan].CtxRegs_RD.DarPtrLo - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.DarPtrLo);
		reg[i] = (UINT32)((PCHAR)&pdreg->CtxRegsGrp[chan].CtxRegs_RD.DarPtrHi - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.DarPtrHi);
		reg[i] = (UINT32)((PCHAR)&pdreg->CtxRegsGrp[chan].CtxRegs_RD.ElPtrLo - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.ElPtrLo);
		reg[i] = (UINT32)((PCHAR)&pdreg->CtxRegsGrp[chan].CtxRegs_RD.ElPtrHi - (PCHAR)pdreg);
		val[i++] = RPP_READ_UINT32(&pdreg->CtxRegsGrp[chan].CtxRegs_RD.ElPtrHi);
	}

	DPRINTF(str, len,
		"enb:          [0x%04X]  %08x\n"
		"IMWr_addr_lo: [0x%04X]  %08x\n"
		"IMWr_addr_hi: [0x%04X]  %08x\n"
		"IMWr_data:    [0x%04X]  %08x\n"
		"int_status:   [0x%04X]  %08x\n"
		"err_status_lo:[0x%04X]  %08x\n"
		"err_status_hi:[0x%04X]  %08x\n"
		"control_1:    [0x%04X]  %08x\n"
		"control_2:    [0x%04X]  %08x\n"
		"xfersize:     [0x%04X]  %08x\n"
		"sar_ptr_lo:   [0x%04X]  %08x\n"
		"sar_ptr_hi:   [0x%04X]  %08x\n"
		"dar_ptr_lo:   [0x%04X]  %08x\n"
		"dar_ptr_hi:   [0x%04X]  %08x\n"
		"el_ptr_lo:    [0x%04X]  %08x\n"
		"el_ptr_hi:    [0x%04X]  %08x\n",
		reg[0], val[0],
		reg[1], val[1],
		reg[2], val[2],
		reg[3], val[3],
		reg[4], val[4],
		reg[5], val[5],
		reg[6], val[6],
		reg[7], val[7],
		reg[8], val[8],
		reg[9], val[9],
		reg[10], val[10],
		reg[11], val[11],
		reg[12], val[12],
		reg[13], val[13],
		reg[14], val[14],
		reg[15], val[15]
	);
}

/**
 * Dump linked list elements.
 *
 * This function serves as a debug routine to see if all the linked list
 * elements are configured properly.
 *
 * @param[in] llAddr  The virtual address of the linked list.
 * @param[in] llLen   The number of elements of the linked list.
 * @param[out] str    The string buffer to hold the returned message.
 * @param[in] len     The size of 'str' buffer.
 */
void DmaDumpLL(PUINT32 llAddr, UINT32 llLen, char *str, int len)
{
	size_t tSize;
	int i;

	for (i = 0; i < llLen; i++) {
		DPRINTF(str, len,
			"%d:\n"
			"  [0x%04X] %08x\n"
			"  [0x%04X] %08x\n"
			"  [0x%04X] %08x\n"
			"  [0x%04X] %08x\n"
			"  [0x%04X] %08x\n"
			"  [0x%04X] %08x\n",
			i,
			(i * 24), RPP_READ_UINT32(llAddr + i * 6),
			(i * 24 + 4), RPP_READ_UINT32(llAddr + i * 6 + 1),
			(i * 24 + 8), RPP_READ_UINT32(llAddr + i * 6 + 2),
			(i * 24 + 12), RPP_READ_UINT32(llAddr + i * 6 + 3),
			(i * 24 + 16), RPP_READ_UINT32(llAddr + i * 6 + 4),
			(i * 24 + 20), RPP_READ_UINT32(llAddr + i * 6 + 5));
		DSTR_LEN(str, &tSize);
		/* DTRACE("tSize = %d  len = %d", tSize, len); */
		str += tSize;
		len -= tSize;
		if (len <= 0)
			break;
	}
}

