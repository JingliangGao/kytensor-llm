/*  SPDX-License-Identifier: GPL-2.0 */
/*
 * Copyright (c) 2018 Synopsys, Inc. and/or its affiliates.
 * Synopsys DesignWare eDMA controller driver.
 */

/*******************************************************************************
 *
 *  HEADER FILE INCLUDES
 *
 ******************************************************************************/
#include "include/rpp_dma.h"
#include "include/rpp_hal_dma.h"
#include "include/rpp_dfx.h"

/*******************************************************************************
 *
 * GLOBAL VARIABLES
 *
 ******************************************************************************/
static char *gErrInfo[DMA_ERR_CODE_NUM] = {0};

/*******************************************************************************
 *
 * STATIC FUNCTION DECLARATIONS
 *
 ******************************************************************************/
static HAL_DMA_RET SingleBlockRW(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan,
        PHYADDR src, PHYADDR dst, UINT32 size, UINT8 wei, BOOLEAN queue);
static HAL_DMA_RET MultiBlockRW(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan,
        UINT32 lle, UINT8 wm, UINT32 recyc, UINT8 wei, BOOLEAN queue,
        PRODUCER_FUNC func, PVOID ctx);
static HAL_DMA_RET MultiBlockRW2(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 ping, UINT8 pong,
        UINT32 lle, UINT8 wm, UINT32 recyc, UINT8 wei, BOOLEAN queue,
        PRODUCER_CB func, PVOID ctx);
static HAL_DMA_RET MultiBlockRW2_1(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan,
        UINT32 lle, UINT8 wm, UINT32 recyc, UINT8 wei, BOOLEAN queue,
        PRODUCER_CB func, PVOID ctx);
static PUINT32 GetBaseLLVAddr(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan);
static PHYADDR GetBaseLLPAddr(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan);
static void ProtectedSetDoorBell(PDMA_SYNCRUN_CONTEXT context);
static void ProtectedAbortXfer(PDMA_SYNCRUN_CONTEXT context);
static void ProtectedInitSingleBlockXfer(PDMA_SYNCRUN_CONTEXT context);
static void ProtectedInitMultiBlockXfer(PDMA_SYNCRUN_CONTEXT context);
static void ProtectedGetChanState(PDMA_SYNCRUN_CONTEXT context);
static void ProtectedCalcXferredSize(PDMA_SYNCRUN_CONTEXT context);
static void ProtectedDumpReg(PDMA_SYNCRUN_CONTEXT context);
static HAL_DMA_RET UpdateLLElements(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan);
static void InitErrInfo(void);

/*******************************************************************************
 *
 * EXTERN FUNCTION DEFINITIONS
 *
 ******************************************************************************/

/**
 * Initialize the eDMA device.
 *
 * The initialization procedure includes:
 *   - Reset controller logic
 *   - Check enabled channels
 *   - Set MSI address and data
 *
 * Firstly both the write and read DMA controller logic are reset by this
 * function. Doing so can ensure the next DMA read/write transfer is executed
 * successfully.
 *
 * Secondly this function read the number of enabled write/read channels from
 * DAM control register to make sure there are available channels to work upon.
 *
 * This function also set the MSI address and data to MWr registers for both
 * read and write channels. All channels use the same MSI resource.
 *
 * @note For our use case, all channels use the same MSI resource, so if user
 * uses a different eDMA core configuration, say enabling multiple MSI messages,
 * then this function need to be updated for that.
 *
 * @param[in] pdrsc  The DMA resource object.
 * @return DMA_SUCCESS if the DMA is initialized susccessfully; Other value
 * indicates some error happened. Call HalDmaGetErrInfo() to get the cause of
 * error.
 *
 * @see DmaSetOp
 * @see DmaGetChanNum
 * @see DmaSetMSIAddr
 * @see DmaSetMSIData
 */
HAL_DMA_RET HalDmaInit(PDMA_RSC pdrsc) {

    PHYADDR addr;
    UINT16 data;
    UINT8 chan;

    /* Check arguments */
    if (pdrsc == NULL) {
        return DMA_NULL_ARG;
    }

    spin_lock_init(&pdrsc->SyncLock);

    /* Firstly reset DMA read/write logic */
    DmaSetOp(pdrsc->DmaRegs, DMA_WRITE, FALSE);
    DmaSetOp(pdrsc->DmaRegs, DMA_READ, FALSE);

    /* Read enabled write/read channels */
    DmaGetChanNum(pdrsc->DmaRegs, &pdrsc->WrChans, &pdrsc->RdChans);

	DTRACE("active DMA channels wr chan = %d, rd chan = %d", pdrsc->WrChans, pdrsc->RdChans);

    if (pdrsc->WrChans == 0 && pdrsc->RdChans == 0) {
        DTRACE("No active DMA channels found!");
/*         return DMA_FATAL; */
    }

    addr = pdrsc->MsiAddr;
    data = pdrsc->MsiData;
    /* We use exactly the same addr/data for all interrupts and channels */
    DmaSetMSIAddr(pdrsc->DmaRegs, DMA_WRITE, DMA_INT_DONE, addr);
    DmaSetMSIAddr(pdrsc->DmaRegs, DMA_WRITE, DMA_INT_ABORT, addr);
    DmaSetMSIAddr(pdrsc->DmaRegs, DMA_READ, DMA_INT_DONE, addr);
    DmaSetMSIAddr(pdrsc->DmaRegs, DMA_READ, DMA_INT_ABORT, addr);

    for (chan = 0; chan < pdrsc->WrChans; chan++) {
        DmaSetMSIData(pdrsc->DmaRegs, DMA_WRITE, chan, data);
    }
    for (chan = 0; chan < pdrsc->RdChans; chan++) {
        DmaSetMSIData(pdrsc->DmaRegs, DMA_READ, chan, data);
    }

    /* Zero out internal variables */
    ZERO_MEM(&pdrsc->WrChanInfo, 8 * sizeof(CHAN_INFO));
    ZERO_MEM(&pdrsc->RdChanInfo, 8 * sizeof(CHAN_INFO));

    /* Enable the DMA engine after initial */
    DmaSetOp(pdrsc->DmaRegs, DMA_WRITE, TRUE);
    DmaSetOp(pdrsc->DmaRegs, DMA_READ, TRUE);

    return DMA_SUCCESS;
}

/**
 * Start a single block DMA write on given channel.
 *
 * Single block DMA write is to transfer (copy) of a Block of data from local
 * (application) memory to remote (link partner) memory.
 *
 * @note Caller must gurantee that the source address sit in local RAM and
 * destination address sit in system memory. This function does not check the
 * addresses against this requirement.
 *
 * @param[in] pdrsc The DMA resource object.
 * @param[in] chan  The write channel on which the transfer is performed. The
 *                  channel must be an available channel. User can get the
 *                  number of available DAM channels from DMA_RSC object after
 *                  calling HalDmaInit().
 * @param[in] src   The source physical address of the block of data need to be
 *                  transferred. This address must locate in system memory, and
 *                  it must be DWORD aligned.
 * @param[in] dst   The destination physical address where the data will be
 *                  transferred to. This address must locate in local RAM, and
 *                  it must be DWORD aligned.
 * @param[in] size  The transfer size of the data. The maximum DMA transfer size
 *                  is 4Gbytes, while the minimum transfer size is one byte.
 * @param[in] wei   The weight of the channel. The value is used by the channel
 *                  weighted round robin arbiter to select the next channel
 *                  write request.
 * @param[in] queue Queue up the request or not. If set this argument to true,
 *                  the DMA transfer will not get started by this function, and
 *                  only related registers are initialzied. So, user should call
 *                  HalDmaFlushQueue() later to really start the transfer.
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Call HalDmaGetErrInfo() to get the cause
 * of the error.
 *
 * @see HalDmaMultiBlockRead
 */
HAL_DMA_RET HalDmaSingleBlockWrite(PDMA_RSC pdrsc, UINT8 chan, PHYADDR src,
        PHYADDR dst, UINT32 size, UINT8 wei, BOOLEAN queue) {
    return SingleBlockRW(pdrsc, DMA_WRITE, chan, src, dst, size, wei, queue);
}


/**
 * Start DMA multi block write on given channel.
 *
 * Multi block write are based on Linked List descriptor. The DMA fetches the
 * transfer control information (called Channel Context ) for each Transfer
 * (Block), from a list of DMA Elements that have been constructed in local
 * memory. This function will create the linked list according to the given
 * arguments, and configures related registers to start the transfer.
 *
 * @note
 *   - Caller specify the source and destination address of each element through
 *   PRODUCER_FUNC() callback, and it must gurantee that the source address sit
 *   in system memory and destination address sit in local RAM. This function
 *   does not check the addresses against this requirement.
 *   - Caller must gurantee that the linked list element number, the recycle and
 *   the PRODUCER_FUNC() callbak are meet to each other. See PRODUCER_FUNC()
 *   for more.
 *
 * @param[in] pdrsc The DMA resource object.
 * @param[in] chan  The write channel on which the transfer is performed. The
 *                  channel must be an available channel. User can get the
 *                  number of available DAM channels from DMA_RSC object after
 *                  calling HalDmaInit().
 * @param[in] lle   The number of elements in linked list descriptor. It
 *                  includes the number of data elements and link element.
 * @param[in] wm    The index of watermark element. Typically a "Watermark"
 *                  interrupt is positioned near the middle of the transfer
 *                  list, and the element's LIE bit is set to 1'b1.
 * @param[in] recyc Specify how many times to recylce the linked list. If 0 is
 *                  given, the recycling will last forever. User can call
 *                  HalDmaAbort() to terminate the transfer.
 * @param[in] wei   The weight of the channel. The value is used by the channel
 *                  weighted round robin arbiter to select the next channel
 *                  write request.
 * @param[in] queue Queue up the request or not. If set this argument to true,
 *                  the DMA transfer will not get started by this function, and
 *                  only related registers are initialzied. So, user should call
 *                  HalDmaFlushQueue() later to really start the transfer.
 * @param[in] func  The linked list data producer callback function, used by
 *                  HAL to fetch source, destination and transfer size of next
 *                  element. See PRODUCER_FUNC() for more details.
 * @param[in] ctx   The context for producer function.
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Call HalDmaGetErrInfo() to get the cause
 * of the error.
 *
 * @see HalDmaSingleBlockRead
 */
HAL_DMA_RET HalDmaMultiBlockWrite(PDMA_RSC pdrsc, UINT8 chan, UINT32 lle,
        UINT8 wm, UINT32 recyc, UINT8 wei, BOOLEAN queue, PRODUCER_FUNC func,
        PVOID ctx) {
    return MultiBlockRW(pdrsc, DMA_WRITE, chan, lle, wm, recyc, wei, queue,
            func, ctx);
}

/**
 * Start DMA multi block write on given channel.
 *
 * Multi block write are based on Linked List descriptor. The DMA fetches the
 * transfer control information (called Channel Context ) for each Transfer
 * (Block), from a list of DMA Elements that have been constructed in local
 * memory. This function will create the linked list according to the given
 * arguments, and configures related registers to start the transfer.
 *
 * @note
 *   - Caller specify the source and destination address of each element through
 *   PRODUCER_FUNC() callback, and it must gurantee that the source address sit
 *   in system memory and destination address sit in local RAM. This function
 *   does not check the addresses against this requirement.
 *   - Caller must gurantee that the linked list element number, the recycle and
 *   the PRODUCER_FUNC() callbak are meet to each other. See PRODUCER_FUNC()
 *   for more.
 *
 * @param[in] pdrsc The DMA resource object.
 * @param[in] chan  The write channel on which the transfer is performed. The
 *                  channel must be an available channel. User can get the
 *                  number of available DAM channels from DMA_RSC object after
 *                  calling HalDmaInit().
 * @param[in] lle   The number of elements in linked list descriptor. It
 *                  includes the number of data elements and link element.
 * @param[in] wm    The index of watermark element. Typically a "Watermark"
 *                  interrupt is positioned near the middle of the transfer
 *                  list, and the element's LIE bit is set to 1'b1.
 * @param[in] recyc Specify how many times to recylce the linked list. If 0 is
 *                  given, the recycling will last forever. User can call
 *                  HalDmaAbort() to terminate the transfer.
 * @param[in] wei   The weight of the channel. The value is used by the channel
 *                  weighted round robin arbiter to select the next channel
 *                  write request.
 * @param[in] queue Queue up the request or not. If set this argument to true,
 *                  the DMA transfer will not get started by this function, and
 *                  only related registers are initialzied. So, user should call
 *                  HalDmaFlushQueue() later to really start the transfer.
 * @param[in] func  The linked list data producer callback function, used by
 *                  HAL to fetch source, destination and transfer size of next
 *                  element. See PRODUCER_FUNC() for more details.
 * @param[in] ctx   The context for producer function.
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Call HalDmaGetErrInfo() to get the cause
 * of the error.
 *
 * @see HalDmaSingleBlockRead
 */
HAL_DMA_RET HalDmaMultiBlockWrite2(PDMA_RSC pdrsc, UINT8 ping, UINT8 pong, UINT32 lle,
        UINT8 wm, UINT32 recyc, UINT8 wei, BOOLEAN queue, PRODUCER_CB func,
        PVOID ctx) {
    return MultiBlockRW2(pdrsc, DMA_WRITE, ping, pong, lle, wm, recyc, wei, queue,
            func, ctx);
}

/**
 * Start DMA multi block write on given channel.
 *
 * Multi block write are based on Linked List descriptor. The DMA fetches the
 * transfer control information (called Channel Context ) for each Transfer
 * (Block), from a list of DMA Elements that have been constructed in local
 * memory. This function will create the linked list according to the given
 * arguments, and configures related registers to start the transfer.
 *
 * @note
 *   - Caller specify the source and destination address of each element through
 *   PRODUCER_FUNC() callback, and it must gurantee that the source address sit
 *   in system memory and destination address sit in local RAM. This function
 *   does not check the addresses against this requirement.
 *   - Caller must gurantee that the linked list element number, the recycle and
 *   the PRODUCER_FUNC() callbak are meet to each other. See PRODUCER_FUNC()
 *   for more.
 *
 * @param[in] pdrsc The DMA resource object.
 * @param[in] chan  The write channel on which the transfer is performed. The
 *                  channel must be an available channel. User can get the
 *                  number of available DAM channels from DMA_RSC object after
 *                  calling HalDmaInit().
 * @param[in] lle   The number of elements in linked list descriptor. It
 *                  includes the number of data elements and link element.
 * @param[in] wm    The index of watermark element. Typically a "Watermark"
 *                  interrupt is positioned near the middle of the transfer
 *                  list, and the element's LIE bit is set to 1'b1.
 * @param[in] recyc Specify how many times to recylce the linked list. If 0 is
 *                  given, the recycling will last forever. User can call
 *                  HalDmaAbort() to terminate the transfer.
 * @param[in] wei   The weight of the channel. The value is used by the channel
 *                  weighted round robin arbiter to select the next channel
 *                  write request.
 * @param[in] queue Queue up the request or not. If set this argument to true,
 *                  the DMA transfer will not get started by this function, and
 *                  only related registers are initialzied. So, user should call
 *                  HalDmaFlushQueue() later to really start the transfer.
 * @param[in] func  The linked list data producer callback function, used by
 *                  HAL to fetch source, destination and transfer size of next
 *                  element. See PRODUCER_FUNC() for more details.
 * @param[in] ctx   The context for producer function.
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Call HalDmaGetErrInfo() to get the cause
 * of the error.
 *
 * @see HalDmaSingleBlockRead
 */
HAL_DMA_RET HalDmaMultiBlockWrite2_1(PDMA_RSC pdrsc, UINT8 chan, UINT32 lle,
        UINT8 wm, UINT32 recyc, UINT8 wei, BOOLEAN queue, PRODUCER_CB func,
        PVOID ctx) {
    return MultiBlockRW2_1(pdrsc, DMA_WRITE, chan, lle, wm, recyc, wei, queue,
            func, ctx);
}

/**
 * Start a single block DMA read on given channel.
 *
 * Single block DMA read is to transfer (copy) of a Block of data from remote
 * (link partner) memory to local (application) memory.
 *
 * @note Caller must gurantee that the source address sit in system memory
 * and destination address sit in local RAM. This function does not check the
 * addresses against this requirement.
 *
 * @param[in] pdrsc The DMA resource object.
 * @param[in] chan  The read channel on which the transfer is performed. The
 *                  channel must be an available channel. User can get the
 *                  number of available DAM channels from DMA_RSC object after
 *                  calling HalDmaInit().
 * @param[in] src   The source physical address of the block of data need to be
 *                  transferred. This address must locate in system memory, and
 *                  it must be DWORD aligned.
 * @param[in] dst   The destination physical address where the data will be
 *                  transferred to. This address must locate in local RAM, and
 *                  it must be DWORD aligned.
 * @param[in] size  The transfer size of the data. The maximum DMA transfer size
 *                  is 4Gbytes, while the minimum transfer size is one byte.
 * @param[in] wei   The weight of the channel. The value is used by the channel
 *                  weighted round robin arbiter to select the next channel
 *                  read request.
 * @param[in] queue Queue up the request or not. If set this argument to true,
 *                  the DMA transfer will not get started by this function, and
 *                  only related registers are initialzied. So, user should call
 *                  HalDmaFlushQueue() later to really start the transfer.
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Call HalDmaGetErrInfo() to get the cause
 * of the error.
 *
 * @see HalDmaMultiBlockRead
 */
HAL_DMA_RET HalDmaSingleBlockRead(PDMA_RSC pdrsc, UINT8 chan, PHYADDR src,
        PHYADDR dst, UINT32 size, UINT8 wei, BOOLEAN queue) {
    return SingleBlockRW(pdrsc, DMA_READ, chan, src, dst, size, wei, queue);
}

/**
 * Start DMA multi block read on given channel.
 *
 * Multi block read are based on Linked List descriptor. The DMA fetches the
 * transfer control information (called Channel Context ) for each Transfer
 * (Block), from a list of DMA Elements that have been constructed in local
 * memory. This function will create the linked list according to the given
 * arguments, and configures related registers to start the transfer.
 *
 * @note
 *   - Caller specify the source and destination address of each element through
 *   PRODUCER_FUNC() callback, and it must gurantee that the source address sit
 *   in system memory and destination address sit in local RAM. This function
 *   does not check the addresses against this requirement.
 *   - Caller must gurantee that the linked list element number, the recycle and
 *   the PRODUCER_FUNC() callbak are meet to each other. See PRODUCER_FUNC()
 *   for more.
 *
 * @param[in] pdrsc The DMA resource object.
 * @param[in] chan  The write channel on which the transfer is performed. The
 *                  channel must be an available channel. User can get the
 *                  number of available DAM channels from DMA_RSC object after
 *                  calling HalDmaInit().
 * @param[in] lle   The number of elements in linked list descriptor. It
 *                  includes the number of data elements and link element.
 * @param[in] wm    The index of watermark element. Typically a "Watermark"
 *                  interrupt is positioned near the middle of the transfer
 *                  list, and the element's LIE bit is set to 1'b1.
 * @param[in] recyc Specify how many times to recylce the linked list. If 0 is
 *                  given, the recycling will last forever. User can call
 *                  HalDmaAbort() to terminate the transfer.
 * @param[in] wei   The weight of the channel. The value is used by the channel
 *                  weighted round robin arbiter to select the next channel
 *                  read request.
 * @param[in] queue Queue up the request or not. If set this argument to true,
 *                  the DMA transfer will not get started by this function, and
 *                  only related registers are initialzied. So, user should call
 *                  HalDmaFlushQueue() later to really start the transfer.
 * @param[in] func  The linked list data producer callback function, used by
 *                  HAL to fetch source, destination and transfer size of next
 *                  element. See PRODUCER_FUNC() for more details.
 * @param[in] ctx   The context for producer function.
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Call HalDmaGetErrInfo() to get the cause
 * of the error.
 *
 * @see HalDmaSingleBlockRead
 */
HAL_DMA_RET HalDmaMultiBlockRead(PDMA_RSC pdrsc, UINT8 chan, UINT32 lle,
        UINT8 wm, UINT32 recyc, UINT8 wei, BOOLEAN queue, PRODUCER_FUNC func,
        PVOID ctx) {
    return MultiBlockRW(pdrsc, DMA_READ, chan, lle, wm, recyc, wei, queue,
            func, ctx);
}

/**
 * Start DMA multi block read on given channel.
 *
 * Multi block read are based on Linked List descriptor. The DMA fetches the
 * transfer control information (called Channel Context ) for each Transfer
 * (Block), from a list of DMA Elements that have been constructed in local
 * memory. This function will create the linked list according to the given
 * arguments, and configures related registers to start the transfer.
 *
 * @note
 *   - Caller specify the source and destination address of each element through
 *   PRODUCER_FUNC() callback, and it must gurantee that the source address sit
 *   in system memory and destination address sit in local RAM. This function
 *   does not check the addresses against this requirement.
 *   - Caller must gurantee that the linked list element number, the recycle and
 *   the PRODUCER_FUNC() callbak are meet to each other. See PRODUCER_FUNC()
 *   for more.
 *
 * @param[in] pdrsc The DMA resource object.
 * @param[in] ping  The write channel on which the transfer is performed. The
 *                  channel must be an available channel. User can get the
 *                  number of available DAM channels from DMA_RSC object after
 *                  calling HalDmaInit().
 * @param[in] pong  The write channel on which the transfer is performed. The
 *                  channel must be an available channel. User can get the
 *                  number of available DAM channels from DMA_RSC object after
 *                  calling HalDmaInit().
 * @param[in] lle   The number of elements in linked list descriptor. It
 *                  includes the number of data elements and link element.
 * @param[in] wm    The index of watermark element. Typically a "Watermark"
 *                  interrupt is positioned near the middle of the transfer
 *                  list, and the element's LIE bit is set to 1'b1.
 * @param[in] recyc Specify how many times to recylce the linked list. If 0 is
 *                  given, the recycling will last forever. User can call
 *                  HalDmaAbort() to terminate the transfer.
 * @param[in] wei   The weight of the channel. The value is used by the channel
 *                  weighted round robin arbiter to select the next channel
 *                  read request.
 * @param[in] queue Queue up the request or not. If set this argument to true,
 *                  the DMA transfer will not get started by this function, and
 *                  only related registers are initialzied. So, user should call
 *                  HalDmaFlushQueue() later to really start the transfer.
 * @param[in] func  The linked list data producer callback function, used by
 *                  HAL to fetch source, destination and transfer size of next
 *                  element. See PRODUCER_FUNC() for more details.
 * @param[in] ctx   The context for producer function.
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Call HalDmaGetErrInfo() to get the cause
 * of the error.
 *
 * @see HalDmaSingleBlockRead
 */
HAL_DMA_RET HalDmaMultiBlockRead2(PDMA_RSC pdrsc, UINT8 ping, UINT8 pong, UINT32 lle,
        UINT8 wm, UINT32 recyc, UINT8 wei, BOOLEAN queue, PRODUCER_CB func,
        PVOID ctx) {
    return MultiBlockRW2(pdrsc, DMA_READ, ping, pong, lle, wm, recyc, wei, queue,
            func, ctx);
}

/**
 * Start DMA multi block read on given channel.
 *
 * Multi block read are based on Linked List descriptor. The DMA fetches the
 * transfer control information (called Channel Context ) for each Transfer
 * (Block), from a list of DMA Elements that have been constructed in local
 * memory. This function will create the linked list according to the given
 * arguments, and configures related registers to start the transfer.
 *
 * @note
 *   - Caller specify the source and destination address of each element through
 *   PRODUCER_FUNC() callback, and it must gurantee that the source address sit
 *   in system memory and destination address sit in local RAM. This function
 *   does not check the addresses against this requirement.
 *   - Caller must gurantee that the linked list element number, the recycle and
 *   the PRODUCER_FUNC() callbak are meet to each other. See PRODUCER_FUNC()
 *   for more.
 *
 * @param[in] pdrsc The DMA resource object.
 * @param[in] ping  The write channel on which the transfer is performed. The
 *                  channel must be an available channel. User can get the
 *                  number of available DAM channels from DMA_RSC object after
 *                  calling HalDmaInit().
 * @param[in] lle   The number of elements in linked list descriptor. It
 *                  includes the number of data elements and link element.
 * @param[in] wm    The index of watermark element. Typically a "Watermark"
 *                  interrupt is positioned near the middle of the transfer
 *                  list, and the element's LIE bit is set to 1'b1.
 * @param[in] recyc Specify how many times to recylce the linked list. If 0 is
 *                  given, the recycling will last forever. User can call
 *                  HalDmaAbort() to terminate the transfer.
 * @param[in] wei   The weight of the channel. The value is used by the channel
 *                  weighted round robin arbiter to select the next channel
 *                  read request.
 * @param[in] queue Queue up the request or not. If set this argument to true,
 *                  the DMA transfer will not get started by this function, and
 *                  only related registers are initialzied. So, user should call
 *                  HalDmaFlushQueue() later to really start the transfer.
 * @param[in] func  The linked list data producer callback function, used by
 *                  HAL to fetch source, destination and transfer size of next
 *                  element. See PRODUCER_FUNC() for more details.
 * @param[in] ctx   The context for producer function.
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Call HalDmaGetErrInfo() to get the cause
 * of the error.
 *
 * @see HalDmaSingleBlockRead
 */
HAL_DMA_RET HalDmaMultiBlockRead2_1(PDMA_RSC pdrsc, UINT8 chan, UINT32 lle,
        UINT8 wm, UINT32 recyc, UINT8 wei, BOOLEAN queue, PRODUCER_CB func,
        PVOID ctx) {
    return MultiBlockRW2_1(pdrsc, DMA_READ, chan, lle, wm, recyc, wei, queue,
            func, ctx);
}

/**
 * Abort an undergoing DMA transfer.
 *
 * An undergoing DMA transfer can be terminated any time as requested by calling
 * this function. The Stop bit of Doorbell Register will be set. After that,
 * this function will check the status of the channel to see if the transfer is
 * successfully terminated.
 *
 * This function takes no effect if the transfer has already stopped before we
 * terminate it.
 *
 * @param[in] pdrsc The pointer to DMA resource.
 * @param[in] dirc  The direction of the channel on which the transfer will be
 *                  terminated.
 * @param[in] chan  The number of the channel on which the transfer will be
 *                  terminated.
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Call HalDmaGetErrInfo() to get the cause
 * of the error.
 *
 * @see HalDmaStop
 * @see DmaSetOp
 * @see DmaGetChanStatus
 */
HAL_DMA_RET HalDmaAbort(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan) {

    DMA_SYNCRUN_CONTEXT context = {pdrsc, dirc, chan, NULL};
    PCHAN_INFO pChanInfo;

    if (pdrsc == NULL) {
        return DMA_NULL_ARG;
    }
    if ((dirc == DMA_WRITE && chan >= pdrsc->WrChans) || (dirc == DMA_READ
            && chan >= pdrsc->RdChans)) {
        return DMA_INVALID_CHAN;
    }


    pChanInfo = (dirc == DMA_WRITE) ? &pdrsc->WrChanInfo[chan]
            : &pdrsc->RdChanInfo[chan];

    INT_SYNC_RUN(ProtectedAbortXfer, &context);

    /* Check if the abort request is successfully performed. */
    KERNEL_WAIT(15);
    INT_SYNC_RUN(ProtectedGetChanState, &context);
    if (pChanInfo->Status == CHAN_RUNNING) {
        DTRACE("Failed to abort the xfer on this channel.\n");
        return DMA_UNKNOWN_FAILURE;
    }
    return DMA_SUCCESS;
}

/**
 * Stop an undergoing DMA transfer.
 *
 * This function is similar with HalDmaAbort but it uses a different way to
 * stop the undergoing transfer on specified channel. This function does not
 * touch the Stop bit of Doorbell Register. Instead, it makes the driver no
 * longer update the linked list, so the DMA engine will stop when it can't
 * find any new data in the linked list.
 *
 * Since the Doorbell Register is not touched, the DMA engine will not issue
 * Abort interrupt. Besides, there will be some delay between you call this
 * function and the DMA transfer stop, because the DMA engine will need to
 * finish all remained data in current linked list.
 *
 * This function takes no effect if the transfer has already stopped before we
 * terminate it.
 *
 * @param[in] pdrsc The pointer to DMA resource.
 * @param[in] dirc  The direction of the channel on which the transfer will be
 *                  stopped.
 * @param[in] chan  The number of the channel on which the transfer will be
 *                  stopped.
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Call HalDmaGetErrInfo() to get the cause
 * of the error.
 *
 * @see HalDmaAbort
 */
HAL_DMA_RET HalDmaStop(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan) {

    PCHAN_INFO pChanInfo;

    if (pdrsc == NULL) {
        return DMA_NULL_ARG;
    }
    if ((dirc == DMA_WRITE && chan >= pdrsc->WrChans) || (dirc == DMA_READ
            && chan >= pdrsc->RdChans)) {
        return DMA_INVALID_CHAN;
    }
    pChanInfo = (dirc == DMA_WRITE) ? &pdrsc->WrChanInfo[chan]
            : &pdrsc->RdChanInfo[chan];
    pChanInfo->Recycle = 1;

    return DMA_SUCCESS;
}
/**
 * Resume an aborted DMA transfer.
 *
 * An undergoing DMA transfer can be terminated any time as requested by calling
 * HalDmaAbort() function. If user want to continue the stopped transfer, this
 * function can be called.
 *
 * @note The resume function is only for debug use and user should not use this
 * feature in any real world application.
 *
 * For single block transfer, this function just re-initialize all DMA registers
 * to start the transfer from the very beginning, not really "resume" from
 * where the transfer is "paused".
 *
 * For multi block transfer, this function just simply set the Doorbell
 * register. The DMA core will fetch the data element from the linked list
 * according to the current element pointer it holds. So, the transfer is
 * roughly "resumed", but the data block stopped last time will be transferred
 * again from beginning.
 *
 * @param[in] pdrsc The pointer to DMA resource.
 * @param[in] dirc  The direction of the channel on which the transfer will be
 *                  resumed.
 * @param[in] chan  The number of the channel on which the transfer will be
 *                  resumed.
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Call HalDmaGetErrInfo() to get the cause
 * of the error.
 */
HAL_DMA_RET HalDmaResume(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan) {

    DMA_SYNCRUN_CONTEXT context = {pdrsc, dirc, chan, NULL};
    PCHAN_INFO pChanInfo;

    if (pdrsc == NULL) {
        return DMA_NULL_ARG;
    }
    if ((dirc == DMA_WRITE && chan >= pdrsc->WrChans) || (dirc == DMA_READ
            && chan >= pdrsc->RdChans)) {
        return DMA_INVALID_CHAN;
    }

    pChanInfo = (dirc == DMA_WRITE) ? &pdrsc->WrChanInfo[chan]
            : &pdrsc->RdChanInfo[chan];

    /* Make sure the channel is stopped */
    INT_SYNC_RUN(ProtectedGetChanState, &context);
    if (pChanInfo->Status != CHAN_STOPPED) {
        return DMA_CHAN_BUSY;
    }

    if (pChanInfo->LLElements) {
        INT_SYNC_RUN(ProtectedSetDoorBell, &context);
    } else {
        SingleBlockRW(pdrsc, dirc, chan, pChanInfo->SrcPos, pChanInfo->DstPos,
                (UINT32)pChanInfo->FeedSize, pChanInfo->Weight, FALSE);
    }
    return DMA_SUCCESS;
}

/**
 * Flush queuing DMA read/write jobs.
 *
 * Queuing jobs are those DMA transfer requests which have all context registers
 * been configured but Doorbell is not set. This function will automatically
 * search for queuing jobs, if any, and kick off the transfer by set Doorbell.
 * If no queuing job are found, this function will report error and no DMA
 * registers will be touched.
 *
 * @param[in] pdrsc The DMA resource object.
 * @return DMA_SUCCESS if queuing jobs are found and is successfully started.
 * Otherwise, an error happens during the process. Call HalDmaGetErrInfo() to
 * get the cause of the error.
 *
 * @see DmaSetOp
 */
HAL_DMA_RET HalDmaFlushQueue(PDMA_RSC pdrsc) {

    DMA_SYNCRUN_CONTEXT context = {0};
    int rChanCnt = 0;
    int wChanCnt = 0;

    /* Check arguments */
    if (pdrsc == NULL) {
        return DMA_NULL_ARG;
    }

    context.DmaRsc = pdrsc;

    /* Check all write channels to see if there is any queuing job. */
    context.Dirc = DMA_WRITE;
    for (context.Chan = 0; context.Chan < pdrsc->WrChans; context.Chan++) {
        if (pdrsc->WrChanInfo[context.Chan].Status == CHAN_QUEUING) {
            pdrsc->WrChanInfo[context.Chan].Status = CHAN_STOPPED;
            INT_SYNC_RUN(ProtectedSetDoorBell, &context);
            wChanCnt++;
        }
    }
    /* Check all read channels to see if there is any queuing job. */
    context.Dirc = DMA_READ;
    for (context.Chan = 0; context.Chan < pdrsc->RdChans; context.Chan++) {
        if (pdrsc->RdChanInfo[context.Chan].Status == CHAN_QUEUING) {
            pdrsc->RdChanInfo[context.Chan].Status = CHAN_STOPPED;
            INT_SYNC_RUN(ProtectedSetDoorBell, &context);
            rChanCnt++;
        }
    }
    if (rChanCnt == 0 && wChanCnt == 0) {
        DTRACE("No queuing job found.\n");
        return DMA_NO_QUEUING_JOBS;
    }
    DTRACE("OK. %d read channels and %d write channels get started.\n",
            rChanCnt, wChanCnt);
    return DMA_SUCCESS;
}


/**
 * Dump DMA registers of interest.
 *
 * Thare are actually a great number of registers up there, but we only care
 * about parts of them. This function serves as a debug approach to make sure
 * all registers are configured as expected.
 *
 * @param[in] pdrsc The DMA resource object.
 * @param[in] dirc  The direction of the channel whose related registers will
 *                  be dumped.
 * @param[in] chan  The number of the channel whose related registers will be
 *                  dumped.
 * @param[out] buf  The buffer to hold register messages. Note that the buffer
 *                  must be at least MAX_MSG_SIZE bytes in size.
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Check HalDmaGetErrInfo() for more.
 *
 * @see DmaDumpReg
 */
HAL_DMA_RET HalDmaDumpReg(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan,
        char *buf) {

    DMA_SYNCRUN_CONTEXT context = {pdrsc, dirc, chan, buf};

    /* Check arguments */
    if (pdrsc == NULL || buf == NULL) {
        return DMA_NULL_ARG;
    }
    if ((dirc == DMA_WRITE && chan >= pdrsc->WrChans) || (dirc == DMA_READ
            && chan >= pdrsc->RdChans)) {
        return DMA_INVALID_CHAN;
    }

    DTRACE("Reg dump. channel=%d dirc=%d\n", chan, dirc);
    INT_SYNC_RUN(ProtectedDumpReg, &context);
    return DMA_SUCCESS;
}


/**
 * Dump the linked list elements of given channel.
 *
 * This function serves as a debug approach to make sure all linked list element
 * are configured as expected.
 *
 * @param[in] pdrsc The DMA resource object.
 * @param[in] dirc  The direction of the channel whose related linked list will
 *                  be dumped.
 * @param[in] chan  The number of the channel whose related linked list will be
 *                  dumped.
 * @param[out] buf  The buffer to hold linked list element data. Note that the
 *                  buffer must be at least MAX_MSG_SIZE bytes in size.
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Check HalDmaGetErrInfo() for more.
 *
 * @see DmaDumpLL
 */
HAL_DMA_RET HalDmaDumpLL(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan, char *buf) {

    PCHAN_INFO pChanInfo;
    PUINT32 llAddr;

    /* Check arguments */
    if (pdrsc == NULL || buf == NULL) {
        return DMA_NULL_ARG;
    }
    if ((dirc == DMA_WRITE && chan >= pdrsc->WrChans) || (dirc == DMA_READ
            && chan >= pdrsc->RdChans)) {
        return DMA_INVALID_CHAN;
    }

    pChanInfo = (dirc == DMA_WRITE) ? &pdrsc->WrChanInfo[chan]
            : &pdrsc->RdChanInfo[chan];
    llAddr = GetBaseLLVAddr(pdrsc, dirc, chan);
    if (pChanInfo->LLElements == 0) {
        DPRINTF(buf, MAX_MSG_SIZE, "No linked list available!");
        return DMA_NO_LL;
    }

    DmaDumpLL(llAddr, pChanInfo->LLElements, buf, MAX_MSG_SIZE);
    return DMA_SUCCESS;
}


/**
 * Get DMA state of given channel.
 *
 * This function tells if the channel is transferring anything and how many
 * data have been transferred, how many times the interrupt is triggerred.
 *
 * @note
 *   - Don't call this function too frequently when the channel is busy at
 *     work, since doing so will potentially harm the DMA transfer speed.
 *   - The transferred bytes and interrupt count will be kept until next
 *     transfer is requested, so those value are available even if the channel
 *     is stopped.
 *
 * @param[in] pdrsc     The DMA resource object.
 * @param[in] dirc      The direction of the channel whose state will be
 *                      fetched.
 * @param[in] chan      The number of the channel whose state will be fetched.
 * @param[out] stat     The status of the channel. See DMA_CHAN_STATUS
 *                      enumeration for possible status.
 * @param[out] err      The hardware error of the channel if any. See
 *                      DMA_ERR enumeration for possible error types.
 * @param[out] xferred  The size of data have been transferred on specified
 *                      channel. This value is cleared when the transfer get
 *                      started and it increases until the transfer is stopped.
 * @param[out] intCntDone
 *                      The Done interrupt count. HAL maintained interrupt
 *                      counters for every channel. The counters are cleared
 *                      when the transfer get started, and it will increment
 *                      each time the DMA device signals an Done interrupt.
 * @param[out] intCntAbort
 *                      The Abort interrupt count. This counter will increment
 *                      each time the DMA device signals an Abort interrupt.
 *
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Check HalDmaGetErrInfo() for more.
 */
HAL_DMA_RET HalDmaState(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan,
        DMA_CHAN_STATUS *stat, DMA_ERR *err, UINT64 *xferred,
        UINT32 *intCntDone, UINT32 *intCntAbort) {

    PCHAN_INFO pChanInfo;
    DMA_SYNCRUN_CONTEXT context;

    /* Check arguments */
    if (pdrsc == NULL) {
        return DMA_NULL_ARG;
    }
    if ((dirc == DMA_WRITE && chan >= pdrsc->WrChans) || (dirc == DMA_READ
            && chan >= pdrsc->RdChans)) {
        return DMA_INVALID_CHAN;
    }

    pChanInfo = (dirc == DMA_WRITE) ? &pdrsc->WrChanInfo[chan]
            : &pdrsc->RdChanInfo[chan];

    DTRACE("Get channel state. dirc=%d channel=%d \n", dirc, chan);

    /* Queuing is not a real HW status, so we return without quering the
     * state registers.
     */
    if (pChanInfo->Status == CHAN_QUEUING) {
        if (stat) *stat = CHAN_QUEUING;
        if (intCntDone) *intCntDone = 0;
        if (intCntAbort) *intCntAbort = 0;
        if (xferred) *xferred = 0;
        if (err) *err = DMA_ERR_NONE;
        return DMA_SUCCESS;
    }

    context.DmaRsc = pdrsc;
    context.Dirc = dirc;
    context.Chan = chan;
    context.Data = NULL;
    INT_SYNC_RUN(ProtectedGetChanState, &context);

    if (stat) *stat = pChanInfo->Status;
    if (intCntDone) *intCntDone = pChanInfo->DoneIntrCnt;
    if (intCntAbort) *intCntAbort = pChanInfo->AbortIntrCnt;
    if (err) *err = pChanInfo->Error;

    if (xferred) {
        if (pChanInfo->LLElements == 0) {
            /* For single block transfer, the transferred data size are simply
             * to subtract remaining data size from feed size .
             */
            *xferred = pChanInfo->FeedSize - pChanInfo->XferSize;
        } else {
            context.DmaRsc = pdrsc;
            context.Dirc = dirc;
		    context.Chan = chan;
		    context.Data = xferred;
            INT_SYNC_RUN(ProtectedCalcXferredSize, &context);
        }
    }

    return DMA_SUCCESS;
}

/**
 * Interrupt service routine for DMA transfer.
 *
 * This function firstly query the Interrupt Status Registers to figure out
 * which channel signals the interrupt. Then it will check the interrupt type
 * to determine what to do next.
 *
 * The DMA generates two Interrupts per Channel:
 *   - Abort Interrupt: The DMA unsuccessfully completes the transfer, or an
 *     error occurs during the transfer.
 *   - Done Interrupt: The DMA successfully completes the transfer.
 *
 * If an Abort interrupt is found, this function will choose to stop or resume
 * the DMA transfer base on the error type read from the Error Status Register.
 *
 * If an Done interrupt is found, this function will update the elements of
 * linked list when transferring in multi block mode, or simply finish the
 * transfer when transferring in single block mode.
 *
 * For whatever interrupt it found, the interrupt is cleared before exiting this
 * function.
 *
 * @note This function is intended to be a subroutine of the upper level ISR of
 * the driver. User should write their own device ISR and only call this API
 * when they are sure that the interrupt is coming from DMA channels.
 *
 * @param[in] pdrsc     The DMA resource object.
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Check HalDmaGetErrInfo() for more.
 */
HAL_DMA_RET HalDmaISR(PDMA_RSC pdrsc)
{
    UINT8 chan;
    DMA_DIRC dirc;
    DMA_INT_TYPE type;
    PCHAN_INFO pChanInfo;
    BOOLEAN hasErr;
    DMA_ERR errType;
    int ret;
    PHYADDR llHead;
    DMA_SYNCRUN_CONTEXT context;
    DMA_CHAN_STATUS dmastatus = CHAN_UNKNOWN;

    /* Check arguments */
    if (!pdrsc)
        return DMA_NULL_ARG;

    while (DmaQueryIntSrc(pdrsc->DmaRegs, &dirc, &chan, &type)) {
        BOOLEAN over = FALSE;
        pChanInfo = (dirc == DMA_WRITE) ? &pdrsc->WrChanInfo[chan]
                : &pdrsc->RdChanInfo[chan];

        context.DmaRsc = pdrsc;
        context.Dirc = dirc;
        context.Chan = chan;
        context.Data = NULL;

        /* Abort and Done interrupts are handled differently. */
        if (type == DMA_INT_ABORT) {
            pChanInfo->AbortIntrCnt++;
            /* Read error status registers to see what's the source of error. */
            hasErr = DmaQueryErrSrc(pdrsc->DmaRegs, dirc, chan,
                    &pChanInfo->Error);
            DmaClrInt(pdrsc->DmaRegs, dirc, chan, DMA_INT_ABORT);
            DmaClrInt(pdrsc->DmaRegs, dirc, chan, DMA_INT_DONE);

            if (hasErr) {
                errType = pChanInfo->Error;
                printk("Xfer on %s channel %d encounterred hardware error: %d\n",
                        dirc == DMA_WRITE ? "write" : "read", chan, errType);

                if (errType == DMA_ERR_WR || errType == DMA_ERR_RD || errType
                        == DMA_ERR_FETCH_LL) {
                    /* Fatal errors. Can't recover. Invoking callback */
                    DmaSetOp(pdrsc->DmaRegs, dirc, TRUE);       /* force reset dma while error happend */
                    over = TRUE;
                } else {
                    /* Try to request the DMA to continue processing. */
                    /*  printk("Resuming DMA transfer from non-fatal error...\n"); */
                    /*  Fixme, if the pcie is triggered by application, the LLElements is 0 also. */
                    /* if (pChanInfo->LLElements == 0) {
                        ProtectedInitSingleBlockXfer(&context);
                    } */
                    /* If this resume path is re-enabled, keep critical HW
                     * tasks under INT_SYNC_RUN.
                     */
                    /*  ProtectedSetDoorBell(&context); */

                    DmaSetOp(pdrsc->DmaRegs, dirc, TRUE);       /* force reset dma while error happend */
                    over = TRUE;
                }
            } else {
                printk("Xfer on %s channel %d aborted but no HW error found!\n",
                        dirc == DMA_WRITE ? "write" : "read", chan);
                over = TRUE;
            }

        } else {
            while(TRUE) {
                if(chan == 0) {
                    DmaGetChanStatus(pdrsc->DmaRegs, dirc, 1, &dmastatus);
                }
                else if(chan == 1) {
                    DmaGetChanStatus(pdrsc->DmaRegs, dirc, 0, &dmastatus);
                }
                else {
                    break;
                }

                if(dmastatus != CHAN_RUNNING) {
                    DTRACE("Polling double chanenel status is done\n");
                    break;
                }
            }

            pChanInfo->DoneIntrCnt++;
            DEBUG_PRINT("dirc=%d chan=%d int=%d\n", dirc, chan, pChanInfo->DoneIntrCnt);

            DmaClrInt(pdrsc->DmaRegs, dirc, chan, DMA_INT_DONE);

            if (pChanInfo->LLElements == 0) {
                over = TRUE;
            } else {
                if (pChanInfo->Recycle == 0 || pChanInfo->DoneIntrCnt < (2
                        * pChanInfo->Recycle - 1)) {
                    printk("Update linked list elements.\n");
                    ret = UpdateLLElements(pdrsc, dirc, chan);
                    if (ret == DMA_SUCCESS) {
                        INT_SYNC_RUN(ProtectedGetChanState, &context);
                        if (pChanInfo->Status == CHAN_STOPPED) {
                            printk("channel stopped, restart it...\n");
                            INT_SYNC_RUN(ProtectedSetDoorBell, &context);
                        }
                    } else {
                        printk("Failed to update elements.\n");
                        return DMA_FATAL;
                    }
                } else {
                    INT_SYNC_RUN(ProtectedGetChanState, &context);
                    llHead = GetBaseLLPAddr(pdrsc, dirc, chan);
                    if (pChanInfo->ElementPos.LowPart == llHead.LowPart) {
                        over = TRUE;
                    }
                }
            }
        }

        /* Xfer is aborted/done, invoking callback if desired */
        if (over && pdrsc->XferDoneFunc)
            pdrsc->XferDoneFunc(dirc, chan, pdrsc->XferDoneContext);
    }

    return DMA_SUCCESS;
}

/**
 * Interrupt service routine for DMA transfer.
 *
 * This function firstly query the Interrupt Status Registers to figure out
 * which channel signals the interrupt. Then it will check the interrupt type
 * to determine what to do next.
 *
 * The DMA generates two Interrupts per Channel:
 *   - Abort Interrupt: The DMA unsuccessfully completes the transfer, or an
 *     error occurs during the transfer.
 *   - Done Interrupt: The DMA successfully completes the transfer.
 *
 * If an Abort interrupt is found, this function will choose to stop or resume
 * the DMA transfer base on the error type read from the Error Status Register.
 *
 * If an Done interrupt is found, this function will update the elements of
 * linked list when transferring in multi block mode, or simply finish the
 * transfer when transferring in single block mode.
 *
 * For whatever interrupt it found, the interrupt is cleared before exiting this
 * function.
 *
 * @note This function is intended to be a subroutine of the upper level ISR of
 * the driver. User should write their own device ISR and only call this API
 * when they are sure that the interrupt is coming from DMA channels.
 *
 * @param[in] pdrsc     The DMA resource object.
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Check HalDmaGetErrInfo() for more.
 */
HAL_DMA_RET HalDmaISR2(struct rpp_dev *pdev, PDMA_RSC pdrsc, UINT8 *channel, DMA_DIRC *direction)
{
    UINT8 chan;
    DMA_DIRC dirc;
    DMA_INT_TYPE type;
    PCHAN_INFO pChanInfo;
    BOOLEAN hasErr;
    DMA_ERR errType;
    int ret;
    PHYADDR llHead;
    DMA_SYNCRUN_CONTEXT context;
    DMA_CHAN_STATUS dmastatus = CHAN_UNKNOWN;

    UINT32 i = 0;

    /* Check arguments */
    if (!pdrsc)
        return DMA_NULL_ARG;

    while (DmaQueryIntSrc(pdrsc->DmaRegs, &dirc, &chan, &type)) {
        BOOLEAN over = FALSE;
        pChanInfo = (dirc == DMA_WRITE) ? &pdrsc->WrChanInfo[chan]
                : &pdrsc->RdChanInfo[chan];

        context.DmaRsc = pdrsc;
        context.Dirc = dirc;
        context.Chan = chan;
        context.Data = NULL;

        /* Abort and Done interrupts are handled differently. */
        if (type == DMA_INT_ABORT) {
            pChanInfo->AbortIntrCnt++;
            /* Read error status registers to see what's the source of error. */
            hasErr = DmaQueryErrSrc(pdrsc->DmaRegs, dirc, chan,
                    &pChanInfo->Error);
            DmaClrInt(pdrsc->DmaRegs, dirc, chan, DMA_INT_ABORT);
            DmaClrInt(pdrsc->DmaRegs, dirc, chan, DMA_INT_DONE);

            if (hasErr) {
                errType = pChanInfo->Error;
                printk("Xfer on %s channel %d encounterred hardware error: %d\n",
                        dirc == DMA_WRITE ? "write" : "read", chan, errType);

                if (errType == DMA_ERR_WR || errType == DMA_ERR_RD || errType
                        == DMA_ERR_FETCH_LL) {
                    /* Fatal errors. Can't recover. Invoking callback */
                    DmaSetOp(pdrsc->DmaRegs, dirc, TRUE);       /* force reset dma while error happend */
                    over = TRUE;
                } else {
                    /* Try to request the DMA to continue processing. */
                    /*  printk("Resuming DMA transfer from non-fatal error...\n"); */
                    /*  Fixme, if the pcie is triggered by application, the LLElements is 0 also. */
                    /* if (pChanInfo->LLElements == 0) {
                        ProtectedInitSingleBlockXfer(&context);
                    } */
                    /* If this resume path is re-enabled, keep critical HW
                     * tasks under INT_SYNC_RUN.
                     */
                    /*  ProtectedSetDoorBell(&context); */
                    DmaSetOp(pdrsc->DmaRegs, dirc, TRUE);       /* force reset dma while error happend */
                    over = TRUE;
                }
            } else {
                printk("Xfer on %s channel %d aborted but no HW error found!\n",
                        dirc == DMA_WRITE ? "write" : "read", chan);
                over = TRUE;
            }

        } else {
            *channel = chan;
            *direction = dirc;

            /*  For multi-block dma Link */
            while (TRUE) {
                if (chan == 0) {
                    DmaGetChanStatus(pdrsc->DmaRegs, dirc, 1, &dmastatus);
                }

                if (chan == 1) {
                    DmaGetChanStatus(pdrsc->DmaRegs, dirc, 0, &dmastatus);
                }

                if (dmastatus != CHAN_RUNNING) {
                    DTRACE("Polling double chanenel status is done\n");
                    break;
                }

                i++;
                if (i > 100000) {
                    printk("Error Timeout\n");
                    return DMA_FATAL;
                }
                udelay(100);
            }

            pChanInfo->DoneIntrCnt++;
            DEBUG_PRINT("dirc=%d chan=%d int=%d\n", dirc, chan, pChanInfo->DoneIntrCnt);

            // for async PCIe DMA, kuanghl
            if (dirc == DMA_WRITE) {
                if ((chan == 0) || (chan == 1)) {
                    // 0,1 channel write(D2H)
                    // RppSetEvent(&devContext->sync_Kevents[1].Complete_Event, FALSE, 0);
                    rpp_rch0_ch1_xfer_done(pdev, NULL);
                }
                else if (chan == 2) {
                    // 2 channel write(D2H)
                    // RppSetEvent(&devContext->sync_Kevents[3].Complete_Event, FALSE, 0);
                    rpp_rch2_xfer_done(pdev, NULL);
                }
                else if (chan == 3) {
                    // 3 channel write(D2H)
                    // RppSetEvent(&devContext->sync_Kevents[5].Complete_Event, FALSE, 0);
                    rpp_rch3_xfer_done(pdev, NULL);
                }
            }

            if (dirc == DMA_READ) {
                if ((chan == 0) || (chan == 1)) {
                    // 0,1 channel read(H2D)
                    // RppSetEvent(&devContext->sync_Kevents[0].Complete_Event, FALSE, 0);
                    rpp_wch0_ch1_xfer_done(pdev, NULL);
                }
                else if (chan == 2) {
                    // 2 channel read(H2D)
                    // RppSetEvent(&devContext->sync_Kevents[2].Complete_Event, FALSE, 0);
                    rpp_wch2_xfer_done(pdev, NULL);
                }
                else if (chan == 3) {
                    // 3 channel read(H2D)
                    // RppSetEvent(&devContext->sync_Kevents[4].Complete_Event, FALSE, 0);
                    rpp_wch3_xfer_done(pdev, NULL);
                }
            }
            
            rpp_dev_semaphore_post(pdev);

            DmaClrInt(pdrsc->DmaRegs, dirc, chan, DMA_INT_DONE);

            if (pChanInfo->LLElements == 0) {
                over = TRUE;
            } else {
                if (pChanInfo->Recycle == 0 || pChanInfo->DoneIntrCnt < (2
                        * pChanInfo->Recycle - 1)) {
                    printk("Update linked list elements.\n");
                    ret = UpdateLLElements(pdrsc, dirc, chan);
                    if (ret == DMA_SUCCESS) {
                        INT_SYNC_RUN(ProtectedGetChanState, &context);
                        if (pChanInfo->Status == CHAN_STOPPED) {
                            printk("channel stopped, restart it...\n");
                            INT_SYNC_RUN(ProtectedSetDoorBell, &context);
                        }
                    } else {
                        printk("Failed to update elements.\n");
                        return DMA_FATAL;
                    }
                } else {
                    INT_SYNC_RUN(ProtectedGetChanState, &context);
                    llHead = GetBaseLLPAddr(pdrsc, dirc, chan);
                    if (pChanInfo->ElementPos.LowPart == llHead.LowPart) {
                        over = TRUE;
                    }
                }
            }
        }

        /* Xfer is aborted/done, invoking callback if desired */
        if (over && pdrsc->XferDoneFunc)
            pdrsc->XferDoneFunc(dirc, chan, pdrsc->XferDoneContext);
    }

    return DMA_SUCCESS;
}

/**
 * Get detailed error information of given code.
 *
 * If the HAL APIs return unseccessful code, there might be dozens of cause
 * for the error. This function call tell the user the exact cause of given
 * code.
 *
 * @param[in] code  The error code
 * @return A string containing explaination of the error code.
 */
char * HalDmaGetErrInfo(HAL_DMA_RET code) {
    if (code < DMA_SUCCESS || code >= DMA_ERR_CODE_NUM)
        return "Invalid Error Code";

    if (gErrInfo[0] == 0)
        InitErrInfo();

    return gErrInfo[code];
}

/*******************************************************************************
 *
 * STATIC FUNCTION DEFINITIONS
 *
 ******************************************************************************/
/**
 * Start a single block DMA read or write on given channel. This is the worker
 * function for external single block read/write APIs.
 *
 * @param[in] pdrsc The DMA resource object.
 * @param[in] dirc  The direction of the channel. Setting this to specify if
 *                  you want to use Read or Write.
 * @param[in] chan  The write channel on which the transfer is performed. The
 *                  channel must be an available channel. User can get the
 *                  number of available DAM channels from DMA_RSC object after
 *                  calling HalDmaInit().
 * @param[in] src   The source physical address of the block of data need to be
 *                  transferred. This address must locate in system memory, and
 *                  it must be DWORD aligned.
 * @param[in] dst   The destination physical address where the data will be
 *                  transferred to. This address must locate in local RAM, and
 *                  it must be DWORD aligned.
 * @param[in] size  The transfer size of the data. One DMA block can hold data
 *                  with the size of 1 byte to 4 G bytes.
 * @param[in] wei   The weight of the channel. The value is used by the channel
 *                  weighted round robin arbiter to select the next channel
 *                  write request.
 * @param[in] queue Queue up the request or not. If set this argument to true,
 *                  the DMA transfer will not get started by this function, and
 *                  only related registers are initialzied. So, user should call
 *                  HalDmaFlushQueue() later to really start the transfer.
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Check HalDmaGetErrInfo() for more.
 *
 * @see MultiBlockRW
 */
static HAL_DMA_RET SingleBlockRW(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan,
        PHYADDR src, PHYADDR dst, UINT32 size, UINT8 wei, BOOLEAN queue) {

    DMA_SYNCRUN_CONTEXT context;
    PCHAN_INFO pChanInfo;

    /* Check arguments */
    if (pdrsc == NULL) {
        return DMA_NULL_ARG;
    }
    if ((dirc == DMA_WRITE && chan >= pdrsc->WrChans) || (dirc == DMA_READ
            && chan >= pdrsc->RdChans)) {
        return DMA_INVALID_CHAN;
    }
    if (size < MIN_BLOCK_SIZE || size > MAX_BLOCK_SIZE) {
        return DMA_INVALID_BLOCK_SIZE;
    }
    if (wei < MIN_WEIGHT || wei > MAX_WEIGHT) {
        return DMA_INVALID_WEIGHT;
    }

    /* Check the status of the channel to make sure it's not running. Otherwise
     * we can't start new transfer on this channel.
     */
    context.DmaRsc = pdrsc;
    context.Dirc = dirc;
    context.Chan = chan;
    context.Data = NULL;
    INT_SYNC_RUN(ProtectedGetChanState, &context);

    pChanInfo = (dirc == DMA_WRITE) ? &pdrsc->WrChanInfo[chan]
            : &pdrsc->RdChanInfo[chan];
    if (pChanInfo->Status == CHAN_RUNNING) {
        return DMA_CHAN_BUSY;
    }
    DTRACE("DMA R/W. dirc=%d channel=%d size=%d\n", dirc, chan, size);

    /* Reset/init channel info */
    pChanInfo->FeedSize = size;
    pChanInfo->SrcPos = src;
    pChanInfo->DstPos = dst;
    pChanInfo->Weight = wei;
    pChanInfo->LLElements = 0;
    pChanInfo->DoneIntrCnt = 0;
    pChanInfo->AbortIntrCnt = 0;
    pChanInfo->Error = DMA_ERR_NONE;

	DTRACE("%s: SrcPos=0x%llx, DstPos=0x%llx, FeedSize=0x%x\n",
		__func__, pChanInfo->SrcPos.QuadPart, pChanInfo->DstPos.QuadPart, pChanInfo->FeedSize);

    /* Configure the context registers for single block transfer. */
    INT_SYNC_RUN(ProtectedInitSingleBlockXfer, &context);

    /* Set Doorbell register when neccessary */
    if (queue) {
        pChanInfo->Status = CHAN_QUEUING;
    } else {
        INT_SYNC_RUN(ProtectedSetDoorBell, &context);
    }
    return DMA_SUCCESS;
}

/**
 * Start DMA multi block read or write operation. This is the worker function
 * for external multi block read/write APIs.
 *
 * @param[in] pdrsc The DMA resource object.
 * @param[in] dirc  The direction of the channel. Setting this to specify if
 *                  you want to use Read or Write.
 * @param[in] chan  The write channel on which the transfer is performed. The
 *                  channel must be an available channel. User can get the
 *                  number of available DAM channels from DMA_RSC object after
 *                  calling HalDmaInit().
 * @param[in] lle   The number of elements in linked list descriptor. It
 *                  includes the number of data elements and link element.
 * @param[in] wm    The index of watermark element. Typically a "Watermark"
 *                  interrupt is positioned near the middle of the transfer
 *                  list, and the element's LIE bit is set to 1'b1.
 * @param[in] recyc Specify how many times to recylce the linked list. If 0 is
 *                  given, the recycling will last forever. User can call
 *                  HalDmaAbort() to terminate the transfer.
 * @param[in] wei   The weight of the channel. The value is used by the channel
 *                  weighted round robin arbiter to select the next channel
 *                  write request.
 * @param[in] queue Queue up the request or not. If set this argument to true,
 *                  the DMA transfer will not get started by this function, and
 *                  only related registers are initialzied. So, user should call
 *                  HalDmaFlushQueue() later to really start the transfer.
 * @param[in] func  The linked list data producer callback function, used by
 *                  HAL to fetch source, destination and transfer size of next
 *                  element. See PRODUCER_FUNC() for more details.
 * @param[in] ctx   The context for producer function.
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Check HalDmaGetErrInfo() for more.
 *
 * @see HalDmaGetErrInfo
 * @see SingleBlockRW
 */
static HAL_DMA_RET MultiBlockRW(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan,
        UINT32 lle, UINT8 wm, UINT32 recyc, UINT8 wei, BOOLEAN queue,
        PRODUCER_FUNC func, PVOID ctx) {

    DMA_SYNCRUN_CONTEXT context;
    PCHAN_INFO pChanInfo;
    HAL_DMA_RET ret;

    /* Check arguments */
    if (pdrsc == NULL || func == NULL) {
        return DMA_NULL_ARG;
    }
    if ((dirc == DMA_WRITE && chan >= pdrsc->WrChans) || (dirc == DMA_READ
            && chan >= pdrsc->RdChans)) {
        return DMA_INVALID_CHAN;
    }
    /* if (lle > MAX_LLELEMENT_NUM || lle < MIN_LLELEMENT_NUM) {
        return DMA_INVALID_LL_LEN;
    }
    if (wm < 1 || wm > lle - 4) {
        return DMA_INVALID_WM;
    } */
    if (wei < MIN_WEIGHT || wei > MAX_WEIGHT) {
        return DMA_INVALID_WEIGHT;
    }

    /* Check the status of the channel to make sure it's not running. Otherwise
     * we can't start new transfer on this channel.
     */
    context.DmaRsc = pdrsc;
    context.Dirc = dirc;
    context.Chan = chan;
    context.Data = NULL;
    INT_SYNC_RUN(ProtectedGetChanState, &context);

    pChanInfo = (dirc == DMA_WRITE) ? &pdrsc->WrChanInfo[chan]
            : &pdrsc->RdChanInfo[chan];
    if (pChanInfo->Status == CHAN_RUNNING) {
        return DMA_CHAN_BUSY;
    }
    DTRACE("DMA R/W. dirc=%d channel=%d recyc=%d\n", dirc, chan, recyc);

    /* Reset/init channel info */
    pChanInfo->FeedSize = 0;
    pChanInfo->LLElements = lle;
    pChanInfo->WaterMark = wm;
    pChanInfo->Recycle = recyc;
    pChanInfo->Weight = wei;
    pChanInfo->ProducerFunc = func;
    pChanInfo->ProducerContext = ctx;
    pChanInfo->PCS = 1;
    pChanInfo->ElementIdx = 0;
    pChanInfo->SrcPos.LowPart = 0;
    pChanInfo->SrcPos.HighPart = 0;
    pChanInfo->DstPos.LowPart = 0;
    pChanInfo->DstPos.HighPart = 0;
    pChanInfo->DoneIntrCnt = 0;
    pChanInfo->AbortIntrCnt = 0;
    pChanInfo->Error = DMA_ERR_NONE;

	DTRACE("pChanInfo->FeedSize = 0x%llx\n", pChanInfo->FeedSize);
	DTRACE("pChanInfo->LLElements = 0x%x\n", pChanInfo->LLElements);
	DTRACE("pChanInfo->WaterMark = 0x%x\n", pChanInfo->WaterMark);
	DTRACE("pChanInfo->Recycle = 0x%x\n", pChanInfo->Recycle);
	DTRACE("pChanInfo->Weight = 0x%x\n", pChanInfo->Weight);

    /* Initialize the elements of the linked list */
    ret = UpdateLLElements(pdrsc, dirc, chan);
    if (ret != DMA_SUCCESS)
        return ret;

    /* Configure the context registers for multi block transfer. */
    INT_SYNC_RUN(ProtectedInitMultiBlockXfer, &context);

    /* Set Doorbell register when neccessary */
    if (queue) {
        pChanInfo->Status = CHAN_QUEUING;
    } else {
        INT_SYNC_RUN(ProtectedSetDoorBell, &context);
    }
    return DMA_SUCCESS;
}

/**
 * Start DMA multi block read or write operation. This is the worker function
 * for external multi block read/write APIs.
 *
 * @param[in] pdrsc The DMA resource object.
 * @param[in] dirc  The direction of the channel. Setting this to specify if
 *                  you want to use Read or Write.
 * @param[in] chan  The write channel on which the transfer is performed. The
 *                  channel must be an available channel. User can get the
 *                  number of available DAM channels from DMA_RSC object after
 *                  calling HalDmaInit().
 * @param[in] lle   The number of elements in linked list descriptor. It
 *                  includes the number of data elements and link element.
 * @param[in] wm    The index of watermark element. Typically a "Watermark"
 *                  interrupt is positioned near the middle of the transfer
 *                  list, and the element's LIE bit is set to 1'b1.
 * @param[in] recyc Specify how many times to recylce the linked list. If 0 is
 *                  given, the recycling will last forever. User can call
 *                  HalDmaAbort() to terminate the transfer.
 * @param[in] wei   The weight of the channel. The value is used by the channel
 *                  weighted round robin arbiter to select the next channel
 *                  write request.
 * @param[in] queue Queue up the request or not. If set this argument to true,
 *                  the DMA transfer will not get started by this function, and
 *                  only related registers are initialzied. So, user should call
 *                  HalDmaFlushQueue() later to really start the transfer.
 * @param[in] func  The linked list data producer callback function, used by
 *                  HAL to fetch source, destination and transfer size of next
 *                  element. See PRODUCER_FUNC() for more details.
 * @param[in] ctx   The context for producer function.
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Check HalDmaGetErrInfo() for more.
 *
 * @see HalDmaGetErrInfo
 * @see SingleBlockRW
 */
static HAL_DMA_RET MultiBlockRW2(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 ping, UINT8 pong,
        UINT32 lle, UINT8 wm, UINT32 recyc, UINT8 wei, BOOLEAN queue,
        PRODUCER_CB func, PVOID ctx) {

    DMA_SYNCRUN_CONTEXT context;
    PCHAN_INFO pChanInfo_ping;
    PCHAN_INFO pChanInfo_pong;
    PUINT32 llvaddr_ping = GetBaseLLVAddr(pdrsc, dirc, ping);
    PUINT32 llvaddr_pong = GetBaseLLVAddr(pdrsc, dirc, pong);
    HAL_DMA_RET ret;

    BOOLEAN isInit = 0;
    PHYADDR src, dst;
    src.QuadPart = 0;
    dst.QuadPart = 0;
    UINT32 xferSize = 0;
    UINT64 offset = 0;
    UINT64 index = 0;
    UINT8 pcs = 1;
    UINT32 i = 0;
    BOOLEAN isWmEle, isLastDataEle, isPing = TRUE;
    UINT32 ping_index = 0, pong_index = 0;

    /* Check arguments */
    if (pdrsc == NULL || func == NULL) {
        return DMA_NULL_ARG;
    }
    if ((dirc == DMA_WRITE && ping >= pdrsc->WrChans) || (dirc == DMA_READ
            && ping >= pdrsc->RdChans)) {
        return DMA_INVALID_CHAN;
    }
    if ((dirc == DMA_WRITE && pong >= pdrsc->WrChans) || (dirc == DMA_READ
            && pong >= pdrsc->RdChans)) {
        return DMA_INVALID_CHAN;
    }
    /* if (lle > MAX_LLELEMENT_NUM || lle < MIN_LLELEMENT_NUM) {
        return DMA_INVALID_LL_LEN;
    }
    if (wm < 1 || wm > lle - 4) {
        return DMA_INVALID_WM;
    } */
    if (wei < MIN_WEIGHT || wei > MAX_WEIGHT) {
        return DMA_INVALID_WEIGHT;
    }

    /* Check the status of the channel to make sure it's not running. Otherwise
     * we can't start new transfer on this channel.
     */
    context.DmaRsc = pdrsc;
    context.Dirc = dirc;
    context.Chan = ping;
    context.Data = NULL;
    INT_SYNC_RUN(ProtectedGetChanState, &context);

    pChanInfo_ping = (dirc == DMA_WRITE) ? &pdrsc->WrChanInfo[ping]
            : &pdrsc->RdChanInfo[ping];
    if (pChanInfo_ping->Status == CHAN_RUNNING) {
        return DMA_CHAN_BUSY;
    }

    /* Check the status of the channel to make sure it's not running. Otherwise
     * we can't start new transfer on this channel.
     */
    context.DmaRsc = pdrsc;
    context.Dirc = dirc;
    context.Chan = pong;
    context.Data = NULL;
    INT_SYNC_RUN(ProtectedGetChanState, &context);

    pChanInfo_pong = (dirc == DMA_WRITE) ? &pdrsc->WrChanInfo[pong]
            : &pdrsc->RdChanInfo[pong];
    if (pChanInfo_pong->Status == CHAN_RUNNING) {
        return DMA_CHAN_BUSY;
    }
    DTRACE("DMA R/W. dirc=%d pong channel=%d pong channel=%d recyc=%d\n", dirc, ping, pong, recyc);

    /*  DMA Link list Describe create */
    while (TRUE) {
        if(!func(&src, &dst, &xferSize, dirc, &index, &offset, ctx)) {
            ERROR_PRINT("!!! index may overflow, No DATA\n");
            return DMA_FATAL;
        }
        if (wm != 0)
        	isWmEle = (i == wm);
		else
			isWmEle = 0;
        isLastDataEle = (i == lle - 2);  /*  lle = number of data elements + Link list Elements */

		/*  DTRACE("src=0x%llx, dst=0x%llx, xferSize=0x%x, pChanInfo->ElementIdx=0x%x\n", */
		/*  	src.QuadPart, dst.QuadPart, xferSize, i); */
		/*  DTRACE("isLastDataEle=0x%x, lle=0x%x\n", isLastDataEle, lle); */

        if(isPing){
            if(ping_index == 0) {
                DmaSetDataEle(llvaddr_ping, ping_index, !pcs, (isWmEle || isLastDataEle), xferSize, src, dst);
            }
            else {
                DmaSetDataEle(llvaddr_ping, ping_index, pcs, (isWmEle || isLastDataEle), xferSize, src, dst);
            }
            ping_index++;
        }
        else {
            if(pong_index == 0) {
                DmaSetDataEle(llvaddr_pong, pong_index, !pcs, (isWmEle || isLastDataEle), xferSize, src, dst);
            }
            else {
                DmaSetDataEle(llvaddr_pong, pong_index, pcs, (isWmEle || isLastDataEle), xferSize, src, dst);
            }
            pong_index++;
        }

        if (isLastDataEle || (!isInit && isWmEle))
            break;

        isPing = !isPing;
        i++;
    }

    /* Set the link element in recycling manner */
    if(isLastDataEle) {
        DmaSetLinkEle(llvaddr_ping, ping_index, !pcs, GetBaseLLPAddr(pdrsc, dirc, ping), FALSE);
        ping_index++;

        if(pong_index != 0) {
            DmaSetLinkEle(llvaddr_pong, pong_index, !pcs, GetBaseLLPAddr(pdrsc, dirc, pong), FALSE);
            pong_index++;
        }

        /* Now flip the pcs of the first element */
        index = 0;
        offset = 0;
        if(!func(&src, &dst, &xferSize, dirc, &index, &offset, ctx)) {
            ERROR_PRINT("!!! index may overflow, No DATA\n");
            return DMA_FATAL;
        }

        /* only two Elements need set MSI interrupt */
        if ((ping_index != pong_index) && (ping_index == 2)) {
            DmaSetDataEle(llvaddr_ping, 0, pcs, TRUE, xferSize, src, dst);
        } else {
            DmaSetDataEle(llvaddr_ping, 0, pcs, FALSE, xferSize, src, dst);
        }

        if(pong_index != 0) {
            /* Now flip the pcs of the first element */
            if(!func(&src, &dst, &xferSize, dirc, &index, &offset, ctx)) {
                ERROR_PRINT("!!! index may overflow, No DATA\n");
                return DMA_FATAL;
            }

            /* only two Elements need set MSI interrupt */
            if ((ping_index == pong_index) && (pong_index == 2)) {
                DmaSetDataEle(llvaddr_pong, 0, pcs, TRUE, xferSize, src, dst);
            } else {
                DmaSetDataEle(llvaddr_pong, 0, pcs, FALSE, xferSize, src, dst);
            }
        }
    }

    /* Configure the context registers for multi block transfer. */
    context.DmaRsc = pdrsc;
    context.Dirc = dirc;
    context.Chan = ping;
    context.Data = NULL;
    INT_SYNC_RUN(ProtectedInitMultiBlockXfer, &context);

    /* Configure the context registers for multi block transfer. */
    context.DmaRsc = pdrsc;
    context.Dirc = dirc;
    context.Chan = pong;
    context.Data = NULL;
    INT_SYNC_RUN(ProtectedInitMultiBlockXfer, &context);

    /* Set Doorbell register when neccessary */
    if (queue) {
        pChanInfo_ping->Status = CHAN_QUEUING;
    } else {
        context.DmaRsc = pdrsc;
        context.Dirc = dirc;
        context.Chan = ping;
        context.Data = NULL;
        INT_SYNC_RUN(ProtectedSetDoorBell, &context);
    }

    /* Set Doorbell register when neccessary */
    if (queue) {
        pChanInfo_pong->Status = CHAN_QUEUING;
    } else {
        context.DmaRsc = pdrsc;
        context.Dirc = dirc;
        context.Chan = pong;
        context.Data = NULL;
        INT_SYNC_RUN(ProtectedSetDoorBell, &context);
    }

    return DMA_SUCCESS;
}

/**
 * Start DMA multi block read or write operation. This is the worker function
 * for external multi block read/write APIs.
 *
 * @param[in] pdrsc The DMA resource object.
 * @param[in] dirc  The direction of the channel. Setting this to specify if
 *                  you want to use Read or Write.
 * @param[in] chan  The write channel on which the transfer is performed. The
 *                  channel must be an available channel. User can get the
 *                  number of available DAM channels from DMA_RSC object after
 *                  calling HalDmaInit().
 * @param[in] lle   The number of elements in linked list descriptor. It
 *                  includes the number of data elements and link element.
 * @param[in] wm    The index of watermark element. Typically a "Watermark"
 *                  interrupt is positioned near the middle of the transfer
 *                  list, and the element's LIE bit is set to 1'b1.
 * @param[in] recyc Specify how many times to recylce the linked list. If 0 is
 *                  given, the recycling will last forever. User can call
 *                  HalDmaAbort() to terminate the transfer.
 * @param[in] wei   The weight of the channel. The value is used by the channel
 *                  weighted round robin arbiter to select the next channel
 *                  write request.
 * @param[in] queue Queue up the request or not. If set this argument to true,
 *                  the DMA transfer will not get started by this function, and
 *                  only related registers are initialzied. So, user should call
 *                  HalDmaFlushQueue() later to really start the transfer.
 * @param[in] func  The linked list data producer callback function, used by
 *                  HAL to fetch source, destination and transfer size of next
 *                  element. See PRODUCER_FUNC() for more details.
 * @param[in] ctx   The context for producer function.
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Check HalDmaGetErrInfo() for more.
 *
 * @see HalDmaGetErrInfo
 * @see SingleBlockRW
 */
static HAL_DMA_RET MultiBlockRW2_1(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan,
        UINT32 lle, UINT8 wm, UINT32 recyc, UINT8 wei, BOOLEAN queue,
        PRODUCER_CB func, PVOID ctx) {

    DMA_SYNCRUN_CONTEXT context;
    PCHAN_INFO pChanInfo_chan;
    PUINT32 llvaddr_chan = GetBaseLLVAddr(pdrsc, dirc, chan);
    HAL_DMA_RET ret;

    BOOLEAN isInit = 0;
    PHYADDR src, dst;
    src.QuadPart = 0;
    dst.QuadPart = 0;
    UINT32 xferSize = 0;
    UINT64 offset = 0;
    UINT64 index = 0;
    UINT8 pcs = 1;
    UINT32 i = 0;
    BOOLEAN isWmEle, isLastDataEle;
    UINT32 chan_index = 0;

    /* Check arguments */
    if (pdrsc == NULL || func == NULL) {
        return DMA_NULL_ARG;
    }
    if ((dirc == DMA_WRITE && chan >= pdrsc->WrChans) || (dirc == DMA_READ
            && chan >= pdrsc->RdChans)) {
        return DMA_INVALID_CHAN;
    }
    /* if (lle > MAX_LLELEMENT_NUM || lle < MIN_LLELEMENT_NUM) {
        return DMA_INVALID_LL_LEN;
    }
    if (wm < 1 || wm > lle - 4) {
        return DMA_INVALID_WM;
    } */
    if (wei < MIN_WEIGHT || wei > MAX_WEIGHT) {
        return DMA_INVALID_WEIGHT;
    }

    /* Check the status of the channel to make sure it's not running. Otherwise
     * we can't start new transfer on this channel.
     */
    context.DmaRsc = pdrsc;
    context.Dirc = dirc;
    context.Chan = chan;
    context.Data = NULL;
    INT_SYNC_RUN(ProtectedGetChanState, &context);

    pChanInfo_chan = (dirc == DMA_WRITE) ? &pdrsc->WrChanInfo[chan]
            : &pdrsc->RdChanInfo[chan];
    if (pChanInfo_chan->Status == CHAN_RUNNING) {
        return DMA_CHAN_BUSY;
    }
    DTRACE("DMA R/W. dirc=%d channel=%d recyc=%d\n", dirc, chan, recyc);

    // DMA Link list Describe create
    while (TRUE) {
        if(!func(&src, &dst, &xferSize, dirc, &index, &offset, ctx)) {
            ERROR_PRINT("!!! index may overflow, No DATA\n");
            return DMA_FATAL;
        }
        if (wm != 0)
        	isWmEle = (i == wm);
		else
			isWmEle = 0;
        isLastDataEle = (i == lle - 2);  // lle = number of data elements + Link list Elements

		// DTRACE("src=0x%llx, dst=0x%llx, xferSize=0x%x, pChanInfo->ElementIdx=0x%x\n",
		// 	src.QuadPart, dst.QuadPart, xferSize, i);
		// DTRACE("isLastDataEle=0x%x, lle=0x%x\n", isLastDataEle, lle);

        if(chan_index == 0) {
            DmaSetDataEle(llvaddr_chan, chan_index, !pcs, (isWmEle || isLastDataEle), xferSize, src, dst);
        }
        else {
            DmaSetDataEle(llvaddr_chan, chan_index, pcs, (isWmEle || isLastDataEle), xferSize, src, dst);
        }
        chan_index++;

        if (isLastDataEle || (!isInit && isWmEle))
            break;

        i++;
    }

    /* Set the link element in recycling manner */
    if(isLastDataEle) {
        DmaSetLinkEle(llvaddr_chan, chan_index, !pcs, GetBaseLLPAddr(pdrsc, dirc, chan), FALSE);
        chan_index++;

        /* Now flip the pcs of the first element */
        index = 0;
        offset = 0;
        if(!func(&src, &dst, &xferSize, dirc, &index, &offset, ctx)) {
            ERROR_PRINT("!!! index may overflow, No DATA\n");
            return DMA_FATAL;
        }

        /* only two Elements need set MSI interrupt */
        DmaSetDataEle(llvaddr_chan, 0, pcs, TRUE, xferSize, src, dst);
    }

    /* Configure the context registers for multi block transfer. */
    context.DmaRsc = pdrsc;
    context.Dirc = dirc;
    context.Chan = chan;
    context.Data = NULL;
    INT_SYNC_RUN(ProtectedInitMultiBlockXfer, &context);

    /* Set Doorbell register when neccessary */
    if (queue) {
        pChanInfo_chan->Status = CHAN_QUEUING;
    } else {
        context.DmaRsc = pdrsc;
        context.Dirc = dirc;
        context.Chan = chan;
        context.Data = NULL;
        INT_SYNC_RUN(ProtectedSetDoorBell, &context);
    }

    return DMA_SUCCESS;
}

/**
 * Get the virtual address of linked list for given channel.
 *
 * The linked list is managed completely by HAL. This can simplify the use
 * of multi block transfer. There are exclusive spaces scattered in local
 * RAM being utilized as linked list descriptor storage. This function is
 * responsible for telling the starting virtual address of the linked list of
 * each channel.
 *
 * Generally speaking, the virtual address is used by software to read or
 * write to the linked list.
 *
 * @param[in] pdrsc The DMA resource object.
 * @param[in] dirc  The direction of the channel.
 * @param[in] chan  The number of the channel.
 * @return the virtual address of the linked list.
 */
static PUINT32 GetBaseLLVAddr(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan) {
    if (dirc == DMA_READ)
        chan += 4; /*  4 for read, 4 for write */

    return pdrsc->LLVirAddr[chan];
}

/**
 * Get the physical address of linked list for given channel.
 *
 * The linked list is managed completely by HAL. This can simplify the use
 * of multi block transfer. There are exclusive spaces scattered in local
 * RAM being utilized as linked list descriptor storage. This function is
 * responsible for telling the starting physical address of the linked list of
 * each channel.
 *
 * Generally speaking, the physical address is used by hardware to read or
 * write to the linked list.
 *
 * @param[in] pdrsc The DMA resource object.
 * @param[in] dirc  The direction of the channel.
 * @param[in] chan  The number of the channel.
 * @return the physical address of the linked list.
 */
static PHYADDR GetBaseLLPAddr(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan) {
    if (dirc == DMA_READ)
        chan += 4; /*  4 for read, 4 for write */

    return pdrsc->LLPhyAddr[chan];
}

/**
 * Start DMA transfer.
 *
 * It's a wrapper around DmaSetDoorBell. This function should be called as
 * protected code where no other thread or HW interrupt can break it.
 *
 * @param[in] context   The arguments wrapper.
 * @see DmaSetDoorBell
 */
static void ProtectedSetDoorBell(PDMA_SYNCRUN_CONTEXT context) {
    PDMA_RSC pdrsc = context->DmaRsc;
    DMA_DIRC dirc = context->Dirc;
    UINT8 chan = context->Chan;
    DmaSetDoorBell(pdrsc->DmaRegs, dirc, chan, FALSE);
}

/**
 * Abort DMA transfer.
 *
 * It's a wrapper around DmaSetDoorBell. This function should be called as
 * protected code where no other thread or HW interrupt can break it.
 *
 * @param[in] context   The arguments wrapper.
 * @see DmaSetDoorBell
 */
static void ProtectedAbortXfer(PDMA_SYNCRUN_CONTEXT context) {
    PDMA_RSC pdrsc = context->DmaRsc;
    DMA_DIRC dirc = context->Dirc;
    UINT8 chan = context->Chan;
    DmaSetDoorBell(pdrsc->DmaRegs, dirc, chan, TRUE);
}

/**
 * Prepare registers for single block transfer.
 *
 * This function should be called as protected code where no other thread or
 * HW interrupt can break it.
 *
 * @param[in] context   The arguments wrapper.
 *
 * @see DmaSetOp
 * @see DmaSetCtrl
 * @see DmaSetXferSize
 * @see DmaSetSrc
 * @see DmaSetDst
 * @see DmaSetWei
 */
static void ProtectedInitSingleBlockXfer(PDMA_SYNCRUN_CONTEXT context) {
    PDMA_RSC pdrsc = context->DmaRsc;
    DMA_DIRC dirc = context->Dirc;
    UINT8 chan = context->Chan;
    PCHAN_INFO pChanInfo = (dirc == DMA_WRITE) ? &pdrsc->WrChanInfo[chan]
            : &pdrsc->RdChanInfo[chan];
    UINT32 blkSize = (UINT32)pChanInfo->FeedSize;
    PHYADDR src = pChanInfo->SrcPos;
    PHYADDR dst = pChanInfo->DstPos;
    UINT8 wei = pChanInfo->Weight;
    DTRACE("SingleBlock: src.lo=0x%08x, dst.lo=0x%08x", src.LowPart, dst.LowPart);

    DmaSetOp(pdrsc->DmaRegs, dirc, TRUE);
    DmaSetCtrl(pdrsc->DmaRegs, dirc, chan, DMA_SINGLE_BLOCK);
    DmaSetXferSize(pdrsc->DmaRegs, dirc, chan, blkSize);
    DmaSetSrc(pdrsc->DmaRegs, dirc, chan, src);
    DmaSetDst(pdrsc->DmaRegs, dirc, chan, dst);
    DmaSetWei(pdrsc->DmaRegs, dirc, chan, wei);
}

/**
 * Prepare registers for multi block transfer.
 *
 * This function should be called as protected code where no other thread or
 * HW interrupt can break it.
 *
 * @param[in] context   The arguments wrapper.
 *
 *
 * @see DmaSetOp
 * @see DmaSetLLIntErr
 * @see DmaSetCtrl
 * @see DmaSetLL
 * @see DmaSetWei
 */
static void ProtectedInitMultiBlockXfer(PDMA_SYNCRUN_CONTEXT context) {
    PDMA_RSC pdrsc = context->DmaRsc;
    DMA_DIRC dirc = context->Dirc;
    UINT8 chan = context->Chan;
    PCHAN_INFO pChanInfo = (dirc == DMA_WRITE) ? &pdrsc->WrChanInfo[chan]
            : &pdrsc->RdChanInfo[chan];
    PHYADDR llpaddr = GetBaseLLPAddr(pdrsc, dirc, chan);
    UINT8 wei = pChanInfo->Weight;

    DmaSetOp(pdrsc->DmaRegs, dirc, TRUE);
    DmaSetLLIntErr(pdrsc->DmaRegs, dirc, chan, TRUE, TRUE);
    DmaSetLLIntErr(pdrsc->DmaRegs, dirc, chan, FALSE, TRUE);
    DmaSetCtrl(pdrsc->DmaRegs, dirc, chan, DMA_MULTI_BLOCK);
    DmaSetLL(pdrsc->DmaRegs, dirc, chan, llpaddr);
    DmaSetWei(pdrsc->DmaRegs, dirc, chan, wei);

	DTRACE("%s, llpaddr=0x%llx, llpaddr.LowPart=0x%x, llpaddr.HighPart=0x%x, wei=0x%x\n",
		__func__, llpaddr.QuadPart, llpaddr.LowPart, llpaddr.HighPart, wei);
}

/**
 * Get the state of give channel.
 *
 * This function should be called as protected code where no other thread or
 * HW interrupt can break it.
 *
 * @param[in] context   The arguments wrapper.
 *
 * @see DmaGetChanStatus
 * @see DmaGetXferSize
 * @see DmaGetElementPtr
 */
static void ProtectedGetChanState(PDMA_SYNCRUN_CONTEXT context) {
    PDMA_RSC pdrsc = context->DmaRsc;
    DMA_DIRC dirc = context->Dirc;
    UINT8 chan = context->Chan;
    PCHAN_INFO pChanInfo = (dirc == DMA_WRITE) ? &pdrsc->WrChanInfo[chan]
            : &pdrsc->RdChanInfo[chan];


    DmaGetChanStatus(pdrsc->DmaRegs, dirc, chan, &pChanInfo->Status);
    DmaGetXferSize(pdrsc->DmaRegs, dirc, chan, &pChanInfo->XferSize);
    DmaGetElementPtr(pdrsc->DmaRegs, dirc, chan, &pChanInfo->ElementPos);

    if (context->Chan == 0) {
        chan = 1;
        pChanInfo = (dirc == DMA_WRITE) ? &pdrsc->WrChanInfo[chan]
            : &pdrsc->RdChanInfo[chan];
        DmaGetChanStatus(pdrsc->DmaRegs, dirc, chan, &pChanInfo->Status);
        DmaGetXferSize(pdrsc->DmaRegs, dirc, chan, &pChanInfo->XferSize);
        DmaGetElementPtr(pdrsc->DmaRegs, dirc, chan, &pChanInfo->ElementPos);
    }

    if (context->Chan == 1) {
        chan = 0;
        pChanInfo = (dirc == DMA_WRITE) ? &pdrsc->WrChanInfo[chan]
            : &pdrsc->RdChanInfo[chan];
        DmaGetChanStatus(pdrsc->DmaRegs, dirc, chan, &pChanInfo->Status);
        DmaGetXferSize(pdrsc->DmaRegs, dirc, chan, &pChanInfo->XferSize);
        DmaGetElementPtr(pdrsc->DmaRegs, dirc, chan, &pChanInfo->ElementPos);
    }
}


/**
 * Get the size of transferred data of give channel.
 *
 * This function should be called as protected code where no other thread or
 * HW interrupt can break it.
 *
 * @param[in] context   The arguments wrapper.
 *
 * @see DmaGetDataEle
 */
static void ProtectedCalcXferredSize(PDMA_SYNCRUN_CONTEXT context)  {
    PDMA_RSC pdrsc = context->DmaRsc;
    DMA_DIRC dirc = context->Dirc;
    UINT8 chan = context->Chan;
    UINT64 *xferred = (PUINT64)context->Data;

    PCHAN_INFO pChanInfo = (dirc == DMA_WRITE) ? &pdrsc->WrChanInfo[chan]
            : &pdrsc->RdChanInfo[chan];

    PHYADDR llpaddr = GetBaseLLPAddr(pdrsc, dirc, chan);
    PUINT32 llvaddr = GetBaseLLVAddr(pdrsc, dirc, chan);
    UINT32 cidx = (pChanInfo->DoneIntrCnt >= (pChanInfo->Recycle * 2 - 1)
            && pChanInfo->ElementPos.LowPart == llpaddr.LowPart)
            ? pChanInfo->LLElements - 2
            : (pChanInfo->ElementPos.LowPart - llpaddr.LowPart) / 6;

    UINT32 i = pChanInfo->LLElements - 2;
    *xferred = pChanInfo->FeedSize;

    DTRACE("i=%d, cidx=%d, ep=0x%x, bp=0x%x", i, cidx,
                    pChanInfo->ElementPos.LowPart, llpaddr.LowPart);

    while (i > cidx) {
        UINT32 tSize = 0;
        DmaGetDataEle(llvaddr, i, NULL, NULL, &tSize, NULL, NULL);
        *xferred -= tSize;
        i--;
    }
    *xferred -= pChanInfo->XferSize;
}


/**
 * Dump the address and content of DMA registers.
 *
 * This function should be called as protected code where no other thread or
 * HW interrupt can break it.
 *
 * @param[in] context   The arguments wrapper.
 *
 * @see DmaDumpReg
 */
static void ProtectedDumpReg(PDMA_SYNCRUN_CONTEXT context) {
    PDMA_RSC pdrsc = context->DmaRsc;
    DMA_DIRC dirc = context->Dirc;
    UINT8 chan = context->Chan;
    PCHAR msg = (PCHAR)context->Data;
    DmaDumpReg(pdrsc->DmaRegs, dirc, chan, msg, MAX_MSG_SIZE);
}

/**
 * Update linked list element.
 *
 * For multi block transfer on either read or write channel, this function
 * is called when the transfer is initialized. This function will also be
 * called each time the channel signals a Done interrupt and the transfer is
 * not finished. The HAL and the DMA core collaborate in Producer-Consumer
 * paradigm. See Linked List Operation section of the user mannual for details.
 *
 * @param[in] pdrsc The DMA resource object.
 * @param[in] chan  The read channel on which the transfer is performed.
 * @param[in] src   The source physical address.
 * @return DMA_SUCCESS if the operation is successfully performed. Otherwise,
 * an error happens during the process. Check HalDmaGetErrInfo() for more.
 */
static HAL_DMA_RET UpdateLLElements(PDMA_RSC pdrsc, DMA_DIRC dirc, UINT8 chan) {
    PCHAN_INFO pChanInfo = (dirc == DMA_WRITE) ? &pdrsc->WrChanInfo[chan]
            : &pdrsc->RdChanInfo[chan];
    UINT32 lle = pChanInfo->LLElements;
    UINT8 wm = pChanInfo->WaterMark;
    UINT8 pcs = pChanInfo->PCS;
    BOOLEAN isInit = (pChanInfo->DoneIntrCnt == 0);
    PUINT32 llvaddr = GetBaseLLVAddr(pdrsc, dirc, chan);
    PRODUCER_FUNC func = pChanInfo->ProducerFunc;
    PVOID funcCtx = pChanInfo->ProducerContext;
    PHYADDR src = pChanInfo->SrcPos;
    PHYADDR dst = pChanInfo->DstPos;
    UINT32 xferSize;
    UINT32 i;
    BOOLEAN isWmEle, isLastDataEle;

    /* Get the data of next element */
    if (!func(&src, &dst, &xferSize, dirc, chan, funcCtx)) {
        DTRACE("!!! SHOULD NOT HAPPEN. NO DATA!!!");
        return DMA_FATAL;
    }
	DTRACE("src=0x%llx, dst=0x%llx, xferSize=0x%x, pChanInfo->ElementIdx=0x%x\n",
		src.QuadPart, dst.QuadPart, xferSize, i);

    pChanInfo->FeedSize += xferSize;
    pChanInfo->SrcPos = src;
    pChanInfo->DstPos = dst;
	pChanInfo->FirstElementXferSize = xferSize;

    i = pChanInfo->ElementIdx;

	DTRACE("llvaddr=0x%llx\n", llvaddr);
    /* !!! Don't flip the pcs of the first element */
    DmaSetDataEle(llvaddr, i, !pcs, FALSE, xferSize, src, dst);

    /* Refresh the element data one by one along the linked list until it
     * encounters watermark element or last data element
     */
    while (TRUE) {
        i++;
        if (!func(&src, &dst, &xferSize, dirc, chan, funcCtx)) {
            DTRACE("!!! SHOULD NOT HAPPEN. NO DATA!!!");
            return DMA_FATAL;
        }
        pChanInfo->FeedSize += xferSize;
		if (wm != 0)
        	isWmEle = (i == wm);
		else
			isWmEle = 0;
        isLastDataEle = (i == lle - 2);
		DTRACE("src=0x%llx, dst=0x%llx, xferSize=0x%x, pChanInfo->ElementIdx=0x%x\n",
			src.QuadPart, dst.QuadPart, xferSize, i);
		DTRACE("isLastDataEle=0x%x, lle=0x%x\n", isLastDataEle, lle);

        DmaSetDataEle(llvaddr, i, pcs, (isWmEle || isLastDataEle), xferSize,
                src, dst);
        if (isLastDataEle || (!isInit && isWmEle))
            break;
    }

    /* Set the link element in recycling manner */
    if (isLastDataEle) {
        DmaSetLinkEle(llvaddr, lle - 1, !pcs, GetBaseLLPAddr(pdrsc, dirc, chan),
                TRUE);
    }

    /* Now flip the pcs of the first element */
    DmaSetDataEle(llvaddr, pChanInfo->ElementIdx, pcs, FALSE, pChanInfo->FirstElementXferSize,
            pChanInfo->SrcPos, pChanInfo->DstPos);

    /* Remember where we are */
    pChanInfo->SrcPos = src;
    pChanInfo->DstPos = dst;
    pChanInfo->ElementIdx = isLastDataEle ? 0 : (i + 1);
    pChanInfo->PCS = isLastDataEle ? !pcs : pcs;
    return DMA_SUCCESS;
}

/**
 * Initialize error information.
 */
static void InitErrInfo(void)
{
    gErrInfo[DMA_SUCCESS] = "Success";
    gErrInfo[DMA_CHAN_BUSY] = "Channel is busy.";
    gErrInfo[DMA_INVALID_CHAN] = "Channel is invalid.";
    gErrInfo[DMA_INVALID_BLOCK_SIZE] = "Block size is invalid.";
    gErrInfo[DMA_INVALID_LL_LEN] = "Linked list element length is invalid.";
    gErrInfo[DMA_INVALID_WM] = "WaterMark element is invalid.";
    gErrInfo[DMA_INVALID_WEIGHT] = "Weight value is invalid.";
    gErrInfo[DMA_NULL_ARG] = "Argument is null.";
    gErrInfo[DMA_UNKNOWN_FAILURE] = "Unknown failure.";
    gErrInfo[DMA_NO_QUEUING_JOBS] = "Cannot find queuing jobs.";
    gErrInfo[DMA_NO_FEED] = "Cannot get more data from producer callback.";
    gErrInfo[DMA_FATAL] = "DMA fatal error! Unexpected input or output.";
}
