/*****************************************************************************
 *
 * <COPYRIGHT_TAG>
 *
 *****************************************************************************/
 /*
 *****************************************************************************
 * Doxygen group definitions
 ****************************************************************************/
/*****************************************************************************
 * @file rpp_sram_io.h
 *
 * @description
 *		This file contains the rpp sram io api
 *
 *****************************************************************************/
#pragma once

#include "rpp_types.h"
#include "rpp_drv_api.h"
#include <rpp_runtime.h>
#include <sys/time.h>
#include <vector>
#include <cmath>
#include <assert.h>
#include <sstream>
#include <string>
#include <iostream>
#include <map>
#include <rpp_graph_mgr.h>
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define SRAM_WORK_SPACE (23*1024*1024)
#define MAX_THREADS (4096)
#define USE_R2H_LUT_KERNEL
typedef struct KernTaskInfo_t
{
	RPPfunction hfunc;
    std::string kernel_name;
	tRppGridDim gridDim;
	tRppTbDim tbDim;
	int nparas;
	uint32_t kparams[64];
}KernTaskInfo;
enum RppFormat_e {
        LINEAR = 0,
        HFMT, 
        RFMT,
        HCFMT,
        RCFMT,
};
typedef struct rppSramIoHandle *rppSramIoHandle_t;
typedef struct rppSramIoHandle
{
	int rowSegLenth;
	int colSegLenth;
	int elementSize;
	int d2hPadding;
	int isH2R;
	uint16_t d2hAddr[64];
	RPPdeviceptr d2hAddrDev;
	RPPdeviceptr workspace[2];
	int sizeRnd[2];
	RPPmodule rppMod;
	KernTaskInfo taskInfo;
    RPPdevice rppDevice;
    RPPcontext rppDeviceContext;
};

static void r2hPattern(rppSramIoHandle_t handle)
{
	int interval = handle->colSegLenth * handle->rowSegLenth * 2;
	int d2hPadding;
	int elementSize = handle->elementSize;
	 if (elementSize == 8)
		 d2hPadding = 4;
	 else if (elementSize == 4)
		  d2hPadding = 8;
	  uint16_t *d2hLo = &handle->d2hAddr[0];
	  uint16_t *d2hHi = &handle->d2hAddr[32];
	  if(elementSize == 8)
	  {
		  for(int i = 0; i < 8; i++)
		  {
			  for(int j = 0; j < 4; j++)
			  {
				  uint32_t addr0 = (interval + d2hPadding) * j + (i * 2);
				  d2hLo[4*i + j] = addr0 & 0xffff;
				  d2hHi[4*i + j] = (addr0 >> 16) & 0xffff;
			  }
		  }
	  }
	  else
	  {
		  for(int i = 0; i < 16; i++)
		  {
			  for(int j = 0; j < 2; j++)
			  {
				  uint32_t addr0 = (interval + d2hPadding) * j + (i * 2);
				  d2hLo[2*i + j] = addr0 & 0xffff;
				  d2hHi[2*i + j] = (addr0 >> 16) & 0xffff;
			  }
		  }
	  }
      rppMemcpyHtoD(handle->d2hAddrDev, handle->d2hAddr, 128);
	  rpp_graph_mgr::GraphManager& graphmgr = rpp_graph_mgr::GraphManager::GetInstance();
	  graphmgr.markWeight((RPPdeviceptr)handle->d2hAddrDev, (RPPdeviceptr)handle->d2hAddr, 128);
}

static void logKernelLaunch(const std::string &kernelName, const KernTaskInfo &taskInfo)
{
    std::ostringstream oss;

    oss << "Kernel function name: " << kernelName
        << "; Grid dimensions: x: " << taskInfo.gridDim.X
        << ", y: " << taskInfo.gridDim.Y
        << ", z: " << taskInfo.gridDim.Z
        << "; Block dimensions: x: " << taskInfo.tbDim.X
        << ", y: " << taskInfo.tbDim.Y
        << ", z: " << taskInfo.tbDim.Z
        << ".\nParameters: ";

    for (int i = 0; i < taskInfo.nparas; i++)
    {
        oss << "0x" << std::hex << taskInfo.kparams[i] << std::dec;
        if (i + 1 < taskInfo.nparas)
        {
            oss << ", ";
        }
    }
    oss << ".\n";

    std::cout << oss.str();
}

static void launchWrapper(rppSramIoHandle_t handle, const std::string &kernelName, RPPstream stream)
{
    KernTaskInfo *pTaskInfo = &(handle->taskInfo);
	RPPmodule rppMod = handle->rppMod;
	RPPfunction hfunc;
	void *params[64];
	RPPresult res = rppModuleGetFunction(&hfunc, rppMod, kernelName.c_str());
    assert(res == RPP_SUCCESS);
	for(int cnt = 0; cnt < pTaskInfo->nparas; cnt++)
	{
		params[cnt] = &(pTaskInfo->kparams[cnt]);
	}
    //logKernelLaunch(kernelName, *pTaskInfo);
	rppLaunchKernel(hfunc, pTaskInfo->gridDim.X, pTaskInfo->gridDim.Y, pTaskInfo->gridDim.Z, 
		pTaskInfo->tbDim.X, pTaskInfo->tbDim.Y, pTaskInfo->tbDim.Z, 0, stream, params, NULL);
	
	return;
}
static int sramIoInit(rppSramIoHandle_t handle)
{
    rppInit(0);
    rppDeviceGet(&handle->rppDevice, 0);
    rppDevicePrimaryCtxRetain(&handle->rppDeviceContext, handle->rppDevice);
    rppCtxPushCurrent(handle->rppDeviceContext);

    std::string binaryName = "/usr/local/rpp/lib/sram_io_kernel.o";
    rppModuleLoad(&handle->rppMod, binaryName.c_str());

    rppMemAlloc(&handle->d2hAddrDev, 128);

	return 0;
}
static int sramIoExit(rppSramIoHandle_t handle)
{
	rppModuleUnload(handle->rppMod);
    rppMemFree(handle->d2hAddrDev);
    rppCtxPopCurrent(&handle->rppDeviceContext);
    rppDevicePrimaryCtxRelease(handle->rppDevice);
	return 0;
}
static void calcSegment(rppSramIoHandle_t handle, int row, int col, RppFormat_e inFormat, RppFormat_e outFormat)
{
	if(inFormat == HCFMT && outFormat == RCFMT)
	{
		handle->elementSize = 8;
		handle->isH2R = 1;
	}
	else if (inFormat == RCFMT && outFormat == HCFMT)
	{
		handle->elementSize = 8;
		handle->isH2R = 0;
	}
	else if(inFormat == HFMT && outFormat == RFMT)
	{
		handle->elementSize = 4;
		handle->isH2R = 1;
	}
	else if (inFormat == RFMT && outFormat == HFMT)
	{
		handle->elementSize = 4;
		handle->isH2R = 0;
	}
	else
		assert(0);

    handle->colSegLenth = col;
    handle->rowSegLenth = row;

	return;
}
static void KShape_TransPadingU16(rppSramIoHandle_t handle, int w, int h)
{
    auto *pTaskInfo = &(handle->taskInfo);
    int h0 = h;
	int w0 = w;
    while(w0 > 4096) 
        w0 = w0 >> 1;
    while(w0 * h0 > 4096) 
        h0 = h0 >> 1;
	
    pTaskInfo->tbDim.X = w0; 
    pTaskInfo->tbDim.Y = h0; 
    pTaskInfo->tbDim.Z = 1;
    pTaskInfo->gridDim.X = w / w0; 
    pTaskInfo->gridDim.Y = h / h0; 
    pTaskInfo->gridDim.Z = 1;
	assert(h == (pTaskInfo->gridDim.Y * h0));
	assert(w == (pTaskInfo->gridDim.X * w0));
    return;
}
static void KParam_TransPadingU16(rppSramIoHandle_t handle, int w, int h, int nMat, RPPdeviceptr sramIn, RPPdeviceptr sramOut, RPPstream stream)
{
    auto *pTaskInfo = &(handle->taskInfo);
    uint32_t input0 = sramIn;
    uint32_t output0 = sramOut;
    int nBlockX, nBlockY, padStride, inBlkStride, outYStride;
 
	nBlockX = pTaskInfo->gridDim.X;
    nBlockY = pTaskInfo->gridDim.Y;
    pTaskInfo->gridDim.Y = 1;
	pTaskInfo->gridDim.X = 1;
    inBlkStride = pTaskInfo->tbDim.X * pTaskInfo->tbDim.Y * pTaskInfo->tbDim.Z * 2;
	padStride = pTaskInfo->tbDim.Y * pTaskInfo->tbDim.Z * 2;
    outYStride = (w + 1);

    int nparas = 0;
    pTaskInfo->kparams[nparas++] = (uint32_t)(input0);
    pTaskInfo->kparams[nparas++] = (uint32_t)(output0);
    pTaskInfo->kparams[nparas++] = inBlkStride;
    pTaskInfo->kparams[nparas++] = padStride;
    pTaskInfo->kparams[nparas++] = outYStride;
    pTaskInfo->kparams[nparas++] = nMat;
    pTaskInfo->kparams[nparas++] = nBlockX;
	pTaskInfo->kparams[nparas++] = nBlockY;
    assert(outYStride < 0xffff);
    pTaskInfo->nparas = nparas;
    launchWrapper(handle, "transpose_padding", stream);
    return;
}
static void KShape_H2R0(rppSramIoHandle_t handle, int elementSize)
{
	auto *pTaskInfo = &(handle->taskInfo);
	int colSegLenth = handle->colSegLenth;
	int outPoints;
	if (elementSize == 8)
		outPoints = 2;
	else if  (elementSize == 4)
		outPoints = 4;
	else if  (elementSize == 2)
		outPoints = 8;
	else
		assert(0);

	if (colSegLenth >= 128 * outPoints)
		pTaskInfo->tbDim.Z = 128; 
	else
	{
		pTaskInfo->tbDim.Z = colSegLenth / outPoints;
	}
	pTaskInfo->tbDim.X = 32;
	pTaskInfo->tbDim.Y = 1;
	pTaskInfo->gridDim.X = 1; 
	pTaskInfo->gridDim.Y = 1; 
	pTaskInfo->gridDim.Z = 1;
	return;
}

static void KParam_H2R0(rppSramIoHandle_t handle, int elementSize, RPPdeviceptr sramIn, RPPdeviceptr sramOut, RPPstream stream = 0)
{
	auto *pTaskInfo = &(handle->taskInfo);
	int rowSegLenth = handle->rowSegLenth;
	int colSegLenth = handle->colSegLenth;
	int outputPad = 2;
	int stride0;
    if (elementSize == 8)
		stride0 = 2;
	else if  (elementSize == 4)
	    stride0 = 4;
	else if  (elementSize == 2)
	    stride0 = 8;
	else
	    assert(0);
	uint32_t input = sramIn;
	uint32_t output0 =sramOut;
	uint32_t blockSize0 = (rowSegLenth + 1) * (colSegLenth + 1) * sizeof(uint16_t);
	blockSize0 = ((blockSize0 + 1023) / 1024) * 1024;
	uint32_t output1 = output0 + blockSize0;
	uint32_t output2 = output1 + blockSize0;
	uint32_t output3 = output2 + blockSize0;
	uint32_t src_x_stribe = colSegLenth * elementSize + 2;
	uint32_t src_y_stribe = (rowSegLenth + 1) * stride0;
	uint32_t load_jump_size1 = (pTaskInfo->tbDim.Z - 1) * 8 * 2;
    uint32_t load_jump_size2 = (pTaskInfo->tbDim.X - 1) * src_x_stribe + (pTaskInfo->tbDim.Z * 8 - 7) * 2;
    uint32_t store_jump_size = (pTaskInfo->tbDim.Z - 1) * (rowSegLenth + 1) * stride0 * 2;
	uint32_t loop_row = rowSegLenth / 32;
	uint32_t loop_block = colSegLenth / (pTaskInfo->tbDim.Z * stride0);
   
    //printf("KParam_H2R0 input %x output0 %x, output1 %x \n", input, output0, output1);
    int nparas = 0;
    pTaskInfo->kparams[nparas++] = (uint32_t)(input);
    pTaskInfo->kparams[nparas++] = (uint32_t)(output0);
    pTaskInfo->kparams[nparas++] = (uint32_t)(output0);
    if (elementSize == 8 || elementSize == 4)
    {
        pTaskInfo->kparams[nparas++] = (uint32_t)(output1);
        pTaskInfo->kparams[nparas++] = (uint32_t)(output1);
    }
    if (elementSize == 8)
    {
        pTaskInfo->kparams[nparas++] = (uint32_t)(output2);
        pTaskInfo->kparams[nparas++] = (uint32_t)(output2);
        pTaskInfo->kparams[nparas++] = (uint32_t)(output3);
        pTaskInfo->kparams[nparas++] = (uint32_t)(output3);
    }
    pTaskInfo->kparams[nparas++] = src_x_stribe;
    pTaskInfo->kparams[nparas++] = src_y_stribe;
    pTaskInfo->kparams[nparas++] = load_jump_size1;
    pTaskInfo->kparams[nparas++] = load_jump_size2;
    pTaskInfo->kparams[nparas++] = store_jump_size;
    pTaskInfo->kparams[nparas++] = loop_row;
    pTaskInfo->kparams[nparas++] = loop_block;
    pTaskInfo->kparams[nparas++] = outputPad;
    pTaskInfo->nparas = nparas;

    if (elementSize == 8)
        launchWrapper(handle, "transpose_u64", stream);
    else if (elementSize == 4)
        launchWrapper(handle, "transpose_u32", stream);
    else
        launchWrapper(handle, "transpose_u16", stream);
    return;

}

static void KShape_H2R1(rppSramIoHandle_t handle)
{
	auto *pTaskInfo = &(handle->taskInfo);
    int colSegLenth = handle->rowSegLenth;

	int outPoints = 8;
	if (colSegLenth >= 128 * outPoints)
		pTaskInfo->tbDim.Z = 128; 
	else
		pTaskInfo->tbDim.Z = colSegLenth / outPoints;

    assert(pTaskInfo->tbDim.Z != 0);
    pTaskInfo->tbDim.X = 32;
	pTaskInfo->tbDim.Y= 1;
    pTaskInfo->gridDim.X = 1; 
	pTaskInfo->gridDim.Y = 1; 
	pTaskInfo->gridDim.Z = 1;

	return;
}

static void KParam_H2R1(rppSramIoHandle_t handle, int wordId, RPPdeviceptr sramIn, RPPdeviceptr sramOut, RPPstream stream = 0)
{
	auto *pTaskInfo = &(handle->taskInfo);
	int rowSegLenth = handle->colSegLenth;
	int colSegLength = handle->rowSegLenth;
	int outputPad = 0;
    int stride0 = 8;
	uint32_t input0 = sramIn;
	uint32_t blockSize0 = (rowSegLenth + 1) * (colSegLength + 1) * sizeof(uint16_t);
	blockSize0 = ((blockSize0 + 1023) / 1024) * 1024;
	input0 = input0 + wordId * blockSize0;

	uint32_t output0;
	output0 = sramOut;
	blockSize0 = rowSegLenth * colSegLength * sizeof(uint16_t);
	
	output0 += wordId * blockSize0;

	uint32_t src_x_stribe = colSegLength * sizeof(short) + 2;
	uint32_t src_y_stribe = (rowSegLenth) * stride0;
	uint32_t load_jump_size1 = (pTaskInfo->tbDim.Z - 1) * 8 * 2;
    uint32_t load_jump_size2 = (pTaskInfo->tbDim.X - 1) * src_x_stribe + (pTaskInfo->tbDim.Z * 8 - 7) * 2;
    uint32_t store_jump_size = (pTaskInfo->tbDim.Z - 1) * (rowSegLenth) * stride0 * 2;
	uint32_t loop_row = rowSegLenth / 32;
	uint32_t loop_block = colSegLength / (pTaskInfo->tbDim.Z * stride0);
    //printf("KParam_H2R1, wid %d input %x output %x \n", wordId, input0, output0);
    int nparas = 0;
    pTaskInfo->kparams[nparas++] = (uint32_t)(input0);
    pTaskInfo->kparams[nparas++] = (uint32_t)(output0);
    pTaskInfo->kparams[nparas++] = src_x_stribe;
    pTaskInfo->kparams[nparas++] = src_y_stribe;
    pTaskInfo->kparams[nparas++] = load_jump_size1;
    pTaskInfo->kparams[nparas++] = load_jump_size2;
    pTaskInfo->kparams[nparas++] = store_jump_size;
    pTaskInfo->kparams[nparas++] = loop_row;
    pTaskInfo->kparams[nparas++] = loop_block;
	pTaskInfo->kparams[nparas++] = outputPad;
    pTaskInfo->nparas = nparas;
    launchWrapper(handle, "transpose_u16", stream);

	return;
}

static void KTask_H2R(rppSramIoHandle_t handle, RPPdeviceptr sramIn, RPPdeviceptr sramOut, RPPdeviceptr workspace, RPPstream stream = 0)
{
	int elementSize = handle->elementSize;
    int w = handle->colSegLenth; int h = handle->rowSegLenth; 
	int sizeRnd = ((w + 1) * (h + 1) * elementSize + 1023) / 1024 * 1024;
    RPPdeviceptr workspace0 =  workspace;
	RPPdeviceptr workspace1 =  workspace + sizeRnd;
    KShape_TransPadingU16(handle, w * elementSize / sizeof(short), h); 
    KParam_TransPadingU16(handle, w * elementSize / sizeof(short), h, 1, sramIn, workspace0, stream);
	KShape_H2R0(handle, elementSize);
	KParam_H2R0(handle, elementSize, workspace0, workspace1, stream);

	KShape_H2R1(handle);
    for(int wid = 0; wid < elementSize / 2; wid++)
	{
		KParam_H2R1(handle, wid, workspace1, sramOut, stream);
	}
	return;
}

static void KShape_R2HPading(rppSramIoHandle_t handle)
{
    auto *pTaskInfo = &(handle->taskInfo);
    int totalThreads = handle->colSegLenth * handle->rowSegLenth;
    int nblocks = 1;
    while (totalThreads > MAX_THREADS)
    {
        totalThreads = totalThreads >> 1;
        nblocks = nblocks * 2;
    }
    assert(totalThreads % 32 == 0);
    pTaskInfo->tbDim.X = totalThreads;
    pTaskInfo->tbDim.Y = 1;
    pTaskInfo->tbDim.Z = 1;
    pTaskInfo->gridDim.X = nblocks; 
    pTaskInfo->gridDim.Y = 1; 
    pTaskInfo->gridDim.Z = 1;
    return;
}
static void KParam_R2HPading(rppSramIoHandle_t handle, int elementSize, RPPdeviceptr sramIn, RPPdeviceptr sramOut, RPPstream stream = 0)
{
    auto *pTaskInfo = &(handle->taskInfo);
    int colSegLength = handle->colSegLenth;
    int rowSegLenth = handle->rowSegLenth;

    uint32_t input0 = sramIn;
    uint32_t output0 = sramOut;
    int nMat, nBlock, padStride, inBlkStride, outBlkStride;
    if (elementSize == 8) {
        nMat = 4;
        padStride = 4;
    }
    else if  (elementSize == 4) {
        nMat = 2;
        padStride = 8;
    }
    else 
        assert(0);
    nBlock = pTaskInfo->gridDim.X;
    pTaskInfo->gridDim.X = 1;
    inBlkStride = pTaskInfo->tbDim.X * pTaskInfo->tbDim.Y * pTaskInfo->tbDim.Z * 2;
    outBlkStride = inBlkStride;
    //printf("KParam_R2HPad, seg=%d, input0 %x, output0=%x, \n", seg, (uint32_t)(input0), (uint32_t)(output0));
    //printf("KParam_R2HPad in %x, out %x \n",input0, output0);
    int nparas = 0;
    pTaskInfo->kparams[nparas++] = (uint32_t)(input0);
    pTaskInfo->kparams[nparas++] = (uint32_t)(output0);
    pTaskInfo->kparams[nparas++] = inBlkStride;
    pTaskInfo->kparams[nparas++] = outBlkStride;
    pTaskInfo->kparams[nparas++] = padStride;
    pTaskInfo->kparams[nparas++] = nMat;
    pTaskInfo->kparams[nparas++] = nBlock;
    pTaskInfo->nparas = nparas;
    launchWrapper(handle, "reformat_d2h_padding", stream);
    return;
}

static void KShape_R2H0(rppSramIoHandle_t handle)
{
	auto *pTaskInfo = &(handle->taskInfo);
    int colSegLenth = handle->colSegLenth;
    
    pTaskInfo->tbDim.X = 32;
    while (pTaskInfo->tbDim.X * colSegLenth > MAX_THREADS)
		colSegLenth = colSegLenth >> 1;
	
	pTaskInfo->tbDim.Y = colSegLenth;
	pTaskInfo->tbDim.Z = 1;
    pTaskInfo->gridDim.X = 1; 
	pTaskInfo->gridDim.Y = 1; 
	pTaskInfo->gridDim.Z = 1;
	return;
}
static void KParam_R2H0(rppSramIoHandle_t handle, int elementSize, RPPdeviceptr sramIn, RPPdeviceptr sramOut, RPPdeviceptr d2hPat, RPPstream stream)
{
	auto *pTaskInfo = &(handle->taskInfo);
	int colSegLength = handle->colSegLenth;
	int rowSegLenth = handle->rowSegLenth;
	int outputPad = 0;
    int stride0;
	uint32_t input0 = sramIn;
	uint32_t output0 = sramOut;
	uint32_t d2hPatternLo = d2hPat;
	uint32_t d2hPatternHi = d2hPatternLo + 64;

    if (elementSize == 8)
        stride0 = 1;
    else if  (elementSize == 4)
        stride0 = 2;
    else 
	    assert(0);

	if((pTaskInfo->tbDim.X * pTaskInfo->tbDim.Y * stride0) > rowSegLenth * colSegLength)
	{
		pTaskInfo->tbDim.Y = colSegLength / 2;
		assert(rowSegLenth >= 32);
		assert(pTaskInfo->tbDim.Y != 0);
	}
	uint32_t loop_n = rowSegLenth * colSegLength / (pTaskInfo->tbDim.X * pTaskInfo->tbDim.Y * stride0);

	uint32_t load_jump_size = pTaskInfo->tbDim.X * pTaskInfo->tbDim.Y * stride0 / 2; 
    uint32_t store_jump_size = load_jump_size * 4 / stride0;

	assert(loop_n != 0);
    int nparas = 0;
    pTaskInfo->kparams[nparas++] = (uint32_t)(input0);
    pTaskInfo->kparams[nparas++] = (uint32_t)(output0);
    pTaskInfo->kparams[nparas++] = d2hPatternHi;
    pTaskInfo->kparams[nparas++] = d2hPatternLo;
    pTaskInfo->kparams[nparas++] = load_jump_size;
    pTaskInfo->kparams[nparas++] = store_jump_size;
    pTaskInfo->kparams[nparas++] = loop_n;
    pTaskInfo->nparas = nparas;

    if (elementSize == 8)
        launchWrapper(handle, "reformat_d2h_u64", stream);
	else 
        launchWrapper(handle, "reformat_d2h_u32", stream);
	return;
}

static void KShape_R2HLut(rppSramIoHandle_t handle)
{
	auto *pTaskInfo = &(handle->taskInfo);
    if (handle->elementSize == 8)
    {
        pTaskInfo->tbDim.X = 4;
        pTaskInfo->tbDim.Y = 8;
    }
    else if (handle->elementSize == 4)
    {
        pTaskInfo->tbDim.X = 2;
        pTaskInfo->tbDim.Y = 16;
    }
    else
    {
        assert(0);
    }
    //HW thread block should be greater than 32, set tbDim.Z to 2 as workaround
	pTaskInfo->tbDim.Z = 2;
    pTaskInfo->gridDim.X = 1;
	pTaskInfo->gridDim.Y = 1;
	pTaskInfo->gridDim.Z = 1;
	return;
}

static void KParam_R2HLut(rppSramIoHandle_t handle, RPPdeviceptr d2hPat, RPPstream stream)
{
	auto *pTaskInfo = &(handle->taskInfo);
    int d2hPadding;
    if (handle->elementSize == 8)
        d2hPadding = 4;
    else if (handle->elementSize == 4)
        d2hPadding = 8;
    else
        assert(0);

    uint32_t d2hPatternLo = d2hPat;
	uint32_t d2hPatternHi = d2hPatternLo + 64;
    uint32_t interval = handle->colSegLenth * handle->rowSegLenth * 2;
    int nparas = 0;
    pTaskInfo->kparams[nparas++] = d2hPatternLo;
    pTaskInfo->kparams[nparas++] = d2hPatternHi;
    pTaskInfo->kparams[nparas++] = interval + d2hPadding;
    pTaskInfo->kparams[nparas++] = pTaskInfo->tbDim.X;
    pTaskInfo->nparas = nparas;
    launchWrapper(handle, "reformat_d2h_lut", stream);
	return;
}

static void KTask_R2H(rppSramIoHandle_t handle, RPPdeviceptr sramIn, RPPdeviceptr sramOut, RPPdeviceptr workspace, RPPstream stream = 0)
{
    int elementSize = handle->elementSize;
    int w = handle->colSegLenth; int h = handle->rowSegLenth; 
	int sizeRnd = ((w + 1) * (h + 1) * elementSize + 1023) / 1024 * 1024;
	RPPdeviceptr workspace0 = workspace;
	RPPdeviceptr workspace1 = workspace + sizeRnd + 1024;

    KShape_R2HPading(handle);
    KParam_R2HPading(handle, elementSize, sramIn, workspace0, stream);

    KShape_R2HLut(handle);
    KParam_R2HLut(handle, workspace1, stream);

    KShape_R2H0(handle);
    KParam_R2H0(handle, elementSize, workspace0, sramOut, workspace1, stream);
	
	return;
}


static void rpp_reformat(rppSramIoHandle_t handle, float *output, float *input, RppFormat_e inFormat, RppFormat_e outFormat, 
		int w, int h, float *workspace, RPPstream stream = 0)
{

	calcSegment(handle, h, w, inFormat, outFormat);
	if(handle->isH2R)
		KTask_H2R(handle, (RPPdeviceptr)input, (RPPdeviceptr)output, (RPPdeviceptr)workspace, stream);
	else
		KTask_R2H(handle, (RPPdeviceptr)input, (RPPdeviceptr)output, (RPPdeviceptr)workspace, stream);
	
}
#ifdef __cplusplus
}
#endif /* __cplusplus */
