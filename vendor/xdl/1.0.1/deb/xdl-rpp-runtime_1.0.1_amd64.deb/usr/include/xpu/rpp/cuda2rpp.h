/*****************************************************************************
 *
 * <COPYRIGHT_TAG>
 *
 *****************************************************************************/
/*
*****************************************************************************
* Doxygen group definitions
****************************************************************************/
/*****************************************************************************
 * @file cuda2rpp.h
 *
 * @description
 *		This file contains the api conversion from cuda to rpp
 *
 *****************************************************************************/

#ifndef CUDA2RPP_H
#define CUDA2RPP_H

#include "rpp_types.h"
#include <rpp_runtime.h>
#include <rpp_smap.h>
#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

#define cudaSuccess rtSuccess
#define cudaError_t rtError_t

// memeory management api
#define cudaMalloc rtMalloc
#define cudaFree rtFree
#define cudaMallocHost rtMallocHost
#define cudaFreeHost rtFreeHost

#define cudaGetDevice rtGetDevice
#define cudaGetLastError rtGetLastError
#define cudaDeviceSynchronize rtDeviceSynchronize
#define cudaGetDeviceProperties rtGetDeviceProperties 
#define cudaDeviceProp rtDeviceProp

#define cudaGetErrorString rtGetErrorString

// data transfer api
// #define cudaMemcpy rtMemcpy
#define cudaMemcpy2D rtMemcpy2D
#define cudaMemset rtMemset
#define cudaMemcpyAsync rtMemcpyAsync
#define cudaMemcpy2DAsync rtMemcpy2DAsync
#define cudaMemsetAsync rtMemsetAsync
#define cudaMemcpyHostToHost rtMemcpyHostToHost
#define cudaMemcpyHostToDevice rtMemcpyHostToDevice
#define cudaMemcpyDeviceToHost rtMemcpyDeviceToHost
#define cudaMemcpyDeviceToDevice rtMemcpyDeviceToDevice

    static inline void cudaMemcpy(void *dst, void *src, size_t count, enum rtMemcpyKind kind)
    {
        if ((count > 512 * 1024 * 1024) && (kind == rtMemcpyHostToDevice || kind == rtMemcpyDeviceToHost))
        {
            for (size_t i = 0; i < count; i += 512 * 1024 * 1024)
            {
                rtMemcpy(dst, src, 512 * 1024 * 1024, kind);
                src = (char *)src + 512 * 1024 * 1024;
                dst = (char *)dst + 512 * 1024 * 1024;
            }
            count = count % 512 * 1024 * 1024;
            if (count != 0)
                rtMemcpy(dst, src, count, kind);
        }
        else
        {
            rtMemcpy(dst, src, count, kind);
        }
    }

// event management api
#define cudaEventCreate rtEventCreate
#define cudaEventCreateWithFlags rtEventCreateWithFlags
#define cudaEventRecord rtEventRecord
#define cudaEventQuery rtEventQuery
#define cudaEventSynchronize rtEventSynchronize
#define cudaEventDestroy rtEventDestroy
#define cudaEventElapsedTime rtEventElapsedTime

// stream management api
#define cudaStreamCreate rtStreamCreate
#define cudaStreamDestroy rtStreamDestroy
#define cudaStreamSynchronize rtStreamSynchronize
#define cudaStreamQuery rtStreamQuery
#define cudaStreamWaitEvent rtStreamWaitEvent

// data type and instance
#define cudaStream_t rtStream_t
#define cudaEvent_t rtEvent_t
#define cuComplex rppComplex

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif
