#pragma once
#define __CUDA_HOSTDEVICE__ __host__ __device__
#include <stdio.h>
class _f16_
{
	unsigned short v_;

	friend __CUDA_HOSTDEVICE__ _f16_ operator-(const _f16_& v);
	friend __CUDA_HOSTDEVICE__ _f16_ operator+(const _f16_& a, const _f16_& b);
	friend __CUDA_HOSTDEVICE__ _f16_ operator-(const _f16_& a, const _f16_& b);
	friend __CUDA_HOSTDEVICE__ _f16_ operator*(const _f16_& a, const _f16_& b);
	friend __CUDA_HOSTDEVICE__ _f16_ operator/(const _f16_& a, const _f16_& b);
	friend __CUDA_HOSTDEVICE__ bool operator<(const _f16_& a, const _f16_& b);
	friend __CUDA_HOSTDEVICE__ bool operator==(const _f16_& a, const _f16_& b);
	friend __CUDA_HOSTDEVICE__ bool operator>(const _f16_& a, const _f16_& b);
	friend __CUDA_HOSTDEVICE__ bool operator!=(const _f16_& a, const _f16_& b);
	friend __CUDA_HOSTDEVICE__ bool operator<=(const _f16_& a, const _f16_& b);
	friend __CUDA_HOSTDEVICE__ bool operator>=(const _f16_& a, const _f16_& b);

	

public:
	__CUDA_HOSTDEVICE__ _f16_() : v_(0) {}
	__CUDA_HOSTDEVICE__ _f16_(const _f16_& v) {v_ = v.v_;}
	__CUDA_HOSTDEVICE__ _f16_(unsigned short v) { v_ = v; }
	__CUDA_HOSTDEVICE__ _f16_(unsigned int v)
	{
#if (defined __CUDA_ARCH__)
		asm("{ CVT.F16.U32 %0, %1; }"
			: "=h"(v_)
			: "r"(v));
#else
		float d = (float)v;
		v_ = ((unsigned short*)&d)[1];
#endif
	}
	__CUDA_HOSTDEVICE__ _f16_(short v)
	{
#if (defined __CUDA_ARCH__)
		asm("{ CVT.F16.S16 %0, %1; }"
			: "=h"(v_)
			: "h"(v));
#else
		float d = (float)v;
		v_ = ((unsigned short*)&d)[1];
#endif
	}
	__CUDA_HOSTDEVICE__ _f16_(int v)
	{
#if (defined __CUDA_ARCH__)
		asm("{ CVT.F16.S32 %0, %1; }"
			: "=h"(v_)
			: "r"(v));
#else
		float d = (float)v;
		v_ = ((unsigned short*)&d)[1];
#endif
	}
	__CUDA_HOSTDEVICE__ _f16_(float v)
	{
#if (defined __CUDA_ARCH__)
		asm("{ CVT.F16.F32 %0, %1; }"
			: "=h"(v_)
			: "f"(v));
#else
		v_ = ((unsigned short*)&v)[1];
#endif
	}

	__CUDA_HOSTDEVICE__ unsigned short to_ushort() const 
	{
#if (defined __CUDA_ARCH__)
		unsigned short out;
		asm("{ CVT.U16.F16 %0, %1; }"
			: "=h"(out)
			: "h"(v_));
		return out;
#else
		union { float flt{ 0 }; unsigned short data[2]; };
		data[1] = v_;
		return (short)flt;
#endif
	}
	__CUDA_HOSTDEVICE__ unsigned int to_uint() const
	{
#if (defined __CUDA_ARCH__)
		unsigned int out;
		asm("{ CVT.U32.F16 %0, %1; }"
			: "=r"(out)
			: "h"(v_));
		return out;
#else
		union { float flt{ 0 }; unsigned short data[2]; };
		data[1] = v_;
		return (int)flt;
#endif
	}
	__CUDA_HOSTDEVICE__ float to_float() const
	{
#if (defined __CUDA_ARCH__)
		float out;
		asm("{ CVT.F32.F16 %0, %1; }"
			: "=f"(out)
			: "h"(v_));
		return out;
#else
		union { float flt{ 0 }; unsigned short data[2]; };
		data[1] = v_;
		return flt;
#endif
	}
	__CUDA_HOSTDEVICE__ int to_int() const
	{
#if (defined __CUDA_ARCH__)
		int out;
		asm("{ CVT.S32.F16 %0, %1; }"
			: "=r"(out)
			: "h"(v_));
		return out;
#else
		union { float flt{ 0 }; unsigned short data[2]; };
		data[1] = v_;
		return (int)flt;
#endif
	}
	__CUDA_HOSTDEVICE__ short to_short() const
	{
#if (defined __CUDA_ARCH__)
		short out;
		asm("{ CVT.S16.F16 %0, %1; }"
			: "=h"(out)
			: "h"(v_));
		return out;
#else
		union { float flt{ 0 }; unsigned short data[2]; };
		data[1] = v_;
		return (short)flt;
#endif
	}
//  operator=

	__CUDA_HOSTDEVICE__ void operator=(const _f16_& v) { v_ = v.v_; }
	__CUDA_HOSTDEVICE__ void operator=(unsigned short v)
	{
#if (defined __CUDA_ARCH__)
		asm("{ CVT.F16.U16 %0, %1; }"
			: "=h"(v_)
			: "h"(v));
#else
		float d = (float)v;
		v_ = ((unsigned short*)&d)[1];
#endif
	}
	__CUDA_HOSTDEVICE__ void operator=(unsigned int v) 
	{
#if (defined __CUDA_ARCH__)
		asm("{ CVT.F16.U32 %0, %1; }"
			: "=h"(v_)
			: "r"(v));
#else
		float d = (float)v;
		v_ = ((unsigned short*)&d)[1];
#endif
	}
	__CUDA_HOSTDEVICE__ void operator=(short v)
	{
#if (defined __CUDA_ARCH__)
		asm("{ CVT.F16.S16 %0, %1; }"
			: "=h"(v_)
			: "h"(v));
#else
		float d = (float)v;
		v_ = ((unsigned short*)&d)[1];
#endif
	}
	__CUDA_HOSTDEVICE__ void operator=(int v)
	{
#if (defined __CUDA_ARCH__)
		asm("{ CVT.F16.S32 %0, %1; }"
			: "=h"(v_)
			: "r"(v));
#else
		float d = (float)v;
		v_ = ((unsigned short*)&d)[1];
#endif
	}
	__CUDA_HOSTDEVICE__ void operator=(float v)
	{
#if (defined __CUDA_ARCH__)
		asm("{ CVT.F16.F32 %0, %1; }"
			: "=h"(v_)
			: "f"(v));
#else
		v_ = ((unsigned short*)&v)[1];
#endif
	}

	__CUDA_HOSTDEVICE__ void operator+=(const _f16_& v) {
#if (defined __CUDA_ARCH__)			
			asm("{ ADD.F16 %0, %1, %2; }"
			: "=h"(v_)
			: "h"(v_), "h"(v.v_));
#else
		union { float flt{ 0 }; unsigned short data[2]; };
		data[1] = v_;
		union { float vv{ 0 }; unsigned short vv_[2]; };
		vv_[1] = v.v_;
		flt = flt + vv;
		v_ = data[1];
#endif
	}
	__CUDA_HOSTDEVICE__ void operator-=(const _f16_& v) {
#if (defined __CUDA_ARCH__)
			asm("{ SUB.F16 %0, %1, %2; }"
			: "=h"(v_)
			: "h"(v_), "h"(v.v_));
#else
		union { float flt{ 0 }; unsigned short data[2]; };
		data[1] = v_;
		union { float vv{ 0 }; unsigned short vv_[2]; };
		vv_[1] = v.v_;
		flt = flt - vv;
		v_ = data[1];
#endif
	}
	__CUDA_HOSTDEVICE__ void operator*=(const _f16_& v) {
#if (defined __CUDA_ARCH__)
			asm("{ MUL.F16 %0, %1, %2; }"
			: "=h"(v_)
			: "h"(v_), "h"(v.v_));
#else
		union { float flt{ 0 }; unsigned short data[2]; };
		data[1] = v_;
		union { float vv{ 0 }; unsigned short vv_[2]; };
		vv_[1] = v.v_;
		flt = flt * vv;
		v_ = data[1];
#endif
	}
	__CUDA_HOSTDEVICE__ void operator/=(const _f16_& v) {
#if (defined __CUDA_ARCH__)
			asm("{ DIV.F16 %0, %1, %2; }"
			: "=h"(v_)
			: "h"(v_), "h"(v.v_));
#else
		union { float flt{ 0 }; unsigned short data[2]; };
		data[1] = v_;
		union { float vv{ 0 }; unsigned short vv_[2]; };
		vv_[1] = v.v_;
		flt = flt / vv;
		v_ = data[1];
#endif
	}

	__CUDA_HOSTDEVICE__ _f16_ operator++() noexcept {
#if (defined __CUDA_ARCH__)
			asm("{ ADD.F16 %0, %1, 0x3f80; }"
			: "=h"(v_)
			: "h"(v_));
			return *this;
#else
		union { float flt{ 0 }; unsigned short data[2]; };
		data[1] = v_;
		++flt;
		v_ = data[1];
		return *this;
#endif
	}
	__CUDA_HOSTDEVICE__ _f16_ operator--() noexcept {
#if (defined __CUDA_ARCH__)
			asm("{ SUB.F16 %0, %1, 0x3f80; }"
			: "=h"(v_)
			: "h"(v_));
			return *this;
#else
		union { float flt{ 0 }; unsigned short data[2]; };
		data[1] = v_;
		--flt;
		v_ = data[1];
		return *this;
#endif
	}
	__CUDA_HOSTDEVICE__ _f16_ operator++(int) noexcept {
#if (defined __CUDA_ARCH__)
			unsigned short t = v_;
			asm("{ ADD.F16 %0, %1, 0x3f80; }"
			: "=h"(v_)
			: "h"(v_));
			return t;
#else
		auto t = v_;
		union { float flt{ 0 }; unsigned short data[2]; };
		data[1] = v_;
		flt++;
		v_ = data[1];
		return t;
#endif
	}
	__CUDA_HOSTDEVICE__ _f16_ operator--(int) noexcept {
#if (defined __CUDA_ARCH__)
			unsigned short t = v_;
			asm("{ SUB.F16 %0, %1, 0x3f80; }"
			: "=h"(v_)
			: "h"(v_));
			return t;
#else
		auto t = v_;
		union { float flt{ 0 }; unsigned short data[2]; };
		data[1] = v_;
		flt--;
		v_ = data[1];
		return t;
#endif
	}
};
inline __CUDA_HOSTDEVICE__ _f16_ operator-(const _f16_& v){
#if (defined __CUDA_ARCH__)
	_f16_ out;
	asm("{ NEG.F16 %0, %1; }"
			: "=h"(out.v_)
			: "h"(v.v_));
	return out;
#else
	union
	{
		float flt{0};
		unsigned short data[2];
	};
	data[1] = v.v_;
	flt = -flt;
	return data[1];
#endif
}
inline __CUDA_HOSTDEVICE__ _f16_ operator+(const _f16_& a, const _f16_& b){
#if (defined __CUDA_ARCH__)
	_f16_ out;
	asm("{ ADD.F16 %0, %1, %2; }"
			: "=h"(out.v_)
			: "h"(a.v_), "h"(b.v_));
	return out;
#else
	union
	{
		float aa{0};
		unsigned short a_[2];
	};
	a_[1] = a.v_;
	union
	{
		float bb{0};
		unsigned short b_[2];
	};
	b_[1] = b.v_;

	aa = aa + bb;
	return a_[1];
#endif
}
inline __CUDA_HOSTDEVICE__ _f16_ operator-(const _f16_& a, const _f16_& b){
#if (defined __CUDA_ARCH__)
	_f16_ out;
	asm("{ SUB.F16 %0, %1, %2; }"
			: "=h"(out.v_)
			: "h"(a.v_), "h"(b.v_));
	return out;
#else
	union
	{
		float aa{0};
		unsigned short a_[2];
	};
	a_[1] = a.v_;
	union
	{
		float bb{0};
		unsigned short b_[2];
	};
	b_[1] = b.v_;

	aa = aa - bb;
	return a_[1];
#endif
}
inline __CUDA_HOSTDEVICE__ _f16_ operator*(const _f16_& a, const _f16_& b){
#if (defined __CUDA_ARCH__)
	_f16_ out;
	asm("{ MUL.F16 %0, %1, %2; }"
			: "=h"(out.v_)
			: "h"(a.v_), "h"(b.v_));
	return out;
#else
	union
	{
		float aa{0};
		unsigned short a_[2];
	};
	a_[1] = a.v_;
	union
	{
		float bb{0};
		unsigned short b_[2];
	};
	b_[1] = b.v_;

	aa = aa * bb;
	return a_[1];
#endif
}
inline __CUDA_HOSTDEVICE__ _f16_ operator/(const _f16_& a, const _f16_& b){
#if (defined __CUDA_ARCH__)
	_f16_ out;
	asm("{ DIV.F16 %0, %1, %2; }"
			: "=h"(out.v_)
			: "h"(a.v_), "h"(b.v_));
	return out;
#else
	union
	{
		float aa{0};
		unsigned short a_[2];
	};
	a_[1] = a.v_;
	union
	{
		float bb{0};
		unsigned short b_[2];
	};
	b_[1] = b.v_;

	aa = aa / bb;
	return a_[1];
#endif
}
inline __CUDA_HOSTDEVICE__ bool operator<(const _f16_& a, const _f16_& b){
#if (defined __CUDA_ARCH__)
	unsigned short out;	
	asm("{ CMP.F16.LT %0, %1, %2; }"
			: "=h"(out)
			: "h"(a.v_), "h"(b.v_));
	return out;
#else
	union
	{
		float aa{0};
		unsigned short a_[2];
	};
	a_[1] = a.v_;
	union
	{
		float bb{0};
		unsigned short b_[2];
	};
	b_[1] = b.v_;

	return aa < bb;
#endif
}
inline __CUDA_HOSTDEVICE__ bool operator==(const _f16_& a, const _f16_& b){
#if (defined __CUDA_ARCH__)
	unsigned short out;	
	asm("{ CMP.F16.EQ %0, %1, %2; }"
			: "=h"(out)
			: "h"(a.v_), "h"(b.v_));
	return out;
#else
	return a.v_ == b.v_;
#endif
}
inline __CUDA_HOSTDEVICE__ bool operator>(const _f16_& a, const _f16_& b){
#if (defined __CUDA_ARCH__)
	unsigned short out;	
	asm("{ CMP.F16.GT %0, %1, %2; }"
			: "=h"(out)
			: "h"(a.v_), "h"(b.v_));
	return out;
#else
	union
	{
		float aa{0};
		unsigned short a_[2];
	};
	a_[1] = a.v_;
	union
	{
		float bb{0};
		unsigned short b_[2];
	};
	b_[1] = b.v_;

	return aa > bb;
#endif
}
inline __CUDA_HOSTDEVICE__ bool operator!=(const _f16_& a, const _f16_& b){
#if (defined __CUDA_ARCH__)
	unsigned short out;	
	asm("{ CMP.F16.NE %0, %1, %2; }"
			: "=h"(out)
			: "h"(a.v_), "h"(b.v_));
	return out;
#else
	return a.v_ != b.v_;
#endif
}
inline __CUDA_HOSTDEVICE__ bool operator<=(const _f16_& a, const _f16_& b){
#if (defined __CUDA_ARCH__)
	unsigned short out;	
	asm("{ CMP.F16.LE %0, %1, %2; }"
			: "=h"(out)
			: "h"(a.v_), "h"(b.v_));
	return out;
#else
	union
	{
		float aa{0};
		unsigned short a_[2];
	};
	a_[1] = a.v_;
	union
	{
		float bb{0};
		unsigned short b_[2];
	};
	b_[1] = b.v_;

	return aa <= bb;
#endif
}
inline __CUDA_HOSTDEVICE__ bool operator>=(const _f16_& a, const _f16_& b){
#if (defined __CUDA_ARCH__)
	unsigned short out;	
	asm("{ CMP.F16.GE %0, %1, %2; }"
			: "=h"(out)
			: "h"(a.v_), "h"(b.v_));
	return out;
#else
	union
	{
		float aa{0};
		unsigned short a_[2];
	};
	a_[1] = a.v_;
	union
	{
		float bb{0};
		unsigned short b_[2];
	};
	b_[1] = b.v_;

	return aa >= bb;
#endif
}
