#ifndef RPP_PERF_H
#define RPP_PERF_H

#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdarg.h>
#include <inttypes.h>

#ifdef _WIN32
#   ifndef WIN32_LEAN_AND_MEAN
#       define WIN32_LEAN_AND_MEAN
#   endif
#   include <windows.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

// ==================== 跨平台兼容宏 ====================
#ifdef _WIN32
#   if defined(RPP_STATIC)
#       define RPP_API
#   elif defined(RPP_EXPORTS)
#       define RPP_API __declspec(dllexport)
#   else
#       define RPP_API __declspec(dllimport)
#   endif
#   define RPP_ALIGNED(x) __declspec(align(x))
#   define RPP_INLINE __inline
#   define RPP_TLS __declspec(thread)
#   define RPP_ATOMIC_INT volatile long
#   define rpp_atomic_inc(p) InterlockedIncrement(p)
#   define rpp_atomic_dec(p) InterlockedDecrement(p)
#   define rpp_atomic_load(p) InterlockedCompareExchange(p, 0, 0)
#   define RPP_FUNC_NAME    __FUNCTION__
#   define RPP_FILE_NAME    __FILE__
#else
#   define RPP_API __attribute__((visibility("default")))
#   define RPP_ALIGNED(x) __attribute__((aligned(x)))
#   define RPP_INLINE static inline
#   define RPP_TLS __thread
#   define RPP_ATOMIC_INT volatile int
#   define rpp_atomic_inc(p) __sync_add_and_fetch(p, 1)
#   define rpp_atomic_dec(p) __sync_sub_and_fetch(p, 1)
#   define rpp_atomic_load(p) __sync_fetch_and_add(p, 0)
#   define RPP_FUNC_NAME    __func__
#   define RPP_FILE_NAME    __FILE__
#endif


// ==================== 事件 phase 宏与字符串（Chrome Trace ph 单字符） ====================
// #define RPP_EVENT_PHASE_B    "B"
// #define RPP_EVENT_PHASE_E    "E"
// #define RPP_EVENT_PHASE_X    "X"
// #define RPP_EVENT_PHASE_I    "i"
// #define RPP_EVENT_PHASE_C    "C"
// #define RPP_EVENT_PHASE_A_B  "b"
// #define RPP_EVENT_PHASE_A_S  "n"
// #define RPP_EVENT_PHASE_A_E  "e"
// #define RPP_EVENT_PHASE_F_B  "s"
// #define RPP_EVENT_PHASE_F_S  "t"
// #define RPP_EVENT_PHASE_F_E  "f"
// #define RPP_EVENT_PHASE_M    "M"
#define RPP_EVENT_PHASE_D    "DURATION_B_E_X"
#define RPP_EVENT_PHASE_I    "INSTANT_i_g_p_t"
#define RPP_EVENT_PHASE_C    "COUNTER_C"
#define RPP_EVENT_PHASE_A    "ASYNC_b_n_e"
#define RPP_EVENT_PHASE_F    "FLOW_s_t_f"
#define RPP_EVENT_PHASE_M    "METADATA_M_P_T"

// ==================== 枚举类型定义 ====================
typedef enum {
    RPP_EVENT_B    = 1,
    RPP_EVENT_E,
    RPP_EVENT_X,
    RPP_EVENT_I_G,
    RPP_EVENT_I_P,
    RPP_EVENT_I_T,
    RPP_EVENT_C,
    RPP_EVENT_A_B,
    RPP_EVENT_A_S,
    RPP_EVENT_A_E,
    RPP_EVENT_F_B,
    RPP_EVENT_F_S,
    RPP_EVENT_F_E,
    RPP_EVENT_M_P,
    RPP_EVENT_M_T,
    RPP_EVENT_MAX
} rpp_event_e;

// ==================== 可配置宏 ====================
#define RPP_MAX_EVENT_NAME_LEN              64 
#define RPP_MAX_CATEGORY_NAME_LEN           64 
#define RPP_MAX_TEMPLATE_NAME_LEN           64 
#define RPP_MAX_THREAD_NUM                  128                                                                // 最大支持线程数
#define RPP_MAX_THREAD_EVENT_LEN            256                                                                // 最大支持缓存事件记录数量每个线程
#define RPP_RING_BUF_NUM                    10                                                                 // 每 slot 环缓冲个数，缓解生产/消费速度不一致时的阻塞
#define RPP_FLUSH_WORKER_MAX                16                                                                 // flush 工作线程数上限（编译期定长数组）
#define RPP_FLUSH_WORKERS_DEFAULT           4                                                                  // 默认 flush 线程数（可通过 rpp_perf_flush_set_worker_count 在 init 前修改）
#define RPP_FLUSH_IO_BATCH_EVENTS_DEFAULT   RPP_MAX_THREAD_EVENT_LEN                                                                 // 默认同一文件、单次加锁批量写入的最大事件数
#define RPP_FLUSH_IO_BATCH_BYTES_DEFAULT    ((size_t)(RPP_MAX_THREAD_EVENT_LEN * 1024))                                            // 默认同一批次序列化字节上限（防单条过大撑爆批次）
/** 传给 rpp_perf_flush_set_cpu_affinity：该 flush worker 不绑核（不调用 SetThreadAffinity / sched_setaffinity） */
#define RPP_FLUSH_CPU_DISABLE               ((int)(-1))
#define RPP_MAX_WINDOWS                     64                                                                 // 最大Window数
#define RPP_MAX_META_ENTRIES                (RPP_EVENT_MAX + 64)                                               // 最大模板数
#define RPP_MAX_EVENT_ARGS                  8                                                                  // 单事件最大参数数
#define RPP_STR_RING_LEN                    (RPP_MAX_THREAD_EVENT_LEN * RPP_FLUSH_WORKER_MAX * RPP_MAX_EVENT_ARGS)                                      // 每 slot string 参数 ring 长度，按 event 上限*2（每 event 最多约 2 个 string）
#define RPP_DROP_ON_FULL                    1                                                                  // 缓冲区满时丢弃事件（0=自旋等待）
#define RPP_DEF_EVENT_NUM                   (RPP_MAX_THREAD_NUM * RPP_MAX_THREAD_EVENT_LEN * RPP_MAX_META_ENTRIES)// 默认每个window最大事件数:线程数 * 每个线程最大事件数 * 模板数
#define RPP_MAX_EVENT_ARGS_SKELETON         (64)                                     // 64字节关键字段骨架字符串长度 + 32*8字节参数骨架字符串长度

// ==================== 基础常量定义 ====================
// PIPE_BUF
#ifdef _WIN32
#define RPP_PIPE_BUF             512
#else
#define RPP_PIPE_BUF             4096
#endif
// MACRO
#define RPP_STRINGIFY_INNER(x)  #x
#define RPP_STRINGIFY(x)        RPP_STRINGIFY_INNER(x)
/* 默认 category：file:func:line 格式（编译期字符串拼接） */
// #define RPP_DEFAULT_NAME          __FILE__ ":" RPP_FUNC_NAME ":" RPP_STRINGIFY(__LINE__)
#define RPP_DEFAULT_NAME          __FILE__ ":" RPP_FUNC_NAME
#define RPP_DEFAULT_HOST_CAT_A   "host"
#define RPP_DEFAULT_DEV_CAT_A    "device"
#define RPP_DEFAULT_WIN_ID       ((uint32_t)1)
#define RPP_INVALID_WID          ((uint32_t)0)
#define RPP_INVALID_TLP          ((uint32_t)0)
#define RPP_INVALID_PID          ((uint32_t)0)
#define RPP_INVALID_TID          ((uint32_t)0)
#define RPP_INVALID_TS           ((uint64_t)0)
#define RPP_INVALID_DUR          ((uint64_t)0)
#define RPP_INVALID_ID           ((uint32_t)0)
#define RPP_INVALID_SCOPE        ((uint8_t)0)
#define RPP_INVALID_NAME         ((const char*)NULL)

typedef enum {
    RPP_TYPE_MIN      = 0,
    RPP_TYPE_I32      = 0,
    RPP_TYPE_U32      = 1,
    RPP_TYPE_I64      = 2,
    RPP_TYPE_U64      = 3,
    RPP_TYPE_FLOAT    = 4,
    RPP_TYPE_RATE     = 5,
    RPP_TYPE_STR_COPY = 6,
    RPP_TYPE_X64      = 7,
    RPP_TYPE_MAX 
} rpp_arg_type_e;

static const char* const g_rpp_arg_fmt[RPP_TYPE_MAX] = {
#if defined(_WIN32) || defined(_WIN64)
    "%" PRIi32,
    "%" PRIu32,
    "%" PRIi64,
    "%" PRIu64,
    "%.6f",
    "%.6f%%",
    "\"%s\"",
    "\"%s\"",
    // "%" PRIx64,
#else
    [RPP_TYPE_I32]      = "%" PRIi32,
    [RPP_TYPE_U32]      = "%" PRIu32,
    [RPP_TYPE_I64]      = "%" PRIi64,
    [RPP_TYPE_U64]      = "%" PRIu64,
    [RPP_TYPE_FLOAT]    = "%.6f",
    [RPP_TYPE_RATE]     = "%.6f%%",
    [RPP_TYPE_STR_COPY] = "\"%s\"",
    [RPP_TYPE_X64]      = "\"%s\"",
    // [RPP_TYPE_X64]      = "%" PRIx64,
#endif
};

typedef enum {
    RPP_REQUIRE_NAME = 1 << 0,
    RPP_REQUIRE_CAT  = 1 << 1,
    RPP_REQUIRE_PID  = 1 << 2,
    RPP_REQUIRE_TID  = 1 << 3,
    RPP_REQUIRE_TS   = 1 << 4,
    RPP_REQUIRE_DUR  = 1 << 5,
    RPP_REQUIRE_ID   = 1 << 6,
    RPP_REQUIRE_SCOPE= 1 << 7,
    RPP_REQUIRE_ARGS = 1 << 8,
} rpp_require_mask_e;

#define RPP_REQUIRE_DURATION_DEF (RPP_REQUIRE_ARGS)
#define RPP_REQUIRE_DURATION_USER (RPP_REQUIRE_PID | RPP_REQUIRE_TID | RPP_REQUIRE_TS | RPP_REQUIRE_ARGS)
#define RPP_REQUIRE_COMPLETE_DEF (RPP_REQUIRE_DUR | RPP_REQUIRE_ARGS)
#define RPP_REQUIRE_COMPLETE_USER (RPP_REQUIRE_PID | RPP_REQUIRE_TID | RPP_REQUIRE_TS | RPP_REQUIRE_DUR | RPP_REQUIRE_ARGS)
#define RPP_REQUIRE_INSTANT_DEF (RPP_REQUIRE_ARGS)
#define RPP_REQUIRE_INSTANT_USER (RPP_REQUIRE_PID | RPP_REQUIRE_TID | RPP_REQUIRE_TS | RPP_REQUIRE_ARGS)
#define RPP_REQUIRE_COUNTER_DEF (RPP_REQUIRE_ARGS)
#define RPP_REQUIRE_COUNTER_USER (RPP_REQUIRE_PID | RPP_REQUIRE_TID | RPP_REQUIRE_TS | RPP_REQUIRE_ARGS)
#define RPP_REQUIRE_ASYNC_DEF (RPP_REQUIRE_ID | RPP_REQUIRE_ARGS)
#define RPP_REQUIRE_ASYNC_USER (RPP_REQUIRE_PID | RPP_REQUIRE_TID | RPP_REQUIRE_TS | RPP_REQUIRE_ID | RPP_REQUIRE_ARGS)
#define RPP_REQUIRE_FLOW_DEF (RPP_REQUIRE_ID | RPP_REQUIRE_ARGS)
#define RPP_REQUIRE_FLOW_USER (RPP_REQUIRE_PID | RPP_REQUIRE_TID | RPP_REQUIRE_TS | RPP_REQUIRE_ID | RPP_REQUIRE_ARGS)
#define RPP_REQUIRE_META_DEF (RPP_REQUIRE_ARGS)
#define RPP_REQUIRE_META_USER (RPP_REQUIRE_PID | RPP_REQUIRE_TID | RPP_REQUIRE_ARGS)

typedef enum {
    RPP_EVENT_SCOPE_GLOBAL  = 'g',
    RPP_EVENT_SCOPE_PROCESS = 'p',
    RPP_EVENT_SCOPE_THREAD  = 't',
} rpp_event_scope_e;

// ====================== 编译期预定义公共字段模板 ======================
// 固定公共字段模板：ph/C事件类型、名称、pid、tid、ts，提前编译为静态字符串
//仅当整数部分超过2^53（约16位十进制整数）时，double本身就已经无法精确存储该整数，无论用什么格式符格式化都会出现精度损失，这是double类型的固有特性，和%.3f无关。
#define RPP_EVENT_START_INIT "\n\t\t{"
#define RPP_EVENT_START ",\n\t\t{"
#define RPP_EVENT_END "}"
/* ts/dur 用 %.3f 固定小数，避免 %.3g 在较大数值时输出科学计数法（如 1.09e+04） */
#define RPP_EVENT_F_D_B "\"ph\":\"B\",\"name\":\"%s\",\"cat\":\"%s\",\"pid\":%" PRIu32 ",\"tid\":%" PRIu32 ",\"ts\":%.5f"
#define RPP_EVENT_F_D_E "\"ph\":\"E\",\"name\":\"%s\",\"cat\":\"%s\",\"pid\":%" PRIu32 ",\"tid\":%" PRIu32 ",\"ts\":%.5f"
#define RPP_EVENT_F_D_X "\"ph\":\"X\",\"name\":\"%s\",\"cat\":\"%s\",\"pid\":%" PRIu32 ",\"tid\":%" PRIu32 ",\"ts\":%.5f,\"dur\":%.3f"
#define RPP_EVENT_F_I_G "\"ph\":\"i\",\"name\":\"%s\",\"cat\":\"%s\",\"pid\":%" PRIu32 ",\"tid\":%" PRIu32 ",\"ts\":%.5f,\"s\":\"g\""
#define RPP_EVENT_F_I_P "\"ph\":\"i\",\"name\":\"%s\",\"cat\":\"%s\",\"pid\":%" PRIu32 ",\"tid\":%" PRIu32 ",\"ts\":%.5f,\"s\":\"p\""
#define RPP_EVENT_F_I_T "\"ph\":\"i\",\"name\":\"%s\",\"cat\":\"%s\",\"pid\":%" PRIu32 ",\"tid\":%" PRIu32 ",\"ts\":%.5f,\"s\":\"t\""
#define RPP_EVENT_F_C   "\"ph\":\"C\",\"name\":\"%s\",\"cat\":\"%s\",\"pid\":%" PRIu32 ",\"tid\":%" PRIu32 ",\"ts\":%.5f"//! todo默认带上value对应的args
#define RPP_EVENT_F_A_B "\"ph\":\"b\",\"name\":\"%s\",\"cat\":\"%s\",\"pid\":%" PRIu32 ",\"tid\":%" PRIu32 ",\"ts\":%.5f,\"id\":%" PRIu32 ""
#define RPP_EVENT_F_A_S "\"ph\":\"n\",\"name\":\"%s\",\"cat\":\"%s\",\"pid\":%" PRIu32 ",\"tid\":%" PRIu32 ",\"ts\":%.5f,\"id\":%" PRIu32 ""
#define RPP_EVENT_F_A_E "\"ph\":\"e\",\"name\":\"%s\",\"cat\":\"%s\",\"pid\":%" PRIu32 ",\"tid\":%" PRIu32 ",\"ts\":%.5f,\"id\":%" PRIu32 ""
#define RPP_EVENT_F_F_B "\"ph\":\"s\",\"name\":\"%s\",\"cat\":\"%s\",\"pid\":%" PRIu32 ",\"tid\":%" PRIu32 ",\"ts\":%.5f,\"id\":%" PRIu32 ""
#define RPP_EVENT_F_F_S "\"ph\":\"t\",\"name\":\"%s\",\"cat\":\"%s\",\"pid\":%" PRIu32 ",\"tid\":%" PRIu32 ",\"ts\":%.5f,\"id\":%" PRIu32 ""
#define RPP_EVENT_F_F_E "\"ph\":\"f\",\"name\":\"%s\",\"cat\":\"%s\",\"pid\":%" PRIu32 ",\"tid\":%" PRIu32 ",\"ts\":%.5f,\"id\":%" PRIu32 ""
#define RPP_EVENT_F_M_P "\"ph\":\"M\",\"name\":\"process_name\",\"pid\":%" PRIu32 ""
#define RPP_EVENT_F_M_T "\"ph\":\"M\",\"name\":\"thread_name\",\"pid\":%" PRIu32 ",\"tid\":%" PRIu32 ""
#define RPP_ARGS_START ",\"args\":{"
#define RPP_ARGS_END "}"

// ==================== 对外API声明 ====================
RPP_API void rpp_perf_set_trace_dir(const char* dir);
RPP_API void rpp_perf_release(void);

RPP_API uint32_t rpp_perf_init(const char* prefix);
/** 以指定 win_id 追加写入已有文件（server/client 同文件时 client 调用）；不写 header，首条事件带逗号。需与 server 约定同一 win_id 与路径。 */
RPP_API uint32_t rpp_perf_attach(uint32_t win_id, const char* path, uint64_t ts);
RPP_API uint32_t rpp_perf_deinit(uint32_t win_id);
RPP_API uint32_t rpp_perf_enable(uint32_t win_id);
RPP_API uint32_t rpp_perf_disable(uint32_t win_id);

RPP_API uint32_t rpp_perf_register_template(uint32_t require_mask, uint32_t arg_count, ...);
RPP_API uint32_t rpp_perf_unregister_template(uint32_t tpl_id);

RPP_API uint32_t rpp_perf_get_window_event_count(uint32_t win_id);
RPP_API uint64_t rpp_perf_now_ns(void);
RPP_API uint64_t rpp_perf_init_ns(uint32_t win_id);
RPP_API const char* rpp_perf_win_path(uint32_t win_id);

RPP_API void rpp_perf_show_window(uint32_t win_id);
RPP_API void rpp_perf_show_template(uint32_t tpl_id);
RPP_API void rpp_perf_flush_count(unsigned int worker_count);
RPP_API void rpp_perf_flush_batch(unsigned int max_events, size_t max_bytes);
RPP_API void rpp_perf_flush_cpu(unsigned int worker_index, int cpu_core);

RPP_API bool _rpp_perf_enabled(uint32_t win_id);
RPP_API void _rpp_perf_write_internal(uint32_t win_id, rpp_event_e phase, uint32_t tpl_id, const char* name, const char* cat,
                                       uint32_t pid, uint32_t tid, uint64_t ts_ns, uint64_t dur_ns,
                                       uint32_t id, ...);

// ==================== 注册宏定义 ====================
//! default template without user args
#define TRACE_REGISTER_DURATION_DEF(name, count, ...) rpp_perf_register_template(name, (uint32_t)RPP_REQUIRE_DURATION_DEF, (uint32_t)count, ##__VA_ARGS__); 
#define TRACE_REGISTER_COMPLETE_DEF(name, count, ...) rpp_perf_register_template(name, (uint32_t)RPP_REQUIRE_COMPLETE_DEF, (uint32_t)count, ##__VA_ARGS__); 
#define TRACE_REGISTER_INSTANT_DEF(name, count, ...) rpp_perf_register_template(name, (uint32_t)RPP_REQUIRE_INSTANT_DEF, (uint32_t)count, ##__VA_ARGS__); 
#define TRACE_REGISTER_COUNTER_DEF(name, count, ...) rpp_perf_register_template(name, (uint32_t)RPP_REQUIRE_COUNTER_DEF, (uint32_t)count, ##__VA_ARGS__); 
#define TRACE_REGISTER_ASYNC_DEF(name, count, ...) rpp_perf_register_template(name, (uint32_t)RPP_REQUIRE_ASYNC_DEF, (uint32_t)count, ##__VA_ARGS__); 
#define TRACE_REGISTER_FLOW_DEF(name, count, ...) rpp_perf_register_template(name, (uint32_t)RPP_REQUIRE_FLOW_DEF, (uint32_t)count, ##__VA_ARGS__); 
//! default template with user args
#define TRACE_REGISTER_DURATION_USER(name, count, ...) rpp_perf_register_template(name, (uint32_t)RPP_REQUIRE_DURATION_USER, (uint32_t)count, ##__VA_ARGS__); 
#define TRACE_REGISTER_COMPLETE_USER(name, count, ...) rpp_perf_register_template(name, (uint32_t)RPP_REQUIRE_COMPLETE_USER, (uint32_t)count, ##__VA_ARGS__); 
#define TRACE_REGISTER_INSTANT_USER(name, count, ...) rpp_perf_register_template(name, (uint32_t)RPP_REQUIRE_INSTANT_USER, (uint32_t)count, ##__VA_ARGS__); 
#define TRACE_REGISTER_COUNTER_USER(name, count, ...) rpp_perf_register_template(name, (uint32_t)RPP_REQUIRE_COUNTER_USER, (uint32_t)count, ##__VA_ARGS__); 
#define TRACE_REGISTER_ASYNC_USER(name, count, ...) rpp_perf_register_template(name, (uint32_t)RPP_REQUIRE_ASYNC_USER, (uint32_t)count, ##__VA_ARGS__); 
#define TRACE_REGISTER_FLOW_USER(name, count, ...) rpp_perf_register_template(name, (uint32_t)RPP_REQUIRE_FLOW_USER, (uint32_t)count, ##__VA_ARGS__); 

// ==================== 埋点宏定义 ====================
#define TRACE_START(name) (uint32_t)rpp_perf_init((name))
#define TRACE_ENABLE(win)  (uint32_t)rpp_perf_enable(win)
#define TRACE_DISABLE(win)  (uint32_t)rpp_perf_disable(win)
#define TRACE_END()  (void)rpp_perf_release()
#define TRACE_END_ALL()  (void)rpp_perf_release()

#define TRACE_COUNT(win)  (uint32_t)rpp_perf_get_window_event_count(win)

#define TRACE_SHOW_WINDOW(win)  (void)rpp_perf_show_window(win)
#define TRACE_SHOW_TEMPLATE(tlp)  (void)rpp_perf_show_template(tlp)

#define TRACE_NOW_NS()  (uint64_t)rpp_perf_now_ns()
#define TRACE_TIME_NS(win)  (uint64_t)rpp_perf_init_ns(win)

//! duration
// FOR DRV_API
#define TRACE_SCOPE(win, name) \
    do { \
        if (!_rpp_perf_enabled(win)) break; \
        _rpp_perf_write_internal((uint32_t)(win), RPP_EVENT_B, (uint32_t)(RPP_EVENT_B), name, RPP_EVENT_PHASE_D, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, RPP_INVALID_ID); \
    } while(0)
#define TRACE_SCOPE_END(win, name) \
    do { \
        if (!_rpp_perf_enabled(win)) break; \
        _rpp_perf_write_internal((uint32_t)(win), RPP_EVENT_E, (uint32_t)(RPP_EVENT_E), name, RPP_EVENT_PHASE_D, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, RPP_INVALID_ID); \
    } while(0)

#define TRACE_FUNC() \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_B, (uint32_t)(RPP_EVENT_B), RPP_FUNC_NAME, RPP_EVENT_PHASE_D, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, RPP_INVALID_ID); \
    } while(0)
#define TRACE_FUNC_END() \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_E, (uint32_t)(RPP_EVENT_E), RPP_FUNC_NAME, RPP_EVENT_PHASE_D, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, RPP_INVALID_ID); \
    } while(0)
#define TRACE_FUNC_CATE(name, cate) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_B, (uint32_t)(RPP_EVENT_B), name, cate, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, RPP_INVALID_ID); \
    } while(0)
#define TRACE_FUNC_END_CATE(name, cate) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_E, (uint32_t)(RPP_EVENT_E), name, cate, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, RPP_INVALID_ID); \
    } while(0)
#define TRACE_SCOPE_ARGS(win, tlp, name, cate, pid, tid, ts_ns, ...) \
    do { \
        if (!_rpp_perf_enabled(win)) break; \
        _rpp_perf_write_internal((uint32_t)win, RPP_EVENT_B, (uint32_t)tlp, name, cate, (uint32_t)pid, (uint32_t)tid, (uint64_t)ts_ns, RPP_INVALID_DUR, RPP_INVALID_ID, ##__VA_ARGS__); \
    } while(0)
#define TRACE_SCOPE_ARGS_END(win, tlp, name, cate, ...) \
    do { \
        if (!_rpp_perf_enabled(win)) break; \
        _rpp_perf_write_internal((uint32_t)win, RPP_EVENT_E, (uint32_t)tlp, name, cate, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, RPP_INVALID_ID, ##__VA_ARGS__); \
    } while(0)

#define TRACE_COMPLETE(dur_ns) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_X, (uint32_t)(RPP_EVENT_X), RPP_FUNC_NAME, RPP_EVENT_PHASE_D, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, (uint64_t)dur_ns, RPP_INVALID_ID); \
    } while(0)
#define TRACE_COMPLETE_CATE(name, cate, dur_ns) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_X, (uint32_t)(RPP_EVENT_X), name, cate, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, (uint64_t)dur_ns, RPP_INVALID_ID); \
    } while(0)
#define TRACE_COMPLETE_ARGS(win, tlp, name, cate, pid, tid, ts_ns, dur_ns, ...) \
    do { \
        if (!_rpp_perf_enabled(win)) break; \
        _rpp_perf_write_internal((uint32_t)win, RPP_EVENT_X, (uint32_t)tlp, name, cate, (uint32_t)pid, (uint32_t)tid, (uint64_t)ts_ns,  (uint64_t)dur_ns, RPP_INVALID_ID, ##__VA_ARGS__); \
    } while(0)

//! instant
#define TRACE_INSTANT_G() \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_I_G, (uint32_t)(RPP_EVENT_I_G), RPP_FUNC_NAME, RPP_EVENT_PHASE_I, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, RPP_INVALID_ID); \
    } while(0)
#define TRACE_INSTANT_G_CATE(name, cate) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_I_G, (uint32_t)(RPP_EVENT_I_G), name, cate, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, RPP_INVALID_ID); \
    } while(0)
#define TRACE_INSTANT_G_ARGS(win, tlp, name, cate, pid, tid, ts_ns, ...) \
    do { \
        if (!_rpp_perf_enabled(win)) break; \
        _rpp_perf_write_internal((uint32_t)win, RPP_EVENT_I_G, (uint32_t)tlp, name, cate, (uint32_t)pid, (uint32_t)tid, (uint64_t)ts_ns,  RPP_INVALID_DUR, RPP_INVALID_ID, ##__VA_ARGS__); \
    } while(0)

#define TRACE_INSTANT_P() \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_I_P, (uint32_t)(RPP_EVENT_I_P), RPP_FUNC_NAME, RPP_EVENT_PHASE_I, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, RPP_INVALID_ID); \
    } while(0)
#define TRACE_INSTANT_P_CATE(name, cate) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_I_P, (uint32_t)(RPP_EVENT_I_P), name, cate, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, RPP_INVALID_ID); \
    } while(0)
#define TRACE_INSTANT_P_ARGS(win, tlp, name, cate, pid, tid, ts_ns, ...) \
    do { \
        if (!_rpp_perf_enabled(win)) break; \
        _rpp_perf_write_internal((uint32_t)win, RPP_EVENT_I_P, (uint32_t)tlp, name, cate, (uint32_t)pid, (uint32_t)tid, (uint64_t)ts_ns,  RPP_INVALID_DUR, RPP_INVALID_ID, ##__VA_ARGS__); \
    } while(0)

#define TRACE_INSTANT_T() \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_I_T, (uint32_t)(RPP_EVENT_I_T), RPP_FUNC_NAME, RPP_EVENT_PHASE_I, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, RPP_INVALID_ID); \
    } while(0)
#define TRACE_INSTANT_T_CATE(name, cate) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_I_T, (uint32_t)(RPP_EVENT_I_T), name, cate, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, RPP_INVALID_ID); \
    } while(0)
#define TRACE_INSTANT_T_ARGS(win, tlp, name, cate, pid, tid, ts_ns, ...) \
    do { \
        if (!_rpp_perf_enabled(win)) break; \
        _rpp_perf_write_internal((uint32_t)win, RPP_EVENT_I_T, (uint32_t)tlp, name, cate, (uint32_t)pid, (uint32_t)tid, (uint64_t)ts_ns,  RPP_INVALID_DUR, RPP_INVALID_ID, ##__VA_ARGS__); \
    } while(0)

//! counter
#define TRACE_COUNTER(val) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_C, (uint32_t)(RPP_EVENT_C), RPP_FUNC_NAME, RPP_EVENT_PHASE_C, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, RPP_INVALID_ID, (uint32_t)val); \
    } while(0)
#define TRACE_COUNTER_CATE(name, cate, val) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_C, (uint32_t)(RPP_EVENT_C), name, cate, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, RPP_INVALID_ID, (uint32_t)val); \
    } while(0)
#define TRACE_COUNTER_ARGS(win, tlp, name, cate, pid, tid, ts_ns, ...) \
    do { \
        if (!_rpp_perf_enabled(win)) break; \
        _rpp_perf_write_internal((uint32_t)win, RPP_EVENT_C, (uint32_t)tlp, name, cate, (uint32_t)pid, (uint32_t)tid, (uint64_t)ts_ns, RPP_INVALID_DUR, RPP_INVALID_ID, ##__VA_ARGS__); \
    } while(0)

//! async
#define TRACE_ASYNC_B(id) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_A_B, (uint32_t)(RPP_EVENT_A_B), RPP_FUNC_NAME, RPP_EVENT_PHASE_A, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, (uint32_t)id); \
    } while(0)
#define TRACE_ASYNC_B_CATE(name, cate, id) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_A_B, (uint32_t)(RPP_EVENT_A_B), name, cate, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, (uint32_t)id); \
    } while(0)
#define TRACE_ASYNC_B_ARGS(win, tlp, name, cate, pid, tid, ts_ns, id, ...) \
    do { \
        if (!_rpp_perf_enabled(win)) break; \
        _rpp_perf_write_internal((uint32_t)win, RPP_EVENT_A_B, (uint32_t)tlp, name, cate, (uint32_t)pid, (uint32_t)tid, (uint64_t)ts_ns,  RPP_INVALID_DUR, (uint32_t)id, ##__VA_ARGS__); \
    } while(0)


#define TRACE_ASYNC_S(id) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_A_S, (uint32_t)(RPP_EVENT_A_S), RPP_FUNC_NAME, RPP_EVENT_PHASE_A, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, (uint32_t)id); \
    } while(0)
#define TRACE_ASYNC_S_CATE(name, cate, id) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_A_S, (uint32_t)(RPP_EVENT_A_S), name, cate, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, (uint32_t)id); \
    } while(0)
#define TRACE_ASYNC_S_ARGS(win, tlp, name, cate, pid, tid, ts_ns, id, ...) \
    do { \
        if (!_rpp_perf_enabled(win)) break; \
        _rpp_perf_write_internal((uint32_t)win, RPP_EVENT_A_S, (uint32_t)tlp, name, cate, (uint32_t)pid, (uint32_t)tid, (uint64_t)ts_ns,  RPP_INVALID_DUR, (uint32_t)id, ##__VA_ARGS__); \
    } while(0)


#define TRACE_ASYNC_E(id) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_A_E, (uint32_t)(RPP_EVENT_A_E), RPP_FUNC_NAME, RPP_EVENT_PHASE_A, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, (uint32_t)id); \
    } while(0)
#define TRACE_ASYNC_E_CATE(name, cate, id) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_A_E, (uint32_t)(RPP_EVENT_A_E), name, cate, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, (uint32_t)id); \
    } while(0)
#define TRACE_ASYNC_E_ARGS(win, tlp, name, cate, pid, tid, ts_ns, id, ...) \
    do { \
        if (!_rpp_perf_enabled(win)) break; \
        _rpp_perf_write_internal((uint32_t)win, RPP_EVENT_A_E, (uint32_t)tlp, name, cate, (uint32_t)pid, (uint32_t)tid, (uint64_t)ts_ns,  RPP_INVALID_DUR, (uint32_t)id, ##__VA_ARGS__); \
    } while(0)

//! flow
#define TRACE_FLOW_B(id) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_F_B, (uint32_t)(RPP_EVENT_F_B), RPP_FUNC_NAME, RPP_EVENT_PHASE_F, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, (uint32_t)id); \
    } while(0)
#define TRACE_FLOW_B_CATE(name, cate, id) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_F_B, (uint32_t)(RPP_EVENT_F_B), name, cate, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, (uint32_t)id); \
    } while(0)
#define TRACE_FLOW_B_ARGS(win, tlp, name, cate, pid, tid, ts_ns, id, ...) \
    do { \
        if (!_rpp_perf_enabled(win)) break; \
        _rpp_perf_write_internal((uint32_t)win, RPP_EVENT_F_B, (uint32_t)tlp, name, cate, (uint32_t)pid, (uint32_t)tid, (uint64_t)ts_ns,  RPP_INVALID_DUR, (uint32_t)id, ##__VA_ARGS__); \
    } while(0)


#define TRACE_FLOW_S(id) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_F_S, (uint32_t)(RPP_EVENT_F_S), RPP_FUNC_NAME, RPP_EVENT_PHASE_F, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, (uint32_t)id); \
    } while(0)
#define TRACE_FLOW_S_CATE(name, cate, id) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_F_S, (uint32_t)(RPP_EVENT_F_S), name, cate, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, (uint32_t)id); \
    } while(0)
#define TRACE_FLOW_S_ARGS(win, tlp, pid, tid, ts_ns, id, ...) \
    do { \
        if (!_rpp_perf_enabled(win)) break; \
        _rpp_perf_write_internal((uint32_t)win, RPP_EVENT_F_S, (uint32_t)tlp, RPP_DEFAULT_NAME, RPP_EVENT_PHASE_F, (uint32_t)pid, (uint32_t)tid, (uint64_t)ts_ns,  RPP_INVALID_DUR, (uint32_t)id, ##__VA_ARGS__); \
    } while(0)


#define TRACE_FLOW_E(id) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_F_E, (uint32_t)(RPP_EVENT_F_E), RPP_FUNC_NAME, RPP_EVENT_PHASE_F, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, (uint32_t)id); \
    } while(0)
#define TRACE_FLOW_E_CATE(name, cate, id) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_F_E, (uint32_t)(RPP_EVENT_F_E), name, cate, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, (uint32_t)id); \
    } while(0)
#define TRACE_FLOW_E_ARGS(win, tlp, pid, tid, ts_ns, id, ...) \
    do { \
        if (!_rpp_perf_enabled(win)) break; \
        _rpp_perf_write_internal((uint32_t)win, RPP_EVENT_F_E, (uint32_t)tlp, RPP_DEFAULT_NAME, RPP_EVENT_PHASE_F, (uint32_t)pid, (uint32_t)tid, (uint64_t)ts_ns,  RPP_INVALID_DUR, (uint32_t)id, ##__VA_ARGS__); \
    } while(0)

// ==================== Metadata Event 宏定义 ====================

#define TRACE_META_P(name) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_M_P, (uint32_t)(RPP_EVENT_M_P), RPP_INVALID_NAME, RPP_INVALID_NAME, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, RPP_INVALID_ID, name); \
    } while(0)
#define TRACE_META_P_ARGS(win, tlp, pid, name, ...) \
    do { \
        if (!_rpp_perf_enabled(win)) break; \
        _rpp_perf_write_internal((uint32_t)win, RPP_EVENT_M_P, (uint32_t)tlp, RPP_INVALID_NAME, RPP_INVALID_NAME, (uint32_t)pid, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, RPP_INVALID_ID, name, ##__VA_ARGS__); \
    } while(0)

#define TRACE_META_T(name) \
    do { \
        if (!_rpp_perf_enabled(RPP_DEFAULT_WIN_ID)) break; \
        _rpp_perf_write_internal(RPP_DEFAULT_WIN_ID, RPP_EVENT_M_T, (uint32_t)(RPP_EVENT_M_T), RPP_INVALID_NAME, RPP_INVALID_NAME, RPP_INVALID_PID, RPP_INVALID_TID, RPP_INVALID_TS, RPP_INVALID_DUR, RPP_INVALID_ID, name); \
    } while(0)
#define TRACE_META_T_ARGS(win, tlp, pid, tid, name, ...) \
    do { \
        if (!_rpp_perf_enabled(win)) break; \
        _rpp_perf_write_internal((uint32_t)win, RPP_EVENT_M_T, (uint32_t)tlp, RPP_INVALID_NAME, RPP_INVALID_NAME, (uint32_t)pid, (uint32_t)tid, RPP_INVALID_TS, RPP_INVALID_DUR, RPP_INVALID_ID, name, ##__VA_ARGS__); \
    } while(0)


#define RPP_TRACE_BY_ID(win, phase, tpl_id, name, cat, pid, tid, ts_ns, dur_ns, id, ...) \
    do { \
        if (!_rpp_perf_enabled(win)) break; \
        _rpp_perf_write_internal((uint32_t)win, phase, tpl_id, name, cat, pid, tid, ts_ns, dur_ns, id, ##__VA_ARGS__); \
    } while(0)


// // ==================== 强制内联核心写入接口 ====================
// __attribute__((always_inline)) static inline void rpp_fast_emit(
//     uint8_t phase, uint32_t tpl_id, const char* name, const char* cat,
//     uint32_t pid, uint32_t tid, uint64_t ts_ns, uint64_t dur_ns,
//     uint32_t id, rpp_fast_arg_t args[RPP_MAX_EVENT_ARGS]) {
//     if (!g_rpp_fast_enabled) return;
//     rpp_fast_ctx_t* ctx = &rpp_fast_tls_ctx;
//     // 直接写入缓冲区，无栈拷贝
//     rpp_fast_event_t* evt = &ctx->buf[ctx->active_buf][ctx->write_idx++];
//     evt->tpl_id = tpl_id;
//     evt->tid = tid ? (uint32_t)tid : (uint32_t)__rdtsc() & 0xFFFF;
// #if RPP_FAST_ENABLE_TS
//     evt->ts = ts_ns ? ts_ns : __rdtsc();
// #endif
// #if RPP_FAST_ENABLE_EXTRA
//     evt->phase = phase;
//     evt->pid = pid;
//     evt->dur_ns = dur_ns;
//     evt->id = (uint32_t)id;
//     if (name) __builtin_strncpy(evt->name, name, 15);
//     if (cat) __builtin_strncpy(evt->cat, cat, 7);
// #endif
//     // 编译期展开参数拷贝，零循环开销
//     for (int i=0; i<RPP_FAST_ARGS_CNT; i++) evt->args[i] = args[i];
//     // 缓冲区满切换，仅触发异步flush不阻塞
//     if (__builtin_expect(ctx->write_idx >= RPP_FAST_BUF_SIZE, 0)) {
//         __atomic_store_n(&ctx->need_flush, true, __ATOMIC_RELEASE);
//         ctx->active_buf ^= 1;
//         ctx->write_idx = 0;
//     }
// }

/*
// ==================== 对外埋点宏：与100ns版完全一致，业务侧零修改 ====================
#define RPP_EMIT(tpl_id, name, cat, pid, tid, ts, dur, id, ...) do { \
    rpp_fast_arg_t args[] = {__VA_ARGS__}; \
    rpp_fast_emit('C', tpl_id, name, cat, pid, tid, ts, dur, id, 0, args); \
} while(0)
*/

#ifdef __cplusplus
}
#endif

#endif // RPP_PERF_H
