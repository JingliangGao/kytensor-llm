#if !defined(__PTI_RESULT_H__)
#define __PTI_RESULT_H__

#ifndef PTIAPI
#ifdef _WIN32
#define PTIAPI __stdcall
#else 
#define PTIAPI
#endif 
#endif 

#if defined(__cplusplus)
extern "C" {
#endif 

/**
 * \defgroup PTI_RESULT_API PTI Result Codes
 * Error and result codes returned by PTI functions.
 * @{
 */

/**
 * \brief PTI result codes.
 *
 * Error and result codes returned by PTI functions.
 */
typedef enum {
    /**
     * No error.
     */
    PTI_SUCCESS                                       = 0,
    /**
     * One or more of the parameters is invalid.
     */
    PTI_ERROR_INVALID_PARAMETER                       = 1,
    /**
     * The device does not correspond to a valid CUDA device.
     */
    PTI_ERROR_INVALID_DEVICE                          = 2,
    /**
     * The context is NULL or not valid.
     */
    PTI_ERROR_INVALID_CONTEXT                         = 3,
    /**
     * The event domain id is invalid.
     */
    PTI_ERROR_INVALID_EVENT_DOMAIN_ID                 = 4,
    /**
     * The event id is invalid.
     */
    PTI_ERROR_INVALID_EVENT_ID                        = 5,
    /**
     * The event name is invalid.
     */
    PTI_ERROR_INVALID_EVENT_NAME                      = 6,
    /**
     * The current operation cannot be performed due to dependency on
     * other factors.
     */
    PTI_ERROR_INVALID_OPERATION                       = 7,
    /**
     * Unable to allocate enough memory to perform the requested
     * operation.
     */
    PTI_ERROR_OUT_OF_MEMORY                           = 8,
    /**
     * An error occurred on the performance monitoring hardware.
     */
    PTI_ERROR_HARDWARE                                = 9,
    /**
     * The output buffer size is not sufficient to return all
     * requested data.
     */
    PTI_ERROR_PARAMETER_SIZE_NOT_SUFFICIENT           = 10,
    /**
     * API is not implemented. 
     */
    PTI_ERROR_API_NOT_IMPLEMENTED                     = 11,
    /**
     * The maximum limit is reached.
     */
    PTI_ERROR_MAX_LIMIT_REACHED                       = 12,
    /**
     * The object is not yet ready to perform the requested operation.
     */
    PTI_ERROR_NOT_READY                               = 13,
    /**
     * The current operation is not compatible with the current state
     * of the object
     */
    PTI_ERROR_NOT_COMPATIBLE                          = 14,
    /**
     * PTI is unable to initialize its connection to the CUDA
     * driver.
     */
    PTI_ERROR_NOT_INITIALIZED                         = 15,
    /**
     * The metric id is invalid.
     */
    PTI_ERROR_INVALID_METRIC_ID                        = 16,
    /**
     * The metric name is invalid.
     */
    PTI_ERROR_INVALID_METRIC_NAME                      = 17,
    /**
     * The queue is empty.
     */
    PTI_ERROR_QUEUE_EMPTY                              = 18,
    /**
     * Invalid handle (internal?).
     */
    PTI_ERROR_INVALID_HANDLE                           = 19,
    /**
     * Invalid stream.
     */
    PTI_ERROR_INVALID_STREAM                           = 20,
    /**
     * Invalid kind.
     */
    PTI_ERROR_INVALID_KIND                             = 21,
    /**
     * Invalid event value.
     */
    PTI_ERROR_INVALID_EVENT_VALUE                      = 22,
    /**
     * PTI is disabled due to conflicts with other enabled profilers
     */
    PTI_ERROR_DISABLED                                 = 23,
    /**
     * Invalid module.
     */
    PTI_ERROR_INVALID_MODULE                           = 24,
    /**
     * Invalid metric value.
     */
    PTI_ERROR_INVALID_METRIC_VALUE                     = 25,
    /**
     * The performance monitoring hardware is in use by other client.
     */
    PTI_ERROR_HARDWARE_BUSY                            = 26,
    /**
     * The attempted operation is not supported on the current
     * system or device.
     */
    PTI_ERROR_NOT_SUPPORTED                            = 27,
    /**
     * Unified memory profiling is not supported on the system.
     * Potential reason could be unsupported OS or architecture.
     */
    PTI_ERROR_UM_PROFILING_NOT_SUPPORTED               = 28,
    /**
     * Unified memory profiling is not supported on the device
     */
    PTI_ERROR_UM_PROFILING_NOT_SUPPORTED_ON_DEVICE     = 29,
    /**
     * Unified memory profiling is not supported on a multi-GPU
     * configuration without P2P support between any pair of devices
     */
    PTI_ERROR_UM_PROFILING_NOT_SUPPORTED_ON_NON_P2P_DEVICES = 30,
    /**
     * Unified memory profiling is not supported under the
     * Multi-Process Service (MPS) environment. CUDA 7.5 removes this
     * restriction.
     */
    PTI_ERROR_UM_PROFILING_NOT_SUPPORTED_WITH_MPS      = 31,
    /**
    * In CUDA 9.0, devices with compute capability 7.0 don't 
    * support CDP tracing
    */
    PTI_ERROR_CDP_TRACING_NOT_SUPPORTED                = 32,
    /**
     * An unknown internal error has occurred.
     */
    PTI_ERROR_UNKNOWN                                  = 999,
    PTI_ERROR_FORCE_INT                                = 0x7fffffff
} PTIResult;

/**
 * \brief Get the descriptive string for a PTIResult.
 * 
 * Return the descriptive string for a PTIResult in \p *str.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param result The result to get the string for
 * \param str Returns the string
 *
 * \retval PTI_SUCCESS on success
 * \retval PTI_ERROR_INVALID_PARAMETER if \p str is NULL or \p
 * result is not a valid PTIResult
 */
PTIResult PTIAPI ptiGetResultString(PTIResult result, const char **str); 
 
/** @} */ /* END PTI_RESULT_API */

#if defined(__cplusplus)
}
#endif 

#endif /*__PTI_RESULT_H__*/


