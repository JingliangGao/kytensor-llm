#pragma once
#include <rpp_runtime.h>
#include <rpp_drv_api.h>
#include <assert.h>
#include <rpp_smap.h>
#define SRAM_WORKSPACE (22*1024*1024)

typedef struct RppSegDesc_t
{
    uint32_t h;
    uint32_t w;
    uint32_t dev_h;
    uint32_t dev_w;
    uint32_t element_size;
    uint32_t pitch;
    uint32_t dev_pitch;
	void* dev;
}tRppSegDesc;
static bool	segment2d(tRppSegDesc &seg_desc, void* dev, 
    uint32_t h, uint32_t w, uint32_t nr_of_segment_h, uint32_t nr_of_segment_w, int element_size)
{
	seg_desc.dev = dev;
	seg_desc.dev_h = h;
	seg_desc.dev_w = w;
	seg_desc.element_size = element_size;
    seg_desc.h = h / nr_of_segment_h;
    seg_desc.w = w / nr_of_segment_w;
    assert(seg_desc.h * nr_of_segment_h == h);
    assert(seg_desc.w * nr_of_segment_w == w);
    //assert((seg_desc.w % 32) == 0);
    seg_desc.pitch = seg_desc.w * seg_desc.element_size;
    seg_desc.dev_pitch = w * seg_desc.element_size;
	return true;
}
static void*  segm_addr2d(tRppSegDesc &seg_desc, uint32_t id_of_segment_h, uint32_t id_of_segment_w)
{
	int cur_h = id_of_segment_h * seg_desc.h;
	int cur_w = id_of_segment_w * seg_desc.w;
	uint32_t offset = (cur_h * seg_desc.dev_w + cur_w) * seg_desc.element_size;
	void* dev = (void*)((char*)seg_desc.dev + offset);
	return dev;
}
static void BlockDim1d(dim3 &threads, dim3 &blocks, int size)
{
    int x = size;
    while(x >= MAX_BLOCK_SIZE)
    {
        x = x >> 1;
    }
    
    threads.x = x;
    threads.y = 1;
    threads.z = 1;

    blocks.x = size / x;
    blocks.y = 1;
    blocks.z = 1;
    assert(blocks.x  * threads.x  == size);
}
static int height1d(dim3 threads, dim3 blocks)
{
    return (blocks.x);
}

static void BlockDim2d(dim3 &threads, dim3 &blocks, int h, int w, int max_block_size = MAX_BLOCK_SIZE)
{
    if (w < 32) w = 32;
    int w0 = w;
    while(w0 >= max_block_size)
    {
        w0 = w0 >> 1;
    }
    int h0 = h;
    while(w0*h0 >= max_block_size)
    {
        if(h0 & 0x1)
           break;
        h0 = h0 >> 1;
    }
    //make sure there is no tail block
    if(w0 * h0 >= max_block_size)
        h0 = 1;

    threads.x = w0;
    threads.y = h0;
    threads.z = 1;

    blocks.x = w/w0;
    blocks.y = h/h0;
    blocks.z = 1;

    assert(h == threads.y * blocks.y);
    assert(w == threads.x * blocks.x);
}

static void BlockDim2d_NoAlign(dim3 &threads, dim3 &blocks, int h, int w, int max_block_size = MAX_BLOCK_SIZE)
{
    int w0 = w;
    while(w0 >= max_block_size)
    {
        w0 = w0 >> 1;
    }
    int h0 = h;
    while(w0*h0 >= max_block_size)
    {
        if(h0 & 0x1)
           break;
        h0 = h0 >> 1;
    }
    //make sure there is no tail block
    if(w0 * h0 >= max_block_size)
        h0 = 1;

    threads.x = w0;
    threads.y = h0;
    threads.z = 1;

    blocks.x = w/w0;
    blocks.y = h/h0;
    blocks.z = 1;

    assert(h == threads.y * blocks.y);
    assert(w == threads.x * blocks.x);
}

static void BlockDim3d(dim3 &threads, dim3 &blocks, int dim2, int dim1, int dim0, int max_block_size = MAX_BLOCK_SIZE)
{
    if (dim0 < 32) dim0 = 32;
    int m_dim0 = dim0;
    while(m_dim0 >= max_block_size)
    {
        m_dim0 = m_dim0 >> 1;
    }
    int m_dim1 = dim1;
    while(m_dim0 * m_dim1 >= max_block_size)
    {
        if(m_dim1 & 0x1)
           break;
        m_dim1 = m_dim1 >> 1;
    }
    //make sure there is no tail block
    if(m_dim0 * m_dim1 >= max_block_size)
        m_dim1 = 1;

    int m_dim2 = dim2;
    while(m_dim0 * m_dim1 * m_dim2 >= max_block_size)
    {
        if(m_dim2 & 0x1)
           break;
        m_dim2 = m_dim2 >> 1;
    }
    if(m_dim0 * m_dim1 * m_dim2 >= max_block_size)
        m_dim2 = 1;

    threads.x = m_dim0;
    threads.y = m_dim1;
    threads.z = m_dim2;

    blocks.x = dim0 / m_dim0;
    blocks.y = dim1 / m_dim1;
    blocks.z = dim2 / m_dim2;
    printf("tid %d, %d, %d, block %d %d %d \n", threads.x, threads.y, threads.z, blocks.x, blocks.y, blocks.z);
    assert(dim2 == threads.z * blocks.z);
    assert(dim1 == threads.y * blocks.y);
    assert(dim0 == threads.x * blocks.x);
}
