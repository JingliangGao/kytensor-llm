/*!
	\file rtFatBinary.h
	\author Andrew Kerr <arkerr@gatech.edu>
	\brief this was extracted from rpp_runtime.h as these structures are shared by
		both the RPP Runtime API and Driver APIs
*/

#ifndef OCELOT_RPP_RPPFATBINARY_H_INCLUDED
#define OCELOT_RPP_RPPFATBINARY_H_INCLUDED

/*----------------------------------- Types ----------------------------------*/

/*
 * Cubin entry type for __rtFat binary.
 * Cubins are specific to a particular gpu profile,
 * although the gpuInfo module might 'know'
 * that cubins will also run on other gpus.
 * Based on the recompilation strategy,
 * fatGetCubinForGpu will return an existing
 * compatible load image, or attempt a recompilation.
 */
typedef struct {
    char*            gpuProfileName;
    char*            cubin;
} __rtFatCubinEntry;


/*
 * Ptx entry type for __rtFat binary.
 * PTX might use particular chip features
 * (such as double precision floating points).
 * When attempting to recompile for a certain
 * gpu architecture, a ptx needs to be available
 * that depends on features that are either
 * implemented by the gpu, or for which the ptx
 * translator can provide an emulation.
 */
typedef struct {
    char*            gpuProfileName;
    char*            ptx;
} __rtFatPtxEntry;


/*
 * Debug entry type for __rtFat binary.
 * Such information might, but need not be available
 * for Cubin entries (ptx files compiled in debug mode
 * will contain their own debugging information)
 */
typedef struct __rtFatDebugEntryRec {
    char*                   gpuProfileName;
    char*                   debug;
    struct __rtFatDebugEntryRec *next;
    unsigned int                   size;
} __rtFatDebugEntry;

typedef struct __rtFatElfEntryRec {
    char*                 gpuProfileName;
    char*                 elf;
    struct __rtFatElfEntryRec *next;
    unsigned int                 size;
} __rtFatElfEntry;

typedef enum {
      __rtFatDontSearchFlag = (1 << 0),
      __rtFatDontCacheFlag  = (1 << 1),
      __rtFatSassDebugFlag  = (1 << 2)
} __rtFatRppBinaryFlag;

/*
 * Imported/exported symbol descriptor, needed for
 * __rtFat binary linking. Not much information is needed,
 * because this is only an index: full symbol information
 * is contained by the binaries.
 */
typedef struct {
    char* name;
} __rtFatSymbol;

/*
 * Fat binary container.
 * A mix of ptx intermediate programs and cubins,
 * plus a global identifier that can be used for
 * further lookup in a translation cache or a resource
 * file. This key is a checksum over the device text.
 * The ptx and cubin array are each terminated with
 * entries that have NULL components.
 */

typedef struct __rtFatRppBinaryRec {
    unsigned long            magic;
    unsigned long            version;
    unsigned long            gpuInfoVersion;
    char*                   key;
    char*                   ident;
    char*                   usageMode;
    __rtFatPtxEntry             *ptx;
    __rtFatCubinEntry           *cubin;
    __rtFatDebugEntry           *debug;
    void*                  debugInfo;
    unsigned int                   flags;
    __rtFatSymbol               *exported;
    __rtFatSymbol               *imported;
    struct __rtFatRppBinaryRec *dependends;
    unsigned int                   characteristic;
    __rtFatElfEntry             *elf;
} __rtFatRppBinary;

typedef struct __rtFatRppBinary2HeaderRec {
    unsigned int            magic;
    unsigned int            version;
	unsigned long long int  length;
} __rtFatRppBinary2Header;

enum FatBin2EntryType {
	FATBIN_2_PTX = 0x1,
	FATBIN_2_ELF = 0x2,
	FATBIN_2_OLDCUBIN = 0x4
};

typedef struct __rtFatRppBinary2EntryRec {
	unsigned int           type;
	unsigned int           binary;
	unsigned long long int binarySize;
	unsigned int           unknown2;
	unsigned int           kindOffset;
	unsigned int           unknown3;
	unsigned int           unknown4;
	unsigned int           name;
	unsigned int           nameSize;
	unsigned long long int flags;
	unsigned long long int unknown7;
	unsigned long long int uncompressedBinarySize;
} __rtFatRppBinary2Entry;

#define COMPRESSED_PTX 0x0000000000001000LL

typedef struct __rtFatRppBinaryRec2 {
	int magic;
	int version;
	const unsigned long long* fatbinData;
	char* f;
} __rtFatRppBinary2;

struct rtFatBinHeaderRec3
{
	unsigned int magic;
	unsigned short version;
	unsigned short headerSize;
	unsigned long long int fatSize;
};

struct FatBinFileHeaderRec3 {
  unsigned short Kind;             // 0x00
  unsigned short unknown02;        // 0x02
  unsigned int HeaderSize;       // 0x04
  unsigned int DataSize;         // 0x08
  unsigned int unknown0c;        // 0x0c
  unsigned int CompressedSize;   // 0x10
  unsigned int SubHeaderSize;    // 0x14
  unsigned short VersionMinor;     // 0x18
  unsigned short VersionMajor;     // 0x1a
  unsigned int CudaArch;         // 0x1c
  unsigned int unknown20;        // 0x20
  unsigned int unknown24;        // 0x24
  unsigned int Flags;            // 0x28
  unsigned int Checksum;        // 0x2c
  unsigned int FatName;         // 0x30
  unsigned int KnameType;        // 0x34
  unsigned int UncompressedSize; // 0x38
  unsigned int unknown3c;        // 0x3c
};

struct rtFatBinEntryRec3 {
	struct FatBinFileHeaderRec3 fileHeader;
};

struct rtFatBinRec3 {
	struct rtFatBinHeaderRec3 header;
	struct rtFatBinEntryRec3 entry;
};

/*
 * Current version and magic numbers:
 */
#define __rtFatVERSION   0x00000001
#define __rtFatMAGIC     0x1ee55a01
#define __rtFatMAGIC2    0x466243b1
#define __rtFatMAGIC3    0xba55ed50

/*
 * Version history log:
 *    1  : __rtFatDebugEntry field added to __rtFatRppBinary struct
 *    2  : flags and debugInfo field added.
 *    3  : import/export symbol list
 *    4  : characteristic added, elf added
 */


/*--------------------------------- Functions --------------------------------*/

typedef enum {
    __rtFatAvoidPTX,
    __rtFatPreferBestCode,
    __rtFatForcePTX
} __rtFatCompilationPolicy;

#endif

