/*****************************************************************************
 *
 * <COPYRIGHT_TAG>
 *
 *****************************************************************************/
 /*
 *****************************************************************************
 * Doxygen group definitions
 ****************************************************************************/
/*****************************************************************************
 * @file rpp_typedef.h
 *
 * @description
 *      This file contains the data type definition that are used by
 *      RPP SW framework.
 *
 *****************************************************************************/

#ifndef  RPP_TYPES_H
#define RPP_TYPES_H

#ifdef __cplusplus
extern "C" {
#endif

#if defined (__linux__) && defined (__KERNEL__)

/* Linux kernel mode */
#include <linux/kernel.h>
#include <linux/types.h>

#elif defined (__FreeBSD__) && defined (_KERNEL)

/* FreeBSD kernel mode */
#include <sys/types.h>
#include <sys/param.h>
#include <sys/kernel.h>

#elif defined (_WIN64) && defined (KERNEL_SPACE)

/* Windows kernel mode */
#include <ntddk.h>
#include <stdio.h>
#include <stddef.h>
#include <stdint.h>

#elif defined (__linux__) || defined (__FreeBSD__) || defined (_WIN32) || defined (_WIN64)

/* Linux, FreeBSD, or Windows user mode */
#include <stdio.h>
#include <stddef.h>
#include <stdint.h>

#else
#error Unsupported operating system
#endif /* OS and mode */

#if defined (_WIN32) || defined (_WIN64)
/* nonstandard extension used : zero-sized array in struct/union */
#pragma warning (disable: 4200)
#endif

typedef uint8_t U8;
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_Types
 * Unsigned byte base type. */
typedef int8_t S8;
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_typedef
 * Signed byte base type. */
typedef uint16_t U16;
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_type
 * Unsigned double-byte base type. */
typedef int16_t S16;
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_type
 * Signed double-byte base type. */
typedef uint32_t U32;
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_type
 * Unsigned quad-byte base type. */
typedef int32_t S32;
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_type
 * Signed quad-byte base type. */
typedef uint64_t U64;
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_type
 * Unsigned double-quad-byte base type. */
typedef int64_t S64;
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_typedef
 * Signed double-quad-byte base type. */

/*****************************************************************************
 *      Generic Base Data Type definitions
 *****************************************************************************/
#ifndef NULL
#define NULL (0)
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_typedef
 * NULL definition. */
#endif

#ifndef TRUE
#define TRUE (1==1)
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_typedef
 * True value definition. */
#endif
#ifndef FALSE
#define FALSE (0==1)
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_typedef
 * False value definition. */
#endif


#ifdef __cplusplus
} /* close the extern "C" { */
#endif


#endif



