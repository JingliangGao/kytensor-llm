#pragma once
#include <rpp_runtime.h>
#include <rpp_drv_api.h>
#include <assert.h>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#ifdef _WIN32
#include <io.h>
#include <direct.h> 
#else
#include <unistd.h>
#include <sys/stat.h>
#endif

#ifdef _WIN32
#define ACCESS(fileName,accessMode) _access(fileName,accessMode)
#define MKDIR(path) _mkdir(path)
#else
#define ACCESS(fileName,accessMode) access(fileName,accessMode)
#define MKDIR(path) mkdir(path,S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH)
#endif
//#define _GRAPH_CAPTURE_
namespace rpp_graph_mgr
{
typedef enum GraphMode_e
{
    GLOBAL = 0xabcd,
	INTERNAL = 0x1224,
}eGraphMode;
typedef struct RppIoInfo_t
{
	uint64_t addr;
	int size;
	int rsvd;
} tRppIoInfo;
typedef struct SubGraphInfo_t
{
    RPPstream graphStream_;
    RPPstream kernelStream_;
    RPPstream dmaStream_;
	RPPevent event_starter_;
	RPPevent event_ender_;
    RPPgraphExec graphexec_;
    RPPgraph graph_;
	std::vector<RppIoInfo_t> graph_inputs_;
	std::vector<RppIoInfo_t> graph_outputs_;
	std::vector<RppIoInfo_t> graph_weights_;
	std::string path_;
	std::string graph_path_;
} tSubGraphInfo;

class GraphManager
{
public:
    virtual ~GraphManager() = default;
    GraphManager(const GraphManager&) = delete;
    GraphManager& operator=(const GraphManager&) = delete;
    static GraphManager& GetInstance()
    {
        static GraphManager instance;
        return instance;
    }
	void createDirectory(std::string &directoryPath)
	{
		uint32_t dirPathLen = directoryPath.length();
		if (dirPathLen > 256)
		{
			assert(0);		
		}
		printf("file=%s \n", directoryPath.c_str());
		char tmpDirPath[256] = { 0 };
		for (uint32_t i = 0; i < dirPathLen; ++i)
		{
			tmpDirPath[i] = directoryPath[i];
			if (tmpDirPath[i] == '/')
			{
				if (ACCESS(tmpDirPath, 0) != 0)
				{
					int32_t ret = MKDIR(tmpDirPath);
					assert(ret == 0);
				}
			}
		}
		return;
	}
	
	void SetIoHeaders(int idx)
	{
		if(mode_ != eGraphMode::GLOBAL)
			return;
		
		std::ofstream ftv;
		std::string file = sub_graphs_[idx].path_ + "/InputHeaders";
		ftv.open(file.c_str(), std::ios::out|std::ios::binary);
		ftv.write(reinterpret_cast<char *>(sub_graphs_[idx].graph_inputs_.data()), sub_graphs_[idx].graph_inputs_.size()*sizeof(RppIoInfo_t));
		ftv.close();
	
		file = sub_graphs_[idx].path_ + "/OutputHeaders";
		ftv.open(file.c_str(), std::ios::out|std::ios::binary);
		ftv.write(reinterpret_cast<char *>(sub_graphs_[idx].graph_outputs_.data()),sub_graphs_[idx].graph_outputs_.size()*sizeof(RppIoInfo_t));
		ftv.close();
	
		file = sub_graphs_[idx].path_ + "/WeightHeaders";
		ftv.open(file.c_str(), std::ios::out|std::ios::binary);
		ftv.write(reinterpret_cast<char *>(sub_graphs_[idx].graph_weights_.data()), sub_graphs_[idx].graph_weights_.size()*sizeof(RppIoInfo_t));
		ftv.close();
	}
	bool InitSubGraph(int idx = 0, std::string path ="./", eGraphMode mode = eGraphMode::GLOBAL)
	{
		mode_ = mode;
		if(idx == 0)
			sub_graphs_.clear();
		curIdx_ = idx;
		tSubGraphInfo sub_graph;
		sub_graph.graph_inputs_.clear();
		sub_graph.graph_outputs_.clear();
		sub_graph.graph_weights_.clear();
		std::ostringstream sId;
		sId << idx;
		sub_graph.graph_path_ = path + "/graph"+ sId.str() + "/";
		sub_graph.path_ = sub_graph.graph_path_ + "/graph_handle/";
		createDirectory(sub_graph.path_);
		rppStreamCreate(&sub_graph.graphStream_, 0);
		rppStreamCreate(&sub_graph.kernelStream_, 0);
		rppStreamCreate(&sub_graph.dmaStream_, 0);
		rppEventCreate(&sub_graph.event_starter_, 0);
		rppEventCreate(&sub_graph.event_ender_, 0);
		rppGraphCreate(&sub_graph.graph_, 0);

		sub_graphs_.push_back(sub_graph);
		return true;
	}
	void Destroy()
	{
		for(int i = 0; i < sub_graphs_.size(); i++)
		{
			SetIoHeaders(i);
			rppEventDestroy(sub_graphs_[i].event_starter_);
			rppEventDestroy(sub_graphs_[i].event_ender_);
			rppStreamDestroy(sub_graphs_[i].kernelStream_);
			rppStreamDestroy(sub_graphs_[i].dmaStream_);
			rppGraphExecDestroy(sub_graphs_[i].graphexec_);
			rppGraphDestroy(sub_graphs_[i].graph_);
		}
		sub_graphs_.clear();
		mode_ = INTERNAL;
	}
    void markInput(RPPdeviceptr dev, RPPdeviceptr host, int size)
	{
		if(mode_ != GLOBAL)
			return;
		
		int idx = sub_graphs_[curIdx_].graph_inputs_.size();
		tRppIoInfo graph_input;
		RPPdeviceptr phy_dev;
		rppMemGetPhyAddr(&phy_dev, (RPPdeviceptr)dev);
		graph_input.addr = phy_dev;
		graph_input.size = size;
	
		std::ostringstream sId;
		sId << idx;
		std::ofstream ftv;
		std::string file = sub_graphs_[curIdx_].path_ + "/input" + sId.str();
		ftv.open(file.c_str(), std::ios::out|std::ios::binary);
		ftv.write(reinterpret_cast<char *>(host), size);
		ftv.close();
		
		sub_graphs_[curIdx_].graph_inputs_.push_back(graph_input);
	}
	void markOutput(RPPdeviceptr dev, RPPdeviceptr host, int size)
	{
		if(mode_ != GLOBAL)
			return;
		
		int idx = sub_graphs_[curIdx_].graph_outputs_.size();
		tRppIoInfo graph_output;
		RPPdeviceptr phy_dev;
		rppMemGetPhyAddr(&phy_dev, (RPPdeviceptr)dev);
		graph_output.addr = phy_dev;
		graph_output.size = size;
	
		std::ostringstream sId;
		sId << idx;
		std::ofstream ftv;
		std::string file = sub_graphs_[curIdx_].path_ + "/output" + sId.str();
		ftv.open(file.c_str(), std::ios::out|std::ios::binary);
		ftv.write(reinterpret_cast<char *>(host), size);
		ftv.close();
		sub_graphs_[curIdx_].graph_outputs_.push_back(graph_output);
	}	
	void markWeight(RPPdeviceptr dev, RPPdeviceptr host, int size)
	{
		if(mode_ != GLOBAL)
			return;
		int idx = sub_graphs_[curIdx_].graph_weights_.size();
		tRppIoInfo graph_weight;
		RPPdeviceptr phy_dev;
		rppMemGetPhyAddr(&phy_dev, (RPPdeviceptr)dev);
		graph_weight.addr = phy_dev;
		graph_weight.size = size;
	
		std::ostringstream sId;
		sId << idx;
		std::ofstream ftv;
		std::string file = sub_graphs_[curIdx_].path_ + "/weight" + sId.str();
		ftv.open(file.c_str(), std::ios::out|std::ios::binary);
		ftv.write(reinterpret_cast<char *>(host), size);
		ftv.close();
		sub_graphs_[curIdx_].graph_weights_.push_back(graph_weight);
	}	
	RPPstream kernelStream()
	{
		return sub_graphs_[curIdx_].kernelStream_;
	}
	RPPstream dmaStream()
	{
		return sub_graphs_[curIdx_].dmaStream_;
	}	
	RPPstream graphStream()
	{
		return sub_graphs_[curIdx_].graphStream_;
	}	
	RPPgraph& graph()
	{
		return sub_graphs_[curIdx_].graph_;
	}
	RPPgraphExec& graphExec()
	{
		return sub_graphs_[curIdx_].graphexec_;
	}	
	bool isGlobal()
	{
		if(mode_ == eGraphMode::GLOBAL)
			return true;
		else
			return false;
	}
	void beginCapture()
	{
		if(mode_ != GLOBAL)
			return;
		rppStreamBeginCapture(sub_graphs_[curIdx_].kernelStream_, RPP_STREAM_CAPTURE_MODE_GLOBAL);
	}
	void endCapture()
	{
		if(mode_ != GLOBAL)
			return;
		rppStreamEndCapture(sub_graphs_[curIdx_].kernelStream_, &sub_graphs_[curIdx_].graph_);
    	rppGraphInstantiate(&sub_graphs_[curIdx_].graphexec_, sub_graphs_[curIdx_].graph_, NULL, NULL, 0);
#ifdef _GRAPH_CAPTURE_
        char basePath[255];
        char *res = getcwd(basePath, sizeof(basePath));
        std::cout << "getcwd: " << basePath << std::endl;
        char name_[255];
        sprintf(name_, "%s/%s%d", basePath, "graphs/graph", curIdx_);
        std::cout << "getcwd: " << name_ << std::endl;
        rppGraphExecSerialize(sub_graphs_[curIdx_].graphexec_, name_, 0);
#endif

	}
	void execution()
	{
		if(mode_ != GLOBAL)
			return;
		rppGraphLaunch(sub_graphs_[curIdx_].graphexec_, sub_graphs_[curIdx_].graphStream_);
	}
    void synchronize()
	{
		if(mode_ != GLOBAL)
			return;
		rtStreamSynchronize(sub_graphs_[curIdx_].graphStream_);
	} 
private:
    GraphManager() = default;

private:
	int mode_;
	std::vector<SubGraphInfo_t>sub_graphs_;
	int curIdx_;

};

}
