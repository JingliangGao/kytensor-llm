#ifndef _RPP_HALF_
#define _RPP_HALF_
#include "half.hpp"
#include "bfloat16.h"

#define _BFLOAT16_

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#ifdef _BFLOAT16_

#define rpp_half  rpp::bfloat16
#else
#define rpp_half  half_float::half
#endif

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif  // TENSORFLOW_CORE_LIB_BFLOAT16_BFLOAT16_H_

