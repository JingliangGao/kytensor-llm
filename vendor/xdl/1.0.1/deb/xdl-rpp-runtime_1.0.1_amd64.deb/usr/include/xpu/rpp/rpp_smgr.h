#pragma once
#include <rpp_tensor.hpp>
#include <rpp_sram_io.h>
#include <cstdint>
#include <atomic>
#include <mutex>
#include <list>
#include <map>

namespace rppsmgr
{

enum Result : int32_t
{
    SUCCESS             = 0,
    NO_ENOUGH_SPACE     = -1,
    DRIVER_ERROR        = -2,
    SIO_ERROR           = -3,
    SRAM_NOT_FOUND      = -4,
    UNKNOWN_FORMAT      = -5,
    UPLOAD_ERROR        = -6,
    FREE_ERROR          = -7,
    SIZE_NOT_MATCH      = -8,
    TENSOR_NOT_FOUND    = -9,
};

enum ElementSize : uint32_t
{
    E_SIZE_1    = 1,
    E_SIZE_2    = 2,
    E_SIZE_4    = 4,
    E_SIZE_8    = 8,
};

namespace
{
class SRamFragment
{
public:
    SRamFragment(uint32_t pitch_size, uint32_t height, uint32_t size_of_element, RPPdeviceptr address, void* ddr_address)
    {
        size_of_element_ = size_of_element;
        width_ = pitch_size / size_of_element;
        height_ = height;
        size_ = pitch_size*height;
        payload_size_ = size_;
        address_ = address;
        ddr_address_ = ddr_address;
        is_free_ = false;
    }

    SRamFragment(RPPdeviceptr address, uint32_t size)
    {
        address_ = address;
        size_ = size;
    }

    ~SRamFragment() = default;
    SRamFragment(const SRamFragment&) = delete;
    SRamFragment& operator=(const SRamFragment&) = delete;

    void Reuse(uint32_t pitch_size, uint32_t height, uint32_t size_of_element, void* ddr_address)
    {
        size_of_element_ = size_of_element;
        width_ = pitch_size / size_of_element;
        height_ = height;
        payload_size_ = pitch_size*height;
        ddr_address_ = ddr_address;
        is_free_ = false;
    }

    void Free()
    {
        payload_size_ = 0;
        width_ = 0;
        height_ = 0;
        size_of_element_ = 0;
        ddr_address_ = nullptr;
        is_free_ = true;
        format_ = LINEAR;
    }

    void Update(RPPdeviceptr address, uint32_t size)
    {
        address_ = address;
        size_ = size;
    }

    std::string GetStats()
    {
        std::string stats;
        stats.resize(1024);
        sprintf((char*)stats.data(),
                "DDR:%16p, SRam: 0x%llx, Size:%8u, Payload Size:%8u, Usage Ratio:%4u%%, Width:%8u, Height:%8u, Element Size: %u, Format: %d, Free: %d, Reserved: %d",
                ddr_address_, address_, size_, payload_size_, size_ == 0 ? 0 : payload_size_*100/size_,
                width_, height_, size_of_element_, format_, is_free_, is_reserved_);
        return stats;
    }

    std::string DrawChart()
    {
        uint32_t entire_length = 0, payload_len = 0, unused_len = 0;

        if (!is_free_)
        {
            payload_len = (payload_size_ + CHART_UNIT_SIZE - 1) / CHART_UNIT_SIZE;
            unused_len = (size_ - payload_size_ + CHART_UNIT_SIZE - 1) / CHART_UNIT_SIZE;
            entire_length = payload_len + unused_len;
        }
        else
        {
            entire_length = (size_ + CHART_UNIT_SIZE - 1) / CHART_UNIT_SIZE;
        }
        std::string chart(entire_length, '.');

        if (!is_free_)
        {
            memset((void*)chart.data(), '*', payload_len);
            if (unused_len != 0) memset(((char*)chart.data())+payload_len, '+', unused_len);
        }

        return chart;
    }

    RPPdeviceptr address_ = 0;
    uint32_t size_ = 0;

    uint32_t payload_size_ = 0;
    uint32_t width_ = 0;
    uint32_t height_ = 0;
    uint32_t size_of_element_ = 0;
    void* ddr_address_ = nullptr;
    bool is_reserved_ = false;
    bool is_free_ = false;

    RppFormat_e format_ = LINEAR;

    static const uint32_t CHART_UNIT_SIZE = 256 * 1024;
};
}

class SRamManager
{
public:
    virtual ~SRamManager() = default;
    SRamManager(const SRamManager&) = delete;
    SRamManager& operator=(const SRamManager&) = delete;
    static SRamManager& GetInstance()
    {
        static SRamManager instance;
        return instance;
    }

    Result Init(uint32_t workspace_size, bool is_profile = false)
    {
        std::lock_guard<std::recursive_mutex> guard(mutex_);

        if (is_initialized_) return SUCCESS;
        if (workspace_size > MAX_WORK_SPACE_SIZE) return NO_ENOUGH_SPACE;
        // Must init sramIo firstly, because sramIoInit() has rpp init logic.
        if (sramIoInit(&rpp_sio_handle_) != 0) return SIO_ERROR;
        if (rppVirtSramAlloc(nullptr, &base_addr_, workspace_size) != RPP_SUCCESS) return DRIVER_ERROR;
        work_space_size_ = workspace_size;
        unused_workspace_size_ = work_space_size_.load();
        unused_workspace_cursor_ = base_addr_;
        reserved_fragment_ = new SRamFragment(base_addr_+work_space_size_.load(), 0);
        reserved_fragment_->is_free_ = true;
        reserved_fragment_->is_reserved_ = true;
        sram_fragment_list_.emplace_back(reserved_fragment_);
        is_profile_ = is_profile;
        is_initialized_ = true;

        return SUCCESS;
    }

    void Destroy()
    {
        // Why not place these in ~SRamManager() ?
        // The reason is:
        // - this object is static
        // - Driver destroy logic is registered on std::atexit()
        // Driver destroy its context firstly, then ~SRamManager() called,
        // but when ~SRamManager() called, Driver's context has been destroyed, so core dump.
        // See also:
        // https://community.ibm.com/community/user/ibmz-and-linuxone/blogs/fang-lu2/2020/03/24/be-careful-when-using-the-atexit-routine-with-static-objects
        // https://en.cppreference.com/w/cpp/utility/program/atexit

        {
            std::lock_guard<std::recursive_mutex> guard(mutex_);
            for (auto& sf : sram_fragment_list_) delete sf;
            is_initialized_ = false;
            is_profile_ = false;
            work_space_size_ = 0;
            unused_workspace_size_ = 0;
            unused_workspace_cursor_ = 0;
            sram_fragment_list_.clear();
            ddr_binding_map_.clear();
            reserved_fragment_ = nullptr;
            tensor_ddr_map_.clear();
        }

        rppVirtSramFree(nullptr, base_addr_);
        // Must destroy sramIO lastly, because sramIoExit() has rpp destroy logic.
        sramIoExit(&rpp_sio_handle_);

        {
            std::lock_guard<std::recursive_mutex> guard(mutex_);
            base_addr_ = 0;
            rpp_sio_handle_ = {0};
        }
    }

    bool IsInitialized() const { return is_initialized_; }
    uint32_t GetWorkspaceSize() const { return work_space_size_.load(); }
    bool IsProfile() const { return is_profile_.load(); }
    void SetProfile(bool profile) { is_profile_ = profile; }

    Result ReserveAllocate(uint32_t size, RPPdeviceptr* p_base)
    {
        std::lock_guard<std::recursive_mutex> guard(mutex_);

        if (reserved_fragment_->size_ >= size)
        {
            if (p_base != nullptr) *p_base = reserved_fragment_->address_;
            return SUCCESS;
        }

        uint32_t to_be_alloc_size = size - reserved_fragment_->size_;
        if (to_be_alloc_size > unused_workspace_size_) return NO_ENOUGH_SPACE;

        unused_workspace_size_ -= to_be_alloc_size;
        reserved_fragment_->Update(reserved_fragment_->address_-to_be_alloc_size, size);

        reserved_fragment_->is_free_ = true;
        reserved_fragment_->is_reserved_ = true;

        if (p_base != nullptr) *p_base = reserved_fragment_->address_;

        return SUCCESS;
    }

    Result FetchReservedSpace(RPPdeviceptr* p_base = nullptr)
    {
        void* ddr_addr = nullptr;

        {
            std::lock_guard<std::recursive_mutex> guard(mutex_);
            reserved_fragment_->is_free_ = false;
            ddr_addr = reserved_fragment_->ddr_address_;
            if (p_base != nullptr) *p_base = reserved_fragment_->address_;
        }

        if (ddr_addr != nullptr)
        {
            return Upload(ddr_addr);
        }

        return SUCCESS;
    }

    Result ReleaseReservedSpace()
    {
        void* ddr_addr = nullptr;

        {
            std::lock_guard<std::recursive_mutex> guard(mutex_);
            ddr_addr = reserved_fragment_->ddr_address_;
            reserved_fragment_->is_free_ = (ddr_addr == nullptr);
        }

        if (ddr_addr != nullptr)
        {
            return Download(ddr_addr);
        }

        return SUCCESS;
    }

    void ReserveFree()
    {
        std::lock_guard<std::recursive_mutex> guard(mutex_);
        if (reserved_fragment_ == nullptr) return;

        if (reserved_fragment_->is_free_)
        {
            unused_workspace_size_ += reserved_fragment_->size_;
            reserved_fragment_->Update(base_addr_+work_space_size_.load(), 0);
        }
        reserved_fragment_->is_reserved_ = false;
    }

    Result PitchAllocate(void* ddr_address, uint32_t height, uint32_t pitch_size, ElementSize element_size, RppFormat_e format)
    {
        std::lock_guard<std::recursive_mutex> guard(mutex_);
        uint32_t size = pitch_size*height;

        SRamFragment* sf = FindReusableFragment(size);
        if (sf != nullptr)
        {
            sf->Reuse(pitch_size, height, element_size, ddr_address);
            sf->format_ = format;
            ddr_binding_map_[ddr_address] = sf;

            // Split
            if (sf->payload_size_*1.0/sf->size_ <= 0.75)
            {
                std::list<SRamFragment*>::iterator sf_it;
                for (sf_it = sram_fragment_list_.begin(); sf_it != sram_fragment_list_.end(); sf_it++) {
                    if (*sf_it == sf) break;
                }
                uint32_t sf_new_size = sf->payload_size_;
                SRamFragment* new_sf = new SRamFragment(sf->address_+sf_new_size, sf->size_-sf_new_size);
                new_sf->Free();
                sram_fragment_list_.insert(++sf_it, new_sf);
                sf->Update(sf->address_, sf_new_size);
            }

            return SUCCESS;
        }
        else
        {
            if (size > unused_workspace_size_)
            {
                if (reserved_fragment_->is_free_ && reserved_fragment_->size_ >= size)
                {
                    reserved_fragment_->Reuse(pitch_size, height, element_size, ddr_address);
                    reserved_fragment_->format_ = format;
                    ddr_binding_map_[ddr_address] = reserved_fragment_;
                    return SUCCESS;
                }
                else
                {
                    assert(0);
                    return NO_ENOUGH_SPACE;
                }
            }

            auto* new_sf = new SRamFragment(pitch_size, height, element_size, unused_workspace_cursor_, ddr_address);
            new_sf->format_ = format;
            unused_workspace_size_ -= size;
            unused_workspace_cursor_ += size;
            sram_fragment_list_.emplace_back(new_sf);
            ddr_binding_map_[ddr_address] = new_sf;
            return SUCCESS;
        }
    }

    Result PitchAllocate(void* ddr_address, uint32_t height, uint32_t pitch_size, uint32_t element_size, RppFormat_e format)
    {
        return PitchAllocate(ddr_address, height, pitch_size, (ElementSize)element_size, format);
    }

    Result Allocate(void* ddr_address, uint32_t height, uint32_t width, ElementSize element_size, RppFormat_e format)
    {
        return PitchAllocate(ddr_address, height, (width+31)/32*32 * element_size, element_size, format);
    }

    Result Allocate(void* ddr_address, uint32_t height, uint32_t width, uint32_t element_size, RppFormat_e format)
    {
        return PitchAllocate(ddr_address, height, (width+31)/32*32 * element_size, element_size, format);
    }

    template<typename T> Result AllocateTensor3D(void* ddr_address,  uint32_t dim2, uint32_t dim1, uint32_t dim0, rppTensor3D<T>* rpp_tensor)
    {
        Result ret_val = Allocate(ddr_address, (dim2 * dim1), dim0, sizeof(T), DetectTensorInitialFormat(sizeof(T)));
        if (ret_val == SUCCESS)
        {
            rpp_tensor->CloneFrom(rppTensor3D<T>(dim2, dim1, dim0, (char*)GetSRamAddr(ddr_address)));
            {
                std::lock_guard<std::recursive_mutex> guard(mutex_);
                tensor_ddr_map_[(void*)rpp_tensor] = ddr_address;
            }
        }
        return ret_val;
    }

    template<typename T> Result AllocateTensor2D(void* ddr_address, uint32_t height, uint32_t width, rppTensor2D<T>* rpp_tensor)
    {
        Result ret_val = Allocate(ddr_address, height, width, sizeof(T), DetectTensorInitialFormat(sizeof(T)));
        if (ret_val == SUCCESS)
        {
            rpp_tensor->CloneFrom(rppTensor2D<T>(height, width, (char*)GetSRamAddr(ddr_address)));
            {
                std::lock_guard<std::recursive_mutex> guard(mutex_);
                tensor_ddr_map_[(void*)rpp_tensor] = ddr_address;
            }
        }
        return ret_val;
    }

    template<typename T> Result AllocateTensor1D(void* ddr_address, uint32_t width, rppTensor1D<T>* rpp_tensor)
    {
        Result ret_val = Allocate(ddr_address, 1, width, sizeof(T), DetectTensorInitialFormat(sizeof(T)));
        if (ret_val == SUCCESS)
        {
            rpp_tensor->CloneFrom(rppTensor1D<T>(width, (char*)GetSRamAddr(ddr_address)));
            {
                std::lock_guard<std::recursive_mutex> guard(mutex_);
                tensor_ddr_map_[(void*)rpp_tensor] = ddr_address;
            }
        }
        return ret_val;
    }

    Result Free(void* ddr_address)
    {
        std::lock_guard<std::recursive_mutex> guard(mutex_);
        auto sram_it = ddr_binding_map_.find(ddr_address);
        if (sram_it == ddr_binding_map_.end()) return SRAM_NOT_FOUND;

        SRamFragment* sf = sram_it->second;
        sf->Free();
        ddr_binding_map_.erase(sram_it);

        // For the case that:
        // |==|=|=|=|=|=|====|====|==|=|=|=|....|....|....|....|....|.|.|.|(....................................................)|.........|
        // then will be:
        // |==|=|=|=|=|=|====|====|==|=|=|=|(........................................................................)|.........|

        if (sf == reserved_fragment_ && !reserved_fragment_->is_reserved_)
        {
            unused_workspace_size_ += reserved_fragment_->size_;
            reserved_fragment_->Update(base_addr_+work_space_size_.load(), 0);
            return SUCCESS;
        }

        std::list<SRamFragment*>::reverse_iterator rit = sram_fragment_list_.rbegin();
        if (sf != *rit) return SUCCESS;

        while ((*rit)->is_free_ && *rit != reserved_fragment_)
        {
            uint32_t fragment_size = (*rit)->size_;
            delete (*rit);
            unused_workspace_size_ += fragment_size;
            unused_workspace_cursor_ -= fragment_size;
            sram_fragment_list_.erase(--(rit.base()));
        }

        return SUCCESS;
    }

    Result FreeTensor(void* tensor)
    {
        void* ddr_address = nullptr;
        std::lock_guard<std::recursive_mutex> guard(mutex_);
        auto tensor_it = tensor_ddr_map_.find(tensor);
        if (tensor_it == tensor_ddr_map_.end()) return TENSOR_NOT_FOUND;
        ddr_address = tensor_it->second;

        return Free(ddr_address);
    }

    void* GetSRamAddr(void* ddr_address)
    {
        std::lock_guard<std::recursive_mutex> guard(mutex_);
        auto sram_it = ddr_binding_map_.find(ddr_address);
        if (sram_it == ddr_binding_map_.end()) return nullptr;
        return (void*)(sram_it->second->address_);
    }

    Result GetSRamFormat(void* ddr_address, RppFormat_e& format)
    {
        std::lock_guard<std::recursive_mutex> guard(mutex_);
        auto sram_it = ddr_binding_map_.find(ddr_address);
        if (sram_it == ddr_binding_map_.end()) return UNKNOWN_FORMAT;
        format = sram_it->second->format_;
        return SUCCESS;
    }
 
    Result Download(void* ddr_address, RPPstream stream = nullptr)
    {
        RPPdeviceptr sram_addr = 0;
        uint32_t size = 0;

        {
            std::lock_guard<std::recursive_mutex> guard(mutex_);
            auto sram_it = ddr_binding_map_.find(ddr_address);
            if (sram_it == ddr_binding_map_.end()) return SRAM_NOT_FOUND;

            SRamFragment* sf = sram_it->second;
            sram_addr = sf->address_;
            size = sf->payload_size_;
        }

        if (rppMemcpyDtoSAsync(sram_addr, (RPPdeviceptr)ddr_address, size, stream) != RPP_SUCCESS) return DRIVER_ERROR;

        return SUCCESS;
    }
    Result Download2d(void* ddr_address, int h, int dev_pitch, int sram_pitch, RPPstream stream = nullptr)
    {
        RPPdeviceptr sram_addr = 0;
        uint32_t size = 0;
        {
            std::lock_guard<std::recursive_mutex> guard(mutex_);
            auto sram_it = ddr_binding_map_.find(ddr_address);
            if (sram_it == ddr_binding_map_.end()) return SRAM_NOT_FOUND;

            SRamFragment* sf = sram_it->second;
            sram_addr = sf->address_;
            size = sf->payload_size_;
        }
        RPP_MEMCPY2D copy2D;
        copy2D.src = (RPPdeviceptr)ddr_address;
        copy2D.srcMemoryType = RPP_MEMORYTYPE_DEVICE;
        copy2D.srcPitch = dev_pitch;
        copy2D.srcXInBytes = 0;
        copy2D.srcY = 0;
        copy2D.dst = sram_addr;
        copy2D.dstMemoryType = RPP_MEMORYTYPE_SRAM;
        copy2D.dstPitch = sram_pitch;
        copy2D.dstXInBytes = 0;
        copy2D.dstY = 0;
        copy2D.Height = h;
        copy2D.WidthInBytes = sram_pitch;
        if (rppMemcpy2DAsync(&copy2D, stream) != RPP_SUCCESS) return DRIVER_ERROR;

        return SUCCESS;
    }
    Result DownloadTensor(void* tensor, RPPstream stream = nullptr)
    {
        void* ddr_address = nullptr;
        std::lock_guard<std::recursive_mutex> guard(mutex_);
        auto tensor_it = tensor_ddr_map_.find(tensor);
        if (tensor_it == tensor_ddr_map_.end()) return TENSOR_NOT_FOUND;
        ddr_address = tensor_it->second;

        Result ret_val = Download(ddr_address);
        if (ret_val != SUCCESS) return ret_val;

        SRamFragment* sf = ddr_binding_map_.find(ddr_address)->second;
        if (sf->format_ == RFMT && sf->size_of_element_ == 4)
        {
            sf->format_ = HFMT;
            if (sf->width_ < MAX_SUPPORTED_INPLACE_REFORMAT_WIDTH) {
                return ReformatInPlace(ddr_address, stream);
            } else {
                return ReformatOutPlace(ddr_address);
            }
        }

        return SUCCESS;
    }

    Result Upload(void* ddr_address, RPPstream stream = nullptr)
    {
        RPPdeviceptr sram_addr = 0;
        uint32_t size = 0;

        {
            std::lock_guard<std::recursive_mutex> guard(mutex_);
            auto sram_it = ddr_binding_map_.find(ddr_address);
            if (sram_it == ddr_binding_map_.end()) return SRAM_NOT_FOUND;

            SRamFragment* sf = sram_it->second;
            sram_addr = sf->address_;
            size = sf->payload_size_;
        }

        if (rppMemcpyStoDAsync((RPPdeviceptr)ddr_address, sram_addr, size, stream) != RPP_SUCCESS) return DRIVER_ERROR;

        return SUCCESS;
    }

    Result Upload2d(void* ddr_address, int h, int dev_pitch, int sram_pitch, RPPstream stream = nullptr)
    {
        RPPdeviceptr sram_addr = 0;
        uint32_t size = 0;
        {
            std::lock_guard<std::recursive_mutex> guard(mutex_);
            auto sram_it = ddr_binding_map_.find(ddr_address);
            if (sram_it == ddr_binding_map_.end()) return SRAM_NOT_FOUND;

            SRamFragment* sf = sram_it->second;
            sram_addr = sf->address_;
            size = sf->payload_size_;
        }
        RPP_MEMCPY2D copy2D;
        copy2D.src =  (RPPdeviceptr)sram_addr;
        copy2D.srcMemoryType = RPP_MEMORYTYPE_SRAM;
        copy2D.srcPitch = sram_pitch;
        copy2D.srcXInBytes = 0;
        copy2D.srcY = 0;

        copy2D.dst = (RPPdeviceptr)ddr_address;
        copy2D.dstMemoryType = RPP_MEMORYTYPE_DEVICE;
        copy2D.dstPitch = dev_pitch;
        copy2D.srcXInBytes = 0;
        copy2D.dstXInBytes = 0;
        copy2D.dstY = 0;
        copy2D.Height = h;
        copy2D.WidthInBytes = sram_pitch;
        if (rppMemcpy2DAsync(&copy2D, stream) != RPP_SUCCESS) return DRIVER_ERROR;

        return SUCCESS;
    }

    Result UploadTensor(void* tensor, RPPstream stream = nullptr)
    {
        void* ddr_address = nullptr;
        std::lock_guard<std::recursive_mutex> guard(mutex_);
        auto tensor_it = tensor_ddr_map_.find(tensor);
        if (tensor_it == tensor_ddr_map_.end()) return TENSOR_NOT_FOUND;
        ddr_address = tensor_it->second;

        auto sram_it = ddr_binding_map_.find(ddr_address);
        if (sram_it == ddr_binding_map_.end()) return SRAM_NOT_FOUND;

        SRamFragment* sf = ddr_binding_map_.find(ddr_address)->second;
        if (sf->format_ == RFMT && sf->size_of_element_ == 4)
        {
            Result ret_val = SUCCESS;
            if (sf->width_ < MAX_SUPPORTED_INPLACE_REFORMAT_WIDTH) {
                ret_val = ReformatInPlace(ddr_address, stream);
                if (ret_val != SUCCESS) {
                    return ret_val;
                } else {
                    return Upload(ddr_address);
                }
            } else {
                ret_val = Upload(ddr_address);
                if (ret_val != SUCCESS) {
                    return ret_val;
                } else {
                   return ReformatDDR(ddr_address);
                }
            }
        }

        return Upload(ddr_address);
    }

    Result Dump(void* ddr_address, bool keep_format = false)
    {
        if (is_profile_.load()) return SUCCESS;

        Result upload_ret = Upload(ddr_address);
        if (keep_format) return upload_ret;

        RppFormat_e sram_fmt = LINEAR;
        {
            std::lock_guard<std::recursive_mutex> guard(mutex_);
            auto sram_it = ddr_binding_map_.find(ddr_address);
            if (sram_it == ddr_binding_map_.end()) return SRAM_NOT_FOUND;
            sram_fmt = sram_it->second->format_;
        }

        if (sram_fmt == RFMT || sram_fmt == RCFMT)
        {
            return ReformatDDR(ddr_address);
        }

        return SUCCESS;
    }

    Result ReformatInPlace(void* ddr_address, RPPstream stream = nullptr)
    {
        RPPdeviceptr sram_addr = 0;
        uint32_t width = 0, height = 0;
        RppFormat_e src_fmt = LINEAR, dst_fmt = LINEAR;
        RPPdeviceptr temp_space = 0;
        uint32_t tmp_workspace_size = 0;

        {
            std::lock_guard<std::recursive_mutex> guard(mutex_);

            auto sram_it = ddr_binding_map_.find(ddr_address);
            if (sram_it == ddr_binding_map_.end()) return SRAM_NOT_FOUND;

            SRamFragment* sf = sram_it->second;
            sram_addr = sf->address_;
            src_fmt = sf->format_;
            if (DetectDstFmt(src_fmt, dst_fmt) != 0) return UNKNOWN_FORMAT;

            width = sf->width_;
            height = sf->height_;
            tmp_workspace_size = CalcTempSpaceSize(width, height, sf->size_of_element_);
            temp_space = AllocateTempSpace(tmp_workspace_size);

            if (temp_space == 0) return NO_ENOUGH_SPACE;
        }

        if ((height < 32 && (width % 1024 == 0) && width >= 1024) && width < MAX_SUPPORTED_INPLACE_REFORMAT_WIDTH) {
            // transform
            width = width / 32;
            height = height * 32;
            rpp_reformat(&rpp_sio_handle_, (float*)sram_addr, (float*)sram_addr, src_fmt, dst_fmt, (int)width, (int)height,
                     (float*)temp_space, stream);
        }
        else if (height >= 32 && width >= 32 && (height % 32 == 0) && (width % 32 == 0) && width < MAX_SUPPORTED_INPLACE_REFORMAT_WIDTH){
            rpp_reformat(&rpp_sio_handle_, (float*)sram_addr, (float*)sram_addr, src_fmt, dst_fmt, (int)width, (int)height,
                     (float*)temp_space, stream);
        } else {
            ReformatOutPlace(ddr_address);
        }
        
        {
            std::lock_guard<std::recursive_mutex> guard(mutex_);
            ddr_binding_map_.find(ddr_address)->second->format_ = dst_fmt;
            FreeTempSpace(temp_space, tmp_workspace_size);
        }

        return SUCCESS;
    }

    Result ReformatTo(void* src_ddr, void* dst_ddr, RPPstream stream = nullptr)
    {
        RPPdeviceptr src_sram = 0, dst_sram = 0;
        uint32_t width = 0, height = 0;
        RppFormat_e src_fmt = LINEAR, dst_fmt = LINEAR;
        RPPdeviceptr temp_space = 0;
        uint32_t tmp_workspace_size = 0;

        {
            std::lock_guard<std::recursive_mutex> guard(mutex_);
            auto binding_end = ddr_binding_map_.end();
            auto src_it = ddr_binding_map_.find(src_ddr);
            auto dst_it = ddr_binding_map_.find(dst_ddr);
            if (src_it == binding_end || dst_it == binding_end) return SRAM_NOT_FOUND;

            SRamFragment* src_sf = src_it->second;
            SRamFragment* dst_sf = dst_it->second;
            if (src_sf->payload_size_ != dst_sf->payload_size_) return SIZE_NOT_MATCH;

            src_sram = src_sf->address_;
            dst_sram = dst_sf->address_;
            src_fmt = src_sf->format_;
            if (DetectDstFmt(src_fmt, dst_fmt) != 0) return UNKNOWN_FORMAT;

            width = src_sf->width_;
            height = src_sf->height_;
            tmp_workspace_size = CalcTempSpaceSize(width, height, src_sf->size_of_element_);
            temp_space = AllocateTempSpace(tmp_workspace_size);
            if (temp_space == 0) return NO_ENOUGH_SPACE;
        }

        rpp_reformat(&rpp_sio_handle_, (float*)dst_sram, (float*)src_sram, src_fmt, dst_fmt, (int)width, (int)height,
                     (float*)temp_space, stream);

        {
            std::lock_guard<std::recursive_mutex> guard(mutex_);
            ddr_binding_map_.find(dst_ddr)->second->format_ = dst_fmt;
            FreeTempSpace(temp_space, tmp_workspace_size);
        }

        return SUCCESS;
    }

    Result ReformatOutPlace(void* ddr_address)
    {
        Result ret_val = SUCCESS;
        RPPdeviceptr sram_addr = 0;
        RppFormat_e src_fmt = LINEAR, dst_fmt = LINEAR;
        uint32_t size = 0, size_of_element = 0, elements = 0;
        uint16_t* src_buf = nullptr;
        uint16_t* dst_buf = nullptr;
        uint16_t* d_tmp = nullptr;

        {
            std::lock_guard<std::recursive_mutex> guard(mutex_);

            auto sram_it = ddr_binding_map_.find(ddr_address);
            if (sram_it == ddr_binding_map_.end()) {
                ret_val = SRAM_NOT_FOUND;
                goto end;
            }

            SRamFragment* sf = sram_it->second;
            sram_addr = sf->address_;
            size = sf->payload_size_;
            size_of_element = sf->size_of_element_;
            src_fmt = sf->format_;
        }

        if (DetectDstFmt(src_fmt, dst_fmt) != 0) {
            ret_val = UNKNOWN_FORMAT;
            goto end;
        }

        src_buf = (uint16_t*)malloc(size);
        dst_buf = (uint16_t*)malloc(size);

        rppMemAlloc((RPPdeviceptr *)&d_tmp, size);

        if (rppMemcpyStoD((RPPdeviceptr)d_tmp, sram_addr, size) != RPP_SUCCESS
            || rppMemcpyDtoH(src_buf, (RPPdeviceptr)d_tmp, size) != RPP_SUCCESS)
        {
            ret_val = DRIVER_ERROR;
            goto end;
        }

        elements = size / size_of_element;
        if (CpuReformat(src_buf, dst_buf, src_fmt, dst_fmt, elements) != 0)
        {
            ret_val = UNKNOWN_FORMAT;
            goto end;
        }

        if (rppMemcpyHtoD((RPPdeviceptr)d_tmp, dst_buf, size) != RPP_SUCCESS
            || rppMemcpyDtoS(sram_addr, (RPPdeviceptr)d_tmp, size) != RPP_SUCCESS)
        {
            ret_val = DRIVER_ERROR;
            goto end;
        }

        {
            std::lock_guard<std::recursive_mutex> guard(mutex_);
            ddr_binding_map_.find(ddr_address)->second->format_ = dst_fmt;
        }

    end:
        if (src_buf != nullptr) free(src_buf);
        if (dst_buf != nullptr) free(dst_buf);
        if (d_tmp != nullptr) rppMemFree((RPPdeviceptr)d_tmp);
        return ret_val;
    }

    Result ReformatDDR(void* ddr_address)
    {
        Result ret_val = SUCCESS;
        RppFormat_e src_fmt = LINEAR, dst_fmt = LINEAR;
        uint32_t size = 0, size_of_element = 0, elements = 0;
        uint16_t* src_buf = nullptr;
        uint16_t* dst_buf = nullptr;

        {
            std::lock_guard<std::recursive_mutex> guard(mutex_);

            auto sram_it = ddr_binding_map_.find(ddr_address);
            if (sram_it == ddr_binding_map_.end()) {
                ret_val = SRAM_NOT_FOUND;
                goto end;
            }

            SRamFragment* sf = sram_it->second;
            size = sf->payload_size_;
            size_of_element = sf->size_of_element_;
            src_fmt = sf->format_;
        }

        if (DetectDstFmt(src_fmt, dst_fmt) != 0) {
            ret_val = UNKNOWN_FORMAT;
            goto end;
        }

        src_buf = (uint16_t*)malloc(size);
        dst_buf = (uint16_t*)malloc(size);

        if (rppMemcpyDtoH(src_buf, (RPPdeviceptr)ddr_address, size) != RPP_SUCCESS)
        {
            ret_val = DRIVER_ERROR;
            goto end;
        }

        elements = size / size_of_element;
        if (CpuReformat(src_buf, dst_buf, src_fmt, dst_fmt, elements) != 0)
        {
            ret_val = UNKNOWN_FORMAT;
            goto end;
        }

        if (rppMemcpyHtoD((RPPdeviceptr)ddr_address, dst_buf, size) != RPP_SUCCESS)
        {
            ret_val = DRIVER_ERROR;
            goto end;
        }

    end:
        if (src_buf != nullptr) free(src_buf);
        if (dst_buf != nullptr) free(dst_buf);
        return ret_val;
    }

    void Clear()
    {
        std::lock_guard<std::recursive_mutex> guard(mutex_);
        uint32_t new_workspace_size = work_space_size_.load();
        if (reserved_fragment_->is_reserved_) {
            new_workspace_size -= reserved_fragment_->size_;
        } else {
            reserved_fragment_->Update(base_addr_+new_workspace_size, 0);
            reserved_fragment_->is_free_ = true;
        }
        unused_workspace_size_ = new_workspace_size;
        unused_workspace_cursor_ = base_addr_;
        for (auto& sf : sram_fragment_list_) {
            if (sf != reserved_fragment_) delete sf;
        }
        sram_fragment_list_.clear();
        sram_fragment_list_.emplace_back(reserved_fragment_);
        ddr_binding_map_.clear();
        tensor_ddr_map_.clear();
    }

    void Status()
    {
        std::lock_guard<std::recursive_mutex> guard(mutex_);
        printf("\n====================== RPP SRam Manager =======================\n");
        printf("Profile: %d\n", is_profile_.load());
        printf("Workspace Size: %u\n", work_space_size_.load());
        printf("SRam Base: 0X%llX\n", base_addr_);
        printf("Unused Workspace Size: %u\n", unused_workspace_size_);
        printf("Unused Workspace Cursor: 0X%llX\n", unused_workspace_cursor_);
        printf("DDR binding length: %zu\n", ddr_binding_map_.size());
        printf("--------------------- SRam Fragments --------------------------\n");
        uint32_t max_reusable_fragment_size = 0;
        uint32_t free_workspace_size = 0;
        for (auto& sf : sram_fragment_list_)
        {
            if (sf->is_free_) free_workspace_size += sf->size_;
            if (sf != reserved_fragment_) {
                printf("%s\n", sf->GetStats().c_str());
            }
            if (sf->size_ > max_reusable_fragment_size) max_reusable_fragment_size = sf->size_;
        }
        printf("---------------------------------------------------------------\n");
        printf("%s\n", reserved_fragment_->GetStats().c_str());
        printf("---------------------------------------------------------------\n");
        printf("MAX Reusable Fragment Size: %u\n", max_reusable_fragment_size);
        printf("---------------------------------------------------------------\n");
        free_workspace_size += unused_workspace_size_;
        printf("Free Workspace Size: %u (%u%%)\n", free_workspace_size, free_workspace_size*100/work_space_size_.load());
        printf("---------------------------------------------------------------\n");
        for (auto& sf : sram_fragment_list_)
        {
            if (sf != reserved_fragment_) {
                printf("|%s", sf->DrawChart().c_str());
            }
        }
        std::string unused_chart((unused_workspace_size_+SRamFragment::CHART_UNIT_SIZE-1)/SRamFragment::CHART_UNIT_SIZE, '.');
        printf("|(%s)", unused_chart.c_str());
        printf("|%s", reserved_fragment_->DrawChart().c_str());
        printf("|\n");
        printf("===============================================================\n\n");
    }

public:
    SRamManager() = default;

private:
    static int DetectDstFmt(RppFormat_e src_fmt, RppFormat_e& dst_fmt)
    {
        switch (src_fmt) {
        case HFMT:
            dst_fmt = RFMT;
            break;
        case RFMT:
            dst_fmt = HFMT;
            break;
        case HCFMT:
            dst_fmt = RCFMT;
            break;
        case RCFMT:
            dst_fmt = HCFMT;
            break;
        default:
            return -1;
        }
        return 0;
    }

    static RppFormat_e DetectTensorInitialFormat(uint32_t element_size)
    {
        RppFormat_e fmt = LINEAR;
        switch (element_size)
        {
        case 1:
            fmt = LINEAR;
            break;
        case 2:
            fmt = RFMT;
            break;
        case 4:
            fmt = RFMT;
            break;
        case 8:
            fmt = RCFMT;
            break;
        default:
            fmt = LINEAR;
            break;
        }
        return fmt;
    }

    SRamFragment* FindReusableFragment(uint32_t size, bool include_reserved = false)
    {
        SRamFragment* ret_val = nullptr;
        uint32_t min_diff = MAX_WORK_SPACE_SIZE;

        for (auto& sf : sram_fragment_list_)
        {
            if (!sf->is_reserved_ && sf->is_free_ && sf->size_ >= size && sf->size_-size < min_diff)
            {
                ret_val = sf;
                min_diff = sf->size_-size;
            }
        }

        if (ret_val == nullptr && include_reserved && reserved_fragment_->is_free_ && reserved_fragment_->size_ >= size)
        {
            ret_val = reserved_fragment_;
        }

        return ret_val;
    }

    uint32_t CalcTempSpaceSize(uint32_t width, uint32_t height, uint32_t element_size)
    {
        uint32_t tmp_workspace_size = (width+1)*(height+1)*element_size;
        tmp_workspace_size = (tmp_workspace_size+1023)/1024*1024 + 128;
        tmp_workspace_size *= 2;
        return tmp_workspace_size;
    }

    RPPdeviceptr AllocateTempSpace(uint32_t size)
    {
        RPPdeviceptr ret_val = 0;
        SRamFragment* tmp_sram = FindReusableFragment(size, true);
        if (tmp_sram != nullptr)
        {
            ret_val = tmp_sram->address_;
            tmp_sram->is_free_ = false;
        }
        else
        {
            if (unused_workspace_size_ >= size)
            {
                unused_workspace_size_ -= size;
                ret_val = unused_workspace_cursor_;
                unused_workspace_cursor_ += size;
            }
        }
        return ret_val;
    }

    void FreeTempSpace(RPPdeviceptr sram_addr, uint32_t size)
    {
        for (auto& sf : sram_fragment_list_)
        {
            if (sf->address_ == sram_addr) {
                sf->is_free_ = true;
                return;
            }
        }

        unused_workspace_size_ += size;
        unused_workspace_cursor_ -= size;
    }

    static int CpuReformat(const uint16_t* src_buf, uint16_t* dst_buf, RppFormat_e src_fmt, RppFormat_e dst_fmt, uint32_t element_num)
    {
        if (src_fmt == HFMT && dst_fmt == RFMT) {
            for(uint32_t i = 0; i < element_num; i++) {
                dst_buf[i] = src_buf[2*i];
                dst_buf[i + element_num] = src_buf[2*i + 1];
            }
        }
        else if (src_fmt == RFMT && dst_fmt == HFMT) {
            for(uint32_t i = 0; i < element_num; i++) {
                dst_buf[2*i] = src_buf[i];
                dst_buf[2*i + 1] = src_buf[i + element_num];
            }
        }
        else if (src_fmt == HCFMT && dst_fmt == RCFMT) {
            for(uint32_t i = 0; i < element_num; i++) {
                dst_buf[i] = src_buf[4*i];
                dst_buf[i + element_num] = src_buf[4*i + 1];
                dst_buf[i + 2*element_num] = src_buf[4*i + 2];
                dst_buf[i + 3*element_num] = src_buf[4*i + 3];
            }
        }
        else if (src_fmt == RCFMT && dst_fmt == HCFMT) {
            for(uint32_t i = 0; i < element_num; i++) {
                dst_buf[4*i] = src_buf[i];
                dst_buf[4*i + 1] = src_buf[i + element_num];
                dst_buf[4*i + 2] = src_buf[i + 2*element_num];
                dst_buf[4*i + 3] = src_buf[i + 3*element_num];
            }
        }
        else {
            return -1;
        }

        return 0;
    }

    Result SwapOut(void* ddr_address)
    {
        if (Upload(ddr_address) != SUCCESS) return UPLOAD_ERROR;
        if (Free(ddr_address) != SUCCESS) return FREE_ERROR;

        return SUCCESS;
    }

public:
    static const uint32_t MAX_SUPPORTED_INPLACE_REFORMAT_WIDTH = 4096;

private:
    static const uint32_t MAX_WORK_SPACE_SIZE = 24 * 1024 * 1024;

    std::recursive_mutex mutex_;
    bool is_initialized_ = false;
    std::atomic_bool is_profile_{false};

    rppSramIoHandle rpp_sio_handle_ = {0};

    std::atomic_uint32_t work_space_size_{0};
    RPPdeviceptr base_addr_ = 0;

    uint32_t unused_workspace_size_ = 0;
    RPPdeviceptr unused_workspace_cursor_ = 0;
    std::list<SRamFragment*> sram_fragment_list_;
    std::map<void*, SRamFragment*> ddr_binding_map_;
    SRamFragment* reserved_fragment_ = nullptr;

    std::map<void*, void*> tensor_ddr_map_;
};

}
