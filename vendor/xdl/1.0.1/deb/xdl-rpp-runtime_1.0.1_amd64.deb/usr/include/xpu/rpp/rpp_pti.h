#if !defined(__RPP_PTI_H__)
#define __RPP_PTI_H__

#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifdef NOMINMAX
#include <windows.h>
#else
#define NOMINMAX
#include <windows.h>
#undef NOMINMAX
#endif
#endif

#if 0
#include <cuda.h>
#endif

#include "rpp_drv_api.h"
#include "rpp_osal.h"
#include <pti_result.h>
#include <pti_version.h>

/* Activity, callback, event and metric APIs */
#include <pti_activity.h>

#include "rpp_driver_api_id.h"
#include "rpp_driver_api_meta.h"


#include <pti_callbacks.h>
#include <pti_events.h>
#include <pti_metrics.h>

/* Runtime, driver, and nvtx function identifiers */
// #include <pti_driver_cbid.h>
// #include <pti_runtime_cbid.h>
// #include <pti_nvtx_cbid.h>

#if 0
/* To support function parameter structures for obsoleted API. See
   cuda.h for the actual definition of these structures. */
typedef unsigned int RPPdeviceptr_v1;
typedef struct CUDA_MEMCPY2D_v1_st { int dummy; } CUDA_MEMCPY2D_v1;
typedef struct CUDA_MEMCPY3D_v1_st { int dummy; } CUDA_MEMCPY3D_v1;
typedef struct CUDA_ARRAY_DESCRIPTOR_v1_st { int dummy; } CUDA_ARRAY_DESCRIPTOR_v1;
typedef struct CUDA_ARRAY3D_DESCRIPTOR_v1_st { int dummy; } CUDA_ARRAY3D_DESCRIPTOR_v1;

/* Function parameter structures */
#include <generated_cuda_runtime_api_meta.h>
#include <generated_cuda_meta.h>

/* The following parameter structures cannot be included unless a
   header that defines GL_VERSION is included before including them.
   If these are needed then make sure such a header is included
   already. */
#ifdef GL_VERSION
#include <generated_cuda_gl_interop_meta.h>
#include <generated_cudaGL_meta.h>
#endif

//#include <generated_nvtx_meta.h>

/* The following parameter structures cannot be included by default as
   they are not guaranteed to be available on all systems. Uncomment
   the includes that are available, or use the include explicitly. */
#if defined(__linux__)
//#include <generated_cuda_vdpau_interop_meta.h>
//#include <generated_cudaVDPAU_meta.h>
#endif

#if defined(_WIN32) || defined(_WIN64)
//#include <generated_cuda_d3d9_interop_meta.h>
//#include <generated_cuda_d3d10_interop_meta.h>
//#include <generated_cuda_d3d11_interop_meta.h>
//#include <generated_cudaD3D9_meta.h>
//#include <generated_cudaD3D10_meta.h>
//#include <generated_cudaD3D11_meta.h>
#endif

#endif

#endif /* __RPP_PTI_H__ */


