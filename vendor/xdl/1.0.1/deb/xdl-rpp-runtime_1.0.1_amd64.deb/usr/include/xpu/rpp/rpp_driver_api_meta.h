#ifndef __RPP_DRIVER_API_META__
#define __RPP_DRIVER_API_META__

#include "rpp_drv_api.h"

#define MAX_PATH_LEN 1024
#define MAX_FUNC_NAME 255
#define MAX_BUSID_LEN 16
#define MAX_USER_PARAM_SIZE 256
#define MAX_USER_PARAM_DESC_SIZE (MAX_USER_PARAM_SIZE * 8)
#define MAX_EXTRA_PARAM_SIZE 4
#define MAX_LOGBUF_LEN 1024
#define MAX_NODE_DEPENDENCIES 16
#define MAX_NODE_IN_GRAPH 0x20000
#define MAX_CDMA_LINK_NUM 512

// The meta of RPP_MEMCPY for rpp_server private use
typedef struct RPP_MEMCPY_META_st
{
    size_t batch;
    size_t depth;
    RPParray dst_array;
    RPPdeviceptr dst;
    size_t dst_depth;
    size_t dst_height;
    uint64_t dst_host;
    shm_info_t dst_shm_info;
    int dst_shm_is_hugetlb;
    size_t dstLOD;
    RPPmemorytype dst_type;
    size_t dst_pitch;
    size_t dst_x;
    size_t dst_y;
    size_t dst_z;
    size_t dst_n;
    size_t height;
    RPParray src_array;
    RPPdeviceptr src;
    size_t src_depth;
    size_t src_height;
    uint64_t src_host;
    shm_info_t src_shm_info;
    int src_shm_is_hugetlb;
    size_t srcLOD;
    RPPmemorytype src_type;
    size_t src_pitch;
    size_t src_x;
    size_t src_y;
    size_t src_z;
    size_t src_n;
    size_t width;
} RPP_MEMCPY_META;

typedef struct RPP_MEMCPY_LINK_META_st
{
    RPPdeviceptr dst[MAX_CDMA_LINK_NUM];
    RPPmemorytype dst_type;
    RPPdeviceptr src[MAX_CDMA_LINK_NUM];
    RPPmemorytype src_type;
    size_t size[MAX_CDMA_LINK_NUM];
    size_t num;
} RPP_MEMCPY_LINK_META;

typedef struct RPP_MEMCPY_INTERLEAVER_META_st
{
    RPPdeviceptr dst;
    RPPmemorytype dst_type;
    RPPdeviceptr src0;
    RPPdeviceptr src1;
    RPPmemorytype src_type;
    size_t size;
} RPP_MEMCPY_INTERLEAVER_META;

typedef struct RPP_MEMCPY_DEINTERLEAVER_META_st
{
    RPPdeviceptr dst0;
    RPPdeviceptr dst1;
    RPPmemorytype dst_type;
    RPPdeviceptr src;
    RPPmemorytype src_type;
    size_t size;
} RPP_MEMCPY_DEINTERLEAVER_META;

typedef struct RPP_MEMCPY_SRAMSPILL_META_st
{
    RPPmemorytype dst_type;
    RPPmemorytype src_type;
} RPP_MEMCPY_SRAMSPILL_META;

typedef struct RPP_EVENT_META_st
{
    uint64_t eventID;
    uint64_t recorded_id;
} RPP_EVENT_META;

typedef struct RPP_SET_PARAMS_META_st
{
    uint64_t orig_execnodeID;
    uint32_t orig_exec_type;
    void *new_node_params;
    void *new_info;
} RPP_SET_PARAMS_META;

typedef struct RPP_MPU_MSG_META_st
{
    uint32_t type;
    uint32_t payload[6];
    uint32_t flags;
    uint32_t reserved0;
} RPP_MPU_MSG_META;

#define RPP_MPU_MSG_FLAG_WAIT_COMPLETE 0x1U

typedef struct RPP_MEMCPY_INDIRECT_UPDATE_NODE_META_st
{
    uint64_t targetNodeID;
    uint32_t requestFlags;
    uint32_t reserved0;
    RPP_MEMCPY_INDIRECT_UPDATE_PARAMS nodeParams;
} RPP_MEMCPY_INDIRECT_UPDATE_NODE_META;

typedef struct rppGetErrorString_params_st
{
    RPPresult error;
    const char **pStr;
} rppGetErrorString_params;

typedef struct rppGetErrorName_params_st
{
    RPPresult error;
    const char **pStr;
} rppGetErrorName_params;

typedef struct rppInit_params_st
{
    unsigned int Flags;
} rppInit_params;

typedef struct rppExit_params_st
{
    unsigned int Flags;
} rppExit_params;

typedef struct rppDriverGetVersion_params_st
{
    int *driverVersion;
} rppDriverGetVersion_params;

typedef struct rppDeviceGet_params_st
{
    uint64_t devID; /* < */
    int ordinal;    /* > */
} rppDeviceGet_params;

typedef struct rppDeviceGetCount_params_st
{
    int count;
} rppDeviceGetCount_params;

typedef struct rppDeviceGetName_params_st
{
    uint64_t devID;
    char name[MAX_FUNC_NAME];
} rppDeviceGetName_params;

typedef struct rppDeviceTotalMem_params_st
{
    uint64_t devID;
    size_t bytes;
} rppDeviceTotalMem_params;

typedef struct rppDeviceGetAttribute_params_st
{
    uint64_t devID;
    int pi;
    RPPdevice_attribute attrib;
} rppDeviceGetAttribute_params;

typedef struct rppDeviceGetProperties_params_st
{
    uint64_t devID;
    RPPdevprop prop;
} rppDeviceGetProperties_params;

typedef struct rppDeviceComputeCapability_params_st
{
    uint64_t devID;
    int major;
    int minor;
} rppDeviceComputeCapability_params;

typedef struct rppCodec_params_st
{
    RPPcontext ctxID;
    RPPCodec codec;
} rppCodec_params;

typedef struct rppDeviceGetCodecInfo_params_st
{
    uint64_t devID;
    RPPdevCodecInfo codecInfo;
} rppDeviceGetCodecInfo_params;

#if 0
typedef struct rppDeviceRegRead_params_st {
    RPPDevice_ctx devCtx;
    uint32_t regAddr;
    uint32_t rData;
} rppDeviceRegRead_params;

typedef struct rppDeviceRegWrite_params_st {
    RPPDevice_ctx devCtx;
    uint32_t regAddr;
    uint32_t wData;
} rppDeviceRegWrite_params;
#else
typedef struct rppDeviceRegRead_params_st
{
    uint64_t devID;
    RPPRegRegion region;
    uint32_t regAddr;
    uint32_t regLen;
    void *rData;
} rppDeviceRegRead_params;

typedef struct rppDeviceRegWrite_params_st
{
    uint64_t devID;
    RPPRegRegion region;
    uint32_t regAddr;
    uint32_t regLen;
    void *wData;
} rppDeviceRegWrite_params;
#endif

typedef struct rppDeviceRegRead32_params_st
{
    uint64_t devID;
    uint64_t addr;
    uint32_t value;
} rppDeviceRegRead32_params;

typedef struct rppDeviceRegWrite32_params_st
{
    uint64_t devID;
    uint64_t addr;
    uint32_t value;
} rppDeviceRegWrite32_params;

typedef struct rppDeviceSetLimit_params_st
{
    uint64_t devID;
    size_t value;
    RPPlimit limit;
} rppDeviceSetLimit_params;

typedef struct rppDeviceGetLimit_params_st
{
    uint64_t devID;
    size_t value;
    RPPlimit limit;
} rppDeviceGetLimit_params;

typedef struct rppCtxCreate_params_st
{
    uint64_t devID;
    uint64_t ctxID;
    unsigned int flags;
} rppCtxCreate_params;

typedef struct rppCtxDestroy_params_st
{
    uint64_t ctxID;
} rppCtxDestroy_params;

typedef struct rppCtxPushCurrent_params_st
{
    uint64_t ctxID;
} rppCtxPushCurrent_params;

typedef struct rppCtxPopCurrent_params_st
{
    uint64_t ctxID;
} rppCtxPopCurrent_params;

typedef struct rppCtxSetCurrent_params_st
{
    uint64_t ctxID;
} rppCtxSetCurrent_params;

typedef struct rppCtxGetCurrent_params_st
{
    uint64_t ctxID;
} rppCtxGetCurrent_params;

typedef struct rppCtxGetDevice_params_st
{
    uint64_t devID;
} rppCtxGetDevice_params;

typedef struct rppCtxGetSpecified_params_st
{
    uint64_t devID;
    uint64_t ctxID;
} rppCtxGetSpecified_params;

typedef struct rppCtxSynchronize_params_st
{
    uint32_t pad;
} rppCtxSynchronize_params;

typedef struct rppCtxGetFlags_params_st
{
    uint32_t flags;
} rppCtxGetFlags_params;

typedef struct rppCtxSetLimit_params_st
{
    RPPlimit limit;
    size_t value;
} rppCtxSetLimit_params;

typedef struct rppCtxGetLimit_params_st
{
    size_t value;
    RPPlimit limit;
} rppCtxGetLimit_params;

typedef struct rppCtxGetCacheConfig_params_st
{
    RPPfunc_cache config;
} rppCtxGetCacheConfig_params;

typedef struct rppCtxSetCacheConfig_params_st
{
    RPPfunc_cache config;
} rppCtxSetCacheConfig_params;

typedef struct rppCtxGetSharedMemConfig_params_st
{
    RPPsharedconfig config;
} rppCtxGetSharedMemConfig_params;

typedef struct rppCtxSetSharedMemConfig_params_st
{
    RPPsharedconfig config;
} rppCtxSetSharedMemConfig_params;

typedef struct rppCtxGetApiVersion_params_st
{
    uint64_t ctxID;
    uint32_t version;
} rppCtxGetApiVersion_params;

#if 0 // Not support yet, 20210526, will jiang
typedef struct rppCtxGetStreamPriorityRange_params_st {
    int *leastPriority;
    int *greatestPriority;
} rppCtxGetStreamPriorityRange_params;

typedef struct rppCtxAttach_params_st {
    uint64_t ctxID;
    unsigned int flags;
} rppCtxAttach_params;

typedef struct rppCtxDetach_params_st {
    uint64_t ctxID;
} rppCtxDetach_params;
#endif

typedef struct rppModuleLoad_params_st
{
    uint64_t modID;
    const void *image;
    shm_info_t shm_info;
    char fname[MAX_PATH_LEN];
} rppModuleLoad_params;

typedef struct rppModuleLoadData_params_st
{
    uint64_t modID;
    const void *image;
    shm_info_t shm_info;
} rppModuleLoadData_params;

typedef struct rppModuleLoadDataEx_params_st
{
    uint64_t modID;
    const void *image;
    shm_info_t shm_info;
    unsigned int numOptions;
    void *options;
    void **optionValues;
} rppModuleLoadDataEx_params;

typedef struct rppModuleLoadFatBinary_params_st
{
    uint64_t modID;
    const void *fatCubin;
} rppModuleLoadFatBinary_params;

typedef struct rppModuleUnload_params_st
{
    uint64_t modID;
} rppModuleUnload_params;

typedef struct rppModuleGetFunction_params_st
{
    uint64_t modID;
    uint64_t funcID;
    char name[MAX_FUNC_NAME];
} rppModuleGetFunction_params;

typedef struct rppModuleGetGlobal_params_st
{
    uint64_t modID;
    uint64_t ptr;
    size_t *bytes;
    const char *name;
} rppModuleGetGlobal_params;

#if 0 // Not support yet, 20210526, will jiang
typedef struct rppLinkCreate_params_st {
    unsigned int numOptions;
    RPPjit_option *options;
    void **optionValues;
    RPPlinkState *stateOut;
} rppLinkCreate_params;

typedef struct rppLinkAddData_params_st {
    RPPlinkState state;
    RPPjitInputType type;
    void *data;
    size_t size;
    const char *name;
    unsigned int numOptions;
    RPPjit_option *options;
    void **optionValues;
} rppLinkAddData_params;

typedef struct rppLinkAddFile_params_st {
    RPPlinkState state;
    RPPjitInputType type;
    const char *path;
    unsigned int numOptions;
    RPPjit_option *options;
    void **optionValues;
} rppLinkAddFile_params;

typedef struct rppLinkComplete_params_st {
    RPPlinkState state;
    void **cubinOut;
    size_t *sizeOut;
} rppLinkComplete_params;

typedef struct rppLinkDestroy_params_st {
    RPPlinkState state;
} rppLinkDestroy_params;
#endif

typedef struct rppMemGetInfo_params_st
{
    size_t free;
    size_t total;
} rppMemGetInfo_params;

typedef struct rppMemAlloc_params_st
{
    uint64_t ptr;
    size_t bytesize;
} rppMemAlloc_params;

typedef struct rppMemFree_params_st
{
    uint64_t ptr;
} rppMemFree_params;

typedef struct rppMemGetAddressRange_params_st
{
    uint64_t pBase;
    size_t *psize;
    uint64_t ptr;
} rppMemGetAddressRange_params;

typedef struct rppMemAllocHost_params_st
{
    uint64_t ptr;
    shm_info_t shm_info;
    uint32_t is_hugetlb;
    size_t bytesize;
} rppMemAllocHost_params;

typedef struct rppMemFreeHost_params_st
{
    uint64_t ptr;
    shm_info_t shm_info;
} rppMemFreeHost_params;

typedef struct rppSramAlloc_params_st
{
    uint64_t ptr;
    size_t bytesize;
} rppSramAlloc_params;

typedef struct rppSramFree_params_st
{
    uint64_t ptr;
} rppSramFree_params;

typedef struct rppVirtSramAlloc_params_st
{
    uint64_t ptr;
    size_t bytesize;
} rppVirtSramAlloc_params;

typedef struct rppVirtSramFree_params_st
{
    uint64_t ptr;
} rppVirtSramFree_params;

typedef struct rppMpumemAlloc_params_st
{
    uint64_t ptr;
    size_t bytesize;
    RPPmpumem_flags flags;
} rppMpumemAlloc_params;

typedef struct rppMpumemFree_params_st
{
    uint64_t ptr;
} rppMpumemFree_params;

typedef struct rppMemcpyHtoM_params_st
{
    uint64_t dstPtr;
    uint64_t srcPtr;
    shm_info_t shm_info;
    size_t ByteCount;
} rppMemcpyHtoM_params;

typedef struct rppMemcpyMtoH_params_st
{
    uint64_t dstPtr;
    shm_info_t shm_info;
    uint64_t srcPtr;
    size_t ByteCount;
} rppMemcpyMtoH_params;

typedef struct rppMemcpyHtoMAsync_params_st
{
    uint64_t streamID;
    uint64_t dstPtr;
    uint64_t srcPtr;
    shm_info_t shm_info;
    size_t ByteCount;
} rppMemcpyHtoMAsync_params;

typedef struct rppMemcpyMtoHAsync_params_st
{
    uint64_t streamID;
    uint64_t dstPtr;
    shm_info_t shm_info;
    uint64_t srcPtr;
    size_t ByteCount;
} rppMemcpyMtoHAsync_params;

typedef struct rppMpumemMemsetD8_params_st
{
    uint64_t dstPtr;
    unsigned char uc;
    size_t N;
} rppMpumemMemsetD8_params;

typedef struct rppMpumemMemsetD8Async_params_st
{
    uint64_t streamID;
    uint64_t dstPtr;
    unsigned char uc;
    size_t N;
} rppMpumemMemsetD8Async_params;

typedef struct rppMemGetPhysAddr_params_st
{
    uint64_t virt;
    uint64_t phys;
} rppMemGetPhysAddr_params;

typedef struct rppMemGetVirtAddr_params_st
{
    uint64_t phys;
    RPPmemorytype type;
    uint64_t virt;
} rppMemGetVirtAddr_params;

#if 0 // Not support yet, 20210526, will jiang
typedef struct rppMemHostAlloc_params_st {
    void **pp;
    size_t bytesize;
    unsigned int Flags;
} rppMemHostAlloc_params;

typedef struct rppMemHostGetDevicePointer_params_st {
    uint64_t ptr;
    void *p;
    unsigned int Flags;
} rppMemHostGetDevicePointer_params;

typedef struct rppMemHostGetFlags_params_st {
    unsigned int *pFlags;
    void *p;
} rppMemHostGetFlags_params;

typedef struct rppMemAllocManaged_params_st {
    uint64_t ptr;
    size_t bytesize;
    unsigned int flags;
} rppMemAllocManaged_params;
#endif

typedef struct rppDeviceGetByPCIBusId_params_st
{
    uint64_t devID;
    const char busid[MAX_BUSID_LEN];
} rppDeviceGetByPCIBusId_params;

typedef struct rppDeviceGetPCIBusId_params_st
{
    uint64_t devID;
    char busid[MAX_BUSID_LEN];
    int len;
} rppDeviceGetPCIBusId_params;

#if 0 // Not support yet, 20210526, will jiang
typedef struct rppIpcGetEventHandle_params_st {
    CUipcEventHandle *pHandle;
    RPPevent event;
} rppIpcGetEventHandle_params;

typedef struct rppIpcOpenEventHandle_params_st {
    uint64_t eventID;
    CUipcEventHandle handle;
} rppIpcOpenEventHandle_params;

typedef struct rppIpcGetMemHandle_params_st {
    CUipcMemHandle *pHandle;
    uint64_t ptr;
} rppIpcGetMemHandle_params;

typedef struct rppIpcOpenMemHandle_params_st {
    uint64_t ptr;
    CUipcMemHandle handle;
    unsigned int Flags;
} rppIpcOpenMemHandle_params;

typedef struct rppIpcCloseMemHandle_params_st {
    uint64_t ptr;
} rppIpcCloseMemHandle_params;
#endif

#if 0 // Not support yet, 20210526, will jiang
typedef struct rppMemHostRegister_params_st {
    void *p;
    size_t bytesize;
    unsigned int Flags;
} rppMemHostRegister_params;

typedef struct rppMemHostUnregister_params_st {
    void *p;
} rppMemHostUnregister_params;
#endif

typedef struct rppMemcpy_params_st
{
    RPP_MEMCPY_META meta;
} rppMemcpy_params;

typedef struct rppMemcpyAsync_params_st
{
    uint64_t streamID;
    RPP_MEMCPY_META meta;
} rppMemcpyAsync_params;

typedef struct rppMemcpyLink_params_st
{
    RPP_MEMCPY_LINK_META meta;
} rppMemcpyLink_params;

typedef struct rppMemcpyLinkAsync_params_st
{
    uint64_t streamID;
    RPP_MEMCPY_LINK_META meta;
} rppMemcpyLinkAsync_params;

typedef struct rppMemsetD8_params_st
{
    uint64_t dstPtr;
    unsigned char uc;
    size_t N;
} rppMemsetD8_params;

typedef struct rppMemsetD16_params_st
{
    uint64_t dstPtr;
    unsigned short us;
    size_t N;
} rppMemsetD16_params;

typedef struct rppMemsetD32_params_st
{
    uint64_t dstPtr;
    unsigned int ui;
    size_t N;
} rppMemsetD32_params;

typedef struct rppSramMemsetD8_params_st
{
    uint64_t dstPtr;
    unsigned char uc;
    size_t N;
} rppSramMemsetD8_params;

typedef struct rppMemsetD8Async_params_st
{
    uint64_t streamID;
    uint64_t dstPtr;
    unsigned char uc;
    size_t N;
} rppMemsetD8Async_params;

typedef struct rppMemsetD16Async_params_st
{
    uint64_t streamID;
    uint64_t dstPtr;
    unsigned short us;
    size_t N;
} rppMemsetD16Async_params;

typedef struct rppMemsetD32Async_params_st
{
    uint64_t streamID;
    uint64_t dstPtr;
    unsigned int ui;
    size_t N;
} rppMemsetD32Async_params;

typedef struct rppMemcpyInterLeaver_params_st
{
    RPP_MEMCPY_INTERLEAVER_META meta;
} rppMemcpyInterLeaver_params;

typedef struct rppMemcpyDeInterLeaver_params_st
{
    RPP_MEMCPY_DEINTERLEAVER_META meta;
} rppMemcpyDeInterLeaver_params;

typedef struct rppMemcpyInterLeaverAsync_params_st
{
    uint64_t streamID;
    RPP_MEMCPY_INTERLEAVER_META meta;
} rppMemcpyInterLeaverAsync_params;

typedef struct rppMemcpyDeInterLeaverAsync_params_st
{
    uint64_t streamID;
    RPP_MEMCPY_DEINTERLEAVER_META meta;
} rppMemcpyDeInterLeaverAsync_params;

typedef struct rppStreamCreate_params_st
{
    uint64_t streamID;
    unsigned int Flags;
} rppStreamCreate_params;

typedef struct rppStreamWaitEvent_params_st
{
    uint64_t streamID;
    uint64_t eventID;
    unsigned int Flags;
} rppStreamWaitEvent_params;

typedef struct rppStreamAddCallback_params_st
{
    uint64_t streamID;
    RPPstreamCallback callback;
    void *userData;
    unsigned int flags;
} rppStreamAddCallback_params;

typedef struct rppStreamQuery_params_st
{
    uint64_t streamID;
} rppStreamQuery_params;

typedef struct rppStreamSynchronize_params_st
{
    uint64_t streamID;
} rppStreamSynchronize_params;

typedef struct rppStreamDestroy_params_st
{
    uint64_t streamID;
} rppStreamDestroy_params;

typedef struct rppSemWait_params_st
{
    uint64_t streamID;
    uint32_t sem;
} rppSemWait_params;

typedef struct rppSemPost_params_st
{
    uint64_t streamID;
    uint32_t sem;
} rppSemPost_params;

typedef struct rppStreamRecord_params_st
{
    uint64_t streamID;
} rppStreamRecord_params;

typedef struct rppStreamSetInOut_params_st
{
    uint64_t streamID;
    uint64_t in;
    uint64_t out;
} rppStreamSetInOut_params;

typedef struct rppReplay_params_st
{
    uint32_t resv;
} rppReplay_params;

typedef struct rppEventCreate_params_st
{
    uint64_t eventID;
    unsigned int Flags;
} rppEventCreate_params;

typedef struct rppEventRecord_params_st
{
    uint64_t eventID;
    uint64_t streamID;
} rppEventRecord_params;

typedef struct rppEventQuery_params_st
{
    uint64_t eventID;
} rppEventQuery_params;

typedef struct rppEventSynchronize_params_st
{
    uint64_t eventID;
} rppEventSynchronize_params;

typedef struct rppEventDestroy_params_st
{
    uint64_t eventID;
} rppEventDestroy_params;

typedef struct rppEventElapsedTime_params_st
{
    RPPevent hStart;
    RPPevent hEnd;
    uint64_t us;
} rppEventElapsedTime_params;

typedef struct rppEventReset_params_st
{
    uint64_t streamID;
    uint64_t eventID;
} rppEventReset_params;

typedef struct rppEventGetOccupied_params_st
{
    uint32_t cevent_num;
    uint32_t gevent_num;
} rppEventGetOccupied_params;

#if 0 // Not support yet, 20210526, will jiang
typedef struct rppFuncGetAttribute_params_st {
    uint64_t funcID;
    int *pi;
    RPPfunction_attribute attrib;
} rppFuncGetAttribute_params;

typedef struct rppFuncSetAttribute_params_st {
    uint64_t funcID;
    RPPfunction_attribute attrib;
    int value;
} rppFuncSetAttribute_params;

typedef struct rppFuncSetCacheConfig_params_st {
    uint64_t funcID;
    RPPfunc_cache config;
} rppFuncSetCacheConfig_params;

typedef struct rppFuncSetSharedMemConfig_params_st {
    uint64_t funcID;
    RPPsharedconfig config;
} rppFuncSetSharedMemConfig_params;
#endif

typedef struct rppGetParamFormat_params_st
{
    uint64_t funcID;
    uint8_t param_desc[MAX_USER_PARAM_DESC_SIZE]; // total 256*8 bytes;
} rppGetParamFormat_params;

typedef struct rppLaunchKernel_params_st
{
    uint64_t streamID;
    RPP_KERNEL_NODE_PARAMS meta;
} rppLaunchKernel_params;

#if 0 // Not support yet, 20210526, will jiang
typedef struct rppLaunchCooperativeKernel_params_st {
    uint64_t streamID;
    uint64_t funcID;
    unsigned int gridDimX;
    unsigned int gridDimY;
    unsigned int gridDimZ;
    unsigned int blockDimX;
    unsigned int blockDimY;
    unsigned int blockDimZ;
    unsigned int sharedMemBytes;
    void **kernelParams;
} rppLaunchCooperativeKernel_params;

typedef struct rppLaunchCooperativeKernelMultiDevice_params_st {
    RPP_LAUNCH_PARAMS *launchParamsList;
    unsigned int numDevices;
    unsigned int flags;
} rppLaunchCooperativeKernelMultiDevice_params;

typedef struct rppFuncSetBlockShape_params_st {
    uint64_t funcID;
    int x;
    int y;
    int z;
} rppFuncSetBlockShape_params;

typedef struct rppFuncSetSharedSize_params_st {
    uint64_t funcID;
    unsigned int bytes;
} rppFuncSetSharedSize_params;
#endif

typedef struct rppParamSetSize_params_st
{
    uint64_t funcID;
    unsigned int numbytes;
} rppParamSetSize_params;

typedef struct rppParamSeti_params_st
{
    uint64_t funcID;
    int offset;
    unsigned int value;
} rppParamSeti_params;

typedef struct rppParamSetf_params_st
{
    uint64_t funcID;
    int offset;
    float value;
} rppParamSetf_params;

typedef struct rppParamSetv_params_st
{
    uint64_t funcID;
    int offset;
    void *ptr;
    unsigned int numbytes;
} rppParamSetv_params;

typedef struct rppLaunch_params_st
{
    uint64_t funcID;
} rppLaunch_params;

typedef struct rppLaunchGrid_params_st
{
    uint64_t funcID;
    int grid_width;
    int grid_height;
} rppLaunchGrid_params;

typedef struct rppLaunchGridAsync_params_st
{
    uint64_t streamID;
    uint64_t funcID;
    int grid_width;
    int grid_height;
} rppLaunchGridAsync_params;

#if 0 // Not support yet, 20210526, will jiang
typedef struct rppLinkCreate_params_st {
    unsigned int numOptions;
    RPPjit_option *options;
    void **optionValues;
    RPPlinkState *stateOut;
} rppLinkCreate_params;

typedef struct rppLinkAddData_params_st {
    RPPlinkState state;
    RPPjitInputType type;
    void *data;
    size_t size;
    const char *name;
    unsigned int numOptions;
    RPPjit_option *options;
    void **optionValues;
} rppLinkAddData_params;

typedef struct rppLinkAddFile_params_st {
    RPPlinkState state;
    RPPjitInputType type;
    const char *path;
    unsigned int numOptions;
    RPPjit_option *options;
    void **optionValues;
} rppLinkAddFile_params;
#endif

typedef struct rppDevicePrimaryCtxGetState_params_st
{
    uint64_t devID;
    uint32_t flags;
    int32_t active;
} rppDevicePrimaryCtxGetState_params;

typedef struct rppDevicePrimaryCtxRelease_params_st
{
    uint64_t devID;
} rppDevicePrimaryCtxRelease_params;

typedef struct rppDevicePrimaryCtxReset_params_st
{
    uint64_t devID;
} rppDevicePrimaryCtxReset_params;

typedef struct rppDevicePrimaryCtxRetain_params_st
{
    uint64_t devID;
    uint64_t ctxID;
} rppDevicePrimaryCtxRetain_params;

typedef struct rppDevicePrimaryCtxSetFlags_params_st
{
    uint64_t devID;
    uint32_t flags;
} rppDevicePrimaryCtxSetFlags_params;

typedef struct rppProfilerInitialize_params_st
{
    char cfg_fname[MAX_PATH_LEN];
    char output_fname[MAX_PATH_LEN];
    RPPoutput_mode outputMode;
} rppProfilerInitialize_params;

typedef struct rppProfilerStart_params_st
{
    uint32_t resv;
} rppProfilerStart_params;

typedef struct rppProfilerStop_params_st
{
    uint32_t resv;
} rppProfilerStop_params;

typedef struct rppLogsDumpToTraceWindows_params_st
{
    uint32_t window_id;
    uint32_t mode;
    char path[MAX_PATH_LEN];
    uint64_t ts;
} rppLogsDumpToTraceWindows_params;

typedef struct rppStreamBeginCapture_params_st
{
    uint64_t streamID;
    RPPstreamCaptureMode mode;
} rppStreamBeginCapture_params;

typedef struct rppStreamEndCapture_params_st
{
    uint64_t streamID;
    uint64_t graphID;
} rppStreamEndCapture_params;

typedef struct rppStreamIsCapturing_params_st
{
    uint64_t streamID;
    RPPstreamCaptureStatus status;
} rppStreamIsCapturing_params;

typedef struct rppGraphCreate_params_st
{
    uint64_t graphID;
    unsigned int Flags;
} rppGraphCreate_params;

typedef struct rppGraphClone_params_st
{
    uint64_t originalGraphID;
    uint64_t newCloneID;
} rppGraphClone_params;

typedef struct rppGraphInstantiate_params_st
{
    uint64_t graphID;
    uint64_t graphExecID;
    uint64_t errorNodeID;
    uint8_t logBuffer[MAX_LOGBUF_LEN];
    size_t bufferSize;
} rppGraphInstantiate_params;

typedef struct rppGraphSerializePara_params_st
{
    uint64_t graphExecID;
    uint32_t type;
    uint32_t size;
    uint8_t data[MAX_LOGBUF_LEN];
    // void* data;
} rppGraphSerializePara_params;
typedef struct rppGraphSerialize_params_st
{
    uint64_t graphExecID;
    char gpath[MAX_PATH_LEN];
    uint32_t flag;
} rppGraphSerialize_params;

typedef struct rppGraphLaunch_params_st
{
    uint64_t streamID;
    uint64_t graphExecID;
} rppGraphLaunch_params;

typedef struct rppGraphExecDestroy_params_st
{
    uint64_t graphExecID;
} rppGraphExecDestroy_params;

typedef struct rppGraphDestroy_params_st
{
    uint64_t graphID;
} rppGraphDestroy_params;

typedef struct rppGraphAddKernelNode_params_st
{
    uint64_t graphID;
    uint64_t nodeID;
    uint64_t dependNodeID[MAX_NODE_DEPENDENCIES];
    uint32_t numDependencies;
    RPP_KERNEL_NODE_PARAMS nodeParams;
} rppGraphAddKernelNode_params;

typedef struct rppGraphKernelNodeGetParams_params_st
{
    uint64_t nodeID;
    RPP_KERNEL_NODE_PARAMS nodeParams;
} rppGraphKernelNodeGetParams_params;

typedef struct rppGraphKernelNodeSetParams_params_st
{
    uint64_t nodeID;
    RPP_KERNEL_NODE_PARAMS nodeParams;
} rppGraphKernelNodeSetParams_params;

typedef struct rppGraphExecKernelNodeSetParams_params_st
{
    uint64_t graphExecID;
    uint64_t nodeID;
    RPP_KERNEL_NODE_PARAMS nodeParams;
} rppGraphExecKernelNodeSetParams_params;

typedef struct rppGraphExecKernelNodeSetParamsAsync_params_st
{
    uint64_t streamID;
    uint64_t graphExecID;
    uint64_t nodeID;
    RPP_KERNEL_NODE_PARAMS nodeParams;
} rppGraphExecKernelNodeSetParamsAsync_params;

typedef struct rppGraphAddMemcpyNode_params_st
{
    uint64_t ctxID;
    uint64_t graphID;
    uint64_t nodeID;
    uint64_t dependNodeID[MAX_NODE_DEPENDENCIES];
    uint32_t numDependencies;
    RPP_MEMCPY_META nodeParamsMeta;
} rppGraphAddMemcpyNode_params;

typedef struct rppGraphMemcpyNodeGetParams_params_st
{
    uint64_t nodeID;
    RPP_MEMCPY_META nodeParamsMeta;
} rppGraphMemcpyNodeGetParams_params;

typedef struct rppGraphMemcpyNodeSetParams_params_st
{
    uint64_t nodeID;
    RPP_MEMCPY_META nodeParamsMeta;
} rppGraphMemcpyNodeSetParams_params;

typedef struct rppGraphExecMemcpyNodeSetParams_params_st
{
    uint64_t ctxID;
    uint64_t graphExecID;
    uint64_t nodeID;
    RPP_MEMCPY_META nodeParamsMeta;
} rppGraphExecMemcpyNodeSetParams_params;

typedef struct rppGraphExecMemcpyNodeSetParamsAsync_params_st
{
    uint64_t streamID;
    uint64_t ctxID;
    uint64_t graphExecID;
    uint64_t nodeID;
    RPP_MEMCPY_META nodeParamsMeta;
} rppGraphExecMemcpyNodeSetParamsAsync_params;

typedef struct rppGraphExecMemcpyNodeSetIndirectParamsAsync_params_st
{
    uint64_t streamID;
    uint64_t ctxID;
    uint64_t graphExecID;
    uint64_t nodeID;
    uint32_t requestFlags;
    uint32_t reserved0;
    RPP_MEMCPY_INDIRECT_UPDATE_PARAMS nodeParams;
} rppGraphExecMemcpyNodeSetIndirectParamsAsync_params;

typedef struct rppGraphMemcpyNodeSetIndirectParamsAsync_params_st
{
    uint64_t streamID;
    uint64_t ctxID;
    uint64_t graphID;
    uint64_t nodeID;
    uint32_t requestFlags;
    uint32_t reserved0;
    RPP_MEMCPY_INDIRECT_UPDATE_PARAMS nodeParams;
} rppGraphMemcpyNodeSetIndirectParamsAsync_params;

typedef struct rppGraphMemcpyIndirectUpdateNodeSetParams_params_st
{
    uint64_t graphID;
    uint64_t nodeID;
    uint64_t targetNodeID;
    uint32_t requestFlags;
    uint32_t reserved0;
    RPP_MEMCPY_INDIRECT_UPDATE_PARAMS nodeParams;
} rppGraphMemcpyIndirectUpdateNodeSetParams_params;

typedef struct rppGraphAddMemsetNode_params_st
{
    uint64_t ctxID;
    uint64_t graphID;
    uint64_t nodeID;
    uint64_t dependNodeID[MAX_NODE_DEPENDENCIES];
    uint32_t numDependencies;
    RPP_MEMSET_NODE_PARAMS nodeParams;
} rppGraphAddMemsetNode_params;

typedef struct rppGraphMemsetNodeGetParams_params_st
{
    uint64_t nodeID;
    RPP_MEMSET_NODE_PARAMS nodeParams;
} rppGraphMemsetNodeGetParams_params;

typedef struct rppGraphMemsetNodeSetParams_params_st
{
    uint64_t nodeID;
    RPP_MEMSET_NODE_PARAMS nodeParams;
} rppGraphMemsetNodeSetParams_params;

typedef struct rppGraphExecMemsetNodeSetParams_params_st
{
    uint64_t ctxID;
    uint64_t graphExecID;
    uint64_t nodeID;
    RPP_MEMSET_NODE_PARAMS nodeParams;
} rppGraphExecMemsetNodeSetParams_params;

typedef struct rppGraphExecMemsetNodeSetParamsAsync_params_st
{
    uint64_t streamID;
    uint64_t ctxID;
    uint64_t graphExecID;
    uint64_t nodeID;
    RPP_MEMSET_NODE_PARAMS nodeParams;
} rppGraphExecMemsetNodeSetParamsAsync_params;

typedef struct rppGraphAddHostNode_params_st
{
    uint64_t graphID;
    uint64_t nodeID;
    uint64_t dependNodeID[MAX_NODE_DEPENDENCIES];
    uint32_t numDependencies;
    RPP_HOST_NODE_PARAMS nodeParams;
} rppGraphAddHostNode_params;

typedef struct rppGraphHostNodeGetParams_params_st
{
    uint64_t nodeID;
    RPP_HOST_NODE_PARAMS nodeParams;
} rppGraphHostNodeGetParams_params;

typedef struct rppGraphHostNodeSetParams_params_st
{
    uint64_t nodeID;
    RPP_HOST_NODE_PARAMS nodeParams;
} rppGraphHostNodeSetParams_params;

typedef struct rppGraphExecHostNodeSetParams_params_st
{
    uint64_t graphExecID;
    uint64_t nodeID;
    RPP_HOST_NODE_PARAMS nodeParams;
} rppGraphExecHostNodeSetParams_params;

typedef struct rppGraphExecHostNodeSetParamsAsync_params_st
{
    uint64_t streamID;
    uint64_t graphExecID;
    uint64_t nodeID;
    RPP_HOST_NODE_PARAMS nodeParams;
} rppGraphExecHostNodeSetParamsAsync_params;

typedef struct rppGraphAddChildGraphNode_params_st
{
    uint64_t graphID;
    uint64_t nodeID;
    uint64_t dependNodeID[MAX_NODE_DEPENDENCIES];
    uint32_t numDependencies;
    uint64_t childGraphID;
} rppGraphAddChildGraphNode_params;

typedef struct rppGraphAddChildGraphexecNode_params_st
{
    uint64_t graphID;
    uint64_t nodeID;
    uint64_t dependNodeID[MAX_NODE_DEPENDENCIES];
    uint32_t numDependencies;
    uint64_t childGraphExecID;
} rppGraphAddChildGraphexecNode_params;

typedef struct rppGraphAddDynamicSelectGraphNode_params_st
{
    uint64_t graphID;
    uint64_t nodeID;
    uint64_t dependNodeID[MAX_NODE_DEPENDENCIES];
    uint32_t numDependencies;
    RPP_MPU_MSG_META nodeParams;
} rppGraphAddDynamicSelectGraphNode_params;

typedef struct rppGraphUpdateChildGraph_params_st
{
    uint64_t graphID;
    uint64_t targetChildNodeID;
    uint64_t oldChildGraphID;
    uint64_t newChildGraphID;
    uint32_t flags;
} rppGraphUpdateChildGraph_params;

typedef struct rppGraphChildGraphNodeGetGraph_params_st
{
    uint64_t graphID;
    uint64_t nodeID;
} rppGraphChildGraphNodeGetGraph_params;

typedef struct rppGraphAddEmptyNode_params_st
{
    uint64_t graphID;
    uint64_t nodeID;
    uint64_t dependNodeID[MAX_NODE_DEPENDENCIES];
    uint32_t numDependencies;
} rppGraphAddEmptyNode_params;

typedef struct rppGraphNodeGetType_params_st
{
    uint64_t nodeID;
    RPPgraphNodeType nodeType;
} rppGraphNodeGetType_params;

typedef struct rppGraphGetNodes_params_st
{
    uint64_t graphID;
    uint32_t numNodes;
    shm_info_t shm_info;
    uint32_t shm_size;
    // uint64_t nodeID[MAX_NODE_IN_GRAPH];
} rppGraphGetNodes_params;

typedef struct rppGraphGetRootNodes_params_st
{
    uint64_t graphID;
    shm_info_t root_shm_info;
    uint32_t root_shm_size;
    uint32_t numRootNodes;
} rppGraphGetRootNodes_params;

typedef struct rppGraphGetEdges_params_st
{
    uint64_t graphID;
    shm_info_t from_shm_info;
    uint32_t from_shm_size;
    shm_info_t to_shm_info;
    uint32_t to_shm_size;
    size_t numEdges;
} rppGraphGetEdges_params;

typedef struct rppGraphNodeGetDependencies_params_st
{
    uint64_t nodeID;
    uint64_t dependenciesID[MAX_NODE_DEPENDENCIES];
    uint32_t numDependencies;
} rppGraphNodeGetDependencies_params;

typedef struct rppGraphNodeGetDependentNodes_params_st
{
    uint64_t nodeID;
    uint64_t dependNodeID[MAX_NODE_DEPENDENCIES];
    uint32_t numDependentNodes;
} rppGraphNodeGetDependentNodes_params;

typedef struct rppGraphAddDependencies_params_st
{
    uint64_t graphID;
    shm_info_t from_shm_info;
    uint32_t from_shm_size;
    shm_info_t to_shm_info;
    uint32_t to_shm_size;
    size_t numDependencies;
} rppGraphAddDependencies_params;

typedef struct rppGraphRemoveDependencies_params_st
{
    uint64_t graphID;
    shm_info_t from_shm_info;
    uint32_t from_shm_size;
    shm_info_t to_shm_info;
    uint32_t to_shm_size;
    size_t numDependencies;
} rppGraphRemoveDependencies_params;

typedef struct rppGraphDestroyNode_params_st
{
    uint64_t nodeID;
} rppGraphDestroyNode_params;

typedef struct rppImportExternalMemory_params_st
{
    uint64_t extID;
    RPPexternalMemoryHandleType type;
    uint64_t addr;
    uint64_t size;
    unsigned int flags; /* reserved for future */
} rppImportExternalMemory_params;

typedef struct rppGetExternalMemoryObjectByType_params_st
{
    uint64_t extID;
    RPPexternalMemoryHandleType type;
} rppGetExternalMemoryObjectByType_params;

typedef struct rppExternalMemoryGetMappedBuffer_params_st
{
    uint64_t extID;
    uint64_t ptr;
    uint64_t offs;
    uint64_t size;
    unsigned int flags; /* reserved for future */
} rppExternalMemoryGetMappedBuffer_params;

typedef struct rppDestroyExternalMemory_params_st
{
    uint64_t extID;
} rppDestroyExternalMemory_params;

typedef struct rppExternalMemoryGetHandleDesc_params_st
{
    uint64_t extID;
    RPPexternalMemoryHandleType type;
    uint64_t addr;
    uint64_t size;
    unsigned int flags; /* reserved for future */
} rppExternalMemoryGetHandleDesc_params;

typedef struct rppDFSSetFreqAsync_params_st
{
    uint64_t streamID;
    uint32_t freq_level;
} rppDFSSetFreqAsync_params;

typedef struct rppMpuMsgAsync_params_st
{
    uint64_t streamID;
    RPP_MPU_MSG_META meta;
} rppMpuMsgAsync_params;

typedef struct rppDeviceSetPwrMode_params_st
{
    uint64_t devID;
    uint32_t pwrmode;
} rppDeviceSetPwrMode_params;

typedef struct rppDeviceGetPwrMode_params_st
{
    uint64_t devID;
    uint32_t pwrmode;
} rppDeviceGetPwrMode_params;

typedef struct rppDeviceSetWorkMode_params_st
{
    uint64_t devID;
    uint32_t workmode;
} rppDeviceSetWorkMode_params;

typedef struct rppDeviceGetWorkMode_params_st
{
    uint64_t devID;
    uint32_t workmode;
} rppDeviceGetWorkMode_params;

typedef struct rppGraphResourceAlloc_params_st
{
    uint64_t ptr;
    size_t bytesize;
    RPPgraphResource_type_e type;
} rppGraphResourceAlloc_params;

typedef struct rppGraphResourceFree_params_st
{
    uint64_t ptr;
    RPPgraphResource_type_e type;
} rppGraphResourceFree_params;

typedef struct rppGraphInstantiateWithParams_params_st
{
    uint64_t graphID;
    uint64_t graphExecID;
    RPP_GRAPH_INSTANTIATE_PARAMS instantiateParams;
} rppGraphInstantiateWithParams_params;

typedef struct rppGraphExecGetParams_params_st
{
    uint64_t graphExecID;
    RPP_GRAPH_INSTANTIATE_PARAMS instantiateParams;
} rppGraphExecGetParams_params;

typedef struct rppGraphExecUpdate_params_st
{
    uint64_t graphExecID;
    uint64_t graphID;
    uint64_t errorFromNodeID;
    uint64_t errorNodeID;
    RPP_GRAPH_EXEC_UPDATE_RESULT result;
} rppGraphExecUpdate_params;

typedef struct rppGraphExecUpdateChildGraphExec_params_st
{
    uint64_t mainGraphExecID;
    uint64_t targetChildNodeID;
    uint64_t newChildGraphExecID;
    uint32_t flags;
} rppGraphExecUpdateChildGraphExec_params;

typedef struct rppGraphExecFinalize_params_st
{
    uint64_t graphExecID;
    size_t structSize;
    uint32_t version;
    uint32_t flags;
    uint64_t reserved[8];
} rppGraphExecFinalize_params;

typedef struct rppGraphExecDynamicSelectGraphNodeSetParams_params_st
{
    uint64_t mainGraphExecID;
    uint64_t targetDynamicSelectGraphNodeID;
    uint64_t indexAddr;
    uint32_t caseCount;
    uint32_t indexValue[RPP_DYNAMIC_SELECT_GRAPH_NODE_UPDATE_MAX_CASES];
    uint64_t childGraphID[RPP_DYNAMIC_SELECT_GRAPH_NODE_UPDATE_MAX_CASES];
    uint64_t childGraphExecID[RPP_DYNAMIC_SELECT_GRAPH_NODE_UPDATE_MAX_CASES];
    uint32_t flags;
} rppGraphExecDynamicSelectGraphNodeSetParams_params;

#endif
