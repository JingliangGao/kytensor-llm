#ifndef __MSG_DEF__
#define __MSG_DEF__

/*
 *
 * bit31 ~ bit22: status, 10 bits, command status, get from rpp server
 * bit21 ~ bit08: size, 14 bits, size of arguments
 * bit07 ~ bit00: number, 8 bits, command id
 *
 */
#define _MSG_STATUSBITS    10
#define _MSG_SIZEBITS    14
#define _MSG_NRBITS    8

#define _MSG_NRMASK    ((1 << _MSG_NRBITS)-1)
#define _MSG_SIZEMASK    ((1 << _MSG_SIZEBITS)-1)
#define _MSG_STATUSMASK    ((1 << _MSG_STATUSBITS)-1)

#define _MSG_NRSHIFT    0
#define _MSG_SIZESHIFT    (_MSG_NRSHIFT+_MSG_NRBITS)
#define _MSG_STATUSSHIFT (_MSG_SIZESHIFT+_MSG_SIZEBITS)

/*
 * Used to create numbers.
 *
 */
#define _MSG(nr,type,status) \
     (((nr) << _MSG_NRSHIFT) | \
     ((sizeof(type)) << _MSG_SIZESHIFT) | \
     ((status) << _MSG_STATUSSHIFT))

/* used to decode numbers.. */
#define _MSG_NR(cmd)            (((cmd) >> _MSG_NRSHIFT) & _MSG_NRMASK)
#define _MSG_SIZE(cmd)        (((cmd) >> _MSG_SIZESHIFT) & _MSG_SIZEMASK)
#define _MSG_STATUS(cmd)        (((cmd) >> _MSG_STATUSSHIFT) & _MSG_STATUSMASK)

/* used to change status.. */
#define _MSG_SET_STATUS(cmd, status) ((cmd) | ((status) << _MSG_STATUSSHIFT))

/* ...... */
#define MSGNR_MASK        (_MSG_NRMASK << _MSG_NRSHIFT)
#define MSGNR_SHIFT        (_MSG_NRSHIFT)
#define MSGSIZE_MASK    (_MSG_SIZEMASK << _MSG_SIZESHIFT)
#define MSGSIZE_SHIFT    (_MSG_SIZESHIFT)
#define MSGSTATUS_MASK    (_MSG_STATUSMASK << _MSG_STATUSSHIFT)
#define MSGSTATUS_SHIFT    (_MSG_STATUSSHIFT)

#endif /* __MSG_DEF__ */
