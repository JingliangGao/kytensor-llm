#if !defined(_PTI_EVENTS_H_)
#define _PTI_EVENTS_H_

#include <pti_result.h>

#ifndef PTIAPI
#ifdef _WIN32
#define PTIAPI __stdcall
#else
#define PTIAPI
#endif
#endif

#if defined(__cplusplus)
extern "C" {
#endif

/**
 * \defgroup PTI_EVENT_API PTI Event API
 * Functions, types, and enums that implement the PTI Event API.
 * @{
 */

/**
 * \brief ID for an event.
 *
 * An event represents a countable activity, action, or occurrence on
 * the device.
 */
typedef uint32_t pti_EventID;

/**
 * \brief ID for an event domain.
 *
 * ID for an event domain. An event domain represents a group of
 * related events. A device may have multiple instances of a domain,
 * indicating that the device can simultaneously record multiple
 * instances of each event within that domain.
 */
typedef uint32_t pti_EventDomainID;

/**
 * \brief A group of events.
 *
 * An event group is a collection of events that are managed
 * together. All events in an event group must belong to the same
 * domain.
 */
typedef void *pti_EventGroup;

/**
 * \brief Device class.
 *
 * Enumeration of device classes for device attribute
 * PTI_DEVICE_ATTR_DEVICE_CLASS.
 */
typedef enum {
  PTI_DEVICE_ATTR_DEVICE_CLASS_TESLA              = 0,
  PTI_DEVICE_ATTR_DEVICE_CLASS_QUADRO             = 1,
  PTI_DEVICE_ATTR_DEVICE_CLASS_GEFORCE            = 2,
  PTI_DEVICE_ATTR_DEVICE_CLASS_TEGRA              = 3,
} pti_DeviceAttributeDeviceClass;

/**
 * \brief Device attributes.
 *
 * PTI device attributes. These attributes can be read using \ref
 * cuptiDeviceGetAttribute.
 */
typedef enum {
  /**
   * Number of event IDs for a device. Value is a uint32_t.
   */
  PTI_DEVICE_ATTR_MAX_EVENT_ID                            = 1,
  /**
   * Number of event domain IDs for a device. Value is a uint32_t.
   */
  PTI_DEVICE_ATTR_MAX_EVENT_DOMAIN_ID                     = 2,
  /**
   * Get global memory bandwidth in Kbytes/sec. Value is a uint64_t.
   */
  PTI_DEVICE_ATTR_GLOBAL_MEMORY_BANDWIDTH                 = 3,
  /**
   * Get theoretical maximum number of instructions per cycle. Value
   * is a uint32_t.
   */
  PTI_DEVICE_ATTR_INSTRUCTION_PER_CYCLE                   = 4,
  /**
   * Get theoretical maximum number of single precision instructions
   * that can be executed per second. Value is a uint64_t.
   */
  PTI_DEVICE_ATTR_INSTRUCTION_THROUGHPUT_SINGLE_PRECISION = 5,
  /**
   * Get number of frame buffers for device.  Value is a uint64_t.
   */
  PTI_DEVICE_ATTR_MAX_FRAME_BUFFERS                       = 6,
  /**
   * Get PCIE link rate in Mega bits/sec for device. Return 0 if bus-type
   * is non-PCIE. Value is a uint64_t.
   */
  PTI_DEVICE_ATTR_PCIE_LINK_RATE                          = 7,
  /**
   * Get PCIE link width for device. Return 0 if bus-type
   * is non-PCIE. Value is a uint64_t.
   */
  PTI_DEVICE_ATTR_PCIE_LINK_WIDTH                         = 8,
  /**
   * Get PCIE generation for device. Return 0 if bus-type
   * is non-PCIE. Value is a uint64_t.
   */
  PTI_DEVICE_ATTR_PCIE_GEN                                = 9,
  /**
   * Get the class for the device. Value is a
   * pti_DeviceAttributeDeviceClass.
   */
  PTI_DEVICE_ATTR_DEVICE_CLASS                            = 10,
  /**
   * Get the peak single precision flop per cycle. Value is a uint64_t.
   */
  PTI_DEVICE_ATTR_FLOP_SP_PER_CYCLE                       = 11,
  /**
   * Get the peak double precision flop per cycle. Value is a uint64_t.
   */
  PTI_DEVICE_ATTR_FLOP_DP_PER_CYCLE                       = 12,
  /**
   * Get number of L2 units. Value is a uint64_t.
   */
  PTI_DEVICE_ATTR_MAX_L2_UNITS                           = 13,
  /**
   * Get the maximum shared memory for the CU_FUNC_CACHE_PREFER_SHARED
   * preference. Value is a uint64_t.
   */
  PTI_DEVICE_ATTR_MAX_SHARED_MEMORY_CACHE_CONFIG_PREFER_SHARED = 14,
  /**
   * Get the maximum shared memory for the CU_FUNC_CACHE_PREFER_L1
   * preference. Value is a uint64_t.
   */
  PTI_DEVICE_ATTR_MAX_SHARED_MEMORY_CACHE_CONFIG_PREFER_L1 = 15,
  /**
   * Get the maximum shared memory for the CU_FUNC_CACHE_PREFER_EQUAL
   * preference. Value is a uint64_t.
   */
  PTI_DEVICE_ATTR_MAX_SHARED_MEMORY_CACHE_CONFIG_PREFER_EQUAL = 16,
  /**
   * Get the peak half precision flop per cycle. Value is a uint64_t.
   */
  PTI_DEVICE_ATTR_FLOP_HP_PER_CYCLE                       = 17,
  /**
   * Check if Nvlink is connected to device. Returns 1, if at least one
   * Nvlink is connected to the device, returns 0 otherwise.
   * Value is a uint32_t.
   */
  PTI_DEVICE_ATTR_NVLINK_PRESENT                          = 18,
    /**
   * Check if Nvlink is present between GPU and CPU. Returns Bandwidth,
   * in Bytes/sec, if Nvlink is present, returns 0 otherwise.
   * Value is a uint64_t.
   */
  PTI_DEVICE_ATTR_GPU_CPU_NVLINK_BW                       = 19,
  PTI_DEVICE_ATTR_FORCE_INT                               = 0x7fffffff,
} pti_DeviceAttribute;

/**
 * \brief Event domain attributes.
 *
 * Event domain attributes. Except where noted, all the attributes can
 * be read using either \ref cuptiDeviceGetEventDomainAttribute or
 * \ref cuptiEventDomainGetAttribute.
 */
typedef enum {
  /**
   * Event domain name. Value is a null terminated const c-string.
   */
  PTI_EVENT_DOMAIN_ATTR_NAME                 = 0,
  /**
   * Number of instances of the domain for which event counts will be
   * collected.  The domain may have additional instances that cannot
   * be profiled (see PTI_EVENT_DOMAIN_ATTR_TOTAL_INSTANCE_COUNT).
   * Can be read only with \ref
   * cuptiDeviceGetEventDomainAttribute. Value is a uint32_t.
   */
  PTI_EVENT_DOMAIN_ATTR_INSTANCE_COUNT       = 1,
  /**
   * Total number of instances of the domain, including instances that
   * cannot be profiled.  Use PTI_EVENT_DOMAIN_ATTR_INSTANCE_COUNT
   * to get the number of instances that can be profiled. Can be read
   * only with \ref cuptiDeviceGetEventDomainAttribute. Value is a
   * uint32_t.
   */
  PTI_EVENT_DOMAIN_ATTR_TOTAL_INSTANCE_COUNT = 3,
  /**
   * Collection method used for events contained in the event domain.
   * Value is a \ref pti_EventCollectionMethod.
   */
  PTI_EVENT_DOMAIN_ATTR_COLLECTION_METHOD    = 4,

  PTI_EVENT_DOMAIN_ATTR_FORCE_INT      = 0x7fffffff,
} pti_EventDomainAttribute;

/**
 * \brief The collection method used for an event.
 *
 * The collection method indicates how an event is collected.
 */
typedef enum {
  /**
   * Event is collected using a hardware global performance monitor.
   */
  PTI_EVENT_COLLECTION_METHOD_PM                  = 0,
  /**
   * Event is collected using a hardware SM performance monitor.
   */
  PTI_EVENT_COLLECTION_METHOD_SM                  = 1,
  /**
   * Event is collected using software instrumentation.
   */
  PTI_EVENT_COLLECTION_METHOD_INSTRUMENTED        = 2,
  /**
   * Event is collected using NvLink throughput counter method.
   */
  PTI_EVENT_COLLECTION_METHOD_NVLINK_TC           = 3,
  PTI_EVENT_COLLECTION_METHOD_FORCE_INT           = 0x7fffffff
} pti_EventCollectionMethod;

/**
 * \brief Event group attributes.
 *
 * Event group attributes. These attributes can be read using \ref
 * cuptiEventGroupGetAttribute. Attributes marked [rw] can also be
 * written using \ref cuptiEventGroupSetAttribute.
 */
typedef enum {
  /**
   * The domain to which the event group is bound. This attribute is
   * set when the first event is added to the group.  Value is a
   * pti_EventDomainID.
   */
  PTI_EVENT_GROUP_ATTR_EVENT_DOMAIN_ID              = 0,
  /**
   * [rw] Profile all the instances of the domain for this
   * eventgroup. This feature can be used to get load balancing
   * across all instances of a domain. Value is an integer.
   */
  PTI_EVENT_GROUP_ATTR_PROFILE_ALL_DOMAIN_INSTANCES = 1,
  /**
   * [rw] Reserved for user data.
   */
  PTI_EVENT_GROUP_ATTR_USER_DATA                    = 2,
  /**
   * Number of events in the group. Value is a uint32_t.
   */
  PTI_EVENT_GROUP_ATTR_NUM_EVENTS                   = 3,
  /**
   * Enumerates events in the group. Value is a pointer to buffer of
   * size sizeof(pti_EventID) * num_of_events in the eventgroup.
   * num_of_events can be queried using
   * PTI_EVENT_GROUP_ATTR_NUM_EVENTS.
   */
  PTI_EVENT_GROUP_ATTR_EVENTS                       = 4,
  /**
   * Number of instances of the domain bound to this event group that
   * will be counted.  Value is a uint32_t.
   */
  PTI_EVENT_GROUP_ATTR_INSTANCE_COUNT               = 5,
  PTI_EVENT_GROUP_ATTR_FORCE_INT                    = 0x7fffffff,
} pti_EventGroupAttribute;

/**
 * \brief Event attributes.
 *
 * Event attributes. These attributes can be read using \ref
 * cuptiEventGetAttribute.
 */
typedef enum {
  /**
   * Event name. Value is a null terminated const c-string.
   */
  PTI_EVENT_ATTR_NAME              = 0,
  /**
   * Short description of event. Value is a null terminated const
   * c-string.
   */
  PTI_EVENT_ATTR_SHORT_DESCRIPTION = 1,
  /**
   * Long description of event. Value is a null terminated const
   * c-string.
   */
  PTI_EVENT_ATTR_LONG_DESCRIPTION  = 2,
  /**
   * Category of event. Value is pti_EventCategory.
   */
  PTI_EVENT_ATTR_CATEGORY          = 3,
  PTI_EVENT_ATTR_FORCE_INT         = 0x7fffffff,
} pti_EventAttribute;

/**
 * \brief Event collection modes.
 *
 * The event collection mode determines the period over which the
 * events within the enabled event groups will be collected.
 */
typedef enum {
  /**
   * Events are collected for the entire duration between the
   * cuptiEventGroupEnable and cuptiEventGroupDisable calls.
   * For devices with compute capability less than 2.0, event
   * values are reset when a kernel is launched. For all other
   * devices event values are only reset when the events are read.
   * For CUDA toolkit v6.0 and older this was the default mode.
   * From CUDA toolkit v6.5 this mode is supported on Tesla devices
   * only.
   */
  PTI_EVENT_COLLECTION_MODE_CONTINUOUS          = 0,
  /**
   * Events are collected only for the durations of kernel executions
   * that occur between the cuptiEventGroupEnable and
   * cuptiEventGroupDisable calls. Event collection begins when a
   * kernel execution begins, and stops when kernel execution
   * completes. Event values are reset to zero when each kernel
   * execution begins. If multiple kernel executions occur between the
   * cuptiEventGroupEnable and cuptiEventGroupDisable calls then the
   * event values must be read after each kernel launch if those
   * events need to be associated with the specific kernel launch.
   * This is the default mode from CUDA toolkit v6.5, and it is the
   * only supported mode for non-Tesla (Quadro, GeForce etc.) devices.
   */
  PTI_EVENT_COLLECTION_MODE_KERNEL              = 1,
  PTI_EVENT_COLLECTION_MODE_FORCE_INT           = 0x7fffffff
} pti_EventCollectionMode;

/**
 * \brief An event category.
 *
 * Each event is assigned to a category that represents the general
 * type of the event. A event's category is accessed using \ref
 * cuptiEventGetAttribute and the PTI_EVENT_ATTR_CATEGORY attribute.
 */
typedef enum {
  /**
   * An instruction related event.
   */
  PTI_EVENT_CATEGORY_INSTRUCTION     = 0,
  /**
   * A memory related event.
   */
  PTI_EVENT_CATEGORY_MEMORY          = 1,
  /**
   * A cache related event.
   */
  PTI_EVENT_CATEGORY_CACHE           = 2,
  /**
   * A profile-trigger event.
   */
  PTI_EVENT_CATEGORY_PROFILE_TRIGGER = 3,
  PTI_EVENT_CATEGORY_FORCE_INT       = 0x7fffffff
} pti_EventCategory;

/**
 * \brief The overflow value for a PTI event.
 *
 * The PTI event value that indicates an overflow.
 */
#define PTI_EVENT_OVERFLOW ((uint64_t)0xFFFFFFFFFFFFFFFFULL)

/**
 * \brief The value that indicates the event value is invalid
 */
#define PTI_EVENT_INVALID ((uint64_t)0xFFFFFFFFFFFFFFFEULL)

/**
 * \brief Flags for cuptiEventGroupReadEvent an
 * cuptiEventGroupReadAllEvents.
 *
 * Flags for \ref cuptiEventGroupReadEvent an \ref
 * cuptiEventGroupReadAllEvents.
 */
typedef enum {
  /**
   * No flags.
   */
  PTI_EVENT_READ_FLAG_NONE          = 0,
  PTI_EVENT_READ_FLAG_FORCE_INT     = 0x7fffffff,
} pti_ReadEventFlags;


/**
 * \brief A set of event groups.
 *
 * A set of event groups. When returned by \ref
 * cuptiEventGroupSetsCreate and \ref cuptiMetricCreateEventGroupSets
 * a set indicates that event groups that can be enabled at the same
 * time (i.e. all the events in the set can be collected
 * simultaneously).
 */
typedef struct {
  /**
   * The number of event groups in the set.
   */
  uint32_t numEventGroups;
  /**
   * An array of \p numEventGroups event groups.
   */
  pti_EventGroup *eventGroups;
} pti_EventGroupSet;

/**
 * \brief A set of event group sets.
 *
 * A set of event group sets. When returned by \ref
 * cuptiEventGroupSetsCreate and \ref cuptiMetricCreateEventGroupSets
 * a pti_EventGroupSets indicates the number of passes required to
 * collect all the events, and the event groups that should be
 * collected during each pass.
 */
typedef struct {
  /**
   * Number of event group sets.
   */
  uint32_t numSets;
  /**
   * An array of \p numSets event group sets.
   */
  pti_EventGroupSet *sets;
} pti_EventGroupSets;

#if 0
/**
 * \brief Set the event collection mode.
 *
 * Set the event collection mode for a \p context.  The \p mode
 * controls the event collection behavior of all events in event
 * groups created in the \p context. This API is invalid in kernel
 * replay mode.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param context The context
 * \param mode The event collection mode
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_CONTEXT
 * \retval PTI_ERROR_INVALID_OPERATION if called when replay mode is enabled
 * \retval PTI_ERROR_NOT_SUPPORTED if mode is not supported on the device
 */

PTIResult PTIAPI ptiSetEventCollectionMode(RPPcontext context,
                                                 pti_EventCollectionMode mode);

/**
 * \brief Read a device attribute.
 *
 * Read a device attribute and return it in \p *value.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param device The CUDA device
 * \param attrib The attribute to read
 * \param valueSize Size of buffer pointed by the value, and
 * returns the number of bytes written to \p value
 * \param value Returns the value of the attribute
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_DEVICE
 * \retval PTI_ERROR_INVALID_PARAMETER if \p valueSize or \p value
 * is NULL, or if \p attrib is not a device attribute
 * \retval PTI_ERROR_PARAMETER_SIZE_NOT_SUFFICIENT For non-c-string
 * attribute values, indicates that the \p value buffer is too small
 * to hold the attribute value.
 */
PTIResult PTIAPI ptiDeviceGetAttribute(RPPdevice device,
                                             pti_DeviceAttribute attrib,
                                             size_t *valueSize,
                                             void *value);

/**
 * \brief Read a device timestamp.
 *
 * Returns the device timestamp in \p *timestamp. The timestamp is
 * reported in nanoseconds and indicates the time since the device was
 * last reset.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param context A context on the device from which to get the timestamp
 * \param timestamp Returns the device timestamp
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_CONTEXT
 * \retval PTI_ERROR_INVALID_PARAMETER is \p timestamp is NULL
 */
PTIResult PTIAPI ptiDeviceGetTimestamp(RPPcontext context,
                                             uint64_t *timestamp);

/**
 * \brief Get the number of domains for a device.
 *
 * Returns the number of domains in \p numDomains for a device.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param device The CUDA device
 * \param numDomains Returns the number of domains
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_DEVICE
 * \retval PTI_ERROR_INVALID_PARAMETER if \p numDomains is NULL
 */
PTIResult PTIAPI ptiDeviceGetNumEventDomains(RPPdevice device,
                                                   uint32_t *numDomains);

/**
 * \brief Get the event domains for a device.
 *
 * Returns the event domains IDs in \p domainArray for a device.  The
 * size of the \p domainArray buffer is given by \p
 * *arraySizeBytes. The size of the \p domainArray buffer must be at
 * least \p numdomains * sizeof(pti_EventDomainID) or else all
 * domains will not be returned. The value returned in \p
 * *arraySizeBytes contains the number of bytes returned in \p
 * domainArray.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param device The CUDA device
 * \param arraySizeBytes The size of \p domainArray in bytes, and
 * returns the number of bytes written to \p domainArray
 * \param domainArray Returns the IDs of the event domains for the device
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_DEVICE
 * \retval PTI_ERROR_INVALID_PARAMETER if \p arraySizeBytes or
 * \p domainArray are NULL
 */
PTIResult PTIAPI ptiDeviceEnumEventDomains(RPPdevice device,
                                                 size_t *arraySizeBytes,
                                                 pti_EventDomainID *domainArray);

/**
 * \brief Read an event domain attribute.
 *
 * Returns an event domain attribute in \p *value. The size of the \p
 * value buffer is given by \p *valueSize. The value returned in \p
 * *valueSize contains the number of bytes returned in \p value.
 *
 * If the attribute value is a c-string that is longer than \p
 * *valueSize, then only the first \p *valueSize characters will be
 * returned and there will be no terminating null byte.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param device The CUDA device
 * \param eventDomain ID of the event domain
 * \param attrib The event domain attribute to read
 * \param valueSize The size of the \p value buffer in bytes, and
 * returns the number of bytes written to \p value
 * \param value Returns the attribute's value
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_DEVICE
 * \retval PTI_ERROR_INVALID_EVENT_DOMAIN_ID
 * \retval PTI_ERROR_INVALID_PARAMETER if \p valueSize or \p value
 * is NULL, or if \p attrib is not an event domain attribute
 * \retval PTI_ERROR_PARAMETER_SIZE_NOT_SUFFICIENT For non-c-string
 * attribute values, indicates that the \p value buffer is too small
 * to hold the attribute value.
 */
PTIResult PTIAPI ptiDeviceGetEventDomainAttribute(RPPdevice device,
                                                        pti_EventDomainID eventDomain,
                                                        pti_EventDomainAttribute attrib,
                                                        size_t *valueSize,
                                                        void *value);

/**
 * \brief Get the number of event domains available on any device.
 *
 * Returns the total number of event domains available on any
 * CUDA-capable device.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param numDomains Returns the number of domains
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_INVALID_PARAMETER if \p numDomains is NULL
 */
PTIResult PTIAPI ptiGetNumEventDomains(uint32_t *numDomains);

/**
 * \brief Get the event domains available on any device.
 *
 * Returns all the event domains available on any CUDA-capable device.
 * Event domain IDs are returned in \p domainArray. The size of the \p
 * domainArray buffer is given by \p *arraySizeBytes. The size of the
 * \p domainArray buffer must be at least \p numDomains *
 * sizeof(pti_EventDomainID) or all domains will not be
 * returned. The value returned in \p *arraySizeBytes contains the
 * number of bytes returned in \p domainArray.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param arraySizeBytes The size of \p domainArray in bytes, and
 * returns the number of bytes written to \p domainArray
 * \param domainArray Returns all the event domains
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_INVALID_PARAMETER if \p arraySizeBytes or
 * \p domainArray are NULL
 */
PTIResult PTIAPI ptiEnumEventDomains(size_t *arraySizeBytes,
                                           pti_EventDomainID *domainArray);

/**
 * \brief Read an event domain attribute.
 *
 * Returns an event domain attribute in \p *value. The size of the \p
 * value buffer is given by \p *valueSize. The value returned in \p
 * *valueSize contains the number of bytes returned in \p value.
 *
 * If the attribute value is a c-string that is longer than \p
 * *valueSize, then only the first \p *valueSize characters will be
 * returned and there will be no terminating null byte.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param eventDomain ID of the event domain
 * \param attrib The event domain attribute to read
 * \param valueSize The size of the \p value buffer in bytes, and
 * returns the number of bytes written to \p value
 * \param value Returns the attribute's value
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_EVENT_DOMAIN_ID
 * \retval PTI_ERROR_INVALID_PARAMETER if \p valueSize or \p value
 * is NULL, or if \p attrib is not an event domain attribute
 * \retval PTI_ERROR_PARAMETER_SIZE_NOT_SUFFICIENT For non-c-string
 * attribute values, indicates that the \p value buffer is too small
 * to hold the attribute value.
 */
PTIResult PTIAPI ptiEventDomainGetAttribute(pti_EventDomainID eventDomain,
                                                  pti_EventDomainAttribute attrib,
                                                  size_t *valueSize,
                                                  void *value);

/**
 * \brief Get number of events in a domain.
 *
 * Returns the number of events in \p numEvents for a domain.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param eventDomain ID of the event domain
 * \param numEvents Returns the number of events in the domain
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_EVENT_DOMAIN_ID
 * \retval PTI_ERROR_INVALID_PARAMETER if \p numEvents is NULL
 */
PTIResult PTIAPI ptiEventDomainGetNumEvents(pti_EventDomainID eventDomain,
                                                  uint32_t *numEvents);

/**
 * \brief Get the events in a domain.
 *
 * Returns the event IDs in \p eventArray for a domain.  The size of
 * the \p eventArray buffer is given by \p *arraySizeBytes. The size
 * of the \p eventArray buffer must be at least \p numdomainevents *
 * sizeof(pti_EventID) or else all events will not be returned. The
 * value returned in \p *arraySizeBytes contains the number of bytes
 * returned in \p eventArray.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param eventDomain ID of the event domain
 * \param arraySizeBytes The size of \p eventArray in bytes, and
 * returns the number of bytes written to \p eventArray
 * \param eventArray Returns the IDs of the events in the domain
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_EVENT_DOMAIN_ID
 * \retval PTI_ERROR_INVALID_PARAMETER if \p arraySizeBytes or \p
 * eventArray are NULL
 */
PTIResult PTIAPI ptiEventDomainEnumEvents(pti_EventDomainID eventDomain,
                                                size_t *arraySizeBytes,
                                                pti_EventID *eventArray);

/**
 * \brief Get an event attribute.
 *
 * Returns an event attribute in \p *value. The size of the \p
 * value buffer is given by \p *valueSize. The value returned in \p
 * *valueSize contains the number of bytes returned in \p value.
 *
 * If the attribute value is a c-string that is longer than \p
 * *valueSize, then only the first \p *valueSize characters will be
 * returned and there will be no terminating null byte.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param event ID of the event
 * \param attrib The event attribute to read
 * \param valueSize The size of the \p value buffer in bytes, and
 * returns the number of bytes written to \p value
 * \param value Returns the attribute's value
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_EVENT_ID
 * \retval PTI_ERROR_INVALID_PARAMETER if \p valueSize or \p value
 * is NULL, or if \p attrib is not an event attribute
 * \retval PTI_ERROR_PARAMETER_SIZE_NOT_SUFFICIENT For non-c-string
 * attribute values, indicates that the \p value buffer is too small
 * to hold the attribute value.
 */
PTIResult PTIAPI ptiEventGetAttribute(pti_EventID event,
                                            pti_EventAttribute attrib,
                                            size_t *valueSize,
                                            void *value);

/**
 * \brief Find an event by name.
 *
 * Find an event by name and return the event ID in \p *event.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param device The CUDA device
 * \param eventName The name of the event to find
 * \param event Returns the ID of the found event or undefined if
 * unable to find the event
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_DEVICE
 * \retval PTI_ERROR_INVALID_EVENT_NAME if unable to find an event
 * with name \p eventName. In this case \p *event is undefined
 * \retval PTI_ERROR_INVALID_PARAMETER if \p eventName or \p event are NULL
 */
PTIResult PTIAPI ptiEventGetIdFromName(RPPdevice device,
                                             const char *eventName,
                                             pti_EventID *event);

/**
 * \brief Create a new event group for a context.
 *
 * Creates a new event group for \p context and returns the new group
 * in \p *eventGroup.
 * \note \p flags are reserved for future use and should be set to zero.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param context The context for the event group
 * \param eventGroup Returns the new event group
 * \param flags Reserved - must be zero
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_CONTEXT
 * \retval PTI_ERROR_OUT_OF_MEMORY
 * \retval PTI_ERROR_INVALID_PARAMETER if \p eventGroup is NULL
 */
PTIResult PTIAPI ptiEventGroupCreate(RPPcontext context,
                                           pti_EventGroup *eventGroup,
                                           uint32_t flags);

/**
 * \brief Destroy an event group.
 *
 * Destroy an \p eventGroup and free its resources. An event group
 * cannot be destroyed if it is enabled.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param eventGroup The event group to destroy
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_OPERATION if the event group is enabled
 * \retval PTI_ERROR_INVALID_PARAMETER if eventGroup is NULL
 */
PTIResult PTIAPI ptiEventGroupDestroy(pti_EventGroup eventGroup);

/**
 * \brief Read an event group attribute.
 *
 * Read an event group attribute and return it in \p *value.
 * \note \b Thread-safety: this function is thread safe but client
 * must guard against simultaneous destruction or modification of \p
 * eventGroup (for example, client must guard against simultaneous
 * calls to \ref cuptiEventGroupDestroy, \ref cuptiEventGroupAddEvent,
 * etc.), and must guard against simultaneous destruction of the
 * context in which \p eventGroup was created (for example, client
 * must guard against simultaneous calls to cudaDeviceReset,
 * cuCtxDestroy, etc.).
 *
 * \param eventGroup The event group
 * \param attrib The attribute to read
 * \param valueSize Size of buffer pointed by the value, and
 * returns the number of bytes written to \p value
 * \param value Returns the value of the attribute
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_PARAMETER if \p valueSize or \p value
 * is NULL, or if \p attrib is not an eventgroup attribute
 * \retval PTI_ERROR_PARAMETER_SIZE_NOT_SUFFICIENT For non-c-string
 * attribute values, indicates that the \p value buffer is too small
 * to hold the attribute value.
 */
PTIResult PTIAPI ptiEventGroupGetAttribute(pti_EventGroup eventGroup,
                                                 pti_EventGroupAttribute attrib,
                                                 size_t *valueSize,
                                                 void *value);

/**
 * \brief Write an event group attribute.
 *
 * Write an event group attribute.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param eventGroup The event group
 * \param attrib The attribute to write
 * \param valueSize The size, in bytes, of the value
 * \param value The attribute value to write
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_PARAMETER if \p valueSize or \p value
 * is NULL, or if \p attrib is not an event group attribute, or if
 * \p attrib is not a writable attribute
 * \retval PTI_ERROR_PARAMETER_SIZE_NOT_SUFFICIENT Indicates that
 * the \p value buffer is too small to hold the attribute value.
 */
PTIResult PTIAPI ptiEventGroupSetAttribute(pti_EventGroup eventGroup,
                                                 pti_EventGroupAttribute attrib,
                                                 size_t valueSize,
                                                 void *value);

/**
 * \brief Add an event to an event group.
 *
 * Add an event to an event group. The event add can fail for a number of reasons:
 * \li The event group is enabled
 * \li The event does not belong to the same event domain as the
 * events that are already in the event group
 * \li Device limitations on the events that can belong to the same group
 * \li The event group is full
 *
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param eventGroup The event group
 * \param event The event to add to the group
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_EVENT_ID
 * \retval PTI_ERROR_OUT_OF_MEMORY
 * \retval PTI_ERROR_INVALID_OPERATION if \p eventGroup is enabled
 * \retval PTI_ERROR_NOT_COMPATIBLE if \p event belongs to a
 * different event domain than the events already in \p eventGroup, or
 * if a device limitation prevents \p event from being collected at
 * the same time as the events already in \p eventGroup
 * \retval PTI_ERROR_MAX_LIMIT_REACHED if \p eventGroup is full
 * \retval PTI_ERROR_INVALID_PARAMETER if \p eventGroup is NULL
 */
PTIResult PTIAPI ptiEventGroupAddEvent(pti_EventGroup eventGroup,
                                             pti_EventID event);

/**
 * \brief Remove an event from an event group.
 *
 * Remove \p event from the an event group. The event cannot be
 * removed if the event group is enabled.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param eventGroup The event group
 * \param event The event to remove from the group
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_EVENT_ID
 * \retval PTI_ERROR_INVALID_OPERATION if \p eventGroup is enabled
 * \retval PTI_ERROR_INVALID_PARAMETER if \p eventGroup is NULL
 */
PTIResult PTIAPI ptiEventGroupRemoveEvent(pti_EventGroup eventGroup,
                                                pti_EventID event);

/**
 * \brief Remove all events from an event group.
 *
 * Remove all events from an event group. Events cannot be removed if
 * the event group is enabled.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param eventGroup The event group
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_OPERATION if \p eventGroup is enabled
 * \retval PTI_ERROR_INVALID_PARAMETER if \p eventGroup is NULL
 */
PTIResult PTIAPI ptiEventGroupRemoveAllEvents(pti_EventGroup eventGroup);

/**
 * \brief Zero all the event counts in an event group.
 *
 * Zero all the event counts in an event group.
 * \note \b Thread-safety: this function is thread safe but client
 * must guard against simultaneous destruction or modification of \p
 * eventGroup (for example, client must guard against simultaneous
 * calls to \ref cuptiEventGroupDestroy, \ref cuptiEventGroupAddEvent,
 * etc.), and must guard against simultaneous destruction of the
 * context in which \p eventGroup was created (for example, client
 * must guard against simultaneous calls to cudaDeviceReset,
 * cuCtxDestroy, etc.).
 *
 * \param eventGroup The event group
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_HARDWARE
 * \retval PTI_ERROR_INVALID_PARAMETER if \p eventGroup is NULL
 */
PTIResult PTIAPI ptiEventGroupResetAllEvents(pti_EventGroup eventGroup);

/**
 * \brief Enable an event group.
 *
 * Enable an event group. Enabling an event group zeros the value of
 * all the events in the group and then starts collection of those
 * events.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param eventGroup The event group
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_HARDWARE
 * \retval PTI_ERROR_NOT_READY if \p eventGroup does not contain any events
 * \retval PTI_ERROR_NOT_COMPATIBLE if \p eventGroup cannot be
 * enabled due to other already enabled event groups
 * \retval PTI_ERROR_INVALID_PARAMETER if \p eventGroup is NULL
 * \retval PTI_ERROR_HARDWARE_BUSY if another client is profiling
 * and hardware is busy
 */
PTIResult PTIAPI ptiEventGroupEnable(pti_EventGroup eventGroup);

/**
 * \brief Disable an event group.
 *
 * Disable an event group. Disabling an event group stops collection
 * of events contained in the group.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param eventGroup The event group
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_HARDWARE
 * \retval PTI_ERROR_INVALID_PARAMETER if \p eventGroup is NULL
 */
PTIResult PTIAPI ptiEventGroupDisable(pti_EventGroup eventGroup);

/**
 * \brief Read the value for an event in an event group.
 *
 * Read the value for an event in an event group. The event value is
 * returned in the \p eventValueBuffer buffer. \p
 * eventValueBufferSizeBytes indicates the size of the \p
 * eventValueBuffer buffer. The buffer must be at least sizeof(uint64)
 * if ::PTI_EVENT_GROUP_ATTR_PROFILE_ALL_DOMAIN_INSTANCES is not set
 * on the group containing the event.  The buffer must be at least
 * (sizeof(uint64) * number of domain instances) if
 * ::PTI_EVENT_GROUP_ATTR_PROFILE_ALL_DOMAIN_INSTANCES is set on the
 * group.
 *
 * If any instance of an event counter overflows, the value returned
 * for that event instance will be ::PTI_EVENT_OVERFLOW.
 *
 * The only allowed value for \p flags is ::PTI_EVENT_READ_FLAG_NONE.
 *
 * Reading an event from a disabled event group is not allowed. After
 * being read, an event's value is reset to zero.
 * \note \b Thread-safety: this function is thread safe but client
 * must guard against simultaneous destruction or modification of \p
 * eventGroup (for example, client must guard against simultaneous
 * calls to \ref cuptiEventGroupDestroy, \ref cuptiEventGroupAddEvent,
 * etc.), and must guard against simultaneous destruction of the
 * context in which \p eventGroup was created (for example, client
 * must guard against simultaneous calls to cudaDeviceReset,
 * cuCtxDestroy, etc.). If \ref cuptiEventGroupResetAllEvents is
 * called simultaneously with this function, then returned event
 * values are undefined.
 *
 * \param eventGroup The event group
 * \param flags Flags controlling the reading mode
 * \param event The event to read
 * \param eventValueBufferSizeBytes The size of \p eventValueBuffer
 * in bytes, and returns the number of bytes written to \p
 * eventValueBuffer
 * \param eventValueBuffer Returns the event value(s)
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_EVENT_ID
 * \retval PTI_ERROR_HARDWARE
 * \retval PTI_ERROR_INVALID_OPERATION if \p eventGroup is disabled
 * \retval PTI_ERROR_INVALID_PARAMETER if \p eventGroup, \p
 * eventValueBufferSizeBytes or \p eventValueBuffer is NULL
 * \retval PTI_ERROR_PARAMETER_SIZE_NOT_SUFFICIENT if size of \p eventValueBuffer
 * is not sufficient
 */
PTIResult PTIAPI ptiEventGroupReadEvent(pti_EventGroup eventGroup,
                                              pti_ReadEventFlags flags,
                                              pti_EventID event,
                                              size_t *eventValueBufferSizeBytes,
                                              uint64_t *eventValueBuffer);

/**
 * \brief Read the values for all the events in an event group.
 *
 * Read the values for all the events in an event group. The event
 * values are returned in the \p eventValueBuffer buffer. \p
 * eventValueBufferSizeBytes indicates the size of \p
 * eventValueBuffer.  The buffer must be at least (sizeof(uint64) *
 * number of events in group) if
 * ::PTI_EVENT_GROUP_ATTR_PROFILE_ALL_DOMAIN_INSTANCES is not set on
 * the group containing the events.  The buffer must be at least
 * (sizeof(uint64) * number of domain instances * number of events in
 * group) if ::PTI_EVENT_GROUP_ATTR_PROFILE_ALL_DOMAIN_INSTANCES is
 * set on the group.
 *
 * The data format returned in \p eventValueBuffer is:
 *    - domain instance 0: event0 event1 ... eventN
 *    - domain instance 1: event0 event1 ... eventN
 *    - ...
 *    - domain instance M: event0 event1 ... eventN
 *
 * The event order in \p eventValueBuffer is returned in \p
 * eventIdArray. The size of \p eventIdArray is specified in \p
 * eventIdArraySizeBytes. The size should be at least
 * (sizeof(pti_EventID) * number of events in group).
 *
 * If any instance of any event counter overflows, the value returned
 * for that event instance will be ::PTI_EVENT_OVERFLOW.
 *
 * The only allowed value for \p flags is ::PTI_EVENT_READ_FLAG_NONE.
 *
 * Reading events from a disabled event group is not allowed. After
 * being read, an event's value is reset to zero.
 * \note \b Thread-safety: this function is thread safe but client
 * must guard against simultaneous destruction or modification of \p
 * eventGroup (for example, client must guard against simultaneous
 * calls to \ref cuptiEventGroupDestroy, \ref cuptiEventGroupAddEvent,
 * etc.), and must guard against simultaneous destruction of the
 * context in which \p eventGroup was created (for example, client
 * must guard against simultaneous calls to cudaDeviceReset,
 * cuCtxDestroy, etc.). If \ref cuptiEventGroupResetAllEvents is
 * called simultaneously with this function, then returned event
 * values are undefined.
 *
 * \param eventGroup The event group
 * \param flags Flags controlling the reading mode
 * \param eventValueBufferSizeBytes The size of \p eventValueBuffer in
 * bytes, and returns the number of bytes written to \p
 * eventValueBuffer
 * \param eventValueBuffer Returns the event values
 * \param eventIdArraySizeBytes The size of \p eventIdArray in bytes,
 * and returns the number of bytes written to \p eventIdArray
 * \param eventIdArray Returns the IDs of the events in the same order
 * as the values return in eventValueBuffer.
 * \param numEventIdsRead Returns the number of event IDs returned
 * in \p eventIdArray
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_HARDWARE
 * \retval PTI_ERROR_INVALID_OPERATION if \p eventGroup is disabled
 * \retval PTI_ERROR_INVALID_PARAMETER if \p eventGroup, \p
 * eventValueBufferSizeBytes, \p eventValueBuffer, \p
 * eventIdArraySizeBytes, \p eventIdArray or \p numEventIdsRead is
 * NULL
 * \retval PTI_ERROR_PARAMETER_SIZE_NOT_SUFFICIENT if size of \p eventValueBuffer
 * or \p eventIdArray is not sufficient
 */
PTIResult PTIAPI ptiEventGroupReadAllEvents(pti_EventGroup       eventGroup,
                                                  pti_ReadEventFlags   flags,
                                                  size_t                 *eventValueBufferSizeBytes,
                                                  uint64_t               *eventValueBuffer,
                                                  size_t                 *eventIdArraySizeBytes,
                                                  pti_EventID          *eventIdArray,
                                                  size_t                 *numEventIdsRead);

/**
 * \brief For a set of events, get the grouping that indicates the
 * number of passes and the event groups necessary to collect the
 * events.
 *
 * The number of events that can be collected simultaneously varies by
 * device and by the type of the events. When events can be collected
 * simultaneously, they may need to be grouped into multiple event
 * groups because they are from different event domains. This function
 * takes a set of events and determines how many passes are required
 * to collect all those events, and which events can be collected
 * simultaneously in each pass.
 *
 * The pti_EventGroupSets returned in \p eventGroupPasses indicates
 * how many passes are required to collect the events with the \p
 * numSets field. Within each event group set, the \p sets array
 * indicates the event groups that should be collected on each pass.
 * \note \b Thread-safety: this function is thread safe, but client
 * must guard against another thread simultaneously destroying \p
 * context.
 *
 * \param context The context for event collection
 * \param eventIdArraySizeBytes Size of \p eventIdArray in bytes
 * \param eventIdArray Array of event IDs that need to be grouped
 * \param eventGroupPasses Returns a pti_EventGroupSets object that
 * indicates the number of passes required to collect the events and
 * the events to collect on each pass
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_CONTEXT
 * \retval PTI_ERROR_INVALID_EVENT_ID
 * \retval PTI_ERROR_INVALID_PARAMETER if \p eventIdArray or
 * \p eventGroupPasses is NULL
 */
PTIResult PTIAPI ptiEventGroupSetsCreate(RPPcontext context,
                                               size_t eventIdArraySizeBytes,
                                               pti_EventID *eventIdArray,
                                               pti_EventGroupSets **eventGroupPasses);

/**
 * \brief Destroy a pti_EventGroupSets object.
 *
 * Destroy a pti_EventGroupSets object.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param eventGroupSets The object to destroy
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_OPERATION if any of the event groups
 * contained in the sets is enabled
 * \retval PTI_ERROR_INVALID_PARAMETER if \p eventGroupSets is NULL
 */
PTIResult PTIAPI ptiEventGroupSetsDestroy(pti_EventGroupSets *eventGroupSets);


/**
 * \brief Enable an event group set.
 *
 * Enable a set of event groups. Enabling a set of event groups zeros the value of
 * all the events in all the groups and then starts collection of those events.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param eventGroupSet The pointer to the event group set
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_HARDWARE
 * \retval PTI_ERROR_NOT_READY if \p eventGroup does not contain any events
 * \retval PTI_ERROR_NOT_COMPATIBLE if \p eventGroup cannot be
 * enabled due to other already enabled event groups
 * \retval PTI_ERROR_INVALID_PARAMETER if \p eventGroupSet is NULL
 * \retval PTI_ERROR_HARDWARE_BUSY if other client is profiling and hardware is
 * busy
 */
PTIResult PTIAPI ptiEventGroupSetEnable(pti_EventGroupSet *eventGroupSet);

/**
 * \brief Disable an event group set.
 *
 * Disable a set of event groups. Disabling a set of event groups
 * stops collection of events contained in the groups.
 * \note \b Thread-safety: this function is thread safe.
 * \note \b If this call fails, some of the event groups in the set may be disabled
 * and other event groups may remain enabled.
 *
 * \param eventGroupSet The pointer to the event group set
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_HARDWARE
 * \retval PTI_ERROR_INVALID_PARAMETER if \p eventGroupSet is NULL
 */
PTIResult PTIAPI ptiEventGroupSetDisable(pti_EventGroupSet *eventGroupSet);

/**
 * \brief Enable kernel replay mode.
 *
 * Set profiling mode for the context to replay mode. In this mode,
 * any number of events can be collected in one run of the kernel. The
 * event collection mode will automatically switch to
 * PTI_EVENT_COLLECTION_MODE_KERNEL.  In this mode, \ref
 * cuptiSetEventCollectionMode will return
 * PTI_ERROR_INVALID_OPERATION.
 * \note \b Kernels might take longer to run if many events are enabled.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param context The context
 * \retval PTI_SUCCESS
 */
PTIResult PTIAPI ptiEnableKernelReplayMode(RPPcontext context);

/**
 * \brief Disable kernel replay mode.
 *
 * Set profiling mode for the context to non-replay (default)
 * mode. Event collection mode will be set to
 * PTI_EVENT_COLLECTION_MODE_KERNEL.  All previously enabled
 * event groups and event group sets will be disabled.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param context The context
 * \retval PTI_SUCCESS
 */
PTIResult PTIAPI ptiDisableKernelReplayMode(RPPcontext context);

/**
 * \brief Function type for getting updates on kernel replay.
 *
 * \param kernelName The mangled kernel name
 * \param numReplaysDone Number of replays done so far
 * \param customData Pointer of any custom data passed in when subscribing
 */
typedef void (PTIAPI *pti_KernelReplayUpdateFunc)(
    const char *kernelName,
    int numReplaysDone,
    void *customData);

/**
 * \brief Subscribe to kernel replay updates.
 *
 * When subscribed, the function pointer passed in will be called each time a
 * kernel run is finished during kernel replay. Previously subscribed function
 * pointer will be replaced. Pass in NULL as the function pointer unsubscribes
 * the update.
 *
 * \param updateFunc The update function pointer
 * \param customData Pointer to any custom data
 * \retval PTI_SUCCESS
 */
PTIResult PTIAPI ptiKernelReplaySubscribeUpdate(pti_KernelReplayUpdateFunc updateFunc, void *customData);
#endif

/** @} */ /* END PTI_EVENT_API */

#if defined(__cplusplus)
}
#endif

#endif /*_PTI_EVENTS_H_*/


