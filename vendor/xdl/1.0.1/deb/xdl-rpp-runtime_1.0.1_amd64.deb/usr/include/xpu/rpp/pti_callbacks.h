#if !defined(__PTI_CALLBACKS_H__)
#define __PTI_CALLBACKS_H__

#include <stdint.h>
#include <pti_result.h>

#ifndef PTIAPI
#ifdef _WIN32
#define PTIAPI __stdcall
#else
#define PTIAPI
#endif
#endif

#if defined(__cplusplus)
extern "C" {
#endif

/**
 * \defgroup PTI_CALLBACK_API PTI Callback API
 * Functions, types, and enums that implement the PTI Callback API.
 * @{
 */

/**
 * \brief Specifies the point in an API call that a callback is issued.
 *
 * Specifies the point in an API call that a callback is issued. This
 * value is communicated to the callback function via \ref
 * pti_CallbackData::callbackSite.
 */
typedef enum {
  /**
   * The callback is at the entry of the API call.
   */
  PTI_API_ENTER                 = 0,
  /**
   * The callback is at the exit of the API call.
   */
  PTI_API_EXIT                  = 1,
  PTI_API_CBSITE_FORCE_INT     = 0x7fffffff
} pti_ApiCallbackSite;

/**
 * \brief Callback domains.
 *
 * Callback domains. Each domain represents callback points for a
 * group of related API functions or CUDA driver activity.
 */
typedef enum {
  /**
   * Invalid domain.
   */
  PTI_CB_DOMAIN_INVALID           = 0,
  /**
   * Domain containing callback points for all driver API functions.
   */
  PTI_CB_DOMAIN_DRIVER_API        = 1,
  /**
   * Domain containing callback points for all runtime API
   * functions.
   */
  PTI_CB_DOMAIN_RUNTIME_API       = 2,
  /**
   * Domain containing callback points for CUDA resource tracking.
   */
  PTI_CB_DOMAIN_RESOURCE          = 3,
  /**
   * Domain containing callback points for CUDA synchronization.
   */
  PTI_CB_DOMAIN_SYNCHRONIZE       = 4,
  /**
   * Domain containing callback points for NVTX API functions.
   */
  PTI_CB_DOMAIN_NVTX              = 5,
  PTI_CB_DOMAIN_SIZE              = 6,
  PTI_CB_DOMAIN_FORCE_INT         = 0x7fffffff
} pti_CallbackDomain;

/**
 * \brief Callback IDs for resource domain.
 *
 * Callback IDs for resource domain, PTI_CB_DOMAIN_RESOURCE.  This
 * value is communicated to the callback function via the \p cbid
 * parameter.
 */
typedef enum {
  /**
   * Invalid resource callback ID.
   */
  PTI_CBID_RESOURCE_INVALID                     = 0,
  /**
   * A new context has been created.
   */
  PTI_CBID_RESOURCE_CONTEXT_CREATED             = 1,
  /**
   * A context is about to be destroyed.
   */
  PTI_CBID_RESOURCE_CONTEXT_DESTROY_STARTING    = 2,
  /**
   * A new stream has been created.
   */
  PTI_CBID_RESOURCE_STREAM_CREATED              = 3,
  /**
   * A stream is about to be destroyed.
   */
  PTI_CBID_RESOURCE_STREAM_DESTROY_STARTING     = 4,
  /**
   * The driver has finished initializing.
   */
  PTI_CBID_RESOURCE_CU_INIT_FINISHED            = 5,
  /**
   * A module has been loaded.
   */
  PTI_CBID_RESOURCE_MODULE_LOADED               = 6,
  /**
   * A module is about to be unloaded.
   */
  PTI_CBID_RESOURCE_MODULE_UNLOAD_STARTING      = 7,
  /**
   * The current module which is being profiled.
   */
  PTI_CBID_RESOURCE_MODULE_PROFILED             = 8,

  PTI_CBID_RESOURCE_SIZE,
  PTI_CBID_RESOURCE_FORCE_INT                   = 0x7fffffff
} pti_CallbackIdResource;

/**
 * \brief Callback IDs for synchronization domain.
 *
 * Callback IDs for synchronization domain,
 * PTI_CB_DOMAIN_SYNCHRONIZE.  This value is communicated to the
 * callback function via the \p cbid parameter.
 */
typedef enum {
  /**
   * Invalid synchronize callback ID.
   */
  PTI_CBID_SYNCHRONIZE_INVALID                  = 0,
  /**
   * Stream synchronization has completed for the stream.
   */
  PTI_CBID_SYNCHRONIZE_STREAM_SYNCHRONIZED      = 1,
  /**
   * Context synchronization has completed for the context.
   */
  PTI_CBID_SYNCHRONIZE_CONTEXT_SYNCHRONIZED     = 2,
  PTI_CBID_SYNCHRONIZE_SIZE,
  PTI_CBID_SYNCHRONIZE_FORCE_INT                = 0x7fffffff
} pti_CallbackIdSync;

/**
 * \brief Data passed into a runtime or driver API callback function.
 *
 * Data passed into a runtime or driver API callback function as the
 * \p cbdata argument to \ref pti_CallbackFunc. The \p cbdata will
 * be this type for \p domain equal to PTI_CB_DOMAIN_DRIVER_API or
 * PTI_CB_DOMAIN_RUNTIME_API. The callback data is valid only within
 * the invocation of the callback function that is passed the data. If
 * you need to retain some data for use outside of the callback, you
 * must make a copy of that data. For example, if you make a shallow
 * copy of pti_CallbackData within a callback, you cannot
 * dereference \p functionParams outside of that callback to access
 * the function parameters. \p functionName is an exception: the
 * string pointed to by \p functionName is a global constant and so
 * may be accessed outside of the callback.
 */
typedef struct {
  /**
   * Point in the runtime or driver function from where the callback
   * was issued.
   */
  pti_ApiCallbackSite callbackSite;

  /**
   * Name of the runtime or driver API function which issued the
   * callback. This string is a global constant and so may be
   * accessed outside of the callback.
   */
  const char *functionName;

  /**
   * Pointer to the arguments passed to the runtime or driver API
   * call. See generated_cuda_runtime_api_meta.h and
   * generated_cuda_meta.h for structure definitions for the
   * parameters for each runtime and driver API function.
   */
  const void *functionParams;

  /**
   * Pointer to the return value of the runtime or driver API
   * call. This field is only valid within the exit::PTI_API_EXIT
   * callback. For a runtime API \p functionReturnValue points to a
   * \p cudaError_t. For a driver API \p functionReturnValue points
   * to a \p CUresult.
   */
  void *functionReturnValue;

  /**
   * Name of the symbol operated on by the runtime or driver API
   * function which issued the callback. This entry is valid only for
   * driver and runtime launch callbacks, where it returns the name of
   * the kernel.
   */
  const char *symbolName;

  /**
   * Driver context current to the thread, or null if no context is
   * current. This value can change from the entry to exit callback
   * of a runtime API function if the runtime initializes a context.
   */
  RPPcontext context;

  /**
   * Unique ID for the CUDA context associated with the thread. The
   * UIDs are assigned sequentially as contexts are created and are
   * unique within a process.
   */
  uint32_t contextUid;

  /**
   * Pointer to data shared between the entry and exit callbacks of
   * a given runtime or drive API function invocation. This field
   * can be used to pass 64-bit values from the entry callback to
   * the corresponding exit callback.
   */
  uint64_t *correlationData;

  /**
   * The activity record correlation ID for this callback. For a
   * driver domain callback (i.e. \p domain
   * PTI_CB_DOMAIN_DRIVER_API) this ID will equal the correlation ID
   * in the pti_ActivityAPI record corresponding to the CUDA driver
   * function call. For a runtime domain callback (i.e. \p domain
   * PTI_CB_DOMAIN_RUNTIME_API) this ID will equal the correlation
   * ID in the pti_ActivityAPI record corresponding to the CUDA
   * runtime function call. Within the callback, this ID can be
   * recorded to correlate user data with the activity record. This
   * field is new in 4.1.
   */
  uint32_t correlationId;

} pti_CallbackData;

/**
 * \brief Data passed into a resource callback function.
 *
 * Data passed into a resource callback function as the \p cbdata
 * argument to \ref pti_CallbackFunc. The \p cbdata will be this
 * type for \p domain equal to PTI_CB_DOMAIN_RESOURCE. The callback
 * data is valid only within the invocation of the callback function
 * that is passed the data. If you need to retain some data for use
 * outside of the callback, you must make a copy of that data.
 */
typedef struct {
  /**
   * For PTI_CBID_RESOURCE_CONTEXT_CREATED and
   * PTI_CBID_RESOURCE_CONTEXT_DESTROY_STARTING, the context being
   * created or destroyed. For PTI_CBID_RESOURCE_STREAM_CREATED and
   * PTI_CBID_RESOURCE_STREAM_DESTROY_STARTING, the context
   * containing the stream being created or destroyed.
   */
  RPPcontext context;

  union {
    /**
     * For PTI_CBID_RESOURCE_STREAM_CREATED and
     * PTI_CBID_RESOURCE_STREAM_DESTROY_STARTING, the stream being
     * created or destroyed.
     */
    RPPstream stream;
  } resourceHandle;

  /**
   * Reserved for future use.
   */
  void *resourceDescriptor;
} pti_ResourceData;


/**
 * \brief Module data passed into a resource callback function.
 *
 * CUDA module data passed into a resource callback function as the \p cbdata
 * argument to \ref pti_CallbackFunc. The \p cbdata will be this
 * type for \p domain equal to PTI_CB_DOMAIN_RESOURCE. The module
 * data is valid only within the invocation of the callback function
 * that is passed the data. If you need to retain some data for use
 * outside of the callback, you must make a copy of that data.
 */

typedef struct {
  /**
   * Identifier to associate with the CUDA module.
   */
    uint32_t moduleId;

  /**
   * The size of the cubin.
   */
    size_t cubinSize;

  /**
   * Pointer to the associated cubin.
   */
    const char *pCubin;
} pti_ModuleResourceData;

/**
 * \brief Data passed into a synchronize callback function.
 *
 * Data passed into a synchronize callback function as the \p cbdata
 * argument to \ref pti_CallbackFunc. The \p cbdata will be this
 * type for \p domain equal to PTI_CB_DOMAIN_SYNCHRONIZE. The
 * callback data is valid only within the invocation of the callback
 * function that is passed the data. If you need to retain some data
 * for use outside of the callback, you must make a copy of that data.
 */
typedef struct {
  /**
   * The context of the stream being synchronized.
   */
  RPPcontext context;
  /**
   * The stream being synchronized.
   */
  RPPstream  stream;
} pti_SynchronizeData;

/**
 * \brief Data passed into a NVTX callback function.
 *
 * Data passed into a NVTX callback function as the \p cbdata argument
 * to \ref pti_CallbackFunc. The \p cbdata will be this type for \p
 * domain equal to PTI_CB_DOMAIN_NVTX. Unless otherwise notes, the
 * callback data is valid only within the invocation of the callback
 * function that is passed the data. If you need to retain some data
 * for use outside of the callback, you must make a copy of that data.
 */
typedef struct {
  /**
   * Name of the NVTX API function which issued the callback. This
   * string is a global constant and so may be accessed outside of the
   * callback.
   */
  const char *functionName;

  /**
   * Pointer to the arguments passed to the NVTX API call. See
   * generated_nvtx_meta.h for structure definitions for the
   * parameters for each NVTX API function.
   */
  const void *functionParams;
} pti_NvtxData;

/**
 * \brief An ID for a driver API, runtime API, resource or
 * synchronization callback.
 *
 * An ID for a driver API, runtime API, resource or synchronization
 * callback. Within a driver API callback this should be interpreted
 * as a pti_driver_api_trace_cbid value (these values are defined in
 * cupti_driver_cbid.h). Within a runtime API callback this should be
 * interpreted as a pti_runtime_api_trace_cbid value (these values
 * are defined in cupti_runtime_cbid.h). Within a resource API
 * callback this should be interpreted as a \ref
 * pti_CallbackIdResource value. Within a synchronize API callback
 * this should be interpreted as a \ref pti_CallbackIdSync value.
 */
typedef uint32_t pti_CallbackId;

/**
 * \brief Function type for a callback.
 *
 * Function type for a callback. The type of the data passed to the
 * callback in \p cbdata depends on the \p domain. If \p domain is
 * PTI_CB_DOMAIN_DRIVER_API or PTI_CB_DOMAIN_RUNTIME_API the type
 * of \p cbdata will be pti_CallbackData. If \p domain is
 * PTI_CB_DOMAIN_RESOURCE the type of \p cbdata will be
 * pti_ResourceData. If \p domain is PTI_CB_DOMAIN_SYNCHRONIZE the
 * type of \p cbdata will be pti_SynchronizeData. If \p domain is
 * PTI_CB_DOMAIN_NVTX the type of \p cbdata will be pti_NvtxData.
 *
 * \param userdata User data supplied at subscription of the callback
 * \param domain The domain of the callback
 * \param cbid The ID of the callback
 * \param cbdata Data passed to the callback.
 */
typedef void (PTIAPI *pti_CallbackFunc)(
    void *userdata,
    pti_CallbackDomain domain,
    pti_CallbackId cbid,
    const void *cbdata);

/**
 * \brief A callback subscriber.
 */
typedef struct pti_Subscriber_st *pti_SubscriberHandle;

/**
 * \brief Pointer to an array of callback domains.
 */
typedef pti_CallbackDomain *pti_DomainTable;


#if 0
/**
 * \brief Get the available callback domains.
 *
 * Returns in \p *domainTable an array of size \p *domainCount of all
 * the available callback domains.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param domainCount Returns number of callback domains
 * \param domainTable Returns pointer to array of available callback domains
 *
 * \retval PTI_SUCCESS on success
 * \retval PTI_ERROR_NOT_INITIALIZED if unable to initialize PTI
 * \retval PTI_ERROR_INVALID_PARAMETER if \p domainCount or \p domainTable are NULL
 */
PTIResult PTIAPI ptiSupportedDomains(size_t *domainCount,
                                           pti_DomainTable *domainTable);

/**
 * \brief Initialize a callback subscriber with a callback function
 * and user data.
 *
 * Initializes a callback subscriber with a callback function and
 * (optionally) a pointer to user data. The returned subscriber handle
 * can be used to enable and disable the callback for specific domains
 * and callback IDs.
 * \note Only a single subscriber can be registered at a time.
 * \note This function does not enable any callbacks.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param subscriber Returns handle to initialize subscriber
 * \param callback The callback function
 * \param userdata A pointer to user data. This data will be passed to
 * the callback function via the \p userdata paramater.
 *
 * \retval PTI_SUCCESS on success
 * \retval PTI_ERROR_NOT_INITIALIZED if unable to initialize PTI
 * \retval PTI_ERROR_MAX_LIMIT_REACHED if there is already a PTI subscriber
 * \retval PTI_ERROR_INVALID_PARAMETER if \p subscriber is NULL
 */
PTIResult PTIAPI ptiSubscribe(pti_SubscriberHandle *subscriber,
                                    pti_CallbackFunc callback,
                                    void *userdata);

/**
 * \brief Unregister a callback subscriber.
 *
 * Removes a callback subscriber so that no future callbacks will be
 * issued to that subscriber.
 * \note \b Thread-safety: this function is thread safe.
 *
 * \param subscriber Handle to the initialize subscriber
 *
 * \retval PTI_SUCCESS on success
 * \retval PTI_ERROR_NOT_INITIALIZED if unable to initialized PTI
 * \retval PTI_ERROR_INVALID_PARAMETER if \p subscriber is NULL or not initialized
 */
PTIResult PTIAPI ptiUnsubscribe(pti_SubscriberHandle subscriber);

/**
 * \brief Get the current enabled/disabled state of a callback for a specific
 * domain and function ID.
 *
 * Returns non-zero in \p *enable if the callback for a domain and
 * callback ID is enabled, and zero if not enabled.
 *
 * \note \b Thread-safety: a subscriber must serialize access to
 * cuptiGetCallbackState, cuptiEnableCallback, cuptiEnableDomain, and
 * cuptiEnableAllDomains. For example, if cuptiGetCallbackState(sub,
 * d, c) and cuptiEnableCallback(sub, d, c) are called concurrently,
 * the results are undefined.
 *
 * \param enable Returns non-zero if callback enabled, zero if not enabled
 * \param subscriber Handle to the initialize subscriber
 * \param domain The domain of the callback
 * \param cbid The ID of the callback
 *
 * \retval PTI_SUCCESS on success
 * \retval PTI_ERROR_NOT_INITIALIZED if unable to initialized PTI
 * \retval PTI_ERROR_INVALID_PARAMETER if \p enabled is NULL, or if \p
 * subscriber, \p domain or \p cbid is invalid.
 */
PTIResult PTIAPI ptiGetCallbackState(uint32_t *enable,
                                           pti_SubscriberHandle subscriber,
                                           pti_CallbackDomain domain,
                                           pti_CallbackId cbid);

/**
 * \brief Enable or disabled callbacks for a specific domain and
 * callback ID.
 *
 * Enable or disabled callbacks for a subscriber for a specific domain
 * and callback ID.
 *
 * \note \b Thread-safety: a subscriber must serialize access to
 * cuptiGetCallbackState, cuptiEnableCallback, cuptiEnableDomain, and
 * cuptiEnableAllDomains. For example, if cuptiGetCallbackState(sub,
 * d, c) and cuptiEnableCallback(sub, d, c) are called concurrently,
 * the results are undefined.
 *
 * \param enable New enable state for the callback. Zero disables the
 * callback, non-zero enables the callback.
 * \param subscriber - Handle to callback subscription
 * \param domain The domain of the callback
 * \param cbid The ID of the callback
 *
 * \retval PTI_SUCCESS on success
 * \retval PTI_ERROR_NOT_INITIALIZED if unable to initialized PTI
 * \retval PTI_ERROR_INVALID_PARAMETER if \p subscriber, \p domain or \p
 * cbid is invalid.
 */
PTIResult PTIAPI ptiEnableCallback(uint32_t enable,
                                         pti_SubscriberHandle subscriber,
                                         pti_CallbackDomain domain,
                                         pti_CallbackId cbid);

/**
 * \brief Enable or disabled all callbacks for a specific domain.
 *
 * Enable or disabled all callbacks for a specific domain.
 *
 * \note \b Thread-safety: a subscriber must serialize access to
 * cuptiGetCallbackState, cuptiEnableCallback, cuptiEnableDomain, and
 * cuptiEnableAllDomains. For example, if cuptiGetCallbackEnabled(sub,
 * d, *) and cuptiEnableDomain(sub, d) are called concurrently, the
 * results are undefined.
 *
 * \param enable New enable state for all callbacks in the
 * domain. Zero disables all callbacks, non-zero enables all
 * callbacks.
 * \param subscriber - Handle to callback subscription
 * \param domain The domain of the callback
 *
 * \retval PTI_SUCCESS on success
 * \retval PTI_ERROR_NOT_INITIALIZED if unable to initialized PTI
 * \retval PTI_ERROR_INVALID_PARAMETER if \p subscriber or \p domain is invalid
 */
PTIResult PTIAPI ptiEnableDomain(uint32_t enable,
                                       pti_SubscriberHandle subscriber,
                                       pti_CallbackDomain domain);

/**
 * \brief Enable or disable all callbacks in all domains.
 *
 * Enable or disable all callbacks in all domains.
 *
 * \note \b Thread-safety: a subscriber must serialize access to
 * cuptiGetCallbackState, cuptiEnableCallback, cuptiEnableDomain, and
 * cuptiEnableAllDomains. For example, if cuptiGetCallbackState(sub,
 * d, *) and cuptiEnableAllDomains(sub) are called concurrently, the
 * results are undefined.
 *
 * \param enable New enable state for all callbacks in all
 * domain. Zero disables all callbacks, non-zero enables all
 * callbacks.
 * \param subscriber - Handle to callback subscription
 *
 * \retval PTI_SUCCESS on success
 * \retval PTI_ERROR_NOT_INITIALIZED if unable to initialized PTI
 * \retval PTI_ERROR_INVALID_PARAMETER if \p subscriber is invalid
 */
PTIResult PTIAPI ptiEnableAllDomains(uint32_t enable,
                                           pti_SubscriberHandle subscriber);

/**
 * \brief Get the name of a callback for a specific domain and callback ID.
 *
 * Returns a pointer to the name c_string in \p **name.
 *
 * \note \b Names are available only for the DRIVER and RUNTIME domains.
 *
 * \param domain The domain of the callback
 * \param cbid The ID of the callback
 * \param name Returns pointer to the name string on success, NULL otherwise
 *
 * \retval PTI_SUCCESS on success
 * \retval PTI_ERROR_INVALID_PARAMETER if \p name is NULL, or if
 * \p domain or \p cbid is invalid.
 */
PTIResult PTIAPI ptiGetCallbackName(pti_CallbackDomain domain,
                                          uint32_t cbid,
                                          const char **name);
#endif

/** @} */ /* END PTI_CALLBACK_API */

#if defined(__cplusplus)
}
#endif

#endif  // file guard

