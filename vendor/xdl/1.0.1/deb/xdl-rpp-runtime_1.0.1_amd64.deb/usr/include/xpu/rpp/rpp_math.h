#pragma once
#include <rpp_f16.h>
#define __CUDA_DEVICE__ inline __device__

typedef struct rppComplex_t0
{
    float x;
	float y;
}rppComplex;

typedef struct rppfftComplex_t0
{
    float x;
    float y;
}rppfftComplex;

__CUDA_DEVICE__ short rpp_isnan(float a)
{
	short out;
	asm("{TESTP.F32 %0, %1;\n}"
      : "=h"(out) : "f"(a));
	return out;
}
__CUDA_DEVICE__ float rpp_copysign(float a, float b)
{
	float out;
	asm("{copysign.f32 	%0, %1, %2;\n}"
      : "=r"(out) : "f"(a), "f"(b));
	return out;
}
__CUDA_DEVICE__ float rpp_max(float x, float y)
{
	float out;
	asm("{max.f32 	%0, %1, %2;\n}"
      : "=r"(out) : "f"(x), "f"(y));
	return out;
}
__CUDA_DEVICE__ int rpp_max(int x, int y)
{
	int out;
	asm("{max.s32 	%0, %1, %2;\n}"
      : "=r"(out) : "r"(x), "r"(y));
	return out;
}
__CUDA_DEVICE__ uint32_t rpp_max(uint32_t x, uint32_t y)
{
	uint32_t out;
	asm("{max.u32 	%0, %1, %2;\n}"
      : "=r"(out) : "r"(x), "r"(y));
	return out;
}
__CUDA_DEVICE__ short rpp_max(short x, short y)
{
	short out;
	asm("{max.s16 	%0, %1, %2;\n}"
      : "=h"(out) : "h"(x), "h"(y));
	return out;
}
__CUDA_DEVICE__ uint16_t rpp_max(uint16_t x, uint16_t y)
{
	uint16_t out;
	asm("{max.u16 	%0, %1, %2;\n}"
      : "=h"(out) : "h"(x), "h"(y));
	return out;
}
__CUDA_DEVICE__ float rpp_min(float x, float y)
{
	float out;
	asm("{min.f32 	%0, %1, %2;\n}"
      : "=r"(out) : "f"(x), "f"(y));
	return out;
}
__CUDA_DEVICE__ int rpp_min(int x, int y)
{
	int out;
	asm("{min.s32 	%0, %1, %2;\n}"
      : "=r"(out) : "r"(x), "r"(y));
	return out;
}
__CUDA_DEVICE__ uint32_t rpp_min(uint32_t x, uint32_t y)
{
	uint32_t out;
	asm("{min.u32 	%0, %1, %2;\n}"
      : "=r"(out) : "r"(x), "r"(y));
	return out;
}
__CUDA_DEVICE__ short rpp_min(short x, short y)
{
	short out;
	asm("{min.s16 	%0, %1, %2;\n}"
      : "=h"(out) : "h"(x), "h"(y));
	return out;
}
__CUDA_DEVICE__ uint16_t rpp_min(uint16_t x, uint16_t y)
{
	uint16_t out;
	asm("{min.u16 	%0, %1, %2;\n}"
      : "=h"(out) : "h"(x), "h"(y));
	return out;
}
__CUDA_DEVICE__ uint16_t rpp_max_f16(uint16_t x, uint16_t y)
{
uint16_t out;
asm("{max.f16 	%0, %1, %2;\n}"
        : "=h"(out) : "h"(x), "h"(y));
return out;
}
__CUDA_DEVICE__ uint16_t rpp_min_f16(uint16_t x, uint16_t y)
{
uint16_t out;
asm("{min.f16 	%0, %1, %2;\n}"
        : "=h"(out) : "h"(x), "h"(y));
return out;
}

__CUDA_DEVICE__ float rpp_abs(float x)
{
	float out;
	asm("{abs.f32 	%0, %1;\n}"
      : "=f"(out) : "f"(x));
	return out;
}
__CUDA_DEVICE__ int rpp_abs(int x)
{
	int out;
	asm("{abs.s32 	%0, %1;\n}"
      : "=r"(out) : "r"(x));
	return out;
}
__CUDA_DEVICE__ uint32_t rpp_abs(uint32_t x)
{
	uint32_t out;
	asm("{abs.u32 	%0, %1;\n}"
      : "=r"(out) : "r"(x));
	return out;
}
__CUDA_DEVICE__ short rpp_abs(short x)
{
	short out;
	asm("{abs.s16 	%0, %1;\n}"
      : "=h"(out) : "h"(x));
	return out;
}
__CUDA_DEVICE__ uint16_t rpp_abs(uint16_t x)
{
	uint16_t out;
	asm("{abs.u16 	%0, %1;\n}"
      : "=h"(out) : "h"(x));
	return out;
}
__CUDA_DEVICE__ float rpp_floorf(float x)
{
	float fout;
	float tmp = rpp_copysign(x, 0.999999f);
	int iout;
	float y = x + tmp;
	y = rpp_min(y, x);
    iout = (int)y;
	fout = (float)iout;
	return fout;
}
__CUDA_DEVICE__ float rpp_ceilf(float x)
{
	float fout;
	float tmp = rpp_copysign(x, 0.999999f);
	int iout;
	float y = x + tmp;
	y = rpp_max(y, x);
    iout = (int)y;
	fout = (float)iout;
	return fout;
}
__CUDA_DEVICE__ float rpp_roundf(float x)
{
	float fout;
	float tmp = rpp_copysign(x, 0.5f);
	int iout;
	float y = x + tmp;
    iout = (int)y;
	fout = (float)iout;
	return fout;
}
__CUDA_DEVICE__ float rpp_rsqrtf(float x)
{
	float xhalf = 0.5f * x;
	int i = *(int*)&x; // get bits for floating value
	i = 0x5f3759df - (i >> 1); // gives initial guess
	float y = *(float*)&i; // convert bits back to float
	y = y * (1.5f - xhalf * y * y); // Newton step
	//float y = x;
	return y;
}

__CUDA_DEVICE__ float rpp_rsqrtf_precise(float x)
{
    float xhalf = 0.5f * x;
    int i = *(int*)&x;
    i = 0x5f3759df - (i >> 1);
    float y = *(float*)&i;

    y = y * (1.5f - xhalf * y * y);
    y = y * (1.5f - xhalf * y * y);
    y = y * (1.5f - xhalf * y * y);

    return y;
}

__CUDA_DEVICE__ float rpp_sqrtf(float x)
{
	float xhalf = 0.5f * x;
	int i = *(int*)&x; // get bits for floating value
	i = 0x5f3759df - (i >> 1); // gives initial guess
	float y = *(float*)&i; // convert bits back to float
	y = y * (1.5f - xhalf * y * y); // Newton step
    y = y * (1.5f - xhalf * y * y);
    y = y * (1.5f - xhalf * y * y);
	y = y * x;
	return y;
}

__CUDA_DEVICE__ float rpp_rcpf(float x)
{
	float x2 = x*x;
	float xhalf = 0.5f * x2;
	int i = *(int*)&x2; // get bits for floating value
	i = 0x5f3759df - (i >> 1); // gives initial guess
	float y = *(float*)&i; // convert bits back to float
	y = y * (1.5f - xhalf * y * y); // Newton step
	y = rpp_copysign(x, y);
	return y;
}
__CUDA_DEVICE__ float rpp_div(float a, float b)
{
    float out;
    asm("{div.f32 	%0, %1, %2;\n}"
            : "=r"(out) : "f"(a), "f"(b));
    return out;
}
__CUDA_DEVICE__ short rpp_div(short a, short b)
{
	short out;
	asm("{div.s16 	%0, %1, %2;\n}"
      : "=h"(out) : "h"(a), "h"(b));
	return out;
}
__CUDA_DEVICE__ uint16_t rpp_div(uint16_t a, uint16_t b)
{
	uint16_t out;
	asm("{div.u16 	%0, %1, %2;\n}"
      : "=h"(out) : "h"(a), "h"(b));
	return out;
}
__CUDA_DEVICE__ int rpp_div(int a, int b)
{
	int out;
	asm("{div.s32 	%0, %1, %2;\n}"
      : "=r"(out) : "r"(a), "r"(b));
	return out;
}
__CUDA_DEVICE__ uint32_t rpp_div(uint32_t a, uint32_t b)
{
	uint32_t out;
	asm("{div.u32 	%0, %1, %2;\n}"
      : "=r"(out) : "r"(a), "r"(b));
	return out;
}
__CUDA_DEVICE__ short rpp_mod(short x, short y)
{
    return x - (rpp_div(x, y) * y);
}

__CUDA_DEVICE__ uint16_t rpp_mod(uint16_t x, uint16_t y)
{
    return x - (rpp_div(x, y) * y);
}
__CUDA_DEVICE__ int rpp_mod(int x, int y)
{
    return x - (rpp_div(x, y) * y);
}
__CUDA_DEVICE__ uint32_t rpp_mod(uint32_t x, uint32_t y)
{
    return x - (rpp_div(x, y) * y);
}
__CUDA_DEVICE__ void rpp_divmod(short x, short y, short& q, short& mod)
{
    q = rpp_div(x, y);
    mod = x - (q * y);
}
__CUDA_DEVICE__ void rpp_divmod(uint16_t x, uint16_t y, uint16_t& q, uint16_t& mod)
{
    q = rpp_div(x, y);
    mod = x - (q * y);
}
__CUDA_DEVICE__ void rpp_divmod(int x, int y, int& q, int& mod)
{
    q = rpp_div(x, y);
    mod = x - (q * y);
}
__CUDA_DEVICE__ void rpp_divmod(uint32_t x, uint32_t y, uint32_t& q, uint32_t& mod)
{
    q = rpp_div(x, y);
    mod = x - (q * y);
}
__CUDA_DEVICE__ uint16_t rpp_msb(uint32_t x)
{
	uint16_t out;
	asm("{BFIND.u32 %0, %1;\n}"
        : "=h"(out) : "r"(x));
	return out;
}
__CUDA_DEVICE__ uint16_t rpp_msb(int32_t x)
{
	uint16_t out;
	asm("{BFIND.s32 %0, %1;\n}"
        : "=h"(out) : "r"(x));
	return out;
}
__CUDA_DEVICE__ uint16_t rpp_msb(uint16_t x)
{
	uint16_t out;
	asm("{BFIND.u16 %0, %1;\n}"
        : "=h"(out) : "h"(x));
	return out;
}
__CUDA_DEVICE__ uint16_t rpp_msb(int16_t x)
{
	uint16_t out;
	asm("{BFIND.s16 %0, %1;\n}"
        : "=h"(out) : "h"(x));
	return out;
}
/*
float tanhf(float x)
{
	float out;
	asm("{	.reg .pred 	p1,p2;\n"
			".reg .f32 	f<24>;\n"
			".reg .b32 	r1,r2,r3,r4,r5;\n"
			"ld.global.f32 	f1, [%1];\n"
			"abs.f32 	f2, f1;\n"
			"setp.ltu.f32	p1, f2, 0f3F19999A;\n"
			"@p1 bra 	BB6_2;\n"
			"bra.uni 	BB6_1;\n"
			"BB6_2:\n"
			"mul.f32 	f13, f1, f1;\n"
			"mov.f32 	f14, 0fBD563CAE;\n"
			"mov.f32 	f15, 0f3C80F082;\n"
			"fma.rn.f32 	f16, f15, f13, f14;\n"
			"mov.f32 	f17, 0f3E085941;\n"
			"fma.rn.f32 	f18, f16, f13, f17;\n"
			"mov.f32 	f19, 0fBEAAA9ED;\n"
			"fma.rn.f32 	f20, f18, f13, f19;\n"
			"mov.f32 	f21, 0f00000000;\n"
			"fma.rn.f32 	f22, f20, f13, f21;\n"
			"fma.rn.f32 	f23, f22, f1, f1;\n"
			"bra.uni 	BB6_3;\n"
			"BB6_1:\n"
			"mul.f32 	f6, f2, 0f4038AA3B;\n"
			"ex2.approx.ftz.f32 	f7, f6;\n"
			"add.f32 	f8, f7, 0f3F800000;\n"
			"rcp.approx.ftz.f32 	f9, f8;\n"
			"mov.f32 	f10, 0f3F800000;\n"
			"mov.f32 	f11, 0fC0000000;\n"
			"fma.rn.f32 	f12, f9, f11, f10;\n"
			"mov.b32 	 r1, f12;\n"
			"setp.ltu.f32	p2, f2, 0f41102CB4;\n"
			"selp.b32	r2, r1, 1065353216, p2;\n"
			"mov.b32 	 r3, f1;\n"
			"and.b32  	r4, r3, -2147483648;\n"
			"or.b32  	r5, r2, r4;\n"
			"mov.b32 	 f23, r5;\n"
			"BB6_3:\n"
			"st.global.f32 	[%0], f23;	}\n"
			: " = r "(out)
			: " r "(x));
	return out;
}
*/

__CUDA_DEVICE__ float rpp_select(float in0, float in1, short mask)
{
    float out;
	asm("{mergemask.wen %0, %1, %2, %3;\n}"
      :"=r"(out) :"f"(in0), "f"(in1), "h"(mask));
	return out;
}
__CUDA_DEVICE__ int rpp_select(int in0, int in1, short mask)
{
    int out;
	asm("{mergemask.wen %0, %1, %2, %3;\n}"
      :"=r"(out) :"r"(in0), "r"(in1), "h"(mask));
	return out;
}
__CUDA_DEVICE__ uint32_t rpp_select(uint32_t in0, uint32_t in1, short mask)
{
    uint32_t out;
	asm("{mergemask.wen %0, %1, %2, %3;\n}"
      :"=r"(out) :"r"(in0), "r"(in1), "h"(mask));
	return out;
}
__CUDA_DEVICE__ uint16_t rpp_select(uint16_t in0, uint16_t in1, short mask)
{
    uint16_t out;
	asm("{mergemask %0, %1, %2, %3;\n}"
      :"=h"(out) :"h"(in0), "h"(in1), "h"(mask));
	return out;
}
__CUDA_DEVICE__ short rpp_select(short in0, short in1, short mask)
{
    short out;
	asm("{mergemask %0, %1, %2, %3;\n}"
      :"=h"(out) :"h"(in0), "h"(in1), "h"(mask));
	return out;
}
__CUDA_DEVICE__ _f16_ rpp_select(_f16_ in0, _f16_ in1, short mask)
{
    _f16_ out;
	asm("{mergemask %0, %1, %2, %3;\n}"
      :"=h"(out) :"h"(in0), "h"(in1), "h"(mask));
	return out;
}
__CUDA_DEVICE__ void rpp_storemask(void *addr, float val, short mask)
{
	asm("{storemask.wen %0, %1, %2;\n}"
      ::"r"(addr),"f"(val), "h"(mask));
	return ;
}
__CUDA_DEVICE__ void rpp_storemask(void *addr, int val, short mask)
{
	asm("{storemask.wen %0, %1, %2;\n}"
      ::"r"(addr),"r"(val), "h"(mask));
	return ;
}
__CUDA_DEVICE__ void rpp_storemask(void *addr, short val, short mask)
{
	asm("{storemask %0, %1, %2;\n}"
      ::"r"(addr),"h"(val), "h"(mask));
	return ;
}
__CUDA_DEVICE__ void rpp_storemask(void *addr, uint32_t val, short mask)
{
	asm("{storemask.wen %0, %1, %2;\n}"
      ::"r"(addr),"r"(val), "h"(mask));
	return ;
}
__CUDA_DEVICE__ void rpp_storemask(void *addr, uint16_t val, short mask)
{
	asm("{storemask %0, %1, %2;\n}"
      ::"r"(addr),"h"(val), "h"(mask));
	return ;
}
__CUDA_DEVICE__ void rpp_storemask(void *addr, _f16_ val, short mask)
{
	asm("{storemask %0, %1, %2;\n}"
      ::"r"(addr),"h"(val), "h"(mask));
	return ;
}
__CUDA_DEVICE__ void rpp_storecont(void *base, uint16_t val)
{
	asm("{STORECONT %0, %1;\n}"
      ::"h"(val),"r"(base));
	return ;
}
__CUDA_DEVICE__ void rpp_storecont_ben(void *base, uint16_t val)
{
	asm("{STORECONT.BEN %0, %1;\n}"
      ::"h"(val),"r"(base));
	return ;
}
__CUDA_DEVICE__ void rpp_storealn(void *base, uint16_t stridy, uint32_t stridz, uint16_t val)
{
	asm("{STOREALN %0, %1, %2, %3;\n}"
      ::"h"(val), "r"(base), "h"(stridy), "r"(stridz));
	return ;
}
__CUDA_DEVICE__ void rpp_loadcont(void *base, uint16_t &val)
{
	asm("{LOADCONT %0, %1;\n}"
      :"=h"(val):"r"(base));
	return ;
}
__CUDA_DEVICE__ void rpp_loadcont_ben(void *base, uint16_t &val)
{
    asm("{LOADCONT.U8 %0, %1;\n}"
            :"=h"(val):"r"(base));
    return ;
}
__CUDA_DEVICE__ void rpp_loadaln(void *base, uint16_t stridy, uint32_t stridz, uint16_t &val)
{
	asm("{LOADALN %0, %1, %2, %3;\n}"
      :"=h"(val):"r"(base), "h"(stridy), "r"(stridz));
	return ;
}
__CUDA_DEVICE__ void rpp_cfg_xyz(uint16_t x, uint16_t y, uint16_t xyz)
{
	asm("{CFGXYZ %0, %1, %2;\n}"
      :: "h"(xyz), "h"(x), "h"(y));
    return;
}
__CUDA_DEVICE__ void rpp_syncthreads()
{
	asm("{DMB_ORI;\n}"
      ::);
    return;
}
__CUDA_DEVICE__ float rpp_expf(float x)
{
    float t = x * 1.442695041f;
	float fi = rpp_floorf(t);
	float f = t - fi;
	int i = (int)fi;
	float cvtf = (0.3371894346f*f + 0.657636276f)*f + 1.00172476f;
    int *cvti = (int*)&cvtf;
	cvti[0] = cvti[0]  + (i << 23);
	return cvtf;
}
__CUDA_DEVICE__ float rpp_tanhf(float x)
{
    float exp = rpp_expf(x+x);
    return rpp_div(exp-1, exp+1);
}
__CUDA_DEVICE__ float rpp_cos(float x)
{
    const float pi = 3.1415927f;

    x = rpp_copysign(1.0f, x);

    uint32_t pi_count = (uint32_t)rpp_div(x, pi);
    x -= (float)pi_count * pi;

    float taylor_series = 1.0f;
    float x2 = x*x;
    for (int i = 14; i > 0; i-=2)
    {
        taylor_series = 1.0f - rpp_div(x2, (float)(i*(i-1))) * taylor_series;
    }

    uint16_t odd_pi = ((pi_count & 1) != 0);
    float neg_taylor_series = -1.0f * taylor_series;
    return rpp_select(taylor_series, neg_taylor_series, odd_pi);
}
__CUDA_DEVICE__ float rpp_sin(float x)
{
    const float pi = 3.1415927f;
    uint32_t is_negative = (*(uint32_t*)&x & 0x80000000);
    x = rpp_abs(x);
    uint32_t pi_count = (uint32_t)rpp_div(x, pi);
    x -= (float)pi_count * pi;

    float taylor_series = 1.0f;
    float x2 = x*x;
    for (int i = 14; i > 0; i-=2)
    {
        taylor_series = x - rpp_div(x2, (float)(i*(i+1))) * taylor_series;
    }
    uint16_t odd_pi = ((pi_count & 1) != 0);
    float neg_taylor_series = -1.0f * taylor_series;
    taylor_series = rpp_select(taylor_series, neg_taylor_series, odd_pi);

    uint16_t neg_input = (is_negative != 0);
    neg_taylor_series = -1.0f * taylor_series;
    return rpp_select(taylor_series, neg_taylor_series, neg_input);
}
// Computes sin(r) on a reduced range using a 15-degree Taylor/Horner polynomial.
// Expected input range: 0 <= r <= pi/2.
__CUDA_DEVICE__ float rpp_sin_poly_precise(float r)
{
    float r2 = r * r;
    float p = 1.0f;

    p = 1.0f - rpp_div(r2 * p, 210.0f); // 14 * 15
    p = 1.0f - rpp_div(r2 * p, 156.0f); // 12 * 13
    p = 1.0f - rpp_div(r2 * p, 110.0f); // 10 * 11
    p = 1.0f - rpp_div(r2 * p, 72.0f);  // 8 * 9
    p = 1.0f - rpp_div(r2 * p, 42.0f);  // 6 * 7
    p = 1.0f - rpp_div(r2 * p, 20.0f);  // 4 * 5
    p = 1.0f - rpp_div(r2 * p, 6.0f);   // 2 * 3

    return r * p;
}

// Computes cos(r) on a reduced range using a 14-degree Taylor/Horner polynomial.
// Expected input range: 0 <= r <= pi/2.
__CUDA_DEVICE__ float rpp_cos_poly_precise(float r)
{
    float r2 = r * r;
    float p = 1.0f;

    p = 1.0f - rpp_div(r2 * p, 182.0f); // 13 * 14
    p = 1.0f - rpp_div(r2 * p, 132.0f); // 11 * 12
    p = 1.0f - rpp_div(r2 * p, 90.0f);  // 9 * 10
    p = 1.0f - rpp_div(r2 * p, 56.0f);  // 7 * 8
    p = 1.0f - rpp_div(r2 * p, 30.0f);  // 5 * 6
    p = 1.0f - rpp_div(r2 * p, 12.0f);  // 3 * 4
    p = 1.0f - rpp_div(r2 * p, 2.0f);   // 1 * 2

    return p;
}

// Computes sin(x) with quadrant range reduction plus short Taylor polynomials.
//
// Compared with rpp_sin(), this version reduces x by pi/2 and then selects
// sin(r) or cos(r) according to the quadrant. The polynomial only needs to work
// on 0 <= r <= pi/2, so it gives better accuracy with a modest cost increase.
__CUDA_DEVICE__ float rpp_sin_precise(float x)
{
    const float half_pi = 1.57079632679489661923f;

    uint32_t is_negative = (*(uint32_t*)&x & 0x80000000u);
    float ax = rpp_abs(x);

    uint32_t quadrant = (uint32_t)rpp_div(ax, half_pi);
    float r = ax - (float)quadrant * half_pi;

    float sin_r = rpp_sin_poly_precise(r);
    float cos_r = rpp_cos_poly_precise(r);

    uint32_t q = quadrant & 3u;
    short use_cos = ((q & 1u) != 0u);
    short flip_sign = ((q & 2u) != 0u);
    short neg_input = (is_negative != 0u);

    float out = rpp_select(sin_r, cos_r, use_cos);
    out = rpp_select(out, -out, flip_sign);
    out = rpp_select(out, -out, neg_input);

    return out;
}
__CUDA_DEVICE__ float rpp_tan(float x)
{
    const float pi = 3.1415927f;
    uint32_t is_negative = (*(uint32_t*)&x & 0x80000000);
    x = rpp_copysign(1.0f, x);
    uint32_t pi_count = (uint32_t)rpp_div(x, pi);
    x -= (float)pi_count * pi;
    float x2 = x*x;

    float sin_taylor_series = 1.0f;
    for (int i = 14; i > 0; i-=2)
    {
        sin_taylor_series = x - rpp_div(x2, (float)(i*(i+1))) * sin_taylor_series;
    }
    uint16_t odd_pi = ((pi_count & 1) != 0);
    float neg_sin_taylor_series = -1.0f * sin_taylor_series;
    sin_taylor_series = rpp_select(sin_taylor_series, neg_sin_taylor_series, odd_pi);
    uint16_t neg_input = (is_negative != 0);
    neg_sin_taylor_series = -1.0f * sin_taylor_series;
    float sin_y = rpp_select(sin_taylor_series, neg_sin_taylor_series, neg_input);

    float cos_taylor_series = 1.0f;
    for (int i = 14; i > 0; i-=2)
    {
        cos_taylor_series = 1.0f - rpp_div(x2, (float)(i*(i-1))) * cos_taylor_series;
    }
    float neg_cos_taylor_series = -1.0f * cos_taylor_series;
    float cos_y = rpp_select(cos_taylor_series, neg_cos_taylor_series, odd_pi);

    return rpp_div(sin_y, cos_y);
}
// https://stackoverflow.com/questions/9799041/efficient-implementation-of-natural-logarithm-ln-and-exponentiation
// Computes the natural (base e) logarithm of arg.
__CUDA_DEVICE__ float rpp_log(float x)
{
	uint16_t invalid_x = (x <= 0);
    // If x in (0, 0.004], change it to 0.004, otherwise will get -inf. For more see above link.
    uint16_t too_small_x = (x < 0.004f);
    too_small_x = (too_small_x & ~invalid_x);
    x = rpp_select(x, 0.004f, too_small_x);
    uint32_t nan = 0xFFFFFFFF;
    float scaling_factor = 256.0f;
    float ln_scaling_factor = 5.545177444f;
    float ln2 = 0.69314718f;

    x *= scaling_factor;
    uint16_t log2 = rpp_msb((uint32_t)x);
    float divisor = (float)(1 << log2);
    float xx = x / divisor;
    float result = -1.7417939f + (2.8212026f + (-1.4699568f + (0.44717955f - 0.056570851f * xx) * xx) * xx) * xx;
    result = result + (float)log2 * ln2 - ln_scaling_factor;

    return rpp_select(result, *(float*)&nan, invalid_x);
}
__CUDA_DEVICE__ float rpp_log_precise(float x)
{
    const float ln2 = 0.69314718055994530942f;
    const float sqrt2 = 1.41421356237309504880f;
    uint32_t nan_bits = 0xFFFFFFFF;
    uint16_t invalid = (x <= 0.0f);

    uint32_t bits = *(uint32_t*)&x;
    int exp = (int)((bits >> 23) & 0xff) - 127;
    bits = (bits & 0x007fffff) | 0x3f800000;
    float m = *(float*)&bits;

    uint16_t m_large = (m > sqrt2);
    m = rpp_select(m, m * 0.5f, m_large);
    float k = (float)exp + rpp_select(0.0f, 1.0f, m_large);

    float t = rpp_div(m - 1.0f, m + 1.0f);
    float t2 = t * t;
    float power = t;
    float sum = t;

    power *= t2; sum += rpp_div(power, 3.0f);
    power *= t2; sum += rpp_div(power, 5.0f);
    power *= t2; sum += rpp_div(power, 7.0f);
    power *= t2; sum += rpp_div(power, 9.0f);
    power *= t2; sum += rpp_div(power, 11.0f);
    power *= t2; sum += rpp_div(power, 13.0f);

    float result = k * ln2 + 2.0f * sum;
    return rpp_select(result, *(float*)&nan_bits, invalid);
}
// Computes atan(t) after range reduction.
// Expected input range: |t| <= tan(pi / 8), about 0.41421356.
// The polynomial is used by rpp_atan2_precise().
__CUDA_DEVICE__ float rpp_atan_poly_minimax(float t)
{
    const float a0  =  3.3333334327e-01f;
    const float a1  = -2.0000000298e-01f;
    const float a2  =  1.4285714924e-01f;
    const float a3  = -1.1111110449e-01f;
    const float a4  =  9.0908870101e-02f;
    const float a5  = -7.6918758452e-02f;
    const float a6  =  6.6610731184e-02f;
    const float a7  = -5.8335702866e-02f;
    const float a8  =  4.9768779427e-02f;
    const float a9  = -3.6531571299e-02f;
    const float a10 =  1.6285820119e-02f;

    float z = t * t;
    float w = z * z;

    float s1 = z * (a0 + w * (a2 + w * (a4 + w * (a6 + w * (a8 + w * a10)))));
    float s2 = w * (a1 + w * (a3 + w * (a5 + w * (a7 + w * a9))));

    return t - t * (s1 + s2);
}
// Computes atan2(y, x) with octant range reduction plus polynomial approximation.
//
// Compared with the old Taylor-only implementation, this method first reduces
// the input into a much smaller interval, then evaluates the polynomial there.
// This gives much better accuracy with far fewer terms.
__CUDA_DEVICE__ float rpp_atan2_precise(float y, float x)
{
    const float pi      = 3.14159265358979323846f;
    const float pi2     = 1.57079632679489661923f;
    const float pi4     = 0.78539816339744830962f;
    const float tan_pi8 = 0.41421356237309504880f;
    const float tiny    = 1.0e-20f;

    float ax = rpp_abs(x);
    float ay = rpp_abs(y);

    float hi = rpp_max(ax, ay);
    float lo = rpp_min(ax, ay);
    hi = rpp_max(hi, tiny);

    float r = rpp_div(lo, hi);

    // If r is still too large, use:
    // atan(r) = pi / 4 + atan((r - 1) / (r + 1))
    short use_pi4 = (r > tan_pi8);

    float t_direct = r;
    float t_pi4 = rpp_div(r - 1.0f, r + 1.0f);
    float t = rpp_select(t_direct, t_pi4, use_pi4);

    float a = rpp_atan_poly_minimax(t);
    a = rpp_select(a, pi4 + a, use_pi4);

    // If |y| > |x|:
    // atan2(|y|, |x|) = pi / 2 - atan(|x| / |y|)
    short y_major = (ay > ax);
    float angle = rpp_select(a, pi2 - a, y_major);

    short x_neg = (x < 0.0f);
    short y_neg = (y < 0.0f);

    float q1 = angle;
    float q2 = pi - angle;
    float q3 = angle - pi;
    float q4 = -angle;

    float out = q1;
    out = rpp_select(out, q2, x_neg & (short)(!y_neg));
    out = rpp_select(out, q3, x_neg & y_neg);
    out = rpp_select(out, q4, (short)(!x_neg) & y_neg);

    return out;
}

__CUDA_DEVICE__ int rpp_floor_to_int_precise(float x)
{
    int i = (int)x;
    short adjust = ((float)i > x);
    return i - (int)adjust;
}

__CUDA_DEVICE__ float rpp_exp2_precise(float x)
{
    uint32_t inf_bits = 0x7f800000u;
    float inf = *(float*)&inf_bits;

    short overflow = (x >= 128.0f);
    short underflow = (x < -149.0f);

    int n = rpp_floor_to_int_precise(x);
    int n_clamped = rpp_min(127, rpp_max(-149, n));
    float r = x - (float)n_clamped;

    const float ln2 = 0.69314718055994530942f;
    float u = r * ln2;

    float p = 2.4801587642e-05f;
    p = 1.9841269841e-04f + u * p;
    p = 1.3888889225e-03f + u * p;
    p = 8.3333337679e-03f + u * p;
    p = 4.1666667908e-02f + u * p;
    p = 1.6666667163e-01f + u * p;
    p = 5.0000000000e-01f + u * p;
    p = 1.0000000000e+00f + u * p;
    p = 1.0000000000e+00f + u * p;

    short normal = (n_clamped >= -126);
    uint32_t normal_scale_bits = (uint32_t)(n_clamped + 127) << 23;
    uint32_t subnormal_scale_bits = (uint32_t)1u << (n_clamped + 149);
    uint32_t scale_bits = rpp_select(subnormal_scale_bits, normal_scale_bits, normal);

    float scale = *(float*)&scale_bits;
    float result = p * scale;
    result = rpp_select(result, inf, overflow);
    result = rpp_select(result, 0.0f, underflow);
    return result;
}

// Computes exp(x) with a 16-term Taylor/Horner expansion.
// This is intended for moderate-size x, such as x = exponent * ln(base)
// in scalar-base pow operators.
__CUDA_DEVICE__ float rpp_expf_precise_taylor16(float x)
{
    float p = 1.0f;

    p = 1.0f + rpp_div(x * p, 16.0f);
    p = 1.0f + rpp_div(x * p, 15.0f);
    p = 1.0f + rpp_div(x * p, 14.0f);
    p = 1.0f + rpp_div(x * p, 13.0f);
    p = 1.0f + rpp_div(x * p, 12.0f);
    p = 1.0f + rpp_div(x * p, 11.0f);
    p = 1.0f + rpp_div(x * p, 10.0f);
    p = 1.0f + rpp_div(x * p, 9.0f);
    p = 1.0f + rpp_div(x * p, 8.0f);
    p = 1.0f + rpp_div(x * p, 7.0f);
    p = 1.0f + rpp_div(x * p, 6.0f);
    p = 1.0f + rpp_div(x * p, 5.0f);
    p = 1.0f + rpp_div(x * p, 4.0f);
    p = 1.0f + rpp_div(x * p, 3.0f);
    p = 1.0f + rpp_div(x * p, 2.0f);
    p = 1.0f + x * p;

    return p;
}

// Computes base^exponent for operators where base is a scalar.
//
// Important:
// - ln_base must be logf(base), computed once on host side.
// - This avoids repeatedly computing log(base) for every matrix element.
// - Formula: base^exponent = exp(exponent * ln(base)).
__CUDA_DEVICE__ float rpp_pow_scalar_base_precision(float exponent, float ln_base)
{
    return rpp_expf_precise_taylor16(exponent * ln_base);
}


__CUDA_DEVICE__ float rpp_pow_precision(float x, float n)
{
    uint32_t nan_bits = 0xffffffffu;
    uint32_t inf_bits = 0x7f800000u;
    float nan = *(float*)&nan_bits;
    float inf = *(float*)&inf_bits;

    int n_int = (int)n;
    short n_is_integer = ((float)n_int == n);
    short negative_x = (x < 0.0f);
    short invalid_negative = negative_x & (short)(!n_is_integer);
    short x_zero = (x == 0.0f);
    short n_zero = (n == 0.0f);
    short x_one = (x == 1.0f);
    short n_negative = (n < 0.0f);
    short nan_input = rpp_isnan(x) | rpp_isnan(n);
    short special = x_zero | n_zero | x_one | nan_input | invalid_negative;

    float ax = rpp_select(x, -x, negative_x);
    ax = rpp_select(ax, 1.0f, special);
    float n_safe = rpp_select(n, 0.0f, special);

    const float inv_ln2 = 1.44269504088896340736f;
    float log2x = rpp_log_precise(ax) * inv_ln2;
    float result = rpp_exp2_precise(n_safe * log2x);

    short odd_n = ((n_int % 2) != 0);
    result = rpp_select(result, -result, negative_x & odd_n);
    result = rpp_select(result, inf, x_zero & n_negative);
    result = rpp_select(result, 0.0f, x_zero & (short)(!n_negative));
    result = rpp_select(result, nan, invalid_negative);
    result = rpp_select(result, nan, nan_input);
    result = rpp_select(result, 1.0f, x_one);
    result = rpp_select(result, 1.0f, n_zero);

    return result;
}

// Optional alias. Use this if you prefer the name "precise".
__CUDA_DEVICE__ float rpp_pow_precise(float x, float n)
{
    return rpp_pow_precision(x, n);
}

// https://stackoverflow.com/questions/2664445/the-most-efficient-way-of-implementing-pow-function-in-floating-point
// y = exp(n*ln(x))
__CUDA_DEVICE__ float rpp_pow(float x, float n)
{
    float result = 0.0f;

    uint16_t negative_x = (x < 0);
    uint16_t odd_n = ((int32_t)n % 2 != 0);
    uint16_t negative_x_odd_n = (negative_x & odd_n);

    uint16_t integer_n = ((int32_t)n - n == 0);
    x = rpp_select(x, rpp_abs(x), integer_n);

    result = rpp_expf(rpp_abs(n) * rpp_log(x));

    uint16_t zero_x = (x == 0);
    result = rpp_select(result, 0.0f, zero_x);

    result = rpp_select(result, 0.0f-result, negative_x_odd_n);

    uint16_t negative_n = (n < 0);
    result = rpp_select(result, rpp_div(1.0f, result), negative_n);

    uint16_t zero_n = (n == 0);
    result = rpp_select(result, 1.0f, zero_n);

    return result;
}
template<typename T0>
__CUDA_DEVICE__ void rpp_print(char *fmt, T0 a)
{
	asm("{ISS_PRINT 0, %0, %1;\n}"
      :: "r"(fmt), "r"(a));
	return ;
}
template<typename T0, typename T1>
__CUDA_DEVICE__ void rpp_print(char *fmt, T0 a, T1 b)
{
	short val = 0;
	asm("{ISS_PRINT 0, %0, %1, %2;\n}"
      :: "r"(fmt), "r"(a), "r"(b));
	return ;
}
template<typename T0, typename T1, typename T2>
__CUDA_DEVICE__ void rpp_print(char *fmt, T0 a, T1 b, T2 c)
{
	asm("{ISS_PRINT 0, %0, %1, %2, %3;\n}"
      ::  "r"(fmt), "r"(a), "r"(b), "r"(c));
	return ;
}

template<typename T0, typename T1, typename T2, typename T3>
__CUDA_DEVICE__ void rpp_print(char *fmt, T0 a, T1 b, T2 c, T3 d)
{
	asm("{ISS_PRINT 0, %0, %1, %2, %3, %4;\n}"
      :: "r"(fmt), "r"(a), "r"(b), "r"(c),"r"(d));
	return ;
}