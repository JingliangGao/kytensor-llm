/*****************************************************************************
 *
 * <COPYRIGHT_TAG>
 *
 *****************************************************************************/
 /*
 *****************************************************************************
 * Doxygen group definitions
 ****************************************************************************/
/*****************************************************************************
 * @file rpp_elf.h
 *
 * @description
 *        This file contains the data structures that are used by
 *        RPP kernel.
 *
 *****************************************************************************/

#ifndef  RPP_ELF_H
#define  RPP_ELF_H

#include <limits.h>
#include "rpp_osal.h"

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#define SH_TEXT ".text."
#define SH_INFO ".rpp.info"
#define SH_INFO_FUNC ".rpp.info."
#define SH_LOG_FMT ".rpp.log.fmt."
#define SH_LOG_AUG ".rpp.log.aug."
#define SH_LOCAL ".rpp.local."
#define SH_SHARED ".rpp.shared."
#define SH_CONST ".rpp.constant"
#define SH_REL ".rel.rpp.constant"
#define SH_RELSPACE ".rpp.constant14"
#define SH_GLOBAL ".rpp.global"
#define SH_GLOBAL_INIT ".rpp.global.init"

#define NV_GLOBAL   0x10

#define Elf_Ehdr Elf64_Ehdr
#define Elf_Shdr Elf64_Shdr
#define Elf_Phdr Elf64_Phdr
#define Elf_Sym     Elf64_Sym

typedef struct section_entry_ {
    uint16_t type;
    uint16_t size;
} section_entry_t;

typedef struct const_entry {
    uint32_t sym_idx;
    uint16_t base;
    uint16_t size;
} const_entry_t;

typedef struct func_entry {
    uint32_t sym_idx;
    uint32_t local_size;
} func_entry_t;

typedef struct param_entry {
    uint16_t idx;
    uint16_t offset;
    uint16_t size;
    uint16_t padding;
} param_entry_t;

typedef struct stack_entry {
    uint16_t size;
    uint16_t unk16;
    uint32_t unk32;
} stack_entry_t;

typedef struct crs_stack_size_entry {
    uint32_t size;
} crs_stack_size_entry_t;

typedef struct symbol_entry {
    uint64_t offset; /* offset in relocation (c14) */
    uint32_t unk32;
    uint32_t sym_idx;
} symbol_entry_t;

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif
