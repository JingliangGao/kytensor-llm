
#pragma once
#include <__clang_cuda_builtin_vars.h>
#include "rpp_smap.h"
#include <rpp_f16.h>
__CUDA_DEVICE__ void rpp_pool_add(float &acc, float accIn, float *addr, uint16_t pitch, uint16_t height, 
	short y, short x, short yInc, short xInc, short yCnt, short xCnt)
{
    uint32_t offset = height * (pitch >> 1);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
	uint16_t stridey = (pitch >> 1);
	uint16_t xIncBytes = xInc * sizeof(short);
	uint16_t yIncBytes = (pitch >> 1) - (xInc * xCnt * sizeof(short));
	asm("{SUM_POOL %0, %1, %2, %3, %4, %5, %6, %7, %8, %9, %10;\n}"
      :"=f"(acc):"r"(addr), "r"(offset), "h"(stridey), "h"(y), "h"(x), 
	  "h"(yIncBytes), "h"(xIncBytes), "h"(yCnt), "h"(xCnt), "r"(accIn));
	//return out;
}
__CUDA_DEVICE__ void rpp_pool_min(float &acc, float accIn, float *addr, uint16_t pitch, uint16_t height, 
	short y, short x, short yInc, short xInc, short yCnt, short xCnt)
{
    uint32_t offset = height * (pitch >> 1);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
	uint16_t stridey = (pitch >> 1);
	uint16_t xIncBytes = xInc * sizeof(short);
	uint16_t yIncBytes = (pitch >> 1) - (xInc * xCnt * sizeof(short));
	asm("{MIN_POOL %0, %1, %2, %3, %4, %5, %6, %7, %8, %9, %10;\n}"
      :"=f"(acc):"r"(addr), "r"(offset), "h"(stridey), "h"(y), "h"(x), 
	  "h"(yIncBytes), "h"(xIncBytes), "h"(yCnt), "h"(xCnt), "r"(accIn));
	//return out;
}
__CUDA_DEVICE__ float rpp_load2d(float *addr, uint32_t pitch, uint16_t height, uint16_t y, uint16_t x)
{
	float out;
    uint32_t offset = height * (pitch >> 1);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
	uint16_t stridey = (pitch >> 1);
	asm("{LOAD_SHA_PITCH.U32 %0, %1, %2, %3, %4, %5;\n}"
      :"=f"(out):"r"(addr), "r"(offset), "h"(stridey), "h"(y), "h"(x));
	return out;
}

__CUDA_DEVICE__ float rpp_load2d_cx(void *addr, uint16_t pitch, uint16_t height, uint16_t y, uint16_t x)
{
	float out;
    uint32_t offset = height * (pitch >> 2);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
	uint16_t stridey = (pitch >> 2);
	asm("{LOAD_SHA_PITCH.U32 %0, %1, %2, %3, %4, %5;\n}"
      :"=f"(out):"r"(addr), "r"(offset), "h"(stridey), "h"(y), "h"(x));
	return out;
}

__CUDA_DEVICE__ float rpp_load2d_cy(void *addr, uint16_t pitch, uint16_t height, uint16_t y, uint16_t x)
{
	float out;
    uint32_t offset = height * (pitch >> 2);
	uint32_t cy_offset = offset * 2;
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
	uint16_t stridey = (pitch >> 2);
	asm("{LOAD_SHA_PITCH.U32 %0, %1, %2, %3, %4, %5;\n}"
      :"=f"(out):"r"((char*)addr + cy_offset), "r"(offset), "h"(stridey), "h"(y), "h"(x));
	return out;
}

__CUDA_DEVICE__ int rpp_load2d(int *addr, uint32_t pitch, uint16_t height, uint16_t y, uint16_t x)
{
	int out;
    uint32_t offset = height * (pitch >> 1);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
	uint16_t stridey = (pitch >> 1);
	asm("{LOAD_SHA_PITCH.U32 %0, %1, %2, %3, %4, %5;\n}"
      :"=r"(out):"r"(addr), "r"(offset), "h"(stridey), "h"(y), "h"(x));
	return out;
}
__CUDA_DEVICE__ uint32_t rpp_load2d(uint32_t *addr, uint32_t pitch, uint16_t height, uint16_t y, uint16_t x)
{
	int out;
    uint32_t offset = height * (pitch >> 1);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
	uint16_t stridey = (pitch >> 1);
	asm("{LOAD_SHA_PITCH.U32 %0, %1, %2, %3, %4, %5;\n}"
      :"=r"(out):"r"(addr), "r"(offset), "h"(stridey), "h"(y), "h"(x));
	return out;
}
__CUDA_DEVICE__ uint16_t rpp_load2d(uint16_t *addr, uint32_t pitch, uint16_t height, uint16_t y, uint16_t x)
{
	uint16_t out;
	uint16_t stridey = (pitch);
	asm("{LOAD_SHA_PITCH.U16 %0, %1, %2, %3, %4, %5;\n}"
      :"=h"(out):"r"(addr), "r"(addr), "h"(stridey), "h"(y), "h"(x));
	return out;
}
__CUDA_DEVICE__ short rpp_load2d(short *addr, uint32_t pitch, uint16_t height, uint16_t y, uint16_t x)
{
	short out;
	uint16_t stridey = (pitch);
	asm("{LOAD_SHA_PITCH.U16 %0, %1, %2, %3, %4, %5;\n}"
      :"=h"(out):"r"(addr), "r"(addr), "h"(stridey), "h"(y), "h"(x));
	return out;
}
__CUDA_DEVICE__ _f16_ rpp_load2d(_f16_ *addr, uint32_t pitch, uint16_t height, uint16_t y, uint16_t x)
{
	_f16_ out;
	uint16_t stridey = (pitch);
	asm("{LOAD_SHA_PITCH.U16 %0, %1, %2, %3, %4, %5;\n}"
      :"=h"(out):"r"(addr), "r"(addr), "h"(stridey), "h"(y), "h"(x));
	return out;
}
__CUDA_DEVICE__ float rpp_load2d_row(float *addr, uint32_t pitch, uint16_t height, uint16_t ridx)
{
	float out;
	int block_offset = (ridx) * (pitch >> 1);
	int offset = height * (pitch >> 1);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
	char *addr_lo = (char*)addr + block_offset;
    char *addr_hi = (char*)addr_lo + offset;
	uint16_t stridey = (0);
	asm("{LOADPITCH %0, %1, %2, %3, %4;\n}"
      :"=f"(out):"r"(addr_lo), "r"(addr_hi), "h"(stridey), "h"(stridey));
	return out;
}
__CUDA_DEVICE__ int rpp_load2d_row(int *addr, uint32_t pitch, uint16_t height, uint16_t ridx)
{
	int out;
	int block_offset = (ridx) * (pitch >> 1);
	int offset = height * (pitch >> 1);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
	char *addr_lo = (char*)addr + block_offset;
    char *addr_hi = (char*)addr_lo + offset;
	uint16_t stridey = (0);
	asm("{LOADPITCH %0, %1, %2, %3, %4;\n}"
      :"=r"(out):"r"(addr_lo), "r"(addr_hi), "h"(stridey), "h"(stridey));
	return out;
}
__CUDA_DEVICE__ uint32_t rpp_load2d_row(uint32_t *addr, uint32_t pitch, uint16_t height, uint16_t ridx)
{
	uint32_t out;
	int block_offset = (ridx) * (pitch >> 1);
	int offset = height * (pitch >> 1);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
	char *addr_lo = (char*)addr + block_offset;
    char *addr_hi = (char*)addr_lo + offset;
	uint16_t stridey = (0);
	asm("{LOADPITCH %0, %1, %2, %3, %4;\n}"
      :"=r"(out):"r"(addr_lo), "r"(addr_hi), "h"(stridey), "h"(stridey));
	return out;
}
__CUDA_DEVICE__ uint16_t rpp_load2d_row(uint16_t *addr, uint32_t pitch, uint16_t height, uint16_t ridx)
{
	uint16_t out;
	int block_offset = (ridx) * (pitch);
	char *addr_lo = (char*)addr + block_offset;
	uint16_t stridey = (pitch >> 1);
	asm("{LOADALN %0, %1, %2, %3;\n}"
	:"=h"(out):"r"(addr_lo), "h"(stridey), "r"(stridey));
	return out;
}
__CUDA_DEVICE__ short rpp_load2d_row(short *addr, uint32_t pitch, uint16_t height, uint16_t ridx)
{
	short out;
	int block_offset = (ridx) * (pitch);
	char *addr_lo = (char*)addr + block_offset;
	uint16_t stridey = (pitch >> 1);
	asm("{LOADALN %0, %1, %2, %3;\n}"
	:"=h"(out):"r"(addr_lo), "h"(stridey), "r"(stridey));
	return out;
}
__CUDA_DEVICE__ float rpp_load2d_col(void *addr, uint32_t pitch, uint16_t height, uint16_t cidx)
{
	float out;
    uint32_t offset = height * (pitch >> 1);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
	uint16_t stridey = (pitch >> 1);
    uint16_t h = threadIdx.y;
	asm("{LOAD_SHA_PITCH.U32 %0, %1, %2, %3, %4, %5;\n}"
      :"=f"(out):"r"(addr), "r"(offset), "h"(stridey), "h"(h), "h"(cidx));
	return out;
}
__CUDA_DEVICE__ float rpp_load2d_fast(float *addr, uint32_t pitch, uint16_t height)
{
	float out;
	int block_offset = (blockIdx.y * blockDim.y) * (pitch >> 1);
	int offset = height * (pitch >> 1);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
	char *addr_lo = (char*)addr + block_offset;
    void *addr_hi = (char*)addr_lo + offset;
	uint16_t stridey = (pitch >> 2);
	asm("{LOADPITCH %0, %1, %2, %3, %4;\n}"
      :"=f"(out):"r"(addr_lo), "r"(addr_hi), "h"(stridey), "h"(stridey));
	return out;
}
__CUDA_DEVICE__ int rpp_load2d_fast(int *addr, uint32_t pitch, uint16_t height)
{
	int out;
	int block_offset = (blockIdx.y * blockDim.y) * (pitch >> 1);
	int offset = height * (pitch >> 1);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
	char *addr_lo = (char*)addr + block_offset;
    char *addr_hi = (char*)addr_lo + offset;
	uint16_t stridey = (pitch >> 2);
	asm("{LOADPITCH %0, %1, %2, %3, %4;\n}"
      :"=r"(out):"r"(addr_lo), "r"(addr_hi), "h"(stridey), "h"(stridey));
	return out;
}
__CUDA_DEVICE__ uint32_t rpp_load2d_fast(uint32_t *addr, uint32_t pitch, uint16_t height)
{
	uint32_t out;
	int block_offset = (blockIdx.y * blockDim.y) * (pitch >> 1);
	int offset = height * (pitch >> 1);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
	char *addr_lo = (char*)addr + block_offset;
    char *addr_hi = (char*)addr_lo + offset;
	uint16_t stridey = (pitch >> 2);
	asm("{LOADPITCH %0, %1, %2, %3, %4;\n}"
      :"=r"(out):"r"(addr_lo), "r"(addr_hi), "h"(stridey), "h"(stridey));
	return out;
}
__CUDA_DEVICE__ uint16_t rpp_load2d_fast(uint16_t *addr, uint32_t pitch, uint16_t height)
{
	uint16_t out;
	int block_offset = (blockIdx.y * blockDim.y) * (pitch);
	char *addr_lo = (char*)addr + block_offset;
	uint16_t stridey = (pitch >> 1);
	asm("{LOADALN %0, %1, %2, %3;\n}"
      :"=h"(out):"r"(addr_lo), "h"(stridey), "r"(stridey));
	return out;
}
__CUDA_DEVICE__ short rpp_load2d_fast(short *addr, uint32_t pitch, uint16_t height)
{
	short out;
	int block_offset = (blockIdx.y * blockDim.y) * (pitch);
	char *addr_lo = (char*)addr + block_offset;
	uint16_t stridey = (pitch >> 1);
	asm("{LOADALN %0, %1, %2, %3;\n}"
      :"=h"(out):"r"(addr_lo), "h"(stridey), "r"(stridey));
	return out;
}
__CUDA_DEVICE__ _f16_ rpp_load2d_fast(_f16_ *addr, uint32_t pitch, uint16_t height)
{
	_f16_ out;
	int block_offset = (blockIdx.y * blockDim.y) * (pitch);
	char *addr_lo = (char*)addr + block_offset;
	uint16_t stridey = (pitch >> 1);
	asm("{LOADALN %0, %1, %2, %3;\n}"
      :"=h"(out):"r"(addr_lo), "h"(stridey), "r"(stridey));
	return out;
}
//load 2d fast with offset
__CUDA_DEVICE__ float rpp_load2d_fast(float *addr, uint32_t pitch, uint16_t height, uint16_t offset_x, uint16_t offset_y)
{
	float out;
	int block_offset = (blockIdx.y * blockDim.y) * (pitch >> 1);
	block_offset += offset_x * 2 + offset_y * (pitch >> 1);
	int offset = height * (pitch >> 1);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
	char *addr_lo = (char*)addr + block_offset;
    void *addr_hi = (char*)addr_lo + offset;
	uint16_t stridey = (pitch >> 2);
	asm("{LOADPITCH %0, %1, %2, %3, %4;\n}"
      :"=f"(out):"r"(addr_lo), "r"(addr_hi), "h"(stridey), "h"(stridey));
	return out;
}
__CUDA_DEVICE__ int rpp_load2d_fast(int *addr, uint32_t pitch, uint16_t height, uint16_t offset_x, uint16_t offset_y)
{
	int out;
	int block_offset = (blockIdx.y * blockDim.y) * (pitch >> 1);
	block_offset += offset_x * 2 + offset_y * (pitch >> 1);
	int offset = height * (pitch >> 1);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
	char *addr_lo = (char*)addr + block_offset;
    void *addr_hi = (char*)addr_lo + offset;
	uint16_t stridey = (pitch >> 2);
	asm("{LOADPITCH %0, %1, %2, %3, %4;\n}"
      :"=r"(out):"r"(addr_lo), "r"(addr_hi), "h"(stridey), "h"(stridey));
	return out;
}
__CUDA_DEVICE__ uint32_t rpp_load2d_fast(uint32_t *addr, uint32_t pitch, uint16_t height, uint16_t offset_x, uint16_t offset_y)
{
	uint32_t out;
	int block_offset = (blockIdx.y * blockDim.y) * (pitch >> 1);
	block_offset += offset_x * 2 + offset_y * (pitch >> 1);
	int offset = height * (pitch >> 1);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
	char *addr_lo = (char*)addr + block_offset;
    void *addr_hi = (char*)addr_lo + offset;
	uint16_t stridey = (pitch >> 2);
	asm("{LOADPITCH %0, %1, %2, %3, %4;\n}"
      :"=r"(out):"r"(addr_lo), "r"(addr_hi), "h"(stridey), "h"(stridey));
	return out;
}
__CUDA_DEVICE__ uint16_t rpp_load2d_fast(uint16_t *addr, uint32_t pitch, uint16_t height, uint16_t offset_x, uint16_t offset_y)
{
	uint16_t out;
	int block_offset = (blockIdx.y * blockDim.y) * (pitch);
	block_offset += offset_x * 2 + offset_y * (pitch);
	char *addr_lo = (char*)addr + block_offset;
	uint16_t stridey = (pitch >> 1);
	asm("{LOADALN %0, %1, %2, %3;\n}"
      :"=h"(out):"r"(addr_lo), "h"(stridey), "r"(stridey));
	return out;
}
__CUDA_DEVICE__ short rpp_load2d_fast(short *addr, uint32_t pitch, uint16_t height, uint16_t offset_x, uint16_t offset_y)
{
	short out;
	int block_offset = (blockIdx.y * blockDim.y) * (pitch);
	block_offset += offset_x * 2 + offset_y * (pitch);
	char *addr_lo = (char*)addr + block_offset;
	uint16_t stridey = (pitch >> 1);
	asm("{LOADALN %0, %1, %2, %3;\n}"
      :"=h"(out):"r"(addr_lo), "h"(stridey), "r"(stridey));
	return out;
}
__CUDA_DEVICE__ _f16_ rpp_load2d_fast(_f16_ *addr, uint32_t pitch, uint16_t height, uint16_t offset_x, uint16_t offset_y)
{
	_f16_ out;
	int block_offset = (blockIdx.y * blockDim.y) * (pitch);
	block_offset += offset_x * 2 + offset_y * (pitch);
	char *addr_lo = (char*)addr + block_offset;
	uint16_t stridey = (pitch >> 1);
	asm("{LOADALN %0, %1, %2, %3;\n}"
      :"=h"(out):"r"(addr_lo), "h"(stridey), "r"(stridey));
	return out;
}
//load 2d fast offset end////
__CUDA_DEVICE__ float rpp_load2d_cx_fast(void *addr, uint16_t pitch, uint16_t height)
{
	float out;
	int block_offset = (blockIdx.y * blockDim.y) * (pitch >> 2);
	addr = (char*)addr + block_offset;
	int offset = height * (pitch >> 2);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
    void *addr_hi = (char*)addr + offset;
	uint16_t stridey = (pitch >> 3);
	asm("{LOADPITCH %0, %1, %2, %3, %4;\n}"
      :"=f"(out):"r"(addr), "r"(addr_hi), "h"(stridey), "h"(stridey));
	return out;
}
__CUDA_DEVICE__ float rpp_load2d_cy_fast(void *addr, uint16_t pitch, uint16_t height)
{
	float out;
	int cy_offset = height * (pitch >> 1);
	int block_offset = (blockIdx.y * blockDim.y) * (pitch >> 2);
	addr = (char*)addr + block_offset + cy_offset;
	int offset = height * (pitch >> 2);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
    void *addr_hi = (char*)addr + offset;
	uint16_t stridey = (pitch >> 3);
	asm("{LOADPITCH %0, %1, %2, %3, %4;\n}"
      :"=f"(out):"r"(addr), "r"(addr_hi), "h"(stridey), "h"(stridey));
	return out;
}


///rpp_store2d_fast begin////
__CUDA_DEVICE__ void rpp_store2d_fast(void *addr, float val, uint32_t pitch, uint16_t height)
{
	int block_offset = (blockIdx.y * blockDim.y) * (pitch >> 1);
	addr = (char*)addr + block_offset;
	int offset = height * (pitch >> 1);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
    void *addr_hi = (char*)addr + offset;
	uint16_t stridey = (pitch >> 2);
	asm("{STOREPITCH %0, %1, %2, %3, %4 ;\n}"
      ::"r"(val), "r"(addr), "r"(addr_hi), "h"(stridey), "h"(stridey));
	return ;
}
__CUDA_DEVICE__ void rpp_store2d_fast(void *addr, int val, uint32_t pitch, uint16_t height)
{
	int block_offset = (blockIdx.y * blockDim.y) * (pitch >> 1);
	int offset = height * (pitch >> 1);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
	addr = (char*)addr + block_offset;
    void *addr_hi = (char*)addr + offset;
	uint16_t stridey = (pitch >> 2);
	asm("{STOREPITCH %0, %1, %2, %3, %4 ;\n}"
      ::"r"(val), "r"(addr), "r"(addr_hi), "h"(stridey), "h"(stridey));
	return ;
}
__CUDA_DEVICE__ void rpp_store2d_fast(void *addr, uint32_t val, uint32_t pitch, uint16_t height)
{
	int block_offset = (blockIdx.y * blockDim.y) * (pitch >> 1);
	int offset = height * (pitch >> 1);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
	addr = (char*)addr + block_offset;
    void *addr_hi = (char*)addr + offset;
	uint16_t stridey = (pitch >> 2);
	asm("{STOREPITCH %0, %1, %2, %3, %4 ;\n}"
      ::"r"(val), "r"(addr), "r"(addr_hi), "h"(stridey), "h"(stridey));
	return ;
}
__CUDA_DEVICE__ void rpp_store2d_fast(void *addr, short val, uint32_t pitch, uint16_t height)
{
	int block_offset = (blockIdx.y * blockDim.y) * (pitch);
	addr = (char*)addr + block_offset;
	uint16_t stridey = (pitch >> 1);
	asm("{STOREALN %0, %1, %2, %3;\n}"
      ::"h"(val), "r"(addr), "h"(stridey), "r"(stridey));
	return ;
}
__CUDA_DEVICE__ void rpp_store_cont(void *addr, short val, uint32_t pitch, uint16_t height)
{
	int block_offset = (blockIdx.y * blockDim.y) * (pitch);
	addr = (char*)addr + block_offset;
	uint16_t stridey = (pitch >> 1);
	asm("{STORECONT %0, %1;\n}"
      ::"h"(val), "r"(addr));
	return ;
}
__CUDA_DEVICE__ void rpp_store2d_fast(void *addr, uint16_t val, uint32_t pitch, uint16_t height)
{
	int block_offset = (blockIdx.y * blockDim.y) * (pitch);
	addr = (char*)addr + block_offset;
	uint16_t stridey = (pitch >> 1);
	asm("{STOREALN %0, %1, %2, %3;\n}"
      ::"h"(val), "r"(addr), "h"(stridey), "r"(stridey));
	return ;
}
__CUDA_DEVICE__ void rpp_store2d_fast(void *addr, _f16_ val, uint32_t pitch, uint16_t height)
{
	int block_offset = (blockIdx.y * blockDim.y) * (pitch);
	addr = (char*)addr + block_offset;
	uint16_t stridey = (pitch >> 1);
	asm("{STOREALN %0, %1, %2, %3;\n}"
      ::"h"(val), "r"(addr), "h"(stridey), "r"(stridey));
	return ;
}
///////rpp_store2d_fast end///////

__CUDA_DEVICE__ void rpp_store1d_fast(void *addr, float val)
{
	int block_offset = blockIdx.x * blockDim.x * sizeof(uint16_t);
	int offset = gridDim.x * blockDim.x * sizeof(uint16_t);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
	addr = (char*)addr + block_offset;
    void *addr_hi = (char*)addr + offset;
	uint16_t stridey = 0;
	asm("{STOREPITCH %0, %1, %2, %3, %4 ;\n}"
      ::"r"(val), "r"(addr), "r"(addr_hi), "h"(stridey), "h"(stridey));
	return ;
}

__CUDA_DEVICE__ void rpp_store2d_cx_fast(void *addr, float val, uint16_t pitch, uint16_t height)
{
	int block_offset = (blockIdx.y * blockDim.y) * (pitch >> 2);
	addr = (char*)addr + block_offset;
	int offset = height * (pitch >> 2);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
    void *addr_hi = (char*)addr + offset;
	uint16_t stridey = (pitch >> 3);
	asm("{STOREPITCH %0, %1, %2, %3, %4 ;\n}"
      ::"r"(val), "r"(addr), "r"(addr_hi), "h"(stridey), "h"(stridey));
	return ;
}
__CUDA_DEVICE__ void rpp_store2d_cy_fast(void *addr, float val, uint16_t pitch, uint16_t height)
{
	int block_offset = (blockIdx.y * blockDim.y) * (pitch >> 2);
	int cy_offset = height * (pitch >> 1);
	addr = (char*)addr + block_offset + cy_offset;
	int offset = height * (pitch >> 2);
#ifdef DMA_REFORMAT
	offset = ((offset + 4095) >> 12) * 4096;
#endif
    void *addr_hi = (char*)addr + offset;
	uint16_t stridey = (pitch >> 3);
	asm("{STOREPITCH %0, %1, %2, %3, %4 ;\n}"
      ::"r"(val), "r"(addr), "r"(addr_hi), "h"(stridey), "h"(stridey));
	return ;
}

static void rppBlock2d(dim3 &threads, dim3 &blocks, int w, int h, int max_block_size = MAX_BLOCK_SIZE)
{
    if (w < 32) w = 32;
    assert(w < max_block_size);
    int h0 = h;
    while(w*h0 >= max_block_size)
    {
        if(h0 & 0x1)
           break;
        h0 = h0 >> 1;
    }
    //make sure there is no tail block
    if(w*h0 >= max_block_size)
        h0 = 1;

    threads.x = w;
    threads.y = h0;
    threads.z = 1;

    blocks.x = 1;
    blocks.y = h/h0;
    blocks.z = 1;

    assert(h == threads.y * blocks.y);
    assert(w == threads.x * blocks.x);
}
__global__ void SetSram_Kernel(float *out, float value, uint32_t pitch,  uint16_t h)
{
    rpp_store2d_fast(out, value, pitch, h);
}
void rppSetSram(float *out, float value, uint32_t pitch,  uint16_t w, uint16_t h, RPPstream stream = 0)
{
    dim3 threads; dim3 blocks;
	rppBlock2d(threads, blocks, w, h);
	SetSram_Kernel<<<blocks, threads, 0, stream>>>(out, 0, pitch, h);
}

__global__ void CopySram_Kernel(float *out, float *input, uint32_t oPitch, uint16_t iPitch, uint16_t h)
{
    float value = rpp_load2d_fast(input, iPitch, h);
    rpp_store2d_fast(out, value, oPitch, h);
}
void rppCopySram(float *out, float *input, uint32_t oPitch, uint32_t iPitch, uint16_t w, uint16_t h, RPPstream stream = 0)
{
    dim3 threads; dim3 blocks;
	rppBlock2d(threads, blocks, w, h);
	CopySram_Kernel<<<blocks, threads, 0, stream>>>(out, input, oPitch, iPitch, h);
}