#ifndef __VERSION_H_
#define __VERSION_H_

#define _STR(x) _VAL(x)  // 第一级传递参数
#define _VAL(x) #x       // 第二级字符串化

#define DRV_API_VERSION_NUMBER  \
	((DRV_API_MAJOR)*0x1000000 + (DRV_API_MINOR)*0x10000 + (DRV_API_PATCH)*0x100 + DRV_API_BUILD)

#define DRV_API_VERSION_STR "v" \
	_STR(DRV_API_MAJOR) "." \
	_STR(DRV_API_MINOR) "." \
	_STR(DRV_API_PATCH) "." \
	_STR(DRV_API_BUILD)

#endif // __NVTOP_VERSION_H_
