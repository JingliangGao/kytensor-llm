#ifndef __RPP_DRV_API_H__
#define __RPP_DRV_API_H__

#include <stddef.h>

#include "rpp_com.h"
#include "drvapi_error_string.h"

//!
//! \mainpage
//!
//! This is the API documentation for the AzurEngine RPP Driver API library. It provides information on individual
//! functions, structs and defines. Use the index on the left to navigate the documentation.
//!
//
//!

//!
//! \file rpp_drv_api.h
//!
//! This is the top-level API file for rpp driver api.
//!

#ifdef __cplusplus
extern "C"
{
#endif /* __cplusplus */

#if defined(WIN32) || defined(_WIN32) || defined(WIN64) || defined(_WIN64)
#define RPP_CB
#else
#define RPP_CB
#endif

#define RPP_GLOBAL_ADDR (0x1000000000)

    typedef unsigned long long RPPdeviceptr;
    typedef uint64_t RPPdevice;                                 /**< RPP device */
    typedef struct RPPctx_st *RPPcontext;                       /**< RPP context */
    typedef struct RPPmodule_st *RPPmodule;                     /**< RPP module */
    typedef struct RPPfunction_st *RPPfunction;                 /**< RPP function */
    typedef struct RPParray_st *RPParray;                       /**< RPP array */
    typedef struct RPPevent_st *RPPevent;                       /**< RPP event */
    typedef struct RPPstream_st *RPPstream;                     /**< RPP stream */
    typedef struct RPPgraphicsResource_st *RPPgraphicsResource; /**< RPP graphics interop resource */
    typedef struct RPPuuid_st *RPPuuid;
    typedef struct RPPgraph_st *RPPgraph;
    typedef struct RPPgraphExec_st *RPPgraphExec;
    typedef struct RPPgraphNode_st *RPPgraphNode;
    typedef struct RPPexternalMemory_st *RPPexternalMemory;
    typedef void(RPP_CB *RPPhostFn)(void *); /**< RPP callback function */

#define __constant__ __attribute__((constant))
#define __device__ __attribute__((device))
#define __global__ __attribute__((global))
#define __host__ __attribute__((host))
#define __shared__ __attribute__((shared))
#define __launch_bounds__(...) __attribute__((launch_bounds(__VA_ARGS__)))

    /**
     * Context creation flags
     */
    typedef enum RPPctx_flags_enum
    {
        RPP_CTX_SCHED_AUTO = 0x00, /**< Automatic scheduling */
        RPP_CTX_SCHED_SLEEP = 0x01, /**< Set sleep as default scheduling */
        RPP_CTX_SCHED_YIELD = 0x02, /**< Set yield as default scheduling */
    } RPPctx_flags;

    /**
     * Stream creation flags
     */
    typedef enum RPPstream_flags_enum
    {
        RPP_STREAM_DEFAULT = 0x00, /**< Default stream creation flag */
    } RPPstream_flags;

    // #define RPP_API_PER_THREAD_DEFAULT_STREAM

    /**
     * Shared memory configurations
     */
    typedef enum RPPsharedconfig_enum
    {
        RPP_SHARED_MEM_CONFIG_DEFAULT_BANK_SIZE = 0x00, /**< set default shared memory bank size */
    } RPPsharedconfig;

    /**
     * Memory types
     */
    typedef enum RPPmemorytype_enum
    {
        RPP_MEMORYTYPE_HOST = 0x01,              /**< Host DMA memory */
        RPP_MEMORYTYPE_DEVICE = 0x02,            /**< Device DDR memory */
        RPP_MEMORYTYPE_ARRAY = 0x03,             /**< Array object memory */
        RPP_MEMORYTYPE_UNIFIED = 0x04,           /**< Unified host/device memory */
        RPP_MEMORYTYPE_SRAM = 0x05,              /**< Device SRAM memory */
        RPP_MEMORYTYPE_MPUMEM = 0x06,            /**< Compatible MPU memory type (MPU0/MPU1/VE lookup) */
        RPP_MEMORYTYPE_MPU1_SRAM = 0x07,         /**< MPU1 SRAM memory */
        RPP_MEMORYTYPE_VE_MEM = 0x08,            /**< VE memory */
        RPP_MEMORYTYPE_DESC = 0x09,              /**< Generic descriptor memory */
        RPP_MEMORYTYPE_VIRT_SRAM = 0x0a,         /**< Virtual SRAM memory */
        RPP_MEMORYTYPE_DMA_HUGETLB = 0x0b,       /**< Host DMA memory backed by huge pages */
        RPP_MEMORYTYPE_VIRT_VE_MEM = 0x0c,       /**< Virtual VE memory */
        RPP_MEMORYTYPE_VIRT_KPARA = 0x0d,        /**< Virtual kernel-parameter memory */
        RPP_MEMORYTYPE_VIRT_FIXED_KQUEUE = 0x0e, /**< Virtual fixed KQUEUE memory */
        RPP_MEMORYTYPE_DYNAMIC_KQUEUE = 0x0f,    /**< Dynamic KQUEUE memory */
        RPP_MEMORYTYPE_PCIE_DESC = 0x10,         /**< PCIe descriptor memory */
        RPP_MEMORYTYPE_GRAPH_KPARA = 0x11,       /**< Graph kernel-parameter memory */
        RPP_MEMORYTYPE_GRAPH_DESC = 0x12         /**< Graph descriptor memory */
    } RPPmemorytype;

    /**
     * MPU SRAM Allocation flags
     */
    typedef enum RPPmpumem_flags_enum
    {
        RPP_MPUMEM_REGION_0 = 0x0, /**< MPU0 mem region */
        RPP_MPUMEM_REGION_1 = 0x1, /**< MPU1 mem region */
        RPP_MPUMEM_REGION_2 = 0x2, /**< MPU2 mem region */
    } RPPmpumem_flags;

    /**
     * memcpy types.
     */
    typedef enum RPPmemcpytype_enum
    {
        RPP_MEMCPYTYPE_H2H = 1,
        RPP_MEMCPYTYPE_H2D = 2,
        RPP_MEMCPYTYPE_D2H = 3,
        RPP_MEMCPYTYPE_D2D = 4,
        RPP_MEMCPYTYPE_D2S = 5,
        RPP_MEMCPYTYPE_S2D = 6,
        RPP_MEMCPYTYPE_S2S = 7,
        RPP_MEMCPYTYPE_H2M = 8,
        RPP_MEMCPYTYPE_M2H = 9,
        RPP_MEMCPYTYPE_H2S = 10,
        RPP_MEMCPYTYPE_S2H = 11,
        RPP_MEMCPYTYPE_MAX,
    } RPPmemcpytype;

    /**
     * Event creation flags
     */
    typedef enum RPPevent_flags_enum
    {
        RPP_EVENT_DEFAULT = 0x0,       /**< Default event flag */
        RPP_EVENT_ENABLE_TIMING = 0x2, /**< Event will record timing data */
    } RPPevent_flags;

    /**
     * Semaphore types
     */
    typedef enum RPPsemtype_enum
    {
        RPP_SEM_CORE = (0x1 << 0),
        RPP_SEM_SRAM = (0x1 << 1),
        RPP_SEM_PCIE_DMA = (0x1 << 2), /* legacy; prefer PDMA_H2D / PDMA_D2H */
        RPP_SEM_USER0 = (0x1 << 3),
        RPP_SEM_USER1 = (0x1 << 4),
        RPP_SEM_USER2 = (0x1 << 5),
        RPP_SEM_USER3 = (0x1 << 6),
        RPP_SEM_MPU_MSG = (0x1 << 7),
        RPP_SEM_PDMA_H2D = (0x1 << 8), /* PCIe DMA Read engine (H2D) */
        RPP_SEM_PDMA_D2H = (0x1 << 9), /* PCIe DMA Write engine (D2H) */
        RPP_SEM_CORE_DMA = (0x1 << 11),
    } RPPsemtype;

    /**
     * Reg types
     */
    typedef enum RPPRegRegion_enum
    {
        RPP_REG_DEVDDR = 0,
        RPP_REG_DEVCFG,
        RPP_REG_DEVMPU,
        RPP_REG_REGION_MAX,
    } RPPRegRegion;

    /**
     * GPU kernel node parameters
     */
    typedef struct RPP_KERNEL_NODE_PARAMS_st
    {
        RPPfunction func;                /**< Kernel to launch */
        unsigned int gridDimX;           /**< Width of grid in blocks */
        unsigned int gridDimY;           /**< Height of grid in blocks */
        unsigned int gridDimZ;           /**< Depth of grid in blocks */
        unsigned int blockDimX;          /**< X dimension of each thread block */
        unsigned int blockDimY;          /**< Y dimension of each thread block */
        unsigned int blockDimZ;          /**< Z dimension of each thread block */
        unsigned int sharedMemBytes;     /**< Dynamic shared-memory size per thread block in bytes */
        unsigned char kernelParams[256]; // total 256 bytes;
        unsigned short extra[8];         // total 8 bytes;
    } RPP_KERNEL_NODE_PARAMS;

    /**
     * Memset node parameters
     */
    typedef struct RPP_MEMSET_NODE_PARAMS_st
    {
        RPPdeviceptr dst;         /**< Destination device pointer */
        size_t pitch;             /**< Pitch of destination device pointer. Unused if height is 1 */
        unsigned int value;       /**< Value to be set */
        unsigned int elementSize; /**< Size of each element in bytes. Must be 1, 2, or 4. */
        size_t width;             /**< Width in bytes, of the row */
        size_t height;            /**< Number of rows */
    } RPP_MEMSET_NODE_PARAMS;

    /**
     * Host node parameters
     */
    typedef struct RPP_HOST_NODE_PARAMS_st
    {
        RPPhostFn fn;   /**< The function to call when the node executes */
        void *userData; /**< Argument to pass to the function */
    } RPP_HOST_NODE_PARAMS;

    /**
     * Graph node types.
     *
     * Application-visible nodes are typically created via ::rppGraphAdd*Node or stream capture.
     * Internal types (for example ::RPP_GRAPH_NODE_TYPE_SET_PARAMS) are inserted during
     * instantiate or async parameter update and become scheduler descriptors at instantiate time.
     */
    typedef enum RPPgraphNodeType_enum
    {
        RPP_GRAPH_NODE_TYPE_KERNEL = 0,           /**< Device kernel compute node */
        RPP_GRAPH_NODE_TYPE_MEMCPY = 1,           /**< CDMA memcpy node (D2D, DtoS, S2D, S2S, etc.) */
        RPP_GRAPH_NODE_TYPE_MEMSET = 2,           /**< Device memset node */
        RPP_GRAPH_NODE_TYPE_HOST = 3,             /**< Host callback node */
        RPP_GRAPH_NODE_TYPE_GRAPH = 4,            /**< Embedded child-graph node */
        RPP_GRAPH_NODE_TYPE_EMPTY = 5,            /**< Empty (no-op) dependency placeholder */
        RPP_GRAPH_NODE_TYPE_WAIT_EVENT = 6,       /**< Wait on graph or common event */
        RPP_GRAPH_NODE_TYPE_EVENT_RECORD = 7,     /**< Record graph or common event */
        RPP_GRAPH_NODE_TYPE_EXT_SEMAS_SIGNAL = 8, /**< External semaphore signal node */
        RPP_GRAPH_NODE_TYPE_EXT_SEMAS_WAIT = 9,   /**< External semaphore wait node */
        RPP_GRAPH_NODE_TYPE_MEM_ALLOC = 10,       /**< In-graph device memory allocation (if enabled) */
        RPP_GRAPH_NODE_TYPE_MEM_FREE = 11,        /**< In-graph device memory free (if enabled) */
        RPP_GRAPH_NODE_TYPE_SET_PARAMS = 12,      /**< Async node-parameter update (often runtime-generated) */
        RPP_GRAPH_NODE_TYPE_EVENT_RESET = 13,     /**< Reset graph event after launch */
        RPP_GRAPH_NODE_TYPE_SET_FREQ = 14,        /**< Fixed DFS frequency set (often from capture) */
        RPP_GRAPH_NODE_TYPE_GLIST = 15,           /**< Execlist submission wrapper */
        RPP_GRAPH_NODE_TYPE_MPU_MSG = 16,         /**< MPU message node (not generic SetParams) */
        RPP_GRAPH_NODE_TYPE_GRAPH_FLOW_CONTROL = 17, /**< Graph launch control (head/tail, virt handshake) */
        RPP_GRAPH_NODE_TYPE_MEMCPY_INDIRECT_UPDATE = 18, /**< Runtime indirect memcpy descriptor update */
    } RPPgraphNodeType;

    /**
     * GraphExec update result detail.
     * Compatible in meaning with CUDA Driver's CUgraphExecUpdateResult.
     */
    typedef enum RPPgraphExecUpdateResult_enum
    {
        RPP_GRAPH_EXEC_UPDATE_SUCCESS = 0x0,
        RPP_GRAPH_EXEC_UPDATE_ERROR = 0x1,
        RPP_GRAPH_EXEC_UPDATE_ERROR_TOPOLOGY_CHANGED = 0x2,
        RPP_GRAPH_EXEC_UPDATE_ERROR_NODE_TYPE_CHANGED = 0x3,
        RPP_GRAPH_EXEC_UPDATE_ERROR_FUNCTION_CHANGED = 0x4,
        RPP_GRAPH_EXEC_UPDATE_ERROR_PARAMETERS_CHANGED = 0x5,
        RPP_GRAPH_EXEC_UPDATE_ERROR_NOT_SUPPORTED = 0x6,
        RPP_GRAPH_EXEC_UPDATE_ERROR_UNSUPPORTED_FUNCTION_CHANGE = 0x7,
        RPP_GRAPH_EXEC_UPDATE_ERROR_ATTRIBUTES_CHANGED = 0x8,
    } RPP_GRAPH_EXEC_UPDATE_RESULT;

    /**
     * Detailed update information returned by ::rppGraphExecUpdate.
     */
    typedef struct RPP_GRAPH_EXEC_UPDATE_RESULT_INFO_st
    {
        RPPgraphNode errorFromNode; /**< "from" node when a dependency edge mismatch is detected */
        RPPgraphNode errorNode;     /**< node associated with update failure */
        RPP_GRAPH_EXEC_UPDATE_RESULT result; /**< detailed update status */
    } RPP_GRAPH_EXEC_UPDATE_RESULT_INFO;

    /**
     * Parameters for replacing one child-graph binding on an existing child wrapper node.
     */
    typedef struct RPP_CHILD_GRAPH_REPLACE_PARAMS_st
    {
        RPPgraph oldChildGraph;     /**< optional expected old child graph; NULL means skip exact-match check */
        RPPgraph newChildGraph;     /**< replacement child graph */
        uint32_t flags;             /**< reserved, must be 0 */
    } RPP_CHILD_GRAPH_REPLACE_PARAMS;

    /**
     * Parameters for replacing the child graphexec bound to one child-graph wrapper on a single instantiated main graphexec.
     */
    typedef struct RPP_CHILD_GRAPHEXEC_REPLACE_PARAMS_st
    {
        RPPgraphExec newChildGraphExec; /**< replacement child graphexec; caller retains ownership (see ::rppGraphExecUpdateChildGraphExec) */
        uint32_t flags;                 /**< reserved, must be 0 */
    } RPP_CHILD_GRAPHEXEC_REPLACE_PARAMS;

#define RPP_DYNAMIC_SELECT_GRAPH_NODE_UPDATE_MAX_CASES 2

#define RPP_MPU_NODE_FLAG_WAIT_COMPLETE 0x1U /**< Wait for private MPU completion event before the node completes */

    /**
     * MPU graph node parameters.
     *
     * The payload words are copied verbatim to the MPU message descriptor.
     */
    typedef struct RPP_DYNAMIC_SELECT_GRAPH_NODE_PARAMS_st
    {
        uint32_t type;       /**< MPU message type */
        uint32_t payload[6]; /**< MPU message payload words copied into the descriptor */
        uint32_t flags;      /**< Bitmask of RPP_MPU_NODE_FLAG_*; currently 0 or ::RPP_MPU_NODE_FLAG_WAIT_COMPLETE */
        uint32_t reserved0;  /**< Reserved for future use; must be 0 */
    } RPP_DYNAMIC_SELECT_GRAPH_NODE_PARAMS;

    /**
     * One ACTION_TABLE branch case for ::rppGraphExecDynamicSelectGraphNodeSetParams.
     *
     * If childGraphExec is non-NULL, the case uses that executable graph's queue range.
     * Otherwise childGraph must be non-NULL and resolvable from one child-graph wrapper under
     * mainGraphExec.
     */
    typedef struct RPP_DYNAMIC_SELECT_GRAPH_NODE_UPDATE_CASE_st
    {
        uint32_t indexValue;        /**< selector value for this row; version 1 supports 0 and 1 */
        RPPgraph childGraph;        /**< child graph to resolve from mainGraphExec when childGraphExec is NULL */
        RPPgraphExec childGraphExec; /**< explicit graphexec for this row; optional */
    } RPP_DYNAMIC_SELECT_GRAPH_NODE_UPDATE_CASE;

    /**
     * Parameters for updating a generic MPU node with a dynamic branch ACTION_TABLE request.
     */
    typedef struct RPP_DYNAMIC_SELECT_GRAPH_NODE_UPDATE_PARAMS_st
    {
        RPPdeviceptr indexAddr; /**< device pointer to the runtime uint32_t selector value */
        uint32_t caseCount; /**< number of valid cases; version 1 requires 2 */
        RPP_DYNAMIC_SELECT_GRAPH_NODE_UPDATE_CASE
            cases[RPP_DYNAMIC_SELECT_GRAPH_NODE_UPDATE_MAX_CASES]; /**< selector cases */
        uint32_t flags; /**< reserved, must be 0 */
    } RPP_DYNAMIC_SELECT_GRAPH_NODE_UPDATE_PARAMS;

    /**
     * Structure version for ::RPP_GRAPH_EXEC_FINALIZE_PARAMS.
     * Must be set to this value in \p version; future fields may be appended.
     */
    #define RPP_GRAPH_EXEC_FINALIZE_PARAMS_VERSION 1

    /**
     * Parameters for ::rppGraphExecFinalize (Step 3 graphexec finalization).
     *
     * Forward compatibility: set \p version to ::RPP_GRAPH_EXEC_FINALIZE_PARAMS_VERSION
     * and \p structSize to \c sizeof(RPP_GRAPH_EXEC_FINALIZE_PARAMS). The driver reads
     * only fields covered by the caller's \p structSize. \p flags and \p reserved must be 0
     * in the current version (no per-field finalize toggles).
     */
    typedef struct RPP_GRAPH_EXEC_FINALIZE_PARAMS_st
    {
        size_t structSize; /**< Input: sizeof(*this); must be >= size of known layout for \p version */
        uint32_t version;  /**< Input: ::RPP_GRAPH_EXEC_FINALIZE_PARAMS_VERSION */
        uint32_t flags;    /**< Reserved, must be 0 */
        uint64_t reserved[8]; /**< Reserved, must be 0 */
    } RPP_GRAPH_EXEC_FINALIZE_PARAMS;

    /**
     * Graph creation flags
     */
    typedef enum RPPgraph_flags_enum
    {
        RPP_GRAPH_DEFAULT = 0x0,      /**< Blocking graph: graph-level head/tail sem serializes SRAM during launch */
        RPP_GRAPH_NON_BLOCKING = 0x1, /**< Per-node sem wait/post; allows other streams to run memcpy/kernel in parallel with graph execution */
    } RPPgraph_flags;

    /**
     * Possible stream capture statuses returned by ::rppStreamIsCapturing
     */
    typedef enum RPPstreamCaptureStatus_enum
    {
        RPP_STREAM_CAPTURE_STATUS_NONE = 0,       /**< Stream is not capturing */
        RPP_STREAM_CAPTURE_STATUS_ACTIVE = 1,     /**< Stream is actively capturing */
        RPP_STREAM_CAPTURE_STATUS_INVALIDATED = 2 /**< Stream is part of a capture sequence that
                                                      has been invalidated, but not terminated */
    } RPPstreamCaptureStatus;

    /**
     * Possible modes for stream capture thread interactions. For more details see
     * ::rppStreamBeginCapture and ::cuThreadExchangeStreamCaptureMode
     */
    typedef enum RPPstreamCaptureMode_enum
    {
        RPP_STREAM_CAPTURE_MODE_GLOBAL = 0,
        RPP_STREAM_CAPTURE_MODE_THREAD_LOCAL = 1,
        RPP_STREAM_CAPTURE_MODE_RELAXED = 2
    } RPPstreamCaptureMode;

    /**
     * Array formats
     */
    typedef enum RPParray_format_enum
    {
        RPP_AD_FORMAT_UNSIGNED_INT8 = 0x01,  /**< Unsigned 8-bit integers */
        RPP_AD_FORMAT_UNSIGNED_INT16 = 0x02, /**< Unsigned 16-bit integers */
        RPP_AD_FORMAT_UNSIGNED_INT32 = 0x03, /**< Unsigned 32-bit integers */
        RPP_AD_FORMAT_SIGNED_INT8 = 0x08,    /**< Signed 8-bit integers */
        RPP_AD_FORMAT_SIGNED_INT16 = 0x09,   /**< Signed 16-bit integers */
        RPP_AD_FORMAT_SIGNED_INT32 = 0x0a,   /**< Signed 32-bit integers */
        RPP_AD_FORMAT_HALF = 0x10,           /**< 16-bit floating point */
        RPP_AD_FORMAT_FLOAT = 0x20           /**< 32-bit floating point */
    } RPParray_format;

    /**
     * Graph execution resource pool type (used with ::RPP_GRAPH_INSTANTIATE_PARAMS).
     */
    typedef enum RPPgraphResource_type_enum
    {
        RPP_GRAPH_RESOURCE_PCIE_DESC = 0, /**< PCIe descriptor pool */
        RPP_GRAPH_RESOURCE_CDMA_DESC = 1, /**< CDMA descriptor pool */
        RPP_GRAPH_RESOURCE_KPARA = 2,     /**< Kernel-parameter pool */
        RPP_GRAPH_RESOURCE_SCHE_DESC = 3, /**< Scheduler descriptor pool (critical for large graphs) */
    } RPPgraphResource_type_e;

    /**
     * One resource pool entry for ::rppGraphInstantiateWithParams.
     *
     * When \p is_external is false, the driver allocates and frees the pool for the graphexec.
     * When true, the caller supplies \p daddr and \p size (for example via ::rppGraphResourceAlloc)
     * and must free external pools after the graphexec is destroyed.
     */
    typedef struct RPPgraphResource_st
    {
        bool is_external; /**< false: driver-owned pool; true: caller-owned pool at \p daddr */
        RPPgraphResource_type_e type;
        RPPdeviceptr daddr;
        size_t size;
    } RPPgraphResource;

    /**
     * 3D array descriptor
     */
    typedef struct RPP_ARRAY3D_DESCRIPTOR_st
    {
        size_t Depth;
        unsigned int Flags;
        RPParray_format Format;
        size_t Height;
        unsigned int NumChannels;
        size_t Width;
    } RPP_ARRAY3D_DESCRIPTOR;

    /**
     * Array descriptor
     */
    typedef struct RPP_ARRAY_DESCRIPTOR_st
    {
        RPParray_format Format;
        size_t Height;
        unsigned int NumChannels;
        size_t Width;
    } RPP_ARRAY_DESCRIPTOR;

    /**
     * Texture reference addressing modes
     */
    typedef enum RPPaddress_mode_enum
    {
        RPP_TR_ADDRESS_MODE_WRAP = 0,   /**< Wrapping address mode */
        RPP_TR_ADDRESS_MODE_CLAMP = 1,  /**< Clamp to edge address mode */
        RPP_TR_ADDRESS_MODE_MIRROR = 2, /**< Mirror address mode */
        RPP_TR_ADDRESS_MODE_BORDER = 3  /**< Border address mode */
    } RPPaddress_mode;

    /**
     * Texture reference filtering modes
     */
    typedef enum RPPfilter_mode_enum
    {
        RPP_TR_FILTER_MODE_POINT = 0, /**< Point filter mode */
        RPP_TR_FILTER_MODE_LINEAR = 1 /**< Linear filter mode */
    } RPPfilter_mode;

    /**
     * Device properties
     */
    typedef enum RPPdevice_attribute_enum
    {
        RPP_DEVICE_ATTRIBUTE_MAX_THREADS_PER_BLOCK = 1,                 /**< Maximum number of threads per block */
        RPP_DEVICE_ATTRIBUTE_MAX_BLOCK_DIM_X = 2,                       /**< Maximum block dimension X */
        RPP_DEVICE_ATTRIBUTE_MAX_BLOCK_DIM_Y = 3,                       /**< Maximum block dimension Y */
        RPP_DEVICE_ATTRIBUTE_MAX_BLOCK_DIM_Z = 4,                       /**< Maximum block dimension Z */
        RPP_DEVICE_ATTRIBUTE_MAX_GRID_DIM_X = 5,                        /**< Maximum grid dimension X */
        RPP_DEVICE_ATTRIBUTE_MAX_GRID_DIM_Y = 6,                        /**< Maximum grid dimension Y */
        RPP_DEVICE_ATTRIBUTE_MAX_GRID_DIM_Z = 7,                        /**< Maximum grid dimension Z */
        RPP_DEVICE_ATTRIBUTE_MAX_SHARED_MEMORY_PER_BLOCK = 8,           /**< Maximum shared memory available per block in bytes */
        RPP_DEVICE_ATTRIBUTE_WARP_SIZE = 10,                            /**< Warp size in threads */
        RPP_DEVICE_ATTRIBUTE_CLOCK_RATE = 13,                           /**< Peak clock frequency in kilohertz */
        RPP_DEVICE_ATTRIBUTE_MULTIPROCESSOR_COUNT = 16,                 /**< Number of multiprocessors on device */
        RPP_DEVICE_ATTRIBUTE_COMPUTE_MODE = 20,                         /**< Compute mode (See ::RPPcomputemode for details) */
        RPP_DEVICE_ATTRIBUTE_CONCURRENT_KERNELS = 31,                   /**< Device can possibly execute multiple kernels concurrently */
        RPP_DEVICE_ATTRIBUTE_PCI_BUS_ID = 33,                           /**< PCI bus ID of the device */
        RPP_DEVICE_ATTRIBUTE_PCI_DEVICE_ID = 34,                        /**< PCI device ID of the device */
        RPP_DEVICE_ATTRIBUTE_GLOBAL_MEMORY_BUS_WIDTH = 37,              /**< Global memory bus width in bits */
        RPP_DEVICE_ATTRIBUTE_MAX_THREADS_PER_MULTIPROCESSOR = 39,       /**< Maximum resident threads per multiprocessor */
        RPP_DEVICE_ATTRIBUTE_PCI_DOMAIN_ID = 50,                        /**< PCI domain ID of the device */
        RPP_DEVICE_ATTRIBUTE_RPP_VERSION = 60,                          /**< RPP version */
        RPP_DEVICE_ATTRIBUTE_DDR_NUM = 61,                              /**< DDR number */
        RPP_DEVICE_ATTRIBUTE_DDR_CLOCK0_RATE = 62,                      /**< DDR clock0 frequency */
        RPP_DEVICE_ATTRIBUTE_DDR_CLOCK1_RATE = 63,                      /**< DDR clock1 frequency */
        RPP_DEVICE_ATTRIBUTE_PCIE_STATUS = 64,                          /**< PCIe link status */
        RPP_DEVICE_ATTRIBUTE_STREAM_PRIORITIES_SUPPORTED = 78,          /**< Device supports stream priorities */
        RPP_DEVICE_ATTRIBUTE_LOCAL_L1_CACHE_SUPPORTED = 80,             /**< Device supports caching locals in L1 */
        RPP_DEVICE_ATTRIBUTE_MAX_SHARED_MEMORY_PER_MULTIPROCESSOR = 81, /**< Maximum shared memory available per multiprocessor in bytes */
        RPP_DEVICE_ATTRIBUTE_MAX_REGISTERS_PER_MULTIPROCESSOR = 82,     /**< Maximum number of 32-bit registers available per multiprocessor */
        RPP_DEVICE_ATTRIBUTE_SCHE_CLOCK_RATE = 83,                      /**< Peak clock frequency of Scheduler in kilohertz */
        RPP_DEVICE_ATTRIBUTE_MAX
    } RPPdevice_attribute;


    /**
     * Device Power Mode
     */
    typedef enum RPPPwrMode_enum
    {
        RPP_DEVICE_PWRMODE_WORKING = 0,                 /**< Working mode */
        RPP_DEVICE_PWRMODE_LOW_POWER = 1,               /**< Lower power mode, RPP MPU is working, but RPP core is sleeping */
        RPP_DEVICE_PWRMODE_STANDBY = 2,                 /**< Standby mode, RPP MPU/Core all sleeping, OS/Bus driver/ACPI driver need support RTD3 */
        RPP_DEVICE_PWRMODE_RESUME = 3,                  /**< Resume frome standby mode, OS/Bus driver/ACPI driver need support RTD3  */
        RPP_DEVICE_PWRMODE_MAX
    } RPPPwrMode;

    /**
     * Device Work Mode
     */
    typedef enum RPPWorkMode_enum
    {
        RPP_DEVICE_WORKMODE_DISABLE_DFS = 0,            /**< Disable DFS */
        RPP_DEVICE_WORKMODE_BOOST_DFS = 1,              /**< The dynamic frequency is 1000/800/666/500/400/333/285/250/222/200 MHz */
        RPP_DEVICE_WORKMODE_LOW_FREQ_DFS = 2,          /**< The dynamic frequency is 800/400/233/200/160/133/114/100/88.8/80 MHz */
        RPP_DEVICE_WORKMODE_MAX
    } RPPWorkMode;

    /**
     * Legacy device properties
     */
    typedef struct RPPdevprop_st
    {
        int maxThreadsPerBlock; /**< Maximum number of threads per block */
        int maxThreadsDim[3];   /**< Maximum size of each dimension of a block */
        int maxGridSize[3];     /**< Maximum size of each dimension of a grid */
        int clockRate;          /**< Clock frequency in kilohertz */
    } RPPdevprop;

    /**
     * Pointer information
     */
    typedef enum RPPpointer_attribute_enum
    {
        RPP_POINTER_ATTRIBUTE_CONTEXT = 1,        /**< The ::RPPcontext on which a pointer was allocated or registered */
        RPP_POINTER_ATTRIBUTE_MEMORY_TYPE = 2,    /**< The ::RPPmemorytype describing the physical location of a pointer */
        RPP_POINTER_ATTRIBUTE_DEVICE_POINTER = 3, /**< The address at which a pointer's memory may be accessed on the device */
        RPP_POINTER_ATTRIBUTE_HOST_POINTER = 4,   /**< The address at which a pointer's memory may be accessed on the host */
    } RPPpointer_attribute;

    /**
     * Function properties
     */
    typedef enum RPPfunction_attribute_enum
    {
        RPP_FUNC_ATTRIBUTE_MAX = 0x00,
    } RPPfunction_attribute;

    /**
     * Function cache configurations
     */
    typedef enum RPPfunc_cache_enum
    {
        RPP_FUNC_CACHE_PREFER_NONE = 0x00, /**< no preference for shared memory or L1 (default) */
    } RPPfunc_cache;

    /**
     * 2D memory copy parameters
     */
    typedef struct RPP_MEMCPY2D_st
    {
        RPParray dstArray;
        RPPdeviceptr dst;
        void *dstHost;
        RPPmemorytype dstMemoryType;
        size_t dstPitch;
        size_t dstXInBytes;
        size_t dstY;
        size_t Height;
        RPParray srcArray;
        RPPdeviceptr src;
        const void *srcHost;
        RPPmemorytype srcMemoryType;
        size_t srcPitch;
        size_t srcXInBytes;
        size_t srcY;
        size_t WidthInBytes;
    } RPP_MEMCPY2D;

    /**
     * 3D memory copy parameters
     */
    typedef struct RPP_MEMCPY3D_st
    {
        size_t Depth;
        RPParray dstArray;
        RPPdeviceptr dst;
        size_t dstHeight;
        void *dstHost;
        size_t dstLOD;
        RPPmemorytype dstMemoryType;
        size_t dstPitch;
        size_t dstXInBytes;
        size_t dstY;
        size_t dstZ;
        size_t Height;
        void *reserved0;
        void *reserved1;
        RPParray srcArray;
        RPPdeviceptr src;
        size_t srcHeight;
        const void *srcHost;
        size_t srcLOD;
        RPPmemorytype srcMemoryType;
        size_t srcPitch;
        size_t srcXInBytes;
        size_t srcY;
        size_t srcZ;
        size_t WidthInBytes;
    } RPP_MEMCPY3D;

    typedef enum RPPmemcpyIndirectTarget_enum
    {
        RPP_MEMCPY_INDIRECT_TARGET_SRC_ADDR = 0,
        RPP_MEMCPY_INDIRECT_TARGET_DST_ADDR = 1,
    } RPPmemcpyIndirectTarget;

    typedef enum RPPmemcpyIndirectInputType_enum
    {
        /* Compatibility type: index_addr + table_base + index * element_size */
        RPP_MEMCPY_INDIRECT_INPUT_TYPE_TABLE = 0,
        /* New type: index_addr + (base + offset) + index * element_size */
        RPP_MEMCPY_INDIRECT_INPUT_TYPE_BASE_OFFSET = 1,
    } RPPmemcpyIndirectInputType;

    typedef struct RPP_MEMCPY_INDIRECT_INPUT_TABLE_st
    {
        RPPdeviceptr indexAddr;
        RPPdeviceptr tableBaseAddr;
        size_t elementSize;
        size_t tableLength;
    } RPP_MEMCPY_INDIRECT_INPUT_TABLE;

    typedef struct RPP_MEMCPY_INDIRECT_INPUT_BASE_OFFSET_st
    {
        RPPdeviceptr indexAddr;
        RPPdeviceptr baseAddr;
        size_t elementSize;
        size_t blockSize;
        size_t offset;
    } RPP_MEMCPY_INDIRECT_INPUT_BASE_OFFSET;

    /**
     * Indirect descriptor-update parameters for executable memcpy nodes.
     *
     * The runtime flow is selected by \p inputType:
     * - TABLE: load index from indexAddr, then load value at tableBaseAddr + index * elementSize
     * - BASE_OFFSET: load index from indexAddr, then load value at (baseAddr + offset) + index * elementSize
     */
    typedef struct RPP_MEMCPY_INDIRECT_UPDATE_PARAMS_st
    {
        RPPmemcpyIndirectInputType inputType;
        RPPmemcpyIndirectTarget target;
        unsigned int reserved;
        union
        {
            RPP_MEMCPY_INDIRECT_INPUT_TABLE tableParams;
            RPP_MEMCPY_INDIRECT_INPUT_BASE_OFFSET baseOffset;
        } input;
    } RPP_MEMCPY_INDIRECT_UPDATE_PARAMS;

    /**
     * Graph-level update-node parameter package:
     * 1) choose target memcpy node
     * 2) provide indirect-update address parameters
     */
    typedef struct RPP_MEMCPY_INDIRECT_UPDATE_NODE_PARAMS_st
    {
        RPPgraphNode targetNode;
        RPP_MEMCPY_INDIRECT_UPDATE_PARAMS updateParams;
        unsigned int reserved;
    } RPP_MEMCPY_INDIRECT_UPDATE_NODE_PARAMS;

    /**
     * 4D memory copy parameters
     */
    typedef struct RPP_MEMCPY4D_st
    {
        size_t Batch;
        size_t Depth;
        RPParray dstArray;
        RPPdeviceptr dst;
        size_t dstDepth;
        size_t dstHeight;
        void *dstHost;
        size_t dstLOD;
        RPPmemorytype dstMemoryType;
        size_t dstPitch;
        size_t dstXInBytes;
        size_t dstY;
        size_t dstZ;
        size_t dstN;
        size_t Height;
        void *reserved0;
        void *reserved1;
        RPParray srcArray;
        RPPdeviceptr src;
        size_t srcDepth;
        size_t srcHeight;
        const void *srcHost;
        size_t srcLOD;
        RPPmemorytype srcMemoryType;
        size_t srcPitch;
        size_t srcXInBytes;
        size_t srcY;
        size_t srcZ;
        size_t srcN;
        size_t WidthInBytes;
    } RPP_MEMCPY4D;

    /**
     * 3D memory cross-context copy parameters
     */
    typedef struct RPP_MEMCPY3D_PEER_st
    {
        size_t Depth;
        RPParray dstArray;
        RPPcontext dstContext;
        RPPdeviceptr dstDevice;
        size_t dstHeight;
        void *dstHost;
        size_t dstLOD;
        RPPmemorytype dstMemoryType;
        size_t dstPitch;
        size_t dstXInBytes;
        size_t dstY;
        size_t dstZ;
        size_t Height;
        RPParray srcArray;
        RPPcontext srcContext;
        RPPdeviceptr srcDevice;
        size_t srcHeight;
        const void *srcHost;
        size_t srcLOD;
        RPPmemorytype srcMemoryType;
        size_t srcPitch;
        size_t srcXInBytes;
        size_t srcY;
        size_t srcZ;
        size_t WidthInBytes;
    } RPP_MEMCPY3D_PEER;

    /**
     * external memory handle type
     */
    typedef enum RPPexternalMemoryHandleType_enum
    {
        // 0-8 reserved
        RPP_EXTERNAL_MEMORY_HANDLE_TYPE_VEBUF = 9,
    } RPPexternalMemoryHandleType;

    /**
     * external memory handle descriptor
     */
    typedef struct RPP_EXTERNAL_MEMORY_HANDLE_DESC_st
    {
        RPPexternalMemoryHandleType type;
        uint64_t addr;
        unsigned long long size;
        unsigned int flags; /* reserved for future */
    } RPP_EXTERNAL_MEMORY_HANDLE_DESC;

    /**
     * external memory buffer descriptor
     */
    typedef struct RPP_EXTERNAL_MEMORY_BUFFER_DESC_st
    {
        unsigned long long offset;
        unsigned long long size;
        unsigned int flags;
    } RPP_EXTERNAL_MEMORY_BUFFER_DESC;

    /**
     * Flags for ::rppGraphInstantiateWithParams (\p RPP_GRAPH_INSTANTIATE_PARAMS::flags).
     */
    typedef enum RPPgraphInstantiate_flags_enum
    {
        RPP_GRAPH_INSTANTIATE_FLAG_DEFAULT = 0x0,
        RPP_GRAPH_INSTANTIATE_FLAG_CHILD_EXEC = 0x1, /**< Child graphexec: required before ::rppGraphExecUpdateChildGraphExec can bind it */
    } RPPgraphInstantiate_flags;

    /**
     * Optional resource pools passed to ::rppGraphInstantiateWithParams.
     *
     * Lets the application pre-size or supply device-side pools (pcie/cdma/kpara/sche descriptors).
     * Larger \p res_sche_desc reduces automatic extended-execlist splits when a branch approaches
     * ::RPP_KQUEUE_SIZE. Use ::rppGraphExecGetParams to read back the layout stored on a graphexec.
     */
    typedef struct RPP_GRAPH_INSTANTIATE_PARAMS_st
    {
        uint64_t flags; /**< Bitmask of ::RPPgraphInstantiate_flags */
        RPPgraphResource res_pcie_desc;
        RPPgraphResource res_cdma_desc;
        RPPgraphResource res_kpara;
        RPPgraphResource res_sche_desc;
    } RPP_GRAPH_INSTANTIATE_PARAMS;

    /**
     * Compute Modes
     *
     */
    typedef enum RPPcomputemode_enum
    {
        RPP_COMPUTEMODE_DEFAULT = 0, /**< Default compute mode (Multiple contexts allowed per device) */
    } RPPcomputemode;

    /**
     * Profile output Modes
     */
    typedef enum RPPoutputmode_enum
    {
        RPP_OUT_CSV = 1, /**< Ouput CSV file */
    } RPPoutput_mode;

    /**
     * Limits
     */
    typedef enum RPPlimit_enum
    {
        RPP_LIMIT_STACK_SIZE = 0x00,     /**< GPU thread stack size */
        RPP_LIMIT_CDMA_BURSTMODE = 0x01, /**< GPU CDMA burst mode */
    } RPPlimit;

    /*
     * codec information struct
     * codeID, ID from rpp server
     * codecNum->index of codec in device(0~3, -1 invalid)
     * instanceNum->instance number(0~7)
     */
    typedef struct RPPCodec_st
    {
        uint64_t rpp_codec;
        int coreIdx;
        int32_t instance;
    } RPPCodec;

    /**
     * Device Register name enum
     */
    typedef enum RPPDevModule_enum
    {
        RPP_MODULE_CODEC = 0x00,
        RPP_MODULE_JPEG,
        RPP_MODULE_MPU0,
        RPP_MODULE_MPU1,
        RPP_MODULE_REG_MAX
    } RPPDevModule_name;

    typedef struct RPPDevVPU_context
    {
        uint32_t coreIdx;
    } RPPDevVPU_ctx;

    typedef struct RPPDevice_context
    {
        RPPdevice rppDev;
        RPPDevModule_name moduleName;
        union
        {
            RPPDevVPU_ctx codecCtx;
        } devModule;
    } RPPDevice_ctx;

    typedef struct RPPdevCodecInfo_st
    {
        struct mem_info
        {
            unsigned long size;      // video engine memory size
            unsigned long phys_addr; // video engine mermory start (physical) address
            size_t base;             // kernel logical address in use kernel(ioremap_nocache)
            size_t virt_addr;        // virtual user space address(mmap)
        } ve_mem;

        struct reg_info
        {
            unsigned long size;      // vpu register space size
            unsigned long phys_addr; // vpu register start (physical) address
            size_t base;             // kernel logical address in use kernel(ioremap_nocache)
            size_t virt_addr;        // virtual user space address(mmap)
        } ve_register;

        struct engine_info
        {
            int8_t avail_codec_ins; // invalid codec instance
            uint8_t populated;      // codec populated flag
        } codec_engine;
    } RPPdevCodecInfo;

    typedef enum RPPDFSFreqLevel_enum
    {
        RPP_FREQ_LEVEL_DEFAULT = 0,     ///< Switch to PLL3, rpp core freq=800MHz
        RPP_FREQ_LEVEL1,                ///< Switch to PLL1, divider=1, if PLL=2GHz, Core's freq=1000MHz, if PLL1=800MHz, Core's freq=400MHz
        RPP_FREQ_LEVEL2,                ///< Switch to PLL1, divider=2, if PLL=2GHz, Core's freq=666MHz, if PLL1=800MHz, Core's freq=233MHz
        RPP_FREQ_LEVEL3,                ///< Switch to PLL1, divider=3, if PLL=2GHz, Core's freq=500MHz, if PLL1=800MHz, Core's freq=200MHz
        RPP_FREQ_LEVEL4,                ///< Switch to PLL1, divider=4, if PLL=2GHz, Core's freq=400MHz, if PLL1=800MHz, Core's freq=160MHz
        RPP_FREQ_LEVEL5,                ///< Switch to PLL1, divider=5, if PLL=2GHz, Core's freq=333MHz, if PLL1=800MHz, Core's freq=133MHz
        RPP_FREQ_LEVEL6,                ///< Switch to PLL1, divider=6, if PLL=2GHz, Core's freq=285MHz, if PLL1=800MHz, Core's freq=114MHz
        RPP_FREQ_LEVEL7,                ///< Switch to PLL1, divider=7, if PLL=2GHz, Core's freq=250MHz, if PLL1=800MHz, Core's freq=100MHz
        RPP_FREQ_LEVEL8,                ///< Switch to PLL1, divider=8, if PLL=2GHz, Core's freq=222MHz, if PLL1=800MHz, Core's freq=88.8MHz
        RPP_FREQ_LEVEL9,                ///< Switch to PLL1, divider=9, if PLL=2GHz, Core's freq=200MHz, if PLL1=800MHz, Core's freq=80MHz
    } RPPDFSFreqLevel;

    typedef enum RPPMpuMsgType_enum
    {
        RPP_FLEXIBLE_FREQ_TYPE0 = 0,
    } RPPMpuMsgType;

    /**
     * flexible DFS level params
     * pre_time -- levelA -- hold_time --levelB
     */
    typedef struct RPPDFSFlexibleFreq_st
    {
        RPPMpuMsgType type;
        RPPDFSFreqLevel levelA;
        RPPDFSFreqLevel levelB;
        uint32_t pre_time; // in us
        uint32_t hold_time; // in us
    } RPPDFSFlexibleFreq;

    /**
     * Error codes
     */
    typedef enum rppError_enum
    {
        /**
         * The API call returned with no errors. In the case of query calls, this
         * can also mean that the operation being queried is complete (see
         * ::rppEventQuery() and ::rppStreamQuery()).
         */
        RPP_SUCCESS = 0,

        /**
         * This indicates that one or more of the parameters passed to the API call
         * is not within an acceptable range of values.
         */
        RPP_ERROR_INVALID_VALUE = 1,

        /**
         * The API call failed because it was unable to allocate enough memory to
         * perform the requested operation.
         */
        RPP_ERROR_OUT_OF_MEMORY = 2,

        /**
         * This indicates that the RPP driver has not been initialized with
         * ::rppInit() or that initialization has failed.
         */
        RPP_ERROR_NOT_INITIALIZED = 3,

        /**
         * This indicates that the RPP driver is in the process of shutting down.
         */
        RPP_ERROR_DEINITIALIZED = 4,

        /**
         * This indicates profiler is not initialized for this run.
         * This can happen when the application is running with external profiling tools like visual profiler.
         */
        RPP_ERROR_PROFILER_DISABLED = 5,
        /**
         * This indicates profiling has not been initialized for this context.
         * Call rppProfilerInitialize() to resolve this.
         */
        RPP_ERROR_PROFILER_NOT_INITIALIZED = 6,
        /**
         * This indicates profiler has already been started and probably
         * rppProfilerStart() is incorrectly called.
         */
        RPP_ERROR_PROFILER_ALREADY_STARTED = 7,
        /**
         * This indicates profiler has already been stopped and probably
         * rppProfilerStop() is incorrectly called.
         */
        RPP_ERROR_PROFILER_ALREADY_STOPPED = 8,
        /**
         * This indicates that no RPP-capable devices were detected by the installed
         * RPP driver.
         */
        RPP_ERROR_NO_DEVICE = 100,

        /**
         * This indicates that the device ordinal supplied by the user does not
         * correspond to a valid RPP device.
         */
        RPP_ERROR_INVALID_DEVICE = 101,

        /**
         * This indicates that the device kernel image is invalid. This can also
         * indicate an invalid RPP module.
         */
        RPP_ERROR_INVALID_IMAGE = 200,

        /**
         * This most frequently indicates that there is no context bound to the
         * current thread. This can also be returned if the context passed to an
         * API call is not a valid handle (such as a context that has had
         * ::rppCtxDestroy() invoked on it). This can also be returned if a user
         * mixes different API versions (i.e. 3010 context with 3020 API calls).
         * See ::rppCtxGetApiVersion() for more details.
         */
        RPP_ERROR_INVALID_CONTEXT = 201,

        /**
         * This indicated that the context being supplied as a parameter to the
         * API call was already the active context.
         * \deprecated
         * This error return is deprecated as of RPP 3.2. It is no longer an
         * error to attempt to push the active context via ::rppCtxPushCurrent().
         */
        RPP_ERROR_CONTEXT_ALREADY_CURRENT = 202,

        /**
         * This indicates that a map or register operation has failed.
         */
        RPP_ERROR_MAP_FAILED = 205,

        /**
         * This indicates that an unmap or unregister operation has failed.
         */
        RPP_ERROR_UNMAP_FAILED = 206,

        /**
         * This indicates that the specified array is currently mapped and thus
         * cannot be destroyed.
         */
        RPP_ERROR_ARRAY_IS_MAPPED = 207,

        /**
         * This indicates that the resource is already mapped.
         */
        RPP_ERROR_ALREADY_MAPPED = 208,

        /**
         * This indicates that there is no kernel image available that is suitable
         * for the device. This can occur when a user specifies code generation
         * options for a particular RPP source file that do not include the
         * corresponding device configuration.
         */
        RPP_ERROR_NO_BINARY_FOR_GPU = 209,

        /**
         * This indicates that a resource has already been acquired.
         */
        RPP_ERROR_ALREADY_ACQUIRED = 210,

        /**
         * This indicates that a resource is not mapped.
         */
        RPP_ERROR_NOT_MAPPED = 211,

        /**
         * This indicates that a mapped resource is not available for access as an
         * array.
         */
        RPP_ERROR_NOT_MAPPED_AS_ARRAY = 212,

        /**
         * This indicates that a mapped resource is not available for access as a
         * pointer.
         */
        RPP_ERROR_NOT_MAPPED_AS_POINTER = 213,

        /**
         * This indicates that an uncorrectable ECC error was detected during
         * execution.
         */
        RPP_ERROR_ECC_UNCORRECTABLE = 214,

        /**
         * This indicates that the ::RPPlimit passed to the API call is not
         * supported by the active device.
         */
        RPP_ERROR_UNSUPPORTED_LIMIT = 215,

        /**
         * This indicates that the ::RPPcontext passed to the API call can
         * only be bound to a single CPU thread at a time but is already
         * bound to a CPU thread.
         */
        RPP_ERROR_CONTEXT_ALREADY_IN_USE = 216,

        /**
         * This indicates that peer access is not supported across the given
         * devices.
         */
        RPP_ERROR_PEER_ACCESS_UNSUPPORTED = 217,

        /**
         * This indicates that the device kernel source is invalid.
         */
        RPP_ERROR_INVALID_SOURCE = 300,

        /**
         * This indicates that the file specified was not found.
         */
        RPP_ERROR_FILE_NOT_FOUND = 301,

        /**
         * This indicates that a link to a shared object failed to resolve.
         */
        RPP_ERROR_SHARED_OBJECT_SYMBOL_NOT_FOUND = 302,

        /**
         * This indicates that initialization of a shared object failed.
         */
        RPP_ERROR_SHARED_OBJECT_INIT_FAILED = 303,

        /**
         * This indicates that an OS call failed.
         */
        RPP_ERROR_OPERATING_SYSTEM = 304,

        /**
         * This indicates that a resource handle passed to the API call was not
         * valid. Resource handles are opaque types like ::RPPstream and ::RPPevent.
         */
        RPP_ERROR_INVALID_HANDLE = 400,

        /**
         * This indicates that a named symbol was not found. Examples of symbols
         * are global/constant variable names, texture names, and surface names.
         */
        RPP_ERROR_NOT_FOUND = 500,

        /**
         * This indicates that asynchronous operations issued previously have not
         * completed yet. This result is not actually an error, but must be indicated
         * differently than ::RPP_SUCCESS (which indicates completion). Calls that
         * may return this value include ::rppEventQuery() and ::rppStreamQuery().
         */
        RPP_ERROR_NOT_READY = 600,

        /**
         * An exception occurred on the device while executing a kernel. Common
         * causes include dereferencing an invalid device pointer and accessing
         * out of bounds shared memory. The context cannot be used, so it must
         * be destroyed (and a new one should be created). All existing device
         * memory allocations from this context are invalid and must be
         * reconstructed if the program is to continue using RPP.
         */
        RPP_ERROR_ILLEGAL_ADDRESS = 700,

        /**
         * This indicates that a launch did not occur because it did not have
         * appropriate resources. This error usually indicates that the user has
         * attempted to pass too many arguments to the device kernel, or the
         * kernel launch specifies too many threads for the kernel's register
         * count. Passing arguments of the wrong size (i.e. a 64-bit pointer
         * when a 32-bit int is expected) is equivalent to passing too many
         * arguments and can also result in this error.
         */
        RPP_ERROR_LAUNCH_OUT_OF_RESOURCES = 701,

        /**
         * This indicates that the device kernel took too long to execute. The
         * context cannot be used (and must be destroyed similar to
         * ::RPP_ERROR_LAUNCH_FAILED). All existing device memory allocations from
         * this context are invalid and must be reconstructed if the program is to
         * continue using RPP.
         */
        RPP_ERROR_LAUNCH_TIMEOUT = 702,

        /**
         * This error indicates a kernel launch that uses an incompatible texturing
         * mode.
         */
        RPP_ERROR_LAUNCH_INCOMPATIBLE_TEXTURING = 703,

        /**
         * This error indicates that the primary context for the specified device
         * has already been initialized.
         */
        RPP_ERROR_PRIMARY_CONTEXT_ACTIVE = 708,

        /**
         * This error indicates that the context current to the calling thread
         * has been destroyed using ::rppCtxDestroy, or is a primary context which
         * has not yet been initialized.
         */
        RPP_ERROR_CONTEXT_IS_DESTROYED = 709,

        /**
         * A device-side assert triggered during kernel execution.
         * The context cannot be used anymore, and must be destroyed.
         * All existing device memory allocations from this context are invalid
         * and must be reconstructed if the program is to continue using RPP.
         */
        RPP_ERROR_ASSERT = 710,

        /**
         * This error indicates that the memory range passed to rppMemHostRegister()
         * has already been registered.
         */
        RPP_ERROR_HOST_MEMORY_ALREADY_REGISTERED = 712,

        /**
         * This error indicates that the pointer passed to rppMemHostUnregister()
         * does not correspond to any currently registered memory region.
         */
        RPP_ERROR_HOST_MEMORY_NOT_REGISTERED = 713,

        /**
         * While executing a kernel, the device encountered a stack error.
         * This can be due to stack corruption or exceeding the stack size limit.
         * This leaves the process in an inconsistent state and any further RPP work
         * will return the same error. To continue using RPP, the process must be terminated
         * and relaunched.
         */
        RPP_ERROR_HARDWARE_STACK_ERROR = 714,

        /**
         * While executing a kernel, the device encountered an illegal instruction.
         * This leaves the process in an inconsistent state and any further RPP work
         * will return the same error. To continue using RPP, the process must be terminated
         * and relaunched.
         */
        RPP_ERROR_ILLEGAL_INSTRUCTION = 715,

        /**
         * While executing a kernel, the device encountered a load or store instruction
         * on a memory address which is not aligned.
         * This leaves the process in an inconsistent state and any further RPP work
         * will return the same error. To continue using RPP, the process must be terminated
         * and relaunched.
         */
        RPP_ERROR_MISALIGNED_ADDRESS = 716,

        /**
         * While executing a kernel, the device encountered an instruction
         * which can only operate on memory locations in certain address spaces
         * (global, shared, or local), but was supplied a memory address not
         * belonging to an allowed address space.
         * This leaves the process in an inconsistent state and any further RPP work
         * will return the same error. To continue using RPP, the process must be terminated
         * and relaunched.
         */
        RPP_ERROR_INVALID_ADDRESS_SPACE = 717,

        /**
         * While executing a kernel, the device program counter wrapped its address space.
         * This leaves the process in an inconsistent state and any further RPP work
         * will return the same error. To continue using RPP, the process must be terminated
         * and relaunched.
         */
        RPP_ERROR_INVALID_PC = 718,

        /**
         * An exception occurred on the device while executing a kernel. Common
         * causes include dereferencing an invalid device pointer and accessing
         * out of bounds shared memory.
         * This leaves the process in an inconsistent state and any further RPP work
         * will return the same error. To continue using RPP, the process must be terminated
         * and relaunched.
         */
        RPP_ERROR_LAUNCH_FAILED = 719,

        /**
         * This error indicates that the number of blocks launched per grid for a kernel
         * exceeds the maximum number of blocks as allowed.
         */
        RPP_ERROR_COOPERATIVE_LAUNCH_TOO_LARGE = 720,

        /**
         * This error indicates that the attempted operation is not permitted.
         */
        RPP_ERROR_NOT_PERMITTED = 800,

        /**
         * This error indicates that the attempted operation is not supported
         * on the current system or device.
         */
        RPP_ERROR_NOT_SUPPORTED = 801,

        /**
         * This error indicates that graph executable update was rejected due to
         * update constraints. Use ::RPP_GRAPH_EXEC_UPDATE_RESULT_INFO for details.
         */
        RPP_ERROR_GRAPH_EXEC_UPDATE_FAILURE = 910,

        /**
         * This indicates that an unknown internal error has occurred.
         */
        RPP_ERROR_UNKNOWN = 999
    } RPPresult;

    static inline const char *getRppDrvErrorString(RPPresult error_id)
    {
        int index = 0;

        while (sRppDrvErrorString[index].error_id != (int)error_id &&
               sRppDrvErrorString[index].error_id != -1)
        {
            index++;
        }

        if (sRppDrvErrorString[index].error_id == (int)error_id)
            return (const char *)sRppDrvErrorString[index].error_string;
        else
            return (const char *)"RPP_ERROR not found!";
    }

    inline static void __checkRppErrors(RPPresult err, const char *file, const int line)
    {
        if (RPP_SUCCESS != err)
        {
            fprintf(stderr, "checkRppErrors() Driver API error = %d \"%s\" from file <%s>, line %i.\n",
                    err, getRppDrvErrorString(err), file, line);
            exit(-1);
        }
    }

#define checkRppErrors(err) __checkRppErrors((RPPresult)err, __FILE__, __LINE__)

#ifdef _WIN32
#define RPP_CB __stdcall
#else
#define RPP_CB
#endif

    typedef void(RPP_CB *RPPstreamCallback)(RPPstream hStream, RPPresult status, void *userData);

/**
 * Interprocess Handles
 */
#define RPP_IPC_HANDLE_SIZE 64

/**
 * End of array terminator for the extra parameter to rppLaunchKernel
 */
#define RPP_LAUNCH_PARAM_END ((void *)0x00)

/**
 * Indicator that the next value in the extra parameter to rppLaunchKernel
 * will be a pointer to a buffer containing all kernel parameters used for
 * launching kernel f. This buffer needs to honor all alignment/padding
 * requirements of the individual parameters.
 * If RPP_LAUNCH_PARAM_BUFFER_SIZE is not also specified in the extra array,
 * then RPP_LAUNCH_PARAM_BUFFER_POINTER will have no effect.
 */
#define RPP_LAUNCH_PARAM_BUFFER_POINTER ((void *)0x01)

/**
 * Indicator that the next value in the extra parameter to rppLaunchKernel
 * will be a pointer to a size_t which contains the size of the buffer
 * specified with RPP_LAUNCH_PARAM_BUFFER_POINTER.
 * It is required that RPP_LAUNCH_PARAM_BUFFER_POINTER also be specified in
 * the extra array if the value associated with RPP_LAUNCH_PARAM_BUFFER_SIZE
 * is not zero.
 */
#define RPP_LAUNCH_PARAM_BUFFER_SIZE ((void *)0x02)

/**
 * If set, host memory is portable between RPP contexts.
 * Flag for ::rppMemHostAlloc()
 */
#define RPP_MEMHOSTALLOC_PORTABLE 0x01

/**
 * If set, host memory is mapped into RPP address space and
 * ::rppMemHostGetDevicePointer() may be called on the host pointer.
 * Flag for ::rppMemHostAlloc()
 */
#define RPP_MEMHOSTALLOC_DEVICEMAP 0x02

/**
 * If set, host memory is allocated as write-combined - fast to write,
 * faster to DMA, slow to read except via SSE4 streaming load instruction
 * (MOVNTDQA).
 * Flag for ::rppMemHostAlloc()
 */
#define RPP_MEMHOSTALLOC_WRITECOMBINED 0x04

/**
 * If set, host memory is portable between RPP contexts.
 * Flag for rppMemHostRegister()
 */
#define RPP_MEMHOSTREGISTER_PORTABLE 0x01

/**
 * If set, host memory is mapped into RPP address space and
 * rppMemHostGetDevicePointer() may be called on the host pointer.
 * Flag for rppMemHostRegister()
 */
#define RPP_MEMHOSTREGISTER_DEVICEMAP 0x02

/**
 * For texture references loaded into the module, use default texunit from
 * texture reference.
 */
#define RPP_PARAM_TR_DEFAULT -1

/**
 * Override the texref format with a format inferred from the array.
 * Flag for rppTexRefSetArray()
 */
#define RPP_TRSA_OVERRIDE_FORMAT 0x01

/**
 * Read the texture as integers rather than promoting the values to floats
 * in the range [0,1].
 * Flag for rppTexRefSetFlags()
 */
#define RPP_TRSF_READ_AS_INTEGER 0x01

/**
 * Use normalized texture coordinates in the range [0,1) instead of [0,dim).
 * Flag for rppTexRefSetFlags()
 */
#define RPP_TRSF_NORMALIZED_COORDINATES 0x02

/**
 * Perform sRGB->linear conversion during texture read.
 * Flag for rppTexRefSetFlags()
 */
#define RPP_TRSF_SRGB 0x10

/**
 * If set, the RPP array is a collection of layers, where each layer is
 * either a 1D or a 2D array and the Depth member of RPP_ARRAY3D_DESCRIPTOR
 * specifies the number of layers, not the depth of a 3D array.
 */
#define RPP_ARRAY3D_LAYERED 0x01

/**
 * Deprecated, use RPP_ARRAY3D_LAYERED
 */
#define RPP_ARRAY3D_2DARRAY 0x01

/**
 * This flag must be set in order to bind a surface reference to the RPP
 * array
 */
#define RPP_ARRAY3D_SURFACE_LDST 0x02

/**
 * If set, the RPP array is a collection of six 2D arrays, representing
 * faces of a cube. The width of such a RPP array must be equal to its
 * height, and Depth must be six. If RPP_ARRAY3D_LAYERED flag is also set,
 * then the RPP array is a collection of cubemaps and Depth must be a
 * multiple of six.
 */
#define RPP_ARRAY3D_CUBEMAP 0x04

/**
 * This flag must be set in order to perform texture gather operations on
 * a RPP array.
 */
#define RPP_ARRAY3D_TEXTURE_GATHER 0x08

/**
 * RPP API version number
 */
#define RPP_VERSION 1000

    /**
     * \defgroup RPP_ERROR Error Handling
     *
     * This section describes the error handling functions of the low-level RPP
     * driver API.
     *
     * @{
     */

    /**
     * \brief Gets the string representation of an error code enum name.
     *
     * Sets \p *pStr to the address of a NULL-terminated string representation of the name of the enum error code \p error.
     * If the error code is not recognized, RPP_ERROR_INVALID_VALUE will be returned and \p *pStr will be set to the NULL address.
     *
     * \param error - Error code to convert to string.
     * \param pStr  - Address of the string pointer.
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_INVALID_VALUE
     */
    RPPresult rppGetErrorName(RPPresult error, const char **pStr);

    /**
     * \brief Gets the string description of an error code.
     *
     * Sets \p *pStr to the address of a NULL-terminated string description of the error code \p error.
     * If the error code is not recognized, RPP_ERROR_INVALID_VALUE will be returned and \p *pStr will be set to the NULL address.
     *
     * \param error - Error code to convert to string.
     * \param pStr  - Address of the string pointer.
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_INVALID_VALUE
     */
    RPPresult rppGetErrorString(RPPresult error, const char **pStr);

    /** @} */ /* END RPP_ERROR */

    /* Initialization */
    /**
     * \defgroup RPP_INITIALIZE Initialization
     *
     * This section describes the initialization functions of the low-level RPP
     * driver API.
     *
     * @{
     */

    /**
     * \brief Initialize the RPP driver API
     *
     * Initializes the driver API and must be called before any other function from
     * the driver API. Currently, the \p Flags parameter must be 0. If ::rppInit()
     * has not been called, any function from the driver API will return
     * ::RPP_ERROR_NOT_INITIALIZED.
     * Note that ::rppInit() is not thread-safe, it requires additional protection
     * if invoked from multiple threads in a process.
     *
     * \param Flags - Initialization flag.
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_DEVICE
     */
    RPPresult rppInit(unsigned int Flags);

    /**
     * \brief Deinitialized the RPP driver API
     *
     * Deinitialized the driver API and must be called after all driver API finished
     * Currently, the Flags parameter must be 0. If rppExit()
     * has not been called, the resource created by rppInit() will be a float state.
     * If any function called after rppExit() will return RPP_ERROR_DEINITIALIZED.
     * Note that ::rppExit() is not thread-safe, it requires additional protection
     * if invoked from multiple threads in a process.
     *
     * Parameters:
     *     Flags - Exit flag.
     *
     * Returns:
     *  RPP_SUCCESS, RPP_ERROR_INVALID_VALUE, RPP_ERROR_INVALID_DEVICE
     */
RPPresult rppExit(unsigned int Flags);

    /** @} */ /* END RPP_INITIALIZE */

    /* Version Management */
    /**
     * \defgroup RPP_VERSION Version Management
     *
     * This section describes the version management functions of the low-level
     * RPP driver API.
     *
     * @{
     */

    /**
     * \brief Returns the RPP driver version
     *
     * Returns in \p *driverVersion the version number of the installed RPP
     * driver. This function automatically returns ::RPP_ERROR_INVALID_VALUE if
     * the \p driverVersion argument is NULL.
     *
     * \param driverVersion - Returns the RPP driver version
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_INVALID_VALUE
     *
     */
    RPPresult rppDriverGetVersion(int *driverVersion);

    /** @} */ /* END RPP_VERSION */

    /* Device Management */
    /**
     * \defgroup RPP_DEVICE Device Management
     *
     * This section describes the device management functions of the low-level
     * RPP driver API.
     *
     * @{
     */

    /**
     * \deprecated
     * \brief Returns the compute capability of the device
     *
     * Returns in \p *major and \p *minor the major and minor revision numbers that
     * define the compute capability of the device \p dev.
     *
     * \param major - Major revision number
     * \param minor - Minor revision number
     * \param dev   - Device handle
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_DEVICE
     *
     * \sa
     * ::rppDeviceGetAttribute,
     * ::rppDeviceGetCount,
     * ::rppDeviceGetName,
     * ::rppDeviceGet,
     * ::rppDeviceTotalMem
     */
    RPPresult rppDeviceComputeCapability(int *major, int *minor, RPPdevice dev);

    /**
     * \brief Returns a handle to a compute device
     *
     * Returns in \p *device a device handle given an ordinal in the range <b>[0,
     * ::rppDeviceGetCount()-1]</b>.
     *
     * \param device  - Returned device handle
     * \param ordinal - Device number to get handle for
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_DEVICE

     *
     * \sa
     * ::rppDeviceGetAttribute,
     * ::rppDeviceGetCount,
     * ::rppDeviceGetName,
     * ::rppDeviceTotalMem
     */
    RPPresult rppDeviceGet(RPPdevice *device, int ordinal);

    /**
     * \brief Returns information about the device
     *
     * Returns in \p *pi the integer value of the attribute \p attrib on device
     * \p dev. The supported attributes are list at \p RPPdevice_attribute
     *
     * \param pi     - Returned device attribute value
     * \param attrib - Device attribute to query
     * \param dev    - Device handle
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_DEVICE
     *
     * \sa
     * ::rppDeviceGetCount,
     * ::rppDeviceGetName,
     * ::rppDeviceGet,
     * ::rppDeviceTotalMem,
     * ::rppDeviceGetAttribute,
     * ::rppDeviceGetProperties
     */
    RPPresult rppDeviceGetAttribute(int *pi, RPPdevice_attribute attrib, RPPdevice dev);

    /**
     * \brief Returns the number of RPP devices
     *
     * Returns in \p *count the number of RPP devices. If there is no such
     * device, ::rppDeviceGetCount() returns 0.
     *
     * \param count - Returned number of RPP devices
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa
     * ::rppDeviceGetAttribute,
     * ::rppDeviceGetName,
     * ::rppDeviceGet,
     * ::rppDeviceTotalMem,
     * ::rppDeviceGetCount
     */
    RPPresult rppDeviceGetCount(int *count);

    /**
     * \brief Returns an identifer string for the device
     *
     * Returns an ASCII string identifying the device \p dev in the NULL-terminated
     * string pointed to by \p name. \p len specifies the maximum length of the
     * string that may be returned.
     *
     * \param name - Returned identifier string for the device
     * \param len  - Maximum length of string to store in \p name
     * \param dev  - Device to get identifier string for
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_DEVICE
     *
     * \sa
     * ::rppDeviceGetAttribute,
     * ::rppDeviceGetCount,
     * ::rppDeviceGet,
     * ::rppDeviceTotalMem,
     * ::rppDeviceGetProperties
     */
    RPPresult rppDeviceGetName(char *name, int len, RPPdevice dev);

    /**
     * \brief Returns an UUID for the device
     *
     * Reserved for future use.
     * Returns 16-octets identifing the device \p dev in the structure pointed by the \p uuid.
     *
     * \param uuid - Returned UUID
     * \param dev  - Device to get identifier string for
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_DEVICE
     *
     * \sa
     * ::rppDeviceGetAttribute,
     * ::rppDeviceGetCount,
     * ::rppDeviceGet,
     * ::rppDeviceTotalMem,
     * ::rppDeviceGetProperties
     */
    RPPresult rppDeviceGetUuid(RPPuuid *uuid, RPPdevice dev);

    /**
     * \deprecated
     * \brief Returns properties for a selected device
     *
     * Returns in \p *prop the properties of device \p dev.
     *
     * \param prop - Returned properties of device
     * \param dev  - Device to get properties for
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_DEVICE
     *
     * \sa
     * ::rppDeviceGetAttribute,
     * ::rppDeviceGetCount,
     * ::rppDeviceGetName,
     * ::rppDeviceGet,
     * ::rppDeviceTotalMem
     */
    RPPresult rppDeviceGetProperties(RPPdevprop *prop, RPPdevice dev);

    /**
     * \brief Returns the total amount of memory on the device
     *
     * Returns in \p *bytes the total amount of memory available on the device
     * \p dev in bytes.
     *
     * \param bytes - Returned memory available on device in bytes
     * \param dev   - Device handle
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_DEVICE
     *
     * \sa
     * ::rppDeviceGetAttribute,
     * ::rppDeviceGetCount,
     * ::rppDeviceGetName,
     * ::rppDeviceGet,
     */
    RPPresult rppDeviceTotalMem(size_t *bytes, RPPdevice dev);

    RPPresult rppDeviceCanAccessPeer(int *canAccessPeer, RPPdevice dev, RPPdevice peerDev);
    RPPresult rppOccupancyMaxActiveBlocksPerMultiprocessor(int *numBlocks, RPPfunction func, int blockSize, size_t dynamicSMemSize);
    RPPresult rppDeviceGetCodecInfo(RPPdevCodecInfo *codecInfo, RPPdevice dev);

    /** @} */ /* END RPP_DEVICE */

    /* Primary Context Management */
    /**
     * \defgroup RPP_PRIM_CTX Primary Context Management
     *
     * This section describes the primary context management functions of the low-level
     * RPP driver API.
     *
     * @{
     */

    /**
     * \brief Get the state of the primary context.
     *
     * Returns in \p *flags the flags for the primary context of \p dev, and in \p *active
     * whether it is active.
     *
     *
     * \param dev   - Device to get primary context flags for
     * \param flags - Pointer to store flags(must be 0)
     * \param active - Pointer to store context state(0=incative, 1=active)
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_DEVICE,
     * ::RPP_ERROR_INVALID_VALUE,
     *
     * \sa ::rppDevicePrimaryCtxSetFlags
     */
    RPPresult rppDevicePrimaryCtxGetState(RPPdevice dev, unsigned int *flags, int *active);

    /**
     * \brief Release the primary context on the device.
     *
     * Releases the primary context interop on the device by decreasing the usage count by 1.
     * If the usage drops to 0 the primary context of device \p dev will be destroyed regardless of
     * how many threads it is current to.
     * Please note that unlike rppCtxDestroy() this method does not pop the context from stack
     * in any circumstances.
     *
     *
     * \param dev   - Device for which primary context is released
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_DEVICE,
     *
     * \sa ::rppDevicePrimaryCtxRetain
     */
    RPPresult rppDevicePrimaryCtxRelease(RPPdevice dev);

    /**
     * \brief Destroy all allocations and reset all state on the primary context.
     *
     * Explicitly destroys and cleans up all resources associated with the current device in the
     * current process.
     * Note that it is responsibility of the calling function to ensure that no other module in
     * the process is using the device any more. For that reason it is recommended to use
     * \p rppDevicePrimaryCtxRelease() in most cases. However it is safe for other modules to call
     * \p rppDevicePrimaryCtxRelease() even after resetting the device.
     *
     *
     * \param dev   - Device for which primary context is destroyed
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_DEVICE,
     * ::RPP_ERROR_PRIMARY_CONTEXT_ACTIVE,
     *
     * \sa ::rppDevicePrimaryCtxRetain
     * \sa ::rppDevicePrimaryCtxRelease
     */
    RPPresult rppDevicePrimaryCtxReset(RPPdevice dev);

    /**
     * \brief Retain the primary context on the device.
     *
     * Retains the primary context on the device, creating it if necessary, increasing its usage
     * count. The caller must call \p rppDevicePrimaryCtxRelease() when done using the context.
     * Unlike \p rppCtxCreate() the newly created context is not pushed onto the stack.
     *
     *
     * \param pctx  - Returned context handle of the new context
     * \param dev   - Device for which primary context is requested
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_DEVICE,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_OUT_OF_MEMORY,
     * ::RPP_ERROR_UNKNOWN,
     *
     * \sa ::rppDevicePrimaryCtxSetFlags
     * \sa ::rppDevicePrimaryCtxRelease
     */
    RPPresult rppDevicePrimaryCtxRetain(RPPcontext *pctx, RPPdevice dev);

    /**
     * \brief Set flags for the primary context.
     *
     *
     * \param dev   - Device to set primary context flags for
     * \param flags - New flags for the device primary context
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_DEVICE,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_PRIMARY_CONTEXT_ACTIVE,
     *
     * \sa ::rppDevicePrimaryCtxGetState
     */
    RPPresult rppDevicePrimaryCtxSetFlags(RPPdevice dev, unsigned int flags);

    /** @} */ /* END RPP_PRIM_CTX */

    /* Context Management */
    /**
     * \defgroup RPP_CTX Context Management
     *
     * This section describes the context management functions of the low-level
     * RPP driver API.
     *
     * @{
     */

    /**
     * \brief Create a RPP context
     *
     * Creates a new RPP context and associates it with the calling thread. The context is created with a usage
     * count of 1 and the caller of ::rppCtxCreate() must call ::rppCtxDestroy() or
     * when done using the context. If a context is already current to the thread,
     * it is supplanted by the newly created context and may be restored by a subsequent
     * call to ::rppCtxPopCurrent().
     *
     *
     * \param pctx  - Returned context handle of the new context
     * \param flags - Context creation flags
     * \param dev   - Device to create context on
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_DEVICE,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_OUT_OF_MEMORY,
     * ::RPP_ERROR_UNKNOWN
     *
     * \sa ::rppCtxDestroy,
     * ::rppCtxGetApiVersion,
     * ::rppCtxGetDevice,
     * ::rppCtxGetFlags,
     * ::rppCtxPopCurrent,
     * ::rppCtxPushCurrent,
     * ::rppCtxSynchronize
     */
    RPPresult rppCtxCreate(RPPcontext *pctx, unsigned int flags, RPPdevice dev);

    /**
     * \brief Destroy a RPP context
     *
     * Destroys the RPP context specified by \p ctx.  The context \p ctx will be
     * destroyed regardless of how many threads it is current to.
     * It is the responsibility of the calling function to ensure that no API
     * call issues using \p ctx while ::rppCtxDestroy() is executing.
     *
     * If \p ctx is current to the calling thread then \p ctx will also be
     * popped from the current thread's context stack (as though ::rppCtxPopCurrent()
     * were called).  If \p ctx is current to other threads, then \p ctx will
     * remain current to those threads, and attempting to access \p ctx from
     * those threads will result in the error ::RPP_ERROR_CONTEXT_IS_DESTROYED.
     *
     * \param ctx - Context to destroy
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppCtxCreate,
     * ::rppCtxGetApiVersion,
     * ::rppCtxGetDevice,
     * ::rppCtxGetFlags,
     * ::rppCtxPopCurrent,
     * ::rppCtxPushCurrent,
     * ::rppCtxSynchronize
     */
    RPPresult rppCtxDestroy(RPPcontext ctx);

    /**
     * \brief Gets the context's API version.
     *
     * Returns a version number in \p version corresponding to the capabilities of
     * the context, which library developers can use to direct
     * callers to a specific API version. If \p ctx is NULL, returns the API version
     * used to create the currently bound context.
     *
     * \param ctx     - Context to check
     * \param version - Pointer to version
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_UNKNOWN
     *
     * \sa ::rppCtxCreate,
     * ::rppCtxDestroy,
     * ::rppCtxGetDevice,
     * ::rppCtxGetFlags,
     * ::rppCtxPopCurrent,
     * ::rppCtxPushCurrent,
     * ::rppCtxSynchronize
     */
    RPPresult rppCtxGetApiVersion(RPPcontext ctx, unsigned int *version);

    /**
     * \brief Returns the preferred cache configuration for the current context.
     *
     * Reserved for future use. Currently, it returns a \p pconfig to RPP_FUNC_CACHE_PREFER_NONE.
     *
     * \param pconfig - Returned cache configuration
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     *
     * \sa ::rppCtxCreate,
     * ::rppCtxDestroy,
     * ::rppCtxGetDevice,
     * ::rppCtxGetFlags,
     * ::rppCtxPopCurrent,
     * ::rppCtxPushCurrent,
     * ::rppCtxSynchronize
     */
    RPPresult rppCtxGetCacheConfig(RPPfunc_cache *pconfig);

    /**
     * \brief Returns the RPP context bound to the calling CPU thread.
     *
     * Returns in \p *pctx the RPP context bound to the calling CPU thread.
     * If no context is bound to the calling CPU thread then \p *pctx is
     * set to NULL and ::RPP_SUCCESS is returned.
     *
     * \param pctx - Returned context handle
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     *
     * \sa
     * ::rppCtxSetCurrent,
     * ::rppCtxCreate,
     * ::rppCtxDestroy,
     * ::rppDeviceGet
     */
    RPPresult rppCtxGetCurrent(RPPcontext *pctx);

    /**
     * \brief Returns the device ID for the current context
     *
     * Returns in \p *device the ordinal of the current context's device.
     *
     * \param device - Returned device ID for the current context
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     *
     * \sa ::rppCtxCreate,
     * ::rppCtxDestroy,
     * ::rppCtxGetApiVersion,
     * ::rppCtxGetFlags,
     * ::rppCtxPopCurrent,
     * ::rppCtxPushCurrent,
     * ::rppCtxSynchronize,
     * ::rppDeviceGet
     */
    RPPresult rppCtxGetDevice(RPPdevice *device);

    /**
     * \brief Returns the flags for the current context
     *
     *
     * \param flags - Returned flags for the current context
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     *
     * \sa ::rppCtxCreate,
     * ::rppCtxDestroy,
     * ::rppCtxGetApiVersion,
     * ::rppCtxGetFlags,
     * ::rppCtxPopCurrent,
     * ::rppCtxPushCurrent,
     * ::rppCtxSynchronize,
     * ::rppDeviceGet
     */
    RPPresult rppCtxGetFlags(unsigned int *flags);

    /**
     * \brief Returns the resource limits
     *
     * Reserved for future use. Currently, the \p *pvalue is set to 0.
     *
     *
     * \param pvalue - Returned size of limit
     * \param limit  - Limit to query
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_UNSUPPORTED_LIMIT,
     *
     * \sa ::rppCtxCreate,
     * ::rppCtxDestroy,
     * ::rppCtxGetApiVersion,
     * ::rppCtxGetFlags,
     * ::rppCtxPopCurrent,
     * ::rppCtxPushCurrent,
     * ::rppCtxSynchronize,
     * ::rppDeviceGet
     */
    RPPresult rppCtxGetLimit(size_t *pvalue, RPPlimit limit);

    /**
     * \brief Returns the current shared memory configuration for the current context.
     *
     * Reserved for future use. Currently, returned in the \p *pConfig with RPP_SHARED_MEM_CONFIG_DEFAULT_BANK_SIZE.
     *
     *
     * \param pConfig - Returned shared memory configuration
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     *
     * \sa ::rppCtxCreate,
     * ::rppCtxDestroy,
     * ::rppCtxGetApiVersion,
     * ::rppCtxGetFlags,
     * ::rppCtxPopCurrent,
     * ::rppCtxPushCurrent,
     * ::rppCtxSynchronize,
     * ::rppDeviceGet
     */
    RPPresult rppCtxGetSharedMemConfig(RPPsharedconfig *pConfig);

    /**
     * \brief Returns the numerical values that correspond to the least and greatest stream priorities.
     *
     * Reserved for future use. Currently, returned in the \p *leastPriority and \p *greatestPriority with '0'.
     *
     *
     * \param leastPriority - Pointer to an int in which the least stream priority
     * \param greatestPriority - Pointer to an int in which the greatest stream priority
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     *
     * \sa ::rppCtxCreate,
     * ::rppCtxDestroy,
     * ::rppCtxGetApiVersion,
     * ::rppCtxGetFlags,
     * ::rppCtxPopCurrent,
     * ::rppCtxPushCurrent,
     * ::rppCtxSynchronize,
     * ::rppDeviceGet
     */
    RPPresult rppCtxGetStreamPriorityRange(int *leastPriority, int *greatestPriority);

    /**
     * \brief Pops the current RPP context from the current CPU thread.
     *
     * Pops the current RPP context from the CPU thread and passes back this
     * context handle in \p *pctx. That context may then be made current
     * to a different CPU thread by calling ::rppCtxPushCurrent().
     *
     *
     * \param pctx - Returned the popped context handle
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT
     *
     * \sa ::rppCtxCreate,
     * ::rppCtxDestroy,
     * ::rppCtxGetApiVersion,
     * ::rppCtxGetDevice,
     * ::rppCtxGetFlags,
     * ::rppCtxPushCurrent,
     * ::rppCtxSynchronize
     */
    RPPresult rppCtxPopCurrent(RPPcontext *pctx);

    /**
     * \brief Pushes a context on the current CPU thread
     *
     * Pushes the given context \p ctx onto the CPU thread's stack of current
     * contexts. The specified context becomes the CPU thread's current context, so
     * all RPP functions that operate on the current context are affected.
     *
     *
     * \param ctx - Context to push
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppCtxCreate,
     * ::rppCtxDestroy,
     * ::rppCtxGetApiVersion,
     * ::rppCtxGetDevice,
     * ::rppCtxGetFlags,
     * ::rppCtxPopCurrent,
     * ::rppCtxSynchronize
     */
    RPPresult rppCtxPushCurrent(RPPcontext ctx);

    /**
     * \brief Sets the preferred cache configuration for the current context.
     *
     * Reserved for future use. Currently, the \p config must be RPP_FUNC_CACHE_PREFER_NONE.
     *
     * \param config - Requested cache configuration
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     *
     * \sa ::rppCtxCreate,
     * ::rppCtxDestroy,
     * ::rppCtxGetDevice,
     * ::rppCtxGetFlags,
     * ::rppCtxPopCurrent,
     * ::rppCtxPushCurrent,
     * ::rppCtxSynchronize
     */
    RPPresult rppCtxSetCacheConfig(RPPfunc_cache config);

    /**
     * \brief Binds the specified RPP context to the calling CPU thread
     *
     * Binds the specified RPP context to the calling CPU thread.
     * If \p ctx is NULL then the RPP context previously bound to the
     * calling CPU thread is unbound and ::RPP_SUCCESS is returned.
     *
     * If there exists a RPP context stack on the calling CPU thread, this
     * will replace the top of that stack with \p ctx.
     * If \p ctx is NULL then this will be equivalent to popping the top
     * of the calling CPU thread's RPP context stack (or a no-op if the
     * calling CPU thread's RPP context stack is empty).
     *
     * \param ctx - Context to bind to the calling CPU thread
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT
     *
     * \sa
     * ::rppCtxGetCurrent,
     * ::rppCtxCreate,
     * ::rppCtxDestroy
     */
    RPPresult rppCtxSetCurrent(RPPcontext ctx);

    /**
     * \brief Set resource limits
     *
     * Reserved for future use. Currently, the \p value must be to 0.
     *
     *
     * \param limit  - Limit to set
     * \param value  - Limit to set
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_UNSUPPORTED_LIMIT,
     *
     * \sa ::rppCtxCreate,
     * ::rppCtxDestroy,
     * ::rppCtxGetApiVersion,
     * ::rppCtxGetFlags,
     * ::rppCtxPopCurrent,
     * ::rppCtxPushCurrent,
     * ::rppCtxSynchronize,
     * ::rppDeviceGet
     */
    RPPresult rppCtxSetLimit(RPPlimit limit, size_t value);

    /**
     * \brief Sets the shared memory configuration for the current context.
     *
     * Reserved for future use. Currently, the \p config must be RPP_SHARED_MEM_CONFIG_DEFAULT_BANK_SIZE.
     *
     *
     * \param config - Requestd shared memory configuration
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     *
     * \sa ::rppCtxCreate,
     * ::rppCtxDestroy,
     * ::rppCtxGetApiVersion,
     * ::rppCtxGetFlags,
     * ::rppCtxPopCurrent,
     * ::rppCtxPushCurrent,
     * ::rppCtxSynchronize,
     * ::rppDeviceGet
     */
    RPPresult rppCtxSetSharedMemConfig(RPPsharedconfig config);

    /**
     * \brief Block for a context's tasks to complete
     *
     * Blocks until the device has completed all preceding requested tasks.
     * ::rppCtxSynchronize() returns an error if one of the preceding tasks failed.
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT
     *
     * \sa ::rppCtxCreate,
     * ::rppCtxDestroy,
     * ::rppCtxGetApiVersion,
     * ::rppCtxGetDevice,
     * ::rppCtxGetFlags,
     * ::rppCtxPopCurrent,
     * ::rppCtxPushCurrent
     */
    RPPresult rppCtxSynchronize(void);

    RPPresult rppCtxGetSpecified(RPPcontext *pctx, RPPdevice dev);

    /** @} */ /* END RPP_CTX_DEPRECATED */

    /* Module Management */

    /**
     * \defgroup RPP_MODULE Module Management
     *
     * This section describes the module management functions of the low-level RPP
     * driver API.
     *
     * @{
     */

    /**
     * \brief Returns a function handle
     *
     * Returns in \p *hfunc the handle of the function of name \p name located in
     * module \p hmod. If no function of that name exists, ::rppModuleGetFunction()
     * returns ::RPP_ERROR_NOT_FOUND.
     *
     * \param hfunc - Returned function handle
     * \param hmod  - Module to retrieve function from
     * \param name  - Name of function to retrieve
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_NOT_FOUND
     *
     * \sa ::rppModuleLoad, ::rppModuleUnload
     */
    RPPresult rppModuleGetFunction(RPPfunction *hfunc, RPPmodule hmod, const char *name);

    /**
     * \brief Returns a global pointer from a module
     *
     * Not supported currently. Returns the \p *dptr with NULL and \p *size with 0.
     *
     * \param dptr  - Returned global device pointer
     * \param bytes - Returned global size in pointer
     * \param hmod  - Module to retrieve global from
     * \param name  - Name of global to retrieve
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_NOT_FOUND
     *
     * \sa ::rppModuleLoad, ::rppModuleUnload
     */
    RPPresult rppModuleGetGlobal(RPPdeviceptr *dptr, size_t *bytes, RPPmodule hmod, const char *name);

    /**
     * \brief Loads a compute module
     *
     * Takes a filename \p fname and loads the corresponding module \p module into
     * the current context. The RPP driver API does not attempt to lazily
     * allocate the resources needed by a module; if the memory for functions and
     * data (constant and global) needed by the module cannot be allocated,
     * ::rppModuleLoad() fails.
     *
     * \param module - Returned module
     * \param fname  - Filename of module to load
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_NOT_FOUND,
     * ::RPP_ERROR_OUT_OF_MEMORY,
     * ::RPP_ERROR_FILE_NOT_FOUND,
     * ::RPP_ERROR_NO_BINARY_FOR_GPU,
     * ::RPP_ERROR_SHARED_OBJECT_SYMBOL_NOT_FOUND,
     * ::RPP_ERROR_SHARED_OBJECT_INIT_FAILED
     *
     * \sa ::rppModuleGetFunction,
     * ::rppModuleUnload
     */
    RPPresult rppModuleLoad(RPPmodule *module, const char *fname);

    /**
     * \brief Loads a module's data
     *
     * \param module - Returned module
     * \param image  - Pointer to a complete, readable ELF64 module image. The
     * image must remain valid for the duration of this call.
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_NOT_FOUND,
     * ::RPP_ERROR_OUT_OF_MEMORY,
     * ::RPP_ERROR_FILE_NOT_FOUND,
     * ::RPP_ERROR_NO_BINARY_FOR_GPU,
     * ::RPP_ERROR_SHARED_OBJECT_SYMBOL_NOT_FOUND,
     * ::RPP_ERROR_SHARED_OBJECT_INIT_FAILED
     *
     * \sa ::rppModuleGetFunction,
     * ::rppModuleUnload
     */
    RPPresult rppModuleLoadData(RPPmodule *module, const void *image);

    /**
     * \brief Loads a module's data with options.
     *
     * Takes a pointer image and loads the corresponding module \p module into
     * the current context. Options are passed as an array via \p options and
     * any corresponding parameters are passed in \p optionValues. The number
     * of total options is supplied via \p numOptions. Any outputs will be returned via
     * \p optionValues.
     *
     * \param module - Returned module
     * \param image  - Module data to load
     * \param numOptions  - Options for JIT
     * \param options     - Type of options values
     * \param optionValues  - Option values for JIT
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_NOT_FOUND,
     * ::RPP_ERROR_OUT_OF_MEMORY,
     * ::RPP_ERROR_FILE_NOT_FOUND,
     * ::RPP_ERROR_NO_BINARY_FOR_GPU,
     * ::RPP_ERROR_SHARED_OBJECT_SYMBOL_NOT_FOUND,
     * ::RPP_ERROR_SHARED_OBJECT_INIT_FAILED
     *
     * \sa ::rppModuleGetFunction,
     * ::rppModuleUnload
     */
    RPPresult rppModuleLoadDataEx(RPPmodule *module, const void *image, unsigned int numOptions, void *options, void **optionValues);

    /**
     * \brief Loads a module's data
     *
     * Not supported currently. Returns the \p *module with NULL.
     *
     * \param module - Returned module
     * \param fatCubin  - Fat binary to load
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_NOT_FOUND,
     * ::RPP_ERROR_OUT_OF_MEMORY,
     * ::RPP_ERROR_FILE_NOT_FOUND,
     * ::RPP_ERROR_NO_BINARY_FOR_GPU,
     * ::RPP_ERROR_SHARED_OBJECT_SYMBOL_NOT_FOUND,
     * ::RPP_ERROR_SHARED_OBJECT_INIT_FAILED
     *
     * \sa ::rppModuleGetFunction,
     * ::rppModuleUnload
     */
    RPPresult rppModuleLoadFatBinary(RPPmodule *module, const void *fatCubin);

    /**
     * \brief Unloads a module
     *
     * Unloads a module \p hmod from the current context.
     *
     * \param hmod - Module to unload
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppModuleGetFunction,
     * ::rppModuleLoad,
     */
    RPPresult rppModuleUnload(RPPmodule hmod);

    /** @} */ /* END RPP_MODULE */

    /**
     * \defgroup RPP_EXEC Execution Control
     *
     * This section describes the execution control functions of the low-level RPP
     * driver API.
     *
     * @{
     */

    /**
     * \brief Returns information about a function.
     *
     *
     * Reserved for future use. Returns the \p *pi with 0.
     *
     * \param pi     - Returned attribute value
     * \param attrib - Attribute requested
     * \param hfunc  - Function to query attribute of
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_HANDLE,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppLaunchKernel
     */
    RPPresult rppFuncGetAttribute(int *pi, RPPfunction_attribute attrib, RPPfunction hfunc);

    /**
     * \brief Sets information about a function.
     *
     *
     * Reserved for future use.
     *
     * \param hfunc  - Function to query attribute of
     * \param attrib - Attribute requested
     * \param value  - The value to set
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_HANDLE,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppLaunchKernel
     */
    RPPresult rppFuncSetAttribute(RPPfunction hfunc, RPPfunction_attribute attrib, int value);

    /**
     * \brief Sets preferred cache configuration for a device function.
     *
     *
     * Reserved for future use.
     *
     * \param hfunc  - Kernel to configure cache for
     * \param config - Requested cache configuration
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_HANDLE,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppLaunchKernel
     */
    RPPresult rppFuncSetCacheConfig(RPPfunction hfunc, RPPfunc_cache config);

    /**
     * \brief Sets the shared memory configuration for a device function.
     *
     *
     * Reserved for future use.
     *
     * \param hfunc  - Kernel to configure cache for
     * \param config - Requested shared memory configuration
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_HANDLE,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppLaunchKernel
     */
    RPPresult rppFuncSetShareMemConfig(RPPfunction hfunc, RPPsharedconfig config);

    /**
     * \brief Launches a RPP function
     *
     * Invokes the kernel \p f on a \p gridDimX x \p gridDimY x \p gridDimZ
     * grid of blocks. Each block contains \p blockDimX x \p blockDimY x
     * \p blockDimZ threads.
     *
     * \p sharedMemBytes sets the amount of dynamic shared memory that will be
     * available to each thread block.
     *
     * Kernel parameters to \p f can be specified in one of two ways:
     *
     * 1) Kernel parameters can be specified via \p kernelParams.  If \p f
     * has N parameters, then \p kernelParams needs to be an array of N
     * pointers.  Each of \p kernelParams[0] through \p kernelParams[N-1]
     * must point to a region of memory from which the actual kernel
     * parameter will be copied.  The number of kernel parameters and their
     * offsets and sizes do not need to be specified as that information is
     * retrieved directly from the kernel's image.
     *
     * 2) Kernel parameters can also be packaged by the application into
     * a single buffer that is passed in via the \p extra parameter.
     * This places the burden on the application of knowing each kernel
     * parameter's size and alignment/padding within the buffer.  Here is
     * an example of using the \p extra parameter in this manner:
     * \code
        size_t argBufferSize;
        char argBuffer[256];

        // populate argBuffer and argBufferSize

        void *config[] = {
            RPP_LAUNCH_PARAM_BUFFER_POINTER, argBuffer,
            RPP_LAUNCH_PARAM_BUFFER_SIZE,    &argBufferSize,
            RPP_LAUNCH_PARAM_END
        };
        status = rppLaunchKernel(f, gx, gy, gz, bx, by, bz, sh, s, NULL, config);
     * \endcode
     *
     * The \p extra parameter exists to allow ::rppLaunchKernel to take
     * additional less commonly used arguments.  \p extra specifies a list of
     * names of extra settings and their corresponding values.  Each extra
     * setting name is immediately followed by the corresponding value.  The
     * list must be terminated with either NULL or ::RPP_LAUNCH_PARAM_END.
     *
     * - ::RPP_LAUNCH_PARAM_END, which indicates the end of the \p extra
     *   array;
     * - ::RPP_LAUNCH_PARAM_BUFFER_POINTER, which specifies that the next
     *   value in \p extra will be a pointer to a buffer containing all
     *   the kernel parameters for launching kernel \p f;
     * - ::RPP_LAUNCH_PARAM_BUFFER_SIZE, which specifies that the next
     *   value in \p extra will be a pointer to a size_t containing the
     *   size of the buffer specified with ::RPP_LAUNCH_PARAM_BUFFER_POINTER;
     *
     * The error ::RPP_ERROR_INVALID_VALUE will be returned if kernel
     * parameters are specified with both \p kernelParams and \p extra
     * (i.e. both \p kernelParams and \p extra are non-NULL).
     *
     * When the kernel \p f is launched via ::rppLaunchKernel(), the previous
     * block shape, shared size and parameter info associated with \p f
     * is overwritten.
     *
     * \param f              - Kernel to launch
     * \param gridDimX       - Width of grid in blocks
     * \param gridDimY       - Height of grid in blocks
     * \param gridDimZ       - Depth of grid in blocks
     * \param blockDimX      - X dimension of each thread block
     * \param blockDimY      - Y dimension of each thread block
     * \param blockDimZ      - Z dimension of each thread block
     * \param sharedMemBytes - Dynamic shared-memory size per thread block in bytes
     * \param hStream        - Stream identifier
     * \param kernelParams   - Array of pointers to kernel parameters
     * \param extra          - Extra options
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_HANDLE,
     * ::RPP_ERROR_INVALID_IMAGE,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_LAUNCH_FAILED,
     * ::RPP_ERROR_LAUNCH_OUT_OF_RESOURCES,
     * ::RPP_ERROR_LAUNCH_TIMEOUT,
     * ::RPP_ERROR_LAUNCH_INCOMPATIBLE_TEXTURING
     *
     * \sa ::rppLaunchKernel
     */
    RPPresult rppLaunchKernel(RPPfunction f, unsigned int gridDimX, unsigned int gridDimY, unsigned int gridDimZ, unsigned int blockDimX, unsigned int blockDimY, unsigned int blockDimZ, unsigned int sharedMemBytes, RPPstream hStream, void **kernelParams, void **extra);

    RPPresult rppLaunchHostFunc(RPPstream hStream, RPPhostFn fn, void *userData);

    /** @} */ /* END RPP_EXEC */

    /* Memory Management */

    /**
     * \defgroup RPP_MEM Memory Management
     *
     * This section describes the memory management functions of the low-level RPP
     * driver API.
     *
     * @{
     */

    /**
     * \brief Creates a 3D RPP array.
     *
     * Reserved for future use.
     *
     * \param pHandle   - Returned array
     * \param pAllocateArray - 3D array descriptor
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_OUT_OF_MEMORY,
     * ::RPP_ERROR_UNKNOWN,
     *
     * \sa ::rppArray3DGetDescriptor, ::rppArrayCreate, ::rppArrayDestroy, ::rppArrayGetDescriptor,
     */
    RPPresult rppArray3DCreate(RPParray *pHandle, const RPP_ARRAY3D_DESCRIPTOR *pAllocateArray);

    /**
     * \brief Get a 3D RPP array descriptor.
     *
     * Reserved for future use.
     *
     * \param pArrayDescriptor   - Returned 3D array descriptor
     * \param hArray - 3D array to get descriptor of
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_HANDLE
     *
     * \sa ::rppArray3DCreate, ::rppArrayCreate, ::rppArrayDestroy, ::rppArrayGetDescriptor,
     */
    RPPresult rppArray3DGetDescriptor(RPP_ARRAY3D_DESCRIPTOR *pArrayDescriptor, RPParray hArray);

    /**
     * \brief Creates a 1D or 2D RPP array.
     *
     * Reserved for future use.
     *
     * \param pHandle   - Returned array
     * \param pAllocateArray - Array descriptor
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_OUT_OF_MEMORY,
     * ::RPP_ERROR_UNKNOWN,
     *
     * \sa ::rppArray3DGetDescriptor, ::rppArray3DCreate, ::rppArrayDestroy, ::rppArrayGetDescriptor,
     */
    RPPresult rppArrayCreate(RPParray *pHandle, const RPP_ARRAY_DESCRIPTOR *pAllocateArray);

    /**
     * \brief Destroys a RPP array.
     *
     * Reserved for future use.
     *
     * \param hArray   - Array to destroy
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_OUT_OF_MEMORY,
     * ::RPP_ERROR_UNKNOWN,
     *
     * \sa ::rppArray3DGetDescriptor, ::rppArray3DCreate, ::rppArrayGetDescriptor, ::rppArray3DGetDescriptor,
     */
    RPPresult rppArrayDestroy(RPParray hArray);

    /**
     * \brief Get a 1D or 2D RPP array descriptor.
     *
     * Reserved for future use.
     *
     * \param pArrayDescriptor   - Returned array descriptor
     * \param hArray    - Array to get descriptor of
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_HANDLE
     *
     * \sa ::rppArray3DCreate, ::rppArrayCreate, ::rppArrayDestroy, ::rppArray3DGetDescriptor,
     */
    RPPresult rppArrayGetDescriptor(RPP_ARRAY_DESCRIPTOR *pArrayDescriptor, RPParray hArray);

    /**
     * \brief Returns a handle to a compute device.
     *
     * Returns in \p *device a device handle given a PCI bus ID string.
     *
     * \param dev      - Returned device handle
     * \param pciBusId - String of PCI bus id.
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_DEVICE,
     *
     * \sa ::rppDeviceGet, ::rppDeviceGetAttribute, ::rppDeviceGetPCIBusId, ::rppDeviceGetByPCIBusId,
     */
    RPPresult rppDeviceGetByPCIBusId(RPPdevice *dev, const char *pciBusId);

    /**
     * \brief Returns a PCI Bus Id string for the device.
     *
     * Returns an ASCII string identifying the device \p dev in the NULL-terminated string
     * pointed to by \* pciBusId. \p len specifies the maximum length of the string that may be
     * returned.
     *
     * \param pciBusId - Returned string of PCI bus id for the device.
     * \param len      - Maximum length of string to store in \p name.
     * \param dev      - Device to get PCI bus ID for.
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_DEVICE,
     *
     * \sa ::rppDeviceGet, ::rppDeviceGetAttribute, ::rppDeviceGetPCIBusId, ::rppDeviceGetByPCIBusId,
     */
    RPPresult rppDeviceGetPCIBusId(char *pciBusId, int len, RPPdevice dev);

    /**
     * \brief Allocates device memory
     *
     * Allocates \p bytesize bytes of linear memory on the device and returns in
     * \p *dptr a pointer to the allocated memory. The \p *dptr is virtual address,
     * and can get the physical device address by rppMemGetPhyAddr().
     * The allocated memory is suitable aligned for any kind of variable.
     * The memory is not cleared. If \p bytesize is 0, ::rppMemAlloc() returns ::RPP_ERROR_INVALID_VALUE.
     *
     * \param dptr     - Returned device pointer
     * \param bytesize - Requested allocation size in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_OUT_OF_MEMORY
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemAlloc(RPPdeviceptr *dptr, size_t bytesize);

    /**
     * \brief Allocates page-locked host memory
     *
     * Allocates \p bytesize bytes of host memory that is page-locked and
     * accessible to the device. The driver tracks the virtual memory ranges
     * allocated with this function and automatically accelerates calls to
     * functions such as ::rppMemcpy(). Since the memory can be accessed directly by
     * the device, it can be read or written with much higher bandwidth than
     * pageable memory obtained with functions such as malloc(). Allocating
     * excessive amounts of memory with ::rppMemAllocHost() may degrade system
     * performance, since it reduces the amount of memory available to the system
     * for paging. As a result, this function is best used sparingly to allocate
     * staging areas for data exchange between host and device.
     *
     * \param pp       - Returned host pointer to page-locked memory
     * \param bytesize - Requested allocation size in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_OUT_OF_MEMORY
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemAllocHost(void **pp, size_t bytesize);

    /**
     * \brief Allocates pitched device memory
     *
     * Reserved for future use.
     *
     * \param dptr     - Returned device pointer
     * \param pPitch   - Returned pitch of allocation in bytes
     * \param WidthInBytes   - Requested allocation width in bytes
     * \param Height   - Requested allocation height in rows
     * \param ElementSizeBytes   - Size of largest reads/writes for range
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_OUT_OF_MEMORY
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemAllocPitch(RPPdeviceptr *dptr, size_t *pPitch, size_t WidthInBytes, size_t Height, unsigned int ElementSizeBytes);

    /**
     * \brief Copies memory.
     *
     * Copies data between two pointer. \p dst and \p src are base pointers of
     * the destination and source, \p ByteCount specifies the number of bytes to copy.
     * This function infers the type of transfer(HtoH, HtoD, DtoD, DtoH) from the pointer values.
     *
     * \param dst      - Destination virtual address space pointer
     * \param src      - Source virtual address space pointer
     * \param ByteCount - Size of memory copy in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpy(RPPdeviceptr dst, RPPdeviceptr src, size_t ByteCount);

    /**
     * \brief Copies memory for 2D arrays.
     *
     * Perform a 2D memory copy according to the parameters specified in pCopy.
     * Currently the type of transfer just support DtoS, StoD and StoS.
     *
     * \param pCopy    - Parameters for the memory copy
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpy2D(const RPP_MEMCPY2D *pCopy);

    /**
     * \brief Copies memory for 2D arrays asynchronously.
     *
     * Perform a 2D memory copy according to the parameters specified in pCopy.
     * Currently the type of transfer just support DtoS, StoD and StoS.
     *
     * \param pCopy    - Parameters for the memory copy
     * \param hStream  - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpy2DAsync(const RPP_MEMCPY2D *pCopy, RPPstream hStream);

    /**
     * \brief Copies memory for 2D arrays asynchronously.
     *
     * Reserved for future use.
     *
     * \param pCopy    - Parameters for the memory copy
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpy2DUnaligned(const RPP_MEMCPY2D *pCopy);

    /**
     * \brief Copies memory for 3D arrays.
     *
     * Perform a 3D memory copy according to the parameters specified in pCopy.
     * Currently the type of transfer just support DtoS, StoD and StoS.
     *
     * \param pCopy    - Parameters for the memory copy
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpy3D(const RPP_MEMCPY3D *pCopy);

    /**
     * \brief Copies memory for 3D arrays asynchronously.
     *
     * Perform a 3D memory copy according to the parameters specified in pCopy.
     * Currently the type of transfer just support DtoS, StoD and StoS.
     *
     * \param pCopy    - Parameters for the memory copy
     * \param hStream  - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpy3DAsync(const RPP_MEMCPY3D *pCopy, RPPstream hStream);

    /**
     * \brief Copies memory for 4D arrays.
     *
     * Perform a 4D memory copy according to the parameters specified in pCopy.
     * Currently the type of transfer just support DtoS, StoD and StoS.
     *
     * \param pCopy    - Parameters for the memory copy
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpy4D(const RPP_MEMCPY4D *pCopy);

    /**
     * \brief Copies memory for 4D arrays asynchronously.
     *
     * Perform a 4D memory copy according to the parameters specified in pCopy.
     * Currently the type of transfer just support DtoS, StoD and StoS.
     *
     * \param pCopy    - Parameters for the memory copy
     * \param hStream  - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpy4DAsync(const RPP_MEMCPY4D *pCopy, RPPstream hStream);

    /**
     * \brief Copies memory asynchronously.
     *
     * Copies data between two pointer. \p dst and \p src are base pointers of
     * the destination and source, \p ByteCount specifies the number of bytes to copy.
     * This function infers the type of transfer(HtoH, HtoD, DtoD, DtoH) from the pointer values.
     *
     * \param dst      - Destination virtual address space pointer
     * \param src      - Source virtual address space pointer
     * \param ByteCount - Size of memory copy in bytes
     * \param hStream  - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpyAsync(RPPdeviceptr dst, RPPdeviceptr src, size_t ByteCount, RPPstream hStream);

    /**
     * \brief Copies memory from Array to Array.
     *
     * Reserved for future use.
     *
     * \param dstArray    - Destination array
     * \param dstOffset   - Offset in bytes of destination array
     * \param srcArray    - Source array
     * \param srcOffset   - Offset in bytes of source array
     * \param ByteCount   - Size of memory copy in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpyAtoA(RPParray dstArray, size_t dstOffset, RPParray srcArray, size_t srcOffset, size_t ByteCount);

    /**
     * \brief Copies memory from Array to Device.
     *
     * Reserved for future use.
     *
     * \param dstDevice   - Destination device pointer
     * \param srcArray    - Source array
     * \param srcOffset   - Offset in bytes of source array
     * \param ByteCount   - Size of memory copy in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpyAtoD(RPPdeviceptr dstDevice, RPParray srcArray, size_t srcOffset, size_t ByteCount);

    /**
     * \brief Copies memory from Array to Host.
     *
     * Reserved for future use.
     *
     * \param dstHost     - Destination host pointer
     * \param srcArray    - Source array
     * \param srcOffset   - Offset in bytes of source array
     * \param ByteCount   - Size of memory copy in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpyAtoH(void *dstHost, RPParray srcArray, size_t srcOffset, size_t ByteCount);

    /**
     * \brief Copies memory from Array to Host asynchronously.
     *
     * Reserved for future use.
     *
     * \param dstHost     - Destination host pointer
     * \param srcArray    - Source array
     * \param srcOffset   - Offset in bytes of source array
     * \param ByteCount   - Size of memory copy in bytes
     * \param hStream     - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpyAtoHAsync(void *dstHost, RPParray srcArray, size_t srcOffset, size_t ByteCount, RPPstream hStream);

    /**
     * \brief Copies memory from Device to Array.
     *
     * Reserved for future use.
     *
     * \param dstArray    - Destination array
     * \param dstOffset   - Offset in bytes of destination array
     * \param srcDevice   - Source device pointer
     * \param ByteCount   - Size of memory copy in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpyDtoA(RPParray dstArray, size_t dstOffset, RPPdeviceptr srcDevice, size_t ByteCount);

    /**
     * \brief Copies memory from Device to Device.
     *
     * Copies from device memory to device memory. \p dstDevice and \p srcDevice are the
     * base pointers of the destination and source. \p ByteCount specifies the number of bytes to copy.
     *
     * \param dstDevice   - Destination device pointer
     * \param srcDevice   - Source device pointer
     * \param ByteCount   - Size of memory copy in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpyDtoD(RPPdeviceptr dstDevice, RPPdeviceptr srcDevice, size_t ByteCount);

    /**
     * \brief Copies memory from Device to Device asynchronously.
     *
     * Copies from device memory to device memory. \p dstDevice and \p srcDevice are the
     * base pointers of the destination and source. \p ByteCount specifies the number of bytes to copy.
     *
     * \param dstDevice   - Destination device pointer
     * \param srcDevice   - Source device pointer
     * \param ByteCount   - Size of memory copy in bytes
     * \param hStream     - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpyDtoDAsync(RPPdeviceptr dstDevice, RPPdeviceptr srcDevice, size_t ByteCount, RPPstream hStream);

    /**
     * \brief Copies memory from Device to Host
     *
     * Copies from device to host memory. \p dstHost and \p srcDevice specify the
     * base pointers of the destination and source, respectively. \p ByteCount
     * specifies the number of bytes to copy.
     *
     * \param dstHost   - Destination host pointer
     * \param srcDevice - Source device pointer
     * \param ByteCount - Size of memory copy in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpyDtoH(void *dstHost, RPPdeviceptr srcDevice, size_t ByteCount);

    /**
     * \brief Copies memory from Device to Host asynchronously
     *
     * Copies from device to host memory. \p dstHost and \p srcDevice specify the
     * base pointers of the destination and source, respectively. \p ByteCount
     * specifies the number of bytes to copy.
     *
     * \param dstHost   - Destination host pointer
     * \param srcDevice - Source device pointer
     * \param ByteCount - Size of memory copy in bytes
     * \param hStream   - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpyDtoHAsync(void *dstHost, RPPdeviceptr srcDevice, size_t ByteCount, RPPstream hStream);

    /**
     * \brief Copies memory from Host to Array.
     *
     * Reserved for future use.
     *
     * \param dstArray    - Destination array
     * \param dstOffset   - Offset in bytes of destination array
     * \param srcHost     - Source host pointer
     * \param ByteCount   - Size of memory copy in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpyHtoA(RPParray dstArray, size_t dstOffset, const void *srcHost, size_t ByteCount);

    /**
     * \brief Copies memory from Host to Array asynchronously.
     *
     * Reserved for future use.
     *
     * \param dstArray    - Destination array
     * \param dstOffset   - Offset in bytes of destination array
     * \param srcHost     - Source host pointer
     * \param ByteCount   - Size of memory copy in bytes
     * \param hStream     - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpyHtoAAsync(RPParray dstArray, size_t dstOffset, const void *srcHost, size_t ByteCount, RPPstream hStream);

    /**
     * \brief Copies memory from Host to Device
     *
     * Copies from host memory to device memory. \p dstDevice and \p srcHost are
     * the base addresses of the destination and source, respectively. \p ByteCount
     * specifies the number of bytes to copy.
     *
     * \param dstDevice - Destination device pointer
     * \param srcHost   - Source host pointer
     * \param ByteCount - Size of memory copy in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpyHtoD(RPPdeviceptr dstDevice, const void *srcHost, size_t ByteCount);

    /**
     * \brief Copies memory from Host to Device asynchronously
     *
     * Copies from host memory to device memory. \p dstDevice and \p srcHost are
     * the base addresses of the destination and source, respectively. \p ByteCount
     * specifies the number of bytes to copy.
     *
     * \param dstDevice - Destination device pointer
     * \param srcHost   - Source host pointer
     * \param ByteCount - Size of memory copy in bytes
     * \param hStream   - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemcpyHtoDAsync(RPPdeviceptr dstDevice, const void *srcHost, size_t ByteCount, RPPstream hStream);

    /**
     * \brief Frees device memory
     *
     * Frees the memory space pointed to by \p dptr, which must have been returned
     * by a previous call to ::rppMemAlloc() or ::rppMemAllocPitch().
     *
     * \param dptr - Pointer to memory to free
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemFree(RPPdeviceptr dptr);

    /**
     * \brief Frees page-locked host memory
     *
     * Frees the memory space pointed to by \p p, which must have been returned by
     * a previous call to ::rppMemAllocHost().
     *
     * \param p - Pointer to memory to free
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemFreeHost(void *p);

    /**
     * \brief Get information on memory allocations.
     *
     * Reserved for future use.
     *
     * \param pbase    - Returned base address
     * \param psize    - Returned size of device memory allocation
     * \param dptr     - Device pointer to query
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_NOT_FOUND,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemGetAddressRange(RPPdeviceptr *pbase, size_t *psize, RPPdeviceptr dptr);

    /**
     * \brief Get free and total memory.
     *
     * Returns in \p *free and \p *total respectively, the free and total amount of memory
     * available for allocation by the RPP context, in bytes.
     *
     * \param free    - Returned free memory in bytes
     * \param total   - Returned total memory in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemGetInfo(size_t *free, size_t *total);

    /**
     * \brief Allocates page-locked host memory
     *
     * Allocates \p bytesize bytes of host memory that is page-locked and accessible
     * to the device. The driver tracks the virtual memory ranges allocated with
     * this function and automatically accelerates calls to functions such as
     * ::rppMemcpyHtoD(). Since the memory can be accessed directly by the device,
     * it can be read or written with much higher bandwidth than pageable memory
     * obtained with functions such as malloc(). Allocating excessive amounts of
     * pinned memory may degrade system performance, since it reduces the amount
     * of memory available to the system for paging. As a result, this function is
     * best used sparingly to allocate staging areas for data exchange between
     * host and device.
     * Currently, the flag must be 1.
     * The memory allocated by this function must be freed with ::rppMemFreeHost().
     *
     * \param pp       - Returned host pointer to page-locked memory
     * \param bytesize - Requested allocation size in bytes
     * \param Flags    - Flags for allocation request
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_OUT_OF_MEMORY
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemHostAlloc(void **pp, size_t bytesize, unsigned int Flags);

    /**
     * \brief Passes back device pointer of mapped pinned memory.
     *
     * Passes back the device pointer \p pdptr corresponding to the mapped, pinned
     * host buffer p allocated by \p rppMemHostAlloc.
     *
     * \param pdptr   - Returned device pointer
     * \param p       - Host pointer
     * \param Flags   - Options (must be 0)
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemHostGetDevicePointer(RPPdeviceptr *pdptr, void *p, unsigned int Flags);

    /**
     * \brief Passes back flags that were used for a pinned allocation.
     *
     * Reserved for future use.
     *
     * \param pFlags  - Returned flags word
     * \param p       - Host pointer
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemHostGetFlags(unsigned int *pFlags, void *p);

    /**
     * \brief Registers an existing host memory range for use by RPP.
     *
     * Reserved for future use.
     *
     * \param pp       - Host pointer to memory to page-lock
     * \param bytesize - Size in bytes of the address range to page-lock
     * \param Flags   - Flags for allocation request
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_OUT_OF_MEMORY,
     * ::RPP_ERROR_HOST_MEMORY_ALREADY_REGISTERED,
     * ::RPP_ERROR_NOT_PERMITTED,
     * ::RPP_ERROR_NOT_SUPPORTED

     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemHostRegister(void *pp, unsigned long long bytesize, unsigned int Flags);

    /**
     * \brief Unregisters a memory range that was registered with rppMemHostRegister.
     *
     * Reserved for future use.
     *
     * \param pp       - Host pointer to memory to unregister
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_OUT_OF_MEMORY,
     * ::RPP_ERROR_HOST_MEMORY_NOT_REGISTERED,
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemHostUnregister(void *pp);

    /**
     * \brief Initializes device memory.
     *
     * Reserved for future use.
     *
     * \param dstDevice   - Destination device pointer
     * \param us          - Value to set
     * \param N           - Number of elements
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemsetD16(RPPdeviceptr dstDevice, unsigned short us, size_t N);

    /**
     * \brief Sets device memory.
     *
     * Reserved for future use.
     *
     * \param dstDevice   - Destination device pointer
     * \param us          - Value to set
     * \param N           - Number of elements
     * \param hStream     - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemsetD16Async(RPPdeviceptr dstDevice, unsigned short us, size_t N, RPPstream hStream);

    /**
     * \brief Initializes device memory.
     *
     * Reserved for future use.
     *
     * \param dstDevice   - Destination device pointer
     * \param dstPitch    - Pitch of destination device pointer
     * \param us          - Value to set
     * \param Width       - Width of row
     * \param Height      - Number of rows
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemsetD2D16(RPPdeviceptr dstDevice, size_t dstPitch, unsigned short us, size_t Width, size_t Height);

    /**
     * \brief Sets device memory.
     *
     * Reserved for future use.
     *
     * \param dstDevice   - Destination device pointer
     * \param dstPitch    - Pitch of destination device pointer
     * \param us          - Value to set
     * \param Width       - Width of row
     * \param Height      - Number of rows
     * \param hStream     - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemsetD2D16Async(RPPdeviceptr dstDevice, size_t dstPitch, unsigned short us, size_t Width, size_t Height, RPPstream hStream);

    /**
     * \brief Initializes device memory.
     *
     * Reserved for future use.
     *
     * \param dstDevice   - Destination device pointer
     * \param dstPitch    - Pitch of destination device pointer
     * \param ui          - Value to set
     * \param Width       - Width of row
     * \param Height      - Number of rows
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemsetD2D32(RPPdeviceptr dstDevice, size_t dstPitch, unsigned int ui, size_t Width, size_t Height);

    /**
     * \brief Sets device memory.
     *
     * Reserved for future use.
     *
     * \param dstDevice   - Destination device pointer
     * \param dstPitch    - Pitch of destination device pointer
     * \param ui          - Value to set
     * \param Width       - Width of row
     * \param Height      - Number of rows
     * \param hStream     - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemsetD2D32Async(RPPdeviceptr dstDevice, size_t dstPitch, unsigned int ui, size_t Width, size_t Height, RPPstream hStream);

    /**
     * \brief Initializes device memory.
     *
     * Reserved for future use.
     *
     * \param dstDevice   - Destination device pointer
     * \param dstPitch    - Pitch of destination device pointer
     * \param uc          - Value to set
     * \param Width       - Width of row
     * \param Height      - Number of rows
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemsetD2D8(RPPdeviceptr dstDevice, size_t dstPitch, unsigned char uc, size_t Width, size_t Height);

    /**
     * \brief Sets device memory.
     *
     * Reserved for future use.
     *
     * \param dstDevice   - Destination device pointer
     * \param dstPitch    - Pitch of destination device pointer
     * \param uc          - Value to set
     * \param Width       - Width of row
     * \param Height      - Number of rows
     * \param hStream     - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemsetD2D8Async(RPPdeviceptr dstDevice, size_t dstPitch, unsigned char uc, size_t Width, size_t Height, RPPstream hStream);

    /**
     * \brief Initializes device memory.
     *
     * Reserved for future use.
     *
     * \param dstDevice   - Destination device pointer
     * \param ui          - Value to set
     * \param N           - Number of elements
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemsetD32(RPPdeviceptr dstDevice, unsigned int ui, size_t N);

    /**
     * \brief Sets device memory.
     *
     * Reserved for future use.
     *
     * \param dstDevice   - Destination device pointer
     * \param ui          - Value to set
     * \param N           - Number of elements
     * \param hStream     - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemsetD32Async(RPPdeviceptr dstDevice, unsigned int ui, size_t N, RPPstream hStream);

    /**
     * \brief Initializes device memory
     *
     * Sets the memory range of \p N 8-bit values to the specified value
     * \p uc.
     *
     * \param dstDevice - Destination device pointer
     * \param uc        - Value to set
     * \param N         - Number of elements
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemsetD8(RPPdeviceptr dstDevice, unsigned char uc, size_t N);

    /**
     * \brief Sets device memory
     *
     * Reserved for future use.
     *
     * \param dstDevice - Destination device pointer
     * \param uc        - Value to set
     * \param N         - Number of elements
     * \param hStream   - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE

     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppMemsetD8Async(RPPdeviceptr dstDevice, unsigned char uc, size_t N, RPPstream hStream);

    /**
     * \brief Returns information about a pointer
     *
     * Reserved for future use.
     *
     * \param data      - Returned pointer attribute value
     * \param attribute - Pointer attribute to query
     * \param ptr       - Pointer
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_DEVICE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppPointerGetAttribute(void *data, RPPpointer_attribute attribute, RPPdeviceptr ptr);
    /** @} */ /* END RPP_MEM */

    /* SRAM Management */

    /**
     * \defgroup RPP_SRAM SRAM Management
     *
     * This section describes the sram management functions of the low-level RPP
     * driver API.
     *
     * @{
     */

    /**
     * \brief Allocates device sram memory
     *
     * Allocates \p bytesize bytes of linear sram memory on the device and returns in
     * \p *dptr a pointer to the allocated sram memory. The \p *dptr is physical sram address,
     * and can get the virtual address by rppMemGetVirtAddr()
     * The allocated memory is suitably aligned for any kind of variable.
     * The memory is not cleared. If \p bytesize is 0, ::rppSramAlloc() returns ::RPP_ERROR_INVALID_VALUE.
     *
     * \param hStream  - Stream identifier
     * \param dptr     - Returned device pointer
     * \param bytesize - Requested allocation size in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_OUT_OF_MEMORY
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppSramAlloc(RPPstream hStream, RPPdeviceptr *dptr, size_t bytesize);

    /**
     * \brief Initializes sram memory
     *
     * Sets the memory range of \p N 8-bit values to the specified value
     * \p uc.
     *
     * \param dstSram   - Destination sram memory pointer
     * \param uc        - Value to set
     * \param N         - Number of elements
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppSramMemsetD8(RPPdeviceptr dstSram, unsigned char uc, size_t N);

    /**
     * \brief Frees device sram memory
     *
     * Frees the memory space pointed to by \p dptr, which must have been returned
     * by a previous call to ::rppSramAlloc().
     *
     * \param hStream - Stream identifier
     * \param dptr - Pointer to memory to free
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemAlloc, ::rppMemFree, ::rppMemAllocHost, ::rppMemFreeHost,
     * ::rppMemcpyHtoD, ::rppMemcpyDtoH,::rppMemsetD8,
     */
    RPPresult rppSramFree(RPPstream hStream, RPPdeviceptr dptr);

    /**
     * \brief Allocates virtual device sram memory
     *
     * Allocates \p bytesize bytes of virt sram memory on the device and returns in
     * \p *dptr a pointer to the allocated sram memory. The \p *dptr is 24bits virt_id and 40 bits sram base address,
     * The virtual sram memory not confilt with the real sram memory alloced by ::rppSramAlloc()
     * The memory is not cleared. If \p bytesize is 0, ::rppVirtSramAlloc() returns ::RPP_ERROR_INVALID_VALUE.
     *
     * \param hStream  - Stream identifier, not used now
     * \param dptr     - Returned device pointer
     * \param bytesize - Requested allocation size in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_OUT_OF_MEMORY
     *
     * \sa ::rppSramAlloc, ::rppSramFree,
     * ::rppMemcpyDtoS, ::rppMemcpyStoD,::rppSramMemsetD8,
     */
    RPPresult rppVirtSramAlloc(RPPstream hStream, RPPdeviceptr *dptr, size_t bytesize);

    /**
     * \brief Frees virtual sram memory
     *
     * Frees the virtual memory space pointed to by \p dptr, which must have been returned
     * by a previous call to ::rppVirtSramAlloc().
     *
     * \param hStream - Stream identifier, not used now
     * \param dptr - Pointer to memory to free
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppSramAlloc, ::rppSramFree,
     * ::rppMemcpyDtoS, ::rppMemcpyStoD,::rppSramMemsetD8,
     */
    RPPresult rppVirtSramFree(RPPstream hStream, RPPdeviceptr dptr);

    /**
     * \brief Copies memory from Host to SRAM
     *
     * Copies from host memory to device SRAM (physical or virtual SRAM) via PCIe DMA.
     * \p dstSram must be allocated by ::rppSramAlloc() or ::rppVirtSramAlloc().
     * \p dstSram and \p srcHost are the base addresses of the destination and source,
     * respectively. \p ByteCount specifies the number of bytes to copy.
     *
     * \param dstSram   - Destination device SRAM pointer
     * \param srcHost   - Source host pointer
     * \param ByteCount - Size of memory copy in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppSramAlloc, ::rppVirtSramAlloc, ::rppMemcpyHtoSAsync,
     * ::rppMemcpyStoH, ::rppMemcpyDtoS, ::rppMemcpyStoD,
     */
    RPPresult rppMemcpyHtoS(RPPdeviceptr dstSram, const void *srcHost, size_t ByteCount);

    /**
     * \brief Copies memory from Host to SRAM asynchronously
     *
     * Copies from host memory to device SRAM (physical or virtual SRAM) via PCIe DMA.
     * \p dstSram must be allocated by ::rppSramAlloc() or ::rppVirtSramAlloc().
     *
     * \param dstSram   - Destination device SRAM pointer
     * \param srcHost   - Source host pointer
     * \param ByteCount - Size of memory copy in bytes
     * \param hStream   - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppSramAlloc, ::rppVirtSramAlloc, ::rppMemcpyHtoS,
     * ::rppMemcpyStoH, ::rppMemcpyStoHAsync,
     */
    RPPresult rppMemcpyHtoSAsync(RPPdeviceptr dstSram, const void *srcHost, size_t ByteCount, RPPstream hStream);

    /**
     * \brief Copies memory from SRAM to Host
     *
     * Copies from device SRAM (physical or virtual SRAM) to host memory via PCIe DMA.
     * \p srcSram must be allocated by ::rppSramAlloc() or ::rppVirtSramAlloc().
     *
     * \param dstHost   - Destination host pointer
     * \param srcSram   - Source device SRAM pointer
     * \param ByteCount - Size of memory copy in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppSramAlloc, ::rppVirtSramAlloc, ::rppMemcpyHtoS, ::rppMemcpyStoHAsync,
     */
    RPPresult rppMemcpyStoH(void *dstHost, RPPdeviceptr srcSram, size_t ByteCount);

    /**
     * \brief Copies memory from SRAM to Host asynchronously
     *
     * Copies from device SRAM (physical or virtual SRAM) to host memory via PCIe DMA.
     * \p srcSram must be allocated by ::rppSramAlloc() or ::rppVirtSramAlloc().
     *
     * \param dstHost   - Destination host pointer
     * \param srcSram   - Source device SRAM pointer
     * \param ByteCount - Size of memory copy in bytes
     * \param hStream   - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppSramAlloc, ::rppVirtSramAlloc, ::rppMemcpyHtoSAsync, ::rppMemcpyStoH,
     */
    RPPresult rppMemcpyStoHAsync(void *dstHost, RPPdeviceptr srcSram, size_t ByteCount, RPPstream hStream);

    /**
     *
     * \brief Copies memory from Device DDR to SRAM
     *
     * Copies from device DDR to device SRAM. \p dstSram and \p srcDevice specify the
     * base pointers of the destination and source, respectively. \p ByteCount
     * specifies the number of bytes to copy.
     *
     * \param dstSram   - Destination device SRAM pointer
     * \param srcDevice - Source device DDR pointer
     * \param ByteCount - Size of memory copy in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppSramAlloc, ::rppSramFree, ::rppSramMemsetD8, ::rppMemcpyStoD,
     * ::rppMemcpyStoS, ::rppMemcpyDtoSAsync,::rppMemcpyStoDAsync,
     */
    RPPresult rppMemcpyDtoS(RPPdeviceptr dstSram, RPPdeviceptr srcDevice, size_t ByteCount);

    /**
     * \brief Copies memory from SRAM to Device DDR
     *
     * Copies from device SRAM to device DDR. \p dstDevice and \p srcSram specify the
     * base pointers of the destination and source, respectively. \p ByteCount
     * specifies the number of bytes to copy.
     *
     * \param dstDevice   - Destination device DDR pointer
     * \param srcSram     - Source device SRAM pointer
     * \param ByteCount - Size of memory copy in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppSramAlloc, ::rppSramFree, ::rppSramMemsetD8, ::rppMemcpyDtoS,
     * ::rppMemcpyStoS, ::rppMemcpyDtoSAsync,::rppMemcpyStoDAsync,
     */
    RPPresult rppMemcpyStoD(RPPdeviceptr dstDevice, RPPdeviceptr srcSram, size_t ByteCount);

    /**
     * \brief Copies memory from SRAM to SRAM
     *
     * Copies from SRAM to SRAM. \p dstSram and \p srcSram specify the
     * base pointers of the destination and source, respectively. \p ByteCount
     * specifies the number of bytes to copy.
     *
     * \param dstSram   - Destination ddevice SRAM pointer
     * \param srcSram   - Source device SRAM pointer
     * \param ByteCount - Size of memory copy in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppSramAlloc, ::rppSramFree, ::rppSramMemsetD8, ::rppMemcpyStoD,
     * ::rppMemcpyDtoS, ::rppMemcpyDtoSAsync,::rppMemcpyStoDAsync,
     */
    RPPresult rppMemcpyStoS(RPPdeviceptr dstSram, RPPdeviceptr srcSram, size_t ByteCount);

    /**
     * \brief Linked copies memory from Device DDR to SRAM
     *
     * Copies from device DDR to device SRAM. \p dstSram and \p srcDevice specify the
     * base pointers of the destination and source, respectively. \p ByteCount
     * specifies the number of bytes to copy.
     *
     * \param dstSram   - Destination device SRAM pointer
     * \param srcDevice - Source device DDR pointer
     * \param ByteCount - Size of memory copy in bytes
     * \param num       - Number of elements
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppSramAlloc, ::rppSramFree, ::rppSramMemsetD8, ::rppMemcpyStoD,
     * ::rppMemcpyStoS, ::rppMemcpyDtoSAsync,::rppMemcpyStoDAsync,
     */
    RPPresult rppMemcpyLinkDtoS(RPPdeviceptr dstSram[], RPPdeviceptr srcDevice[], size_t ByteCount[], const int num);

    /**
     * \brief Linked copies memory from SRAM to Device DDR
     *
     * Copies from device SRAM to device DDR. \p dstDevice and \p srcSram specify the
     * base pointers of the destination and source, respectively. \p ByteCount
     * specifies the number of bytes to copy.
     *
     * \param dstDevice - Destination device DDR pointer
     * \param srcSram   - Source device SRAM pointer
     * \param ByteCount - Size of memory copy in bytes
     * \param num       - Number of elements
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppSramAlloc, ::rppSramFree, ::rppSramMemsetD8, ::rppMemcpyStoD,
     * ::rppMemcpyStoS, ::rppMemcpyDtoSAsync,::rppMemcpyStoDAsync,
     */
    RPPresult rppMemcpyLinkStoD(RPPdeviceptr dstDevice[], RPPdeviceptr srcSram[], size_t ByteCount[], const int num);

    /**
     * \brief Linked copies memory from Device DDR to Device DDR
     *
     * Copies from device DDR to device DDR. \p dstDevice and \p srcDevice specify the
     * base pointers of the destination and source, respectively. \p ByteCount
     * specifies the number of bytes to copy.
     *
     * \param dstDevice - Destination device DDR pointer
     * \param srcDevice - Source device DDR pointer
     * \param ByteCount - Size of memory copy in bytes
     * \param num       - Number of elements
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemcpyDtoD, ::rppMemcpyDtoDAsync, ::rppMemcpyLinkDtoS,
     * ::rppMemcpyLinkStoD,
     */
    RPPresult rppMemcpyLinkDtoD(RPPdeviceptr dstDevice[], RPPdeviceptr srcDevice[], size_t ByteCount[], const int num);

    /**
     * \brief Copies memory from Device DDR to SRAM asynchronously
     *
     * Copies from device DDR to device SRAM asynchronously. \p dstSram and \p srcDevice specify the
     * base pointers of the destination and source, respectively. \p ByteCount
     * specifies the number of bytes to copy.
     *
     * \param dstSram   - Destination device SRAM pointer
     * \param srcDevice - Source device DDR pointer
     * \param ByteCount - Size of memory copy in bytes
     * \param hStream   - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppSramAlloc, ::rppSramFree, ::rppSramMemsetD8, ::rppMemcpyStoD,
     * ::rppMemcpyStoS, ::rppMemcpyDtoSAsync,::rppMemcpyStoDAsync,
     */
    RPPresult rppMemcpyDtoSAsync(RPPdeviceptr dstSram, RPPdeviceptr srcDevice, size_t ByteCount, RPPstream hStream);

    /**
     * \brief Copies memory from SRAM to Device DDR asynchronously
     *
     * Copies from device SRAM to device DDR. \p dstDevice and \p srcSram specify the
     * base pointers of the destination and source, respectively. \p ByteCount
     * specifies the number of bytes to copy.
     *
     * \param dstDevice   - Destination device DDR pointer
     * \param srcSram     - Source device SRAM pointer
     * \param ByteCount - Size of memory copy in bytes
     * \param hStream   - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppSramAlloc, ::rppSramFree, ::rppSramMemsetD8, ::rppMemcpyDtoS,
     * ::rppMemcpyStoS, ::rppMemcpyDtoSAsync,::rppMemcpyStoDAsync,
     */
    RPPresult rppMemcpyStoDAsync(RPPdeviceptr dstDevice, RPPdeviceptr srcSram, size_t ByteCount, RPPstream hStream);

    /**
     * \brief Copies memory from SRAM to SRAM asynchronously
     *
     * Copies from SRAM to SRAM. \p dstSram and \p srcSram specify the
     * base pointers of the destination and source, respectively. \p ByteCount
     * specifies the number of bytes to copy.
     *
     * \param dstSram   - Destination ddevice SRAM pointer
     * \param srcSram   - Source device SRAM pointer
     * \param ByteCount - Size of memory copy in bytes
     * \param hStream   - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppSramAlloc, ::rppSramFree, ::rppSramMemsetD8, ::rppMemcpyStoD,
     * ::rppMemcpyDtoS, ::rppMemcpyDtoSAsync,::rppMemcpyStoDAsync,
     */
    RPPresult rppMemcpyStoSAsync(RPPdeviceptr dstSram, RPPdeviceptr srcSram, size_t ByteCount, RPPstream hStream);

    /**
     * \brief Linked copies memory from Device DDR to SRAM asynchronously
     *
     * Copies from device DDR to device SRAM asynchronously. \p dstSram and \p srcDevice specify the
     * base pointers of the destination and source, respectively. \p ByteCount
     * specifies the number of bytes to copy.
     *
     * \param dstSram   - Destination device SRAM pointer
     * \param srcDevice - Source device DDR pointer
     * \param ByteCount - Size of memory copy in bytes
     * \param num       - Number of elements
     * \param hStream   - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppSramAlloc, ::rppSramFree, ::rppSramMemsetD8, ::rppMemcpyStoD,
     * ::rppMemcpyStoS, ::rppMemcpyDtoSAsync,::rppMemcpyStoDAsync,
     */
    RPPresult rppMemcpyLinkDtoSAsync(RPPdeviceptr dstSram[], RPPdeviceptr srcDevice[], size_t ByteCount[], const int num, RPPstream hStream);

    /**
     * \brief Linked copies memory from SRAM to Device DDR asynchronously
     *
     * Copies from device SRAM to device DDR asynchronously. \p dstDevice and \p srcSram specify the
     * base pointers of the destination and source, respectively. \p ByteCount
     * specifies the number of bytes to copy.
     *
     * \param dstDevice - Destination device DDR pointer
     * \param srcSram   - Source device SRAM pointer
     * \param ByteCount - Size of memory copy in bytes
     * \param num       - Number of elements
     * \param hStream   - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppSramAlloc, ::rppSramFree, ::rppSramMemsetD8, ::rppMemcpyStoD,
     * ::rppMemcpyStoS, ::rppMemcpyDtoSAsync,::rppMemcpyStoDAsync,
     */
    RPPresult rppMemcpyLinkStoDAsync(RPPdeviceptr dstDevice[], RPPdeviceptr srcSram[], size_t ByteCount[], const int num, RPPstream hStream);

    /**
     * \brief Linked copies memory from Device DDR to Device DDR asynchronously
     *
     * Copies from device DDR to device DDR asynchronously. \p dstDevice and \p srcDevice specify the
     * base pointers of the destination and source, respectively. \p ByteCount
     * specifies the number of bytes to copy.
     *
     * \param dstDevice - Destination device DDR pointer
     * \param srcDevice - Source device DDR pointer
     * \param ByteCount - Size of memory copy in bytes
     * \param num       - Number of elements
     * \param hStream   - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemcpyDtoD, ::rppMemcpyDtoDAsync, ::rppMemcpyLinkDtoSAsync,
     * ::rppMemcpyLinkStoDAsync,
     */
    RPPresult rppMemcpyLinkDtoDAsync(RPPdeviceptr dstDevice[], RPPdeviceptr srcDevice[], size_t ByteCount[], const int num, RPPstream hStream);

    /**
     * \brief Allocates MPU memory
     *
     * Allocates \p bytesize bytes of linear MPU memory on the device and returns in
     * \p *dptr a pointer to the allocated mpu memory. The \p *dptr is physical address,
     * and can get the virtual device address by rppMemGetVirtAddr()
     * The allocated memory is suitably aligned for any kind of variable.
     * The memory is not cleared. If \p bytesize is 0, ::rppMpumemAlloc() returns ::RPP_ERROR_INVALID_VALUE.
     *
     * \param dptr     - Returned device MPU memory pointer
     * \param bytesize - Requested allocation size in bytes
     * \param flags    - Requested allocation region in \p RPPmpumem_flags
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_OUT_OF_MEMORY
     *
     * \sa ::rppMpumemFree, ::rppMemcpyHtoM, ::rppMemcpyMtoH, ::rppMpumemMemsetD8, ::rppMpumemMemsetD8Async,
     * ::rppMemcpyHtoMAsync, ::rppMemcpyMtoHAsync,
     */
    RPPresult rppMpumemAlloc(RPPdeviceptr *dptr, size_t bytesize, RPPmpumem_flags flags);

    /**
     * \brief Initializes MPU memory
     *
     * Sets the memory range of \p N 8-bit values to the specified value
     * \p uc.
     *
     * \param dstMpumem   - Destination MPU memory pointer
     * \param uc        - Value to set
     * \param N         - Number of elements
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMpumemAlloc, ::rppMpumemFree, ::rppMemcpyHtoM, ::rppMemcpyMtoH, ::rppMpumemMemsetD8Async,
     * ::rppMemcpyHtoMAsync, ::rppMemcpyMtoHAsync,
     */
    RPPresult rppMpumemMemsetD8(RPPdeviceptr dstMpumem, unsigned char uc, size_t N);

    /**
     * \brief Initializes MPU memory asynchronously
     *
     * Sets the memory range of \p N 8-bit values to the specified value asynchronously
     * \p uc.
     *
     * \param dstMpumem   - Destination MPU memory pointer
     * \param uc        - Value to set
     * \param N         - Number of elements
     * \param hStream   - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMpumemAlloc, ::rppMpumemFree, ::rppMemcpyHtoM, ::rppMemcpyMtoH, ::rppMpumemMemsetD8,
     * ::rppMemcpyHtoMAsync, ::rppMemcpyMtoHAsync,
     */
    RPPresult rppMpumemMemsetD8Async(RPPdeviceptr dstMpumem, unsigned char uc, size_t N, RPPstream hStream);

    /**
     * \brief Frees device MPU memory
     *
     * Frees the memory space pointed to by \p dptr, which must have been returned
     * by a previous call to ::rppMpumemAlloc().
     *
     * \param dptr - Pointer to MPU memory to free
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMpumemAlloc, ::rppMemcpyHtoM, ::rppMemcpyMtoH, ::rppMpumemMemsetD8, ::rppMpumemMemsetD8Async,
     * ::rppMemcpyHtoMAsync, ::rppMemcpyMtoHAsync,
     */
    RPPresult rppMpumemFree(RPPdeviceptr dptr);

    /**
     *
     * \brief Copies memory from Host to MPU memory
     *
     * Copies from host to MPU memory. \p dstMpumem and \p srcHost specify the
     * base pointers of the destination and source, respectively. \p ByteCount
     * specifies the number of bytes to copy.
     *
     * \param dstMpumem   - Destination device MPU memory pointer
     * \param srcHost - Source Host pointer
     * \param ByteCount - Size of memory copy in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMpumemAlloc, ::rppMpumemFree, ::rppMemcpyMtoH, ::rppMpumemMemsetD8, ::rppMpumemMemsetD8Async,
     * ::rppMemcpyHtoMAsync, ::rppMemcpyMtoHAsync,
     */
    RPPresult rppMemcpyHtoM(RPPdeviceptr dstMpumem, const void *srcHost, size_t ByteCount);

    /**
     * \brief Copies from MPU memory to Host
     *
     * Copies from MPU memory to host. \p dstHost and \p srcMpumem specify the
     * base pointers of the destination and source, respectively. \p ByteCount
     * specifies the number of bytes to copy.
     *
     * \param dstHost   - Destination Host pointer
     * \param srcMpumem     - Source MPU memory pointer
     * \param ByteCount - Size of memory copy in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMpumemAlloc, ::rppMpumemFree, ::rppMemcpyHtoM, ::rppMpumemMemsetD8, ::rppMpumemMemsetD8Async,
     * ::rppMemcpyHtoMAsync, ::rppMemcpyMtoHAsync,
     */
    RPPresult rppMemcpyMtoH(void *dstHost, RPPdeviceptr srcMpumem, size_t ByteCount);

    /**
     * \brief Copies memory from Host to MPU memory asynchronously
     *
     * Copies from host to MPU memory asynchronously. \p dstMpumem and \p srcHost specify the
     * base pointers of the destination and source, respectively. \p ByteCount
     * specifies the number of bytes to copy.
     *
     * \param dstMpumem   - Destination MPU memory pointer
     * \param srcHost - Source Host pointer
     * \param ByteCount - Size of memory copy in bytes
     * \param hStream   - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMpumemAlloc, ::rppMpumemFree, ::rppMemcpyHtoM, ::rppMemcpyMtoH, ::rppMpumemMemsetD8, ::rppMpumemMemsetD8Async,
     * ::rppMemcpyMtoHAsync,
     */
    RPPresult rppMemcpyHtoMAsync(RPPdeviceptr dstMpumem, const void *srcHost, size_t ByteCount, RPPstream hStream);

    /**
     * \brief Copies memory from MPU memory to Host asynchronously
     *
     * Copies from MPU memory to host. \p dstHost and \p srcMpumem specify the
     * base pointers of the destination and source, respectively. \p ByteCount
     * specifies the number of bytes to copy.
     *
     * \param dstHost   - Destination Host pointer
     * \param srcMpumem     - Source device MPU memory pointer
     * \param ByteCount - Size of memory copy in bytes
     * \param hStream   - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMpumemAlloc, ::rppMpumemFree, ::rppMemcpyHtoM, ::rppMemcpyMtoH, ::rppMpumemMemsetD8, ::rppMpumemMemsetD8Async,
     * ::rppMemcpyHtoMAsync,
     */
    RPPresult rppMemcpyMtoHAsync(void *dstHost, RPPdeviceptr srcMpumem, size_t ByteCount, RPPstream hStream);

    /**
     * Get physical address of device memory, used in rpp dnn library.
     *
     * Get physical address of device memory by specified virtual address \p virt.
     * Note that this api just support virtual address as the input. For our allcation api,
     * The return address type is below:
     * rppMemAlloc: return virtual address.
     * rppMemAllocHost: return physical address.
     * rppSramAlloc: return physical address.
     * rppMpumemAlloc: return physical address.
     *
     * \param phys - Returned device physical memory pointer
     * \param virt - Specified virtual address
     *
     * \return
     * The pointer of device physical address.
     *
     */
    RPPresult rppMemGetPhyAddr(RPPdeviceptr *phys, RPPdeviceptr virt);

    /**
     * Get virtual address of memory.
     *
     * Get virtual address of memory by specified physical address \p phys.
     * Different memory region maybe have the same physical address,
     * so the \p type also need be specified.
     * Note that this api just support physical address as the input. For our allcation api,
     * The return address type is below:
     * rppMemAlloc: return virtual address.
     * rppMemAllocHost: return physical address.
     * rppSramAlloc: return physical address.
     * rppMpumemAlloc: return physical address.
     *
     * \param phys - Specified physical address
     * \param type - Specified memory type
     * \param virt - Returned device virtual memory pointer
     *
     * \return
     * The pointer of device virtual address.
     *
     */
    RPPresult rppMemGetVirtAddr(RPPdeviceptr *virt, RPPmemorytype type, RPPdeviceptr phys);

    /**
     *
     * \brief Copies memory from Device DDR to SRAM with interleaver mode
     *
     * Copies from device DDR to device SRAM. \p dstSram and \p srcDevice0/srcDevice1 specify the
     * base pointers of the destination and source, respectively.
     * \p ByteCount specifies the number of bytes to copy.
     *
     * \param dstSram   - Destination device SRAM pointer
     * \param srcDevice0 - One of the source device DDR pointer
     * \param srcDevice1 - Another of the source device DDR pointer
     * \param ByteCount - Size of memory copy in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemcpyDtoSInterLeaverAsync, ::rppMemcpyDtoSDeInterLeaver, ::rppMemcpyDtoSDeInterLeaverAsync,
     * ::rppMemcpyStoDInterLeaver, ::rppMemcpyStoDInterLeaverAsync,::rppMemcpyStoDDeInterLeaver,
     * ::rppMemcpyStoDDeInterLeaverAsync,
     */
    RPPresult rppMemcpyDtoSInterLeaver(RPPdeviceptr dstSram, RPPdeviceptr srcDevice0, RPPdeviceptr srcDevice1, size_t ByteCount);

    /**
     *
     * \brief Copies memory from Device DDR to SRAM with interleaver mode asynchronously.
     *
     * Copies from device DDR to device SRAM. \p dstSram and \p srcDevice0/srcDevice1 specify the
     * base pointers of the destination and source, respectively.
     * \p ByteCount specifies the number of bytes to copy.
     *
     * \param dstSram    - Destination device SRAM pointer
     * \param srcDevice0 - One of the source device DDR pointer
     * \param srcDevice1 - Another of the source device DDR pointer
     * \param ByteCount  - Size of memory copy in bytes
     * \param hStream    - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemcpyDtoSInterLeaver, ::rppMemcpyDtoSDeInterLeaver, ::rppMemcpyDtoSDeInterLeaverAsync,
     * ::rppMemcpyStoDInterLeaver, ::rppMemcpyStoDInterLeaverAsync,::rppMemcpyStoDDeInterLeaver,
     * ::rppMemcpyStoDDeInterLeaverAsync,
     */
    RPPresult rppMemcpyDtoSInterLeaverAsync(RPPdeviceptr dstSram, RPPdeviceptr srcDevice0, RPPdeviceptr srcDevice1, size_t ByteCount, RPPstream hStream);

    /**
     *
     * \brief Copies memory from Device DDR to SRAM with deinterleaver mode
     *
     * Copies from device DDR to device SRAM. \p dstSram0/dstSram1 and \p srcDevice specify the
     * base pointers of the destination and source, respectively.
     * \p ByteCount specifies the number of bytes to copy.
     *
     * \param dstSram0  - One of the destination device SRAM pointer
     * \param dstSram1  - Another of the destination device SRAM pointer
     * \param srcDevice - Source device DDR pointer
     * \param ByteCount - Size of memory copy in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemcpyDtoSInterLeaver, ::rppMemcpyDtoSInterLeaverAsync, ::rppMemcpyDtoSDeInterLeaverAsync,
     * ::rppMemcpyStoDInterLeaver, ::rppMemcpyStoDInterLeaverAsync,::rppMemcpyStoDDeInterLeaver,
     * ::rppMemcpyStoDDeInterLeaverAsync,
     */
    RPPresult rppMemcpyDtoSDeInterLeaver(RPPdeviceptr dstSram0, RPPdeviceptr dstSram1, RPPdeviceptr srcDevice, size_t ByteCount);

    /**
     *
     * \brief Copies memory from Device DDR to SRAM with deinterleaver mode asynchronously.
     *
     * Copies from device DDR to device SRAM. \p dstSram0/dstSram1 and \p srcDevice specify the
     * base pointers of the destination and source, respectively.
     * \p ByteCount specifies the number of bytes to copy.
     *
     * \param dstSram0  - One of the destination device SRAM pointer
     * \param dstSram1  - Another of the destination device SRAM pointer
     * \param srcDevice - Source device DDR pointer
     * \param ByteCount - Size of memory copy in bytes
     * \param hStream   - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemcpyDtoSInterLeaver, ::rppMemcpyDtoSInterLeaverAsync, ::rppMemcpyDtoSDeInterLeaverAsync,
     * ::rppMemcpyStoDInterLeaver, ::rppMemcpyStoDInterLeaverAsync,::rppMemcpyStoDDeInterLeaver,
     * ::rppMemcpyStoDDeInterLeaverAsync,
     */
    RPPresult rppMemcpyDtoSDeInterLeaverAsync(RPPdeviceptr dstSram0, RPPdeviceptr dstSram1, RPPdeviceptr srcDevice, size_t ByteCount, RPPstream hStream);

    /**
     *
     * \brief Copies memory from SRAM to Device DDR with interleaver mode
     *
     * Copies from device SRAM to device DDR . \p dstDevice and \p srcSram0/srcSram1 specify the
     * base pointers of the destination and source, respectively.
     * \p ByteCount specifies the number of bytes to copy.
     *
     * \param dstDevice  - Destination device DDR pointer
     * \param srcSram0   - One of the source device SRAM pointer
     * \param srcSram1   - Another of the source device SRAM pointer
     * \param ByteCount  - Size of memory copy in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemcpyDtoSInterLeaver, ::rppMemcpyDtoSInterLeaverAsync, ::rppMemcpyDtoSDeInterLeaver, ::rppMemcpyDtoSDeInterLeaverAsync,
     * ::rppMemcpyStoDInterLeaverAsync,::rppMemcpyStoDDeInterLeaver, ::rppMemcpyStoDDeInterLeaverAsync,
     */
    RPPresult rppMemcpyStoDInterLeaver(RPPdeviceptr dstDevice, RPPdeviceptr srcSram0, RPPdeviceptr srcSram1, size_t ByteCount);

    /**
     *
     * \brief Copies memory from SRAM to Device DDR with interleaver mode asynchronously
     *
     * Copies from device SRAM to device DDR . \p dstDevice and \p srcSram0/srcSram1 specify the
     * base pointers of the destination and source, respectively.
     * \p ByteCount specifies the number of bytes to copy.
     *
     * \param dstDevice  - Destination device DDR pointer
     * \param srcSram0   - One of the source device SRAM pointer
     * \param srcSram1   - Another of the source device SRAM pointer
     * \param ByteCount  - Size of memory copy in bytes
     * \param hStream    - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemcpyDtoSInterLeaver, ::rppMemcpyDtoSInterLeaverAsync, ::rppMemcpyDtoSDeInterLeaver, ::rppMemcpyDtoSDeInterLeaverAsync,
     * ::rppMemcpyStoDInterLeaverAsync,::rppMemcpyStoDDeInterLeaver, ::rppMemcpyStoDDeInterLeaverAsync,
     */
    RPPresult rppMemcpyStoDInterLeaverAsync(RPPdeviceptr dstDevice, RPPdeviceptr srcSram0, RPPdeviceptr srcSram1, size_t ByteCount, RPPstream hStream);

    /**
     *
     * \brief Copies memory from SRAM to Device DDR with deinterleaver mode
     *
     * Copies from device SRAM to device DDR . \p dstDevice0/dstDevice1 and \p srcSram specify the
     * base pointers of the destination and source, respectively.
     * \p ByteCount specifies the number of bytes to copy.
     *
     * \param dstDevice0  - One of the destination device DDR pointer
     * \param dstDevice1  - Another of the destination device DDR pointer
     * \param srcSram     - Source device SRAM pointer
     * \param ByteCount   - Size of memory copy in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemcpyDtoSInterLeaver, ::rppMemcpyDtoSInterLeaverAsync, ::rppMemcpyDtoSDeInterLeaver, ::rppMemcpyDtoSDeInterLeaverAsync,
     * ::rppMemcpyStoDInterLeaver, ::rppMemcpyStoDInterLeaverAsync, ::rppMemcpyStoDDeInterLeaverAsync,
     */
    RPPresult rppMemcpyStoDDeInterLeaver(RPPdeviceptr dstDevice0, RPPdeviceptr dstDevice1, RPPdeviceptr srcSram, size_t ByteCount);

    /**
     *
     * \brief Copies memory from SRAM to Device DDR with deinterleaver mode asynchronously
     *
     * Copies from device SRAM to device DDR . \p dstDevice0/dstDevice1 and \p srcSram specify the
     * base pointers of the destination and source, respectively.
     * \p ByteCount specifies the number of bytes to copy.
     *
     * \param dstDevice0  - One of the destination device DDR pointer
     * \param dstDevice1  - Another of the destination device DDR pointer
     * \param srcSram     - Source device SRAM pointer
     * \param ByteCount   - Size of memory copy in bytes
     * \param hStream     - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppMemcpyDtoSInterLeaver, ::rppMemcpyDtoSInterLeaverAsync, ::rppMemcpyDtoSDeInterLeaver, ::rppMemcpyDtoSDeInterLeaverAsync,
     * ::rppMemcpyStoDInterLeaver, ::rppMemcpyStoDInterLeaverAsync, ::rppMemcpyStoDDeInterLeaverAsync,
     */
    RPPresult rppMemcpyStoDDeInterLeaverAsync(RPPdeviceptr dstDevice0, RPPdeviceptr dstDevice1, RPPdeviceptr srcSram, size_t ByteCount, RPPstream hStream);

    /** @} */ /* END RPP_SRAM */

    /* Stream Management */

    /**
     * \defgroup RPP_STREAM Stream Management
     *
     * This section describes the stream management functions of the low-level RPP
     * driver API.
     *
     * @{
     */

    /**
     * \brief Add a callback to a stream.
     *
     * Reserved for future use.
     *
     * \param hStream  - Stream to add callback to
     * \param callback - The function to call once preceding sream operations are complete
     * \param userData - User specified data to be passed to the callback function
     * \param flags    - Reserved for future use, must be 0
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_HANDLE,
     * ::RPP_ERROR_NOT_SUPPORTED
     *
     * \sa ::rppStreamCreate,
     * ::rppStreamDestroy,
     * ::rppStreamQuery,
     * ::rppStreamSynchronize,
     * ::rppStreamWaitEvent
     */
    RPPresult rppStreamAddCallback(RPPstream hStream, RPPstreamCallback callback, void *userData, unsigned int flags);

    /**
     * \brief Create a stream.
     *
     * Creates a stream and returns a handle in \p phStream. The \p Flags argument determines
     * behaviors of the stream. Currently, the \p Flags must be RPP_STREAM_DEFAULT.
     *
     * \param phStream - Returned newly created stream
     * \param Flags    - Parameters for stream creation
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_OUT_OF_MEMORY
     *
     * \sa ::rppStreamCreate,
     * ::rppStreamDestroy,
     * ::rppStreamQuery,
     * ::rppStreamSynchronize,
     * ::rppStreamWaitEvent
     */
    RPPresult rppStreamCreate(RPPstream *phStream, unsigned int Flags);

    /**
     * \brief Destroys a stream.
     *
     * Destroys the stream specified by \p hStream.
     * In case the device is still doing work in the stream \p hStream when \p rppStreamDestroy()
     * is called, the function will return immediately and the resources associated with
     * \p hStream will be released automatically once the device has completed all work in \p hStream.
     *
     * \param hStream - Stream to destroy
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_HANDLE,
     * ::RPP_ERROR_INVALID_VALUE
     *
     * \sa ::rppStreamCreate,
     * ::rppStreamQuery,
     * ::rppStreamSynchronize,
     * ::rppStreamWaitEvent
     */
    RPPresult rppStreamDestroy(RPPstream hStream);

    /**
     * \brief Query the context associated with a stream.
     *
     * Reserved for future use.
     *
     * \param hStream - Handle to the stream to be queried
     * \param pctx    - Returned context associated with the stream
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_HANDLE
     *
     * \sa ::rppStreamCreate,
     * ::rppStreamQuery,
     * ::rppStreamSynchronize,
     * ::rppStreamWaitEvent
     */
    RPPresult rppStreamGetCtx(RPPstream hStream, RPPcontext *pctx);

    /**
     * \brief Query the flags of a given stream.
     *
     * Reserved for future use.
     *
     * \param hStream - Handle to the stream to be queried
     * \param flags   - Pointer to an unsigned integer in which the stream's flags are returned.
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_HANDLE,
     * ::RPP_ERROR_OUT_OF_MEMORY
     *
     * \sa ::rppStreamCreate,
     * ::rppStreamQuery,
     * ::rppStreamSynchronize,
     * ::rppStreamWaitEvent
     */
    RPPresult rppStreamGetFlags(RPPstream hStream, unsigned int *flags);

    /**
     * \brief Query the priority of a given stream.
     *
     * Reserved for future use.
     *
     * \param hStream - Handle to the stream to be queried
     * \param priority - Pointer to an signed integer in which the stream's priority are returned.
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_HANDLE,
     * ::RPP_ERROR_OUT_OF_MEMORY
     *
     * \sa ::rppStreamCreate,
     * ::rppStreamQuery,
     * ::rppStreamSynchronize,
     * ::rppStreamWaitEvent
     */
    RPPresult rppStreamGetPriority(RPPstream hStream, int *priority);

    /**
     * \brief Determine status of a stream.
     *
     * Reserved for future use.
     *
     * \param hStream - Stream to query status of
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_HANDLE,
     * ::RPP_ERROR_NOT_READY
     *
     * \sa ::rppStreamCreate,
     * ::rppStreamQuery,
     * ::rppStreamSynchronize,
     * ::rppStreamWaitEvent
     */
    RPPresult rppStreamQuery(RPPstream hStream);

    /**
     * \brief Wait until a stream's tasks are completed.
     *
     * The CPU thread will waits until the device has completed all operations
     * in the stream specified by \p hStream.
     *
     * \param hStream - Stream to wait for
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_HANDLE
     * ::RPP_ERROR_UNKNOWN
     *
     * \sa ::rppStreamCreate,
     * ::rppStreamQuery,
     * ::rppStreamSynchronize,
     * ::rppStreamWaitEvent
     */
    RPPresult rppStreamSynchronize(RPPstream hStream);

    /**
     * \brief Make a stream wait on an event.
     *
     * Makes all future work submitted to \p hStream wait for all work caputed in \p hEvent.
     * See rppEventRecord() for details on what is captured by an event. The synchronization
     * will be performed efficiently on the device when applicable. \p hEvent may be
     * from a different context or device than \p hStream.
     *
     * \param hStream - Stream to wait
     * \param hEvent  - Event to wait on (may not be NULL)
     * \param Flags   - Parameters for the operation (must be 0)
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_HANDLE
     *
     * \sa ::rppStreamCreate,
     * ::rppStreamQuery,
     * ::rppStreamSynchronize,
     * ::rppStreamWaitEvent
     */
    RPPresult rppStreamWaitEvent(RPPstream hStream, RPPevent hEvent, unsigned int Flags);

    /** @} */ /* END RPP_STREAM */

    /* Event Management */

    /**
     * \defgroup RPP_EVENT Event Management
     *
     * This section describes the event management functions of the low-level RPP
     * driver API.
     *
     * @{
     */

    /**
     * \brief Create an event.
     *
     * Creates an event \p phEvent for the current context with the flags specified via \p Flags.
     * Valid flags include:
     * RPP_EVENT_DEFAULT: Default event creation flag.
     * RPP_EVENT_DISABLE_TIMING: Specifies that the created event does not need to record timing data.
     *
     * \param phEvent - Returned newly created event
     * \param Flags   - Event creation flags
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_OUT_OF_MEMORY
     *
     * \sa ::rppEventRecord,
     * ::rppEventQuery,
     * ::rppEventSynchronize,
     * ::rppEventDestroy,
     * ::rppEventElapsedTime
     */
    RPPresult rppEventCreate(RPPevent *phEvent, unsigned int Flags);

    /**
     * \brief Destroys an event.
     *
     * Destroys the event specified by \p hEvent.
     * An event may be destroyed before it is complete. In this case, the call does not
     * block on completion of the event, and any associated resources will automatically
     * be released asynchronously at completion.
     *
     * \param hEvent - Event to destroy
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_HANDLE
     *
     * \sa ::rppEventRecord,
     * ::rppEventQuery,
     * ::rppEventSynchronize,
     * ::rppEventCreate,
     * ::rppEventElapsedTime
     */
    RPPresult rppEventDestroy(RPPevent hEvent);

    /**
     * \brief Computes the elapsed time between two events.
     *
     * Computes the elapsed time between two events (in milliseconds with a resolution of
     * around 0.5 microseconds). Any number of other different stream operations could
     * execute in between the two measured events, thus altering the timing in a significant way.
     * If rppEventRecord() has not been called on either event then
     * RPP_ERROR_INVALID_HANDLE is returned. If rppEventRecord() has been called on
     * both events but one or both of them has not yet been completed, RPP_ERROR_NOT_READY
     * is returned. If either event was created with the RPP_EVENT_DISABLE_TIMING flag,
     * then this function will return RPP_ERROR_INVALID_HANDLE.
     *
     * \param pMilliseconds - Time between \p hStart and \p hEnd in ms
     * \param hStart        - Starting event
     * \param hEnd          - Ending event
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_HANDLE
     * ::RPP_ERROR_NOT_READY
     *
     * \sa ::rppEventRecord,
     * ::rppEventQuery,
     * ::rppEventSynchronize,
     * ::rppEventCreate,
     * ::rppEventDestroy
     */
    RPPresult rppEventElapsedTime(float *pMilliseconds, RPPevent hStart, RPPevent hEnd);

    /**
     * \brief Queries an event's status.
     *
     * Queries the status of all work currently captured by \p hEvent.
     * Returns RPP_SUCCESS if all captured work has been completed, or RPP_ERROR_NOT_READY
     * if any captured work is incomplete.
     *
     * \param hEvent - Event to query
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_HANDLE,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_NOT_READY
     *
     * \sa ::rppEventRecord,
     * ::rppEventElapsedTime,
     * ::rppEventSynchronize,
     * ::rppEventCreate,
     * ::rppEventDestroy
     */
    RPPresult rppEventQuery(RPPevent hEvent);

    /**
     * \brief Records an event.
     *
     * Captures in \p hEvent the contents of \p hStream at the time of this call.
     * \p hEvent and \p hStream must be from the same context. Calls such as \p rppEventQuery()
     * or \p rppStreamWaitEvent() will then examine or wait for completion of the work
     * that was captured. Uses of \p hStream after this call do not modify hEvent.
     * \p rppEventRecord() can be called multiple times on the same event and will
     * overwrite the previously captured state. Other APIs such as rppStreamWaitEvent()
     * use the most recently captured state at the time of the API call, and are not
     * affected by later calls to rppEventRecord(). Before the first call to \p rppEventRecord(),
     * an event represents an empty set of work, so for example rppEventQuery() would return RPP_SUCCESS.
     *
     * \param hEvent  - Event to record
     * \param hStream - Stream to record event for
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_HANDLE,
     * ::RPP_ERROR_INVALID_VALUE,
     *
     * \sa ::rppEventQuery,
     * ::rppEventElapsedTime,
     * ::rppEventSynchronize,
     * ::rppEventCreate,
     * ::rppEventDestroy
     */
    RPPresult rppEventRecord(RPPevent hEvent, RPPstream hStream);


    /**
     * Wait until the completion of all device work preceding the most recent
     * call to rppEventRecord() (in the appropriate compute streams, as specified
     * by the arguments to rppEventRecord()).
     *
     * If rppEventRecord() has not been called on hEvent, RPP_SUCCESS is returned
     * immediately.
     *
     * Waiting for an event that was created with the RPP_EVENT_BLOCKING_SYNC flag
     * will cause the calling CPU thread to block until the event has been
     * completed by the device. If the RPP_EVENT_BLOCKING_SYNC flag has not been
     * set, then the CPU thread will busy-wait until the event has been completed
     * by the device.
     *
     * Parameters:
     *     phEvent     - Event to reset
     *
     * Returns:
     *     RPP_SUCCESS, RPP_ERROR_DEINITIALIZED, RPP_ERROR_NOT_INITIALIZED,
     *     RPP_ERROR_INVALID_CONTEXT, RPP_ERROR_INVALID_HANDLE
     *
     * Note:
     *     Note that this function may also return error codes from previous,
     *     asynchronous launches.
     *
     * See also:
     *     rppEventCreate, rppEventRecord, rppEventQuery, rppEventDestroy,
     *     rppEventElapsedTime
     */
    RPPresult rppEventReset(RPPevent hEvent, RPPstream hStream);

    /**
     * \brief Waits for an event to complete.
     *
     * Waits until the completion of all work currently captured in \p hEvent.
     * See \p rppEventRecord() for details on what is captured by an event.
     *
     * \param hEvent  - Event to wait for
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_HANDLE,
     *
     * \sa ::rppEventQuery,
     * ::rppEventElapsedTime,
     * ::rppEventRecord,
     * ::rppEventCreate,
     * ::rppEventDestroy
     */
    RPPresult rppEventSynchronize(RPPevent hEvent);
    /** @} */ /* END RPP_EVENT */

    /* Profiling */

    /**
     * \defgroup RPP_PROFILE Profiling
     *
     * This section describes the profiling functions of the low-level RPP
     * driver API.
     *
     * @{
     */

    /**
     * \brief Initialize the profiling.
     *
     * Waits until the completion of all work currently captured in \p hEvent.
     * See \p rppEventRecord() for details on what is captured by an event.
     *
     * \param configFile  - Name of the config file that lists the counters/options for profiling.
     * \param outputFile  - Name of the output file where the profiling results will be stored.
     * \param outputMode  - Currently, it must be RPP_OUT_CSV.
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_PROFILER_DISABLED
     *
     * \sa ::rppProfilerStart, ::rppProfilerStop
     */
    RPPresult rppProfilerInitialize(const char *configFile, const char *outputFile, RPPoutput_mode outputMode);

    /**
     * \brief Enable profiling.
     *
     * Enables profile collection by the active profiling tool for the current \p context.
     * If profiling is already enabled, then rppProfilerStart() has no effect.
     * \p rppProfilerStart and \p rppProfilerStop APIs are used to programmatically control the
     * profiling granularity by allowing profiling to be done only on selective pieces of code.
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_PROFILER_ALREADY_STARTED
     *
     * \sa ::rppProfilerInitialize, ::rppProfilerStop,
     */
    RPPresult rppProfilerStart(void);

    /**
     * \brief Disable profiling.
     *
     * Disables profile collection by the active profiling tool for the current context.
     * If profiling is already disabled, then rppProfilerStop() has no effect.
     * \p rppProfilerStart and \p rppProfilerStop APIs are used to programmatically control the
     * profiling granularity by allowing profiling to be done only on selective pieces of code.
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_PROFILER_ALREADY_STOPPED
     *
     * \sa ::rppProfilerInitialize, ::rppProfilerStart,
     */
    RPPresult rppProfilerStop(void);

    /** @} */ /* END RPP_PROFILE */

    /* RPP Extension */
    /**
     * \defgroup RPP_EXTENSION Extension Function
     *
     * This section describes some extension functions of the low-level RPP
     * driver API.
     *
     * @{
     */

    /**
     *
     * \brief Decrements (locks) the semaphore pointed to by sem asynchronous.
     *
     * Decrements (locks) the RPP semaphore pointed to by sem. The concept of RPP Semaphore
     * is the same as the CPU semaphore, used to protect access to critical resources.
     *
     * \param sem       - Semaphore identifier, all supported RPP semaphore list at \p RPPsemtype_enum
     * \param hStream   - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_UNKNOWN
     *
     */
    RPPresult rppSemWait(uint32_t sem, RPPstream hStream);

    /**
     *
     * \brief Increments (locks) the semaphore pointed to by sem asynchronous.
     *
     * Increments (unlocks) the RPP semaphore pointed to by sem. The concept of RPP Semaphore
     * is the same as the CPU semaphore, used to protect access to critical resources.
     *
     * \param sem       - Semaphore identifier, all supported RPP semaphore list at \p RPPsemtype_enum
     * \param hStream   - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_UNKNOWN
     *
     */
    RPPresult rppSemPost(uint32_t sem, RPPstream hStream);

    /**
     *
     * \brief Set the freqency level in DFS mode
     *
     * Add a node to a stream to adjust the freqency level.
     *
     * \param level       - the freqency level, all supported freqency level list at \p RPPDFSFreqLevel_enum
     * \param hStream   - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_UNKNOWN
     *
     */
    RPPresult rppDFSSetFreqAsync(RPPDFSFreqLevel level, RPPstream hStream);

    /**
     *
     * \brief Set the flexible freqency level
     *
     * Add a node to a stream to adjust the freqency level.
     *
     * \param freq       - the addjusted freqency
     * \param hStream   - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_UNKNOWN
     *
     */
    RPPresult rppDFSSetFlexibleFreqAsync(RPPDFSFlexibleFreq freq, RPPstream hStream);

    /**
     *
     * \brief Set the power mode of RPP Device
     *
     * Set the RPP deivce power mode.
     *
     * \param pwrmode       - the power mode, all supported power mode list at \p RPPPwrMode_enum
     * \param dev   - device identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_UNKNOWN
     *
     */
    RPPresult rppDeviceSetPwrMode(RPPPwrMode pwrmode, RPPdevice dev);

    /**
     *
     * \brief Get the power mode of RPP Device
     *
     * Get the RPP deivce power mode.
     *
     * \param pwrmode   - the power mode, all supported power mode list at \p RPPPwrMode_enum
     * \param dev       - device identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_UNKNOWN
     *
     */
    RPPresult rppDeviceGetPwrMode(RPPPwrMode *pwrmode, RPPdevice dev);


    /**
     *
     * \brief Set the work mode of RPP Device
     *
     * Set the RPP deivce work mode.
     *
     * \param workmode       - the work mode, all supported work mode list at \p RPPWorkMode_enum
     * \param dev           - device identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_UNKNOWN
     *
     */
    RPPresult rppDeviceSetWorkMode(RPPWorkMode workmode, RPPdevice dev);

    /**
     *
     * \brief Get the work mode of RPP Device
     *
     * Get the RPP deivce work mode.
     *
     * \param workmode   - the work mode, all supported work mode list at \p RPPWorkMode_enum
     * \param dev       - device identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_UNKNOWN
     *
     */
    RPPresult rppDeviceGetWorkMode(RPPWorkMode *workmode, RPPdevice dev);


    /**
     *
     * \brief Record the all nodes of the stream.
     *
     * Record all nodes of the stream
     *
     * \param hStream   - Stream identifier
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_UNKNOWN
     *
     */
    RPPresult rppStreamRecord(RPPstream hStream);

    /**
     *
     * \brief Modify the input and output.
     *
     * Modify the input of the first CDMA node to \p in and output of the last CDMA node to \p out,
     * Note: Not support H2DAsync and D2HAsync yet.
     *
     * \param hStream   - Stream identifier
     * \param in        - Input of the first CDMA node, set to 0 if the input address not changed
     * \param out       - Output of the last CDMA node, set to 0 if the output address not changed
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_UNKNOWN
     *
     */
    RPPresult rppStreamSetInOut(RPPstream hStream, RPPdeviceptr in, RPPdeviceptr out);

    /**
     *
     * \brief Replay the recorded stream.
     *
     * Replay the recorded stream.
     * Note: Not support H2DAsync and D2HAsync yet.
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_UNKNOWN
     *
     */
    RPPresult rppReplay();

#if 0
RPPresult rppDeviceRegRead(RPPDevice_ctx *pDevCtx, uint32_t regAddr, uint32_t *rData);
RPPresult rppDeviceRegWrite(RPPDevice_ctx *pDevCtx, uint32_t regAddr, uint32_t wData);
#else
    /** @deprecated [Use rppDeviceRegRead32 instead] */
    RPPresult rppDeviceRegRead(RPPRegRegion region, uint32_t regAddr, uint32_t regLen, void *rData);
    /** @deprecated [Use rppDeviceRegWrite32 instead] */
    RPPresult rppDeviceRegWrite(RPPRegRegion region, uint32_t regAddr, uint32_t regLen, void *wData);
#endif

    RPPresult rppDeviceRegRead32(uint64_t addr, uint32_t *value, RPPdevice dev);
    RPPresult rppDeviceRegWrite32(uint64_t addr, uint32_t value, RPPdevice dev);

    RPPresult rppDeviceGetLimit(size_t *pvalue, RPPlimit limit, RPPdevice dev);
    RPPresult rppDeviceSetLimit(RPPlimit limit, size_t value, RPPdevice dev);
    /** @} */ /* END RPP_EXTENSION */

    /**
     * \brief Begins graph capture on a stream
     *
     * Begin graph capture on \p hStream. When a stream is in capture mode, all operations
     * pushed into the stream will not be executed, but will instead be captured into
     * a graph, which will be returned via ::rppStreamEndCapture. Capture may not be initiated
     * if \p stream is RPP_STREAM_LEGACY. Capture must be ended on the same stream in which
     * it was initiated, and it may only be initiated if the stream is not already in capture
     * mode. The capture mode may be queried via ::rppStreamIsCapturing. A unique id
     * representing the capture sequence may be queried via ::rppStreamGetCaptureInfo.
     *
     * If \p mode is not ::RPP_STREAM_CAPTURE_MODE_RELAXED, ::rppStreamEndCapture must be
     * called on this stream from the same thread.
     *
     * \param hStream - Stream in which to initiate capture
     * \param mode    - Controls the interaction of this capture sequence with other API
     *                  calls that are potentially unsafe. For more details see
     *                  ::cuThreadExchangeStreamCaptureMode.
     *
     * \note Kernels captured using this API must not use texture and surface references.
     *       Reading or writing through any texture or surface reference is undefined
     *       behavior. This restriction does not apply to texture and surface objects.
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE
     * \notefnerr
     *
     * \sa
     * ::rppStreamCreate,
     * ::rppStreamIsCapturing,
     * ::rppStreamEndCapture,
     * ::cuThreadExchangeStreamCaptureMode
     */
    RPPresult rppStreamBeginCapture(RPPstream hStream, RPPstreamCaptureMode mode);

    /**
     * \brief Ends capture on a stream, returning the captured graph
     *
     * End capture on \p hStream, returning the captured graph via \p phGraph.
     * Capture must have been initiated on \p hStream via a call to ::rppStreamBeginCapture.
     * If capture was invalidated, due to a violation of the rules of stream capture, then
     * a NULL graph will be returned.
     *
     * If the \p mode argument to ::rppStreamBeginCapture was not
     * ::RPP_STREAM_CAPTURE_MODE_RELAXED, this call must be from the same thread as
     * ::rppStreamBeginCapture.
     *
     * \param hStream - Stream to query
     * \param phGraph - The captured graph
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_STREAM_CAPTURE_WRONG_THREAD
     * \notefnerr
     *
     * \sa
     * ::rppStreamCreate,
     * ::rppStreamBeginCapture,
     * ::rppStreamIsCapturing
     */
    RPPresult rppStreamEndCapture(RPPstream hStream, RPPgraph *phGraph);

    /**
     * \brief Returns a stream's capture status
     *
     * Return the capture status of \p hStream via \p captureStatus. After a successful
     * call, \p *captureStatus will contain one of the following:
     * - ::RPP_STREAM_CAPTURE_STATUS_NONE: The stream is not capturing.
     * - ::RPP_STREAM_CAPTURE_STATUS_ACTIVE: The stream is capturing.
     * - ::RPP_STREAM_CAPTURE_STATUS_INVALIDATED: The stream was capturing but an error
     *   has invalidated the capture sequence. The capture sequence must be terminated
     *   with ::rppStreamEndCapture on the stream where it was initiated in order to
     *   continue using \p hStream.
     *
     * Note that, if this is called on ::RPP_STREAM_LEGACY (the "null stream") while
     * a blocking stream in the same context is capturing, it will return
     * ::RPP_ERROR_STREAM_CAPTURE_IMPLICIT and \p *captureStatus is unspecified
     * after the call. The blocking stream capture is not invalidated.
     *
     * When a blocking stream is capturing, the legacy stream is in an
     * unusable state until the blocking stream capture is terminated. The legacy
     * stream is not supported for stream capture, but attempted use would have an
     * implicit dependency on the capturing stream(s).
     *
     * \param hStream       - Stream to query
     * \param captureStatus - Returns the stream's capture status
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_STREAM_CAPTURE_IMPLICIT
     * \notefnerr
     *
     * \sa
     * ::rppStreamCreate,
     * ::rppStreamBeginCapture,
     * ::rppStreamEndCapture
     */
    RPPresult rppStreamIsCapturing(RPPstream hStream, RPPstreamCaptureStatus *captureStatus);

    /**
     * \defgroup RPP_GRAPH Graph Management
     *
     * ___MANBRIEF___ graph management functions of the low-level RPP driver API
     * (___CURRENT_FILE___) ___ENDMANBRIEF___
     *
     * This section describes the graph management functions of the low-level RPP
     * driver application programming interface.
     *
     * Typical flow: ::rppGraphCreate (or capture) -> add nodes -> ::rppGraphInstantiate
     * or ::rppGraphInstantiateWithParams -> ::rppGraphLaunch. See docs/api/graph-training-v1
     * for usage, constraints, and performance notes.
     *
     * @{
     */

    /**
     * \brief Creates a graph
     *
     * Creates an empty graph, which is returned via \p phGraph.
     *
     * \param phGraph - Returns newly created graph
     * \param flags   - Graph creation flags in ::RPPgraph_flags
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_OUT_OF_MEMORY
     * \note_graph_thread_safety
     * \note ::RPP_GRAPH_NON_BLOCKING allows other streams to access SRAM during graph execution;
     *       coordinate virt_sram regions or avoid virt_sram to prevent data races.
     * \note Graphs with DFS (::RPP_GRAPH_NODE_TYPE_SET_FREQ) capture nodes may affect work on other streams.
     * \notefnerr
     *
     * \sa
     * ::rppGraphAddChildGraphNode,
     * ::rppGraphAddEmptyNode,
     * ::rppGraphAddKernelNode,
     * ::rppGraphAddHostNode,
     * ::rppGraphAddMemcpyNode,
     * ::rppGraphAddMemsetNode,
     * ::rppGraphInstantiate,
     * ::rppGraphDestroy,
     * ::rppGraphGetNodes,
     * ::rppGraphGetRootNodes,
     * ::rppGraphGetEdges,
     * ::rppGraphClone
     */
    RPPresult rppGraphCreate(RPPgraph *phGraph, unsigned int flags);

#if 1
    /**
     * \brief Creates a kernel execution node and adds it to a graph
     *
     * Creates a new kernel execution node and adds it to \p hGraph with \p numDependencies
     * dependencies specified via \p dependencies and arguments specified in \p nodeParams.
     * It is possible for \p numDependencies to be 0, in which case the node will be placed
     * at the root of the graph. \p dependencies may not have any duplicate entries.
     * A handle to the new node will be returned in \p phGraphNode.
     *
     * The RPP_KERNEL_NODE_PARAMS structure is defined as:
     *
     * \code
     *  typedef struct RPP_KERNEL_NODE_PARAMS_st {
     *      RPPfunction func;
     *      unsigned int gridDimX;
     *      unsigned int gridDimY;
     *      unsigned int gridDimZ;
     *      unsigned int blockDimX;
     *      unsigned int blockDimY;
     *      unsigned int blockDimZ;
     *      unsigned int sharedMemBytes;
     *      void **kernelParams;
     *      void **extra;
     *  } RPP_KERNEL_NODE_PARAMS;
     * \endcode
     *
     * When the graph is launched, the node will invoke kernel \p func on a (\p gridDimX x
     * \p gridDimY x \p gridDimZ) grid of blocks. Each block contains
     * (\p blockDimX x \p blockDimY x \p blockDimZ) threads.
     *
     * \p sharedMemBytes sets the amount of dynamic shared memory that will be
     * available to each thread block.
     *
     * Kernel parameters to \p func can be specified in one of two ways:
     *
     * 1) Kernel parameters can be specified via \p kernelParams. If the kernel has N
     * parameters, then \p kernelParams needs to be an array of N pointers. Each pointer,
     * from \p kernelParams[0] to \p kernelParams[N-1], points to the region of memory from which the actual
     * parameter will be copied. The number of kernel parameters and their offsets and sizes do not need
     * to be specified as that information is retrieved directly from the kernel's image.
     *
     * 2) Kernel parameters can also be packaged by the application into a single buffer that is passed in
     * via \p extra. This places the burden on the application of knowing each kernel
     * parameter's size and alignment/padding within the buffer. The \p extra parameter exists
     * to allow this function to take additional less commonly used arguments. \p extra specifies
     * a list of names of extra settings and their corresponding values. Each extra setting name is
     * immediately followed by the corresponding value. The list must be terminated with either NULL or
     * RPP_LAUNCH_PARAM_END.
     *
     * - ::RPP_LAUNCH_PARAM_END, which indicates the end of the \p extra
     *   array;
     * - ::RPP_LAUNCH_PARAM_BUFFER_POINTER, which specifies that the next
     *   value in \p extra will be a pointer to a buffer
     *   containing all the kernel parameters for launching kernel
     *   \p func;
     * - ::RPP_LAUNCH_PARAM_BUFFER_SIZE, which specifies that the next
     *   value in \p extra will be a pointer to a size_t
     *   containing the size of the buffer specified with
     *   ::RPP_LAUNCH_PARAM_BUFFER_POINTER;
     *
     * The error ::RPP_ERROR_INVALID_VALUE will be returned if kernel parameters are specified with both
     * \p kernelParams and \p extra (i.e. both \p kernelParams and
     * \p extra are non-NULL).
     *
     * The \p kernelParams or \p extra array, as well as the argument values it points to,
     * are copied during this call.
     *
     * \note Kernels launched using graphs must not use texture and surface references. Reading or
     *       writing through any texture or surface reference is undefined behavior.
     *       This restriction does not apply to texture and surface objects.
     *
     * \param phGraphNode     - Returns newly created node
     * \param hGraph          - Graph to which to add the node
     * \param dependencies    - Dependencies of the node
     * \param numDependencies - Number of dependencies
     * \param nodeParams      - Parameters for the GPU execution node
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::cuLaunchKernel,
     * ::rppGraphKernelNodeGetParams,
     * ::rppGraphKernelNodeSetParams,
     * ::rppGraphCreate,
     * ::rppGraphDestroyNode,
     * ::rppGraphAddChildGraphNode,
     * ::rppGraphAddEmptyNode,
     * ::rppGraphAddHostNode,
     * ::rppGraphAddMemcpyNode,
     * ::rppGraphAddMemsetNode
     */
    RPPresult rppGraphAddKernelNode(RPPgraphNode *phGraphNode, RPPgraph hGraph, const RPPgraphNode *dependencies, size_t numDependencies, const RPP_KERNEL_NODE_PARAMS *nodeParams);

    /**
     * \brief Returns a kernel node's parameters
     *
     * Returns the parameters of kernel node \p hNode in \p nodeParams.
     * The \p kernelParams or \p extra array returned in \p nodeParams,
     * as well as the argument values it points to, are owned by the node.
     * This memory remains valid until the node is destroyed or its
     * parameters are modified, and should not be modified
     * directly. Use ::rppGraphKernelNodeSetParams to update the
     * parameters of this node.
     *
     * The params will contain either \p kernelParams or \p extra,
     * according to which of these was most recently set on the node.
     *
     * \param hNode      - Node to get the parameters for
     * \param nodeParams - Pointer to return the parameters
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::cuLaunchKernel,
     * ::rppGraphAddKernelNode,
     * ::rppGraphKernelNodeSetParams
     */
    RPPresult rppGraphKernelNodeGetParams(RPPgraphNode hNode, RPP_KERNEL_NODE_PARAMS *nodeParams);

    /**
     * \brief Sets a kernel node's parameters on the graph definition
     *
     * Sets the parameters of kernel node \p hNode to \p nodeParams on the host-side graph.
     * Does not modify any existing ::RPPgraphExec; call ::rppGraphInstantiate again or use
     * ::rppGraphExecKernelNodeSetParams to update an instantiated graphexec.
     *
     * \param hNode      - Node to set the parameters for
     * \param nodeParams - Parameters to copy
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_HANDLE,
     * ::RPP_ERROR_OUT_OF_MEMORY
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::cuLaunchKernel,
     * ::rppGraphAddKernelNode,
     * ::rppGraphKernelNodeGetParams
     */
    RPPresult rppGraphKernelNodeSetParams(RPPgraphNode hNode, const RPP_KERNEL_NODE_PARAMS *nodeParams);

    /**
     * \brief Creates a memcpy node and adds it to a graph
     *
     * Creates a new memcpy node and adds it to \p hGraph with \p numDependencies
     * dependencies specified via \p dependencies.
     * It is possible for \p numDependencies to be 0, in which case the node will be placed
     * at the root of the graph. \p dependencies may not have any duplicate entries.
     * A handle to the new node will be returned in \p phGraphNode.
     *
     * When the graph is launched, the node will perform the memcpy described by \p copyParams.
     * See ::rppMemcpy3D() for a description of the structure and its restrictions.
     *
     * Memcpy nodes have some additional restrictions with regards to managed memory, if the
     * system contains at least one device which has a zero value for the device attribute
     * ::RPP_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS. If one or more of the operands refer
     * to managed memory, then using the memory type ::RPP_MEMORYTYPE_UNIFIED is disallowed
     * for those operand(s). The managed memory will be treated as residing on either the
     * host or the device, depending on which memory type is specified.
     *
     * \param phGraphNode     - Returns newly created node
     * \param hGraph          - Graph to which to add the node
     * \param dependencies    - Dependencies of the node
     * \param numDependencies - Number of dependencies
     * \param copyParams      - Parameters for the memory copy
     * \param ctx             - Context on which to run the node
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphMemcpyNodeGetParams,
     * ::rppGraphMemcpyNodeSetParams,
     * ::rppGraphCreate,
     * ::rppGraphDestroyNode,
     * ::rppGraphAddChildGraphNode,
     * ::rppGraphAddEmptyNode,
     * ::rppGraphAddKernelNode,
     * ::rppGraphAddHostNode,
     * ::rppGraphAddMemsetNode
     */
    RPPresult rppGraphAddMemcpyNode(RPPgraphNode *phGraphNode, RPPgraph hGraph, const RPPgraphNode *dependencies, size_t numDependencies, const RPP_MEMCPY3D *copyParams, RPPcontext ctx);

    /**
     * \brief Returns a memcpy node's parameters
     *
     * Returns the parameters of memcpy node \p hNode in \p nodeParams.
     *
     * \param hNode      - Node to get the parameters for
     * \param nodeParams - Pointer to return the parameters
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphAddMemcpyNode,
     * ::rppGraphMemcpyNodeSetParams
     */
    RPPresult rppGraphMemcpyNodeGetParams(RPPgraphNode hNode, RPP_MEMCPY3D *nodeParams);

    /**
     * \brief Sets a memcpy node's parameters on the graph definition
     *
     * Sets the parameters of memcpy node \p hNode to \p nodeParams on the host-side graph.
     * Does not modify any existing ::RPPgraphExec; use ::rppGraphExecMemcpyNodeSetParams for
     * the current graphexec. Memcpy operands must stay in the same context, 1-dimensional,
     * with unchanged memory mapping and non-zero length (same rules as graphexec update).
     *
     * \param hNode      - Node to set the parameters for
     * \param nodeParams - Parameters to copy
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE,
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphAddMemcpyNode,
     * ::rppGraphMemcpyNodeGetParams
     */
    RPPresult rppGraphMemcpyNodeSetParams(RPPgraphNode hNode, const RPP_MEMCPY3D *nodeParams);

    /**
     * \brief Captures an indirect memcpy descriptor update on a stream
     *
     * Records a ::RPP_GRAPH_NODE_TYPE_MEMCPY_INDIRECT_UPDATE node that resolves source or
     * destination addresses via a device-side table or base+offset (see ::RPP_MEMCPY_INDIRECT_UPDATE_PARAMS).
     * Used with stream capture or explicit graph construction before instantiate.
     *
     * \param hGraph      - Graph that owns the target memcpy node
     * \param hNode       - Target memcpy graph node (may be NULL during capture)
     * \param copyParams  - Indirect descriptor update parameters
     * \param ctx         - Context on which to run the node
     * \param stream      - Stream on which to capture the indirect-update node
     *
     * \sa ::rppGraphExecMemcpyNodeSetIndirectParamsAsync
     */
    RPPresult rppGraphMemcpyNodeSetIndirectParamsAsync(RPPgraph hGraph, RPPgraphNode hNode, const RPP_MEMCPY_INDIRECT_UPDATE_PARAMS *copyParams, RPPcontext ctx, RPPstream stream);

    /**
     * \brief Sets parameters on a captured indirect-update graph node
     *
     * \param hGraph      - Graph that owns the update and target nodes
     * \param hNode       - ::RPP_GRAPH_NODE_TYPE_MEMCPY_INDIRECT_UPDATE node to update
     * \param nodeParams  - Target memcpy node plus ::RPP_MEMCPY_INDIRECT_UPDATE_PARAMS
     *
     * \sa ::rppGraphMemcpyNodeSetIndirectParamsAsync
     */
    RPPresult rppGraphMemcpyIndirectUpdateNodeSetParams(RPPgraph hGraph, RPPgraphNode hNode, const RPP_MEMCPY_INDIRECT_UPDATE_NODE_PARAMS *nodeParams);

    /**
     * \brief Creates a memset node and adds it to a graph
     *
     * Creates a new memset node and adds it to \p hGraph with \p numDependencies
     * dependencies specified via \p dependencies.
     * It is possible for \p numDependencies to be 0, in which case the node will be placed
     * at the root of the graph. \p dependencies may not have any duplicate entries.
     * A handle to the new node will be returned in \p phGraphNode.
     *
     * The element size must be 1, 2, or 4 bytes.
     * When the graph is launched, the node will perform the memset described by \p memsetParams.
     *
     * \param phGraphNode     - Returns newly created node
     * \param hGraph          - Graph to which to add the node
     * \param dependencies    - Dependencies of the node
     * \param numDependencies - Number of dependencies
     * \param memsetParams    - Parameters for the memory set
     * \param ctx             - Context on which to run the node
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_CONTEXT
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphMemsetNodeGetParams,
     * ::rppGraphMemsetNodeSetParams,
     * ::rppGraphCreate,
     * ::rppGraphDestroyNode,
     * ::rppGraphAddChildGraphNode,
     * ::rppGraphAddEmptyNode,
     * ::rppGraphAddKernelNode,
     * ::rppGraphAddHostNode,
     * ::rppGraphAddMemcpyNode
     */
    RPPresult rppGraphAddMemsetNode(RPPgraphNode *phGraphNode, RPPgraph hGraph, const RPPgraphNode *dependencies, size_t numDependencies, const RPP_MEMSET_NODE_PARAMS *memsetParams, RPPcontext ctx);

    /**
     * \brief Returns a memset node's parameters
     *
     * Returns the parameters of memset node \p hNode in \p nodeParams.
     *
     * \param hNode      - Node to get the parameters for
     * \param nodeParams - Pointer to return the parameters
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphAddMemsetNode,
     * ::rppGraphMemsetNodeSetParams
     */
    RPPresult rppGraphMemsetNodeGetParams(RPPgraphNode hNode, RPP_MEMSET_NODE_PARAMS *nodeParams);

    /**
     * \brief Sets a memset node's parameters
     *
     * Sets the parameters of memset node \p hNode to \p nodeParams.
     *
     * \param hNode      - Node to set the parameters for
     * \param nodeParams - Parameters to copy
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphAddMemsetNode,
     * ::rppGraphMemsetNodeGetParams
     */
    RPPresult rppGraphMemsetNodeSetParams(RPPgraphNode hNode, const RPP_MEMSET_NODE_PARAMS *nodeParams);

    /**
     * \brief Creates a host execution node and adds it to a graph
     *
     * Creates a new CPU execution node and adds it to \p hGraph with \p numDependencies
     * dependencies specified via \p dependencies and arguments specified in \p nodeParams.
     * It is possible for \p numDependencies to be 0, in which case the node will be placed
     * at the root of the graph. \p dependencies may not have any duplicate entries.
     * A handle to the new node will be returned in \p phGraphNode.
     *
     * When the graph is launched, the node will invoke the specified CPU function.
     * Host nodes are not supported under MPS with pre-Volta GPUs.
     *
     * \param phGraphNode     - Returns newly created node
     * \param hGraph          - Graph to which to add the node
     * \param dependencies    - Dependencies of the node
     * \param numDependencies - Number of dependencies
     * \param nodeParams      - Parameters for the host node
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_NOT_SUPPORTED,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::cuLaunchHostFunc,
     * ::rppGraphHostNodeGetParams,
     * ::rppGraphHostNodeSetParams,
     * ::rppGraphCreate,
     * ::rppGraphDestroyNode,
     * ::rppGraphAddChildGraphNode,
     * ::rppGraphAddEmptyNode,
     * ::rppGraphAddKernelNode,
     * ::rppGraphAddMemcpyNode,
     * ::rppGraphAddMemsetNode
     */
    RPPresult rppGraphAddHostNode(RPPgraphNode *phGraphNode, RPPgraph hGraph, const RPPgraphNode *dependencies, size_t numDependencies, const RPP_HOST_NODE_PARAMS *nodeParams);

    /**
     * \brief Returns a host node's parameters
     *
     * Returns the parameters of host node \p hNode in \p nodeParams.
     *
     * \param hNode      - Node to get the parameters for
     * \param nodeParams - Pointer to return the parameters
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::cuLaunchHostFunc,
     * ::rppGraphAddHostNode,
     * ::rppGraphHostNodeSetParams
     */
    RPPresult rppGraphHostNodeGetParams(RPPgraphNode hNode, RPP_HOST_NODE_PARAMS *nodeParams);

    /**
     * \brief Sets a host node's parameters
     *
     * Sets the parameters of host node \p hNode to \p nodeParams.
     *
     * \param hNode      - Node to set the parameters for
     * \param nodeParams - Parameters to copy
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::cuLaunchHostFunc,
     * ::rppGraphAddHostNode,
     * ::rppGraphHostNodeGetParams
     */
    RPPresult rppGraphHostNodeSetParams(RPPgraphNode hNode, const RPP_HOST_NODE_PARAMS *nodeParams);

    /**
     * \brief Creates a child graph node and adds it to a graph
     *
     * Creates a new node which executes an embedded graph, and adds it to \p hGraph with
     * \p numDependencies dependencies specified via \p dependencies.
     * It is possible for \p numDependencies to be 0, in which case the node will be placed
     * at the root of the graph. \p dependencies may not have any duplicate entries.
     * A handle to the new node will be returned in \p phGraphNode.
     *
     * The node executes an embedded child graph. The child graph is cloned in this call.
     *
     * Phase-1 constraints: parent graph must use branch 0 only and contain only child-graph
     * nodes (no kernel/memcpy mixed at the top level); multiple children run sequentially;
     * nested or parallel top-level child graphs are not supported.
     * Parent and each child must be instantiated separately; one parent ::rppGraphLaunch
     * schedules all children. Replace bindings with ::rppGraphUpdateChildGraph (definition) or
     * ::rppGraphExecUpdateChildGraphExec (one graphexec instance).
     *
     * \param phGraphNode     - Returns newly created node
     * \param hGraph          - Graph to which to add the node
     * \param dependencies    - Dependencies of the node
     * \param numDependencies - Number of dependencies
     * \param childGraph      - The graph to clone into this node
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE,
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphChildGraphNodeGetGraph,
     * ::rppGraphCreate,
     * ::rppGraphDestroyNode,
     * ::rppGraphAddEmptyNode,
     * ::rppGraphAddKernelNode,
     * ::rppGraphAddHostNode,
     * ::rppGraphAddMemcpyNode,
     * ::rppGraphAddMemsetNode,
     * ::rppGraphClone
     */
    RPPresult rppGraphAddChildGraphNode(RPPgraphNode *phGraphNode, RPPgraph hGraph, const RPPgraphNode *dependencies, size_t numDependencies, RPPgraph childGraph);

    /**
    /**
     * \brief Adds a child graphexec node to a graph
     *
     * Creates a child-graph wrapper node that references a caller-owned, pre-instantiated
     * child graphexec instead of a child graph definition. This allows the caller to
     * destroy and finalize the child graph before composing the parent graph:
     *
     * \code
     * rppStreamEndCapture(stream, &childGraph);
     * rppGraphInstantiateWithParams(&childGraphExec, childGraph, &instParams); // CHILD_EXEC flag
     * rppGraphDestroy(childGraph);
     * rppGraphExecFinalize(childGraphExec, NULL);
     * rppGraphAddChildGraphexecNode(&node, mainGraph, NULL, 0, childGraphExec);
     * \endcode
     *
     * \p childGraphExec must be created with ::RPP_GRAPH_INSTANTIATE_FLAG_CHILD_EXEC in the
     * same context as \p hGraph, fully instantiated, and not in-flight. The caller retains
     * ownership of \p childGraphExec; destroying the parent graphexec does not destroy it.
     *
     * Phase-1 constraints match ::rppGraphAddChildGraphNode.
     *
     * \param phGraphNode      - Returns newly created node
     * \param hGraph           - Graph to which to add the node
     * \param dependencies     - Dependencies of the node
     * \param numDependencies  - Number of dependencies
     * \param childGraphExec   - Pre-instantiated child graphexec to embed
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_HANDLE,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_NOT_READY,
     * ::RPP_ERROR_NOT_SUPPORTED,
     * ::RPP_ERROR_OUT_OF_MEMORY
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphAddChildGraphNode,
     * ::rppGraphExecUpdateChildGraphExec,
     * ::rppGraphExecFinalize,
     * ::RPP_GRAPH_INSTANTIATE_FLAG_CHILD_EXEC
     */
    RPPresult rppGraphAddChildGraphexecNode(RPPgraphNode *phGraphNode, RPPgraph hGraph, const RPPgraphNode *dependencies, size_t numDependencies, RPPgraphExec childGraphExec);

    /**
     * \brief Creates an MPU message node and adds it to a graph
     *
     * Creates a generic MPU message node and adds it to \p hGraph with
     * \p numDependencies dependencies specified via \p dependencies.
     * \p nodeParams->reserved0 must be 0. \p nodeParams->flags may be 0 or
     * ::RPP_MPU_NODE_FLAG_WAIT_COMPLETE.
     *
     * Phase-1 follows the current graph dependency limitations: dependency arguments
     * are accepted by the API shape, while ML graph execution still uses branch-0
     * construction order for this node family.
     *
     * \param phGraphNode     - Returns newly created node
     * \param hGraph          - Graph to which to add the node
     * \param dependencies    - Dependencies of the node
     * \param numDependencies - Number of dependencies
     * \param nodeParams      - MPU message node parameters
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_HANDLE,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_OUT_OF_MEMORY
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphExecDynamicSelectGraphNodeSetParams,
     * ::rppGraphCreate,
     * ::rppGraphDestroyNode
     */
    RPPresult rppGraphAddDynamicSelectGraphNode(RPPgraphNode *phGraphNode, RPPgraph hGraph, const RPPgraphNode *dependencies, size_t numDependencies, const RPP_DYNAMIC_SELECT_GRAPH_NODE_PARAMS *nodeParams);

    /**
     * \brief Replaces one child graph bound to an existing child graph node
     *
     * Replaces the child graph referenced by \p targetChildNode in \p mainGraph.
     * The wrapper node location is preserved. Any instantiated graphexec belonging to
     * \p mainGraph is refreshed through the graph-exec update path.
     *
     * \param mainGraph       - Parent graph containing the target child wrapper node
     * \param targetChildNode - Existing child wrapper node in \p mainGraph to update
     * \param replaceParams   - Replacement parameters
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_HANDLE,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_NOT_SUPPORTED,
     * ::RPP_ERROR_NOT_READY,
     * ::RPP_ERROR_OUT_OF_MEMORY,
     * ::RPP_ERROR_GRAPH_EXEC_UPDATE_FAILURE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphAddChildGraphNode,
     * ::rppGraphExecUpdate
     */
    RPPresult rppGraphUpdateChildGraph(
        RPPgraph mainGraph,
        RPPgraphNode targetChildNode,
        const RPP_CHILD_GRAPH_REPLACE_PARAMS *replaceParams);

    /**
     * \brief Gets a handle to the embedded graph of a child graph node
     *
     * Gets a handle to the embedded graph in a child graph node. This call
     * does not clone the graph. Changes to the graph will be reflected in
     * the node, and the node retains ownership of the graph.
     *
     * \param hNode   - Node to get the embedded graph for
     * \param phGraph - Location to store a handle to the graph
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE,
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphAddChildGraphNode,
     * ::rppGraphNodeFindInClone
     */
    RPPresult rppGraphChildGraphNodeGetGraph(RPPgraphNode hNode, RPPgraph *phGraph);

    /**
     * \brief Creates an empty node and adds it to a graph
     *
     * Creates a new node which performs no operation, and adds it to \p hGraph with
     * \p numDependencies dependencies specified via \p dependencies.
     * It is possible for \p numDependencies to be 0, in which case the node will be placed
     * at the root of the graph. \p dependencies may not have any duplicate entries.
     * A handle to the new node will be returned in \p phGraphNode.
     *
     * An empty node performs no operation during execution, but can be used for
     * transitive ordering. For example, a phased execution graph with 2 groups of n
     * nodes with a barrier between them can be represented using an empty node and
     * 2*n dependency edges, rather than no empty node and n^2 dependency edges.
     *
     * \param phGraphNode     - Returns newly created node
     * \param hGraph          - Graph to which to add the node
     * \param dependencies    - Dependencies of the node
     * \param numDependencies - Number of dependencies
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE,
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphCreate,
     * ::rppGraphDestroyNode,
     * ::rppGraphAddChildGraphNode,
     * ::rppGraphAddKernelNode,
     * ::rppGraphAddHostNode,
     * ::rppGraphAddMemcpyNode,
     * ::rppGraphAddMemsetNode
     */
    RPPresult rppGraphAddEmptyNode(RPPgraphNode *phGraphNode, RPPgraph hGraph, const RPPgraphNode *dependencies, size_t numDependencies);

#endif

    /**
     * \brief Clones a graph
     *
     * This function creates a copy of \p originalGraph and returns it in \p * phGraphClone.
     * All parameters are copied into the cloned graph. The original graph may be modified
     * after this call without affecting the clone.
     *
     * Child graph nodes in the original graph are recursively copied into the clone.
     *
     * \param phGraphClone  - Returns newly created cloned graph
     * \param originalGraph - Graph to clone
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_OUT_OF_MEMORY
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphCreate,
     * ::rppGraphNodeFindInClone
     */
    RPPresult rppGraphClone(RPPgraph *phGraphClone, RPPgraph originalGraph);

    /**
     * \brief Finds a cloned version of a node
     *
     * This function returns the node in \p hClonedGraph corresponding to \p hOriginalNode
     * in the original graph.
     *
     * \p hClonedGraph must have been cloned from \p hOriginalGraph via ::rppGraphClone.
     * \p hOriginalNode must have been in \p hOriginalGraph at the time of the call to
     * ::rppGraphClone, and the corresponding cloned node in \p hClonedGraph must not have
     * been removed. The cloned node is then returned via \p phClonedNode.
     *
     * \param phNode  - Returns handle to the cloned node
     * \param hOriginalNode - Handle to the original node
     * \param hClonedGraph - Cloned graph to query
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_INVALID_VALUE,
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphClone
     */
    RPPresult rppGraphNodeFindInClone(RPPgraphNode *phNode, RPPgraphNode hOriginalNode, RPPgraph hClonedGraph);

    /**
     * \brief Returns a node's type
     *
     * Returns the node type of \p hNode in \p type.
     *
     * \param hNode - Node to query
     * \param type  - Pointer to return the node type
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphGetNodes,
     * ::rppGraphGetRootNodes,
     * ::rppGraphChildGraphNodeGetGraph,
     * ::rppGraphKernelNodeGetParams,
     * ::rppGraphKernelNodeSetParams,
     * ::rppGraphHostNodeGetParams,
     * ::rppGraphHostNodeSetParams,
     * ::rppGraphMemcpyNodeGetParams,
     * ::rppGraphMemcpyNodeSetParams,
     * ::rppGraphMemsetNodeGetParams,
     * ::rppGraphMemsetNodeSetParams
     */
    RPPresult rppGraphNodeGetType(RPPgraphNode hNode, RPPgraphNodeType *type);

    /**
     * \brief Returns a graph's nodes
     *
     * Returns a list of \p hGraph's nodes. \p nodes may be NULL, in which case this
     * function will return the number of nodes in \p numNodes. Otherwise,
     * \p numNodes entries will be filled in. If \p numNodes is higher than the actual
     * number of nodes, the remaining entries in \p nodes will be set to NULL, and the
     * number of nodes actually obtained will be returned in \p numNodes.
     *
     * \param hGraph   - Graph to query
     * \param nodes    - Pointer to return the nodes
     * \param numNodes - See description
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphCreate,
     * ::rppGraphGetRootNodes,
     * ::rppGraphGetEdges,
     * ::rppGraphNodeGetType,
     * ::rppGraphNodeGetDependencies,
     * ::rppGraphNodeGetDependentNodes
     */
    RPPresult rppGraphGetNodes(RPPgraph hGraph, RPPgraphNode *nodes, size_t *numNodes);

    /**
     * \brief Returns a graph's root nodes
     *
     * Returns a list of \p hGraph's root nodes. \p rootNodes may be NULL, in which case this
     * function will return the number of root nodes in \p numRootNodes. Otherwise,
     * \p numRootNodes entries will be filled in. If \p numRootNodes is higher than the actual
     * number of root nodes, the remaining entries in \p rootNodes will be set to NULL, and the
     * number of nodes actually obtained will be returned in \p numRootNodes.
     *
     * \param hGraph       - Graph to query
     * \param rootNodes    - Pointer to return the root nodes
     * \param numRootNodes - See description
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphCreate,
     * ::rppGraphGetNodes,
     * ::rppGraphGetEdges,
     * ::rppGraphNodeGetType,
     * ::rppGraphNodeGetDependencies,
     * ::rppGraphNodeGetDependentNodes
     */
    RPPresult rppGraphGetRootNodes(RPPgraph hGraph, RPPgraphNode *rootNodes, size_t *numRootNodes);

    /**
     * \brief Returns a graph's dependency edges
     *
     * Returns a list of \p hGraph's dependency edges. Edges are returned via corresponding
     * indices in \p from and \p to; that is, the node in \p to[i] has a dependency on the
     * node in \p from[i]. \p from and \p to may both be NULL, in which
     * case this function only returns the number of edges in \p numEdges. Otherwise,
     * \p numEdges entries will be filled in. If \p numEdges is higher than the actual
     * number of edges, the remaining entries in \p from and \p to will be set to NULL, and
     * the number of edges actually returned will be written to \p numEdges.
     *
     * \param hGraph   - Graph to get the edges from
     * \param from     - Location to return edge endpoints
     * \param to       - Location to return edge endpoints
     * \param numEdges - See description
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphGetNodes,
     * ::rppGraphGetRootNodes,
     * ::rppGraphAddDependencies,
     * ::rppGraphRemoveDependencies,
     * ::rppGraphNodeGetDependencies,
     * ::rppGraphNodeGetDependentNodes
     */
    RPPresult rppGraphGetEdges(RPPgraph hGraph, RPPgraphNode *from, RPPgraphNode *to, size_t *numEdges);

    /**
     * \brief Returns a node's dependencies
     *
     * Returns a list of \p node's dependencies. \p dependencies may be NULL, in which case this
     * function will return the number of dependencies in \p numDependencies. Otherwise,
     * \p numDependencies entries will be filled in. If \p numDependencies is higher than the actual
     * number of dependencies, the remaining entries in \p dependencies will be set to NULL, and the
     * number of nodes actually obtained will be returned in \p numDependencies.
     *
     * \param hNode           - Node to query
     * \param dependencies    - Pointer to return the dependencies
     * \param numDependencies - See description
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphNodeGetDependentNodes,
     * ::rppGraphGetNodes,
     * ::rppGraphGetRootNodes,
     * ::rppGraphGetEdges,
     * ::rppGraphAddDependencies,
     * ::rppGraphRemoveDependencies
     */
    RPPresult rppGraphNodeGetDependencies(RPPgraphNode hNode, RPPgraphNode *dependencies, size_t *numDependencies);

    /**
     * \brief Returns a node's dependent nodes
     *
     * Returns a list of \p node's dependent nodes. \p dependentNodes may be NULL, in which
     * case this function will return the number of dependent nodes in \p numDependentNodes.
     * Otherwise, \p numDependentNodes entries will be filled in. If \p numDependentNodes is
     * higher than the actual number of dependent nodes, the remaining entries in
     * \p dependentNodes will be set to NULL, and the number of nodes actually obtained will
     * be returned in \p numDependentNodes.
     *
     * \param hNode             - Node to query
     * \param dependentNodes    - Pointer to return the dependent nodes
     * \param numDependentNodes - See description
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphNodeGetDependencies,
     * ::rppGraphGetNodes,
     * ::rppGraphGetRootNodes,
     * ::rppGraphGetEdges,
     * ::rppGraphAddDependencies,
     * ::rppGraphRemoveDependencies
     */
    RPPresult rppGraphNodeGetDependentNodes(RPPgraphNode hNode, RPPgraphNode *dependentNodes, size_t *numDependentNodes);

    /**
     * \brief Adds dependency edges to a graph
     *
     * The number of dependencies to be added is defined by \p numDependencies
     * Elements in \p from and \p to at corresponding indices define a dependency.
     * Each node in \p from and \p to must belong to \p hGraph.
     *
     * If \p numDependencies is 0, elements in \p from and \p to will be ignored.
     * Specifying an existing dependency will return an error.
     *
     * \param hGraph - Graph to which dependencies are added
     * \param from - Array of nodes that provide the dependencies
     * \param to - Array of dependent nodes
     * \param numDependencies - Number of dependencies to be added
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphRemoveDependencies,
     * ::rppGraphGetEdges,
     * ::rppGraphNodeGetDependencies,
     * ::rppGraphNodeGetDependentNodes
     */
    RPPresult rppGraphAddDependencies(RPPgraph hGraph, const RPPgraphNode *from, const RPPgraphNode *to, size_t numDependencies);

    /**
     * \brief Removes dependency edges from a graph
     *
     * The number of \p dependencies to be removed is defined by \p numDependencies.
     * Elements in \p from and \p to at corresponding indices define a dependency.
     * Each node in \p from and \p to must belong to \p hGraph.
     *
     * If \p numDependencies is 0, elements in \p from and \p to will be ignored.
     * Specifying a non-existing dependency will return an error.
     *
     * \param hGraph - Graph from which to remove dependencies
     * \param from - Array of nodes that provide the dependencies
     * \param to - Array of dependent nodes
     * \param numDependencies - Number of dependencies to be removed
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphAddDependencies,
     * ::rppGraphGetEdges,
     * ::rppGraphNodeGetDependencies,
     * ::rppGraphNodeGetDependentNodes
     */
    RPPresult rppGraphRemoveDependencies(RPPgraph hGraph, const RPPgraphNode *from, const RPPgraphNode *to, size_t numDependencies);

    /**
     * \brief Remove a node from the graph
     *
     * Removes \p hNode from its graph. This operation also severs any dependencies of other nodes
     * on \p hNode and vice versa.
     *
     * \param hNode  - Node to remove
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphAddChildGraphNode,
     * ::rppGraphAddEmptyNode,
     * ::rppGraphAddKernelNode,
     * ::rppGraphAddHostNode,
     * ::rppGraphAddMemcpyNode,
     * ::rppGraphAddMemsetNode
     */
    RPPresult rppGraphDestroyNode(RPPgraphNode hNode);

    /**
     * \brief Creates an executable graph from a graph
     *
     * Instantiates \p hGraph as an executable graph. The graph is validated for any
     * structural constraints or intra-node constraints which were not previously
     * validated. If instantiation is successful, a handle to the instantiated graph
     * is returned in \p graphExec.
     *
     * If there are any errors, diagnostic information may be returned in \p errorNode and
     * \p logBuffer. This is the primary way to inspect instantiation errors. The output
     * will be null terminated unless the diagnostics overflow
     * the buffer. In this case, they will be truncated, and the last byte can be
     * inspected to determine if truncation occurred.
     *
     * \param phGraphExec - Returns instantiated graph
     * \param hGraph      - Graph to instantiate
     * \param phErrorNode - In case of an instantiation error, this may be modified to
     *                      indicate a node contributing to the error
     * \param logBuffer   - A character buffer to store diagnostic messages
     * \param bufferSize  - Size of the log buffer in bytes
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphCreate,
     * ::rppGraphLaunch,
     * ::rppGraphExecDestroy
     */
    RPPresult rppGraphInstantiate(RPPgraphExec *phGraphExec, RPPgraph hGraph, RPPgraphNode *phErrorNode, char *logBuffer, size_t bufferSize);

    /**
     * \brief Allocates device memory for an external graph resource pool
     *
     * Used when ::RPPgraphResource::is_external is true in ::RPP_GRAPH_INSTANTIATE_PARAMS.
     *
     * \param dptr      - Returns device pointer
     * \param bytesize  - Pool size in bytes
     * \param type      - Pool type (::RPPgraphResource_type_e)
     *
     * \sa ::rppGraphResourceFree, ::rppGraphInstantiateWithParams
     */
    RPPresult rppGraphResourceAlloc(RPPdeviceptr *dptr, size_t bytesize, RPPgraphResource_type_e type);

    /**
     * \brief Frees device memory allocated by ::rppGraphResourceAlloc
     *
     * \param dptr - Device pointer to free
     * \param type - Pool type passed to ::rppGraphResourceAlloc
     *
     * \sa ::rppGraphResourceAlloc
     */
    RPPresult rppGraphResourceFree(RPPdeviceptr dptr, RPPgraphResource_type_e type);

    /**
     * \brief Instantiates a graph with caller-supplied resource pools
     *
     * Same validation as ::rppGraphInstantiate, but resource layout comes from
     * \p instantiateParams (see ::RPP_GRAPH_INSTANTIATE_PARAMS). The same graph may be
     * instantiated multiple times with different pool sizes or external buffers.
     *
     * \param phGraphExec        - Returns instantiated graphexec
     * \param hGraph             - Graph to instantiate
     * \param instantiateParams  - Resource pools and instantiate flags (may be partially external)
     *
     * \sa ::rppGraphInstantiate, ::rppGraphExecGetParams, ::rppGraphResourceAlloc
     */
    RPPresult rppGraphInstantiateWithParams(RPPgraphExec *phGraphExec, RPPgraph hGraph, RPP_GRAPH_INSTANTIATE_PARAMS *instantiateParams);

    /**
     * \brief Returns instantiate parameters stored on a graphexec
     *
     * Copies the ::RPP_GRAPH_INSTANTIATE_PARAMS snapshot saved at instantiate time
     * (pool addresses, sizes, and flags). Useful for debugging or re-instantiating with
     * the same layout.
     *
     * \param hGraphExec         - Executable graph to query
     * \param instantiateParams  - Output parameter structure
     *
     * \sa ::rppGraphInstantiateWithParams
     */
    RPPresult rppGraphExecGetParams(RPPgraphExec hGraphExec, RPP_GRAPH_INSTANTIATE_PARAMS *instantiateParams);

    /**
     * \brief Updates an executable graph to match a modified graph definition
     *
     * Applies topology-safe changes from \p hGraph to \p hGraphExec without a full
     * destroy/re-instantiate when node types and dependencies are compatible.
     * On failure, \p resultInfo may identify ::errorNode and ::errorFromNode.
     * For topology or node-type changes, destroy and ::rppGraphInstantiate instead.
     * To replace only a child-graph binding on the definition, use ::rppGraphUpdateChildGraph.
     *
     * \param hGraphExec  - Executable graph to update
     * \param hGraph      - Updated graph definition
     * \param resultInfo  - Optional detailed status (may be NULL)
     *
     * \sa ::rppGraphExecUpdateChildGraphExec, ::RPP_GRAPH_EXEC_UPDATE_RESULT_INFO
     */
    RPPresult rppGraphExecUpdate(RPPgraphExec hGraphExec, RPPgraph hGraph, RPP_GRAPH_EXEC_UPDATE_RESULT_INFO *resultInfo);

    /**
     * \brief Replaces the child graphexec for one child-graph node on a single main graphexec instance
     *
     * Updates only \p mainGraphExec: the host graph and other graphexec instances of the same graph are unchanged.
     * \p targetChildNode must be a ::RPP_GRAPH_NODE_TYPE_GRAPH node belonging to \p mainGraphExec's graph.
     * \p newChildGraphExec must be in the same context as \p mainGraphExec, fully instantiated and not in-flight
     * (internal status complete, not actively executing),
     * and created with ::RPP_GRAPH_INSTANTIATE_FLAG_CHILD_EXEC so child launch nodes exist.
     * On success, \p mainGraphExec only holds a reference to \p newChildGraphExec; the caller keeps ownership and
     * must keep it valid for any launch of \p mainGraphExec that uses that child slot until it is replaced again.
     * \p rppGraphExecDestroy(\p mainGraphExec) does not destroy a caller-installed child graphexec; the caller
     * must destroy \p newChildGraphExec (and any prior caller-installed child) after it is no longer referenced.
     * If the slot previously held a driver-created child graphexec (default instantiate path), that object is
     * destroyed when replaced by this call.
     *
     * \param mainGraphExec    Main executable graph instance to modify
     * \param targetChildNode  Child wrapper node (::RPP_GRAPH_NODE_TYPE_GRAPH) in main's graph
     * \param replaceParams    Must be non-NULL; \p flags must be 0
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_HANDLE,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_NOT_READY,
     * ::RPP_ERROR_GRAPH_EXEC_UPDATE_FAILURE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa ::rppGraphExecUpdate, ::rppGraphUpdateChildGraph
     */
    RPPresult rppGraphExecUpdateChildGraphExec(
        RPPgraphExec mainGraphExec,
        RPPgraphNode targetChildNode,
        const RPP_CHILD_GRAPHEXEC_REPLACE_PARAMS *replaceParams);

    /**
    /**
     * \brief Finalizes a graphexec for launch-only replay (Step 3)
     *
     * Drops member execnode host instantiation mirrors (desc / info / params copies, etc.)
     * under a fixed driver policy after device-side resources are populated at instantiate.
     * Finalization is irreversible for this graphexec unless the graph is instantiated again.
     *
     * \p hGraphExec must not be in-flight (complete and not bound to an active launch stream).
     * Profiling-enabled graphexecs are not supported. Child graphexecs are processed recursively
     * by default. Scheduling execnode host \p desc and child-wrapper \p info required by
     * ::rppGraphExecUpdateChildGraphExec are retained.
     *
     * \p params may be NULL (equivalent to a zero-initialized structure with current
     * \p version and \p structSize). When non-NULL, \p structSize and \p version must be valid;
     * \p flags and \p reserved must be 0.
     *
     * \param hGraphExec - Executable graph
     * \param params     - Optional extensible parameters (may be NULL)
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_HANDLE,
     * ::RPP_ERROR_NOT_READY,
     * ::RPP_ERROR_NOT_SUPPORTED
     *
     * \sa ::RPP_GRAPH_EXEC_FINALIZE_PARAMS, ::rppGraphDestroy,
     *     ::rppGraphExecUpdateChildGraphExec
     */
    RPPresult rppGraphExecFinalize(
        RPPgraphExec hGraphExec,
        const RPP_GRAPH_EXEC_FINALIZE_PARAMS *params);

    /**
     * \brief Sets parameters of one dynamic select graph node on a graphexec
     *
     * \p targetNode must be a dynamic select graph node already present in
     * \p mainGraphExec or inside one child-graph wrapper owned by \p mainGraphExec.
     * The update affects only \p mainGraphExec.
     *
     * \param mainGraphExec  Main executable graph instance
     * \param targetNode     Dynamic select graph node to update
     * \param updateParams   Dynamic branch ACTION_TABLE parameters; must be non-NULL and
     *                       \p flags must be 0
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_INVALID_HANDLE,
     * ::RPP_ERROR_INVALID_CONTEXT,
     * ::RPP_ERROR_NOT_READY,
     * ::RPP_ERROR_OUT_OF_MEMORY,
     * ::RPP_ERROR_GRAPH_EXEC_UPDATE_FAILURE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa ::rppGraphExecUpdateChildGraphExec
     */
    RPPresult rppGraphExecDynamicSelectGraphNodeSetParams(
        RPPgraphExec mainGraphExec,
        RPPgraphNode targetNode,
        const RPP_DYNAMIC_SELECT_GRAPH_NODE_UPDATE_PARAMS *updateParams);

    /**
     * \brief Serializes selected graphexec parameters to a caller buffer
     *
     * \param hGraphExec - Executable graph to serialize
     * \param type       - Parameter type identifier
     * \param size       - Size of \p data in bytes
     * \param data       - Output buffer
     *
     * \sa ::rppGraphExecSerialize
     */
    RPPresult rppGraphExecSerializeParams(RPPgraphExec hGraphExec, uint32_t type, uint32_t size, void* data);
    /**
     * \brief Serializes an executable graph to disk
     *
     * Writes the executable graph specified by \p hGraphExec and its executable nodes
     * under folder \p gpath using mode \p flag.
     *
     * \param hGraphExec - Executable graph to serialize
     * \param gpath      - Output folder path
     * \param flag       - Serialization mode flags
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphInstantiate,
     * ::rppGraphLaunch
     */
    RPPresult rppGraphExecSerialize(RPPgraphExec hGraphExec, char* gpath, uint32_t flag);

    /**
     * \brief Sets the parameters for a kernel node in the given graphExec
     *
     * Sets kernel parameters on \p hGraphExec only; the host graph and other graphexec
     * instances are unchanged (contrast with ::rppGraphKernelNodeSetParams). \p hNode must
     * remain in the source graph; \p func in \p nodeParams must match instantiate-time value.
     * Changes apply on the next launch; in-flight launches are unaffected.
     *
     * \param hGraphExec  - The executable graph in which to set the specified node
     * \param hNode       - kernel node from the graph from which graphExec was instantiated
     * \param nodeParams  - Updated Parameters to set
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_INVALID_VALUE,
     *
     * \sa
     * ::rppGraphAddKernelNode,
     * ::rppGraphKernelNodeSetParams,
     * ::rppGraphInstantiate
     */
    RPPresult rppGraphExecKernelNodeSetParams(RPPgraphExec hGraphExec, RPPgraphNode hNode, const RPP_KERNEL_NODE_PARAMS *nodeParams);

    /**
     * \brief Asynchronously sets kernel node parameters on a graphexec
     *
     * Enqueues a ::RPP_GRAPH_NODE_TYPE_SET_PARAMS update on \p stream so the scheduler
     * applies \p nodeParams during graph execution. If \p stream is not ordered before
     * ::rppGraphLaunch on another stream, updates may run out of order; use events or
     * the same stream. Does not modify the host graph or other graphexec instances.
     *
     * \param hGraphExec  - Executable graph
     * \param hNode       - Kernel node from the source graph
     * \param nodeParams  - Updated parameters (\p func must match instantiate-time value)
     * \param stream      - Stream that carries the update
     *
     * \sa ::rppGraphExecKernelNodeSetParams, ::rppGraphLaunch
     */
    RPPresult rppGraphExecKernelNodeSetParamsAsync(RPPgraphExec hGraphExec, RPPgraphNode hNode, const RPP_KERNEL_NODE_PARAMS *nodeParams, RPPstream stream);


    /**
     * @brief Sets the parameters for a host node in the given \p graphExec.
     *
     * Updates the work represented by \p hNode in \p hGraphExec as though \p hNode had contained
     * \p nodeParams at instantiation.
     *
     * \p hNode must not have been removed from the original graph.
     * Changed edges to and from \p hNode are ignored.
     *
     * The modifications take effect at the next launch of \p hGraphExec. Already
     * enqueued or running launches of \p hGraphExec are not affected by this call.
     * \p hNode is also not modified by this call.
     *
     * \param hGraphExec  - The executable graph in which to set the specified node
     * \param hNode       - Host node from the graph from which graphExec was instantiated
     * \param nodeParams  - Updated Parameters to set
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_INVALID_VALUE,
     *
     * \sa
     * ::rppGraphAddHostNode,
     * ::rppGraphHostNodeSetParams,
     * ::rppGraphInstantiate
     */
    RPPresult rppGraphExecHostNodeSetParams(RPPgraphExec hGraphExec, RPPgraphNode hNode, const RPP_HOST_NODE_PARAMS *nodeParams);

    /**
     * \brief Asynchronously sets host node parameters on a graphexec
     *
     * See ::rppGraphExecKernelNodeSetParamsAsync for stream ordering requirements.
     *
     * \sa ::rppGraphExecHostNodeSetParams
     */
    RPPresult rppGraphExecHostNodeSetParamsAsync(RPPgraphExec hGraphExec, RPPgraphNode hNode, const RPP_HOST_NODE_PARAMS *nodeParams, RPPstream stream);

    /**
     * @brief Sets the parameters for a memcpy node in the given \p graphExec.
     *
     * Updates the work represented by \p hNode in \p hGraphExec as though \p hNode had contained
     * \p copyParams at instantiation.
     *
     * \p hNode must not have been removed from the original graph.
     * Changed edges to and from \p hNode are ignored.
     *
     * The source and destination memory in \p copyParams must be allocated from the same
     * contexts as the original source and destination memory. Both the instantiation-time memory
     * operands and the memory operands in \p copyParams must be 1-dimensional. Zero-length
     * operations are not supported.
     *
     * The modifications take effect at the next launch of \p hGraphExec. Already
     * enqueued or running launches of \p hGraphExec are not affected by this call.
     * \p hNode is also not modified by this call.
     *
     * Returns \p RPP_ERROR_INVALID_VALUE if the memory operands' mappings changed or either
     * the original or new memory operands are multidimensional.
     *
     * \param hGraphExec  - The executable graph in which to set the specified node
     * \param hNode       - Memcpy node from the graph which was used to instantiate graphExec
     * \param copyParams  - The updated parameters to set
     * \param ctx         - Context on which to run the node
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_INVALID_VALUE,
     *
     * \sa
     * ::rppGraphAddMemcpyNode,
     * ::rppGraphMemcpyNodeSetParams,
     * ::rppGraphInstantiate
     */
    RPPresult rppGraphExecMemcpyNodeSetParams(RPPgraphExec hGraphExec, RPPgraphNode hNode, const RPP_MEMCPY3D *copyParams, RPPcontext ctx);

    /**
     * @brief Async sets the parameters for a memcpy node in the given \p graphExec.
     *
     * Updates the work represented by \p hNode in \p hGraphExec as though \p hNode had contained
     * \p copyParams at instantiation.
     *
     * \p hNode must not have been removed from the original graph.
     * Changed edges to and from \p hNode are ignored.
     *
     * The source and destination memory in \p copyParams must be allocated from the same
     * contexts as the original source and destination memory.
     * Both the instantiation-time memory
     * operands and the memory operands in \p copyParams must be 1-dimensional. Zero-length
     * operations are not supported.
     * If the graphExec has launched into
     * different stream with setParamsAsync node, the execution of graphExec and setParamsAsync are out of order,
     * So application should be strictly control their execution order.
     *
     *
     * Returns \p RPP_ERROR_INVALID_VALUE if the memory operands' mappings changed or either
     * the original or new memory operands are multidimensional.
     *
     * \param hGraphExec  - The executable graph in which to set the specified node
     * \param hNode       - Memcpy node from the graph which was used to instantiate graphExec
     * \param copyParams  - The updated parameters to set
     * \param stream      - stream on which to run the node
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_INVALID_VALUE,
     *
     * \sa
     * ::rppGraphAddMemcpyNode,
     * ::rppGraphMemcpyNodeSetParams,
     * ::rppGraphExecMemcpyNodeSetParams,
     * ::rppGraphInstantiate
     */
    RPPresult rppGraphExecMemcpyNodeSetParamsAsync(RPPgraphExec hGraphExec, RPPgraphNode hNode, const RPP_MEMCPY3D *copyParams, RPPcontext ctx, RPPstream stream);

    /**
     * \brief Asynchronously updates indirect memcpy parameters on a graphexec
     *
     * Resolves source or destination via device-side index table or base+offset
     * (see ::RPP_MEMCPY_INDIRECT_UPDATE_PARAMS). Enqueued on \p stream; indirect tables
     * must be visible to the device before this work runs. Order relative to ::rppGraphLaunch
     * using the same stream or explicit dependencies.
     *
     * \param hGraphExec  - Executable graph
     * \param hNode       - Memcpy node from the source graph
     * \param copyParams  - Indirect update parameters
     * \param ctx         - Context on which to run the update
     * \param stream      - Stream for the MPU/sched update request
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_INVALID_VALUE,
     * ::RPP_ERROR_NOT_SUPPORTED
     *
     * \sa ::rppGraphMemcpyNodeSetIndirectParamsAsync, ::rppGraphExecMemcpyNodeSetParamsAsync
     */
    RPPresult rppGraphExecMemcpyNodeSetIndirectParamsAsync(RPPgraphExec hGraphExec, RPPgraphNode hNode, const RPP_MEMCPY_INDIRECT_UPDATE_PARAMS *copyParams, RPPcontext ctx, RPPstream stream);

    /**
     * @brief Sets the parameters for a memset node in the given \p graphExec.
     *
     * Updates the work represented by \p hNode in \p hGraphExec as though \p hNode had contained
     * \p memsetParams at instantiation.
     *
     * \p hNode must not have been removed from the original graph.
     * Changed edges to and from \p hNode are ignored.
     *
     * The source and destination memory in \p memsetParams must be allocated from the same
     * contexts as the original source and destination memory. Both the instantiation-time memory
     * operands and the memory operands in \p memsetParams must be 1-dimensional. Zero-length
     * operations are not supported.
     *
     * The modifications take effect at the next launch of \p hGraphExec. Already
     * enqueued or running launches of \p hGraphExec are not affected by this call.
     * \p hNode is also not modified by this call.
     *
     * The destination memory in \p memsetParams must be allocated from the same contexts
     * as the original destination memory. Both the instantiation-time memory operand and the
     * memory operand in \p memsetParams must be 1-dimensional. Zero-length operations are not
     * supported.
     *
     * Returns \p RPP_ERROR_INVALID_VALUE if the memory operands' mappings changed or either
     * the original or new memory operands are multidimensional.
     *
     * \param hGraphExec  - The executable graph in which to set the specified node
     * \param hNode       - Memset node from the graph which was used to instantiate graphExec
     * \param memsetParams- The updated parameters to set
     * \param ctx         - Context on which to run the node
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_INVALID_VALUE,
     *
     * \sa
     * ::rppGraphAddMemcpyNode,
     * ::rppGraphMemcpyNodeSetParams,
     * ::rppGraphInstantiate
     */
    RPPresult rppGraphExecMemsetNodeSetParams(RPPgraphExec hGraphExec, RPPgraphNode hNode, const RPP_MEMSET_NODE_PARAMS *memsetParams, RPPcontext ctx);

    /**
     * \brief Asynchronously sets memset node parameters on a graphexec
     *
     * See ::rppGraphExecKernelNodeSetParamsAsync for stream ordering requirements.
     *
     * \sa ::rppGraphExecMemsetNodeSetParams
     */
    RPPresult rppGraphExecMemsetNodeSetParamsAsync(RPPgraphExec hGraphExec, RPPgraphNode hNode, const RPP_MEMSET_NODE_PARAMS *memsetParams, RPPcontext ctx, RPPstream stream);


    /**
     * \brief Launches an executable graph in a stream
     *
     * Executes \p hGraphExec in \p hStream. Only one in-flight launch per \p hGraphExec is
     * allowed; a second launch waits until the previous one completes. Each launch is ordered
     * behind prior work on \p hStream and prior launches of the same graphexec. For overlapping
     * execution, instantiate the same graph multiple times into separate graphexec handles.
     * Launch submits graph scheduling on \p hStream (not a separate internal graph stream).
     *
     * \param hGraphExec - Executable graph to launch
     * \param hStream    - Stream in which to launch the graph
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphInstantiate,
     * ::rppGraphExecDestroy
     */
    RPPresult rppGraphLaunch(RPPgraphExec hGraphExec, RPPstream hStream);

    /**
     * \brief Destroys an executable graph
     *
     * Destroys the executable graph specified by \p hGraphExec, as well
     * as all of its executable nodes. If the executable graph is
     * in-flight, it will not be terminated, but rather freed
     * asynchronously on completion.
     *
     * \param hGraphExec - Executable graph to destroy
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphInstantiate,
     * ::rppGraphLaunch
     */
    RPPresult rppGraphExecDestroy(RPPgraphExec hGraphExec);

    /**
     * \brief Destroys a graph
     *
     * Destroys the graph specified by \p hGraph and its nodes when no graphexec instances
     * derived from it remain; otherwise destruction is deferred until the last graphexec is gone.
     *
     * \param hGraph - Graph to destroy
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_DEINITIALIZED,
     * ::RPP_ERROR_NOT_INITIALIZED,
     * ::RPP_ERROR_INVALID_VALUE
     * \note_graph_thread_safety
     * \notefnerr
     *
     * \sa
     * ::rppGraphCreate
     */
    RPPresult rppGraphDestroy(RPPgraph hGraph);
    /** @} */ /* END RPP_GRAPH */

    /**
     * \brief Create ve codec instance
     *
     * create a codec instance in rpp device
     *
     * \param ctx   - context of build with device
     * \param codec - return codec information
     *
     * \Returns
     * ::RPP_SUCCESS
     * ::RPP_ERROR_DEINITIALIZED
     * ::RPP_ERROR_NOT_INITIALIZED
     * ::RPP_ERROR_INVALID_CONTEXT
     * ::RPP_ERROR_INVALID_VALUE
     * ::RPP_ERROR_INVALID_DEVICE
     */
    RPPresult rppCodecCreate(RPPCodec *codec, RPPcontext ctx);
    /**
     * destroy a codec instance in rpp device
     *
     * Parameters:
     * dev     - device id
     * codec - codec information
     *
     * Returns:
     * RPP_SUCCESS, RPP_ERROR_DEINITIALIZED, RPP_ERROR_NOT_INITIALIZED,
     * RPP_ERROR_INVALID_CONTEXT, RPP_ERROR_INVALID_VALUE,
     * RPP_ERROR_INVALID_DEVICE
     */
    RPPresult rppCodecDestroy(RPPCodec *codec, RPPcontext ctx);

    RPPresult rppGetExternalMemoryObjectByType(RPPexternalMemory *extMem_out, const RPPexternalMemoryHandleType type);

    RPPresult rppImportExternalMemory(RPPexternalMemory *extMem_out, const RPP_EXTERNAL_MEMORY_HANDLE_DESC *memHandleDesc);

    RPPresult rppExternalMemoryGetHandleDesc(RPPexternalMemory extMem, RPP_EXTERNAL_MEMORY_HANDLE_DESC *memHandleDesc);

    RPPresult rppExternalMemoryGetMappedBuffer(RPPdeviceptr *devPtr, RPPexternalMemory extMem,
                                               const RPP_EXTERNAL_MEMORY_BUFFER_DESC *bufferDesc);

    RPPresult rppDestroyExternalMemory(RPPexternalMemory extMem);

    /**
     * \brief Set the trace window id for driver logs.
     *
     * Sets the trace window id used by the driver to dump logs to a trace window.
     *
     * \param window_id - Trace window id.
     * \param mode      - Trace mode. `0` = host + device, `1` = host only.
     *
     * \return
     * ::RPP_SUCCESS,
     * ::RPP_ERROR_INVALID_VALUE
     *
     */
    RPPresult rppLogsDumpToTraceWindows(uint32_t window_id, uint32_t mode);

#ifdef __cplusplus
}
#endif /* __cplusplus  */
#endif
