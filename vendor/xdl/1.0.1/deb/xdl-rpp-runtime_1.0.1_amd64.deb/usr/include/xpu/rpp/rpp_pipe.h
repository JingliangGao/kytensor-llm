#ifndef _RPP_PIPE_H_
#define _RPP_PIPE_H_

#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rpp_osal.h"
#include "common.h"
#include "rpp_pti.h"

#if defined(_WIN32) || defined(_WIN64)
#define PIPENAME "\\\\?\\pipe\\rpp\\rpp.pipe"
#else
#define PIPENAME "/tmp/rpp/rpp.pipe"
#endif

#define RPP_REQ_PROBE 0x0
#define RPP_REQ_TERMINATE 0x1

#define RPP_IPC_MSG_MAX_LENGTH 1024
#define MAX_DEV 32
#define MAX_CTX_PER_DEV 32

typedef struct ipc_identity_s
{
    osal_uid_t uid;
    osal_pid_t pid;
    osal_thread_t tid;  /* pthread_self() value */
    osal_pid_t ttid;    /* system thread ID: gettid() on Linux, GetCurrentThreadId() on Windows */
} ipc_identity_t;

typedef struct ipc_header_s
{
    uint32_t msgid;
    uint32_t cmd;
    ipc_identity_t client;
} ipc_header_t;

typedef struct ipc_req_s
{
    ipc_header_t header;
    void *payload;
} ipc_req_t;

typedef struct ipc_resp_s
{
    ipc_header_t header;
    void *payload;
} ipc_resp_t;

typedef enum
{
    IPC_CLIENT_INIT = 0x00,
    IPC_CLIENT_CONNECTTED = 0x01,
    IPC_CLIENT_DISCONNECTTED = 0x02,
    IPC_CLIENT_CLOSED = 0x03,
} ipc_client_status;

typedef struct ipc_client_s
{
    int connfd;
    osal_thread_t ipc_tid;
    int ipc_status;
    struct list_head thread_list;
    struct list_head entry; // server_ctx_t->client_list
} ipc_client_t;

typedef struct ipc_ctx_s
{
    int ipc_status;
    int sockfd;
    osal_buf_t buf;
    ipc_identity_t client;
    ipc_client_t *ipc_client; // used in mps=off
    osal_mutex_t msg_mutex;
    uint64_t currCtxID; // current ctx
    uint32_t msgid;
    uint8_t to[65536];
    uint8_t from[65536];
    struct list_head entry;
} ipc_ctx_t;

typedef struct sock_ctx_s
{
    osal_loop_t loop;
    osal_tcp_t ipc_sock;
    osal_connect_t sock_connect_req; // req
    struct sockaddr_in addr;
    osal_buf_t buf;
    uint8_t msg_buf[32]; // sizeof(header) + arg_size
} sock_ctx_t;

#if defined(__clang__) || \
    defined(__GNUC__) ||  \
    defined(__INTEL_COMPILER)
#define UNUSED __attribute__((unused))
#else
#define UNUSED
#endif

/* Fully close a loop */
static void close_walk_cb(osal_handle_t *handle, void *arg)
{
    if (!osal_is_closing(handle))
        osal_close(handle, NULL);
}

UNUSED static void close_loop(osal_loop_t *loop)
{
    osal_walk(loop, close_walk_cb, NULL);
    osal_run(loop, OSAL_RUN_DEFAULT);
}

/* This macro cleans up the main loop. This is used to avoid valgrind
 * warnings about memory being "leaked" by the main event loop.
 */
#define MAKE_VALGRIND_HAPPY(loop)           \
    do                                      \
    {                                       \
        close_loop((loop));                 \
        assert(0 == osal_loop_close((loop))); \
    } while (0)

#define MSG_INVALID _MSG(RPP_DRIVER_API_ID_INVALID)
#define MSG_rppInit _MSG(RPP_DRIVER_API_ID_rppInit, rppInit_params, 0)
#define MSG_rppExit _MSG(RPP_DRIVER_API_ID_rppExit, rppExit_params, 0)
#define MSG_rppDriverGetVersion _MSG(RPP_DRIVER_API_ID_rppDriverGetVersion, rppDriverGetVersion_params, 0)
#define MSG_rppDeviceGet _MSG(RPP_DRIVER_API_ID_rppDeviceGet, rppDeviceGet_params, 0)
#define MSG_rppDeviceGetCount _MSG(RPP_DRIVER_API_ID_rppDeviceGetCount, rppDeviceGetCount_params, 0)
#define MSG_rppDeviceGetName _MSG(RPP_DRIVER_API_ID_rppDeviceGetName, rppDeviceGetName_params, 0)
#define MSG_rppDeviceGetPCIBusId _MSG(RPP_DRIVER_API_ID_rppDeviceGetPCIBusId, rppDeviceGetPCIBusId_params, 0)
#define MSG_rppDeviceGetByPCIBusId _MSG(RPP_DRIVER_API_ID_rppDeviceGetByPCIBusId, rppDeviceGetByPCIBusId_params, 0)
#define MSG_rppDeviceComputeCapability _MSG(RPP_DRIVER_API_ID_rppDeviceComputeCapability, rppDeviceComputeCapability_params, 0)
#define MSG_rppDeviceTotalMem _MSG(RPP_DRIVER_API_ID_rppDeviceTotalMem, rppDeviceTotalMem_params, 0)
#define MSG_rppDeviceGetProperties _MSG(RPP_DRIVER_API_ID_rppDeviceGetProperties, rppDeviceGetProperties_params, 0)
#define MSG_rppDeviceGetAttribute _MSG(RPP_DRIVER_API_ID_rppDeviceGetAttribute, rppDeviceGetAttribute_params, 0)
#define MSG_rppDeviceGetCodecInfo _MSG(RPP_DRIVER_API_ID_rppDeviceGetCodecInfo, rppDeviceGetCodecInfo_params, 0)
#define MSG_rppDeviceRegRead _MSG(RPP_DRIVER_API_ID_rppDeviceRegRead, rppDeviceRegRead_params, 0)
#define MSG_rppDeviceRegWrite _MSG(RPP_DRIVER_API_ID_rppDeviceRegWrite, rppDeviceRegWrite_params, 0)
#define MSG_rppDeviceRegRead32 _MSG(RPP_DRIVER_API_ID_rppDeviceRegRead32, rppDeviceRegRead32_params, 0)
#define MSG_rppDeviceRegWrite32 _MSG(RPP_DRIVER_API_ID_rppDeviceRegWrite32, rppDeviceRegWrite32_params, 0)
#define MSG_rppDeviceSetLimit _MSG(RPP_DRIVER_API_ID_rppDeviceSetLimit, rppDeviceSetLimit_params, 0)
#define MSG_rppDeviceGetLimit _MSG(RPP_DRIVER_API_ID_rppDeviceGetLimit, rppDeviceGetLimit_params, 0)
#define MSG_rppCtxCreate _MSG(RPP_DRIVER_API_ID_rppCtxCreate, rppCtxCreate_params, 0)
#define MSG_rppCtxDestroy _MSG(RPP_DRIVER_API_ID_rppCtxDestroy, rppCtxDestroy_params, 0)
#define MSG_rppCtxPushCurrent _MSG(RPP_DRIVER_API_ID_rppCtxPushCurrent, rppCtxPushCurrent_params, 0)
#define MSG_rppCtxPopCurrent _MSG(RPP_DRIVER_API_ID_rppCtxPopCurrent, rppCtxPopCurrent_params, 0)
#define MSG_rppCtxSetCurrent _MSG(RPP_DRIVER_API_ID_rppCtxSetCurrent, rppCtxSetCurrent_params, 0)
#define MSG_rppCtxGetCurrent _MSG(RPP_DRIVER_API_ID_rppCtxGetCurrent, rppCtxGetCurrent_params, 0)
#define MSG_rppCtxGetDevice _MSG(RPP_DRIVER_API_ID_rppCtxGetDevice, rppCtxGetDevice_params, 0)
#define MSG_rppCtxGetSpecified _MSG(RPP_DRIVER_API_ID_rppCtxGetSpecified, rppCtxGetSpecified_params, 0)
#define MSG_rppCtxSynchronize _MSG(RPP_DRIVER_API_ID_rppCtxSynchronize, rppCtxSynchronize_params, 0)
#define MSG_rppCtxGetFlags _MSG(RPP_DRIVER_API_ID_rppCtxGetFlags, rppCtxGetFlags_params, 0)
#define MSG_rppCtxSetLimit _MSG(RPP_DRIVER_API_ID_rppCtxSetLimit, rppCtxSetLimit_params, 0)
#define MSG_rppCtxGetLimit _MSG(RPP_DRIVER_API_ID_rppCtxGetLimit, rppCtxGetLimit_params, 0)
#define MSG_rppCtxSetCacheConfig _MSG(RPP_DRIVER_API_ID_rppCtxSetCacheConfig, rppCtxSetCacheConfig_params, 0)
#define MSG_rppCtxGetCacheConfig _MSG(RPP_DRIVER_API_ID_rppCtxGetCacheConfig, rppCtxGetCacheConfig_params, 0)
#define MSG_rppCtxSetSharedMemConfig _MSG(RPP_DRIVER_API_ID_rppCtxSetSharedMemConfig, rppCtxSetSharedMemConfig_params, 0)
#define MSG_rppCtxGetSharedMemConfig _MSG(RPP_DRIVER_API_ID_rppCtxGetSharedMemConfig, rppCtxGetSharedMemConfig_params, 0)
#define MSG_rppCtxGetApiVersion _MSG(RPP_DRIVER_API_ID_rppCtxGetApiVersion, rppCtxGetApiVersion_params, 0)
#define MSG_rppModuleLoad _MSG(RPP_DRIVER_API_ID_rppModuleLoad, rppModuleLoad_params, 0)
#define MSG_rppModuleLoadData _MSG(RPP_DRIVER_API_ID_rppModuleLoadData, rppModuleLoadData_params, 0)
#define MSG_rppModuleLoadDataEx _MSG(RPP_DRIVER_API_ID_rppModuleLoadDataEx, rppModuleLoadDataEx_params, 0)
#define MSG_rppModuleLoadFatBinary _MSG(RPP_DRIVER_API_ID_rppModuleLoadFatBinary, rppModuleLoadFatBinary_params, 0)
#define MSG_rppModuleUnload _MSG(RPP_DRIVER_API_ID_rppModuleUnload, rppModuleUnload_params, 0)
#define MSG_rppModuleGetFunction _MSG(RPP_DRIVER_API_ID_rppModuleGetFunction, rppModuleGetFunction_params, 0)
#define MSG_rppModuleGetGlobal _MSG(RPP_DRIVER_API_ID_rppModuleGetGlobal, rppModuleGetGlobal_params, 0)
#define MSG_rppMemGetInfo _MSG(RPP_DRIVER_API_ID_rppMemGetInfo, rppMemGetInfo_params, 0)
#define MSG_rppMemAlloc _MSG(RPP_DRIVER_API_ID_rppMemAlloc, rppMemAlloc_params, 0)
#define MSG_rppMemFree _MSG(RPP_DRIVER_API_ID_rppMemFree, rppMemFree_params, 0)
#define MSG_rppMemGetAddressRange _MSG(RPP_DRIVER_API_ID_rppMemGetAddressRange, rppMemGetAddressRange_params, 0)
#define MSG_rppMemAllocHost _MSG(RPP_DRIVER_API_ID_rppMemAllocHost, rppMemAllocHost_params, 0)
#define MSG_rppMemFreeHost _MSG(RPP_DRIVER_API_ID_rppMemFreeHost, rppMemFreeHost_params, 0)
#define MSG_rppSramAlloc _MSG(RPP_DRIVER_API_ID_rppSramAlloc, rppSramAlloc_params, 0)
#define MSG_rppSramFree _MSG(RPP_DRIVER_API_ID_rppSramFree, rppSramFree_params, 0)
#define MSG_rppVirtSramAlloc _MSG(RPP_DRIVER_API_ID_rppVirtSramAlloc, rppVirtSramAlloc_params, 0)
#define MSG_rppVirtSramFree _MSG(RPP_DRIVER_API_ID_rppVirtSramFree, rppVirtSramFree_params, 0)
#define MSG_rppMemcpyHtoD _MSG(RPP_DRIVER_API_ID_rppMemcpyHtoD, rppMemcpy_params, 0)
#define MSG_rppMemcpyDtoH _MSG(RPP_DRIVER_API_ID_rppMemcpyDtoH, rppMemcpy_params, 0)
#define MSG_rppMemcpyDtoD _MSG(RPP_DRIVER_API_ID_rppMemcpyDtoD, rppMemcpy_params, 0)
#define MSG_rppMemcpyDtoS _MSG(RPP_DRIVER_API_ID_rppMemcpyDtoS, rppMemcpy_params, 0)
#define MSG_rppMemcpyStoD _MSG(RPP_DRIVER_API_ID_rppMemcpyStoD, rppMemcpy_params, 0)
#define MSG_rppMemcpyHtoS _MSG(RPP_DRIVER_API_ID_rppMemcpyHtoS, rppMemcpy_params, 0)
#define MSG_rppMemcpyStoH _MSG(RPP_DRIVER_API_ID_rppMemcpyStoH, rppMemcpy_params, 0)
#define MSG_rppMemcpyStoS _MSG(RPP_DRIVER_API_ID_rppMemcpyStoS, rppMemcpy_params, 0)
#define MSG_rppMemcpyDtoSInterLeaver _MSG(RPP_DRIVER_API_ID_rppMemcpyDtoSInterLeaver, rppMemcpyInterLeaver_params, 0)
#define MSG_rppMemcpyStoDInterLeaver _MSG(RPP_DRIVER_API_ID_rppMemcpyStoDInterLeaver, rppMemcpyInterLeaver_params, 0)
#define MSG_rppMemcpyDtoSDeInterLeaver _MSG(RPP_DRIVER_API_ID_rppMemcpyDtoSDeInterLeaver, rppMemcpyDeInterLeaver_params, 0)
#define MSG_rppMemcpyStoDDeInterLeaver _MSG(RPP_DRIVER_API_ID_rppMemcpyStoDDeInterLeaver, rppMemcpyDeInterLeaver_params, 0)
#define MSG_rppMemcpy2D _MSG(RPP_DRIVER_API_ID_rppMemcpy2D, rppMemcpy_params, 0)
#define MSG_rppMemcpy3D _MSG(RPP_DRIVER_API_ID_rppMemcpy3D, rppMemcpy_params, 0)
#define MSG_rppMemcpy4D _MSG(RPP_DRIVER_API_ID_rppMemcpy4D, rppMemcpy_params, 0)
#define MSG_rppMemcpyHtoDAsync _MSG(RPP_DRIVER_API_ID_rppMemcpyHtoDAsync, rppMemcpyAsync_params, 0)
#define MSG_rppMemcpyDtoHAsync _MSG(RPP_DRIVER_API_ID_rppMemcpyDtoHAsync, rppMemcpyAsync_params, 0)
#define MSG_rppMemcpyDtoDAsync _MSG(RPP_DRIVER_API_ID_rppMemcpyDtoDAsync, rppMemcpyAsync_params, 0)
#define MSG_rppMemcpyDtoSAsync _MSG(RPP_DRIVER_API_ID_rppMemcpyDtoSAsync, rppMemcpyAsync_params, 0)
#define MSG_rppMemcpyStoDAsync _MSG(RPP_DRIVER_API_ID_rppMemcpyStoDAsync, rppMemcpyAsync_params, 0)
#define MSG_rppMemcpyStoSAsync _MSG(RPP_DRIVER_API_ID_rppMemcpyStoSAsync, rppMemcpyAsync_params, 0)
#define MSG_rppMemcpyHtoSAsync _MSG(RPP_DRIVER_API_ID_rppMemcpyHtoSAsync, rppMemcpyAsync_params, 0)
#define MSG_rppMemcpyStoHAsync _MSG(RPP_DRIVER_API_ID_rppMemcpyStoHAsync, rppMemcpyAsync_params, 0)
#define MSG_rppMemcpy2DAsync _MSG(RPP_DRIVER_API_ID_rppMemcpy2DAsync, rppMemcpyAsync_params, 0)
#define MSG_rppMemcpy3DAsync _MSG(RPP_DRIVER_API_ID_rppMemcpy3DAsync, rppMemcpyAsync_params, 0)
#define MSG_rppMemcpy4DAsync _MSG(RPP_DRIVER_API_ID_rppMemcpy4DAsync, rppMemcpyAsync_params, 0)
#define MSG_rppMemcpyDtoSInterLeaverAsync _MSG(RPP_DRIVER_API_ID_rppMemcpyDtoSInterLeaverAsync, rppMemcpyInterLeaverAsync_params, 0)
#define MSG_rppMemcpyStoDInterLeaverAsync _MSG(RPP_DRIVER_API_ID_rppMemcpyStoDInterLeaverAsync, rppMemcpyInterLeaverAsync_params, 0)
#define MSG_rppMemcpyDtoSDeInterLeaverAsync _MSG(RPP_DRIVER_API_ID_rppMemcpyDtoSDeInterLeaverAsync, rppMemcpyDeInterLeaverAsync_params, 0)
#define MSG_rppMemcpyStoDDeInterLeaverAsync _MSG(RPP_DRIVER_API_ID_rppMemcpyStoDDeInterLeaverAsync, rppMemcpyDeInterLeaverAsync_params, 0)
#define MSG_rppMemcpyLinkDtoS _MSG(RPP_DRIVER_API_ID_rppMemcpyLinkDtoS, rppMemcpyLink_params, 0)
#define MSG_rppMemcpyLinkStoD _MSG(RPP_DRIVER_API_ID_rppMemcpyLinkStoD, rppMemcpyLink_params, 0)
#define MSG_rppMemcpyLinkDtoD _MSG(RPP_DRIVER_API_ID_rppMemcpyLinkDtoD, rppMemcpyLink_params, 0)
#define MSG_rppMemcpyLinkDtoSAsync _MSG(RPP_DRIVER_API_ID_rppMemcpyLinkDtoSAsync, rppMemcpyLinkAsync_params, 0)
#define MSG_rppMemcpyLinkStoDAsync _MSG(RPP_DRIVER_API_ID_rppMemcpyLinkStoDAsync, rppMemcpyLinkAsync_params, 0)
#define MSG_rppMemcpyLinkDtoDAsync _MSG(RPP_DRIVER_API_ID_rppMemcpyLinkDtoDAsync, rppMemcpyLinkAsync_params, 0)
#define MSG_rppMemsetD8 _MSG(RPP_DRIVER_API_ID_rppMemsetD8, rppMemsetD8_params, 0)
#define MSG_rppMemsetD16 _MSG(RPP_DRIVER_API_ID_rppMemsetD16, rppMemsetD16_params, 0)
#define MSG_rppMemsetD32 _MSG(RPP_DRIVER_API_ID_rppMemsetD32, rppMemsetD32_params, 0)
#define MSG_rppSramMemsetD8 _MSG(RPP_DRIVER_API_ID_rppSramMemsetD8, rppSramMemsetD8_params, 0)
#define MSG_rppMpumemAlloc _MSG(RPP_DRIVER_API_ID_rppMpumemAlloc, rppMpumemAlloc_params, 0)
#define MSG_rppMpumemFree _MSG(RPP_DRIVER_API_ID_rppMpumemFree, rppMpumemFree_params, 0)
#define MSG_rppMemcpyHtoM _MSG(RPP_DRIVER_API_ID_rppMemcpyHtoM, rppMemcpy_params, 0)
#define MSG_rppMemcpyMtoH _MSG(RPP_DRIVER_API_ID_rppMemcpyMtoH, rppMemcpy_params, 0)
#define MSG_rppMemcpyHtoMAsync _MSG(RPP_DRIVER_API_ID_rppMemcpyHtoMAsync, rppMemcpyAsync_params, 0)
#define MSG_rppMemcpyMtoHAsync _MSG(RPP_DRIVER_API_ID_rppMemcpyMtoHAsync, rppMemcpyAsync_params, 0)
#define MSG_rppMpumemMemsetD8 _MSG(RPP_DRIVER_API_ID_rppMpumemMemsetD8, rppMpumemMemsetD8_params, 0)
#define MSG_rppMpumemMemsetD8Async _MSG(RPP_DRIVER_API_ID_rppMpumemMemsetD8Async, rppMpumemMemsetD8Async_params, 0)
#define MSG_rppMemGetPhysAddr _MSG(RPP_DRIVER_API_ID_rppMemGetPhysAddr, rppMemGetPhysAddr_params, 0)
#define MSG_rppMemGetVirtAddr _MSG(RPP_DRIVER_API_ID_rppMemGetVirtAddr, rppMemGetVirtAddr_params, 0)
#define MSG_rppFuncSetBlockShape _MSG(RPP_DRIVER_API_ID_rppFuncSetBlockShape, rppFuncSetBlockShape_params, 0)
#define MSG_rppFuncSetSharedSize _MSG(RPP_DRIVER_API_ID_rppFuncSetSharedSize, rppFuncSetSharedSize_params, 0)
#define MSG_rppFuncGetAttribute _MSG(RPP_DRIVER_API_ID_rppFuncGetAttribute, rppFuncGetAttribute_params, 0)
#define MSG_rppFuncSetCacheConfig _MSG(RPP_DRIVER_API_ID_rppFuncSetCacheConfig, rppFuncSetCacheConfig_params, 0)
#define MSG_rppParamSetSize _MSG(RPP_DRIVER_API_ID_rppParamSetSize, rppParamSetSize_params, 0)
#define MSG_rppParamSeti _MSG(RPP_DRIVER_API_ID_rppParamSeti, rppParamSeti_params, 0)
#define MSG_rppParamSetf _MSG(RPP_DRIVER_API_ID_rppParamSetf, rppParamSetf_params, 0)
#define MSG_rppParamSetv _MSG(RPP_DRIVER_API_ID_rppParamSetv, rppParamSetv_params, 0)
#define MSG_rppLaunch _MSG(RPP_DRIVER_API_ID_rppLaunch, rppLaunch_params, 0)
#define MSG_rppGetParamFormat _MSG(RPP_DRIVER_API_ID_rppGetParamFormat, rppGetParamFormat_params, 0)
#define MSG_rppLaunchKernel _MSG(RPP_DRIVER_API_ID_rppLaunchKernel, rppLaunchKernel_params, 0)
#define MSG_rppLaunchGrid _MSG(RPP_DRIVER_API_ID_rppLaunchGrid, rppLaunchGrid_params, 0)
#define MSG_rppLaunchGridAsync _MSG(RPP_DRIVER_API_ID_rppLaunchGridAsync, rppLaunchGridAsync_params, 0)
#define MSG_rppEventCreate _MSG(RPP_DRIVER_API_ID_rppEventCreate, rppEventCreate_params, 0)
#define MSG_rppEventRecord _MSG(RPP_DRIVER_API_ID_rppEventRecord, rppEventRecord_params, 0)
#define MSG_rppEventQuery _MSG(RPP_DRIVER_API_ID_rppEventQuery, rppEventQuery_params, 0)
#define MSG_rppEventSynchronize _MSG(RPP_DRIVER_API_ID_rppEventSynchronize, rppEventSynchronize_params, 0)
#define MSG_rppEventDestroy _MSG(RPP_DRIVER_API_ID_rppEventDestroy, rppEventDestroy_params, 0)
#define MSG_rppEventElapsedTime _MSG(RPP_DRIVER_API_ID_rppEventElapsedTime, rppEventElapsedTime_params, 0)
#define MSG_rppEventReset _MSG(RPP_DRIVER_API_ID_rppEventReset, rppEventReset_params, 0)
#define MSG_rppEventGetOccupied _MSG(RPP_DRIVER_API_ID_rppEventGetOccupied, rppEventGetOccupied_params, 0)

#define MSG_rppStreamCreate _MSG(RPP_DRIVER_API_ID_rppStreamCreate, rppStreamCreate_params, 0)
#define MSG_rppStreamQuery _MSG(RPP_DRIVER_API_ID_rppStreamQuery, rppStreamQuery_params, 0)
#define MSG_rppStreamSynchronize _MSG(RPP_DRIVER_API_ID_rppStreamSynchronize, rppStreamSynchronize_params, 0)
#define MSG_rppStreamDestroy _MSG(RPP_DRIVER_API_ID_rppStreamDestroy, rppStreamDestroy_params, 0)
#define MSG_rppStreamWaitEvent _MSG(RPP_DRIVER_API_ID_rppStreamWaitEvent, rppStreamWaitEvent_params, 0)
#define MSG_rppSemWait _MSG(RPP_DRIVER_API_ID_rppSemWait, rppSemWait_params, 0)
#define MSG_rppSemPost _MSG(RPP_DRIVER_API_ID_rppSemPost, rppSemPost_params, 0)
#define MSG_rppStreamRecord _MSG(RPP_DRIVER_API_ID_rppStreamRecord, rppStreamRecord_params, 0)
#define MSG_rppStreamSetInOut _MSG(RPP_DRIVER_API_ID_rppStreamSetInOut, rppStreamSetInOut_params, 0)
#define MSG_rppReplay _MSG(RPP_DRIVER_API_ID_rppReplay, rppReplay_params, 0)
#define MSG_rppDevicePrimaryCtxGetState _MSG(RPP_DRIVER_API_ID_rppDevicePrimaryCtxGetState, rppDevicePrimaryCtxGetState_params, 0)
#define MSG_rppDevicePrimaryCtxRelease _MSG(RPP_DRIVER_API_ID_rppDevicePrimaryCtxRelease, rppDevicePrimaryCtxRelease_params, 0)
#define MSG_rppDevicePrimaryCtxReset _MSG(RPP_DRIVER_API_ID_rppDevicePrimaryCtxReset, rppDevicePrimaryCtxReset_params, 0)
#define MSG_rppDevicePrimaryCtxRetain _MSG(RPP_DRIVER_API_ID_rppDevicePrimaryCtxRetain, rppDevicePrimaryCtxRetain_params, 0)
#define MSG_rppDevicePrimaryCtxSetFlags _MSG(RPP_DRIVER_API_ID_rppDevicePrimaryCtxSetFlags, rppDevicePrimaryCtxSetFlags_params, 0)
#define MSG_rppProfilerInitialize _MSG(RPP_DRIVER_API_ID_rppProfilerInitialize, rppProfilerInitialize_params, 0)
#define MSG_rppProfilerStart _MSG(RPP_DRIVER_API_ID_rppProfilerStart, rppProfilerStart_params, 0)
#define MSG_rppProfilerStop _MSG(RPP_DRIVER_API_ID_rppProfilerStop, rppProfilerStop_params, 0)
#define MSG_rppLogsDumpToTraceWindows _MSG(RPP_DRIVER_API_ID_rppLogsDumpToTraceWindows, rppLogsDumpToTraceWindows_params, 0)
#define MSG_rppStreamBeginCapture _MSG(RPP_DRIVER_API_ID_rppStreamBeginCapture, rppStreamBeginCapture_params, 0)
#define MSG_rppStreamEndCapture _MSG(RPP_DRIVER_API_ID_rppStreamEndCapture, rppStreamEndCapture_params, 0)
#define MSG_rppStreamIsCapturing _MSG(RPP_DRIVER_API_ID_rppStreamIsCapturing, rppStreamIsCapturing_params, 0)
#define MSG_rppGraphCreate _MSG(RPP_DRIVER_API_ID_rppGraphCreate, rppGraphCreate_params, 0)
#define MSG_rppGraphClone _MSG(RPP_DRIVER_API_ID_rppGraphClone, rppGraphClone_params, 0)
#define MSG_rppGraphInstantiate _MSG(RPP_DRIVER_API_ID_rppGraphInstantiate, rppGraphInstantiate_params, 0)
#define MSG_rppGraphExecSerializeParams _MSG(RPP_DRIVER_API_ID_rppGraphSerializeParams, rppGraphSerializePara_params, 0)
#define MSG_rppGraphExecSerialize _MSG(RPP_DRIVER_API_ID_rppGraphSerialize, rppGraphSerialize_params, 0)
#define MSG_rppGraphLaunch _MSG(RPP_DRIVER_API_ID_rppGraphLaunch, rppGraphLaunch_params, 0)
#define MSG_rppGraphExecDestroy _MSG(RPP_DRIVER_API_ID_rppGraphExecDestroy, rppGraphExecDestroy_params, 0)
#define MSG_rppGraphDestroy _MSG(RPP_DRIVER_API_ID_rppGraphDestroy, rppGraphDestroy_params, 0)
#define MSG_rppGraphAddKernelNode _MSG(RPP_DRIVER_API_ID_rppGraphAddKernelNode, rppGraphAddKernelNode_params, 0)
#define MSG_rppGraphKernelNodeGetParams _MSG(RPP_DRIVER_API_ID_rppGraphKernelNodeGetParams, rppGraphKernelNodeGetParams_params, 0)
#define MSG_rppGraphKernelNodeSetParams _MSG(RPP_DRIVER_API_ID_rppGraphKernelNodeSetParams, rppGraphKernelNodeSetParams_params, 0)
#define MSG_rppGraphAddMemcpyNode _MSG(RPP_DRIVER_API_ID_rppGraphAddMemcpyNode, rppGraphAddMemcpyNode_params, 0)
#define MSG_rppGraphMemcpyNodeGetParams _MSG(RPP_DRIVER_API_ID_rppGraphMemcpyNodeGetParams, rppGraphMemcpyNodeGetParams_params, 0)
#define MSG_rppGraphMemcpyNodeSetParams _MSG(RPP_DRIVER_API_ID_rppGraphMemcpyNodeSetParams, rppGraphMemcpyNodeSetParams_params, 0)
#define MSG_rppGraphAddMemsetNode _MSG(RPP_DRIVER_API_ID_rppGraphAddMemsetNode, rppGraphAddMemsetNode_params, 0)
#define MSG_rppGraphMemsetNodeGetParams _MSG(RPP_DRIVER_API_ID_rppGraphMemsetNodeGetParams, rppGraphMemsetNodeGetParams_params, 0)
#define MSG_rppGraphMemsetNodeSetParams _MSG(RPP_DRIVER_API_ID_rppGraphMemsetNodeSetParams, rppGraphMemsetNodeSetParams_params, 0)
#define MSG_rppGraphAddHostNode _MSG(RPP_DRIVER_API_ID_rppGraphAddHostNode, rppGraphAddHostNode_params, 0)
#define MSG_rppGraphHostNodeGetParams _MSG(RPP_DRIVER_API_ID_rppGraphHostNodeGetParams, rppGraphHostNodeGetParams_params, 0)
#define MSG_rppGraphHostNodeSetParams _MSG(RPP_DRIVER_API_ID_rppGraphHostNodeSetParams, rppGraphHostNodeSetParams_params, 0)
#define MSG_rppGraphAddChildGraphNode _MSG(RPP_DRIVER_API_ID_rppGraphAddChildGraphNode, rppGraphAddChildGraphNode_params, 0)
#define MSG_rppGraphAddChildGraphexecNode _MSG(RPP_DRIVER_API_ID_rppGraphAddChildGraphexecNode, rppGraphAddChildGraphexecNode_params, 0)
#define MSG_rppGraphAddDynamicSelectGraphNode _MSG(RPP_DRIVER_API_ID_rppGraphAddDynamicSelectGraphNode, rppGraphAddDynamicSelectGraphNode_params, 0)
#define MSG_rppGraphUpdateChildGraph _MSG(RPP_DRIVER_API_ID_rppGraphUpdateChildGraph, rppGraphUpdateChildGraph_params, 0)
#define MSG_rppGraphExecKernelNodeSetParams _MSG(RPP_DRIVER_API_ID_rppGraphExecKernelNodeSetParams, rppGraphExecKernelNodeSetParams_params, 0)
#define MSG_rppGraphExecMemcpyNodeSetParams _MSG(RPP_DRIVER_API_ID_rppGraphExecMemcpyNodeSetParams, rppGraphExecMemcpyNodeSetParams_params, 0)
#define MSG_rppGraphExecMemsetNodeSetParams _MSG(RPP_DRIVER_API_ID_rppGraphExecMemsetNodeSetParams, rppGraphExecMemsetNodeSetParams_params, 0)
#define MSG_rppGraphExecHostNodeSetParams _MSG(RPP_DRIVER_API_ID_rppGraphExecHostNodeSetParams, rppGraphExecHostNodeSetParams_params, 0)
#define MSG_rppGraphExecKernelNodeSetParamsAsync _MSG(RPP_DRIVER_API_ID_rppGraphExecKernelNodeSetParamsAsync, rppGraphExecKernelNodeSetParamsAsync_params, 0)
#define MSG_rppGraphExecMemcpyNodeSetParamsAsync _MSG(RPP_DRIVER_API_ID_rppGraphExecMemcpyNodeSetParamsAsync, rppGraphExecMemcpyNodeSetParamsAsync_params, 0)
#define MSG_rppGraphExecMemcpyNodeSetIndirectParamsAsync _MSG(RPP_DRIVER_API_ID_rppGraphExecMemcpyNodeSetIndirectParamsAsync, rppGraphExecMemcpyNodeSetIndirectParamsAsync_params, 0)
#define MSG_rppGraphMemcpyNodeSetIndirectParamsAsync _MSG(RPP_DRIVER_API_ID_rppGraphMemcpyNodeSetIndirectParamsAsync, rppGraphMemcpyNodeSetIndirectParamsAsync_params, 0)
#define MSG_rppGraphMemcpyIndirectUpdateNodeSetParams _MSG(RPP_DRIVER_API_ID_rppGraphMemcpyIndirectUpdateNodeSetParams, rppGraphMemcpyIndirectUpdateNodeSetParams_params, 0)
#define MSG_rppGraphExecMemsetNodeSetParamsAsync _MSG(RPP_DRIVER_API_ID_rppGraphExecMemsetNodeSetParamsAsync, rppGraphExecMemsetNodeSetParamsAsync_params, 0)
#define MSG_rppGraphExecHostNodeSetParamsAsync _MSG(RPP_DRIVER_API_ID_rppGraphExecHostNodeSetParamsAsync, rppGraphExecHostNodeSetParamsAsync_params, 0)
#define MSG_rppGraphChildGraphNodeGetGraph _MSG(RPP_DRIVER_API_ID_rppGraphChildGraphNodeGetGraph, rppGraphChildGraphNodeGetGraph_params, 0)
#define MSG_rppGraphAddEmptyNode _MSG(RPP_DRIVER_API_ID_rppGraphAddEmptyNode, rppGraphAddEmptyNode_params, 0)
#define MSG_rppGraphNodeGetType _MSG(RPP_DRIVER_API_ID_rppGraphNodeGetType, rppGraphNodeGetType_params, 0)
#define MSG_rppGraphGetNodes _MSG(RPP_DRIVER_API_ID_rppGraphGetNodes, rppGraphGetNodes_params, 0)
#define MSG_rppGraphGetRootNodes _MSG(RPP_DRIVER_API_ID_rppGraphGetRootNodes, rppGraphGetRootNodes_params, 0)
#define MSG_rppGraphGetEdges _MSG(RPP_DRIVER_API_ID_rppGraphGetEdges, rppGraphGetEdges_params, 0)
#define MSG_rppGraphNodeGetDependencies _MSG(RPP_DRIVER_API_ID_rppGraphNodeGetDependencies, rppGraphNodeGetDependencies_params, 0)
#define MSG_rppGraphNodeGetDependentNodes _MSG(RPP_DRIVER_API_ID_rppGraphNodeGetDependentNodes, rppGraphNodeGetDependentNodes_params, 0)
#define MSG_rppGraphAddDependencies _MSG(RPP_DRIVER_API_ID_rppGraphAddDependencies, rppGraphAddDependencies_params, 0)
#define MSG_rppGraphRemoveDependencies _MSG(RPP_DRIVER_API_ID_rppGraphRemoveDependencies, rppGraphRemoveDependencies_params, 0)
#define MSG_rppGraphDestroyNode _MSG(RPP_DRIVER_API_ID_rppGraphDestroyNode, rppGraphDestroyNode_params, 0)
#define MSG_rppGraphResourceAlloc _MSG(RPP_DRIVER_API_ID_rppGraphResourceAlloc, rppGraphResourceAlloc_params, 0)
#define MSG_rppGraphResourceFree _MSG(RPP_DRIVER_API_ID_rppGraphResourceFree, rppGraphResourceFree_params, 0)
#define MSG_rppGraphInstantiateWithParams _MSG(RPP_DRIVER_API_ID_rppGraphInstantiateWithParams, rppGraphInstantiateWithParams_params, 0)
#define MSG_rppGraphExecGetParams _MSG(RPP_DRIVER_API_ID_rppGraphExecGetParams, rppGraphExecGetParams_params, 0)
#define MSG_rppGraphExecUpdate _MSG(RPP_DRIVER_API_ID_rppGraphExecUpdate, rppGraphExecUpdate_params, 0)
#define MSG_rppGraphExecUpdateChildGraphExec _MSG(RPP_DRIVER_API_ID_rppGraphExecUpdateChildGraphExec, rppGraphExecUpdateChildGraphExec_params, 0)
#define MSG_rppGraphExecFinalize _MSG(RPP_DRIVER_API_ID_rppGraphExecFinalize, rppGraphExecFinalize_params, 0)
#define MSG_rppGraphExecDynamicSelectGraphNodeSetParams _MSG(RPP_DRIVER_API_ID_rppGraphExecDynamicSelectGraphNodeSetParams, rppGraphExecDynamicSelectGraphNodeSetParams_params, 0)

#define MSG_rppCodecCreate _MSG(RPP_DRIVER_API_ID_rppCodecCreate, rppCodec_params, 0)
#define MSG_rppCodecDestroy _MSG(RPP_DRIVER_API_ID_rppCodecDestroy, rppCodec_params, 0)
#define MSG_rppGetExternalMemoryObjectByType _MSG(RPP_DRIVER_API_ID_rppGetExternalMemoryObjectByType, rppGetExternalMemoryObjectByType_params, 0)
#define MSG_rppImportExternalMemory _MSG(RPP_DRIVER_API_ID_rppImportExternalMemory, rppImportExternalMemory_params, 0)
#define MSG_rppExternalMemoryGetMappedBuffer _MSG(RPP_DRIVER_API_ID_rppExternalMemoryGetMappedBuffer, rppExternalMemoryGetMappedBuffer_params, 0)
#define MSG_rppDestroyExternalMemory _MSG(RPP_DRIVER_API_ID_rppDestroyExternalMemory, rppDestroyExternalMemory_params, 0)
#define MSG_rppExternalMemoryGetHandleDesc _MSG(RPP_DRIVER_API_ID_rppExternalMemoryGetHandleDesc, rppExternalMemoryGetHandleDesc_params, 0)
#define MSG_rppDFSSetFreqAsync _MSG(RPP_DRIVER_API_ID_rppDFSSetFreqAsync, rppDFSSetFreqAsync_params, 0)
#define MSG_rppDFSSetFlexibleFreqAsync _MSG(RPP_DRIVER_API_ID_rppDFSSetFlexibleFreqAsync, rppMpuMsgAsync_params, 0)
#define MSG_rppDeviceSetPwrMode _MSG(RPP_DRIVER_API_ID_rppDeviceSetPwrMode, rppDeviceSetPwrMode_params, 0)
#define MSG_rppDeviceGetPwrMode _MSG(RPP_DRIVER_API_ID_rppDeviceGetPwrMode, rppDeviceGetPwrMode_params, 0)
#define MSG_rppDeviceSetWorkMode _MSG(RPP_DRIVER_API_ID_rppDeviceSetWorkMode, rppDeviceSetWorkMode_params, 0)
#define MSG_rppDeviceGetWorkMode _MSG(RPP_DRIVER_API_ID_rppDeviceGetWorkMode, rppDeviceGetWorkMode_params, 0)

ipc_ctx_t *ipc_open(void);
ipc_ctx_t *get_ipc_ctx(void);
void ipc_close(ipc_ctx_t *ipc_ctx);
int ipc_connect(ipc_ctx_t *ipc_ctx);
void ipc_disconnect(ipc_ctx_t *ipc_ctx);
int ipc_msg(uint32_t cmd, void *args, const char *func_name);
int ipc_sock_msg(uint32_t cmd, void *args);
int ipc_ctx_set_rppctx(uint64_t rppCtxID);
uint64_t ipc_ctx_get_rppctx();
int rpp_get_client_perf_mode(void);
int rpp_get_client_perf_to_file(void);
uint32_t rpp_client_get_trace_window_id(void);
void rpp_client_set_trace_window_id(uint32_t window_id);
void rpp_set_perf_window_id(uint32_t window_id, uint32_t flags);
void parse_sys_env(void);

#endif /* _RPP_PIPE_H_ */
