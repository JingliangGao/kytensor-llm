#ifndef   FIFO_MUTEX_H
#define   FIFO_MUTEX_H
#include <errno.h>
#include "rpp_osal.h"

/* First in, first out mutex type and associated inline functions.
 * Note that the type is not async signal safe, and therefore should
 * not be used in signal handlers; this is due to condition variables
 * used in the structure internally.
*/

typedef struct fifo_mutex	fifo_mutex_t;
struct fifo_mutex {
	pthread_mutex_t		mutex;
	pthread_cond_t		cond;
	unsigned int		worker;
	unsigned int		waiter;
};



static inline int fifo_mutex_init(fifo_mutex_t *const fifo)
{
	if (fifo) {
		if (pthread_mutex_init(&(fifo->mutex), NULL)) {
			abort();
		}
		if (pthread_cond_init(&(fifo->cond), NULL)) {
			abort();
		}

		fifo->worker = 1U;
		fifo->waiter = 0U;

		return 0;
	}
	return EINVAL;
}

static inline void fifo_mutex_destroy(fifo_mutex_t *const fifo)
{
	if (fifo) {
		pthread_cond_destroy(&(fifo->cond));

		pthread_mutex_destroy(&(fifo->mutex));
	}
}

static inline int fifo_mutex_unlock(fifo_mutex_t *const fifo)
{
	int result;

	if (fifo) {
		fifo->worker++;

		result = pthread_cond_broadcast(&(fifo->cond));
		if (result)
			return result;

		result = pthread_mutex_unlock(&(fifo->mutex));
		if (result)
			return result;

		return 0;
	}
	return EINVAL;
}

static inline int fifo_mutex_lock(fifo_mutex_t *const fifo)
{
	int result, waiter;

	if (fifo) {

        /* Atomic preincrement */
        waiter = __sync_add_and_fetch((int *)&(fifo->waiter), (int)1);

        /* Obtain the mutex */
		result = pthread_mutex_lock(&(fifo->mutex));
		if (result)
			return result;

                /* This thread? */
		if (waiter == fifo->worker)
			return 0;

		while (waiter != fifo->worker)
			pthread_cond_wait(&(fifo->cond), &(fifo->mutex));

		return 0;
	}
	return EINVAL;
}

#endif /* FIFO_MUTEX_H */
