
#pragma once
#include <stdint.h>
template<typename T0>
class rppTensor1D
{
    int m_w;
    int m_hl_offset;
    uint32_t m_addr;
public:
    rppTensor1D()
    {
    }
    rppTensor1D(uint16_t width, char *data)
    {
        m_w = width;
        if(sizeof(T0) == 4)
            m_hl_offset = m_w * 2;
        else
            m_hl_offset = 0;
        m_addr = (uint32_t)((uint64_t)data);
    }
    void CloneFrom(const rppTensor1D<T0>& tensor1D)
    {
        m_w = tensor1D.GetW();
        m_hl_offset = tensor1D.GetHLOffset();
        m_addr = tensor1D.GetAddr();
    }
    ~rppTensor1D()
    {
    }
    int GetW() const { return m_w; }
    int GetHLOffset() const { return m_hl_offset; }
    uint32_t GetAddr() const { return m_addr; }

#if (defined __CUDA_RPP_DEV_BUILTIN)
    inline __device__ uint32_t addr(){
        return m_addr;
    }
    inline __device__ uint16_t width(){
        return m_w;
    }
    inline __device__ T0 get_cont(){
        T0 out;
        if (sizeof(T0)==4)
        {
            uint32_t block_offset = (blockIdx.x * blockDim.x) * 2;
            uint32_t addr_lo = m_addr + block_offset;
            asm("{LOADCONT.U32 %0, %1, %2;\n}"
                :"=r"(out):"r"(addr_lo), "r"(addr_lo + m_hl_offset));
        }
        else if (sizeof(T0)==2)
        {
            uint32_t block_offset = (blockIdx.x * blockDim.x) * 2;
            uint32_t addr_lo = m_addr + block_offset;
            asm("{LOADCONT %0, %1;\n}"
                :"=h"(out):"r"(addr_lo));
        }
        else
        {
            uint32_t block_offset = (blockIdx.x * blockDim.x);
            uint32_t addr_lo = m_addr + block_offset;
            asm("{LOADCONT.U8 %0, %1;\n}"
                :"=h"(out):"r"(addr_lo));
        }      
        return out;
    }
    inline __device__ void set_cont(T0 val){
        if (sizeof(T0)==4)
        {
            uint32_t block_offset = (blockIdx.x * blockDim.x) * 2;
            uint32_t addr_lo = m_addr + block_offset;
            asm("{STORE_CONT.U32 %0, %1, %2;\n}"
                ::"r"(val), "r"(addr_lo), "r"(addr_lo + m_hl_offset));
        }
        else if (sizeof(T0)==2)
        {
            uint32_t block_offset = (blockIdx.x * blockDim.x) * 2;
            uint32_t addr_lo = m_addr + block_offset;
            asm("{STORECONT %0, %1;\n}"
            ::"h"(val), "r"(addr_lo));
        }
        else
        {
            uint32_t block_offset = (blockIdx.x * blockDim.x);
            uint32_t addr_lo = m_addr + block_offset;
            asm("{STORECONT.BEN %0, %1;\n}"
            ::"h"(val), "r"(addr_lo));
        } 
        return ;
    }
   inline __device__ T0 get(uint16_t w){
        T0 out;
        if (sizeof(T0)==4)
        {
            //uint16_t stridey = (m_cols * sizeof(short));
            asm("{LOAD_SHA_PITCH_1D %0, %1, %2, %3, %4, %5;\n}"
            :"=r"(out):"r"(m_addr), "r"(m_hl_offset), "h"(0), "h"(w), "h"(w));
        }
        else if (sizeof(T0)==2)
        {
            //uint16_t stridey = (m_cols * sizeof(short));
            asm("{LOAD_SHA_PITCH_1D.U16 %0, %1, %2, %3, %4, %5;\n}"
                :"=h"(out):"r"(m_addr), "r"(m_addr), "h"(0), "h"(w), "h"(w));
        }
        else
        {
            //uint16_t stridey = (m_cols);
            asm("{LOAD_SHA_PITCH_1D.U8 %0, %1, %2, %3, %4, %5;\n}"
                :"=h"(out):"r"(m_addr), "r"(m_addr), "h"(0), "h"(w), "h"(w));
        }      
        return out;
    }

   inline __device__ T0 get_algn(int offset){
        T0 out;
        if (sizeof(T0)==4)
        {
            uint32_t addr_lo = m_addr + (offset / 2);
            asm("{LOADCONT.U32 %0, %1, %2;\n}"
                :"=r"(out):"r"(addr_lo), "r"(addr_lo + m_hl_offset));
        }
        else if (sizeof(T0)==2)
        {
            uint32_t addr_lo = m_addr + offset;
            asm("{LOADCONT %0, %1;\n}"
                :"=h"(out):"r"(addr_lo));
        }
        else
        {
            uint32_t addr_lo = m_addr + offset;
            asm("{LOADCONT.U8 %0, %1;\n}"
                :"=h"(out):"r"(addr_lo));
        }      
        return out;
    }
    inline __device__ void set_algn(T0 val, int offset){
        if (sizeof(T0)==4)
        {
            uint32_t addr_lo = m_addr + (offset / 2);
            asm("{STORE_CONT.U32 %0, %1, %2;\n}"
                ::"r"(val), "r"(addr_lo), "r"(addr_lo + m_hl_offset));
        }
        else if (sizeof(T0)==2)
        {
            uint32_t addr_lo = m_addr + offset;
            asm("{STORECONT %0, %1;\n}"
            ::"h"(val), "r"(addr_lo));
        }
        else
        {
            uint32_t addr_lo = m_addr + offset;
            asm("{STORECONT.BEN %0, %1;\n}"
            ::"h"(val), "r"(addr_lo));
        } 
        return ;
    }
#endif
};
template<typename T0>
class rppTensor2D
{
    int m_w;
    int m_h;
    int m_hl_offset;
    uint32_t m_addr;
public:
    rppTensor2D()
    {
    }
    rppTensor2D(uint16_t height, uint16_t width, char *data)
    {
        m_w = width;
        m_h = height;
        if(sizeof(T0) == 4)
            m_hl_offset = m_w * m_h * 2;
        else
            m_hl_offset = 0;
        m_addr = (uint32_t)((uint64_t)data);
    }
    void CloneFrom(const rppTensor2D<T0>& tensor2D)
    {
        m_w = tensor2D.GetW();
        m_h = tensor2D.GetH();
        m_hl_offset = tensor2D.GetHLOffset();
        m_addr = tensor2D.GetAddr();
    }
    ~rppTensor2D()
    {
    }
    int GetW() const { return m_w; }
    int GetH() const { return m_h; }
    int GetHLOffset() const { return m_hl_offset; }
    uint32_t GetAddr() const { return m_addr; }

#if (defined __CUDA_RPP_DEV_BUILTIN)
    inline __device__ uint32_t addr(){
        return m_addr;
    }
    inline __device__ uint16_t width(){
        return m_w;
    }
    inline __device__ uint16_t height(){
        return m_h;
    }
    inline __device__ T0 get_cont(){
        T0 out;
        if (sizeof(T0)==4)
        {
            uint32_t block_offset = (blockIdx.y * blockDim.y * m_w) * 2;
            uint32_t addr_lo = m_addr + block_offset;
            asm("{LOADCONT.U32 %0, %1, %2;\n}"
                :"=r"(out):"r"(addr_lo), "r"(addr_lo + m_hl_offset));
        }
        else if (sizeof(T0)==2)
        {
            uint32_t block_offset = (blockIdx.y * blockDim.y * m_w) * 2;
            uint32_t addr_lo = m_addr + block_offset;
            asm("{LOADCONT %0, %1;\n}"
                :"=h"(out):"r"(addr_lo));
        }
        else
        {
            uint32_t block_offset = (blockIdx.y * blockDim.y * m_w);
            uint32_t addr_lo = m_addr + block_offset;
            asm("{LOADCONT.U8 %0, %1;\n}"
                :"=h"(out):"r"(addr_lo));
        }      
        return out;
    }
    inline __device__ void set_cont(T0 val){
        if (sizeof(T0)==4)
        {
            uint32_t block_offset = (blockIdx.y * blockDim.y * m_w) * 2;
            uint32_t addr_lo = m_addr + block_offset;
            asm("{STORE_CONT.U32 %0, %1, %2;\n}"
                ::"r"(val), "r"(addr_lo), "r"(addr_lo + m_hl_offset));
        }
        else if (sizeof(T0)==2)
        {
            uint32_t block_offset = (blockIdx.y * blockDim.y * m_w) * 2;
            uint32_t addr_lo = m_addr + block_offset;
            asm("{STORECONT %0, %1;\n}"
            ::"h"(val), "r"(addr_lo));
        }
        else
        {
            uint32_t block_offset = (blockIdx.y * blockDim.y * m_w);
            uint32_t addr_lo = m_addr + block_offset;
            asm("{STORECONT.BEN %0, %1;\n}"
            ::"h"(val), "r"(addr_lo));
        } 
        return ;
    }

   inline __device__ T0 get(uint16_t h, uint16_t w){
        T0 out;
        if (sizeof(T0)==4)
        {
            uint16_t stridey = (m_w * sizeof(short));
            asm("{LOAD_SHA_PITCH.U32 %0, %1, %2, %3, %4, %5;\n}"
            :"=r"(out):"r"(m_addr), "r"(m_hl_offset), "h"(stridey), "h"(h), "h"(w));
        }
        else if (sizeof(T0)==2)
        {
            uint16_t stridey = (m_w * sizeof(short));
            asm("{LOAD_SHA_PITCH.U16 %0, %1, %2, %3, %4, %5;\n}"
                :"=h"(out):"r"(m_addr), "r"(m_addr), "h"(stridey), "h"(h), "h"(w));
        }
        else
        {
            asm("{LOAD_SHA_PITCH.U8 %0, %1, %2, %3, %4, %5;\n}"
                :"=h"(out):"r"(m_addr), "r"(m_addr), "h"(m_w), "h"(h), "h"(w));
        }      
        return out;
    }

     inline __device__ T0 get_algn(int offset, uint16_t stride0){
        T0 out;
        if (sizeof(T0)==4)
        {
            uint32_t addr_lo = m_addr + (offset / 2);
            uint16_t strideY = stride0 / 4;
            asm("{LOADPITCH %0, %1, %2, %3, %4;\n}"
                :"=f"(out):"r"(addr_lo), "r"(addr_lo + m_hl_offset), "h"(strideY), "h"(strideY));
            return out;
        }
        else if (sizeof(T0)==2)
        {
            uint32_t addr_lo = m_addr + offset;
            uint16_t strideY = stride0 / 2;
            asm("{LOADALN %0, %1, %2, %3;\n}"
                :"=h"(out):"r"(addr_lo), "h"(strideY), "h"(strideY));
        }
        else
        {
            uint32_t addr_lo = m_addr + offset;
            asm("{LOADALN.U8 %0, %1, %2, %3;\n}"
                :"=h"(out):"r"(addr_lo), "h"(stride0), "h"(stride0));
        }
        return out;
    }
    inline __device__ void set_algn(T0 val, int offset, uint16_t stride0){
        if (sizeof(T0)==4)
        {
            uint32_t addr_lo = m_addr + (offset / 2);
            uint16_t strideY = stride0 / 4;
            asm("{STOREPITCH %0, %1, %2, %3, %4 ;\n}"
                ::"r"(val), "r"(addr_lo), "r"(addr_lo + m_hl_offset), "h"(strideY), "h"(strideY));
        }
        else if (sizeof(T0)==2)
        {
            uint32_t addr_lo = m_addr + offset;
            uint16_t strideY = stride0 / 2;
            asm("{STOREALN %0, %1, %2, %3;\n}"
            ::"h"(val), "r"(addr_lo),"h"(stride0), "h"(stride0));
        }
        else
        {
            uint32_t addr_lo = m_addr + offset;
            asm("{STOREALN.BEN %0, %1, %2, %3;\n}"
                ::"h"(val), "r"(addr_lo),"h"(stride0), "h"(stride0));
        } 
        return ;
    }
#endif
};

template<typename T0>
class rppTensor3D
{
    int m_dim0;
    int m_dim1;
    int m_dim2;
    int m_hl_offset;
    uint32_t m_addr;
public:
    rppTensor3D()
    {
    }
    rppTensor3D(uint16_t dim2, uint16_t dim1, uint16_t dim0, char *data)
    {
        m_dim0 = dim0;
        m_dim1 = dim1;
        m_dim2 = dim2;
        if(sizeof(T0) == 4)
            m_hl_offset = m_dim0 * m_dim1 * m_dim2 * 2;
        else
            m_hl_offset = 0;
        m_addr = (uint32_t)((uint64_t)data);
    }
    void CloneFrom(const rppTensor3D<T0>& tensor3D)
    {
        m_dim0 = tensor3D.GetDim0();
        m_dim1 = tensor3D.GetDim1();
        m_dim2 = tensor3D.GetDim2();
        m_hl_offset = tensor3D.GetHLOffset();
        m_addr = tensor3D.GetAddr();
    }
    ~rppTensor3D()
    {
    }
    int GetDim0() const { return m_dim0; }
    int GetDim1() const { return m_dim1; }
    int GetDim2() const { return m_dim2; }
    int GetHLOffset() const { return m_hl_offset; }
    uint32_t GetAddr() const { return m_addr; }

#if (defined __CUDA_RPP_DEV_BUILTIN)
    inline __device__ uint32_t addr(){
        return m_addr;
    }
    inline __device__ uint16_t dim0(){
        return m_dim0;
    }
    inline __device__ uint16_t dim1(){
        return m_dim1;
    }
    inline __device__ uint16_t dim2(){
        return m_dim2;
    }
    inline __device__ T0 get_cont(){
        T0 out;
        if (sizeof(T0)==4)
        {
            uint32_t block_offset = (blockIdx.y * blockDim.y * m_dim0);
            block_offset += (blockIdx.z * blockDim.z * m_dim0 * m_dim1);
            uint32_t addr_lo = m_addr + block_offset * 2;
            asm("{LOADCONT.U32 %0, %1, %2;\n}"
                :"=r"(out):"r"(addr_lo), "r"(addr_lo + m_hl_offset));
        }
        else if (sizeof(T0)==2)
        {
            uint32_t block_offset = (blockIdx.y * blockDim.y * m_dim0);
            block_offset += (blockIdx.z * blockDim.z * m_dim0 * m_dim1);
            uint32_t addr_lo = m_addr + block_offset * 2;
            asm("{LOADCONT %0, %1;\n}"
                :"=h"(out):"r"(addr_lo));
        }
        else
        {
            uint32_t block_offset = (blockIdx.y * blockDim.y * m_dim0);
            block_offset += (blockIdx.z * blockDim.z * m_dim0 * m_dim1);
            uint32_t addr_lo = m_addr + block_offset;
            asm("{LOADCONT.U8 %0, %1;\n}"
                :"=h"(out):"r"(addr_lo));
        }      
        return out;
    }
    inline __device__ void set_cont(T0 val){
        if (sizeof(T0)==4)
        {
            uint32_t block_offset = (blockIdx.y * blockDim.y * m_dim0);
            block_offset += (blockIdx.z * blockDim.z * m_dim0 * m_dim1);
            uint32_t addr_lo = m_addr + block_offset * 2;
            asm("{STORE_CONT.U32 %0, %1, %2;\n}"
                ::"r"(val), "r"(addr_lo), "r"(addr_lo + m_hl_offset));
        }
        else if (sizeof(T0)==2)
        {
            uint32_t block_offset = (blockIdx.y * blockDim.y * m_dim0);
            block_offset += (blockIdx.z * blockDim.z * m_dim0 * m_dim1);
            uint32_t addr_lo = m_addr + block_offset * 2;
            asm("{STORECONT %0, %1;\n}"
            ::"h"(val), "r"(addr_lo));
        }
        else
        {
            uint32_t block_offset = (blockIdx.y * blockDim.y * m_dim0);
            block_offset += (blockIdx.z * blockDim.z * m_dim0 * m_dim1);
            uint32_t addr_lo = m_addr + block_offset;
            asm("{STORECONT.BEN %0, %1;\n}"
            ::"h"(val), "r"(addr_lo));
        } 
        return ;
    }

   inline __device__ T0 get(uint16_t idx2, uint16_t idx1, uint16_t idx0){
        T0 out;
        if (sizeof(T0)==4)
        {
            uint16_t stridey = (m_dim0 * sizeof(short));
            asm("{LOAD_SHA_PITCH_3D.U32 %0, %1, %2, %3, %4, %5, %6, %7;\n}"
            :"=r"(out):"r"(m_addr), "r"(m_hl_offset), "h"(stridey), "r"(stridey * m_dim1), "h"(idx2), "h"(idx1), "h"(idx0));
        }
        else if (sizeof(T0)==2)
        {
            uint16_t stridey = (m_dim0 * sizeof(short));
            asm("{LOAD_SHA_PITCH_3D.U16 %0, %1, %2, %3, %4, %5, %6, %7;\n}"
                :"=h"(out):"r"(m_addr), "r"(m_addr), "h"(stridey), "r"(stridey * m_dim1), "h"(idx2), "h"(idx1), "h"(idx0));
        }
        else
        {
            asm("{LOAD_SHA_PITCH_3D.U8 %0, %1, %2, %3, %4, %5, %6, %7;\n}"
                :"=h"(out):"r"(m_addr), "r"(m_addr), "h"(m_dim0), "r"(m_dim0 * m_dim1), "h"(idx2), "h"(idx1), "h"(idx0));
        }      
        return out;
    }

     inline __device__ T0 get_algn(int offset, uint16_t stride0, uint32_t stride1){
        T0 out;
        if (sizeof(T0)==4)
        {
            uint32_t addr_lo = m_addr + (offset / 2);
            asm("{LOADPITCH %0, %1, %2, %3, %4;\n}"
                :"=f"(out):"r"(addr_lo), "r"(addr_lo + m_hl_offset), "h"(stride0/4), "h"(stride1/4));
            return out;
        }
        else if (sizeof(T0)==2)
        {
            uint32_t addr_lo = m_addr + offset;
            asm("{LOADALN %0, %1, %2, %3;\n}"
                :"=h"(out):"r"(addr_lo), "h"(stride0/2), "h"(stride1/2));
        }
        else
        {
            uint32_t addr_lo = m_addr + offset;
            asm("{LOADALN.U8 %0, %1, %2, %3;\n}"
                :"=h"(out):"r"(addr_lo), "h"(stride0), "h"(stride1));
        }
        return out;
    }
    inline __device__ void set_algn(T0 val, int offset, uint16_t stride0, uint32_t stride1){
        if (sizeof(T0)==4)
        {
            uint32_t addr_lo = m_addr + (offset / 2);
            asm("{STOREPITCH %0, %1, %2, %3, %4 ;\n}"
                ::"r"(val), "r"(addr_lo), "r"(addr_lo + m_hl_offset), "h"(stride0/4), "h"(stride1/4));
        }
        else if (sizeof(T0)==2)
        {
            uint32_t addr_lo = m_addr + offset;
            asm("{STOREALN %0, %1, %2, %3;\n}"
            ::"h"(val), "r"(addr_lo),"h"(stride0/2), "h"(stride1/2));
        }
        else
        {
            uint32_t addr_lo = m_addr + offset;
            asm("{STOREALN.BEN %0, %1, %2, %3;\n}"
                ::"h"(val), "r"(addr_lo),"h"(stride0/2), "h"(stride1/2));
        } 
        return ;
    }
#endif
};

