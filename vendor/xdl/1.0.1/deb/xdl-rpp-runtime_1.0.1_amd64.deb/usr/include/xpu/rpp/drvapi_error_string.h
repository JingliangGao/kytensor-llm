#ifndef  COMMON_DRVAPI_ERROR_STRING_H_
#define  COMMON_DRVAPI_ERROR_STRING_H_

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Error Code string definitions here
typedef struct {
    char const *error_name;
    char const *error_string;
    int error_id;
} s_RppErrorStr;

/**
 * Error codes
 */
static s_RppErrorStr sRppDrvErrorString[] = {
    /**
     * The API call returned with no errors. In the case of query calls, this
     * can also mean that the operation being queried is complete (see
     * ::rppEventQuery() and ::rppStreamQuery()).
     */
    {"RPP_SUCCESS",
     "No errors.",
     0},

    /**
     * This indicates that one or more of the parameters passed to the API call
     * is not within an acceptable range of values.
     */
    {"RPP_ERROR_INVALID_VALUE",
     "One or more of the parameters passed to the API call is not within an acceptable range of values.",
     1},

    /**
     * The API call failed because it was unable to allocate enough memory to
     * perform the requested operation.
     */
    {"RPP_ERROR_OUT_OF_MEMORY",
     "Unable to allocate enough memory to perform the requested operation.",
     2},

    /**
     * This indicates that the RPP driver has not been initialized with
     * ::rppInit() or that initialization has failed.
     */
    {"RPP_ERROR_NOT_INITIALIZED",
     "The RPP driver has not been initialized with rppInit().",
    3},

    /**
     * This indicates that the RPP driver is in the process of shutting down.
     */
    {"RPP_ERROR_DEINITIALIZED",
     "The RPP driver is in the process of shutting down.",
     4},

    /**
     * This indicates profiler is not initialized for this run.
     * This can happen when the application is running with external profiling tools like visual profiler.
     */
    {"RPP_ERROR_PROFILER_DISABLED",
     "Profiler is not initialized for this run.",
     5},
    /**
     * This indicates profiling has not been initialized for this context.
     * Call cuProfilerInitialize() to resolve this.
     */
    {"RPP_ERROR_PROFILER_NOT_INITIALIZED",
     "Profiling has not been initialized for this context.",
     6},
    /**
     * This indicates profiler has already been started and probably
     * cuProfilerStart() is incorrectly called.
     */
    {"RPP_ERROR_PROFILER_ALREADY_STARTED",
     "Profiler has already been started.",
     7},
    /**
     * This indicates profiler has already been stopped and probably
     * cuProfilerStop() is incorrectly called.
     */
    {"RPP_ERROR_PROFILER_ALREADY_STOPPED",
     "Profiler has already been stopped.",
     8},
    /**
     * This indicates that no RPP-capable devices were detected by the
     * installed RPP driver.
     */
    {"RPP_ERROR_NO_DEVICE (no RPP-capable devices were detected)",
    "No RPP-capable devices were detected.",
    100},

    /**
     * This indicates that the device ordinal supplied by the user does not
     * correspond to a valid RPP device.
     */
    {"RPP_ERROR_INVALID_DEVICE",
    "The device ordinal supplied does not correspond to a valid RPP device.",
     101},

    /**
     * This indicates that the device kernel image is invalid. This can also
     * indicate an invalid RPP module.
     */
    {"RPP_ERROR_INVALID_IMAGE",
     "The device kernel image is invalid.",
     200},

    /**
     * This most frequently indicates that there is no context bound to the
     * current thread. This can also be returned if the context passed to an
     * API call is not a valid handle (such as a context that has had
     * ::rppCtxDestroy() invoked on it). This can also be returned if a user
     * mixes different API versions (i.e. 3010 context with 3020 API calls).
     * See ::rppCtxGetApiVersion() for more details.
     */
    {"RPP_ERROR_INVALID_CONTEXT",
     "There is no context bound to the current thread or the context passed to an API call is not a valid handle.",
     201},

    /**
     * This indicated that the context being supplied as a parameter to the
     * API call was already the active context.
     * \deprecated
     * This error return is deprecated as of RPP 3.2. It is no longer an
     * error to attempt to push the active context via ::rppCtxPushCurrent().
     */
    {"RPP_ERROR_CONTEXT_ALREADY_CURRENT",
     "The context being supplied as a parameter to the API call was already the active context.",
     202},

    /**
     * This indicates that a map or register operation has failed.
     */
    {"RPP_ERROR_MAP_FAILED",
     "A map or register operation has failed.",
     205},

    /**
     * This indicates that an unmap or unregister operation has failed.
     */
    {"RPP_ERROR_UNMAP_FAILED",
     "An unmap or unregister operation has failed.",
     206},

    /**
     * This indicates that the specified array is currently mapped and thus
     * cannot be destroyed.
     */
    {"RPP_ERROR_ARRAY_IS_MAPPED",
     "The specified array is currently mapped and thus cannot be destroyed.",
     207},

    /**
     * This indicates that the resource is already mapped.
     */
    {"RPP_ERROR_ALREADY_MAPPED",
     "The resource is already mapped.",
     208},

    /**
     * This indicates that there is no kernel image available that is suitable
     * for the device. This can occur when a user specifies code generation
     * options for a particular RPP source file that do not include the
     * corresponding device configuration.
     */
    {"RPP_ERROR_NO_BINARY_FOR_GPU",
     "There is no kernel image available that is suitable for the device.",
     209},

    /**
     * This indicates that a resource has already been acquired.
     */
    {"RPP_ERROR_ALREADY_ACQUIRED",
     "A resource has already been acquired.",
     210},

    /**
     * This indicates that a resource is not mapped.
     */
    {"RPP_ERROR_NOT_MAPPED",
     "A resource is not mapped.",
     211},

    /**
     * This indicates that a mapped resource is not available for access as an
     * array.
     */
    {"RPP_ERROR_NOT_MAPPED_AS_ARRAY",
     "A mapped resource is not available for access as an array.",
     212},

    /**
     * This indicates that a mapped resource is not available for access as a
     * pointer.
     */
    {"RPP_ERROR_NOT_MAPPED_AS_POINTER",
     "A mapped resource is not available for access as a pointer.",
     213},

    /**
     * This indicates that an uncorrectable ECC error was detected during
     * execution.
     */
    {"RPP_ERROR_ECC_UNCORRECTABLE",
     "An uncorrectable ECC error was detected during execution.",
     214},

    /**
     * This indicates that the ::RPPlimit passed to the API call is not
     * supported by the active device.
     */
    {"RPP_ERROR_UNSUPPORTED_LIMIT",
     "The RPPlimit passed to the API call is not supported by the active device.",
     215},

    /**
     * This indicates that the ::RPPcontext passed to the API call can
     * only be bound to a single CPU thread at a time but is already
     * bound to a CPU thread.
     */
    {"RPP_ERROR_CONTEXT_ALREADY_IN_USE",
     "The context passed to the API call can only be bound to a single CPU thread at a time but is already bound to a CPU thread.",
     216},

    /**
     * This indicates that peer access is not supported across the given
     * devices.
     */
    {"RPP_ERROR_PEER_ACCESS_UNSUPPORTED",
     "The peer access is not supported across the given devices.",
     217},

    /**
     * This indicates that the device kernel source is invalid.
     */
    {"RPP_ERROR_INVALID_SOURCE",
     "The device kernel source is invalid.",
     300},

    /**
     * This indicates that the file specified was not found.
     */
    {"RPP_ERROR_FILE_NOT_FOUND",
     "The file specified was not found.",
     301},

    /**
     * This indicates that a link to a shared object failed to resolve.
     */
    {"RPP_ERROR_SHARED_OBJECT_SYMBOL_NOT_FOUND",
     "A link to a shared object failed to resolve.",
     302},

    /**
     * This indicates that initialization of a shared object failed.
     */
    {"RPP_ERROR_SHARED_OBJECT_INIT_FAILED",
     "Initialization of a shared object failed.",
     303},

    /**
     * This indicates that an OS call failed.
     */
    {"RPP_ERROR_OPERATING_SYSTEM",
     "An OS call failed.",
     304},

    /**
     * This indicates that a resource handle passed to the API call was not
     * valid. Resource handles are opaque types like ::RPPstream and ::RPPevent.
     */
    {"RPP_ERROR_INVALID_HANDLE",
     "A resource handle passed to the API call was not valid.",
     400},

    /**
     * This indicates that a named symbol was not found. Examples of symbols
     * are global/constant variable names, texture names }, and surface names.
     */
    {"RPP_ERROR_NOT_FOUND",
     "A named symbol was not found.",
     500},

    /**
     * This indicates that asynchronous operations issued previously have not
     * completed yet. This result is not actually an error, but must be
     * indicated differently than ::RPP_SUCCESS (which indicates completion).
     * Calls that may return this value include ::rppEventQuery() and
     * ::rppStreamQuery().
     */
    {"RPP_ERROR_NOT_READY",
     "Asynchronous operations issued previously have not completed yet.",
     600},

    /**
     * While executing a kernel, the device encountered a
     * load or store instruction on an invalid memory address.
     * This leaves the process in an inconsistent state and any further RPP
     * work will return the same error. To continue using RPP, the process must
     * be terminated and relaunched.
     */
    {"RPP_ERROR_ILLEGAL_ADDRESS",
     "While executing a kernel, the device encountered a load or store instruction on an invalid memory address.",
     700},

    /**
     * This indicates that a launch did not occur because it did not have
     * appropriate resources. This error usually indicates that the user has
     * attempted to pass too many arguments to the device kernel, or the
     * kernel launch specifies too many threads for the kernel's register
     * count. Passing arguments of the wrong size (i.e. a 64-bit pointer
     * when a 32-bit int is expected) is equivalent to passing too many
     * arguments and can also result in this error.
     */
    {"RPP_ERROR_LAUNCH_OUT_OF_RESOURCES",
     "A launch did not occur because it did not have appropriate resources.",
     701},

    /**
     * This indicates that the device kernel took too long to execute. This can
     * only occur if timeouts are enabled - see the device attribute
     * ::RPP_DEVICE_ATTRIBUTE_KERNEL_EXEC_TIMEOUT for more information. The
     * context cannot be used (and must be destroyed similar to
     * ::RPP_ERROR_LAUNCH_FAILED). All existing device memory allocations from
     * this context are invalid and must be reconstructed if the program is to
     * continue using RPP.
     */
    {"RPP_ERROR_LAUNCH_TIMEOUT",
     "The device kernel took too long to execute.",
     702},

    /**
     * This error indicates a kernel launch that uses an incompatible texturing
     * mode.
     */
    {"RPP_ERROR_LAUNCH_INCOMPATIBLE_TEXTURING",
     "A kernel launch that uses an incompatible texturing mode.",
     703},

    /**
     * This error indicates that the primary context for the specified device
     * has already been initialized.
     */
    {"RPP_ERROR_PRIMARY_CONTEXT_ACTIVE",
     "The primary context for the specified device has already been initialized.",
     708},

    /**
     * This error indicates that the context current to the calling thread
     * has been destroyed using ::rppCtxDestroy, or is a primary context which
     * has not yet been initialized.
     */
    {"RPP_ERROR_CONTEXT_IS_DESTROYED",
     "The context current to the calling thread has been destroyed.",
     709},

    /**
     * A device-side assert triggered during kernel execution. The context
     * cannot be used anymore, and must be destroyed. All existing device
     * memory allocations from this context are invalid and must be
     * reconstructed if the program is to continue using RPP.
     */
    {"RPP_ERROR_ASSERT",
     "A device-side assert triggered during kernel execution.",
     710},

    /**
     * This error indicates that the memory range passed to
     * ::rppMemHostRegister() has already been registered.
     */
    {"RPP_ERROR_HOST_MEMORY_ALREADY_REGISTERED",
     "The memory range has already been registered.",
     712},

    /**
     * This error indicates that the pointer passed to ::rppMemHostUnregister()
     * does not correspond to any currently registered memory region.
     */
    {"RPP_ERROR_HOST_MEMORY_NOT_REGISTERED",
     "The pointer passed to ::rppMemHostUnregister() does not correspond to any currently registered memory region.",
     713},

    /**
     * While executing a kernel, the device encountered a stack error.
     * This can be due to stack corruption or exceeding the stack size limit.
     * This leaves the process in an inconsistent state and any further RPP
     * work will return the same error. To continue using RPP, the process must
     * be terminated and relaunched.
     */
    {"RPP_ERROR_HARDWARE_STACK_ERROR",
     "While executing a kernel, the device encountered a stack error.",
     714},

    /**
     * While executing a kernel, the device encountered an illegal instruction.
     * This leaves the process in an inconsistent state and any further RPP
     * work will return the same error. To continue using RPP, the process must
     * be terminated and relaunched.
     */
    {"RPP_ERROR_ILLEGAL_INSTRUCTION",
     "While executing a kernel, the device encountered an illegal instruction.",
     715},

    /**
     * While executing a kernel, the device encountered a load or store
     * instruction on a memory address which is not aligned. This leaves the
     * process in an inconsistent state and any further RPP work will return
     * the same error. To continue using RPP, the process must be terminated
     * and relaunched.
     */
    {"RPP_ERROR_MISALIGNED_ADDRESS",
     "While executing a kernel, the device encountered a load or store instruction on a memory address which is not aligned.",
     716},

    /**
     * While executing a kernel, the device encountered an instruction
     * which can only operate on memory locations in certain address spaces
     * (global, shared, or local), but was supplied a memory address not
     * belonging to an allowed address space.
     * This leaves the process in an inconsistent state and any further RPP
     * work will return the same error. To continue using RPP, the process must
     * be terminated and relaunched.
     */
    {"RPP_ERROR_INVALID_ADDRESS_SPACE",
     "While executing a kernel, the device encountered an instruction  which can only operate on memory locations in certain address spaces(global, shared, or local), but was supplied a memory address not belonging to an allowed address space.",
     717},

    /**
     * While executing a kernel, the device program counter wrapped its address
     * space. This leaves the process in an inconsistent state and any further
     * RPP work will return the same error. To continue using RPP, the process
     * must be terminated and relaunched.
     */
    {"RPP_ERROR_INVALID_PC",
     "While executing a kernel, the device program counter wrapped its address space.",
     718},

    /**
     * An exception occurred on the device while executing a kernel. Common
     * causes include dereferencing an invalid device pointer and accessing
     * out of bounds shared memory. The context cannot be used }, so it must
     * be destroyed (and a new one should be created). All existing device
     * memory allocations from this context are invalid and must be
     * reconstructed if the program is to continue using RPP.
     */
    {"RPP_ERROR_LAUNCH_FAILED",
     "An exception occurred on the device while executing a kernel.",
     719},

    /**
     * This error indicates that the number of blocks launched per grid for a
     * kernel that was launched via either ::rppLaunchCooperativeKernel or
     * ::rppLaunchCooperativeKernelMultiDevice exceeds the maximum number of
     * blocks as allowed by ::rppOccupancyMaxActiveBlocksPerMultiprocessor or
     * ::rppOccupancyMaxActiveBlocksPerMultiprocessorWithFlags times the number
     * of multiprocessors as specified by the device attribute
     * ::RPP_DEVICE_ATTRIBUTE_MULTIPROCESSOR_COUNT.
     */
    {"RPP_ERROR_COOPERATIVE_LAUNCH_TOO_LARGE",
     "This error indicates that the number of blocks launched per grid for a kernel.",
     720},

    /**
     * This error indicates that the attempted operation is not permitted.
     */
    {"RPP_ERROR_NOT_PERMITTED",
     "The attempted operation is not permitted.",
     800},

    /**
     * This error indicates that the attempted operation is not supported
     * on the current system or device.
     */
    {"RPP_ERROR_NOT_SUPPORTED",
     "The attempted operation is not supported on the current system or device.",
     801},

    /**
     * Graph executable update failed because update constraints were violated.
     * Check RPP_GRAPH_EXEC_UPDATE_RESULT_INFO for detailed reason.
     */
    {"RPP_ERROR_GRAPH_EXEC_UPDATE_FAILURE",
     "Graph executable update failed due to update constraints.",
     910},

    /**
     * This indicates that an unknown internal error has occurred.
     */
    {"RPP_ERROR_UNKNOWN",
     "An unknown internal error has occurred.",
     999},

    {NULL,
     NULL,
     -1}
};

#endif  //  COMMON_DRVAPI_ERROR_STRING_H_
