#ifndef _COMMON_H_
#define _COMMON_H_

#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <assert.h>

#include "rpp_osal.h"
#include "rpp_typedef.h"
#include "msg_def.h"
#include "list.h"
#include "log.h"
#include "rpp_pipe.h"


//#define USE_PTHREAD_MUTEX_INSTEAD

#ifdef USE_PTHREAD_MUTEX_INSTEAD

#define MUTEX_TYPE "osal_mutex_t"
#define fifo_mutex_t            osal_mutex_t
#define fifo_mutex_lock(p)      osal_mutex_lock(p)
#define fifo_mutex_unlock(p)    osal_mutex_unlock(p)
#define fifo_mutex_init(p)      osal_mutex_init(p)
#define fifo_mutex_destroy(p)   osal_mutex_destroy(p)

#else

#define MUTEX_TYPE "fifo_mutex_t"
#include "fifo_mutex.h"

#endif

#define MAX_FILENAME        255
#ifndef RPP_SIM_RT
#define RPP_DIR_NAME  "/dev"
#define RPP_DEV_NAME  "%s/rpp%d_entire_ctrl"
#define VE_DEV_NAME  "%s/ve%d_entire_ctrl"
#else
#define RPP_DIR_NAME  "/dev"
#define RPP_DEV_NAME  "%s/rpp_sim"
#endif
#if defined(_WIN32) || defined(_WIN64)
#define RPP_WORKSPACE       ".\\rpp"
#define RPP_PIPENAME        ".\\rpp\\rpp.pipe"
#else
#define RPP_WORKSPACE       "/tmp/rpp"
#define RPP_PIPENAME        "/tmp/rpp/rpp.pipe"
#endif

#define RPP_SOCK_DAEMON_IP      "127.0.0.1"     // RPP Client <--> RPP Daemon
#define RPP_SOCK_SERVER_IP      "127.0.0.1"     // RPP Client <--> RPP Server
#define RPP_SOCK_PTI_IP         "127.0.0.1"     // RPP Server <--> PTI Server

#define RPP_SOCK_DAEMON_PORT    36800
#define RPP_SOCK_SERVER_PORT    36801
#define RPP_SOCK_PTI_PORT       36802
#define RPP_REQ_PROBE        0x0
#define RPP_REQ_TERMINATE    0x1

#if defined(_WIN32) || defined(_WIN64)
#define PTI_NOTIFY_DIR      "\\tmp\\rpp"
#else
#define PTI_NOTIFY_DIR      "/tmp/rpp"
#endif
#define PTI_NOTIFY_ROOT     "pti"

#define RPP_GRAPH_POLICY_2       2  // Dispatch all nodes at rppGraphInstantiate
#define RPP_GRAPH_POLICY         RPP_GRAPH_POLICY_2

#define RPP_DRIVER_BUF_HOST_SIZE_LIMIT (64ULL * 1024 * 1024)

#ifndef offsetof
#define offsetof(TYPE, MEMBER) ((size_t) &((TYPE *)0)->MEMBER)
#endif

#ifndef container_of
#define container_of(ptr, type, member) (__extension__({              \
    const typeof( ((type *)0)->member ) *__mptr = (ptr);    \
    (type *)( (char *)__mptr - offsetof(type,member) );}))
#endif

extern int rdev_initialized;

typedef struct shm_bo {
    int shm_id;
    uint32_t size;
    uint32_t shm_size;
    uint32_t is_hugetlb;
    uint8_t *shm_ptr;
    uint64_t vaddr;
    struct list_head entry;
} shm_bo_t;

struct RPPctx_st {
    void *fakeptr;
};

struct RPPmodule_st{
    void *fakeptr;
};

struct RPPfunction_st{
    void *fakeptr;
};

struct RPPevent_st{
    void *fakeptr;
};

struct RPPstream_st{
    void *fakeptr;
};

struct RPPuuid_st{
    void *fakeptr;
};

struct RPPgraph_st{
    void *fakeptr;
};

struct RPPgraphExec_st{
    void *fakeptr;
};

struct RPPgraphNode_st{
    void *fakeptr;
};

struct RPPexternalMemory_st{
    void *fakeptr;
};

typedef struct rppProbe_params_st {
    unsigned int Flags;
} rppProbe_params;

typedef struct rppTerminate_params_st {
    unsigned int Flags;
} rppTerminate_params;

#define MSG_REQ_PROBE        _MSG(RPP_REQ_PROBE, rppProbe_params, 0)
#define MSG_REQ_TERMINATE    _MSG(RPP_REQ_TERMINATE, rppTerminate_params, 0)

#endif /* _COMMON_H_ */

