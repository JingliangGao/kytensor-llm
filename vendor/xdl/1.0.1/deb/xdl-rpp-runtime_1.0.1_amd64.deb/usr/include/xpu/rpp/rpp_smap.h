#pragma once
#include <rpp_runtime.h>
#include <rpp_drv_api.h>
#include <map>
#include <assert.h>
#include <rpp_sram_io.h>
#define MAX_BLOCK_SIZE 8192

typedef struct SmapInfo_t
{
    RPPdeviceptr addr;
    int size;
    int sizeRnd;
    int size_of_element;
}tSmapInfo;

class SramManager
{
public:
    SramManager(void){
        m_size = 0;
        m_used = 0;
    };
    ~SramManager(void){
        if(m_size != 0)
        {
            rppVirtSramFree(NULL, m_base);
            m_size = 0;
            m_used = 0;
            m_addr = 0;
            m_smap.clear();
        }
    };
   bool init(int workspace, bool isProfile = false){
        RPPdeviceptr sVirtBase;
        if(m_size == 0)
        {
	        assert(rppVirtSramAlloc(NULL, &m_base, workspace)==RPP_SUCCESS);
            m_size = workspace;
            m_used = 0;
            m_addr = m_base;
            m_profile = isProfile;
            m_smap.clear();
            sramIoInit(&handle_sio);
        }
        return RPP_SUCCESS;
    };
  bool release(){
      if(m_size != 0)
      {
	    rppVirtSramFree(NULL, m_base);
	    m_size = 0;
	    m_used = 0;
	    m_addr = 0;
	    m_smap.clear();
        sramIoExit(&handle_sio);
      }
	  return RPP_SUCCESS;
    };
   // BOOL unmap(void *daddr);
   void reformat_cpu(void *daddr, int size, RppFormat_e inFormat, RppFormat_e outFormat) {
       RPPdeviceptr src = (RPPdeviceptr)daddr;
       uint16_t *input = (uint16_t*)malloc(size);
       uint16_t *output = (uint16_t*)malloc(size);
       int elements = size / sizeof(float);
       rppMemcpyDtoH(input, src, size); 
       if (inFormat == HFMT && outFormat == RFMT) {
           for(int i = 0; i < elements; i++) {
              output[i] = input[2*i];
              output[i + elements] = input[2*i + 1];
           }
       } 
	   else if (inFormat == RFMT && outFormat == HFMT) {
           for(int i = 0; i < elements; i++) {
              output[2*i] = input[i];
              output[2*i + 1] = input[i + elements];
           }
       } 
	   else if (inFormat == HCFMT && outFormat == RCFMT) {
       	   elements = size / 8;
           for(int i = 0; i < elements; i++) {
			   output[i] = input[4*i];
			   output[i + elements] = input[4*i + 1];
			   output[i + 2*elements] = input[4*i + 2];
			   output[i + 3*elements] = input[4*i + 3];
           }
       }
	   else if (inFormat == RCFMT && outFormat == HCFMT) {
       	   elements = size / 8;
           for(int i = 0; i < elements; i++) {
			   output[4*i] = input[i];
			   output[4*i + 1] = input[i + elements];
			   output[4*i + 2] = input[i + 2*elements];
			   output[4*i + 3] = input[i + 3*elements];
           }
       }
       else
            assert(0);

       rppMemcpyHtoD(src, output, size);
       free(input);
       free(output);
   }
  void reformat(void *output, void *input, int w, int h, RppFormat_e inFormat, RppFormat_e outFormat, RPPstream stream = 0) {
    int elementSize = 4;
    if(inFormat==HCFMT || inFormat==RCFMT)
        elementSize = 8;
    int sizeRnd = (w+1)*(h+1)*elementSize;
    sizeRnd = (sizeRnd + 1023)/1024*1024 + 128;
    sizeRnd = sizeRnd * 2;
    RPPdeviceptr workspace = m_addr + sizeRnd;
    assert((m_used + sizeRnd) < m_size);
    rpp_reformat(&handle_sio, (float*)output, (float*)input, inFormat, outFormat, w, h, (float*)workspace, stream);
   }
  void reformat(void *output, int w, int h, RppFormat_e inFormat, RppFormat_e outFormat, RPPstream stream = 0) {
    int elementSize = 4;
    if(inFormat==HCFMT || inFormat==RCFMT)
        elementSize = 8;
    int sizeRnd = (w+1)*(h+1)*elementSize;
    sizeRnd = (sizeRnd + 1023)/1024*1024 + 128;
    sizeRnd = sizeRnd * 2;
    RPPdeviceptr workspace = m_addr + sizeRnd;
    assert((m_used + sizeRnd) < m_size);
    rpp_reformat(&handle_sio, (float*)output, (float*)output, inFormat, outFormat, w, h, (float*)workspace, stream);
   }
   bool download(void *daddr, RppFormat_e inFormat = HFMT, RppFormat_e outFormat = HFMT, RPPstream stream = 0) {
       if(m_profile)
            return RPP_SUCCESS;
       RPPdeviceptr src = (RPPdeviceptr)daddr;
       std::map<RPPdeviceptr, tSmapInfo>::iterator iter;
       iter = m_smap.find(src);
       if(iter == m_smap.end())
        assert(0);
       tSmapInfo mapInfo = iter->second;
       RPPdeviceptr dst = mapInfo.addr;
       int size = mapInfo.size;
       int sizeRnd = mapInfo.sizeRnd;
       int size_of_element = mapInfo.size_of_element;
       //printf("rppMemcpyDtoS, ddr %llx, sram %llx size=%d\n", (uint64_t)src, (uint64_t)dst, size);
       if(inFormat == outFormat || size_of_element != 4) {
            rppMemcpyDtoSAsync(dst, src, size, stream);
       }
       else {
                reformat_cpu((void*)src, size, inFormat, outFormat);
                rppMemcpyDtoSAsync(dst, src, size, stream);
       }
       return RPP_SUCCESS;
   }
   RPPdeviceptr base() {
       return m_base;
   }
   RPPdeviceptr addr() {
       return m_addr;
   }
   RPPdeviceptr size() {
       return m_size;
   }
RPPdeviceptr map(void *daddr, int size, int size_of_element = 4){
       RPPdeviceptr dst = (RPPdeviceptr)daddr;
       tSmapInfo mapInfo;
       std::map<RPPdeviceptr, tSmapInfo>::iterator iter;
       iter = m_smap.find(dst);
       if(iter == m_smap.end())
       {
           mapInfo.addr = m_addr;
           mapInfo.size = size;
		   mapInfo.size_of_element = size_of_element;
#ifdef DMA_REFORMAT
           int sizeRnd = ((size + 8191) >> 13) * 8192;
#else
           int sizeRnd = ((size + 1023) >> 10) * 1024;
#endif
           m_addr += sizeRnd;
           m_used += sizeRnd;
           mapInfo.sizeRnd = sizeRnd;
           assert(m_used < m_size);
           RPPdeviceptr key = (RPPdeviceptr)daddr;
           //printf("map address: sram = %llx ddr = %llx, size=%x \n", mapInfo.addr, (RPPdeviceptr)daddr, size);
           m_smap.insert(std::pair<RPPdeviceptr, tSmapInfo>(key, mapInfo));
       }
       else
       {
           mapInfo = iter->second;
       }
       return mapInfo.addr;
   }
float* cache(void *daddr) {
	  RPPdeviceptr dst = (RPPdeviceptr)daddr;
	  tSmapInfo mapInfo;
	  std::map<RPPdeviceptr, tSmapInfo>::iterator iter;
	  iter = m_smap.find(dst);
	  if(iter == m_smap.end())
	  {
		  assert(0);
	  }
	  else
	  {
		  mapInfo = iter->second;
	  }
	  return (float*)mapInfo.addr;
   }
   bool upload(void *daddr, RppFormat_e inFormat = HFMT, RppFormat_e outFormat = HFMT, RPPstream stream = 0, int sizeNew = 0) {
       if(m_profile)
            return RPP_SUCCESS;
       RPPdeviceptr dst = (RPPdeviceptr)daddr;
       std::map<RPPdeviceptr, tSmapInfo>::iterator iter;
       iter = m_smap.find(dst);
       if(iter == m_smap.end())
        assert(0);
       tSmapInfo mapInfo = iter->second;
       RPPdeviceptr src = mapInfo.addr;
       int size = mapInfo.size;
       int sizeRnd = mapInfo.sizeRnd;
	   int size_of_element = mapInfo.size_of_element;
       if(sizeNew)
       {
            assert(sizeNew <= size);
            size = sizeNew;
       }
       if(inFormat == outFormat || size_of_element != 4) {
            rppMemcpyStoDAsync(dst, src, size, stream);
       }
       else {
            rppMemcpyStoD(dst, src, size);
            reformat_cpu((void*)dst, size, inFormat, outFormat);
       }

       return RPP_SUCCESS;
   }
   bool clear() {
        m_used = 0;
        m_addr = m_base;
        m_smap.clear();
         return RPP_SUCCESS;
   }
   RPPdeviceptr cvt(void *daddr) {
       RPPdeviceptr dst = (RPPdeviceptr)daddr;
       std::map<RPPdeviceptr, tSmapInfo>::iterator iter;
       iter = m_smap.find(dst);
       if(iter == m_smap.end())
        assert(0);
       tSmapInfo mapInfo = iter->second;
       return mapInfo.addr;
   }
   // bool loadGroup();
   // void* saddr(void *daddr);

private:


public:


private:
    RPPdeviceptr m_base;
    RPPdeviceptr m_addr;
    int m_size;
    int m_used;
    bool m_profile;
	std::map<RPPdeviceptr, tSmapInfo> m_smap;
    rppSramIoHandle handle_sio;
};

