#if !defined(__PTI_VERSION_H__)
#define __PTI_VERSION_H__

#include <pti_result.h>

#ifndef PTIAPI
#ifdef _WIN32
#define PTIAPI __stdcall
#else
#define PTIAPI
#endif
#endif

#if defined(__cplusplus)
extern "C" {
#endif

/**
 * \defgroup PTI_VERSION_API PTI Version
 * Function and macro to determine the PTI version.
 * @{
 */

/**
 * \brief The API version for this implementation of RPP PTI.
 *
 * The API version for this implementation of PTI. This define along
 * with \ref ptiGetVersion can be used to dynamically detect if the
 * version of PTI compiled against matches the version of the loaded
 * PTI library.
 *
 */
#define PTI_API_VERSION 1

/**
 * \brief Get the PTI API version.
 *
 * Return the API version in \p *version.
 *
 * \param version Returns the version
 *
 * \retval PTI_SUCCESS on success
 * \retval PTI_ERROR_INVALID_PARAMETER if \p version is NULL
 * \sa PTI_API_VERSION
 */
PTIResult PTIAPI ptiGetVersion(uint32_t *version);

/** @} */ /* END PTI_VERSION_API */

#if defined(__cplusplus)
}
#endif

#endif /*__PTI_VERSION_H__*/

