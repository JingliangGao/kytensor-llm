/*****************************************************************************
 *
 * <COPYRIGHT_TAG>
 *
 *****************************************************************************/
 /*
 *****************************************************************************
 * Doxygen group definitions
 ****************************************************************************/
/*****************************************************************************
 * @file rpp_typedef.h
 *
 * @description
 *      This file contains the data type definition that are used by
 *      RPP SW framework.
 *
 *****************************************************************************/

#ifndef  RPP_TYPEDEF_H
#define RPP_TYPEDEF_H

#ifdef __cplusplus
extern "C" {
#endif

#if defined (__linux__) && defined (__KERNEL__)

/* Linux kernel mode */
#include <linux/kernel.h>
#include <linux/types.h>

#elif defined (__FreeBSD__) && defined (_KERNEL)

/* FreeBSD kernel mode */
#include <sys/types.h>
#include <sys/param.h>
#include <sys/kernel.h>

#elif defined (_WIN64) && defined (KERNEL_SPACE)

/* Windows kernel mode */
#include <ntddk.h>
#include <stdio.h>
#include <stddef.h>
#include <stdint.h>

#elif defined (__linux__) || defined (__FreeBSD__) || defined (WIN32) || defined (_WIN64)

/* Linux, FreeBSD, or Windows user mode */
#include <stdio.h>
#include <stddef.h>
#include <stdint.h>

#else
#error Unsupported operating system
#endif /* OS and mode */

#if defined (WIN32) || defined (_WIN64)
/* nonstandard extension used : zero-sized array in struct/union */
#pragma warning (disable: 4200)
#endif

typedef uint8_t Rpp8U;
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_Types
 * Unsigned byte base type. */
typedef int8_t Rpp8S;
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_typedef
 * Signed byte base type. */
typedef uint16_t Rpp16U;
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_type
 * Unsigned double-byte base type. */
typedef int16_t Rpp16S;
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_type
 * Signed double-byte base type. */
typedef uint32_t Rpp32U;
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_type
 * Unsigned quad-byte base type. */
typedef int32_t Rpp32S;
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_type
 * Signed quad-byte base type. */
typedef uint64_t Rpp64U;
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_type
 * Unsigned double-quad-byte base type. */
typedef int64_t Rpp64S;
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_typedef
 * Signed double-quad-byte base type. */

/*****************************************************************************
 *      Generic Base Data Type definitions
 *****************************************************************************/
#ifndef NULL
#define NULL (0)
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_typedef
 * NULL definition. */
#endif

#ifndef TRUE
#define TRUE (1==1)
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_typedef
 * True value definition. */
#endif
#ifndef FALSE
#define FALSE (0==1)
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_typedef
 * False value definition. */
#endif

typedef    void         __global__;
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_typedef
 * global function. */


/**
 *****************************************************************************
 * @file rpp_typedef.h
 * @ingroup rpp_typedef
 *      Boolean type.
 *
 * @description
 *      Functions in this API use this type for Boolean variables that take
 *      true or false values.
 *
 *****************************************************************************/
typedef enum _RppBoolean
{
    RPP_FALSE = FALSE, /**< False value */
    RPP_TRUE = TRUE /**< True value */
} RppBoolean;


/**
 *****************************************************************************
 * @file rpp_typedef.h
 * @ingroup rpp_typedef
 *      Declare a bitmap of specified size (in bits).
 *
 * @description
 *      This macro is used to declare a bitmap of arbitrary size.
 *
 *      To test whether a bit in the bitmap is set, use @ref
 *      RPP_BITMAP_BIT_TEST.
 *
 *      While most uses of bitmaps on the API are read-only, macros are also
 *      provided to set (see @ref RPP_BITMAP_BIT_SET) and clear (see @ref
 *      RPP_BITMAP_BIT_CLEAR) bits in the bitmap.
 *****************************************************************************/
#define RPP_BITMAP(name, sizeInBits) \
        RPP32U name[((sizeInBits)+31)/32]

#define RPP_BITMAP_BIT_TEST(bitmask, bit) \
        ((bitmask[(bit)/32]) & (0x1 << ((bit)%32)))
/**<
 * @ingroup rpp_typedef
 * Test a specified bit in the specified bitmap.  The bitmap may have been
 * declared using @ref RPP_BITMAP.  Returns a Boolean (true if the bit is
 * set, false otherwise). */

#define RPP_BITMAP_BIT_SET(bitmask, bit) \
        (bitmask[(bit)/32] |= (0x1 << ((bit)%32)))
/**<
 * @file rpp_typedef.h
 * @ingroup rpp_typedef
 * Set a specified bit in the specified bitmap.  The bitmap may have been
 * declared using @ref RPP_BITMAP. */

#define RPP_BITMAP_BIT_CLEAR(bitmask, bit) \
        (bitmask[(bit)/32] &= ~(0x1 << ((bit)%32)))
/**<
 * @ingroup rpp_typedef
 * Clear a specified bit in the specified bitmap.  The bitmap may have been
 * declared using @ref RPP_BITMAP. */


/**
 **********************************************************************
 *
 * @ingroup rpp_typedef
 *
 * @description
 *       Declare a function or type and mark it as deprecated so that
 *       usages get flagged with a warning.
 *
 **********************************************************************
 */
#if defined(__GNUC__) || defined(__INTEL_COMPILER) || defined(_WIN64)
/*
 * gcc and icc support the __attribute__ ((deprecated)) syntax for marking
 * functions and other constructs as deprecated.
 */
/*
 * Uncomment the deprecated macro if you need to see which structs are deprecated
 */
#define RPP_DEPRECATED 
/*#define RPP_DEPRECATED __attribute__ ((deprecated)) */
#else
/*
 * for all other compilers, define deprecated to do nothing
 *
 */
/* #define RPP_DEPRECATED_FUNC(func) func; #pragma deprecated(func) */
#pragma message("WARNING: You need to implement the RPP_DEPRECATED macro for this compiler")
#define RPP_DEPRECATED
#endif

#define _DEBUG_
#define SW_DEBUG
#define MAX_INT16           32767
#define MIN_INT16           -32768
#define MAX_GROUP           2



#ifdef __cplusplus
} /* close the extern "C" { */
#endif


#endif



