#if !defined(__PTI_ACTIVITY_H__)
#define __PTI_ACTIVITY_H__

#include <pti_callbacks.h>
#include <pti_events.h>
#include <pti_metrics.h>
#include <pti_result.h>
#include "rpp_drv_api.h"

#ifndef PTIAPI
#ifdef _WIN32
#define PTIAPI __stdcall
#else
#define PTIAPI
#endif
#endif

#if defined(__LP64__)
#define PTILP64 1
#elif defined(_WIN64)
#define PTILP64 1
#else
#undef PTILP64
#endif

#define ACTIVITY_RECORD_ALIGNMENT 8
#if defined (_WIN32) || defined (_WIN64) // Windows 32- and 64-bit
#define START_PACKED_ALIGNMENT __pragma(pack(push,1)) // exact fit - no padding
#define PACKED_ALIGNMENT __declspec(align(ACTIVITY_RECORD_ALIGNMENT))
#define END_PACKED_ALIGNMENT __pragma(pack(pop))
#elif defined(__GNUC__) // GCC
#define START_PACKED_ALIGNMENT
#define PACKED_ALIGNMENT __attribute__ ((__packed__)) __attribute__ ((aligned (ACTIVITY_RECORD_ALIGNMENT)))
#define END_PACKED_ALIGNMENT
#else // all other compilers
#define START_PACKED_ALIGNMENT
#define PACKED_ALIGNMENT
#define END_PACKED_ALIGNMENT
#endif

#define MAX_PATH_LEN 		1024
#define MAX_FUNC_NAME 		255
#define MAX_DEVICE_NAME		32
#define MAX_NAME	 		32

#define PTI_UNIFIED_MEMORY_CPU_DEVICE_ID ((uint32_t) 0xFFFFFFFFU)
#if defined(__cplusplus)
extern "C" {
#endif

/**
 * \defgroup PTI_ACTIVITY_API PTI Activity API
 * Functions, types, and enums that implement the PTI Activity API.
 * @{
 */

/**
 * \brief The kinds of activity records.
 *
 * Each activity record kind represents information about a GPU or an
 * activity occurring on a CPU or GPU. Each kind is associated with a
 * activity record structure that holds the information associated
 * with the kind.
 * \see pti_Activity
 * \see pti_ActivityAPI
 * \see pti_ActivityContext
 * \see pti_ActivityDevice
 * \see pti_ActivityDevice2
 * \see pti_ActivityDeviceAttribute
 * \see pti_ActivityEvent
 * \see pti_ActivityEventInstance
 * \see pti_ActivityKernel
 * \see pti_ActivityKernel2
 * \see pti_ActivityKernel3
 * \see pti_ActivityKernel4
 * \see pti_ActivityCdpKernel
 * \see pti_ActivityPreemption
 * \see pti_ActivityMemcpy
 * \see pti_ActivityMemcpy2
 * \see pti_ActivityMemset
 * \see pti_ActivityMetric
 * \see pti_ActivityMetricInstance
 * \see pti_ActivityName
 * \see pti_ActivityMarker
 * \see pti_ActivityMarker2
 * \see pti_ActivityMarkerData
 * \see pti_ActivitySourceLocator
 * \see pti_ActivityGlobalAccess
 * \see pti_ActivityGlobalAccess2
 * \see pti_ActivityGlobalAccess3
 * \see pti_ActivityBranch
 * \see pti_ActivityBranch2
 * \see pti_ActivityOverhead
 * \see pti_ActivityEnvironment
 * \see pti_ActivityInstructionExecution
 * \see pti_ActivityUnifiedMemoryCounter
 * \see pti_ActivityFunction
 * \see pti_ActivityModule
 * \see pti_ActivitySharedAccess
 * \see pti_ActivityPCSampling
 * \see pti_ActivityPCSampling2
 * \see pti_ActivityPCSampling3
 * \see pti_ActivityPCSamplingRecordInfo
 * \see pti_ActivityRppEvent
 * \see pti_ActivityStream
 * \see pti_ActivitySynchronization
 * \see pti_ActivityInstructionCorrelation
 * \see pti_ActivityExternalCorrelation
 * \see pti_ActivityUnifiedMemoryCounter2
 * \see pti_ActivityOpenAccData
 * \see pti_ActivityOpenAccLaunch
 * \see pti_ActivityOpenAccOther
 * \see pti_ActivityNvLink
 * \see pti_ActivityNvLink2
 * \see pti_ActivityMemory
 */
typedef enum {
  /**
   * The activity record is invalid.
   */
  PTI_ACTIVITY_KIND_INVALID  = 0,
  /**
   * A host<->host, host<->device, or device<->device memory copy. The
   * corresponding activity record structure is \ref
   * pti_ActivityMemcpy.
   */
  PTI_ACTIVITY_KIND_MEMCPY   = 1,
  /**
   * A memory set executing on the GPU. The corresponding activity
   * record structure is \ref pti_ActivityMemset.
   */
  PTI_ACTIVITY_KIND_MEMSET   = 2,
  /**
   * A kernel executing on the GPU. The corresponding activity record
   * structure is \ref pti_ActivityKernel4.
   */
  PTI_ACTIVITY_KIND_KERNEL   = 3,
  /**
   * A RPP driver API function execution. The corresponding activity
   * record structure is \ref pti_ActivityAPI.
   */
  PTI_ACTIVITY_KIND_DRIVER   = 4,
  /**
   * A RPP runtime API function execution. The corresponding activity
   * record structure is \ref pti_ActivityAPI.
   */
  PTI_ACTIVITY_KIND_RUNTIME  = 5,
  /**
   * An event value. The corresponding activity record structure is
   * \ref pti_ActivityEvent.
   */
  PTI_ACTIVITY_KIND_EVENT    = 6,
  /**
   * A metric value. The corresponding activity record structure is
   * \ref pti_ActivityMetric.
   */
  PTI_ACTIVITY_KIND_METRIC   = 7,
  /**
   * Information about a device. The corresponding activity record
   * structure is \ref pti_ActivityDevice2.
   */
  PTI_ACTIVITY_KIND_DEVICE   = 8,
  /**
   * Information about a context. The corresponding activity record
   * structure is \ref pti_ActivityContext.
   */
  PTI_ACTIVITY_KIND_CONTEXT  = 9,
  /**
   * A (potentially concurrent) kernel executing on the GPU. The
   * corresponding activity record structure is \ref
   * pti_ActivityKernel4.
   */
  PTI_ACTIVITY_KIND_CONCURRENT_KERNEL = 10,
  /**
   * Thread, device, context, etc. name. The corresponding activity
   * record structure is \ref pti_ActivityName.
   */
  PTI_ACTIVITY_KIND_NAME     = 11,
  /**
   * Instantaneous, start, or end marker. The corresponding activity
   * record structure is \ref pti_ActivityMarker2.
   */
  PTI_ACTIVITY_KIND_MARKER = 12,
  /**
   * Extended, optional, data about a marker. The corresponding
   * activity record structure is \ref pti_ActivityMarkerData.
   */
  PTI_ACTIVITY_KIND_MARKER_DATA = 13,
  /**
   * Source information about source level result. The corresponding
   * activity record structure is \ref pti_ActivitySourceLocator.
   */
  PTI_ACTIVITY_KIND_SOURCE_LOCATOR = 14,
  /**
   * Results for source-level global acccess. The
   * corresponding activity record structure is \ref
   * pti_ActivityGlobalAccess3.
   */
  PTI_ACTIVITY_KIND_GLOBAL_ACCESS = 15,
  /**
   * Results for source-level branch. The corresponding
   * activity record structure is \ref pti_ActivityBranch2.
   */
  PTI_ACTIVITY_KIND_BRANCH = 16,
  /**
   * Overhead activity records. The
   * corresponding activity record structure is
   * \ref pti_ActivityOverhead.
   */
  PTI_ACTIVITY_KIND_OVERHEAD = 17,
  /**
   * A CDP (RPP Dynamic Parallel) kernel executing on the GPU. The
   * corresponding activity record structure is \ref
   * pti_ActivityCdpKernel.  This activity can not be directly
   * enabled or disabled. It is enabled and disabled through
   * concurrent kernel activity i.e. _CONCURRENT_KERNEL
   */
  PTI_ACTIVITY_KIND_CDP_KERNEL = 18,
  /**
   * Preemption activity record indicating a preemption of a CDP (RPP
   * Dynamic Parallel) kernel executing on the GPU. The corresponding
   * activity record structure is \ref pti_ActivityPreemption.
   */
  PTI_ACTIVITY_KIND_PREEMPTION = 19,
  /**
   * Environment activity records indicating power, clock, thermal,
   * etc. levels of the GPU. The corresponding activity record
   * structure is \ref pti_ActivityEnvironment.
   */
  PTI_ACTIVITY_KIND_ENVIRONMENT = 20,
  /**
   * An event value associated with a specific event domain
   * instance. The corresponding activity record structure is \ref
   * pti_ActivityEventInstance.
   */
  PTI_ACTIVITY_KIND_EVENT_INSTANCE = 21,
  /**
   * A peer to peer memory copy. The corresponding activity record
   * structure is \ref pti_ActivityMemcpy2.
   */
  PTI_ACTIVITY_KIND_MEMCPY2 = 22,
  /**
   * A metric value associated with a specific metric domain
   * instance. The corresponding activity record structure is \ref
   * pti_ActivityMetricInstance.
   */
  PTI_ACTIVITY_KIND_METRIC_INSTANCE = 23,
  /**
   * Results for source-level instruction execution.
   * The corresponding activity record structure is \ref
   * pti_ActivityInstructionExecution.
   */
  PTI_ACTIVITY_KIND_INSTRUCTION_EXECUTION = 24,
  /**
   * Unified Memory counter record. The corresponding activity
   * record structure is \ref pti_ActivityUnifiedMemoryCounter2.
   */
  PTI_ACTIVITY_KIND_UNIFIED_MEMORY_COUNTER = 25,
  /**
   * Device global/function record. The corresponding activity
   * record structure is \ref pti_ActivityFunction.
   */
  PTI_ACTIVITY_KIND_FUNCTION = 26,
  /**
   * RPP Module record. The corresponding activity
   * record structure is \ref pti_ActivityModule.
   */
  PTI_ACTIVITY_KIND_MODULE = 27,
  /**
   * A device attribute value. The corresponding activity record
   * structure is \ref pti_ActivityDeviceAttribute.
   */
  PTI_ACTIVITY_KIND_DEVICE_ATTRIBUTE   = 28,
  /**
   * Results for source-level shared acccess. The
   * corresponding activity record structure is \ref
   * pti_ActivitySharedAccess.
   */
  PTI_ACTIVITY_KIND_SHARED_ACCESS = 29,
  /**
   * Enable PC sampling for kernels. This will serialize
   * kernels. The corresponding activity record structure
   * is \ref pti_ActivityPCSampling3.
   */
  PTI_ACTIVITY_KIND_PC_SAMPLING = 30,
  /**
   * Summary information about PC sampling records. The
   * corresponding activity record structure is \ref
   * pti_ActivityPCSamplingRecordInfo.
   */
  PTI_ACTIVITY_KIND_PC_SAMPLING_RECORD_INFO = 31,
  /**
   * SASS/Source line-by-line correlation record.
   * This will generate sass/source correlation for functions that have source
   * level analysis or pc sampling results. The records will be generated only
   * when either of source level analysis or pc sampling activity is enabled.
   * The corresponding activity record structure is \ref
   * pti_ActivityInstructionCorrelation.
   */
  PTI_ACTIVITY_KIND_INSTRUCTION_CORRELATION = 32,
  /**
   * OpenACC data events.
   * The corresponding activity record structure is \ref
   * pti_ActivityOpenAccData.
   */
  PTI_ACTIVITY_KIND_OPENACC_DATA = 33,
  /**
   * OpenACC launch events.
   * The corresponding activity record structure is \ref
   * pti_ActivityOpenAccLaunch.
   */
  PTI_ACTIVITY_KIND_OPENACC_LAUNCH = 34,
  /**
   * OpenACC other events.
   * The corresponding activity record structure is \ref
   * pti_ActivityOpenAccOther.
   */
  PTI_ACTIVITY_KIND_OPENACC_OTHER = 35,
  /**
   * Information about a RPP event. The
   * corresponding activity record structure is \ref
   * pti_ActivityRppEvent.
   */
  PTI_ACTIVITY_KIND_RPP_EVENT = 36,
  /**
   * Information about a RPP stream. The
   * corresponding activity record structure is \ref
   * pti_ActivityStream.
   */
  PTI_ACTIVITY_KIND_STREAM = 37,
  /**
   * Records for synchronization management. The
   * corresponding activity record structure is \ref
   * pti_ActivitySynchronization.
   */
  PTI_ACTIVITY_KIND_SYNCHRONIZATION = 38,
  /**
   * Records for correlation of different programming APIs. The
   * corresponding activity record structure is \ref
   * pti_ActivityExternalCorrelation.
   */
  PTI_ACTIVITY_KIND_EXTERNAL_CORRELATION = 39,
  /**
   * NVLink information.
   * The corresponding activity record structure is \ref
   * pti_ActivityNvLink2.
   */
  PTI_ACTIVITY_KIND_NVLINK = 40,
  /**
   * Instantaneous Event information.
   * The corresponding activity record structure is \ref
   * pti_ActivityInstantaneousEvent.
   */
  PTI_ACTIVITY_KIND_INSTANTANEOUS_EVENT = 41,
  /**
   * Instantaneous Event information for a specific event
   * domain instance.
   * The corresponding activity record structure is \ref
   * pti_ActivityInstantaneousEventInstance
   */
  PTI_ACTIVITY_KIND_INSTANTANEOUS_EVENT_INSTANCE = 42,
  /**
   * Instantaneous Metric information
   * The corresponding activity record structure is \ref
   * pti_ActivityInstantaneousMetric.
   */
  PTI_ACTIVITY_KIND_INSTANTANEOUS_METRIC = 43,
  /**
   * Instantaneous Metric information for a specific metric
   * domain instance.
   * The corresponding activity record structure is \ref
   * pti_ActivityInstantaneousMetricInstance.
   */
  PTI_ACTIVITY_KIND_INSTANTANEOUS_METRIC_INSTANCE = 44,
  /*
   * Memory activity tracking allocation and freeing of the memory
   * The corresponding activity record structure is \ref
   * pti_ActivityMemory.
   */
  PTI_ACTIVITY_KIND_MEMORY = 45,

  PTI_ACTIVITY_KIND_MAX = 46,

  PTI_ACTIVITY_KIND_FORCE_INT     = 0x7fffffff
} pti_ActivityKind;

/**
 * \brief The kinds of activity objects.
 * \see pti_ActivityObjectKindId
 */
typedef enum {
  /**
   * The object kind is not known.
   */
  PTI_ACTIVITY_OBJECT_UNKNOWN  = 0,
  /**
   * A process.
   */
  PTI_ACTIVITY_OBJECT_PROCESS  = 1,
  /**
   * A thread.
   */
  PTI_ACTIVITY_OBJECT_THREAD   = 2,
  /**
   * A device.
   */
  PTI_ACTIVITY_OBJECT_DEVICE   = 3,
  /**
   * A context.
   */
  PTI_ACTIVITY_OBJECT_CONTEXT  = 4,
  /**
   * A stream.
   */
  PTI_ACTIVITY_OBJECT_STREAM   = 5,

  PTI_ACTIVITY_OBJECT_FORCE_INT = 0x7fffffff
} pti_ActivityObjectKind;

/**
 * \brief Identifiers for object kinds as specified by
 * pti_ActivityObjectKind.
 * \see pti_ActivityObjectKind
 */
typedef union {
  /**
   * A process object requires that we identify the process ID. A
   * thread object requires that we identify both the process and
   * thread ID.
   */
  struct {
    uint32_t processId;
    uint32_t threadId;
  } pt;
  /**
   * A device object requires that we identify the device ID. A
   * context object requires that we identify both the device and
   * context ID. A stream object requires that we identify device,
   * context, and stream ID.
   */
  struct {
    uint32_t deviceId;
    uint32_t contextId;
    uint32_t streamId;
  } dcs;
} pti_ActivityObjectKindId;

/**
 * \brief The kinds of activity overhead.
 */
typedef enum {
  /**
   * The overhead kind is not known.
   */
  PTI_ACTIVITY_OVERHEAD_UNKNOWN               = 0,
  /**
   * Compiler(JIT) overhead.
   */
  PTI_ACTIVITY_OVERHEAD_DRIVER_COMPILER       = 1,
  /**
   * Activity buffer flush overhead.
   */
  PTI_ACTIVITY_OVERHEAD_PTI_BUFFER_FLUSH    = 1<<16,
  /**
   * PTI instrumentation overhead.
   */
  PTI_ACTIVITY_OVERHEAD_PTI_INSTRUMENTATION = 2<<16,
  /**
   * PTI resource creation and destruction overhead.
   */
  PTI_ACTIVITY_OVERHEAD_PTI_RESOURCE        = 3<<16,
  PTI_ACTIVITY_OVERHEAD_FORCE_INT             = 0x7fffffff
} pti_ActivityOverheadKind;

/**
 * \brief The kind of a compute API.
 */
typedef enum {
  /**
   * The compute API is not known.
   */
  PTI_ACTIVITY_COMPUTE_API_UNKNOWN    = 0,
  /**
   * The compute APIs are for RPP.
   */
  PTI_ACTIVITY_COMPUTE_API_RPP       = 1,
  /**
   * The compute APIs are for RPP running
   * in MPS (Multi-Process Service) environment.
   */
  PTI_ACTIVITY_COMPUTE_API_RPP_MPS   = 2,

  PTI_ACTIVITY_COMPUTE_API_FORCE_INT  = 0x7fffffff
} pti_ActivityComputeApiKind;

/**
 * \brief Flags associated with activity records.
 *
 * Activity record flags. Flags can be combined by bitwise OR to
 * associated multiple flags with an activity record. Each flag is
 * specific to a certain activity kind, as noted below.
 */
typedef enum {
  /**
   * Indicates the activity record has no flags.
   */
  PTI_ACTIVITY_FLAG_NONE          = 0,

  /**
   * Indicates the activity represents a device that supports
   * concurrent kernel execution. Valid for
   * PTI_ACTIVITY_KIND_DEVICE.
   */
  PTI_ACTIVITY_FLAG_DEVICE_CONCURRENT_KERNELS  = 1 << 0,

  /**
   * Indicates if the activity represents a RPPdevice_attribute value
   * or a pti_DeviceAttribute value. Valid for
   * PTI_ACTIVITY_KIND_DEVICE_ATTRIBUTE.
   */
  PTI_ACTIVITY_FLAG_DEVICE_ATTRIBUTE_RPPDEVICE  = 1 << 0,

  /**
   * Indicates the activity represents an asynchronous memcpy
   * operation. Valid for PTI_ACTIVITY_KIND_MEMCPY.
   */
  PTI_ACTIVITY_FLAG_MEMCPY_ASYNC  = 1 << 0,

  /**
   * Indicates the activity represents an instantaneous marker. Valid
   * for PTI_ACTIVITY_KIND_MARKER.
   */
  PTI_ACTIVITY_FLAG_MARKER_INSTANTANEOUS  = 1 << 0,

  /**
   * Indicates the activity represents a region start marker. Valid
   * for PTI_ACTIVITY_KIND_MARKER.
   */
  PTI_ACTIVITY_FLAG_MARKER_START  = 1 << 1,

  /**
   * Indicates the activity represents a region end marker. Valid for
   * PTI_ACTIVITY_KIND_MARKER.
   */
  PTI_ACTIVITY_FLAG_MARKER_END  = 1 << 2,

  /**
   * Indicates the activity represents an attempt to acquire a user
   * defined synchronization object.
   * Valid for PTI_ACTIVITY_KIND_MARKER.
   */
  PTI_ACTIVITY_FLAG_MARKER_SYNC_ACQUIRE = 1 << 3,

  /**
   * Indicates the activity represents success in acquiring the
   * user defined synchronization object.
   * Valid for PTI_ACTIVITY_KIND_MARKER.
   */
  PTI_ACTIVITY_FLAG_MARKER_SYNC_ACQUIRE_SUCCESS = 1 << 4,

  /**
   * Indicates the activity represents failure in acquiring the
   * user defined synchronization object.
   * Valid for PTI_ACTIVITY_KIND_MARKER.
   */
  PTI_ACTIVITY_FLAG_MARKER_SYNC_ACQUIRE_FAILED = 1 << 5,

  /**
   * Indicates the activity represents releasing a reservation on
   * user defined synchronization object.
   * Valid for PTI_ACTIVITY_KIND_MARKER.
   */
  PTI_ACTIVITY_FLAG_MARKER_SYNC_RELEASE = 1 << 6,

  /**
   * Indicates the activity represents a marker that does not specify
   * a color. Valid for PTI_ACTIVITY_KIND_MARKER_DATA.
   */
  PTI_ACTIVITY_FLAG_MARKER_COLOR_NONE  = 1 << 0,

  /**
   * Indicates the activity represents a marker that specifies a color
   * in alpha-red-green-blue format. Valid for
   * PTI_ACTIVITY_KIND_MARKER_DATA.
   */
  PTI_ACTIVITY_FLAG_MARKER_COLOR_ARGB  = 1 << 1,

  /**
   * The number of bytes requested by each thread
   * Valid for pti_ActivityGlobalAccess3.
   */
  PTI_ACTIVITY_FLAG_GLOBAL_ACCESS_KIND_SIZE_MASK  = 0xFF << 0,
  /**
   * If bit in this flag is set, the access was load, else it is a
   * store access. Valid for pti_ActivityGlobalAccess3.
   */
  PTI_ACTIVITY_FLAG_GLOBAL_ACCESS_KIND_LOAD       = 1 << 8,
  /**
   * If this bit in flag is set, the load access was cached else it is
   * uncached. Valid for pti_ActivityGlobalAccess3.
   */
  PTI_ACTIVITY_FLAG_GLOBAL_ACCESS_KIND_CACHED     = 1 << 9,
  /**
   * If this bit in flag is set, the metric value overflowed. Valid
   * for pti_ActivityMetric and pti_ActivityMetricInstance.
   */
  PTI_ACTIVITY_FLAG_METRIC_OVERFLOWED     = 1 << 0,
  /**
   * If this bit in flag is set, the metric value couldn't be
   * calculated. This occurs when a value(s) required to calculate the
   * metric is missing.  Valid for pti_ActivityMetric and
   * pti_ActivityMetricInstance.
   */
  PTI_ACTIVITY_FLAG_METRIC_VALUE_INVALID  = 1 << 1,
    /**
   * If this bit in flag is set, the source level metric value couldn't be
   * calculated. This occurs when a value(s) required to calculate the
   * source level metric cannot be evaluated.
   * Valid for pti_ActivityInstructionExecution.
   */
  PTI_ACTIVITY_FLAG_INSTRUCTION_VALUE_INVALID  = 1 << 0,
  /**
   * The mask for the instruction class, \ref pti_ActivityInstructionClass
   * Valid for pti_ActivityInstructionExecution and
   * pti_ActivityInstructionCorrelation
   */
  PTI_ACTIVITY_FLAG_INSTRUCTION_CLASS_MASK    = 0xFF << 1,
  /**
   * When calling cuptiActivityFlushAll, this flag
   * can be set to force PTI to flush all records in the buffer, whether
   * finished or not
   */
  PTI_ACTIVITY_FLAG_FLUSH_FORCED = 1 << 0,

  /**
   * The number of bytes requested by each thread
   * Valid for pti_ActivitySharedAccess.
   */
  PTI_ACTIVITY_FLAG_SHARED_ACCESS_KIND_SIZE_MASK  = 0xFF << 0,
  /**
   * If bit in this flag is set, the access was load, else it is a
   * store access.  Valid for pti_ActivitySharedAccess.
   */
  PTI_ACTIVITY_FLAG_SHARED_ACCESS_KIND_LOAD       = 1 << 8,

  /**
   * Indicates the activity represents an asynchronous memset
   * operation. Valid for PTI_ACTIVITY_KIND_MEMSET.
   */
  PTI_ACTIVITY_FLAG_MEMSET_ASYNC  = 1 << 0,

  /**
   * Indicates the activity represents thrashing in CPU.
   * Valid for counter of kind PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_THRASHING in
   * PTI_ACTIVITY_KIND_UNIFIED_MEMORY_COUNTER
   */
  PTI_ACTIVITY_FLAG_THRASHING_IN_CPU = 1 << 0,

 /**
   * Indicates the activity represents page throttling in CPU.
   * Valid for counter of kind PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_THROTTLING in
   * PTI_ACTIVITY_KIND_UNIFIED_MEMORY_COUNTER
   */
  PTI_ACTIVITY_FLAG_THROTTLING_IN_CPU = 1 << 0,

  PTI_ACTIVITY_FLAG_FORCE_INT = 0x7fffffff
} pti_ActivityFlag;

/**
 * \brief The stall reason for PC sampling activity.
 */
typedef enum {
  /**
   * Invalid reason
   */
  PTI_ACTIVITY_PC_SAMPLING_STALL_INVALID      = 0,
   /**
   * No stall, instruction is selected for issue
   */
  PTI_ACTIVITY_PC_SAMPLING_STALL_NONE         = 1,
  /**
   * Warp is blocked because next instruction is not yet available,
   * because of instruction cache miss, or because of branching effects
   */
  PTI_ACTIVITY_PC_SAMPLING_STALL_INST_FETCH   = 2,
  /**
   * Instruction is waiting on an arithmatic dependency
   */
  PTI_ACTIVITY_PC_SAMPLING_STALL_EXEC_DEPENDENCY   = 3,
  /**
   * Warp is blocked because it is waiting for a memory access to complete.
   */
  PTI_ACTIVITY_PC_SAMPLING_STALL_MEMORY_DEPENDENCY   = 4,
  /**
   * Texture sub-system is fully utilized or has too many outstanding requests.
   */
  PTI_ACTIVITY_PC_SAMPLING_STALL_TEXTURE   = 5,
  /**
   * Warp is blocked as it is waiting at __syncthreads() or at memory barrier.
   */
  PTI_ACTIVITY_PC_SAMPLING_STALL_SYNC   = 6,
  /**
   * Warp is blocked waiting for __constant__ memory and immediate memory access to complete.
   */
  PTI_ACTIVITY_PC_SAMPLING_STALL_CONSTANT_MEMORY_DEPENDENCY   = 7,
  /**
   * Compute operation cannot be performed due to the required resources not
   * being available.
   */
  PTI_ACTIVITY_PC_SAMPLING_STALL_PIPE_BUSY   = 8,
  /**
   * Warp is blocked because there are too many pending memory operations.
   * In Kepler architecture it often indicates high number of memory replays.
   */
  PTI_ACTIVITY_PC_SAMPLING_STALL_MEMORY_THROTTLE   = 9,
  /**
   * Warp was ready to issue, but some other warp issued instead.
   */
  PTI_ACTIVITY_PC_SAMPLING_STALL_NOT_SELECTED   = 10,
  /**
   * Miscellaneous reasons
   */
  PTI_ACTIVITY_PC_SAMPLING_STALL_OTHER   = 11,
  /**
   * Sleeping.
   */
  PTI_ACTIVITY_PC_SAMPLING_STALL_SLEEPING   = 12,
  PTI_ACTIVITY_PC_SAMPLING_STALL_FORCE_INT  = 0x7fffffff
} pti_ActivityPCSamplingStallReason;

/**
 * \brief Sampling period for PC sampling method
 * Sampling period can be set using /ref cuptiActivityConfigurePCSampling
 */
typedef enum {
  /**
   * The PC sampling period is not set.
   */
  PTI_ACTIVITY_PC_SAMPLING_PERIOD_INVALID = 0,
  /**
   * Minimum sampling period available on the device.
   */
  PTI_ACTIVITY_PC_SAMPLING_PERIOD_MIN = 1,
  /**
   * Sampling period in lower range.
   */
  PTI_ACTIVITY_PC_SAMPLING_PERIOD_LOW = 2,
  /**
   * Medium sampling period.
   */
  PTI_ACTIVITY_PC_SAMPLING_PERIOD_MID = 3,
  /**
   * Sampling period in higher range.
   */
  PTI_ACTIVITY_PC_SAMPLING_PERIOD_HIGH = 4,
  /**
   * Maximum sampling period available on the device.
   */
  PTI_ACTIVITY_PC_SAMPLING_PERIOD_MAX = 5,
  PTI_ACTIVITY_PC_SAMPLING_PERIOD_FORCE_INT = 0x7fffffff
} pti_ActivityPCSamplingPeriod;

/**
 * \brief The kind of a memory copy, indicating the source and
 * destination targets of the copy.
 *
 * Each kind represents the source and destination targets of a memory
 * copy. Targets are host, device, and array.
 */

typedef enum {
  /**
   * The memory copy kind is not known.
   */
  PTI_ACTIVITY_MEMCPY_KIND_UNKNOWN = 0,
  /**
   * A host to host memory copy.
   */
  PTI_ACTIVITY_MEMCPY_KIND_HTOH    = 1,
  /**
   * A host to device memory copy.
   */
  PTI_ACTIVITY_MEMCPY_KIND_HTOD    = 2,
  /**
   * A device to host memory copy.
   */
  PTI_ACTIVITY_MEMCPY_KIND_DTOH    = 3,
  /**
   * A devoce to device memory copy.
   */
  PTI_ACTIVITY_MEMCPY_KIND_DTOD    = 4,
  /**
   * A device to shared memory memory copy.
   */
  PTI_ACTIVITY_MEMCPY_KIND_DTOS    = 5,
  /**
   * A shared memory to device memory copy.
   */
  PTI_ACTIVITY_MEMCPY_KIND_STOD    = 6,
  /**
   * A shared memory to shared memory copy.
   */
  PTI_ACTIVITY_MEMCPY_KIND_STOS    = 7,
  /**
   * A device to video memory copy.
   */
  PTI_ACTIVITY_MEMCPY_KIND_HTOM    = 8,
  /**
   * A video memory to host memory copy.
   */
  PTI_ACTIVITY_MEMCPY_KIND_MTOH    = 9,
  /**
   * A host to SRAM memory copy.
   */
  PTI_ACTIVITY_MEMCPY_KIND_HTOS    = 10,
  /**
   * A SRAM to host memory copy.
   */
  PTI_ACTIVITY_MEMCPY_KIND_STOH    = 11,

  PTI_ACTIVITY_MEMCPY_KIND_FORCE_INT = 0x7fffffff
} pti_ActivityMemcpyKind;

/**
 * \brief The kinds of memory accessed by a memory operation/copy.
 *
 * Each kind represents the type of the memory
 * accessed by a memory operation/copy.
 */
typedef enum {
  /**
   * The memory kind is unknown.
   */
  PTI_ACTIVITY_MEMORY_KIND_UNKNOWN            = 0,
  /**
   * The memory is pageable.
   */
  PTI_ACTIVITY_MEMORY_KIND_PAGEABLE           = 1,
  /**
   * The memory is pinned.
   */
  PTI_ACTIVITY_MEMORY_KIND_PINNED             = 2,
  /**
   * The memory is on the device.
   */
  PTI_ACTIVITY_MEMORY_KIND_DEVICE             = 3,
  /**
   * The memory is an array.
   */
  PTI_ACTIVITY_MEMORY_KIND_ARRAY              = 4,
  /**
   * The memory is managed
   */
  PTI_ACTIVITY_MEMORY_KIND_MANAGED            = 5,
  /**
   * The memory is device static
   */
  PTI_ACTIVITY_MEMORY_KIND_DEVICE_STATIC      = 6,
  /**
   * The memory is managed static
   */
  PTI_ACTIVITY_MEMORY_KIND_MANAGED_STATIC     = 7,
  PTI_ACTIVITY_MEMORY_KIND_FORCE_INT          = 0x7fffffff
} pti_ActivityMemoryKind;

/**
 * \brief The kind of a preemption activity.
 */
typedef enum {
  /**
   * The preemption kind is not known.
   */
  PTI_ACTIVITY_PREEMPTION_KIND_UNKNOWN    = 0,
  /**
   * Preemption to save CDP block.
   */
  PTI_ACTIVITY_PREEMPTION_KIND_SAVE       = 1,
  /**
   * Preemption to restore CDP block.
   */
  PTI_ACTIVITY_PREEMPTION_KIND_RESTORE    = 2,
  PTI_ACTIVITY_PREEMPTION_KIND_FORCE_INT  = 0x7fffffff
} pti_ActivityPreemptionKind;

/**
 * \brief The kind of environment data. Used to indicate what type of
 * data is being reported by an environment activity record.
 */
typedef enum {
  /**
   * Unknown data.
   */
  PTI_ACTIVITY_ENVIRONMENT_UNKNOWN = 0,
  /**
   * The environment data is related to speed.
   */
  PTI_ACTIVITY_ENVIRONMENT_SPEED = 1,
  /**
   * The environment data is related to temperature.
   */
  PTI_ACTIVITY_ENVIRONMENT_TEMPERATURE = 2,
  /**
   * The environment data is related to power.
   */
  PTI_ACTIVITY_ENVIRONMENT_POWER = 3,
  /**
   * The environment data is related to cooling.
   */
  PTI_ACTIVITY_ENVIRONMENT_COOLING = 4,

  PTI_ACTIVITY_ENVIRONMENT_COUNT,
  PTI_ACTIVITY_ENVIRONMENT_KIND_FORCE_INT    = 0x7fffffff
} pti_ActivityEnvironmentKind;

/**
 * \brief Reasons for clock throttling.
 *
 * The possible reasons that a clock can be throttled. There can be
 * more than one reason that a clock is being throttled so these types
 * can be combined by bitwise OR.  These are used in the
 * clocksThrottleReason field in the Environment Activity Record.
 */
typedef enum {
  /**
   * Nothing is running on the GPU and the clocks are dropping to idle
   * state.
   */
  PTI_CLOCKS_THROTTLE_REASON_GPU_IDLE              = 0x00000001,
  /**
   * The GPU clocks are limited by a user specified limit.
   */
  PTI_CLOCKS_THROTTLE_REASON_USER_DEFINED_CLOCKS   = 0x00000002,
  /**
   * A software power scaling algorithm is reducing the clocks below
   * requested clocks.
   */
  PTI_CLOCKS_THROTTLE_REASON_SW_POWER_CAP          = 0x00000004,
  /**
   * Hardware slowdown to reduce the clock by a factor of two or more
   * is engaged.  This is an indicator of one of the following: 1)
   * Temperature is too high, 2) External power brake assertion is
   * being triggered (e.g. by the system power supply), 3) Change in
   * power state.
   */
  PTI_CLOCKS_THROTTLE_REASON_HW_SLOWDOWN           = 0x00000008,

  /**
   * Throttle reason is not supported for this GPU.
   */
  PTI_CLOCKS_THROTTLE_REASON_UNSUPPORTED           = 0x40000000,
  /**
   * No clock throttling.
   */
  PTI_CLOCKS_THROTTLE_REASON_NONE                  = 0x00000000,

  PTI_CLOCKS_THROTTLE_REASON_FORCE_INT             = 0x7ffffffe,
  /**
   * Some unspecified factor is reducing the clocks.
   */
  PTI_CLOCKS_THROTTLE_REASON_UNKNOWN               = 0x7fffffff
} pti_EnvironmentClocksThrottleReason;

/**
 * \brief Scope of the unified memory counter (deprecated in RPP 7.0)
 */
typedef enum {
  /**
   * The unified memory counter scope is not known.
   */
  PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_SCOPE_UNKNOWN = 0,
  /**
   * Collect unified memory counter for single process on one device
   */
  PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_SCOPE_PROCESS_SINGLE_DEVICE = 1,
  /**
   * Collect unified memory counter for single process across all devices
   */
  PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_SCOPE_PROCESS_ALL_DEVICES = 2,

  PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_SCOPE_COUNT,
  PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_SCOPE_FORCE_INT = 0x7fffffff
} pti_ActivityUnifiedMemoryCounterScope;

/**
 * \brief Kind of the Unified Memory counter
 *
 * Many activities are associated with Unified Memory mechanism; among them
 * are tranfer from host to device, device to host, page fault at
 * host side.
 */
typedef enum {
  /**
   * The unified memory counter kind is not known.
   */
  PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_UNKNOWN = 0,
  /**
   * Number of bytes transfered from host to device
   */
  PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_BYTES_TRANSFER_HTOD = 1,
  /**
   * Number of bytes transfered from device to host
   */
  PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_BYTES_TRANSFER_DTOH = 2,
  /**
   * Number of CPU page faults, this is only supported on 64 bit
   * Linux and Mac platforms
   */
  PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_CPU_PAGE_FAULT_COUNT = 3,
  /**
   * Number of GPU page faults, this is only supported on devices with
   * compute capability 6.0 and higher and 64 bit Linux platforms
   */
  PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_GPU_PAGE_FAULT = 4,
  /**
   * Thrashing occurs when data is frequently accessed by
   * multiple processors and has to be constantly migrated around
   * to achieve data locality. In this case the overhead of migration
   * may exceed the benefits of locality.
   * This is only supported on 64 bit Linux platforms.
   */
  PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_THRASHING = 5,
  /**
   * Throttling is a prevention technique used by the driver to avoid
   * further thrashing. Here, the driver doesn't service the fault for
   * one of the contending processors for a specific period of time,
   * so that the other processor can run at full-speed.
   * This is only supported on 64 bit Linux platforms.
   */
  PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_THROTTLING = 6,
  /**
   * In case throttling does not help, the driver tries to pin the memory
   * to a processor for a specific period of time. One of the contending
   * processors will have slow  access to the memory, while the other will
   * have fast access.
   * This is only supported on 64 bit Linux platforms.
   */
  PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_REMOTE_MAP = 7,

  /**
   * Number of bytes transferred from one device to another device.
   * This is only supported on 64 bit Linux platforms.
   */
  PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_BYTES_TRANSFER_DTOD = 8,

  PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_COUNT,
  PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_FORCE_INT = 0x7fffffff
} pti_ActivityUnifiedMemoryCounterKind;

/**
 * \brief Memory access type for unified memory page faults
 *
 * This is valid for \ref PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_GPU_PAGE_FAULT
 * and \ref PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_CPU_PAGE_FAULT_COUNT
 */
typedef enum {
    /**
     * The unified memory access type is not known
     */
    PTI_ACTIVITY_UNIFIED_MEMORY_ACCESS_TYPE_UNKNOWN = 0,
    /**
     * The page fault was triggered by read memory instruction
     */
    PTI_ACTIVITY_UNIFIED_MEMORY_ACCESS_TYPE_READ = 1,
    /**
     * The page fault was triggered by write memory instruction
     */
    PTI_ACTIVITY_UNIFIED_MEMORY_ACCESS_TYPE_WRITE = 2,
    /**
     * The page fault was triggered by atomic memory instruction
     */
    PTI_ACTIVITY_UNIFIED_MEMORY_ACCESS_TYPE_ATOMIC = 3,
    /**
     * The page fault was triggered by memory prefetch operation
     */
    PTI_ACTIVITY_UNIFIED_MEMORY_ACCESS_TYPE_PREFETCH = 4
} pti_ActivityUnifiedMemoryAccessType;

/**
 * \brief Migration cause of the Unified Memory counter
 *
 * This is valid for \ref PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_BYTES_TRANSFER_HTOD and
 * \ref PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_BYTES_TRANSFER_DTOH
 */
typedef enum {
    /**
     * The unified memory migration cause is not known
     */
    PTI_ACTIVITY_UNIFIED_MEMORY_MIGRATION_CAUSE_UNKNOWN = 0,
    /**
     * The unified memory migrated due to an explicit call from
     * the user e.g. rppMemPrefetchAsync
     */
    PTI_ACTIVITY_UNIFIED_MEMORY_MIGRATION_CAUSE_USER = 1,
    /**
     * The unified memory migrated to guarantee data coherence
     * e.g. CPU/GPU faults on Pascal+ and kernel launch on pre-Pascal GPUs
     */
    PTI_ACTIVITY_UNIFIED_MEMORY_MIGRATION_CAUSE_COHERENCE = 2,
    /**
     * The unified memory was speculatively migrated by the UVM driver
     * before being accessed by the destination processor to improve
     * performance
     */
    PTI_ACTIVITY_UNIFIED_MEMORY_MIGRATION_CAUSE_PREFETCH = 3,
    /**
     * The unified memory migrated to the CPU because it was evicted to make
     * room for another block of memory on the GPU
     */
    PTI_ACTIVITY_UNIFIED_MEMORY_MIGRATION_CAUSE_EVICTION = 4,
} pti_ActivityUnifiedMemoryMigrationCause;

typedef enum {
    /**
     * The cause of mapping to remote memory was unknown
     */
    PTI_ACTIVITY_UNIFIED_MEMORY_REMOTE_MAP_CAUSE_UNKNOWN = 0,
    /**
     * Mapping to remote memory was added to maintain data coherence.
     */
    PTI_ACTIVITY_UNIFIED_MEMORY_REMOTE_MAP_CAUSE_COHERENCE = 1,
    /**
     * Mapping to remote memory was added to prevent further thrashing
     */
    PTI_ACTIVITY_UNIFIED_MEMORY_REMOTE_MAP_CAUSE_THRASHING = 2,
    /**
     * Mapping to remote memory was added to enforce the hints
     * specified by the programmer or by performance heuristics of the
     * UVM driver
     */
    PTI_ACTIVITY_UNIFIED_MEMORY_REMOTE_MAP_CAUSE_POLICY = 3,
    /**
     * Mapping to remote memory was added because there is no more
     * memory available on the processor and eviction was not
     * possible
     */
    PTI_ACTIVITY_UNIFIED_MEMORY_REMOTE_MAP_CAUSE_OUT_OF_MEMORY = 4,
} pti_ActivityUnifiedMemoryRemoteMapCause;

/**
 * \brief SASS instruction classification.
 *
 * The sass instruction are broadly divided into different class. Each enum represents a classification.
 */
typedef enum {
  /**
   * The instruction class is not known.
   */
  PTI_ACTIVITY_INSTRUCTION_CLASS_UNKNOWN = 0,
  /**
   * Represents a 32 bit floating point operation.
   */
  PTI_ACTIVITY_INSTRUCTION_CLASS_FP_32 = 1,
  /**
   * Represents a 64 bit floating point operation.
   */
  PTI_ACTIVITY_INSTRUCTION_CLASS_FP_64 = 2,
  /**
   * Represents an integer operation.
   */
  PTI_ACTIVITY_INSTRUCTION_CLASS_INTEGER = 3,
  /**
   * Represents a bit conversion operation.
   */
  PTI_ACTIVITY_INSTRUCTION_CLASS_BIT_CONVERSION = 4,
  /**
   * Represents a control flow instruction.
   */
  PTI_ACTIVITY_INSTRUCTION_CLASS_CONTROL_FLOW = 5,
  /**
   * Represents a global load-store instruction.
   */
  PTI_ACTIVITY_INSTRUCTION_CLASS_GLOBAL = 6,
  /**
   * Represents a shared load-store instruction.
   */
  PTI_ACTIVITY_INSTRUCTION_CLASS_SHARED = 7,
  /**
   * Represents a local load-store instruction.
   */
  PTI_ACTIVITY_INSTRUCTION_CLASS_LOCAL = 8,
  /**
   * Represents a generic load-store instruction.
   */
  PTI_ACTIVITY_INSTRUCTION_CLASS_GENERIC = 9,
  /**
   * Represents a surface load-store instruction.
   */
  PTI_ACTIVITY_INSTRUCTION_CLASS_SURFACE = 10,
  /**
   * Represents a constant load instruction.
   */
  PTI_ACTIVITY_INSTRUCTION_CLASS_CONSTANT = 11,
  /**
   * Represents a texture load-store instruction.
   */
  PTI_ACTIVITY_INSTRUCTION_CLASS_TEXTURE = 12,
  /**
   * Represents a global atomic instruction.
   */
  PTI_ACTIVITY_INSTRUCTION_CLASS_GLOBAL_ATOMIC = 13,
  /**
   * Represents a shared atomic instruction.
   */
  PTI_ACTIVITY_INSTRUCTION_CLASS_SHARED_ATOMIC = 14,
  /**
   * Represents a surface atomic instruction.
   */
  PTI_ACTIVITY_INSTRUCTION_CLASS_SURFACE_ATOMIC = 15,
  /**
   * Represents a inter-thread communication instruction.
   */
  PTI_ACTIVITY_INSTRUCTION_CLASS_INTER_THREAD_COMMUNICATION = 16,
  /**
   * Represents a barrier instruction.
   */
  PTI_ACTIVITY_INSTRUCTION_CLASS_BARRIER = 17,
  /**
   * Represents some miscellaneous instructions which do not fit in the above classification.
   */
  PTI_ACTIVITY_INSTRUCTION_CLASS_MISCELLANEOUS = 18,
  /**
   * Represents a 16 bit floating point operation.
   */
  PTI_ACTIVITY_INSTRUCTION_CLASS_FP_16 = 19,

  PTI_ACTIVITY_INSTRUCTION_CLASS_KIND_FORCE_INT     = 0x7fffffff
} pti_ActivityInstructionClass;

/**
 * \brief Partitioned global caching option
 */
typedef enum {
  /**
   * Partitioned global cache config unknown.
   */
  PTI_ACTIVITY_PARTITIONED_GLOBAL_CACHE_CONFIG_UNKNOWN = 0,
  /**
   * Partitioned global cache not supported.
   */
  PTI_ACTIVITY_PARTITIONED_GLOBAL_CACHE_CONFIG_NOT_SUPPORTED = 1,
  /**
   * Partitioned global cache config off.
   */
  PTI_ACTIVITY_PARTITIONED_GLOBAL_CACHE_CONFIG_OFF = 2,
  /**
   * Partitioned global cache config on.
   */
  PTI_ACTIVITY_PARTITIONED_GLOBAL_CACHE_CONFIG_ON = 3,
  PTI_ACTIVITY_PARTITIONED_GLOBAL_CACHE_CONFIG_FORCE_INT  = 0x7fffffff
} pti_ActivityPartitionedGlobalCacheConfig;

/**
 * \brief Synchronization type.
 *
 * The types of synchronization to be used with pti_ActivitySynchronization.
 */

typedef enum {
  /**
   * Unknown data.
   */
  PTI_ACTIVITY_SYNCHRONIZATION_TYPE_UNKNOWN = 0,
  /**
   * Event synchronize API.
   */
  PTI_ACTIVITY_SYNCHRONIZATION_TYPE_EVENT_SYNCHRONIZE = 1,
  /**
   * Stream wait event API.
   */
  PTI_ACTIVITY_SYNCHRONIZATION_TYPE_STREAM_WAIT_EVENT = 2,
  /**
   * Stream synchronize API.
   */
  PTI_ACTIVITY_SYNCHRONIZATION_TYPE_STREAM_SYNCHRONIZE = 3,
  /**
   * Context synchronize API.
   */
  PTI_ACTIVITY_SYNCHRONIZATION_TYPE_CONTEXT_SYNCHRONIZE = 4,

  PTI_ACTIVITY_SYNCHRONIZATION_TYPE_FORCE_INT     = 0x7fffffff
} pti_ActivitySynchronizationType;

/**
 * \brief stream type.
 *
 * The types of stream to be used with pti_ActivityStream.
 */

typedef enum {
  /**
   * Unknown data.
   */
  PTI_ACTIVITY_STREAM_CREATE_FLAG_UNKNOWN = 0,
  /**
   * Default stream.
   */
  PTI_ACTIVITY_STREAM_CREATE_FLAG_DEFAULT = 1,
  /**
   * Non-blocking stream.
   */
  PTI_ACTIVITY_STREAM_CREATE_FLAG_NON_BLOCKING = 2,
  /**
   * Null stream.
   */
  PTI_ACTIVITY_STREAM_CREATE_FLAG_NULL = 3,
  /**
   * Stream create Mask
   */
  PTI_ACTIVITY_STREAM_CREATE_MASK = 0xFFFF,

  PTI_ACTIVITY_STREAM_CREATE_FLAG_FORCE_INT = 0x7fffffff
} pti_ActivityStreamFlag;

/**
* \brief Link flags.
*
* Describes link properties, to be used with pti_ActivityNvLink.
*/

typedef enum {
  PTI_LINK_FLAG_INVALID = 0,
  /**
  * Is peer to peer access supported by this link.
  */
  PTI_LINK_FLAG_PEER_ACCESS = (1 << 1),
  /**
  * Is system memory access supported by this link.
  */
  PTI_LINK_FLAG_SYSMEM_ACCESS = (1 << 2),
  /**
  * Is peer atomic access supported by this link.
  */
  PTI_LINK_FLAG_PEER_ATOMICS = (1 << 3),
  /**
  * Is system memory atomic access supported by this link.
  */
  PTI_LINK_FLAG_SYSMEM_ATOMICS = (1 << 4),

  PTI_LINK_FLAG_FORCE_INT = 0x7fffffff
} pti_LinkFlag;

/**
 * The source-locator ID that indicates an unknown source
 * location. There is not an actual pti_ActivitySourceLocator object
 * corresponding to this value.
 */
#define PTI_SOURCE_LOCATOR_ID_UNKNOWN 0

/**
 * An invalid/unknown correlation ID. A correlation ID of this value
 * indicates that there is no correlation for the activity record.
 */
#define PTI_CORRELATION_ID_UNKNOWN 0

/**
 * An invalid/unknown grid ID.
 */
#define PTI_GRID_ID_UNKNOWN 0LL

/**
 * An invalid/unknown timestamp for a start, end, queued, submitted,
 * or completed time.
 */
#define PTI_TIMESTAMP_UNKNOWN 0LL

/**
 * An invalid/unknown value.
 */
#define PTI_SYNCHRONIZATION_INVALID_VALUE -1

/**
 * An invalid/unknown process id.
 */
#define PTI_AUTO_BOOST_INVALID_CLIENT_PID 0

/**
 * Invalid/unknown NVLink port number.
*/
#define PTI_NVLINK_INVALID_PORT -1

/**
 * Maximum NVLink port numbers.
*/
#define PTI_MAX_NVLINK_PORTS 16

START_PACKED_ALIGNMENT
/**
 * \brief Unified Memory counters configuration structure
 *
 * This structure controls the enable/disable of the various
 * Unified Memory counters consisting of scope, kind and other parameters.
 * See function /ref cuptiActivityConfigureUnifiedMemoryCounter
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * Unified Memory counter Counter scope. (deprecated in RPP 7.0)
   */
  pti_ActivityUnifiedMemoryCounterScope scope;

  /**
   * Unified Memory counter Counter kind
   */
  pti_ActivityUnifiedMemoryCounterKind kind;

  /**
   * Device id of the traget device. This is relevant only
   * for single device scopes. (deprecated in RPP 7.0)
   */
  uint32_t deviceId;

  /**
   * Control to enable/disable the counter. To enable the counter
   * set it to non-zero value while disable is indicated by zero.
   */
  uint32_t enable;
} pti_ActivityUnifiedMemoryCounterConfig;

/**
 * \brief Device auto boost state structure
 *
 * This structure defines auto boost state for a device.
 * See function /ref cuptiGetAutoBoostState
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * Returned auto boost state. 1 is returned in case auto boost is enabled, 0
   * otherwise
   */
  uint32_t enabled;

  /**
   * Id of process that has set the current boost state. The value will be
   * PTI_AUTO_BOOST_INVALID_CLIENT_PID if the user does not have the
   * permission to query process ids or there is an error in querying the
   * process id.
   */
  uint32_t pid;

} pti_ActivityAutoBoostState;

/**
 * \brief PC sampling configuration structure
 *
 * This structure defines the pc sampling configuration.
 *
 * See function /ref cuptiActivityConfigurePCSampling
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * Size of configuration structure.
   * PTI client should set the size of the structure. It will be used in PTI to check what fields are
   * available in the structure. Used to preserve backward compatibility.
   */
  uint32_t size;
  /**
   * There are 5 level provided for sampling period. The level
   * internally maps to a period in terms of cycles. Same level can
   * map to different number of cycles on different gpus. No of
   * cycles will be chosen to minimize information loss. The period
   * chosen will be given by samplingPeriodInCycles in
   * /ref pti_ActivityPCSamplingRecordInfo for each kernel instance.
   */
  pti_ActivityPCSamplingPeriod samplingPeriod;

  /**
   * This will override the period set by samplingPeriod. Value 0 in samplingPeriod2 will be
   * considered as samplingPeriod2 should not be used and samplingPeriod should be used.
   * Valid values for samplingPeriod2 are between 5 to 31 both inclusive.
   * This will set the sampling period to (2^samplingPeriod2) cycles.
   */
  uint32_t samplingPeriod2;
} pti_ActivityPCSamplingConfig;

/**
 * \brief The base activity record.
 *
 * The activity API uses a pti_Activity as a generic representation
 * for any activity. The 'kind' field is used to determine the
 * specific activity kind, and from that the pti_Activity object can
 * be cast to the specific activity record type appropriate for that kind.
 *
 * Note that all activity record types are padded and aligned to
 * ensure that each member of the record is naturally aligned.
 *
 * \see pti_ActivityKind
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The kind of this activity.
   */
  pti_ActivityKind kind;
} pti_Activity;

/**
 * \brief The activity record for memory copies.
 *
 * This activity record represents a memory copy
 * (PTI_ACTIVITY_KIND_MEMCPY).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_MEMCPY.
   */
  pti_ActivityKind kind;

  /**
   * The kind of the memory copy, stored as a byte to reduce record
   * size. \see pti_ActivityMemcpyKind
   */
  uint8_t copyKind;

  /**
   * The source memory kind read by the memory copy, stored as a byte
   * to reduce record size. \see pti_ActivityMemoryKind
   */
  uint8_t srcKind;

  /**
   * The destination memory kind read by the memory copy, stored as a
   * byte to reduce record size. \see pti_ActivityMemoryKind
   */
  uint8_t dstKind;

  /**
   * The flags associated with the memory copy. \see pti_ActivityFlag
   */
  uint8_t flags;

  /**
   * The number of bytes transferred by the memory copy.
   */
  uint64_t bytes;

  /**
   * The start cycles for the memory copy. A value of 0 for
   * both the start and end cycles indicates that cycle
   * information could not be collected for the memory copy.
   */
  uint64_t start;

  /**
   * The end cycles for the memory copy. A value of 0 for
   * both the start and end cycles indicates that cycle
   * information could not be collected for the memory copy.
   */
  uint64_t end;

  /**
   * The ID of the device where the memory copy is occurring.
   */
  uint32_t deviceId;

  /**
   * The ID of the context where the memory copy is occurring.
   */
  uint32_t contextId;

  /**
   * The ID of the stream where the memory copy is occurring.
   */
  uint32_t streamId;

  /**
   * The correlation ID of the memory copy. Each memory copy is
   * assigned a unique correlation ID that is identical to the
   * correlation ID in the driver API activity record that launched
   * the memory copy.
   */
  uint32_t correlationId;

  /**
   * The runtime correlation ID of the memory copy. Each memory copy
   * is assigned a unique runtime correlation ID that is identical to
   * the correlation ID in the runtime API activity record that
   * launched the memory copy.
   */
  uint32_t runtimeCorrelationId;

#ifdef PTILP64
  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
#endif

  /**
   * Undefined. Reserved for internal use.
   */
  void *reserved0;
} pti_ActivityMemcpy;

/**
 * \brief The activity record for peer-to-peer memory copies.
 *
 * This activity record represents a peer-to-peer memory copy
 * (PTI_ACTIVITY_KIND_MEMCPY2).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_MEMCPY2.
   */
  pti_ActivityKind kind;

  /**
   * The kind of the memory copy, stored as a byte to reduce record
   * size.  \see pti_ActivityMemcpyKind
   */
  uint8_t copyKind;

  /**
   * The source memory kind read by the memory copy, stored as a byte
   * to reduce record size.  \see pti_ActivityMemoryKind
   */
  uint8_t srcKind;

  /**
   * The destination memory kind read by the memory copy, stored as a
   * byte to reduce record size.  \see pti_ActivityMemoryKind
   */
  uint8_t dstKind;

  /**
   * The flags associated with the memory copy. \see
   * pti_ActivityFlag
   */
  uint8_t flags;

  /**
   * The number of bytes transferred by the memory copy.
   */
  uint64_t bytes;

  /**
   * The start cycles for the memory copy. A value of 0 for
   * both the start and end cycles indicates that cycle
   * information could not be collected for the memory copy.
   */
  uint64_t start;

  /**
   * The end cycles for the memory copy. A value of 0 for
   * both the start and end cycles indicates that cycle
   * information could not be collected for the memory copy.
   */
  uint64_t end;

  /**
  * The ID of the device where the memory copy is occurring.
  */
  uint32_t deviceId;

  /**
   * The ID of the context where the memory copy is occurring.
   */
  uint32_t contextId;

  /**
   * The ID of the stream where the memory copy is occurring.
   */
  uint32_t streamId;

  /**
   * The ID of the device where memory is being copied from.
   */
  uint32_t srcDeviceId;

  /**
   * The ID of the context owning the memory being copied from.
   */
  uint32_t srcContextId;

  /**
   * The ID of the device where memory is being copied to.
   */
  uint32_t dstDeviceId;

  /**
   * The ID of the context owning the memory being copied to.
   */
  uint32_t dstContextId;

  /**
   * The correlation ID of the memory copy. Each memory copy is
   * assigned a unique correlation ID that is identical to the
   * correlation ID in the driver and runtime API activity record that
   * launched the memory copy.
   */
  uint32_t correlationId;

#ifndef PTILP64
  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
#endif

  /**
   * Undefined. Reserved for internal use.
   */
  void *reserved0;
} pti_ActivityMemcpy2;

/**
 * \brief The activity record for memset.
 *
 * This activity record represents a memory set operation
 * (PTI_ACTIVITY_KIND_MEMSET).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_MEMSET.
   */
  pti_ActivityKind kind;

  /**
   * The value being assigned to memory by the memory set.
   */
  uint32_t value;

  /**
   * The number of bytes being set by the memory set.
   */
  uint64_t bytes;

  /**
   * The start cycles for the memory set. A value of 0 for
   * both the start and end cycles indicates that cycle
   * information could not be collected for the memory set.
   */
  uint64_t start;

  /**
   * The end cycles for the memory set. A value of 0 for
   * both the start and end cycles indicates that cycle
   * information could not be collected for the memory set.
   */
  uint64_t end;

  /**
   * The ID of the device where the memory set is occurring.
   */
  uint32_t deviceId;

  /**
   * The ID of the context where the memory set is occurring.
   */
  uint32_t contextId;

  /**
   * The ID of the stream where the memory set is occurring.
   */
  uint32_t streamId;

  /**
   * The correlation ID of the memory set. Each memory set is assigned
   * a unique correlation ID that is identical to the correlation ID
   * in the driver API activity record that launched the memory set.
   */
  uint32_t correlationId;

  /**
   * The flags associated with the memset. \see pti_ActivityFlag
   */
  uint16_t flags;

  /**
   * The memory kind of the memory set \see pti_ActivityMemoryKind
   */
  uint16_t memoryKind;

#ifdef PTILP64
  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
#endif

  /**
   * Undefined. Reserved for internal use.
   */
  void *reserved0;
} pti_ActivityMemset;

/**
 * \brief The activity record for memory.
 *
 * This activity record represents a memory allocation and free operation
 * (PTI_ACTIVITY_KIND_MEMORY).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_MEMORY
   */
  pti_ActivityKind kind;

  /**
   * The memory kind requested by the user
   */
  pti_ActivityMemoryKind memoryKind;

  /**
   * The virtual address of the allocation
   */
  uint64_t address;

  /**
   * The number of bytes of memory allocated.
   */
  uint64_t bytes;

  /**
   * The start timestamp for the memory operation, i.e.
   * the time when memory was allocated, in ns.
   */
  uint64_t start;

  /**
   * The end timestamp for the memory operation, i.e.
   * the time when memory was freed, in ns.
   * This will be 0 if memory is not freed in the application
   */
  uint64_t end;

  /**
   * The program counter of the allocation of memory
   */
  uint64_t allocPC;

  /**
   * The program counter of the freeing of memory. This will
   * be 0 if memory is not freed in the application
   */
  uint64_t freePC;

  /**
   * The ID of the process to which this record belongs to.
   */
  uint32_t processId;

  /**
   * The ID of the device where the memory allocation is taking place.
   */
  uint32_t deviceId;

  /**
   * The ID of the context
   */
  uint32_t contextId;

#ifdef PTILP64
  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
#endif

  /**
   * Variable name. This name is shared across all activity
   * records representing the same symbol, and so should not be
   * modified.
   */
  char name[MAX_NAME];
} pti_ActivityMemory;

/**
 * \brief The activity record for kernel. (deprecated)
 *
 * This activity record represents a kernel execution
 * (PTI_ACTIVITY_KIND_KERNEL and
 * PTI_ACTIVITY_KIND_CONCURRENT_KERNEL) but is no longer generated
 * by PTI. Kernel activities are now reported using the
 * pti_ActivityKernel4 activity record.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_KERNEL
   * or PTI_ACTIVITY_KIND_CONCURRENT_KERNEL.
   */
  pti_ActivityKind kind;

  /**
   * The cache configuration requested by the kernel. The value is one
   * of the RPPfunc_cache enumeration values from rpp.h.
   */
  uint8_t cacheConfigRequested;

  /**
   * The cache configuration used for the kernel. The value is one of
   * the RPPfunc_cache enumeration values from rpp.h.
   */
  uint8_t cacheConfigExecuted;

  /**
   * The number of registers required for each thread executing the
   * kernel.
   */
  uint16_t registersPerThread;

  /**
   * The start timestamp for the kernel execution, in ns. A value of 0
   * for both the start and end timestamps indicates that timestamp
   * information could not be collected for the kernel.
   */
  uint64_t start;

  /**
   * The end timestamp for the kernel execution, in ns. A value of 0
   * for both the start and end timestamps indicates that timestamp
   * information could not be collected for the kernel.
   */
  uint64_t end;

  /**
   * The ID of the device where the kernel is executing.
   */
  uint32_t deviceId;

  /**
   * The ID of the context where the kernel is executing.
   */
  uint32_t contextId;

  /**
   * The ID of the stream where the kernel is executing.
   */
  uint32_t streamId;

  /**
   * The X-dimension grid size for the kernel.
   */
  int32_t gridX;

  /**
   * The Y-dimension grid size for the kernel.
   */
  int32_t gridY;

  /**
   * The Z-dimension grid size for the kernel.
   */
  int32_t gridZ;

  /**
   * The X-dimension block size for the kernel.
   */
  int32_t blockX;

  /**
   * The Y-dimension block size for the kernel.
   */
  int32_t blockY;

  /**
   * The Z-dimension grid size for the kernel.
   */
  int32_t blockZ;

  /**
   * The static shared memory allocated for the kernel, in bytes.
   */
  int32_t staticSharedMemory;

  /**
   * The dynamic shared memory reserved for the kernel, in bytes.
   */
  int32_t dynamicSharedMemory;

  /**
   * The amount of local memory reserved for each thread, in bytes.
   */
  uint32_t localMemoryPerThread;

  /**
   * The total amount of local memory reserved for the kernel, in
   * bytes.
   */
  uint32_t localMemoryTotal;

  /**
   * The correlation ID of the kernel. Each kernel execution is
   * assigned a unique correlation ID that is identical to the
   * correlation ID in the driver API activity record that launched
   * the kernel.
   */
  uint32_t correlationId;

  /**
   * The runtime correlation ID of the kernel. Each kernel execution
   * is assigned a unique runtime correlation ID that is identical to
   * the correlation ID in the runtime API activity record that
   * launched the kernel.
   */
  uint32_t runtimeCorrelationId;

  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;

  /**
   * The name of the kernel. This name is shared across all activity
   * records representing the same kernel, and so should not be
   * modified.
   */
  const char *name;

  /**
   * Undefined. Reserved for internal use.
   */
  void *reserved0;
} pti_ActivityKernel;

/**
 * \brief The activity record for kernel. (deprecated)
 *
 * This activity record represents a kernel execution
 * (PTI_ACTIVITY_KIND_KERNEL and
 * PTI_ACTIVITY_KIND_CONCURRENT_KERNEL) but is no longer generated
 * by PTI. Kernel activities are now reported using the
 * pti_ActivityKernel4 activity record.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_KERNEL or
   * PTI_ACTIVITY_KIND_CONCURRENT_KERNEL.
   */
  pti_ActivityKind kind;

  union {
    uint8_t both;
    struct {
      /**
       * The cache configuration requested by the kernel. The value is one
       * of the RPPfunc_cache enumeration values from rpp.h.
       */
      uint8_t requested:4;
      /**
       * The cache configuration used for the kernel. The value is one of
       * the RPPfunc_cache enumeration values from rpp.h.
       */
      uint8_t executed:4;
    } config;
  } cacheConfig;

  /**
   * The shared memory configuration used for the kernel. The value is one of
   * the CUsharedconfig enumeration values from rpp.h.
   */
  uint8_t sharedMemoryConfig;

  /**
   * The number of registers required for each thread executing the
   * kernel.
   */
  uint16_t registersPerThread;

  /**
   * The start timestamp for the kernel execution, in ns. A value of 0
   * for both the start and end timestamps indicates that timestamp
   * information could not be collected for the kernel.
   */
  uint64_t start;

  /**
   * The end timestamp for the kernel execution, in ns. A value of 0
   * for both the start and end timestamps indicates that timestamp
   * information could not be collected for the kernel.
   */
  uint64_t end;

  /**
   * The completed timestamp for the kernel execution, in ns.  It
   * represents the completion of all it's child kernels and the
   * kernel itself. A value of PTI_TIMESTAMP_UNKNOWN indicates that
   * the completion time is unknown.
   */
  uint64_t completed;

  /**
   * The ID of the device where the kernel is executing.
   */
  uint32_t deviceId;

  /**
   * The ID of the context where the kernel is executing.
   */
  uint32_t contextId;

  /**
   * The ID of the stream where the kernel is executing.
   */
  uint32_t streamId;

  /**
   * The X-dimension grid size for the kernel.
   */
  int32_t gridX;

  /**
   * The Y-dimension grid size for the kernel.
   */
  int32_t gridY;

  /**
   * The Z-dimension grid size for the kernel.
   */
  int32_t gridZ;

  /**
   * The X-dimension block size for the kernel.
   */
  int32_t blockX;

  /**
   * The Y-dimension block size for the kernel.
   */
  int32_t blockY;

  /**
   * The Z-dimension grid size for the kernel.
   */
  int32_t blockZ;

  /**
   * The static shared memory allocated for the kernel, in bytes.
   */
  int32_t staticSharedMemory;

  /**
   * The dynamic shared memory reserved for the kernel, in bytes.
   */
  int32_t dynamicSharedMemory;

  /**
   * The amount of local memory reserved for each thread, in bytes.
   */
  uint32_t localMemoryPerThread;

  /**
   * The total amount of local memory reserved for the kernel, in
   * bytes.
   */
  uint32_t localMemoryTotal;

  /**
   * The correlation ID of the kernel. Each kernel execution is
   * assigned a unique correlation ID that is identical to the
   * correlation ID in the driver or runtime API activity record that
   * launched the kernel.
   */
  uint32_t correlationId;

  /**
   * The grid ID of the kernel. Each kernel is assigned a unique
   * grid ID at runtime.
   */
  int64_t gridId;

  /**
   * The name of the kernel. This name is shared across all activity
   * records representing the same kernel, and so should not be
   * modified.
   */
  const char *name;

  /**
   * Undefined. Reserved for internal use.
   */
  void *reserved0;
} pti_ActivityKernel2;

/**
 * \brief The activity record for a kernel (RPP 6.5(with sm_52 support) onwards).
 * (deprecated in RPP 9.0)
 *
 * This activity record represents a kernel execution
 * (PTI_ACTIVITY_KIND_KERNEL and
 * PTI_ACTIVITY_KIND_CONCURRENT_KERNEL).
 * Kernel activities are now reported using the pti_ActivityKernel4 activity
 * record.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_KERNEL or
   * PTI_ACTIVITY_KIND_CONCURRENT_KERNEL.
   */
  pti_ActivityKind kind;

  union {
    uint8_t both;
    struct {
      /**
       * The cache configuration requested by the kernel. The value is one
       * of the RPPfunc_cache enumeration values from rpp.h.
       */
      uint8_t requested:4;
      /**
       * The cache configuration used for the kernel. The value is one of
       * the RPPfunc_cache enumeration values from rpp.h.
       */
      uint8_t executed:4;
    } config;
  } cacheConfig;

  /**
   * The shared memory configuration used for the kernel. The value is one of
   * the CUsharedconfig enumeration values from rpp.h.
   */
  uint8_t sharedMemoryConfig;

  /**
   * The number of registers required for each thread executing the
   * kernel.
   */
  uint16_t registersPerThread;

  /**
   * The partitioned global caching requested for the kernel. Partitioned
   * global caching is required to enable caching on certain chips, such as
   * devices with compute capability 5.2.
   */
  pti_ActivityPartitionedGlobalCacheConfig partitionedGlobalCacheRequested;

  /**
   * The partitioned global caching executed for the kernel. Partitioned
   * global caching is required to enable caching on certain chips, such as
   * devices with compute capability 5.2. Partitioned global caching can be
   * automatically disabled if the occupancy requirement of the launch cannot
   * support caching.
   */
  pti_ActivityPartitionedGlobalCacheConfig partitionedGlobalCacheExecuted;

  /**
   * The start timestamp for the kernel execution, in ns. A value of 0
   * for both the start and end timestamps indicates that timestamp
   * information could not be collected for the kernel.
   */
  uint64_t start;

  /**
   * The end timestamp for the kernel execution, in ns. A value of 0
   * for both the start and end timestamps indicates that timestamp
   * information could not be collected for the kernel.
   */
  uint64_t end;

  /**
   * The completed timestamp for the kernel execution, in ns.  It
   * represents the completion of all it's child kernels and the
   * kernel itself. A value of PTI_TIMESTAMP_UNKNOWN indicates that
   * the completion time is unknown.
   */
  uint64_t completed;

  /**
   * The ID of the device where the kernel is executing.
   */
  uint32_t deviceId;

  /**
   * The ID of the context where the kernel is executing.
   */
  uint32_t contextId;

  /**
   * The ID of the stream where the kernel is executing.
   */
  uint32_t streamId;

  /**
   * The X-dimension grid size for the kernel.
   */
  int32_t gridX;

  /**
   * The Y-dimension grid size for the kernel.
   */
  int32_t gridY;

  /**
   * The Z-dimension grid size for the kernel.
   */
  int32_t gridZ;

  /**
   * The X-dimension block size for the kernel.
   */
  int32_t blockX;

  /**
   * The Y-dimension block size for the kernel.
   */
  int32_t blockY;

  /**
   * The Z-dimension grid size for the kernel.
   */
  int32_t blockZ;

  /**
   * The static shared memory allocated for the kernel, in bytes.
   */
  int32_t staticSharedMemory;

  /**
   * The dynamic shared memory reserved for the kernel, in bytes.
   */
  int32_t dynamicSharedMemory;

  /**
   * The amount of local memory reserved for each thread, in bytes.
   */
  uint32_t localMemoryPerThread;

  /**
   * The total amount of local memory reserved for the kernel, in
   * bytes.
   */
  uint32_t localMemoryTotal;

  /**
   * The correlation ID of the kernel. Each kernel execution is
   * assigned a unique correlation ID that is identical to the
   * correlation ID in the driver or runtime API activity record that
   * launched the kernel.
   */
  uint32_t correlationId;

  /**
   * The grid ID of the kernel. Each kernel is assigned a unique
   * grid ID at runtime.
   */
  int64_t gridId;

  /**
   * The name of the kernel. This name is shared across all activity
   * records representing the same kernel, and so should not be
   * modified.
   */
  const char *name;

  /**
   * Undefined. Reserved for internal use.
   */
  void *reserved0;
} pti_ActivityKernel3;

/**
 * \brief The type of the RPP kernel launch.
 */
typedef enum {
  /**
  * The kernel was launched via a regular kernel call
  */
  PTI_ACTIVITY_LAUNCH_TYPE_REGULAR = 0,
  /**
  * The kernel was launched via API \ref rppLaunchCooperativeKernel() or
  * \ref cuLaunchCooperativeKernel()
  */
  PTI_ACTIVITY_LAUNCH_TYPE_COOPERATIVE_SINGLE_DEVICE = 1,
  /**
  * The kernel was launched via API \ref rppLaunchCooperativeKernelMultiDevice() or
  * \ref cuLaunchCooperativeKernelMultiDevice()
  */
  PTI_ACTIVITY_LAUNCH_TYPE_COOPERATIVE_MULTI_DEVICE = 2
} pti_ActivityLaunchType;

/**
 * \brief The activity record for a kernel.
 *
 * This activity record represents a kernel execution
 * (PTI_ACTIVITY_KIND_KERNEL and
 * PTI_ACTIVITY_KIND_CONCURRENT_KERNEL).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_KERNEL or
   * PTI_ACTIVITY_KIND_CONCURRENT_KERNEL.
   */
  pti_ActivityKind kind;

  /**
   * For devices with compute capability 7.0+ cacheConfig values are not updated
   * in case field isSharedMemoryCarveoutRequested is set
   */
  union {
    uint8_t both;
    struct {
      /**
       * The cache configuration requested by the kernel. The value is one
       * of the RPPfunc_cache enumeration values from rpp.h.
       */
      uint8_t requested:4;
      /**
       * The cache configuration used for the kernel. The value is one of
       * the RPPfunc_cache enumeration values from rpp.h.
       */
      uint8_t executed:4;
    } config;
  } cacheConfig;

  /**
   * The shared memory configuration used for the kernel. The value is one of
   * the CUsharedconfig enumeration values from rpp.h.
   */
  uint8_t sharedMemoryConfig;

  /**
   * The number of registers required for each thread executing the
   * kernel.
   */
  uint16_t registersPerThread;

  /**
   * The partitioned global caching requested for the kernel. Partitioned
   * global caching is required to enable caching on certain chips, such as
   * devices with compute capability 5.2.
   */
  pti_ActivityPartitionedGlobalCacheConfig partitionedGlobalCacheRequested;

  /**
   * The partitioned global caching executed for the kernel. Partitioned
   * global caching is required to enable caching on certain chips, such as
   * devices with compute capability 5.2. Partitioned global caching can be
   * automatically disabled if the occupancy requirement of the launch cannot
   * support caching.
   */
  pti_ActivityPartitionedGlobalCacheConfig partitionedGlobalCacheExecuted;

  /**
   * The start cycles for the kernel execution. A value of 0
   * for both the start and end cycles indicates that cycle
   * information could not be collected for the kernel.
   */
  uint64_t start;

  /**
   * The end cycles for the kernel execution. A value of 0
   * for both the start and end cycles indicates that cycle
   * information could not be collected for the kernel.
   */
  uint64_t end;

  /**
   * The completed timestamp for the kernel execution, in ns.  It
   * represents the completion of all it's child kernels and the
   * kernel itself. A value of PTI_TIMESTAMP_UNKNOWN indicates that
   * the completion time is unknown.
   */
  uint64_t completed;

  /**
   * The ID of the device where the kernel is executing.
   */
  uint32_t deviceId;

  /**
   * The ID of the context where the kernel is executing.
   */
  uint32_t contextId;

  /**
   * The ID of the stream where the kernel is executing.
   */
  uint32_t streamId;

  /**
   * The X-dimension grid size for the kernel.
   */
  int32_t gridX;

  /**
   * The Y-dimension grid size for the kernel.
   */
  int32_t gridY;

  /**
   * The Z-dimension grid size for the kernel.
   */
  int32_t gridZ;

  /**
   * The X-dimension block size for the kernel.
   */
  int32_t blockX;

  /**
   * The Y-dimension block size for the kernel.
   */
  int32_t blockY;

  /**
   * The Z-dimension grid size for the kernel.
   */
  int32_t blockZ;

  /**
   * The static shared memory allocated for the kernel, in bytes.
   */
  int32_t staticSharedMemory;

  /**
   * The dynamic shared memory reserved for the kernel, in bytes.
   */
  int32_t dynamicSharedMemory;

  /**
   * The amount of local memory reserved for each thread, in bytes.
   */
  uint32_t localMemoryPerThread;

  /**
   * The total amount of local memory reserved for the kernel, in
   * bytes.
   */
  uint32_t localMemoryTotal;

  /**
   * The correlation ID of the kernel. Each kernel execution is
   * assigned a unique correlation ID that is identical to the
   * correlation ID in the driver or runtime API activity record that
   * launched the kernel.
   */
  uint32_t correlationId;

  /**
   * The grid ID of the kernel. Each kernel is assigned a unique
   * grid ID at runtime.
   */
  int64_t gridId;

  /**
   * The name of the kernel. This name is shared across all activity
   * records representing the same kernel, and so should not be
   * modified.
   */
  char name[MAX_FUNC_NAME];

  /**
   * Undefined. Reserved for internal use.
   */
  void *reserved0;

  /**
   * The timestamp when the kernel is queued up in the command buffer, in ns.
   * A value of PTI_TIMESTAMP_UNKNOWN indicates that the queued time
   * could not be collected for the kernel. This timestamp is not collected
   * by default. Use API \ref cuptiActivityEnableLatencyTimestamps() to
   * enable collection.
   *
   * Command buffer is a buffer written by RPP driver to send commands
   * like kernel launch, memory copy etc to the GPU. All launches of RPP
   * kernels are asynchrnous with respect to the host, the host requests
   * the launch by writing commands into the command buffer, then returns
   * without checking the GPU's progress.
   */
  uint64_t queued;

  /**
   * The timestamp when the command buffer containing the kernel launch
   * is submitted to the GPU, in ns. A value of PTI_TIMESTAMP_UNKNOWN
   * indicates that the submitted time could not be collected for the kernel.
   * This timestamp is not collected by default. Use API \ref
   * cuptiActivityEnableLatencyTimestamps() to enable collection.
   */
  uint64_t submitted;

  /**
   * The indicates if the kernel was executed via a regular launch or via a
   * single/multi device cooperative launch. \see pti_ActivityLaunchType
   */
  uint8_t launchType;

  /**
   * This indicates if CU_FUNC_ATTRIBUTE_PREFERRED_SHARED_MEMORY_CARVEOUT was
   * updated for the kernel launch
   */
  uint8_t isSharedMemoryCarveoutRequested;

  /**
   * Shared memory carveout value requested for the function in percentage of
   * the total resource. The value will be updated only if field
   * isSharedMemoryCarveoutRequested is set.
   */
  uint8_t sharedMemoryCarveoutRequested;

  /**
   * Undefined. Reserved for internal use.
   */
  uint8_t padding[5];
} pti_ActivityKernel4;

/**
 * \brief The activity record for CDP (RPP Dynamic Parallelism)
 * kernel.
 *
 * This activity record represents a CDP kernel execution.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_CDP_KERNEL
   */
  pti_ActivityKind kind;

  union {
    uint8_t both;
    struct {
      /**
       * The cache configuration requested by the kernel. The value is one
       * of the RPPfunc_cache enumeration values from rpp.h.
       */
      uint8_t requested:4;
      /**
       * The cache configuration used for the kernel. The value is one of
       * the RPPfunc_cache enumeration values from rpp.h.
       */
      uint8_t executed:4;
    } config;
  } cacheConfig;

  /**
   * The shared memory configuration used for the kernel. The value is one of
   * the CUsharedconfig enumeration values from rpp.h.
   */
  uint8_t sharedMemoryConfig;

  /**
   * The number of registers required for each thread executing the
   * kernel.
   */
  uint16_t registersPerThread;

  /**
   * The start timestamp for the kernel execution, in ns. A value of 0
   * for both the start and end timestamps indicates that timestamp
   * information could not be collected for the kernel.
   */
  uint64_t start;

  /**
   * The end timestamp for the kernel execution, in ns. A value of 0
   * for both the start and end timestamps indicates that timestamp
   * information could not be collected for the kernel.
   */
  uint64_t end;

  /**
   * The ID of the device where the kernel is executing.
   */
  uint32_t deviceId;

  /**
   * The ID of the context where the kernel is executing.
   */
  uint32_t contextId;

  /**
   * The ID of the stream where the kernel is executing.
   */
  uint32_t streamId;

  /**
   * The X-dimension grid size for the kernel.
   */
  int32_t gridX;

  /**
   * The Y-dimension grid size for the kernel.
   */
  int32_t gridY;

  /**
   * The Z-dimension grid size for the kernel.
   */
  int32_t gridZ;

  /**
   * The X-dimension block size for the kernel.
   */
  int32_t blockX;

  /**
   * The Y-dimension block size for the kernel.
   */
  int32_t blockY;

  /**
   * The Z-dimension grid size for the kernel.
   */
  int32_t blockZ;

  /**
   * The static shared memory allocated for the kernel, in bytes.
   */
  int32_t staticSharedMemory;

  /**
   * The dynamic shared memory reserved for the kernel, in bytes.
   */
  int32_t dynamicSharedMemory;

  /**
   * The amount of local memory reserved for each thread, in bytes.
   */
  uint32_t localMemoryPerThread;

  /**
   * The total amount of local memory reserved for the kernel, in
   * bytes.
   */
  uint32_t localMemoryTotal;

  /**
   * The correlation ID of the kernel. Each kernel execution is
   * assigned a unique correlation ID that is identical to the
   * correlation ID in the driver API activity record that launched
   * the kernel.
   */
  uint32_t correlationId;

  /**
   * The grid ID of the kernel. Each kernel execution
   * is assigned a unique grid ID.
   */
  int64_t gridId;

  /**
   * The grid ID of the parent kernel.
   */
  int64_t parentGridId;

  /**
   * The timestamp when kernel is queued up, in ns. A value of
   * PTI_TIMESTAMP_UNKNOWN indicates that the queued time is
   * unknown.
   */
  uint64_t queued;

  /**
   * The timestamp when kernel is submitted to the gpu, in ns. A value
   * of PTI_TIMESTAMP_UNKNOWN indicates that the submission time is
   * unknown.
   */
  uint64_t submitted;

  /**
   * The timestamp when kernel is marked as completed, in ns. A value
   * of PTI_TIMESTAMP_UNKNOWN indicates that the completion time is
   * unknown.
   */
  uint64_t completed;

  /**
   * The X-dimension of the parent block.
   */
  uint32_t parentBlockX;

  /**
   * The Y-dimension of the parent block.
   */
  uint32_t parentBlockY;

  /**
   * The Z-dimension of the parent block.
   */
  uint32_t parentBlockZ;

#ifdef PTILP64
  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
#endif

  /**
   * The name of the kernel. This name is shared across all activity
   * records representing the same kernel, and so should not be
   * modified.
   */
  const char *name;
} pti_ActivityCdpKernel;

/**
 * \brief The activity record for a preemption of a CDP kernel.
 *
 * This activity record represents a preemption of a CDP kernel.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_PREEMPTION
   */
  pti_ActivityKind kind;

  /**
  * kind of the preemption
  */
  pti_ActivityPreemptionKind preemptionKind;

  /**
   * The timestamp of the preemption, in ns. A value of 0 indicates
   * that timestamp information could not be collected for the
   * preemption.
   */
  uint64_t timestamp;

  /**
  * The grid-id of the block that is preempted
  */
  int64_t gridId;

  /**
   * The X-dimension of the block that is preempted
   */
  uint32_t blockX;

  /**
   * The Y-dimension of the block that is preempted
   */
  uint32_t blockY;

  /**
   * The Z-dimension of the block that is preempted
   */
  uint32_t blockZ;

  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
} pti_ActivityPreemption;

/**
 * \brief The activity record for a driver or runtime API invocation.
 *
 * This activity record represents an invocation of a driver or
 * runtime API (PTI_ACTIVITY_KIND_DRIVER and
 * PTI_ACTIVITY_KIND_RUNTIME).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_DRIVER or
   * PTI_ACTIVITY_KIND_RUNTIME.
   */
  pti_ActivityKind kind;

  /**
   * The ID of the driver or runtime function.
   */
  pti_CallbackId cbid;

  /**
   * The start timestamp for the function, in ns. A value of 0 for
   * both the start and end timestamps indicates that timestamp
   * information could not be collected for the function.
   */
  uint64_t start;

  /**
   * The end timestamp for the function, in ns. A value of 0 for both
   * the start and end timestamps indicates that timestamp information
   * could not be collected for the function.
   */
  uint64_t end;

  /**
   * The ID of the process where the driver or runtime RPP function
   * is executing.
   */
  uint32_t processId;

  /**
   * The ID of the thread where the driver or runtime RPP function is
   * executing.
   */
  uint32_t threadId;

  /**
   * The correlation ID of the driver or runtime RPP function. Each
   * function invocation is assigned a unique correlation ID that is
   * identical to the correlation ID in the memcpy, memset, or kernel
   * activity record that is associated with this function.
   */
  uint32_t correlationId;

  /**
   * The return value for the function. For a RPP driver function
   * with will be a CUresult value, and for a RPP runtime function
   * this will be a rppError_t value.
   */
  uint32_t returnValue;
} pti_ActivityAPI;

/**
 * \brief The activity record for a PTI event.
 *
 * This activity record represents a PTI event value
 * (PTI_ACTIVITY_KIND_EVENT). This activity record kind is not
 * produced by the activity API but is included for completeness and
 * ease-of-use. Profile frameworks built on top of PTI that collect
 * event data may choose to use this type to store the collected event
 * data.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_EVENT.
   */
  pti_ActivityKind kind;

  /**
   * The event ID.
   */
  pti_EventID id;

  /**
   * The event value.
   */
  uint64_t value;

  /**
   * The event domain ID.
   */
  pti_EventDomainID domain;

  /**
   * The correlation ID of the event. Use of this ID is user-defined,
   * but typically this ID value will equal the correlation ID of the
   * kernel for which the event was gathered.
   */
  uint32_t correlationId;
} pti_ActivityEvent;

/**
 * \brief The activity record for a PTI event with instance
 * information.
 *
 * This activity record represents the a PTI event value for a
 * specific event domain instance
 * (PTI_ACTIVITY_KIND_EVENT_INSTANCE). This activity record kind is
 * not produced by the activity API but is included for completeness
 * and ease-of-use. Profile frameworks built on top of PTI that
 * collect event data may choose to use this type to store the
 * collected event data. This activity record should be used when
 * event domain instance information needs to be associated with the
 * event.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be
   * PTI_ACTIVITY_KIND_EVENT_INSTANCE.
   */
  pti_ActivityKind kind;

  /**
   * The event ID.
   */
  pti_EventID id;

  /**
   * The event domain ID.
   */
  pti_EventDomainID domain;

  /**
   * The event domain instance.
   */
  uint32_t instance;

  /**
   * The event value.
   */
  uint64_t value;

  /**
   * The correlation ID of the event. Use of this ID is user-defined,
   * but typically this ID value will equal the correlation ID of the
   * kernel for which the event was gathered.
   */
  uint32_t correlationId;

  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
} pti_ActivityEventInstance;

/**
 * \brief The activity record for a PTI metric.
 *
 * This activity record represents the collection of a PTI metric
 * value (PTI_ACTIVITY_KIND_METRIC). This activity record kind is not
 * produced by the activity API but is included for completeness and
 * ease-of-use. Profile frameworks built on top of PTI that collect
 * metric data may choose to use this type to store the collected metric
 * data.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_METRIC.
   */
  pti_ActivityKind kind;

  /**
   * The metric ID.
   */
  pti_MetricID id;

  /**
   * The metric value.
   */
  pti_MetricValue value;

  /**
   * The correlation ID of the metric. Use of this ID is user-defined,
   * but typically this ID value will equal the correlation ID of the
   * kernel for which the metric was gathered.
   */
  uint32_t correlationId;

  /**
   * The properties of this metric. \see pti_ActivityFlag
   */
  uint8_t flags;

  /**
   * Undefined. Reserved for internal use.
   */
  uint8_t pad[3];
} pti_ActivityMetric;

/**
 * \brief The activity record for a PTI metric with instance
 * information.
 *
 * This activity record represents a PTI metric value
 * for a specific metric domain instance
 * (PTI_ACTIVITY_KIND_METRIC_INSTANCE).  This activity record kind
 * is not produced by the activity API but is included for
 * completeness and ease-of-use. Profile frameworks built on top of
 * PTI that collect metric data may choose to use this type to store
 * the collected metric data. This activity record should be used when
 * metric domain instance information needs to be associated with the
 * metric.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be
   * PTI_ACTIVITY_KIND_METRIC_INSTANCE.
   */
  pti_ActivityKind kind;

  /**
   * The metric ID.
   */
  pti_MetricID id;

  /**
   * The metric value.
   */
  pti_MetricValue value;

  /**
   * The metric domain instance.
   */
  uint32_t instance;

  /**
   * The correlation ID of the metric. Use of this ID is user-defined,
   * but typically this ID value will equal the correlation ID of the
   * kernel for which the metric was gathered.
   */
  uint32_t correlationId;

  /**
   * The properties of this metric. \see pti_ActivityFlag
   */
  uint8_t flags;

  /**
   * Undefined. Reserved for internal use.
   */
  uint8_t pad[7];
} pti_ActivityMetricInstance;

/**
 * \brief The activity record for source locator.
 *
 * This activity record represents a source locator
 * (PTI_ACTIVITY_KIND_SOURCE_LOCATOR).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_SOURCE_LOCATOR.
   */
  pti_ActivityKind kind;

  /**
   * The ID for the source path, will be used in all the source level
   * results.
   */
  uint32_t id;

  /**
   * The line number in the source .
   */
  uint32_t lineNumber;

#ifdef PTILP64
  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
#endif

  /**
   * The path for the file.
   */
  const char *fileName;
} pti_ActivitySourceLocator;

/**
 * \brief The activity record for source-level global
 * access. (deprecated)
 *
 * This activity records the locations of the global
 * accesses in the source (PTI_ACTIVITY_KIND_GLOBAL_ACCESS).
 * Global access activities are now reported using the
 * pti_ActivityGlobalAccess3 activity record.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_GLOBAL_ACCESS.
   */
  pti_ActivityKind kind;

  /**
   * The properties of this global access.
   */
  pti_ActivityFlag flags;

  /**
   * The ID for source locator.
   */
  uint32_t sourceLocatorId;

  /**
   * The correlation ID of the kernel to which this result is associated.
   */
  uint32_t correlationId;

  /**
   * The pc offset for the access.
   */
  uint32_t pcOffset;

  /**
   * The number of times this instruction was executed per warp. It will be incremented
   * when at least one of thread among warp is active with predicate and condition code
   * evaluating to true.
   */
  uint32_t executed;

  /**
   * This increments each time when this instruction is executed by number
   * of threads that executed this instruction with predicate and condition code evaluating to true.
   */
  uint64_t threadsExecuted;

  /**
   * The total number of 32 bytes transactions to L2 cache generated by this access
   */
  uint64_t l2_transactions;
} pti_ActivityGlobalAccess;

/**
 * \brief The activity record for source-level global
 * access. (deprecated in RPP 9.0)
 *
 * This activity records the locations of the global
 * accesses in the source (PTI_ACTIVITY_KIND_GLOBAL_ACCESS).
 * Global access activities are now reported using the
 * pti_ActivityGlobalAccess3 activity record.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_GLOBAL_ACCESS.
   */
  pti_ActivityKind kind;

  /**
   * The properties of this global access.
   */
  pti_ActivityFlag flags;

  /**
   * The ID for source locator.
   */
  uint32_t sourceLocatorId;

  /**
   * The correlation ID of the kernel to which this result is associated.
   */
  uint32_t correlationId;

 /**
  * Correlation ID with global/device function name
  */
  uint32_t functionId;

  /**
   * The pc offset for the access.
   */
  uint32_t pcOffset;

  /**
   * This increments each time when this instruction is executed by number
   * of threads that executed this instruction with predicate and condition code evaluating to true.
   */
  uint64_t threadsExecuted;

  /**
   * The total number of 32 bytes transactions to L2 cache generated by this access
   */
  uint64_t l2_transactions;

  /**
   * The minimum number of L2 transactions possible based on the access pattern.
   */
  uint64_t theoreticalL2Transactions;

  /**
   * The number of times this instruction was executed per warp. It will be incremented
   * when at least one of thread among warp is active with predicate and condition code
   * evaluating to true.
   */
  uint32_t executed;

  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
} pti_ActivityGlobalAccess2;

/**
 * \brief The activity record for source-level global
 * access.
 *
 * This activity records the locations of the global
 * accesses in the source (PTI_ACTIVITY_KIND_GLOBAL_ACCESS).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_GLOBAL_ACCESS.
   */
  pti_ActivityKind kind;

  /**
   * The properties of this global access.
   */
  pti_ActivityFlag flags;

  /**
   * The ID for source locator.
   */
  uint32_t sourceLocatorId;

  /**
   * The correlation ID of the kernel to which this result is associated.
   */
  uint32_t correlationId;

 /**
  * Correlation ID with global/device function name
  */
  uint32_t functionId;

  /**
   * The number of times this instruction was executed per warp. It will be incremented
   * when at least one of thread among warp is active with predicate and condition code
   * evaluating to true.
   */
  uint32_t executed;

  /**
   * The pc offset for the access.
   */
  uint64_t pcOffset;

  /**
   * This increments each time when this instruction is executed by number of
   * threads that executed this instruction with predicate and condition code
   * evaluating to true.
   */
  uint64_t threadsExecuted;

  /**
   * The total number of 32 bytes transactions to L2 cache generated by this
     access
   */
  uint64_t l2_transactions;

  /**
   * The minimum number of L2 transactions possible based on the access pattern.
   */
  uint64_t theoreticalL2Transactions;
} pti_ActivityGlobalAccess3;

/**
 * \brief The activity record for source level result
 * branch. (deprecated)
 *
 * This activity record the locations of the branches in the
 * source (PTI_ACTIVITY_KIND_BRANCH).
 * Branch activities are now reported using the
 * pti_ActivityBranch2 activity record.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_BRANCH.
   */
  pti_ActivityKind kind;

  /**
   * The ID for source locator.
   */
  uint32_t sourceLocatorId;

  /**
   * The correlation ID of the kernel to which this result is associated.
   */
  uint32_t correlationId;

  /**
   * The pc offset for the branch.
   */
  uint32_t pcOffset;

  /**
   * The number of times this instruction was executed per warp. It will be incremented
   * regardless of predicate or condition code.
   */
  uint32_t executed;

  /**
   * Number of times this branch diverged
   */
  uint32_t diverged;

  /**
   * This increments each time when this instruction is executed by number
   * of threads that executed this instruction
   */
  uint64_t threadsExecuted;
} pti_ActivityBranch;

/**
 * \brief The activity record for source level result
 * branch.
 *
 * This activity record the locations of the branches in the
 * source (PTI_ACTIVITY_KIND_BRANCH).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_BRANCH.
   */
  pti_ActivityKind kind;

  /**
   * The ID for source locator.
   */
  uint32_t sourceLocatorId;

  /**
   * The correlation ID of the kernel to which this result is associated.
   */
  uint32_t correlationId;

 /**
  * Correlation ID with global/device function name
  */
  uint32_t functionId;

  /**
   * The pc offset for the branch.
   */
  uint32_t pcOffset;

  /**
   * Number of times this branch diverged
   */
  uint32_t diverged;

  /**
   * This increments each time when this instruction is executed by number
   * of threads that executed this instruction
   */
  uint64_t threadsExecuted;

  /**
   * The number of times this instruction was executed per warp. It will be incremented
   * regardless of predicate or condition code.
   */
  uint32_t executed;

  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
} pti_ActivityBranch2;


/**
 * \brief The activity record for a device. (deprecated)
 *
 * This activity record represents information about a GPU device
 * (PTI_ACTIVITY_KIND_DEVICE).
 * Device activity is now reported using the
 * pti_ActivityDevice2 activity record.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_DEVICE.
   */
  pti_ActivityKind kind;

  /**
   * The flags associated with the device. \see pti_ActivityFlag
   */
  pti_ActivityFlag flags;

  /**
   * The global memory bandwidth available on the device, in
   * kBytes/sec.
   */
  uint64_t globalMemoryBandwidth;

  /**
   * The amount of global memory on the device, in bytes.
   */
  uint64_t globalMemorySize;

  /**
   * The amount of constant memory on the device, in bytes.
   */
  uint32_t constantMemorySize;

  /**
   * The size of the L2 cache on the device, in bytes.
   */
  uint32_t l2CacheSize;

  /**
   * The number of threads per warp on the device.
   */
  uint32_t numThreadsPerWarp;

  /**
   * The core clock rate of the device, in kHz.
   */
  uint32_t coreClockRate;

  /**
   * Number of memory copy engines on the device.
   */
  uint32_t numMemcpyEngines;

  /**
   * Number of multiprocessors on the device.
   */
  uint32_t numMultiprocessors;

  /**
   * The maximum "instructions per cycle" possible on each device
   * multiprocessor.
   */
  uint32_t maxIPC;

  /**
   * Maximum number of warps that can be present on a multiprocessor
   * at any given time.
   */
  uint32_t maxWarpsPerMultiprocessor;

  /**
   * Maximum number of blocks that can be present on a multiprocessor
   * at any given time.
   */
  uint32_t maxBlocksPerMultiprocessor;

  /**
   * Maximum number of registers that can be allocated to a block.
   */
  uint32_t maxRegistersPerBlock;

  /**
   * Maximum amount of shared memory that can be assigned to a block,
   * in bytes.
   */
  uint32_t maxSharedMemoryPerBlock;

  /**
   * Maximum number of threads allowed in a block.
   */
  uint32_t maxThreadsPerBlock;

  /**
   * Maximum allowed X dimension for a block.
   */
  uint32_t maxBlockDimX;

  /**
   * Maximum allowed Y dimension for a block.
   */
  uint32_t maxBlockDimY;

  /**
   * Maximum allowed Z dimension for a block.
   */
  uint32_t maxBlockDimZ;

  /**
   * Maximum allowed X dimension for a grid.
   */
  uint32_t maxGridDimX;

  /**
   * Maximum allowed Y dimension for a grid.
   */
  uint32_t maxGridDimY;

  /**
   * Maximum allowed Z dimension for a grid.
   */
  uint32_t maxGridDimZ;

  /**
   * Compute capability for the device, major number.
   */
  uint32_t computeCapabilityMajor;

  /**
   * Compute capability for the device, minor number.
   */
  uint32_t computeCapabilityMinor;

  /**
   * The device ID.
   */
  uint32_t id;

#ifdef PTILP64
  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
#endif

  /**
   * The device name. This name is shared across all activity records
   * representing instances of the device, and so should not be
   * modified.
   */
  const char *name;
} pti_ActivityDevice;

/**
 * \brief The activity record for a device. (RPP 7.0 onwards)
 *
 * This activity record represents information about a GPU device
 * (PTI_ACTIVITY_KIND_DEVICE).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_DEVICE.
   */
  pti_ActivityKind kind;

  /**
   * The flags associated with the device. \see pti_ActivityFlag
   */
  pti_ActivityFlag flags;

  /**
   * The global memory bandwidth available on the device, in
   * kBytes/sec.
   */
  uint64_t globalMemoryBandwidth;

  /**
   * The amount of global memory on the device, in bytes.
   */
  uint64_t globalMemorySize;

  /**
   * The amount of constant memory on the device, in bytes.
   */
  uint32_t constantMemorySize;

  /**
   * The size of the L2 cache on the device, in bytes.
   */
  uint32_t l2CacheSize;

  /**
   * The number of threads per warp on the device.
   */
  uint32_t numThreadsPerWarp;

  /**
   * The core clock rate of the device, in kHz.
   */
  uint32_t coreClockRate;

  /**
   * Number of memory copy engines on the device.
   */
  uint32_t numMemcpyEngines;

  /**
   * Number of multiprocessors on the device.
   */
  uint32_t numMultiprocessors;

  /**
   * The maximum "instructions per cycle" possible on each device
   * multiprocessor.
   */
  uint32_t maxIPC;

  /**
   * Maximum number of warps that can be present on a multiprocessor
   * at any given time.
   */
  uint32_t maxWarpsPerMultiprocessor;

  /**
   * Maximum number of blocks that can be present on a multiprocessor
   * at any given time.
   */
  uint32_t maxBlocksPerMultiprocessor;

  /**
   * Maximum amount of shared memory available per multiprocessor, in bytes.
   */
  uint32_t maxSharedMemoryPerMultiprocessor;

  /**
   * Maximum number of 32-bit registers available per multiprocessor.
   */
  uint32_t maxRegistersPerMultiprocessor;

  /**
   * Maximum number of registers that can be allocated to a block.
   */
  uint32_t maxRegistersPerBlock;

  /**
   * Maximum amount of shared memory that can be assigned to a block,
   * in bytes.
   */
  uint32_t maxSharedMemoryPerBlock;

  /**
   * Maximum number of threads allowed in a block.
   */
  uint32_t maxThreadsPerBlock;

  /**
   * Maximum allowed X dimension for a block.
   */
  uint32_t maxBlockDimX;

  /**
   * Maximum allowed Y dimension for a block.
   */
  uint32_t maxBlockDimY;

  /**
   * Maximum allowed Z dimension for a block.
   */
  uint32_t maxBlockDimZ;

  /**
   * Maximum allowed X dimension for a grid.
   */
  uint32_t maxGridDimX;

  /**
   * Maximum allowed Y dimension for a grid.
   */
  uint32_t maxGridDimY;

  /**
   * Maximum allowed Z dimension for a grid.
   */
  uint32_t maxGridDimZ;

  /**
   * Compute capability for the device, major number.
   */
  uint32_t computeCapabilityMajor;

  /**
   * Compute capability for the device, minor number.
   */
  uint32_t computeCapabilityMinor;

  /**
   * The device ID.
   */
  uint32_t id;

  /**
   * ECC enabled flag for device
   */
  uint32_t eccEnabled;

  /**
   * The device UUID. This value is the globally unique immutable
   * alphanumeric identifier of the device.
   */
  RPPuuid uuid;

#ifndef PTILP64
  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
#endif

  /**
   * The device name. This name is shared across all activity records
   * representing instances of the device, and so should not be
   * modified.
   */
  char name[MAX_DEVICE_NAME];
} pti_ActivityDevice2;

/**
 * \brief The activity record for a device attribute.
 *
 * This activity record represents information about a GPU device:
 * either a pti_DeviceAttribute or RPPdevice_attribute value
 * (PTI_ACTIVITY_KIND_DEVICE_ATTRIBUTE).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be
   * PTI_ACTIVITY_KIND_DEVICE_ATTRIBUTE.
   */
  pti_ActivityKind kind;

  /**
   * The flags associated with the device. \see pti_ActivityFlag
   */
  pti_ActivityFlag flags;

  /**
   * The ID of the device that this attribute applies to.
   */
  uint32_t deviceId;

  /**
   * The attribute, either a pti_DeviceAttribute or
   * RPPdevice_attribute. Flag
   * PTI_ACTIVITY_FLAG_DEVICE_ATTRIBUTE_RPPDEVICE is used to indicate
   * what kind of attribute this is. If
   * PTI_ACTIVITY_FLAG_DEVICE_ATTRIBUTE_RPPDEVICE is 1 then
   * RPPdevice_attribute field is value, otherwise
   * pti_DeviceAttribute field is valid.
   */
  union {
    RPPdevice_attribute rpp_attr;
    pti_DeviceAttribute pti_attr;
  } attribute;

  /**
   * The value for the attribute. See pti_DeviceAttribute and
   * RPPdevice_attribute for the type of the value for a given
   * attribute.
   */
  union {
    double vDouble;
    uint32_t vUint32;
    uint64_t vUint64;
    int32_t vInt32;
    int64_t vInt64;
  } value;
} pti_ActivityDeviceAttribute;

/**
 * \brief The activity record for a context.
 *
 * This activity record represents information about a context
 * (PTI_ACTIVITY_KIND_CONTEXT).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_CONTEXT.
   */
  pti_ActivityKind kind;

  /**
   * The context ID.
   */
  uint32_t contextId;

  /**
   * The device ID.
   */
  uint32_t deviceId;

  /**
   * The compute API kind. \see pti_ActivityComputeApiKind
   */
  uint16_t computeApiKind;

  /**
   * The ID for the NULL stream in this context
   */
  uint16_t nullStreamId;
} pti_ActivityContext;

/**
 * \brief The activity record providing a name.
 *
 * This activity record provides a name for a device, context, thread,
 * etc.  (PTI_ACTIVITY_KIND_NAME).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_NAME.
   */
  pti_ActivityKind kind;

  /**
   * The kind of activity object being named.
   */
  pti_ActivityObjectKind objectKind;

  /**
   * The identifier for the activity object. 'objectKind' indicates
   * which ID is valid for this record.
   */
  pti_ActivityObjectKindId objectId;

#ifdef PTILP64
  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
#endif

  /**
   * The name.
   */
  char name[MAX_NAME];

} pti_ActivityName;

/**
 * \brief The activity record providing a marker which is an
 * instantaneous point in time. (deprecated in RPP 8.0)
 *
 * The marker is specified with a descriptive name and unique id
 * (PTI_ACTIVITY_KIND_MARKER).
 * Marker activity is now reported using the
 * pti_ActivityMarker2 activity record.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_MARKER.
   */
  pti_ActivityKind kind;

  /**
   * The flags associated with the marker. \see pti_ActivityFlag
   */
  pti_ActivityFlag flags;

  /**
   * The timestamp for the marker, in ns. A value of 0 indicates that
   * timestamp information could not be collected for the marker.
   */
  uint64_t timestamp;

  /**
   * The marker ID.
   */
  uint32_t id;

  /**
   * The kind of activity object associated with this marker.
   */
  pti_ActivityObjectKind objectKind;

  /**
   * The identifier for the activity object associated with this
   * marker. 'objectKind' indicates which ID is valid for this record.
   */
  pti_ActivityObjectKindId objectId;

#ifdef PTILP64
  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
#endif

  /**
   * The marker name for an instantaneous or start marker. This will
   * be NULL for an end marker.
   */
  const char *name;

} pti_ActivityMarker;

/**
 * \brief The activity record providing a marker which is an
 * instantaneous point in time.
 *
 * The marker is specified with a descriptive name and unique id
 * (PTI_ACTIVITY_KIND_MARKER).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_MARKER.
   */
  pti_ActivityKind kind;

  /**
   * The flags associated with the marker. \see pti_ActivityFlag
   */
  pti_ActivityFlag flags;

  /**
   * The timestamp for the marker, in ns. A value of 0 indicates that
   * timestamp information could not be collected for the marker.
   */
  uint64_t timestamp;

  /**
   * The marker ID.
   */
  uint32_t id;

  /**
   * The kind of activity object associated with this marker.
   */
  pti_ActivityObjectKind objectKind;

  /**
   * The identifier for the activity object associated with this
   * marker. 'objectKind' indicates which ID is valid for this record.
   */
  pti_ActivityObjectKindId objectId;

  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;


  /**
   * The marker name for an instantaneous or start marker. This will
   * be NULL for an end marker.
   */
  const char *name;

  /**
   * The name of the domain to which this marker belongs to.
   * This will be NULL for default domain.
   */
  const char *domain;

} pti_ActivityMarker2;

/**
 * \brief The activity record providing detailed information for a marker.
 *
 * The marker data contains color, payload, and category.
 * (PTI_ACTIVITY_KIND_MARKER_DATA).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be
   * PTI_ACTIVITY_KIND_MARKER_DATA.
   */
  pti_ActivityKind kind;

  /**
   * The flags associated with the marker. \see pti_ActivityFlag
   */
  pti_ActivityFlag flags;

  /**
   * The marker ID.
   */
  uint32_t id;

  /**
   * Defines the payload format for the value associated with the marker.
   */
  pti_MetricValueKind payloadKind;

  /**
   * The payload value.
   */
  pti_MetricValue payload;

  /**
   * The color for the marker.
   */
  uint32_t color;

  /**
   * The category for the marker.
   */
  uint32_t category;

} pti_ActivityMarkerData;

/**
 * \brief The activity record for PTI and driver overheads.
 *
 * This activity record provides PTI and driver overhead information
 * (PTI_ACTIVITY_OVERHEAD).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_OVERHEAD.
   */
  pti_ActivityKind kind;

  /**
   * The kind of overhead, PTI, DRIVER, COMPILER etc.
   */
  pti_ActivityOverheadKind overheadKind;

  /**
   * The kind of activity object that the overhead is associated with.
   */
  pti_ActivityObjectKind objectKind;

  /**
   * The identifier for the activity object. 'objectKind' indicates
   * which ID is valid for this record.
   */
  pti_ActivityObjectKindId objectId;

  /**
   * The start timestamp for the overhead, in ns. A value of 0 for
   * both the start and end timestamps indicates that timestamp
   * information could not be collected for the overhead.
   */
  uint64_t start;

  /**
   * The end timestamp for the overhead, in ns. A value of 0 for both
   * the start and end timestamps indicates that timestamp information
   * could not be collected for the overhead.
   */
  uint64_t end;
} pti_ActivityOverhead;

/**
 * \brief The activity record for PTI environmental data.
 *
 * This activity record provides PTI environmental data, include
 * power, clocks, and thermals.  This information is sampled at
 * various rates and returned in this activity record.  The consumer
 * of the record needs to check the environmentKind field to figure
 * out what kind of environmental record this is.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_ENVIRONMENT.
   */
  pti_ActivityKind kind;

  /**
   * The ID of the device
   */
  uint32_t deviceId;

  /**
   * The timestamp when this sample was retrieved, in ns. A value of 0
   * indicates that timestamp information could not be collected for
   * the marker.
   */
  uint64_t timestamp;

  /**
   * The kind of data reported in this record.
   */
  pti_ActivityEnvironmentKind environmentKind;

  union {
    /**
     * Data returned for PTI_ACTIVITY_ENVIRONMENT_SPEED environment
     * kind.
     */
    struct {
      /**
       * The SM frequency in MHz
       */
      uint32_t smClock;

      /**
       * The memory frequency in MHz
       */
      uint32_t memoryClock;

      /**
       * The PCIe link generation.
       */
      uint32_t pcieLinkGen;

      /**
       * The PCIe link width.
       */
      uint32_t pcieLinkWidth;

      /**
       * The clocks throttle reasons.
       */
      pti_EnvironmentClocksThrottleReason clocksThrottleReasons;
    } speed;
    /**
     * Data returned for PTI_ACTIVITY_ENVIRONMENT_TEMPERATURE
     * environment kind.
     */
    struct {
      /**
       * The GPU temperature in degrees C.
       */
      uint32_t gpuTemperature;
    } temperature;
    /**
     * Data returned for PTI_ACTIVITY_ENVIRONMENT_POWER environment
     * kind.
     */
    struct {
      /**
       * The power in milliwatts consumed by GPU and associated
       * circuitry.
       */
      uint32_t power;

      /**
       * The power in milliwatts that will trigger power management
       * algorithm.
       */
      uint32_t powerLimit;
    } power;
    /**
     * Data returned for PTI_ACTIVITY_ENVIRONMENT_COOLING
     * environment kind.
     */
    struct {
      /**
       * The fan speed as percentage of maximum.
       */
      uint32_t fanSpeed;
    } cooling;
  } data;
} pti_ActivityEnvironment;

/**
 * \brief The activity record for source-level instruction execution.
 *
 * This activity records result for source level instruction execution.
 * (PTI_ACTIVITY_KIND_INSTRUCTION_EXECUTION).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_INSTRUCTION_EXECUTION.
   */
  pti_ActivityKind kind;

  /**
   * The properties of this instruction execution.
   */
  pti_ActivityFlag flags;

  /**
   * The ID for source locator.
   */
  uint32_t sourceLocatorId;

  /**
   * The correlation ID of the kernel to which this result is associated.
   */
  uint32_t correlationId;

 /**
  * Correlation ID with global/device function name
  */
  uint32_t functionId;

  /**
   * The pc offset for the instruction.
   */
  uint32_t pcOffset;

  /**
   * This increments each time when this instruction is executed by number
   * of threads that executed this instruction, regardless of predicate or condition code.
   */
  uint64_t threadsExecuted;

  /**
   * This increments each time when this instruction is executed by number
   * of threads that executed this instruction with predicate and condition code evaluating to true.
   */
  uint64_t notPredOffThreadsExecuted;

  /**
   * The number of times this instruction was executed per warp. It will be incremented
   * regardless of predicate or condition code.
   */
  uint32_t executed;

  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
} pti_ActivityInstructionExecution;

/**
 * \brief The activity record for PC sampling. (deprecated in RPP 8.0)
 *
 * This activity records information obtained by sampling PC
 * (PTI_ACTIVITY_KIND_PC_SAMPLING).
 * PC sampling activities are now reported using the
 * pti_ActivityPCSampling2 activity record.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_PC_SAMPLING.
   */
  pti_ActivityKind kind;

  /**
   * The properties of this instruction.
   */
  pti_ActivityFlag flags;

  /**
   * The ID for source locator.
   */
  uint32_t sourceLocatorId;

  /**
   * The correlation ID of the kernel to which this result is associated.
   */
  uint32_t correlationId;

 /**
  * Correlation ID with global/device function name
  */
  uint32_t functionId;

  /**
   * The pc offset for the instruction.
   */
  uint32_t pcOffset;

  /**
   * Number of times the PC was sampled with the stallReason in the record.
   * The same PC can be sampled with different stall reasons.
   */
  uint32_t samples;

  /**
   * Current stall reason. Includes one of the reasons from
   * \ref pti_ActivityPCSamplingStallReason
   */
  pti_ActivityPCSamplingStallReason stallReason;
} pti_ActivityPCSampling;

/**
 * \brief The activity record for PC sampling. (deprecated in RPP 9.0)
 *
 * This activity records information obtained by sampling PC
 * (PTI_ACTIVITY_KIND_PC_SAMPLING).
 * PC sampling activities are now reported using the
 * pti_ActivityPCSampling3 activity record.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_PC_SAMPLING.
   */
  pti_ActivityKind kind;

  /**
   * The properties of this instruction.
   */
  pti_ActivityFlag flags;

  /**
   * The ID for source locator.
   */
  uint32_t sourceLocatorId;

  /**
   * The correlation ID of the kernel to which this result is associated.
   */
  uint32_t correlationId;

 /**
  * Correlation ID with global/device function name
  */
  uint32_t functionId;

  /**
   * The pc offset for the instruction.
   */
  uint32_t pcOffset;

  /**
   * Number of times the PC was sampled with the stallReason in the record.
   * These samples indicate that no instruction was issued in that cycle from
   * the warp scheduler from where the warp was sampled.
   * Field is valid for devices with compute capability 6.0 and higher
   */
  uint32_t latencySamples;

  /**
   * Number of times the PC was sampled with the stallReason in the record.
   * The same PC can be sampled with different stall reasons. The count includes
   * latencySamples.
   */
  uint32_t samples;

  /**
   * Current stall reason. Includes one of the reasons from
   * \ref pti_ActivityPCSamplingStallReason
   */
  pti_ActivityPCSamplingStallReason stallReason;

  uint32_t pad;
} pti_ActivityPCSampling2;

/**
 * \brief The activity record for PC sampling.
 *
 * This activity records information obtained by sampling PC
 * (PTI_ACTIVITY_KIND_PC_SAMPLING).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_PC_SAMPLING.
   */
  pti_ActivityKind kind;

  /**
   * The properties of this instruction.
   */
  pti_ActivityFlag flags;

  /**
   * The ID for source locator.
   */
  uint32_t sourceLocatorId;

  /**
   * The correlation ID of the kernel to which this result is associated.
   */
  uint32_t correlationId;

 /**
  * Correlation ID with global/device function name
  */
  uint32_t functionId;

  /**
   * Number of times the PC was sampled with the stallReason in the record.
   * These samples indicate that no instruction was issued in that cycle from
   * the warp scheduler from where the warp was sampled.
   * Field is valid for devices with compute capability 6.0 and higher
   */
  uint32_t latencySamples;

  /**
   * Number of times the PC was sampled with the stallReason in the record.
   * The same PC can be sampled with different stall reasons. The count includes
   * latencySamples.
   */
  uint32_t samples;

  /**
   * Current stall reason. Includes one of the reasons from
   * \ref pti_ActivityPCSamplingStallReason
   */
  pti_ActivityPCSamplingStallReason stallReason;

    /**
   * The pc offset for the instruction.
   */
  uint64_t pcOffset;
} pti_ActivityPCSampling3;

/**
 * \brief The activity record for record status for PC sampling.
 *
 * This activity records information obtained by sampling PC
 * (PTI_ACTIVITY_KIND_PC_SAMPLING_RECORD_INFO).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_PC_SAMPLING_RECORD_INFO.
   */
  pti_ActivityKind kind;

  /**
   * The correlation ID of the kernel to which this result is associated.
   */
  uint32_t correlationId;

  /**
   * Number of times the PC was sampled for this kernel instance including all
   * dropped samples.
   */
  uint64_t totalSamples;

  /**
   * Number of samples that were dropped by hardware due to backpressure/overflow.
   */
  uint64_t droppedSamples;
  /**
   * Sampling period in terms of number of cycles .
   */
  uint64_t samplingPeriodInCycles;
} pti_ActivityPCSamplingRecordInfo;

/**
 * \brief The activity record for Unified Memory counters (deprecated in RPP 7.0)
 *
 * This activity record represents a Unified Memory counter
 * (PTI_ACTIVITY_KIND_UNIFIED_MEMORY_COUNTER).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_UNIFIED_MEMORY_COUNTER
   */
  pti_ActivityKind kind;

  /**
   * The Unified Memory counter kind. See /ref pti_ActivityUnifiedMemoryCounterKind
   */
  pti_ActivityUnifiedMemoryCounterKind counterKind;

  /**
   * Scope of the Unified Memory counter. See /ref pti_ActivityUnifiedMemoryCounterScope
   */
  pti_ActivityUnifiedMemoryCounterScope scope;

  /**
   * The ID of the device involved in the memory transfer operation.
   * It is not relevant if the scope of the counter is global (all devices).
   */
  uint32_t deviceId;

  /**
   * Value of the counter
   *
   */
  uint64_t value;

  /**
   * The timestamp when this sample was retrieved, in ns. A value of 0
   * indicates that timestamp information could not be collected
   */
  uint64_t timestamp;

  /**
   * The ID of the process to which this record belongs to. In case of
   * global scope, processId is undefined.
   */
  uint32_t processId;

  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
} pti_ActivityUnifiedMemoryCounter;

/**
 * \brief The activity record for Unified Memory counters (RPP 7.0 and beyond)
 *
 * This activity record represents a Unified Memory counter
 * (PTI_ACTIVITY_KIND_UNIFIED_MEMORY_COUNTER).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_UNIFIED_MEMORY_COUNTER
   */
  pti_ActivityKind kind;

  /**
   * The Unified Memory counter kind
   */
  pti_ActivityUnifiedMemoryCounterKind counterKind;

  /**
   * Value of the counter
   * For counterKind PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_BYTES_TRANSFER_HTOD,
   * PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_BYTES_TRANSFER_DTOH,
   * PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_THREASHING and
   * PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_REMOTE_MAP, it is the size of the
   * memory region in bytes.
   * For counterKind PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_GPU_PAGE_FAULT, it
   * is the number of page fault groups for the same page.
   * For counterKind PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_CPU_PAGE_FAULT_COUNT,
   * it is the program counter for the instruction that caused fault.
   */
  uint64_t value;

  /**
   * The start timestamp of the counter, in ns.
   * For counterKind PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_BYTES_TRANSFER_HTOD and
   * PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_BYTES_TRANSFER_DTOH, timestamp is
   * captured when activity starts on GPU.
   * For counterKind PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_GPU_PAGE_FAULT and
   * PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_CPU_PAGE_FAULT_COUNT, timestamp is
   * captured when RPP driver started processing the fault.
   * For counterKind PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_THRASHING, timestamp
   * is captured when RPP driver detected thrashing of memory region.
   * For counterKind PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_THROTTLING,
   * timestamp is captured when throttling opeeration was started by RPP driver.
   * For counterKind PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_REMOTE_MAP,
   * timestamp is captured when RPP driver has pushed all required operations
   * to the processor specified by dstId.
   */
  uint64_t start;

  /**
   * The end timestamp of the counter, in ns.
   * Ignore this field if counterKind is
   * PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_CPU_PAGE_FAULT_COUNT or
   * PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_THRASHING or
   * PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_REMOTE_MAP.
   * For counterKind PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_BYTES_TRANSFER_HTOD and
   * PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_BYTES_TRANSFER_DTOH, timestamp is
   * captured when activity finishes on GPU.
   * For counterKind PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_GPU_PAGE_FAULT, timestamp is
   * captured when RPP driver queues the replay of faulting memory accesses on the GPU
   * For counterKind PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_THROTTLING, timestamp
   * is captured when throttling operation was finished by RPP driver
   */
  uint64_t end;

  /**
   * This is the virtual base address of the page/s being transferred. For cpu and
   * gpu faults, the virtual address for the page that faulted.
   */
  uint64_t address;

  /**
   * The ID of the source CPU/device involved in the memory transfer, page fault, thrashing,
   * throttling or remote map operation. For counterKind
   * PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_THRASHING, it is a bitwise ORing of the
   * device IDs fighting for the memory region. Ignore this field if counterKind is
   * PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_CPU_PAGE_FAULT_COUNT
   */
  uint32_t srcId;

  /**
   * The ID of the destination CPU/device involved in the memory transfer or remote map
   * operation. Ignore this field if counterKind is
   * PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_GPU_PAGE_FAULT or
   * PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_CPU_PAGE_FAULT_COUNT or
   * PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_THRASHING or
   * PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_THROTTLING
   */
  uint32_t dstId;

  /**
   * The ID of the stream causing the transfer.
   * This value of this field is invalid.
   */
  uint32_t streamId;

  /**
   * The ID of the process to which this record belongs to.
   */
  uint32_t processId;

  /**
   * The flags associated with this record. See enums \ref pti_ActivityUnifiedMemoryAccessType
   * if counterKind is PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_GPU_PAGE_FAULT
   * and \ref pti_ActivityUnifiedMemoryMigrationCause if counterKind is
   * PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_BYTES_TRANSFER_HTOD or
   * PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_BYTES_TRANSFER_HTOD
   * and \ref pti_ActivityUnifiedMemoryRemoteMapCause if counterKind is
   * PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_REMOTE_MAP and \ref pti_ActivityFlag
   * if counterKind is PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_THRASHING or
   * PTI_ACTIVITY_UNIFIED_MEMORY_COUNTER_KIND_THROTTLING
   */
  uint32_t flags;

  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
} pti_ActivityUnifiedMemoryCounter2;

/**
 * \brief The activity record for global/device functions.
 *
 * This activity records function name and corresponding module
 * information.
 * (PTI_ACTIVITY_KIND_FUNCTION).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_FUNCTION.
   */
  pti_ActivityKind kind;

  /**
  * ID to uniquely identify the record
  */
  uint32_t id;

  /**
   * The ID of the context where the function is launched.
   */
  uint32_t contextId;

  /**
   * The module ID in which this global/device function is present.
   */
  uint32_t moduleId;

  /**
   * The function's unique symbol index in the module.
   */
  uint32_t functionIndex;

#ifdef PTILP64
  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
#endif

  /**
   * The name of the function. This name is shared across all activity
   * records representing the same kernel, and so should not be
   * modified.
   */
  // const char *name;
  char name[MAX_FUNC_NAME];
} pti_ActivityFunction;

/**
 * \brief The activity record for a RPP module.
 *
 * This activity record represents a RPP module
 * (PTI_ACTIVITY_KIND_MODULE). This activity record kind is not
 * produced by the activity API but is included for completeness and
 * ease-of-use. Profile frameworks built on top of PTI that collect
 * module data from the module callback may choose to use this type to
 * store the collected module data.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_MODULE.
   */
  pti_ActivityKind kind;

  /**
   * The ID of the context where the module is loaded.
   */
  uint32_t contextId;

  /**
   * The module ID.
   */
  uint32_t id;

  /**
   * The cubin size.
   */
  uint32_t cubinSize;

#ifndef PTILP64
  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
#endif

  /**
   * The pointer to cubin.
   */
  const void *cubin;
} pti_ActivityModule;

/**
 * \brief The activity record for source-level shared
 * access.
 *
 * This activity records the locations of the shared
 * accesses in the source
 * (PTI_ACTIVITY_KIND_SHARED_ACCESS).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_SHARED_ACCESS.
   */
  pti_ActivityKind kind;

  /**
   * The properties of this shared access.
   */
  pti_ActivityFlag flags;

  /**
   * The ID for source locator.
   */
  uint32_t sourceLocatorId;

  /**
   * The correlation ID of the kernel to which this result is associated.
   */
  uint32_t correlationId;

 /**
  * Correlation ID with global/device function name
  */
  uint32_t functionId;

  /**
   * The pc offset for the access.
   */
  uint32_t pcOffset;

  /**
   * This increments each time when this instruction is executed by number
   * of threads that executed this instruction with predicate and condition code evaluating to true.
   */
  uint64_t threadsExecuted;

  /**
   * The total number of shared memory transactions generated by this access
   */
  uint64_t sharedTransactions;

  /**
   * The minimum number of shared memory transactions possible based on the access pattern.
   */
  uint64_t theoreticalSharedTransactions;

  /**
   * The number of times this instruction was executed per warp. It will be incremented
   * when at least one of thread among warp is active with predicate and condition code
   * evaluating to true.
   */
  uint32_t executed;

  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
} pti_ActivitySharedAccess;

/**
 * \brief The activity record for RPP event.
 *
 * This activity is used to track recorded events.
 * (PTI_ACTIVITY_KIND_RPP_EVENT).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_RPP_EVENT.
   */
  pti_ActivityKind kind;

  /**
   * The correlation ID of the API to which this result is associated.
   */
  uint32_t correlationId;

  /**
   * The ID of the context where the event was recorded.
   */
  uint32_t contextId;

  /**
   * The compute stream where the event was recorded.
   */
  uint32_t streamId;

  /**
   * A unique event ID to identify the event record.
   */
  uint32_t eventId;

  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
} pti_ActivityRppEvent;

/**
 * \brief The activity record for RPP stream.
 *
 * This activity is used to track created streams.
 * (PTI_ACTIVITY_KIND_STREAM).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_STREAM.
   */
  pti_ActivityKind kind;
  /**
   * The ID of the context where the stream was created.
   */
  uint32_t contextId;

  /**
   * A unique stream ID to identify the stream.
   */
  uint32_t streamId;

  /**
   * The clamped priority for the stream.
   */
  uint32_t priority;

  /**
   * Flags associated with the stream.
   */
  pti_ActivityStreamFlag flag;

  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
} pti_ActivityStream;

/**
 * \brief The activity record for synchronization management.
 *
 * This activity is used to track various RPP synchronization APIs.
 * (PTI_ACTIVITY_KIND_SYNCHRONIZATION).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_SYNCHRONIZATION.
   */
  pti_ActivityKind kind;

  /**
   * The type of record.
   */
  pti_ActivitySynchronizationType type;

  /**
   * The start timestamp for the function, in ns. A value of 0 for
   * both the start and end timestamps indicates that timestamp
   * information could not be collected for the function.
   */
  uint64_t start;

  /**
   * The end timestamp for the function, in ns. A value of 0 for both
   * the start and end timestamps indicates that timestamp information
   * could not be collected for the function.
   */
  uint64_t end;

  /**
   * The correlation ID of the API to which this result is associated.
   */
  uint32_t correlationId;

  /**
   * The ID of the context for which the synchronization API is called.
   * In case of context synchronization API it is the context id for which the API is called.
   * In case of stream/event synchronization it is the ID of the context where the stream/event was created.
   */
  uint32_t contextId;

  /**
   * The compute stream for which the synchronization API is called.
   * A PTI_SYNCHRONIZATION_INVALID_VALUE value indicate the field is not applicable for this record.
   * Not valid for cuCtxSynchronize, cuEventSynchronize.
   */
  uint32_t streamId;

  /**
   * The event ID for which the synchronization API is called.
   * A PTI_SYNCHRONIZATION_INVALID_VALUE value indicate the field is not applicable for this record.
   * Not valid for cuCtxSynchronize, cuStreamSynchronize.
   */
  uint32_t rppEventId;
} pti_ActivitySynchronization;


/**
 * \brief The activity record for source-level sass/source
 * line-by-line correlation.
 *
 * This activity records source level sass/source correlation
 * information.
 * (PTI_ACTIVITY_KIND_INSTRUCTION_CORRELATION).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_INSTRUCTION_CORRELATION.
   */
  pti_ActivityKind kind;

  /**
   * The properties of this instruction.
   */
  pti_ActivityFlag flags;

  /**
   * The ID for source locator.
   */
  uint32_t sourceLocatorId;

 /**
  * Correlation ID with global/device function name
  */
  uint32_t functionId;

  /**
   * The pc offset for the instruction.
   */
  uint32_t pcOffset;

  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad;
} pti_ActivityInstructionCorrelation;

/**
 * \brief The OpenAcc event kind for OpenAcc activity records.
 *
 * \see pti_ActivityKindOpenAcc
 */
typedef enum {
    PTI_OPENACC_EVENT_KIND_INVALID              = 0,
    PTI_OPENACC_EVENT_KIND_DEVICE_INIT          = 1,
    PTI_OPENACC_EVENT_KIND_DEVICE_SHUTDOWN      = 2,
    PTI_OPENACC_EVENT_KIND_RUNTIME_SHUTDOWN     = 3,
    PTI_OPENACC_EVENT_KIND_ENQUEUE_LAUNCH       = 4,
    PTI_OPENACC_EVENT_KIND_ENQUEUE_UPLOAD       = 5,
    PTI_OPENACC_EVENT_KIND_ENQUEUE_DOWNLOAD     = 6,
    PTI_OPENACC_EVENT_KIND_WAIT                 = 7,
    PTI_OPENACC_EVENT_KIND_IMPLICIT_WAIT        = 8,
    PTI_OPENACC_EVENT_KIND_COMPUTE_CONSTRUCT    = 9,
    PTI_OPENACC_EVENT_KIND_UPDATE               = 10,
    PTI_OPENACC_EVENT_KIND_ENTER_DATA           = 11,
    PTI_OPENACC_EVENT_KIND_EXIT_DATA            = 12,
    PTI_OPENACC_EVENT_KIND_CREATE               = 13,
    PTI_OPENACC_EVENT_KIND_DELETE               = 14,
    PTI_OPENACC_EVENT_KIND_ALLOC                = 15,
    PTI_OPENACC_EVENT_KIND_FREE                 = 16,
    PTI_OPENACC_EVENT_KIND_FORCE_INT            = 0x7fffffff
} pti_OpenAccEventKind;

/**
 * \brief The OpenAcc parent construct kind for OpenAcc activity records.
 */
typedef enum {
    PTI_OPENACC_CONSTRUCT_KIND_UNKNOWN          = 0,
    PTI_OPENACC_CONSTRUCT_KIND_PARALLEL         = 1,
    PTI_OPENACC_CONSTRUCT_KIND_KERNELS          = 2,
    PTI_OPENACC_CONSTRUCT_KIND_LOOP             = 3,
    PTI_OPENACC_CONSTRUCT_KIND_DATA             = 4,
    PTI_OPENACC_CONSTRUCT_KIND_ENTER_DATA       = 5,
    PTI_OPENACC_CONSTRUCT_KIND_EXIT_DATA        = 6,
    PTI_OPENACC_CONSTRUCT_KIND_HOST_DATA        = 7,
    PTI_OPENACC_CONSTRUCT_KIND_ATOMIC           = 8,
    PTI_OPENACC_CONSTRUCT_KIND_DECLARE          = 9,
    PTI_OPENACC_CONSTRUCT_KIND_INIT             = 10,
    PTI_OPENACC_CONSTRUCT_KIND_SHUTDOWN         = 11,
    PTI_OPENACC_CONSTRUCT_KIND_SET              = 12,
    PTI_OPENACC_CONSTRUCT_KIND_UPDATE           = 13,
    PTI_OPENACC_CONSTRUCT_KIND_ROUTINE          = 14,
    PTI_OPENACC_CONSTRUCT_KIND_WAIT             = 15,
    PTI_OPENACC_CONSTRUCT_KIND_RUNTIME_API      = 16,
    PTI_OPENACC_CONSTRUCT_KIND_FORCE_INT        = 0x7fffffff

} pti_OpenAccConstructKind;

/**
 * \brief The base activity record for OpenAcc records.
 *
 * The OpenACC activity API part uses a pti_ActivityOpenAcc as a generic
 * representation for any OpenACC activity. The 'kind' field is used to determine the
 * specific activity kind, and from that the pti_ActivityOpenAcc object can
 * be cast to the specific OpenACC activity record type appropriate for that kind.
 *
 * Note that all OpenACC activity record types are padded and aligned to
 * ensure that each member of the record is naturally aligned.
 *
 * \see pti_ActivityKind
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The kind of this activity.
   */
  pti_ActivityKind kind;

  /**
   * PTI OpenACC event kind (\see pti_OpenAccEventKind)
   */
  pti_OpenAccEventKind eventKind;

  /**
   * PTI OpenACC parent construct kind (\see pti_OpenAccConstructKind)
   *
   * Note that for applications using PGI OpenACC runtime < 16.1, this
   * will always be PTI_OPENACC_CONSTRUCT_KIND_UNKNOWN.
   */
  pti_OpenAccConstructKind parentConstruct;

  /*
   * Version number
   */
  uint32_t version;

  /*
   * 1 for any implicit event, such as an implicit wait at a synchronous data construct
   * 0 otherwise
   */
  uint32_t implicit;

  /*
   * Device type
   */
  uint32_t deviceType;

  /*
   * Device number
   */
  uint32_t deviceNumber;

  /**
   * ThreadId
   */
  uint32_t threadId;

  /*
   * Value of async() clause of the corresponding directive
   */
  uint64_t async;

  /*
   * Internal asynchronous queue number used
   */
  uint64_t asyncMap;

  /*
   * The line number of the directive or program construct or the starting line
   * number of the OpenACC construct corresponding to the event.
   * A zero value means the line number is not known.
   */
  uint32_t lineNo;

  /*
   * For an OpenACC construct, this contains the line number of the end
   * of the construct. A zero value means the line number is not known.
   */
  uint32_t endLineNo;

  /*
   * The line number of the first line of the function named in funcName.
   * A zero value means the line number is not known.
   */
  uint32_t funcLineNo;

  /*
   * The last line number of the function named in funcName.
   * A zero value means the line number is not known.
   */
  uint32_t funcEndLineNo;

  /**
   * PTI start timestamp
   */
  uint64_t start;

  /**
   * PTI end timestamp
   */
  uint64_t end;

  /**
   * RPP device id
   * Valid only if deviceType is acc_device_nvidia.
   */
  uint32_t cuDeviceId;

  /**
   * RPP context id
   * Valid only if deviceType is acc_device_nvidia.
   */
  uint32_t cuContextId;

  /**
   * RPP stream id
   * Valid only if deviceType is acc_device_nvidia.
   */
  uint32_t cuStreamId;

  /**
   * The ID of the process where the OpenACC activity is executing.
   */
  uint32_t cuProcessId;

  /**
   * The ID of the thread where the OpenACC activity is executing.
   */
  uint32_t cuThreadId;

  /**
   * The OpenACC correlation ID.
   * Valid only if deviceType is acc_device_nvidia.
   * If not 0, it uniquely identifies this record. It is identical to the
   * externalId in the preceeding external correlation record of type
   * PTI_EXTERNAL_CORRELATION_KIND_OPENACC.
   */
  uint32_t externalId;

  /*
   * A pointer to null-terminated string containing the name of or path to
   * the source file, if known, or a null pointer if not.
   */
  const char *srcFile;

  /*
   * A pointer to a null-terminated string containing the name of the
   * function in which the event occurred.
   */
  const char *funcName;
} pti_ActivityOpenAcc;

/**
 * \brief The activity record for OpenACC data.
 *
 * (PTI_ACTIVITY_KIND_OPENACC_DATA).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_OPENACC_DATA.
   */
  pti_ActivityKind kind;

  /**
   * PTI OpenACC event kind (\see pti_OpenAccEventKind)
   */
  pti_OpenAccEventKind eventKind;

  /*
   * PTI OpenACC parent construct kind (\see pti_OpenAccConstructKind)
   *
   * Note that for applications using PGI OpenACC runtime < 16.1, this
   * will always be PTI_OPENACC_CONSTRUCT_KIND_UNKNOWN.
   */
  pti_OpenAccConstructKind parentConstruct;

  /*
   * Version number
   */
  uint32_t version;

  /*
   * 1 for any implicit event, such as an implicit wait at a synchronous data construct
   * 0 otherwise
   */
  uint32_t implicit;

  /*
   * Device type
   */
  uint32_t deviceType;

  /*
   * Device number
   */
  uint32_t deviceNumber;

  /**
   * ThreadId
   */
  uint32_t threadId;

  /*
   * Value of async() clause of the corresponding directive
   */
  uint64_t async;

  /*
   * Internal asynchronous queue number used
   */
  uint64_t asyncMap;

  /*
   * The line number of the directive or program construct or the starting line
   * number of the OpenACC construct corresponding to the event.
   * A negative or zero value means the line number is not known.
   */
  uint32_t lineNo;

  /*
   * For an OpenACC construct, this contains the line number of the end
   * of the construct. A negative or zero value means the line number is not known.
   */
  uint32_t endLineNo;

  /*
   * The line number of the first line of the function named in func_name.
   * A negative or zero value means the line number is not known.
   */
  uint32_t funcLineNo;

  /*
   * The last line number of the function named in func_name.
   * A negative or zero value means the line number is not known.
   */
  uint32_t funcEndLineNo;

  /**
   * PTI start timestamp
   */
  uint64_t start;

  /**
   * PTI end timestamp
   */
  uint64_t end;

  /**
   * RPP device id
   * Valid only if deviceType is acc_device_nvidia.
   */
  uint32_t cuDeviceId;

  /**
   * RPP context id
   * Valid only if deviceType is acc_device_nvidia.
   */
  uint32_t cuContextId;

  /**
   * RPP stream id
   * Valid only if deviceType is acc_device_nvidia.
   */
  uint32_t cuStreamId;

  /**
   * The ID of the process where the OpenACC activity is executing.
   */
  uint32_t cuProcessId;

  /**
   * The ID of the thread where the OpenACC activity is executing.
   */
  uint32_t cuThreadId;

  /**
   * The OpenACC correlation ID.
   * Valid only if deviceType is acc_device_nvidia.
   * If not 0, it uniquely identifies this record. It is identical to the
   * externalId in the preceeding external correlation record of type
   * PTI_EXTERNAL_CORRELATION_KIND_OPENACC.
   */
  uint32_t externalId;

  /*
   * A pointer to null-terminated string containing the name of or path to
   * the source file, if known, or a null pointer if not.
   */
  const char *srcFile;

  /*
   * A pointer to a null-terminated string containing the name of the
   * function in which the event occurred.
   */
  const char *funcName;

  /* --- end of common pti_ActivityOpenAcc part --- */

  /**
   * Number of bytes
   */
  uint64_t bytes;

  /**
   * Host pointer if available
   */
  uint64_t hostPtr;

  /**
   * Device pointer if available
   */
  uint64_t devicePtr;

#ifndef PTILP64
  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad1;
#endif

  /*
   * A pointer to null-terminated string containing the name of the variable
   * for which this event is triggered, if known, or a null pointer if not.
   */
  const char *varName;

} pti_ActivityOpenAccData;

/**
 * \brief The activity record for OpenACC launch.
 *
 * (PTI_ACTIVITY_KIND_OPENACC_LAUNCH).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_OPENACC_LAUNCH.
   */
  pti_ActivityKind kind;

  /**
   * PTI OpenACC event kind (\see pti_OpenAccEventKind)
   */
  pti_OpenAccEventKind eventKind;

  /*
   * PTI OpenACC parent construct kind (\see pti_OpenAccConstructKind)
   *
   * Note that for applications using PGI OpenACC runtime < 16.1, this
   * will always be PTI_OPENACC_CONSTRUCT_KIND_UNKNOWN.
   */
  pti_OpenAccConstructKind parentConstruct;

  /*
   * Version number
   */
  uint32_t version;

  /*
   * 1 for any implicit event, such as an implicit wait at a synchronous data construct
   * 0 otherwise
   */
  uint32_t implicit;

  /*
   * Device type
   */
  uint32_t deviceType;

  /*
   * Device number
   */
  uint32_t deviceNumber;

  /**
   * ThreadId
   */
  uint32_t threadId;

  /*
   * Value of async() clause of the corresponding directive
   */
  uint64_t async;

  /*
   * Internal asynchronous queue number used
   */
  uint64_t asyncMap;

  /*
   * The line number of the directive or program construct or the starting line
   * number of the OpenACC construct corresponding to the event.
   * A negative or zero value means the line number is not known.
   */
  uint32_t lineNo;

  /*
   * For an OpenACC construct, this contains the line number of the end
   * of the construct. A negative or zero value means the line number is not known.
   */
  uint32_t endLineNo;

  /*
   * The line number of the first line of the function named in func_name.
   * A negative or zero value means the line number is not known.
   */
  uint32_t funcLineNo;

  /*
   * The last line number of the function named in func_name.
   * A negative or zero value means the line number is not known.
   */
  uint32_t funcEndLineNo;

  /**
   * PTI start timestamp
   */
  uint64_t start;

  /**
   * PTI end timestamp
   */
  uint64_t end;

  /**
   * RPP device id
   * Valid only if deviceType is acc_device_nvidia.
   */
  uint32_t cuDeviceId;

  /**
   * RPP context id
   * Valid only if deviceType is acc_device_nvidia.
   */
  uint32_t cuContextId;

  /**
   * RPP stream id
   * Valid only if deviceType is acc_device_nvidia.
   */
  uint32_t cuStreamId;

  /**
   * The ID of the process where the OpenACC activity is executing.
   */
  uint32_t cuProcessId;

  /**
   * The ID of the thread where the OpenACC activity is executing.
   */
  uint32_t cuThreadId;

  /**
   * The OpenACC correlation ID.
   * Valid only if deviceType is acc_device_nvidia.
   * If not 0, it uniquely identifies this record. It is identical to the
   * externalId in the preceeding external correlation record of type
   * PTI_EXTERNAL_CORRELATION_KIND_OPENACC.
   */
  uint32_t externalId;

  /*
   * A pointer to null-terminated string containing the name of or path to
   * the source file, if known, or a null pointer if not.
   */
  const char *srcFile;

  /*
   * A pointer to a null-terminated string containing the name of the
   * function in which the event occurred.
   */
  const char *funcName;

  /* --- end of common pti_ActivityOpenAcc part --- */

  /**
   * The number of gangs created for this kernel launch
   */
  uint64_t numGangs;

  /**
   * The number of workers created for this kernel launch
   */
  uint64_t numWorkers;

  /**
   * The number of vector lanes created for this kernel launch
   */
  uint64_t vectorLength;

#ifndef PTILP64
  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t pad1;
#endif

  /*
   * A pointer to null-terminated string containing the name of the
   * kernel being launched, if known, or a null pointer if not.
   */
  const char *kernelName;

} pti_ActivityOpenAccLaunch;

/**
 * \brief The activity record for OpenACC other.
 *
 * (PTI_ACTIVITY_KIND_OPENACC_OTHER).
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_OPENACC_OTHER.
   */
  pti_ActivityKind kind;

  /**
   * PTI OpenACC event kind (\see pti_OpenAccEventKind)
   */
  pti_OpenAccEventKind eventKind;

  /*
   * PTI OpenACC parent construct kind (\see pti_OpenAccConstructKind)
   *
   * Note that for applications using PGI OpenACC runtime < 16.1, this
   * will always be PTI_OPENACC_CONSTRUCT_KIND_UNKNOWN.
   */
  pti_OpenAccConstructKind parentConstruct;

  /*
   * Version number
   */
  uint32_t version;

  /*
   * 1 for any implicit event, such as an implicit wait at a synchronous data construct
   * 0 otherwise
   */
  uint32_t implicit;

  /*
   * Device type
   */
  uint32_t deviceType;

  /*
   * Device number
   */
  uint32_t deviceNumber;

  /**
   * ThreadId
   */
  uint32_t threadId;

  /*
   * Value of async() clause of the corresponding directive
   */
  uint64_t async;

  /*
   * Internal asynchronous queue number used
   */
  uint64_t asyncMap;

  /*
   * The line number of the directive or program construct or the starting line
   * number of the OpenACC construct corresponding to the event.
   * A negative or zero value means the line number is not known.
   */
  uint32_t lineNo;

  /*
   * For an OpenACC construct, this contains the line number of the end
   * of the construct. A negative or zero value means the line number is not known.
   */
  uint32_t endLineNo;

  /*
   * The line number of the first line of the function named in func_name.
   * A negative or zero value means the line number is not known.
   */
  uint32_t funcLineNo;

  /*
   * The last line number of the function named in func_name.
   * A negative or zero value means the line number is not known.
   */
  uint32_t funcEndLineNo;

  /**
   * PTI start timestamp
   */
  uint64_t start;

  /**
   * PTI end timestamp
   */
  uint64_t end;

  /**
   * RPP device id
   * Valid only if deviceType is acc_device_nvidia.
   */
  uint32_t cuDeviceId;

  /**
   * RPP context id
   * Valid only if deviceType is acc_device_nvidia.
   */
  uint32_t cuContextId;

  /**
   * RPP stream id
   * Valid only if deviceType is acc_device_nvidia.
   */
  uint32_t cuStreamId;

  /**
   * The ID of the process where the OpenACC activity is executing.
   */
  uint32_t cuProcessId;

  /**
   * The ID of the thread where the OpenACC activity is executing.
   */
  uint32_t cuThreadId;

  /**
   * The OpenACC correlation ID.
   * Valid only if deviceType is acc_device_nvidia.
   * If not 0, it uniquely identifies this record. It is identical to the
   * externalId in the preceeding external correlation record of type
   * PTI_EXTERNAL_CORRELATION_KIND_OPENACC.
   */
  uint32_t externalId;

  /*
   * A pointer to null-terminated string containing the name of or path to
   * the source file, if known, or a null pointer if not.
   */
  const char *srcFile;

  /*
   * A pointer to a null-terminated string containing the name of the
   * function in which the event occurred.
   */
  const char *funcName;

  /* --- end of common pti_ActivityOpenAcc part --- */
} pti_ActivityOpenAccOther;

/**
 * \brief The kind of external APIs supported for correlation.
 *
 * Custom correlation kinds are reserved for usage in external tools.
 *
 * \see pti_ActivityExternalCorrelation
 */
typedef enum {
    PTI_EXTERNAL_CORRELATION_KIND_INVALID              = 0,

    /* The external API is unknown to PTI */
    PTI_EXTERNAL_CORRELATION_KIND_UNKNOWN              = 1,

    /* The external API is OpenACC */
    PTI_EXTERNAL_CORRELATION_KIND_OPENACC              = 2,

    /* The external API is custom0 */
    PTI_EXTERNAL_CORRELATION_KIND_CUSTOM0              = 3,

    /* The external API is custom1 */
    PTI_EXTERNAL_CORRELATION_KIND_CUSTOM1              = 4,

    /* The external API is custom2 */
    PTI_EXTERNAL_CORRELATION_KIND_CUSTOM2              = 5,

    /* Add new kinds before this line */
    PTI_EXTERNAL_CORRELATION_KIND_SIZE,

    PTI_EXTERNAL_CORRELATION_KIND_FORCE_INT            = 0x7fffffff
} pti_ExternalCorrelationKind;

/**
 * \brief The activity record for correlation with external records
 *
 * This activity record correlates native RPP records (e.g. RPP Driver API,
 * kernels, memcpys, ...) with records from external APIs such as OpenACC.
 * (PTI_ACTIVITY_KIND_EXTERNAL_CORRELATION).
 *
 * \see pti_ActivityKind
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The kind of this activity.
   */
  pti_ActivityKind kind;

  /**
   * The kind of external API this record correlated to.
   */
  pti_ExternalCorrelationKind externalKind;

  /**
   * The correlation ID of the associated non-RPP API record.
   * The exact field in the associated external record depends
   * on that record's activity kind (\see externalKind).
   */
  uint64_t externalId;

  /**
   * The correlation ID of the associated RPP driver or runtime API record.
   */
  uint32_t correlationId;

  /**
   * Undefined. Reserved for internal use.
   */
  uint32_t reserved;
} pti_ActivityExternalCorrelation;

/**
* \brief The device type for device connected to NVLink.
*/
typedef enum {
    PTI_DEV_TYPE_INVALID = 0,
    /**
    * The device type is GPU.
    */
    PTI_DEV_TYPE_GPU = 1,
    /**
    * The device type is NVLink processing unit in CPU.
    */
    PTI_DEV_TYPE_NPU = 2,
    PTI_DEV_TYPE_FORCE_INT = 0x7fffffff
} pti_DevType;

/**
* \brief NVLink information. (deprecated in RPP 9.0)
*
* This structure gives capabilities of each logical NVLink connection between two devices,
* gpu<->gpu or gpu<->CPU which can be used to understand the topology.
* NVLink information are now reported using the
* pti_ActivityNvLink2 activity record.
*/

typedef struct PACKED_ALIGNMENT {
    /**
    * The activity record kind, must be PTI_ACTIVITY_KIND_NVLINK.
    */
    pti_ActivityKind kind;
    /**
    * NVLink version.
    */
    uint32_t  nvlinkVersion;
    /**
    * Type of device 0 \ref pti_DevType
    */
    pti_DevType typeDev0;
    /**
    * Type of device 1 \ref pti_DevType
    */
    pti_DevType typeDev1;
    /**
    * If typeDev0 is PTI_DEV_TYPE_GPU, UUID for device 0. \ref pti_ActivityDevice2.
    * If typeDev0 is PTI_DEV_TYPE_NPU, struct npu for NPU.
    */
    union {
        RPPuuid    uuidDev;
        struct {
            /**
            * Index of the NPU. First index will always be zero.
            */
            uint32_t  index;
            /**
            * Domain ID of NPU. On Linux, this can be queried using lspci.
            */
            uint32_t  domainId;
        } npu;
    } idDev0;
    /**
    * If typeDev1 is PTI_DEV_TYPE_GPU, UUID for device 1. \ref pti_ActivityDevice2.
    * If typeDev1 is PTI_DEV_TYPE_NPU, struct npu for NPU.
    */
    union {
        RPPuuid    uuidDev;
        struct {
            /**
            * Index of the NPU. First index will always be zero.
            */
            uint32_t  index;
            /**
            * Domain ID of NPU. On Linux, this can be queried using lspci.
            */
            uint32_t  domainId;
        } npu;
    } idDev1;
    /**
    * Flag gives capabilities of the link \see pti_LinkFlag
    */
    uint32_t flag;
    /**
    * Number of physical NVLinks present between two devices.
    */
    uint32_t  physicalNvLinkCount;
    /**
    * Port numbers for maximum 4 NVLinks connected to device 0.
    * If typeDev0 is PTI_DEV_TYPE_NPU, ignore this field.
    * In case of invalid/unknown port number, this field will be set
    * to value PTI_NVLINK_INVALID_PORT.
    * This will be used to correlate the metric values to individual
    * physical link and attribute traffic to the logical NVLink in
    * the topology.
    */
    int8_t  portDev0[4];
    /**
    * Port numbers for maximum 4 NVLinks connected to device 1.
    * If typeDev1 is PTI_DEV_TYPE_NPU, ignore this field.
    * In case of invalid/unknown port number, this field will be set
    * to value PTI_NVLINK_INVALID_PORT.
    * This will be used to correlate the metric values to individual
    * physical link and attribute traffic to the logical NVLink in
    * the topology.
    */
    int8_t  portDev1[4];
    /**
    * Banwidth of NVLink in kbytes/sec
    */
    uint64_t  bandwidth;
} pti_ActivityNvLink;

/**
* \brief NVLink information.
*
* This structure gives capabilities of each logical NVLink connection between two devices,
* gpu<->gpu or gpu<->CPU which can be used to understand the topology.
*/

typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_NVLINK.
   */
  pti_ActivityKind kind;
  /**
   * NvLink version.
   */
  uint32_t  nvlinkVersion;
  /**
   * Type of device 0 \ref pti_DevType
   */
  pti_DevType typeDev0;
  /**
   * Type of device 1 \ref pti_DevType
   */
  pti_DevType typeDev1;
  /**
   * If typeDev0 is PTI_DEV_TYPE_GPU, UUID for device 0. \ref pti_ActivityDevice2.
   * If typeDev0 is PTI_DEV_TYPE_NPU, struct npu for NPU.
   */
  union {
    RPPuuid    uuidDev;
    struct {
      /**
       * Index of the NPU. First index will always be zero.
       */
      uint32_t  index;
      /**
       * Domain ID of NPU. On Linux, this can be queried using lspci.
       */
      uint32_t  domainId;
    } npu;
  } idDev0;
  /**
   * If typeDev1 is PTI_DEV_TYPE_GPU, UUID for device 1. \ref pti_ActivityDevice2.
   * If typeDev1 is PTI_DEV_TYPE_NPU, struct npu for NPU.
   */
  union {
    RPPuuid    uuidDev;
    struct {
      /**
       * Index of the NPU. First index will always be zero.
       */
      uint32_t  index;
      /**
       * Domain ID of NPU. On Linux, this can be queried using lspci.
       */
      uint32_t  domainId;
    } npu;
  } idDev1;
  /**
   * Flag gives capabilities of the link \see pti_LinkFlag
   */
  uint32_t flag;
  /**
   * Number of physical NVLinks present between two devices.
   */
  uint32_t  physicalNvLinkCount;
  /**
   * Port numbers for maximum 16 NVLinks connected to device 0.
   * If typeDev0 is PTI_DEV_TYPE_NPU, ignore this field.
   * In case of invalid/unknown port number, this field will be set
   * to value PTI_NVLINK_INVALID_PORT.
   * This will be used to correlate the metric values to individual
   * physical link and attribute traffic to the logical NVLink in
   * the topology.
   */
  int8_t  portDev0[PTI_MAX_NVLINK_PORTS];
  /**
   * Port numbers for maximum 16 NVLinks connected to device 1.
   * If typeDev1 is PTI_DEV_TYPE_NPU, ignore this field.
   * In case of invalid/unknown port number, this field will be set
   * to value PTI_NVLINK_INVALID_PORT.
   * This will be used to correlate the metric values to individual
   * physical link and attribute traffic to the logical NVLink in
   * the topology.
   */
  int8_t  portDev1[PTI_MAX_NVLINK_PORTS];
  /**
   * Banwidth of NVLink in kbytes/sec
   */
  uint64_t  bandwidth;
} pti_ActivityNvLink2;

/**
 * \brief The activity record for an instantaneous PTI event.
 *
 * This activity record represents a PTI event value
 * (PTI_ACTIVITY_KIND_EVENT) sampled at a particular instant.
 * This activity record kind is not produced by the activity API but is
 * included for completeness and ease-of-use. Profiler frameworks built on
 * top of PTI that collect event data at a particular time may choose to
 * use this type to store the collected event data.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_INSTANTANEOUS_EVENT.
   */
  pti_ActivityKind kind;

  /**
   * The event ID.
   */
  pti_EventID id;

  /**
   * The event value.
   */
  uint64_t value;

  /**
   * The timestamp at which event is sampled
   */
  uint64_t timestamp;

  /**
   * The device id
   */
  uint32_t deviceId;
  /**
   * Undefined. reserved for internal use
   */
  uint32_t reserved;
} pti_ActivityInstantaneousEvent;

/**
 * \brief The activity record for an instantaneous PTI event
 * with event domain instance information.
 *
 * This activity record represents the a PTI event value for a
 * specific event domain instance
 * (PTI_ACTIVITY_KIND_EVENT_INSTANCE) sampled at a particular instant.
 * This activity record kind is not produced by the activity API but is
 * included for completeness and ease-of-use. Profiler frameworks built on
 * top of PTI that collect event data may choose to use this type to store the
 * collected event data. This activity record should be used when
 * event domain instance information needs to be associated with the
 * event.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_INSTANTANEOUS_EVENT_INSTANCE.
   */
  pti_ActivityKind kind;

  /**
   * The event ID.
   */
  pti_EventID id;

  /**
   * The event value.
   */
  uint64_t value;

  /**
   * The timestamp at which event is sampled
   */
  uint64_t timestamp;

  /**
   * The device id
   */
  uint32_t deviceId;
  /**
   * The event domain instance
   */
  uint8_t instance;
  /**
   * Undefined. reserved for internal use
   */
  uint8_t pad[3];
} pti_ActivityInstantaneousEventInstance;

/**
 * \brief The activity record for an instantaneous PTI metric.
 *
 * This activity record represents the collection of a PTI metric
 * value (PTI_ACTIVITY_KIND_METRIC) at a particular instance.
 * This activity record kind is not produced by the activity API but
 * is included for completeness and ease-of-use. Profiler frameworks built
 * on top of PTI that collect metric data may choose to use this type to
 * store the collected metric data.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_INSTANTANEOUS_METRIC.
   */
  pti_ActivityKind kind;

  /**
   * The metric ID.
   */
  pti_MetricID id;

  /**
   * The metric value.
   */
  pti_MetricValue value;

  /**
   * The timestamp at which metric is sampled
   */
  uint64_t timestamp;

  /**
   * The device id
   */
  uint32_t deviceId;

  /**
   * The properties of this metric. \see pti_ActivityFlag
   */
  uint8_t flags;

  /**
   * Undefined. reserved for internal use
   */
  uint8_t pad[3];
} pti_ActivityInstantaneousMetric;

/**
 * \brief The instantaneous activity record for a PTI metric with instance
 * information.

 * This activity record represents a PTI metric value
 * for a specific metric domain instance
 * (PTI_ACTIVITY_KIND_METRIC_INSTANCE) sampled at a particular time. This
 * activity record kind is not produced by the activity API but is included for
 * completeness and ease-of-use. Profiler frameworks built on top of
 * PTI that collect metric data may choose to use this type to store
 * the collected metric data. This activity record should be used when
 * metric domain instance information needs to be associated with the
 * metric.
 */
typedef struct PACKED_ALIGNMENT {
  /**
   * The activity record kind, must be PTI_ACTIVITY_KIND_INSTANTANEOUS_METRIC_INSTANCE.
   */
  pti_ActivityKind kind;

  /**
   * The metric ID.
   */
  pti_MetricID id;

  /**
   * The metric value.
   */
  pti_MetricValue value;

  /**
   * The timestamp at which metric is sampled
   */
  uint64_t timestamp;

  /**
   * The device id
   */
  uint32_t deviceId;

  /**
   * The properties of this metric. \see pti_ActivityFlag
   */
  uint8_t flags;

  /**
   * The metric domain instance
   */
  uint8_t instance;
  /**
   * Undefined. reserved for internal use
   */
  uint8_t pad[2];
} pti_ActivityInstantaneousMetricInstance;

END_PACKED_ALIGNMENT

/**
 * \brief Activity attributes.
 *
 * These attributes are used to control the behavior of the activity
 * API.
 */
typedef enum {
    /**
     * The device memory size (in bytes) reserved for storing profiling
     * data for non-CDP operations, especially for concurrent kernel
     * tracing, for each buffer on a context. The value is a size_t.
     *
     * Having larger buffer size means less flush operations but
     * consumes more device memory. Having smaller buffer size
     * increases the risk of dropping timestamps for kernel records
     * if too many kernels are launched/replayed at one time. This
     * value only applies to new buffer allocations.
     *
     * Set this value before initializing RPP or before creating a
     * context to ensure it is considered for the following allocations.
     *
     * The default value is 8388608 (8MB).
     *
     * Note: The actual amount of device memory per buffer reserved by
     * PTI might be larger.
     */
    PTI_ACTIVITY_ATTR_DEVICE_BUFFER_SIZE              = 0,
    /**
     * The device memory size (in bytes) reserved for storing profiling
     * data for CDP operations for each buffer on a context. The
     * value is a size_t.
     *
     * Having larger buffer size means less flush operations but
     * consumes more device memory. This value only applies to new
     * allocations.
     *
     * Set this value before initializing RPP or before creating a
     * context to ensure it is considered for the following allocations.
     *
     * The default value is 8388608 (8MB).
     *
     * Note: The actual amount of device memory per context reserved by
     * PTI might be larger.
     */
    PTI_ACTIVITY_ATTR_DEVICE_BUFFER_SIZE_CDP          = 1,
    /**
     * The maximum number of memory buffers per context. The value is
     * a size_t.
     *
     * Buffers can be reused by the context. Increasing this value
     * reduces the number of times PTI needs to flush the buffers.
     * Setting this value will not modify the number of memory buffers
     * currently stored.
     *
     * Set this value before initializing RPP to ensure the limit is
     * not exceeded.
     *
     * The default value is 100.
     */
    PTI_ACTIVITY_ATTR_DEVICE_BUFFER_POOL_LIMIT        = 2,

    /**
     * The profiling semaphore pool size reserved for storing profiling
     * data for serialized kernels and memory operations for each context.
     * The value is a size_t.
     *
     * Having larger pool size means less semaphore query operations but
     * consumes more device resources. Having smaller pool size increases
     * the risk of dropping timestamps for kernel and memcpy records if
     * too many kernels or memcpy are launched/replayed at one time.
     * This value only applies to new pool allocations.
     *
     * Set this value before initializing RPP or before creating a
     * context to ensure it is considered for the following allocations.
     *
     * The default value is 65536.
     *
     */
    PTI_ACTIVITY_ATTR_PROFILING_SEMAPHORE_POOL_SIZE   = 3,
    /**
     * The maximum number of profiling semaphore pools per context. The
     * value is a size_t.
     *
     * Profiling semaphore pool can be reused by the context. Increasing
     * this value reduces the number of times PTI needs to query semaphores
     * in the pool. Setting this value will not modify the number of
     * semaphore pools currently stored.
     *
     * Set this value before initializing RPP to ensure the limit is
     * not exceeded.
     *
     * The default value is 100.
     */
    PTI_ACTIVITY_ATTR_PROFILING_SEMAPHORE_POOL_LIMIT  = 4,

    PTI_ACTIVITY_ATTR_DEVICE_BUFFER_FORCE_INT         = 0x7fffffff
} pti_ActivityAttribute;

/**
 * \brief Thread-Id types.
 *
 * PTI uses different methods to obtain the thread-id depending on the
 * support and the underlying platform. This enum documents these methods
 * for each type. APIs \ref cuptiSetThreadIdType and \ref cuptiGetThreadIdType
 * can be used to set and get the thread-id type.
 */
typedef enum {
    /**
     * Default type
     * Windows uses API GetCurrentThreadId()
     * Linux/Mac/Android/QNX use POSIX pthread API pthread_self()
     */
    PTI_ACTIVITY_THREAD_ID_TYPE_DEFAULT       = 0,

    /**
     * This type is based on the system API available on the underlying platform
     * and thread-id obtained is supposed to be unique for the process lifetime.
     * Windows uses API GetCurrentThreadId()
     * Linux uses syscall SYS_gettid
     * Mac uses syscall SYS_thread_selfid
     * Android/QNX use gettid()
     */
    PTI_ACTIVITY_THREAD_ID_TYPE_SYSTEM        = 1,

    PTI_ACTIVITY_THREAD_ID_TYPE_FORCE_INT     = 0x7fffffff
} pti_ActivityThreadIdType;


/**
 * \brief Get the PTI timestamp.
 *
 * Returns a timestamp normalized to correspond with the start and end
 * timestamps reported in the PTI activity records. The timestamp is
 * reported in us.
 *
 * \param timestamp Returns the PTI timestamp
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_INVALID_PARAMETER if \p timestamp is NULL
 */
PTIResult PTIAPI ptiGetTimestamp(uint64_t *timestamp);

/**
 * \brief Enable collection of a specific kind of activity record.
 *
 * Enable collection of a specific kind of activity record. Multiple
 * kinds can be enabled by calling this function multiple times. By
 * default all activity kinds are disabled for collection.
 *
 * \param kind The kind of activity record to collect
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_NOT_COMPATIBLE if the activity kind cannot be enabled
 * \retval PTI_ERROR_INVALID_KIND if the activity kind is not supported
 */
PTIResult PTIAPI ptiActivityEnable(pti_ActivityKind kind);

/**
 * \brief Disable collection of a specific kind of activity record.
 *
 * Disable collection of a specific kind of activity record. Multiple
 * kinds can be disabled by calling this function multiple times. By
 * default all activity kinds are disabled for collection.
 *
 * \param kind The kind of activity record to stop collecting
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_KIND if the activity kind is not supported
 */
PTIResult PTIAPI ptiActivityDisable(pti_ActivityKind kind);

/**
 * \brief Get the number of activity records that were dropped of
 * insufficient buffer space.
 *
 * Get the number of records that were dropped because of insufficient
 * buffer space.  The dropped count includes records that could not be
 * recorded because PTI did not have activity buffer space available
 * for the record (because the pti_BuffersCallbackRequestFunc
 * callback did not return an empty buffer of sufficient size) and
 * also CDP records that could not be record because the device-size
 * buffer was full (size is controlled by the
 * PTI_ACTIVITY_ATTR_DEVICE_BUFFER_SIZE_CDP attribute). The dropped
 * count maintained for the queue is reset to zero when this function
 * is called.
 *
 * \param context The context, or NULL to get dropped count from global queue
 * \param streamId The stream ID
 * \param dropped The number of records that were dropped since the last call
 * to this function.
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_PARAMETER if \p dropped is NULL
 */
PTIResult PTIAPI ptiActivityGetNumDroppedRecords(RPPcontext context, uint32_t streamId,
                                                       size_t *dropped);

/**
 * \brief Iterate over the activity records in a buffer.
 *
 * This is a helper function to iterate over the activity records in a
 * buffer. A buffer of activity records is typically obtained by
 * receiving a pti_BuffersCallbackCompleteFunc callback.
 *
 * An example of typical usage:
 * \code
 * pti_Activity *record = NULL;
 * PTIResult status = PTI_SUCCESS;
 *   do {
 *      status = cuptiActivityGetNextRecord(buffer, validSize, &record);
 *      if(status == PTI_SUCCESS) {
 *           // Use record here...
 *      }
 *      else if (status == PTI_ERROR_MAX_LIMIT_REACHED)
 *          break;
 *      else {
 *          goto Error;
 *      }
 *    } while (1);
 * \endcode
 *
 * \param buffer The buffer containing activity records
 * \param record Inputs the previous record returned by
 * cuptiActivityGetNextRecord and returns the next activity record
 * from the buffer. If input value is NULL, returns the first activity
 * record in the buffer. Records of kind PTI_ACTIVITY_KIND_CONCURRENT_KERNEL
 * may contain invalid (0) timestamps, indicating that no timing information could
 * be collected for lack of device memory.
 * \param validBufferSizeBytes The number of valid bytes in the buffer.
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_MAX_LIMIT_REACHED if no more records in the buffer
 * \retval PTI_ERROR_INVALID_PARAMETER if \p buffer is NULL.
 */
PTIResult PTIAPI ptiActivityGetNextRecord(uint8_t* buffer, size_t validBufferSizeBytes,
                                                pti_Activity **record);

/**
 * \brief Function type for callback used by PTI to request an empty
 * buffer for storing activity records.
 *
 * This callback function signals the PTI client that an activity
 * buffer is needed by PTI. The activity buffer is used by PTI to
 * store activity records. The callback function can decline the
 * request by setting \p *buffer to NULL. In this case PTI may drop
 * activity records.
 *
 * \param buffer Returns the new buffer. If set to NULL then no buffer
 * is returned.
 * \param size Returns the size of the returned buffer.
 * \param maxNumRecords Returns the maximum number of records that
 * should be placed in the buffer. If 0 then the buffer is filled with
 * as many records as possible. If > 0 the buffer is filled with at
 * most that many records before it is returned.
 */
typedef void (PTIAPI *pti_BuffersCallbackRequestFunc)(
    uint8_t **buffer,
    size_t *size,
    size_t *maxNumRecords);

/**
 * \brief Function type for callback used by PTI to return a buffer
 * of activity records.
 *
 * This callback function returns to the PTI client a buffer
 * containing activity records.  The buffer contains \p validSize
 * bytes of activity records which should be read using
 * cuptiActivityGetNextRecord. The number of dropped records can be
 * read using cuptiActivityGetNumDroppedRecords. After this call PTI
 * relinquished ownership of the buffer and will not use it
 * anymore. The client may return the buffer to PTI using the
 * pti_BuffersCallbackRequestFunc callback.
 * Note: RPP 6.0 onwards, all buffers returned by this callback are
 * global buffers i.e. there is no context/stream specific buffer.
 * User needs to parse the global buffer to extract the context/stream
 * specific activity records.
 *
 * \param context The context this buffer is associated with. If NULL, the
 * buffer is associated with the global activities. This field is deprecated
 * as of RPP 6.0 and will always be NULL.
 * \param streamId The stream id this buffer is associated with.
 * This field is deprecated as of RPP 6.0 and will always be NULL.
 * \param buffer The activity record buffer.
 * \param size The total size of the buffer in bytes as set in
 * pti_BuffersCallbackRequestFunc.
 * \param validSize The number of valid bytes in the buffer.
 */
typedef void (PTIAPI *pti_BuffersCallbackCompleteFunc)(
    RPPcontext context,
    uint32_t streamId,
    uint8_t *buffer,
    size_t size,
    size_t validSize);

/**
 * \brief Registers callback functions with PTI for activity buffer
 * handling.
 *
 * This function registers two callback functions to be used in asynchronous
 * buffer handling. If registered, activity record buffers are handled using
 * asynchronous requested/completed callbacks from PTI.
 *
 * Registering these callbacks prevents the client from using PTI's
 * blocking enqueue/dequeue functions.
 *
 * \param funcBufferRequested callback which is invoked when an empty
 * buffer is requested by PTI
 * \param funcBufferCompleted callback which is invoked when a buffer
 * containing activity records is available from PTI
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_INVALID_PARAMETER if either \p
 * funcBufferRequested or \p funcBufferCompleted is NULL
 */
PTIResult PTIAPI ptiActivityRegisterCallbacks(pti_BuffersCallbackRequestFunc funcBufferRequested,
        pti_BuffersCallbackCompleteFunc funcBufferCompleted);

/**
 * \brief Wait for all activity records are delivered via the
 * completion callback.
 *
 * This function does not return until all activity records associated
 * with all contexts/streams (and the global buffers not associated
 * with any stream) are returned to the PTI client using the
 * callback registered in cuptiActivityRegisterCallbacks. To ensure
 * that all activity records are complete, the requested stream(s), if
 * any, are synchronized.
 *
 * Before calling this function, the buffer handling callback api must
 * be activated by calling cuptiActivityRegisterCallbacks.
 *
 * \param flag The flag can be set to indicate a forced flush. See pti_ActivityFlag
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 * \retval PTI_ERROR_INVALID_OPERATION if not preceeded by a
 * successful call to cuptiActivityRegisterCallbacks
 * \retval PTI_ERROR_UNKNOWN an internal error occurred
 */
PTIResult PTIAPI ptiActivityFlushAll(uint32_t flag);


/**
 * \brief Sets the flush period for the worker thread
 *
 * PTI creates a worker thread to minimize the perturbance for the application created
 * threads. PTI offloads certain operations from the application threads to the worker
 * thread, this includes synchronization of profiling resources between host and device,
 * delivery of the activity buffers to the client using the callback registered in
 * ptiActivityRegisterCallbacks. For performance reasons, CUPTI wakes up the worker
 * thread based on certain heuristics.
 *
 * This API is used to control the flush period of the worker thread. This setting will
 * override the PTI heurtistics. Setting time to zero disables the periodic flush and
 * restores the default behavior.
 *
 * Periodic flush can return only those activity buffers which are full and have all the
 * activity records completed.
 *
 * It's allowed to use the API \ref ptiActivityFlushAll to flush the data on-demand, even
 * when client sets the periodic flush.
 *
 * \param time flush period in usec(defaut 1000us).
 *
 * \retval PTI_SUCCESS
 * \retval PTI_ERROR_NOT_INITIALIZED
 *
 * \see ptiActivityFlushAll
 */
PTIResult PTIAPI ptiActivityFlushPeriod(uint32_t time);

/**
 * \brief Cleanup PTI
 *
 * Explicitly destroys and cleans up all resources associated with PTI
 * in the current process. Any subsequent PTI API call will reinitialize PTI.
 * The PTI client needs to make sure that required RPP synchronization and
 * PTI activity buffer flush is done before calling cuptiFinalize.
 */
PTIResult PTIAPI ptiFinalize(void);

/** @} */ /* END PTI_ACTIVITY_API */

#if defined(__cplusplus)
}
#endif

#endif /*__PTI_ACTIVITY_H__*/
