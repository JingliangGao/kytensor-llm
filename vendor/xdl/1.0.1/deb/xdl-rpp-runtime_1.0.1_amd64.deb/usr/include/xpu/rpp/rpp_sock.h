#ifndef _RPP_SOCK_H_
#define _RPP_SOCK_H_

#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "rpp_osal.h"

//#define RPP_SOCK_PORT        8280

#define RPP_SOCK_DAEMON    0x0
#define RPP_SOCK_SERVER    0x1
#define RPP_SOCK_CLIENT    0x2

#define RPP_REQ_PROBE        0x0
#define RPP_REQ_TERMINATE    0x1

struct identity {
    osal_uid_t uid;
    osal_pid_t pid;
    osal_thread_t tid;
};

struct sock_req_msg {
    uint32_t src; // RPP_SOCK_DAEMON/RPP_SOCK_SERVER/RPP_SOCK_CLIENT
    uint32_t dst; // RPP_SOCK_DAEMON/RPP_SOCK_SERVER/RPP_SOCK_CLIENT
    uint32_t type; // RPP_REQ_PROBE/RPP_REQ_TERMINATE
    struct identity src_id;
};

#endif /* _RPP_SOCK_H_ */


