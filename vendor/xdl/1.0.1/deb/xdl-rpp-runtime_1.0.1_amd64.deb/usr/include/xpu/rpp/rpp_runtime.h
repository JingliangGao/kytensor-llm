/*! \file rpp_runtime.h
	\author Will Jiang <weiwei.jiang@azurengine.com>
	\brief implements an up-to-date RPP Runtime API
	\date 2023/04/27
*/

#ifndef RPP_RUNTIME_H_INCLUDED
#define RPP_RUNTIME_H_INCLUDED

// C includes
#ifdef __cplusplus
#include <cstring>
#include <cstdint>
#else
#include <string.h>
#include <stdint.h>
#endif
#include <limits.h>
//#include "vector_types.h"

// Ocelot includes
#include "rppFatBinary.h"

#ifdef __cplusplus
extern "C" {
#endif

struct rtArray;
struct rtMemcpy3DParams;
struct textureReference;

typedef struct RPPevent_st *rtEvent_t;                       /**< RPP Runtime event */
typedef struct RPPstream_st *rtStream_t;                     /**< RPP Runtime stream */
typedef struct RPPCodec_st *rtCodec_t;
typedef struct RPPdevCodecInfo_st *rtDeviceCodecInfo_t;
typedef struct RPPDevice_context *rtDeviceCtx_t;
typedef struct RPPgraph_st *rtGraph_t;
typedef struct RPPgraphExec_st *rtGraphExec_t;
typedef struct RPPgraphNode_st *rtGraphNode_t;
typedef struct RPPexternalMemory_st *rtExtMem_t;

#define rtHostAllocDefault        0   ///< Default page-locked allocation flag
#define rtHostAllocPortable       1   ///< Pinned memory accessible by all RPP contexts
#define rtHostAllocMapped         2   ///< Map allocation into device space
#define rtHostAllocWriteCombined  4   ///< Write-combined memory

#define rtEventDefault            0   ///< Default event flag, not enable timing
#define rtEventBlockingSync       1   ///< Event uses blocking synchronization
#define rtEventEnableTiming       2   ///< Event enable timing
#define rtEventDisableTiming      rtEventDefault   ///< Event disable timing

#define rtDeviceScheduleAuto      0   ///< Device flag - Automatic scheduling
#define rtDeviceScheduleSpin      1   ///< Device flag - Spin default scheduling
#define rtDeviceScheduleYield     2   ///< Device flag - Yield default scheduling
#define rtDeviceScheduleBlockingSync      4   ///< Device flag - Use blocking synchronization
#define rtDeviceMapHost           8   ///< Device flag - Support mapped pinned allocations
#define rtDeviceLmemResizeToMax   16  ///< Device flag - Keep local memory allocation after launch
#define rtDeviceMask              0x1f ///< Device flags mask

struct uint2 {
	unsigned int x, y;
};

struct uint2 make_uint2(unsigned int x, unsigned int y);

struct uint3 {
	unsigned int x, y, z;
};

struct dim3
{
    unsigned int x, y, z;
#if defined(__cplusplus) && !defined(__RPPBE__)
    dim3(unsigned int x = 1, unsigned int y = 1, unsigned int z = 1) : x(x), y(y), z(z) {}
    dim3(uint3 v) : x(v.x), y(v.y), z(v.z) {}
    operator uint3(void) { uint3 t; t.x = x; t.y = y; t.z = z; return t; }
#endif
};

/*DEVICE_BUILTIN*/
typedef struct dim3 dim3;

enum rtSharedMemConfig {
	rtSharedMemBankSizeDefault = 0,
	rtSharedMemBankSizeFourByte = 1,
	rtSharedMemBankSizeEightByte = 2
};

/**
 * \brief Memory copy direction for ::rtMemcpy and related APIs
 *
 * Values 0–3 are the standard host/device paths. Values 4–6 copy between
 * device DDR and on-chip SRAM. Values 7–8 copy between host and MPU memory.
 * Values 9–10 copy between host and SRAM via PCIe DMA (physical or virtual
 * SRAM from ::rtMallocSram, ::rtMallocVirtSram, or Driver ::rppSramAlloc /
 * ::rppVirtSramAlloc); they map to ::rppMemcpyHtoS and ::rppMemcpyStoH.
 */
enum rtMemcpyKind {
	rtMemcpyHostToHost = 0,
	rtMemcpyHostToDevice = 1,
	rtMemcpyDeviceToHost = 2,
	rtMemcpyDeviceToDevice = 3,
	rtMemcpyDeviceToSram = 4,
	rtMemcpySramToDevice = 5,
	rtMemcpySramToSram = 6,
	rtMemcpyHostToMpu = 7,
	rtMemcpyMpuToHost = 8,
	rtMemcpyHostToSram = 9,
	rtMemcpySramToHost = 10,
	rtMemcpyKindMax
};

enum rtCdmaTransKind {
	rtMemcpyDramToSram = 4, // the value must same as driver api
	rtMemcpySramToDram = 8
};

enum rtChannelFormatKind {
	rtChannelFormatKindSigned = 0,
	rtChannelFormatKindUnsigned = 1,
	rtChannelFormatKindFloat = 2,
	rtChannelFormatKindNone = 3
};

enum rtComputeMode {
	rtComputeModeDefault,
	rtComputeModeExclusive,
	rtComputeModeProhibited
};

enum rtStreamKind {
	rtStreamDefault = 0,
	rtStreamNonBlocking
};

enum rtSemType {
	rtSemCore = (0x1 << 0),
	rtSemSram = (0x1 << 1),
	rtSemPcieDma = (0x1 << 2), /* legacy; prefer rtSemPdmaH2D / rtSemPdmaD2H */
	rtSemUser0 = (0x1 << 3),
	rtSemUser1 = (0x1 << 4),
	rtSemUser2 = (0x1 << 5),
	rtSemUser3 = (0x1 << 6),
	rtSemMpuMsg = (0x1 << 7),
	rtSemPdmaH2D = (0x1 << 8), /* PCIe DMA Read engine (H2D) */
	rtSemPdmaD2H = (0x1 << 9), /* PCIe DMA Write engine (D2H) */
	rtSemCoreDma = (0x1 << 11),
};

enum rtRegRegion {
    rtRegDevDDR = 0,
    rtRegDevCFG,
    rtRegDevMPU,
};

enum rtError
{
  rtSuccess                           =      0,   ///< No errors
  rtErrorInvalidValue                 =      1,   ///< Invalid value
  rtErrorMemoryAllocation             =      2,   ///< Memory allocation error
  rtErrorInitializationError          =      3,   ///< Initialization error
  rtErrorRpprtUnloading               =      4,   ///< RPP runtime unloading
  rtErrorInvalidConfiguration         =      9,   ///< Invalid configuration
  rtErrorInvalidPitchValue            =     12,   ///< Invalid pitch value
  rtErrorInvalidSymbol                =     13,   ///< Invalid symbol
  rtErrorInvalidHostPointer           =     16,   ///< Invalid host pointer
  rtErrorInvalidDevicePointer         =     17,   ///< Invalid device pointer
  rtErrorInvalidTexture               =     18,   ///< Invalid texture
  rtErrorInvalidTextureBinding        =     19,   ///< Invalid texture binding
  rtErrorInvalidChannelDescriptor     =     20,   ///< Invalid channel descriptor
  rtErrorInvalidMemcpyDirection       =     21,   ///< Invalid memcpy direction
  rtErrorAddressOfConstant            =     22,   ///< Address of constant error
  rtErrorTextureFetchFailed           =     23,   ///< Texture fetch failed
  rtErrorTextureNotBound              =     24,   ///< Texture not bound error
  rtErrorSynchronizationError         =     25,   ///< Synchronization error
  rtErrorInvalidFilterSetting         =     26,   ///< Invalid filter setting
  rtErrorInvalidNormSetting           =     27,   ///< Invalid norm setting
  rtErrorMixedDeviceExecution         =     28,   ///< Mixed device execution
  rtErrorNotYetImplemented            =     31,   ///< Function not yet implemented
  rtErrorMemoryValueTooLarge          =     32,   ///< Memory value too large
  rtErrorInsufficientDriver           =     35,   ///< RPP runtime is newer than driver
  rtErrorMissingConfiguration         =     52,   ///< Missing configuration error
  rtErrorPriorLaunchFailure           =     53,   ///< Prior launch failure
  rtErrorInvalidDeviceFunction        =     98,   ///< Invalid device function
  rtErrorNoDevice                     =     100,   ///< No available RPP device
  rtErrorInvalidDevice                =     101,   ///< Invalid device
  rtErrorECCUncorrectable             =     214,   ///< Uncorrectable ECC error detected
  rtErrorStartupFailure               =     127,   ///< Startup failure
  rtErrorMapBufferObjectFailed        =     205,   ///< Map buffer object failed
  rtErrorUnmapBufferObjectFailed      =     206,   ///< Unmap buffer object failed
  rtErrorInvalidResourceHandle        =     400,   ///< Invalid resource handle
  rtErrorNotReady                     =     600,   ///< Not ready error
  rtErrorLaunchOutOfResources         =     701,   ///< Launch out of resources error
  rtErrorLaunchTimeout                =     702,   ///< Launch timeout error
  rtErrorSetOnActiveProcess           =     708,   ///< Set on active process error
  rtErrorLaunchFailure                =     719,   ///< Launch failure
  rtErrorUnknown                      =     999,   ///< Unknown error condition
  rtErrorApiFailureBase               =     10000    ///< API failure base
};

typedef enum rtError rtError_t;

enum rtFuncCache
{
  rtFuncCachePreferNone   = 0,    ///< Default function cache configuration, no preference
  rtFuncCachePreferShared = 1,    ///< Prefer larger shared memory and smaller L1 cache
  rtFuncCachePreferL1     = 2     ///< Prefer larger L1 cache and smaller shared memory
};

enum rtLimit
{
    rtLimitStackSize      = 0x00, //< GPU thread stack size
    rtLimitCdmaBurstMode    = 0x01, /**< GPU CDMA burst mode */
    // rtLimitPrintfFifoSize = 0x01, //< GPU printf FIFO size
    // rtLimitMallocHeapSize = 0x02  //< GPU malloc heap size
};


enum rtPwrMode
{
    rtPwrModeWorking = 0,                 /**< Working mode */
    rtPwrModeLowPower = 1,               /**< Lower power mode, RPP MPU is working, but RPP core is sleeping */
    rtPwrModeStandby = 2,                 /**< Standby mode, RPP MPU/Core all sleeping, OS/Bus driver/ACPI driver need support RTD3 */
    rtPwrModeResume = 3,                  /**< Resume frome standby mode, OS/Bus driver/ACPI driver need support RTD3  */
};

enum rtWorkMode
{
    rtWorkModeDisableDFS = 0,            /**< Disable DFS */
    rtWorkModeBoostDFS = 1,              /**< The dynamic frequency is 1000/800/666/500/400/333/285/250/222/200 MHz */
    rtWorkModeLowFreqDFS = 2,          /**< The dynamic frequency is 800/400/233/200/160/133/114/100/88.8/80 MHz */
};

/**
 * Profile output Modess
 */
enum rtOutputMode {
    rtOutCsv         = 1, /**< Ouput CSV file */
};

/**
 * RPP kernel node parameters
 */
struct rtKernelNodeParams {
    void* func;                     /**< Kernel to launch */
    dim3 gridDim;                   /**< Grid dimensions */
    dim3 blockDim;                  /**< Block dimensions */
    unsigned int sharedMemBytes;    /**< Dynamic shared-memory size per thread block in bytes */
    void **kernelParams;            /**< Array of pointers to individual kernel arguments*/
    void **extra;                   /**< Pointer to kernel arguments in the "extra" format */
};

/**
 * RPP Memset node parameters
 */
struct  rtMemsetParams {
    void *dst;                              /**< Destination device pointer */
    size_t pitch;                           /**< Pitch of destination device pointer. Unused if height is 1 */
    unsigned int value;                     /**< Value to be set */
    unsigned int elementSize;               /**< Size of each element in bytes. Must be 1, 2, or 4. */
    size_t width;                           /**< Width in bytes, of the row */
    size_t height;                          /**< Number of rows */
};

enum rtDFSFreqLevel
{
    rtDFSFreqLevelDefault = 0,    ///< Default value, switch to PLL1, divider=1, if PLL=2GHz, Core's freq=1000MHz, if PLL1=800MHz, Core's freq=400MHz

    rtDFSFreqLevel1,               ///< Switch to PLL1, divider=1, if PLL=2GHz, Core's freq=1000MHz, if PLL1=800MHz, Core's freq=400MHz
    rtDFSFreqLevel2,               ///< Switch to PLL1, divider=2, if PLL=2GHz, Core's freq=666MHz, if PLL1=800MHz, Core's freq=233MHz
    rtDFSFreqLevel3,               ///< Switch to PLL1, divider=3, if PLL=2GHz, Core's freq=500MHz, if PLL1=800MHz, Core's freq=200MHz
    rtDFSFreqLevel4,               ///< Switch to PLL1, divider=4, if PLL=2GHz, Core's freq=400MHz, if PLL1=800MHz, Core's freq=160MHz
    rtDFSFreqLevel5,               ///< Switch to PLL1, divider=5, if PLL=2GHz, Core's freq=333MHz, if PLL1=800MHz, Core's freq=133MHz
    rtDFSFreqLevel6,               ///< Switch to PLL1, divider=6, if PLL=2GHz, Core's freq=285MHz, if PLL1=800MHz, Core's freq=114MHz
    rtDFSFreqLevel7,               ///< Switch to PLL1, divider=7, if PLL=2GHz, Core's freq=250MHz, if PLL1=800MHz, Core's freq=100MHz
    rtDFSFreqLevel8,               ///< Switch to PLL1, divider=8, if PLL=2GHz, Core's freq=222MHz, if PLL1=800MHz, Core's freq=88.8MHz
    rtDFSFreqLevel9,               ///< Switch to PLL1, divider=9, if PLL=2GHz, Core's freq=200MHz, if PLL1=800MHz, Core's freq=80MHz
};

enum rtMpuMsgType
{
    rtDFSFlexibleFreqType0 = 0,
};

/**
 * flexible DFS level params
 * pre_time -- levelA -- hold_time --levelB
 */
typedef struct rtDFSFlexibleFreq_st
{
    rtMpuMsgType type;
    rtDFSFreqLevel levelA;
    rtDFSFreqLevel levelB;
    uint32_t pre_time; // in us
    uint32_t hold_time; // in us
} rtDFSFlexibleFreq_t;


#ifdef _WIN32
#define RPPRT_CB __stdcall
#else
#define RPPRT_CB
#endif

/**
 * RPP host function
 * \param userData Argument value passed to the function
 */
typedef void (RPPRT_CB *rtHostFn_t)(void *userData);


/**
 * RPP host node parameters
 */
struct rtHostNodeParams {
    rtHostFn_t fn;    /**< The function to call when the node executes */
    void* userData; /**< Argument to pass to the function */
};


/**
 * RPP Graph node types exposed to the runtime API.
 *
 * Additional internal types (SetParams, SetFreq, flow control, etc.) exist in the
 * driver API (::RPPgraphNodeType) and are created during instantiate or capture.
 */
enum rtGraphNodeType {
    rtGraphNodeTypeKernel         = 0x00, /**< Device kernel compute node */
    rtGraphNodeTypeMemcpy         = 0x01, /**< CDMA memcpy node */
    rtGraphNodeTypeMemset         = 0x02, /**< Device memset node */
    rtGraphNodeTypeHost           = 0x03, /**< Host callback node */
    rtGraphNodeTypeGraph          = 0x04, /**< Embedded child-graph node */
    rtGraphNodeTypeEmpty          = 0x05, /**< Empty (no-op) dependency placeholder */
    rtGraphNodeTypeWaitEvent      = 0x06, /**< Wait on graph or common event */
    rtGraphNodeTypeEventRecord    = 0x07, /**< Record graph or common event */
    rtGraphNodeTypeExtSemasSignal = 0x08, /**< External semaphore signal node */
    rtGraphNodeTypeExtSemasWait   = 0x09, /**< External semaphore wait node */
    rtGraphNodeTypeMemAlloc       = 0x0a, /**< In-graph device memory allocation (if enabled) */
    rtGraphNodeTypeMemFree        = 0x0b, /**< In-graph device memory free (if enabled) */
    rtGraphNodeTypeCount
};

/**
 * RPP Graph creation flags
 */
enum rtGraphFlags {
    rtGraphDefault = 0x0,      /**< Blocking graph: graph-level head/tail sem serializes SRAM during launch */
    rtGraphNonBlocking = 0x1,  /**< Per-node sem; allows other streams to run work in parallel with the graph */
};


/**
 * Possible stream capture statuses returned by ::rtStreamIsCapturing
 */
enum rtStreamCaptureStatus {
    rtStreamCaptureStatusNone        = 0, /**< Stream is not capturing */
    rtStreamCaptureStatusActive      = 1, /**< Stream is actively capturing */
    rtStreamCaptureStatusInvalidated = 2  /**< Stream is part of a capture sequence that
                                                   has been invalidated, but not terminated */
};

/**
 * Possible modes for stream capture thread interactions. For more details see
 * ::rtStreamBeginCapture
 */
enum rtStreamCaptureMode {
    rtStreamCaptureModeGlobal      = 0,
};


/**
 * external memory handle type
 */
enum rtExternalMemoryHandleType {
    // 0-8 reserved
    rtExternalMemoryHandleTypeVebuf = 9,
};

/**
 * Graph execution resource pool type (used with ::rtGraphInstantiateParams_t).
 */
enum rtGraphResourceType
{
    rtGraphResourcePcieDesc = 0, /**< PCIe descriptor pool */
    rtGraphResourceCdmaDesc = 1, /**< CDMA descriptor pool */
    rtGraphResourceKpara    = 2, /**< Kernel-parameter pool */
    rtGraphResourceScheDesc = 3, /**< Scheduler descriptor pool */
};

/**
 * external memory handle descriptor
 */
struct rtExternalMemoryHandleDesc {
    enum rtExternalMemoryHandleType type;
    uint64_t addr;
    unsigned long long size;
    unsigned int flags; /* reserved for future */
};

/**
 * external memory buffer descriptor
 */
struct rtExternalMemoryBufferDesc {
    unsigned long long offset;
    unsigned long long size;
    unsigned int flags;
};


struct rtExtent {
	size_t width;
	size_t height;
	size_t depth;
};

struct rtDeviceProp
{
    char   name[256];                  /**< ASCII string identifying device */
    size_t totalGlobalMem;             /**< Global memory available on device in bytes */
    size_t sharedMemPerBlock;          /**< Shared memory available per block in bytes */
    int    regsPerBlock;               /**< 32-bit registers available per block */
    int    warpSize;                   /**< Warp size in threads */
    size_t memPitch;                   /**< Maximum pitch in bytes allowed by memory copies */
    int    maxThreadsPerBlock;         /**< Maximum number of threads per block */
    int    maxThreadsDim[3];           /**< Maximum size of each dimension of a block */
    int    maxGridSize[3];             /**< Maximum size of each dimension of a grid */
    int    clockRate;                  /**< Clock frequency in kilohertz */
    size_t totalConstMem;              /**< Constant memory available on device in bytes */
    int    major;                      /**< Major compute capability */
    int    minor;                      /**< Minor compute capability */
    size_t textureAlignment;           /**< Alignment requirement for textures */
    size_t texturePitchAlignment;      /**< Pitch alignment requirement for texture references bound to pitched memory */
    int    deviceOverlap;              /**< Device can concurrently copy memory and execute a kernel. Deprecated. Use instead asyncEngineCount. */
    int    multiProcessorCount;        /**< Number of multiprocessors on device */
    int    kernelExecTimeoutEnabled;   /**< Specified whether there is a run time limit on kernels */
    int    integrated;                 /**< Device is integrated as opposed to discrete */
    int    canMapHostMemory;           /**< Device can map host memory with rtHostAlloc/rtHostGetDevicePointer */
    int    computeMode;                /**< Compute mode (See ::rtComputeMode) */
    int    maxTexture1D;               /**< Maximum 1D texture size */
    int    maxTexture1DLinear;         /**< Maximum size for 1D textures bound to linear memory */
    int    maxTexture2D[2];            /**< Maximum 2D texture dimensions */
    int    maxTexture2DLinear[3];      /**< Maximum dimensions (width, height, pitch) for 2D textures bound to pitched memory */
    int    maxTexture2DGather[2];      /**< Maximum 2D texture dimensions if texture gather operations have to be performed */
    int    maxTexture3D[3];            /**< Maximum 3D texture dimensions */
    int    maxTextureCubemap;          /**< Maximum Cubemap texture dimensions */
    int    maxTexture1DLayered[2];     /**< Maximum 1D layered texture dimensions */
    int    maxTexture2DLayered[3];     /**< Maximum 2D layered texture dimensions */
    int    maxTextureCubemapLayered[2];/**< Maximum Cubemap layered texture dimensions */
    int    maxSurface1D;               /**< Maximum 1D surface size */
    int    maxSurface2D[2];            /**< Maximum 2D surface dimensions */
    int    maxSurface3D[3];            /**< Maximum 3D surface dimensions */
    int    maxSurface1DLayered[2];     /**< Maximum 1D layered surface dimensions */
    int    maxSurface2DLayered[3];     /**< Maximum 2D layered surface dimensions */
    int    maxSurfaceCubemap;          /**< Maximum Cubemap surface dimensions */
    int    maxSurfaceCubemapLayered[2];/**< Maximum Cubemap layered surface dimensions */
    size_t surfaceAlignment;           /**< Alignment requirements for surfaces */
    int    concurrentKernels;          /**< Device can possibly execute multiple kernels concurrently */
    int    ECCEnabled;                 /**< Device has ECC support enabled */
    int    pciBusID;                   /**< PCI bus ID of the device */
    int    pciDeviceID;                /**< PCI device ID of the device */
    int    pciDomainID;                /**< PCI domain ID of the device */
    int    tccDriver;                  /**< 1 if device is a Tesla device using TCC driver, 0 otherwise */
    int    asyncEngineCount;           /**< Number of asynchronous engines */
    int    unifiedAddressing;          /**< Device shares a unified address space with the host */
    int    memoryClockRate;            /**< Peak memory clock frequency in kilohertz */
    int    memoryBusWidth;             /**< Global memory bus width in bits */
    int    l2CacheSize;                /**< Size of L2 cache in bytes */
    int    maxThreadsPerMultiProcessor;/**< Maximum resident threads per multiprocessor */
};

/**
 * RPP device attributes
 */
enum rtDeviceAttr
{
    rtDevAttrMaxThreadsPerBlock             = 1,  /**< Maximum number of threads per block */
    rtDevAttrMaxBlockDimX                   = 2,  /**< Maximum block dimension X */
    rtDevAttrMaxBlockDimY                   = 3,  /**< Maximum block dimension Y */
    rtDevAttrMaxBlockDimZ                   = 4,  /**< Maximum block dimension Z */
    rtDevAttrMaxGridDimX                    = 5,  /**< Maximum grid dimension X */
    rtDevAttrMaxGridDimY                    = 6,  /**< Maximum grid dimension Y */
    rtDevAttrMaxGridDimZ                    = 7,  /**< Maximum grid dimension Z */
    rtDevAttrMaxSharedMemoryPerBlock        = 8,  /**< Maximum shared memory available per block in bytes */
    rtDevAttrWarpSize                       = 10, /**< Warp size in threads */
    rtDevAttrClockRate                      = 13, /**< Peak clock frequency in kilohertz */
    rtDevAttrMultiProcessorCount            = 16, /**< Number of multiprocessors on device */
    rtDevAttrComputeMode                    = 20, /**< Compute mode (See ::rtComputeMode for details) */
    rtDevAttrConcurrentKernels              = 31, /**< Device can possibly execute multiple kernels concurrently */
    rtDevAttrPciBusId                       = 33, /**< PCI bus ID of the device */
    rtDevAttrPciDeviceId                    = 34, /**< PCI device ID of the device */
    rtDevAttrGlobalMemoryBusWidth           = 37, /**< Global memory bus width in bits */
    rtDevAttrMaxThreadsPerMultiProcessor    = 39, /**< Maximum resident threads per multiprocessor */
    rtDevAttrPciDomainId                    = 50, /**< PCI domain ID of the device */
    rtDevAttrMaxSurface3DDepth              = 60, /**< Maximum 3D surface depth */
    rtDevAttrMaxSurface1DLayeredWidth       = 61, /**< Maximum 1D layered surface width */
    rtDevAttrMaxSurface1DLayeredLayers      = 62, /**< Maximum layers in a 1D layered surface */
    rtDevAttrMaxSurface2DLayeredWidth       = 63, /**< Maximum 2D layered surface width */
    rtDevAttrMaxSurface2DLayeredHeight      = 64, /**< Maximum 2D layered surface height */
    rtDevAttrComputeCapabilityMajor         = 75, /**< Major compute capability version number */
    rtDevAttrComputeCapabilityMinor         = 76, /**< Minor compute capability version number */
    rtDevAttrStreamPrioritiesSupport        = 78, /**< Device supports stream priorities */
    rtDevAttrLocalL1CacheSupported          = 80, /**< Device supports caching locals in L1 */
    rtDevAttrMaxSharedMemoryPerMultiprocessor = 81, /**< Maximum shared memory available per multiprocessor in bytes */
    rtDevAttrMaxRegistersPerMultiprocessor  = 82,     /**< Maximum number of 32-bit registers available per multiprocessor */
    rtDevAttrScheClockRate                  = 83, /**< Peak clock frequency of Scheduler in kilohertz */
    rtDevAttrMax
};

struct rtChannelFormatDesc {
	int x;
	int y;
	int z;
	int w;
	enum rtChannelFormatKind f;
};

struct rtFuncAttributes {
   size_t sharedSizeBytes;  ///< Size of shared memory in bytes
   size_t constSizeBytes;   ///< Size of constant memory in bytes
   size_t localSizeBytes;   ///< Size of local memory in bytes
   int maxThreadsPerBlock;  ///< Maximum number of threads per block
   int numRegs;             ///< Number of registers used
   int ptxVersion;          ///< PTX version number eq 21
   int binaryVersion;       ///< binary version
};

struct rtPitchedPtr {
	void *ptr;
	size_t pitch;
	size_t xsize;
	size_t ysize;
};

struct rtPos {
	size_t x;
	size_t y;
	size_t z;
};

struct rtMemcpy3DParams {
	struct rtArray *srcArray;
	struct rtPos srcPos;
	struct rtPitchedPtr srcPtr;
	struct rtArray *dstArray;
	struct rtPos dstPos;
	struct rtPitchedPtr dstPtr;
	struct rtExtent extent;
	enum rtMemcpyKind kind;
};

/**
 * One resource pool entry for ::rtGraphInstantiateWithParams.
 *
 * When \p is_external is false, the runtime allocates the pool for the graphexec.
 * When true, the caller supplies \p daddr and \p size (for example via ::rtGraphResourceAlloc).
 */
struct rtGraphResource_t
{
    bool is_external; /**< false: runtime-owned; true: caller-owned pool at \p daddr */
    rtGraphResourceType type;
    uint64_t daddr;
    size_t size;
};

/**
 * Optional resource pools for ::rtGraphInstantiateWithParams.
 *
 * Pre-sizing \p res_sche_desc reduces automatic extended-execlist splits on large graphs.
 * Use ::rtGraphExecGetParams to read back the layout stored on a graphexec.
 */
struct rtGraphInstantiateParams_t
{
    uint64_t flags; /**< Instantiate flags (driver ::RPPgraphInstantiate_flags in low-level API) */
    struct rtGraphResource_t res_pcie_desc;
    struct rtGraphResource_t res_cdma_desc;
    struct rtGraphResource_t res_kpara;
    struct rtGraphResource_t res_sche_desc;
};

enum rtTextureAddressMode
{
  rtAddressModeWrap,
  rtAddressModeClamp
};

enum rtTextureFilterMode
{
  rtFilterModePoint,
  rtFilterModeLinear
};

enum rtTextureReadMode
{
  rtReadModeElementType,
  rtReadModeNormalizedFloat
};

#if 1 // TODO: willjiang, 20190422
struct textureReference {
  int normalized;
  enum rtTextureFilterMode filterMode;
  enum rtTextureAddressMode addressMode[3];
  struct rtChannelFormatDesc channelDesc;
  int __rtReserved[16];
};
#endif

typedef struct RPPuuid_st rtUUID_t;

#ifdef _WIN32
#define RPP_CB __stdcall
#else
#define RPP_CB
#endif

typedef void (RPP_CB *rtStreamCallback_t)(rtStream_t hStream, rtError_t status, void *userData);

/*
 * Function        : Select a load image from the __rtFat binary
 *                   that will run on the specified GPU.
 * Parameters      : binary  (I) Fat binary
 *                   policy  (I) Parameter influencing the selection process in case no
 *                               fully matching cubin can be found, but instead a choice can
 *                               be made between ptx compilation or selection of a
 *                               cubin for a less capable GPU.
 *                   gpuName (I) Name of target GPU
 *                   cubin   (O) Returned cubin text string, or NULL when
 *                               no matching cubin for the specified gpu
 *                               could be found.
 *                   dbgInfo (O) If this parameter is not NULL upon entry, then
 *                               the name of a file containing debug information
 *                               on the returned cubin will be returned, or NULL
 *                               will be returned when cubin or such debug info
 *                               cannot be found.
 */
void fatGetCubinForGpuWithPolicy( __rtFatRppBinary *binary, __rtFatCompilationPolicy policy, char* gpuName, char* *cubin, char* *dbgInfoFile );

#define fatGetCubinForGpu(binary,gpuName,cubin,dbgInfoFile) \
          fatGetCubinForGpuWithPolicy(binary,__rtFatAvoidPTX,gpuName,cubin,dbgInfoFile)

/*
 * Function        : Check if a binary will be JITed for the specified target architecture
 * Parameters      : binary  (I) Fat binary
 *                   policy  (I) Compilation policy, as described by fatGetCubinForGpuWithPolicy
 *                   gpuName (I) Name of target GPU
 *                   ptx     (O) PTX string to be JITed
 * Function Result : True if the given binary will be JITed; otherwise, False
 */
unsigned char fatCheckJitForGpuWithPolicy( __rtFatRppBinary *binary, __rtFatCompilationPolicy policy, char* gpuName, char* *ptx );

#define fatCheckJitForGpu(binary,gpuName,ptx) \
          fatCheckJitForGpuWithPolicy(binary,__rtFatAvoidPTX,gpuName,ptx)

/*
 * Function        : Free information previously obtained via function fatGetCubinForGpu.
 * Parameters      : cubin   (I) Cubin text string to free
 *                   dbgInfo (I) Debug info filename to free, or NULL
 */
void fatFreeCubin( char* cubin, char* dbgInfoFile );


/*******************************************************************************
*                                                                              *
*                                                                              *
*                                                                              *
*******************************************************************************/

extern void** __rtRegisterFatBinary(void *fatCubin);
extern void __rtRegisterFatBinaryEnd(void **fatCubinHandle);
extern void __rtUnregisterFatBinary(void **fatCubinHandle);

extern void __rtRegisterFunction(
        void **fatCubinHandle,
  const char *hostFun,
        char *deviceFun,
  const char *deviceName,
        int thread_limit,
        struct uint3 *tid,
        struct uint3 *bid,
        struct dim3 *bDim,
        struct dim3 *gDim,
        int *wSize
);

/*******************************************************************************
*                                                                              *
*                                                                              *
*                                                                              *
*******************************************************************************/
/**
 * \defgroup RPP_DEVICE Device Management
 *
 * ___MANBRIEF___ device management functions of the RPP runtime API
 * (___CURRENT_FILE___) ___ENDMANBRIEF___
 *
 * This section describes the device management functions of the RPP runtime
 * application programming interface.
 *
 * @{
 */

/**
 * \brief Returns the number of compute-capable devices
 *
 * Returns in \p *count the number of devices are available for execution.
 *
 * \param count - Returns the number of devices
 *
 * \return
 * ::rtSuccess
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtGetDevice, ::rtSetDevice, ::rtGetDeviceProperties,
 * ::rtChooseDevice,
 * ::rppDeviceGetCount
 */
extern rtError_t rtGetDeviceCount(int *count);


/**
 * \brief Returns information about the compute-device
 *
 * Returns in \p *prop the properties of device \p dev.
 *
 * \param prop   - Properties for the specified device
 * \param device - Device number to get properties for
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidDevice
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtGetDeviceCount, ::rtGetDevice, ::rtSetDevice, ::rtChooseDevice,
 * ::rtDeviceGetAttribute,
 * ::rppDeviceGetAttribute,
 * ::rppDeviceGetName
 */
extern rtError_t rtGetDeviceProperties(struct rtDeviceProp *prop, int device);

/**
 * \brief Select compute-device which best matches criteria
 *
 * Returns in \p *device the device which has properties that best match
 * \p *prop.
 *
 * \param device - Device with best match
 * \param prop   - Desired device properties
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtGetDeviceCount, ::rtGetDevice, ::rtSetDevice,
 * ::rtGetDeviceProperties
 */
extern rtError_t rtChooseDevice(int *device, const struct rtDeviceProp *prop);


/**
 * \brief Set device to be used for GPU executions
 *
 * Sets \p device as the current device for the calling host thread.
 * Valid device id's are 0 to (::rtGetDeviceCount() - 1).
 *
 * Any device memory subsequently allocated from this host thread
 * using ::rtMalloc(), ::rtMallocPitch() or ::rtMallocArray()
 * will be physically resident on \p device.  Any host memory allocated
 * from this host thread using ::rtMallocHost() or ::rtHostAlloc()
 * or ::rtHostRegister() will have its lifetime associated  with
 * \p device.  Any streams or events created from this host thread will
 * be associated with \p device.  Any kernels launched from this host
 * thread using the <<<>>> operator or ::rtLaunchKernel() will be executed
 * on \p device.
 *
 * This call may be made from any host thread, to any device, and at
 * any time.  This function will do no synchronization with the previous
 * or new device, and should be considered a very low overhead call.
 *
 * \param device - Device on which the active host thread should execute the
 * device code.
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidDevice,
 * ::rtErrorDeviceAlreadyInUse
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtGetDeviceCount, ::rtGetDevice, ::rtGetDeviceProperties,
 * ::rtChooseDevice,
 * ::rppCtxSetCurrent
 */
extern rtError_t rtSetDevice(int device);


/**
 * \brief Returns which device is currently being used
 *
 * Returns in \p *device the current device for the calling host thread.
 *
 * \param device - Returns the device on which the active host thread
 * executes the device code.
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtGetDeviceCount, ::rtSetDevice, ::rtGetDeviceProperties,
 * ::rtChooseDevice,
 * ::rppCtxGetCurrent
 */
extern rtError_t rtGetDevice(int *device);

#if 0 // willjiang, not support yet, 20230508

/**
 * \brief Set a list of devices that can be used for RPP
 *
 * Sets a list of devices for RPP execution in priority order using
 * \p device_arr. The parameter \p len specifies the number of elements in the
 * list.  RPP will try devices from the list sequentially until it finds one
 * that works.  If this function is not called, or if it is called with a \p len
 * of 0, then RPP will go back to its default behavior of trying devices
 * sequentially from a default list containing all of the available RPP
 * devices in the system. If a specified device ID in the list does not exist,
 * this function will return ::rtErrorInvalidDevice. If \p len is not 0 and
 * \p device_arr is NULL or if \p len exceeds the number of devices in
 * the system, then ::rtErrorInvalidValue is returned.
 *
 * \param device_arr - List of devices to try
 * \param len        - Number of devices in specified list
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidDevice
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtGetDeviceCount, ::rtSetDevice, ::rtGetDeviceProperties,
 * ::rtSetDeviceFlags,
 * ::rtChooseDevice
 */
extern rtError_t rtSetValidDevices(int *device_arr, int len);

#endif

/**
 * \brief Sets flags to be used for device executions
 *
 * Records \p flags as the flags to use when initializing the current
 * device.  If no device has been made current to the calling thread,
 * then \p flags will be applied to the initialization of any device
 * initialized by the calling host thread, unless that device has had
 * its initialization flags set explicitly by this or any host thread.
 *
 * \param flags - Parameters for device operation
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorSetOnActiveProcess
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtGetDeviceFlags, ::rtGetDeviceCount, ::rtGetDevice, ::rtGetDeviceProperties,
 * ::rtSetDevice, ::rtSetValidDevices,
 * ::rtChooseDevice,
 * ::rppDevicePrimaryCtxSetFlags
 */
extern rtError_t rtSetDeviceFlags(unsigned int flags );

extern rtError_t rtGetDeviceFlags(unsigned int *flags );


/**
 * \brief Returns information about the device
 *
 * Returns in \p *value the integer value of the attribute \p attr on device
 * \p device.
 *
 * \param value  - Returned device attribute value
 * \param attr   - Device attribute to query
 * \param device - Device number to query
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidDevice,
 * ::rtErrorInvalidValue
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtGetDeviceCount, ::rtGetDevice, ::rtSetDevice, ::rtChooseDevice,
 * ::rtGetDeviceProperties,
 * ::rppDeviceGetAttribute
 */
extern rtError_t rtDeviceGetAttribute( int* value, enum rtDeviceAttr attrbute,
	int device );

extern rtError_t rtDeviceGetPCIBusId(char *pciBusId, int len, int device);
extern rtError_t rtDeviceGetByPCIBusId(int *device, const char *pciBusId);
#if 0 // willjiang, not support yet, 20230508
extern rtError_t rtDeviceGetCodecInfo(rtDeviceCodecInfo_t codecInfo, int device);
extern rtError_t rtDeviceRegRead(rtDeviceCtx_t dev_ctx, uint32_t reg_addr, uint32_t *data);
extern rtError_t rtDeviceRegWrite(rtDeviceCtx_t dev_ctx, uint32_t reg_addr, uint32_t data);
#endif

/*******************************************************************************
*                                                                              *
*                                                                              *
*                                                                              *
*******************************************************************************/


/**
 * \brief Destroy all allocations and reset all state on the current device
 * in the current process.
 *
 * Explicitly destroys and cleans up all resources associated with the current
 * device in the current process.  Any subsequent API call to this device will
 * reinitialize the device.
 *
 * Note that this function will reset the device immediately.  It is the caller's
 * responsibility to ensure that the device is not being accessed by any
 * other host threads from the process when this function is called.
 *
 * \return
 * ::rtSuccess
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtDeviceSynchronize
 */
extern rtError_t rtDeviceReset(void);

/**
 * \brief Shut down the RPP Runtime instance for this process.
 *
 * This releases the Runtime singleton and deinitializes the underlying Driver
 * API. The caller must ensure that no other host thread is executing a Runtime
 * API call and that no Runtime resource remains in use. Calling this function
 * more than once is safe.
 *
 * A subsequent Runtime API call creates a new Runtime instance and
 * reinitializes the Driver API.
 *
 * \return
 * ::rtSuccess on success, ::rtErrorUnknown if Driver API shutdown fails.
 */
extern rtError_t rtRuntimeShutdown(void);


/**
 * \brief Wait for compute device to finish
 *
 * Blocks until the device has completed all preceding requested tasks.
 * ::rtDeviceSynchronize() returns an error if one of the preceding tasks
 * has failed. If the ::rtDeviceScheduleBlockingSync flag was set for
 * this device, the host thread will block until the device has finished
 * its work.
 *
 * \return
 * ::rtSuccess
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtDeviceReset,
 * ::rppCtxSynchronize
 */
extern rtError_t rtDeviceSynchronize(void);


/**
 * \brief Set resource limits
 *
 * Setting \p limit to \p value is a request by the application to update
 * the current limit maintained by the device.  The driver is free to
 * modify the requested value to meet h/w requirements (this could be
 * clamping to minimum or maximum values, rounding up to nearest element
 * size, etc).  The application can use ::rtDeviceGetLimit() to find out
 * exactly what the limit has been set to.
 *
 * \param limit - Limit to set
 * \param value - Size of limit
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorUnsupportedLimit,
 * ::rtErrorInvalidValue,
 * ::rtErrorMemoryAllocation
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtDeviceGetLimit,
 * ::rppCtxSetLimit
 */
extern rtError_t rtDeviceSetLimit(enum rtLimit limit, size_t value);


/**
 * \brief Returns resource limits
 *
 * Returns in \p *pValue the current size of \p limit.
 *
 * \param limit  - Limit to query
 * \param pValue - Returned size of the limit
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorUnsupportedLimit,
 * ::rtErrorInvalidValue
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtDeviceSetLimit,
 * ::rppCtxGetLimit
 */
extern rtError_t rtDeviceGetLimit(size_t *pValue, enum rtLimit limit);



/**
 * \brief Set power mode
 *
 * Setting \p pwrmode to device.  The application can use ::rtDeviceGetPwrMode() to find out
 * exactly what the pwrmode has been set to.
 *
 * \param pwrmode - Power mode to set
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtDeviceGetPwrMode,
 */
extern rtError_t rtDeviceSetPwrMode(enum rtPwrMode pwrmode);


/**
 * \brief Returns power mode
 *
 * Returns in \p *pwrmode of the device power mode.
 *
 * \param pwrmode - Returned the power mode
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtDeviceSetPwrMode,
 */
extern rtError_t rtDeviceGetPwrMode(enum rtPwrMode *pwrmode);


/**
 * \brief Set work mode
 *
 * Setting \p workmode to device.  The application can use ::rtDeviceGetworkMode() to find out
 * exactly what the workmode has been set to.
 *
 * \param workmode - work mode to set
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtDeviceGetWorkMode,
 */
extern rtError_t rtDeviceSetWorkMode(enum rtWorkMode workmode);


/**
 * \brief Returns work mode
 *
 * Returns in \p *workmode of the device work mode.
 *
 * \param workmode - Returned the work mode
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtDeviceSetWorkMode,
 */
extern rtError_t rtDeviceGetWorkMode(enum rtWorkMode *workmode);

/**
 * \brief Write register��
 *
 * Write \p value to global address \p addr.
 *
 * \param addr - global address to be write
 * \param value - the write value
 *
 * \note some registers can't write in low power mode, and still returns success, it can read back for sure
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtDeviceRegRead32,
 */
extern rtError_t rtDeviceRegWrite32(uint64_t addr, uint32_t value);


/**
 * \brief Read register
 *
 * Read \p value from global address \p addr.
 *
 * \param addr - global address to be write
 * \param value - return value
 *
 * \note some registers can't access in low power mode, and still returns success, it can read back for sure
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtDeviceRegWrite32,
 */
extern rtError_t rtDeviceRegRead32(uint64_t addr, uint32_t *value);

/**
 * \brief Returns the preferred cache configuration for the current device.
 *
 * On devices where the L1 cache and shared memory use the same hardware
 * resources, this returns through \p pCacheConfig the preferred cache
 * configuration for the current device. This is only a preference. The
 * runtime will use the requested configuration if possible, but it is free to
 * choose a different configuration if required to execute functions.
 *
 * This will return a \p pCacheConfig of ::rtFuncCachePreferNone on devices
 * where the size of the L1 cache and shared memory are fixed.
 *
 *
 * \param pCacheConfig - Returned cache configuration
 *
 * \return
 * ::rtSuccess
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa rtDeviceSetCacheConfig,
 * \ref ::rtFuncSetCacheConfig(const void*, enum rtFuncCache) "rtFuncSetCacheConfig (C API)",
 * \ref ::rtFuncSetCacheConfig(T*, enum rtFuncCache) "rtFuncSetCacheConfig (C++ API)",
 * ::rppCtxGetCacheConfig
 */
extern rtError_t rtDeviceGetCacheConfig(enum rtFuncCache *pCacheConfig);


/**
 * \brief Sets the preferred cache configuration for the current device.
 *
 * On devices where the L1 cache and shared memory use the same hardware
 * resources, this sets through \p cacheConfig the preferred cache
 * configuration for the current device. This is only a preference. The
 * runtime will use the requested configuration if possible, but it is free to
 * choose a different configuration if required to execute the function. Any
 * function preference set via
 * \ref ::rtFuncSetCacheConfig(const void*, enum rtFuncCache) "rtFuncSetCacheConfig (C API)"
 * or
 * \ref ::rtFuncSetCacheConfig(T*, enum rtFuncCache) "rtFuncSetCacheConfig (C++ API)"
 * will be preferred over this device-wide setting. Setting the device-wide
 * cache configuration to ::rtFuncCachePreferNone will cause subsequent
 * kernel launches to prefer to not change the cache configuration unless
 * required to launch the kernel.
 *
 * This setting does nothing on devices where the size of the L1 cache and
 * shared memory are fixed.
 *
 * Launching a kernel with a different preference than the most recent
 * preference setting may insert a device-side synchronization point.
 *
 * \param cacheConfig - Requested cache configuration
 *
 * \return
 * ::rtSuccess
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtDeviceGetCacheConfig,
 * \ref ::rtFuncSetCacheConfig(const void*, enum rtFuncCache) "rtFuncSetCacheConfig (C API)",
 * \ref ::rtFuncSetCacheConfig(T*, enum rtFuncCache) "rtFuncSetCacheConfig (C++ API)",
 * ::rppCtxSetCacheConfig
 */
extern rtError_t rtDeviceSetCacheConfig(enum rtFuncCache cacheConfig);


extern rtError_t rtDFSSetFreqAsync(enum rtDFSFreqLevel level, rtStream_t stream);

extern rtError_t rtDFSSetFlexibleFreqAsync(rtDFSFlexibleFreq_t freq, rtStream_t stream);


/** @} */ /* END RPP_DEVICE */

/*******************************************************************************
*                                                                              *
*                                                                              *
*                                                                              *
*******************************************************************************/

extern rtError_t rtGetChannelDesc(struct rtChannelFormatDesc *desc,
	const struct rtArray *array);
extern struct rtChannelFormatDesc rtCreateChannelDesc(int x, int y, int z,
	int w, enum rtChannelFormatKind f);

/*******************************************************************************
*                                                                              *
*                                                                              *
*                                                                              *
*******************************************************************************/
/**
 * \defgroup RPP_ERROR Error Handling
 *
 * ___MANBRIEF___ error handling functions of the RPP runtime API
 * (___CURRENT_FILE___) ___ENDMANBRIEF___
 *
 * This section describes the error handling functions of the RPP runtime
 * application programming interface.
 *
 * @{
 */


/**
 * \brief Returns the last error from a runtime call
 *
 * Returns the last error that has been produced by any of the runtime calls
 * in the same host thread and resets it to ::rtSuccess.
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorMissingConfiguration,
 * ::rtErrorMemoryAllocation,
 * ::rtErrorInitializationError,
 * ::rtErrorLaunchFailure,
 * ::rtErrorLaunchTimeout,
 * ::rtErrorLaunchOutOfResources,
 * ::rtErrorInvalidDeviceFunction,
 * ::rtErrorInvalidConfiguration,
 * ::rtErrorInvalidDevice,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidPitchValue,
 * ::rtErrorInvalidSymbol,
 * ::rtErrorUnmapBufferObjectFailed,
 * ::rtErrorInvalidDevicePointer,
 * ::rtErrorInvalidTexture,
 * ::rtErrorInvalidTextureBinding,
 * ::rtErrorInvalidChannelDescriptor,
 * ::rtErrorInvalidMemcpyDirection,
 * ::rtErrorInvalidFilterSetting,
 * ::rtErrorInvalidNormSetting,
 * ::rtErrorUnknown,
 * ::rtErrorInvalidResourceHandle,
 * ::rtErrorInsufficientDriver,
 * ::rtErrorNoDevice,
 * ::rtErrorSetOnActiveProcess,
 * ::rtErrorStartupFailure,
 * ::rtErrorInvalidPtx,
 * ::rtErrorNoKernelImageForDevice,
 * ::rtErrorJitCompilerNotFound
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtPeekAtLastError, ::rtGetErrorName, ::rtGetErrorString, ::rtError
 */
extern rtError_t rtGetLastError(void);


/**
 * \brief Returns the last error from a runtime call
 *
 * Returns the last error that has been produced by any of the runtime calls
 * in the same host thread. Note that this call does not reset the error to
 * ::rtSuccess like ::rtGetLastError().
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorMissingConfiguration,
 * ::rtErrorMemoryAllocation,
 * ::rtErrorInitializationError,
 * ::rtErrorLaunchFailure,
 * ::rtErrorLaunchTimeout,
 * ::rtErrorLaunchOutOfResources,
 * ::rtErrorInvalidDeviceFunction,
 * ::rtErrorInvalidConfiguration,
 * ::rtErrorInvalidDevice,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidPitchValue,
 * ::rtErrorInvalidSymbol,
 * ::rtErrorUnmapBufferObjectFailed,
 * ::rtErrorInvalidDevicePointer,
 * ::rtErrorInvalidTexture,
 * ::rtErrorInvalidTextureBinding,
 * ::rtErrorInvalidChannelDescriptor,
 * ::rtErrorInvalidMemcpyDirection,
 * ::rtErrorInvalidFilterSetting,
 * ::rtErrorInvalidNormSetting,
 * ::rtErrorUnknown,
 * ::rtErrorInvalidResourceHandle,
 * ::rtErrorInsufficientDriver,
 * ::rtErrorNoDevice,
 * ::rtErrorSetOnActiveProcess,
 * ::rtErrorStartupFailure,
 * ::rtErrorInvalidPtx,
 * ::rtErrorNoKernelImageForDevice,
 * ::rtErrorJitCompilerNotFound
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtGetLastError, ::rtGetErrorName, ::rtGetErrorString, ::rtError
 */
extern rtError_t rtPeekAtLastError();


/**
 * \brief Returns the description string for an error code
 *
 * Returns the description string for an error code.  If the error
 * code is not recognized, "unrecognized error code" is returned.
 *
 * \param error - Error code to convert to string
 *
 * \return
 * \p char* pointer to a NULL-terminated string
 *
 * \sa ::rtGetErrorName, ::rtGetLastError, ::rtPeekAtLastError, ::rtError,
 * ::rppGetErrorString
 */
extern const char* rtGetErrorString(rtError_t error);
extern const char* rtGetErrorName(rtError_t error);

/** @} */ /* END RPP_ERROR */


/*******************************************************************************
*                                                                              *
*                                                                              *
*                                                                              *
*******************************************************************************/

/**
 * \defgroup RPP_STREAM Stream Management
 *
 * ___MANBRIEF___ stream management functions of the RPP runtime API
 * (___CURRENT_FILE___) ___ENDMANBRIEF___
 *
 * This section describes the stream management functions of the RPP runtime
 * application programming interface.
 *
 * @{
 */

/**
 * \brief Create an asynchronous stream
 *
 * Creates a new asynchronous stream.
 *
 * \param pStream - Pointer to new stream identifier
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtStreamCreateWithPriority,
 * ::rtStreamCreateWithFlags,
 * ::rtStreamGetPriority,
 * ::rtStreamGetFlags,
 * ::rtStreamQuery,
 * ::rtStreamSynchronize,
 * ::rtStreamWaitEvent,
 * ::rtStreamAddCallback,
 * ::rtStreamDestroy,
 * ::rppStreamCreate
 */
extern rtError_t rtStreamCreate(rtStream_t *pStream);

/**
 * \brief Create an asynchronous stream with flag
 *
 * Creates a new asynchronous stream with flag.
 *
 * \param pStream - Pointer to new stream identifier
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtStreamCreateWithPriority,
 * ::rtStreamCreateWithFlags,
 * ::rtStreamGetPriority,
 * ::rtStreamGetFlags,
 * ::rtStreamQuery,
 * ::rtStreamSynchronize,
 * ::rtStreamWaitEvent,
 * ::rtStreamAddCallback,
 * ::rtStreamDestroy,
 * ::rppStreamCreate
 */
extern rtError_t rtStreamCreateWithFlags(rtStream_t *pStream, unsigned int flags);

/**
 * \brief Destroys and cleans up an asynchronous stream
 *
 * Destroys and cleans up the asynchronous stream specified by \p stream.
 *
 * In case the device is still doing work in the stream \p stream
 * when ::rtStreamDestroy() is called, the function will return immediately
 * and the resources associated with \p stream will be released automatically
 * once the device has completed all work in \p stream.
 *
 * \param stream - Stream identifier
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidResourceHandle
 * \note_null_stream
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtStreamCreate,
 * ::rtStreamCreateWithFlags,
 * ::rtStreamQuery,
 * ::rtStreamWaitEvent,
 * ::rtStreamSynchronize,
 * ::rtStreamAddCallback,
 * ::rppStreamDestroy
 */
extern rtError_t rtStreamDestroy(rtStream_t stream);



/**
 * \brief Make a compute stream wait on an event
 *
 * Makes all future work submitted to \p stream wait for all work captured in
 * \p event.  See ::rtEventRecord() for details on what is captured by an event.
 * The synchronization will be performed efficiently on the device when applicable.
 * \p event may be from a different device than \p stream.
 *
 * \param stream - Stream to wait
 * \param event  - Event to wait on
 * \param flags  - Parameters for the operation (must be 0)
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidResourceHandle
 * \note_null_stream
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtStreamCreate, ::rtStreamCreateWithFlags, ::rtStreamQuery, ::rtStreamSynchronize, ::rtStreamAddCallback, ::rtStreamDestroy,
 * ::rppStreamWaitEvent
 */
extern rtError_t rtStreamWaitEvent(rtStream_t stream, rtEvent_t event, unsigned int flags);

/**
 * \brief Wait on a semaphore in a stream
 *
 * Enqueues a semaphore wait operation into \p stream.
 *
 * \param sem    - Semaphore identifier or bitmask, supports bitwise OR of values in ::rtSemType
 * \param stream - Stream identifier
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidResourceHandle
 * \note_null_stream
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtSemPost, ::rppSemWait
 */
extern rtError_t rtSemWait(uint32_t sem, rtStream_t stream);

/**
 * \brief Post a semaphore in a stream
 *
 * Enqueues a semaphore post operation into \p stream.
 *
 * \param sem    - Semaphore identifier or bitmask, supports bitwise OR of values in ::rtSemType
 * \param stream - Stream identifier
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidResourceHandle
 * \note_null_stream
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtSemWait, ::rppSemPost
 */
extern rtError_t rtSemPost(uint32_t sem, rtStream_t stream);


/**
 * \brief Waits for stream tasks to complete
 *
 * Blocks until \p stream has completed all operations. If the
 * ::rtDeviceScheduleBlockingSync flag was set for this device,
 * the host thread will block until the stream is finished with
 * all of its tasks.
 *
 * \param stream - Stream identifier
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidResourceHandle
 * \note_null_stream
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtStreamCreate, ::rtStreamCreateWithFlags, ::rtStreamQuery, ::rtStreamWaitEvent, ::rtStreamAddCallback, ::rtStreamDestroy,
 * ::rppStreamSynchronize
 */
extern rtError_t rtStreamSynchronize(rtStream_t stream);


/**
 * \brief Queries an asynchronous stream for completion status
 *
 * Returns ::rtSuccess if all operations in \p stream have
 * completed, or ::rtErrorNotReady if not.
 *
 * For the purposes of Unified Memory, a return value of ::rtSuccess
 * is equivalent to having called ::rtStreamSynchronize().
 *
 * \param stream - Stream identifier
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorNotReady,
 * ::rtErrorInvalidResourceHandle
 * \note_null_stream
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtStreamCreate, ::rtStreamCreateWithFlags, ::rtStreamWaitEvent, ::rtStreamSynchronize, ::rtStreamAddCallback, ::rtStreamDestroy,
 * ::rppStreamQuery
 */
extern rtError_t rtStreamQuery(rtStream_t stream);

#if 0 // willjiang, not support yet, 20230508
/**
 * \brief Add a callback to a compute stream
 *
 * \note This function is slated for eventual deprecation and removal. If
 * you do not require the callback to execute in case of a device error,
 * consider using ::rtLaunchHostFunc. Additionally, this function is not
 * supported with ::rtStreamBeginCapture and ::rtStreamEndCapture, unlike
 * ::rtLaunchHostFunc.
 *
 * Adds a callback to be called on the host after all currently enqueued
 * items in the stream have completed.  For each
 * rtStreamAddCallback call, a callback will be executed exactly once.
 * The callback will block later work in the stream until it is finished.
 *
 * The callback may be passed ::rtSuccess or an error code.  In the event
 * of a device error, all subsequently executed callbacks will receive an
 * appropriate ::rtError_t.
 *
 * Callbacks must not make any RPP API calls.  Attempting to use RPP APIs
 * may result in ::rtErrorNotPermitted.  Callbacks must not perform any
 * synchronization that may depend on outstanding device work or other callbacks
 * that are not mandated to run earlier.  Callbacks without a mandated order
 * (in independent streams) execute in undefined order and may be serialized.
 *
 * For the purposes of Unified Memory, callback execution makes a number of
 * guarantees:
 * <ul>
 *   <li>The callback stream is considered idle for the duration of the
 *   callback.  Thus, for example, a callback may always use memory attached
 *   to the callback stream.</li>
 *   <li>The start of execution of a callback has the same effect as
 *   synchronizing an event recorded in the same stream immediately prior to
 *   the callback.  It thus synchronizes streams which have been "joined"
 *   prior to the callback.</li>
 *   <li>Adding device work to any stream does not have the effect of making
 *   the stream active until all preceding callbacks have executed.  Thus, for
 *   example, a callback might use global attached memory even if work has
 *   been added to another stream, if it has been properly ordered with an
 *   event.</li>
 *   <li>Completion of a callback does not cause a stream to become
 *   active except as described above.  The callback stream will remain idle
 *   if no device work follows the callback, and will remain idle across
 *   consecutive callbacks without device work in between.  Thus, for example,
 *   stream synchronization can be done by signaling from a callback at the
 *   end of the stream.</li>
 * </ul>
 *
 * \param stream   - Stream to add callback to
 * \param callback - The function to call once preceding stream operations are complete
 * \param userData - User specified data to be passed to the callback function
 * \param flags    - Reserved for future use, must be 0
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidResourceHandle,
 * ::rtErrorInvalidValue,
 * ::rtErrorNotSupported
 * \note_null_stream
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtStreamCreate, ::rtStreamCreateWithFlags, ::rtStreamQuery, ::rtStreamSynchronize, ::rtStreamWaitEvent, ::rtStreamDestroy, ::rtMallocManaged, ::rtStreamAttachMemAsync,
 * ::rtLaunchHostFunc, ::rppStreamAddCallback
 */
extern rtError_t rtStreamAddCallback(rtStream_t stream, rtStreamCallback_t callback, void* userData, unsigned int flags);
#endif

/**
 * \brief Begins graph capture on a stream
 *
 * Begin graph capture on \p stream. When a stream is in capture mode, all operations
 * pushed into the stream will not be executed, but will instead be captured into
 * a graph, which will be returned via ::rtStreamEndCapture. Capture may not be initiated
 * if \p stream is ::rtStreamLegacy. Capture must be ended on the same stream in which
 * it was initiated, and it may only be initiated if the stream is not already in capture
 * mode. The capture mode may be queried via ::rtStreamIsCapturing. A unique id
 * representing the capture sequence may be queried via ::rtStreamGetCaptureInfo.
 *
 * If \p mode is not ::rtStreamCaptureModeRelaxed, ::rtStreamEndCapture must be
 * called on this stream from the same thread.
 *
 *
 * \param stream - Stream in which to initiate capture
 * \param mode    - Controls the interaction of this capture sequence with other API
 *                  calls that are potentially unsafe. For more details see
 *                  ::rtThreadExchangeStreamCaptureMode.
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \notefnerr
 *
 * \sa
 * ::rtStreamCreate,
 * ::rtStreamIsCapturing,
 * ::rtStreamEndCapture,
 * ::rtThreadExchangeStreamCaptureMode
 */
extern rtError_t rtStreamBeginCapture(rtStream_t stream, enum rtStreamCaptureMode mode);


/**
 * \brief Ends capture on a stream, returning the captured graph
 *
 * End capture on \p stream, returning the captured graph via \p pGraph.
 * Capture must have been initiated on \p stream via a call to ::rtStreamBeginCapture.
 * If capture was invalidated, due to a violation of the rules of stream capture, then
 * a NULL graph will be returned.
 *
 * If the \p mode argument to ::rtStreamBeginCapture was not
 * ::rtStreamCaptureModeRelaxed, this call must be from the same thread as
 * ::rtStreamBeginCapture.
 *
 * \param stream - Stream to query
 * \param pGraph - The captured graph
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorStreamCaptureWrongThread
 * \notefnerr
 *
 * \sa
 * ::rtStreamCreate,
 * ::rtStreamBeginCapture,
 * ::rtStreamIsCapturing
 */
extern rtError_t rtStreamEndCapture(rtStream_t stream, rtGraph_t *pGraph);


/**
 * \brief Returns a stream's capture status
 *
 * Return the capture status of \p stream via \p pCaptureStatus. After a successful
 * call, \p *pCaptureStatus will contain one of the following:
 * - ::rtStreamCaptureStatusNone: The stream is not capturing.
 * - ::rtStreamCaptureStatusActive: The stream is capturing.
 * - ::rtStreamCaptureStatusInvalidated: The stream was capturing but an error
 *   has invalidated the capture sequence. The capture sequence must be terminated
 *   with ::rtStreamEndCapture on the stream where it was initiated in order to
 *   continue using \p stream.
 *
 * Note that, if this is called on ::rtStreamLegacy (the "null stream") while
 * a blocking stream on the same device is capturing, it will return
 * ::rtErrorStreamCaptureImplicit and \p *pCaptureStatus is unspecified
 * after the call. The blocking stream capture is not invalidated.
 *
 * When a blocking stream is capturing, the legacy stream is in an
 * unusable state until the blocking stream capture is terminated. The legacy
 * stream is not supported for stream capture, but attempted use would have an
 * implicit dependency on the capturing stream(s).
 *
 * \param stream         - Stream to query
 * \param pCaptureStatus - Returns the stream's capture status
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorStreamCaptureImplicit
 * \notefnerr
 *
 * \sa
 * ::rtStreamCreate,
 * ::rtStreamBeginCapture,
 * ::rtStreamEndCapture
 */
extern rtError_t rtStreamIsCapturing(rtStream_t stream, enum rtStreamCaptureStatus *pCaptureStatus);
extern rtError_t rtStreamGetCaptureInfo(rtStream_t stream, rtStreamCaptureStatus *captureStatus_out, unsigned long long *id_out,
    rtGraph_t *graph_out, const rtGraphNode_t **dependencies_out, size_t *numDependencies_out);
extern rtError_t rtStreamGetFlags(rtStream_t hStream, unsigned int *flags);
/** @} */ /* END RPP_STREAM */

/*******************************************************************************
*                                                                              *
*                                                                              *
*                                                                              *
*******************************************************************************/

/**
 * \defgroup RPP_EVENT Event Management
 *
 * ___MANBRIEF___ event management functions of the RPP runtime API
 * (___CURRENT_FILE___) ___ENDMANBRIEF___
 *
 * This section describes the event management functions of the RPP runtime
 * application programming interface.
 *
 * @{
 */

/**
 * \brief Creates an event object
 *
 * Creates an event object for the current device using ::rtEventDefault.
 *
 * \param event - Newly created event
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorLaunchFailure,
 * ::rtErrorMemoryAllocation
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa \ref ::rtEventCreate(rtEvent_t*, unsigned int) "rtEventCreate (C++ API)",
 * ::rtEventCreateWithFlags, ::rtEventRecord, ::rtEventQuery,
 * ::rtEventSynchronize, ::rtEventDestroy, ::rtEventElapsedTime,
 * ::rtStreamWaitEvent,
 * ::rppEventCreate
 */
extern rtError_t rtEventCreate(rtEvent_t *event);


/**
 * \brief Creates an event object with the specified flags
 *
 * Creates an event object for the current device with the specified flags. Valid
 * flags include:
 * - ::rtEventDefault: Default event creation flag.
 * - ::rtEventEnableTiming: Specifies that the created event need
 *   to record timing data.  Events created with this flag specified and
 *   the ::rtEventBlockingSync flag not specified will provide the best
 *   performance when used with ::rtStreamWaitEvent() and ::rtEventQuery().
 *
 * \param event - Newly created event
 * \param flags - Flags for new event
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorLaunchFailure,
 * ::rtErrorMemoryAllocation
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa \ref ::rtEventCreate(rtEvent_t*) "rtEventCreate (C API)",
 * ::rtEventSynchronize, ::rtEventDestroy, ::rtEventElapsedTime,
 * ::rtStreamWaitEvent,
 * ::rppEventCreate
 */
extern rtError_t rtEventCreateWithFlags(rtEvent_t *event, int flags);


/**
 * \brief Records an event
 *
 * Captures in \p event the contents of \p stream at the time of this call.
 * \p event and \p stream must be on the same device.
 * Calls such as ::rtEventQuery() or ::rtStreamWaitEvent() will then
 * examine or wait for completion of the work that was captured. Uses of
 * \p stream after this call do not modify \p event. See note on default
 * stream behavior for what is captured in the default case.
 *
 * ::rtEventRecord() can be called multiple times on the same event and
 * will overwrite the previously captured state. Other APIs such as
 * ::rtStreamWaitEvent() use the most recently captured state at the time
 * of the API call, and are not affected by later calls to
 * ::rtEventRecord(). Before the first call to ::rtEventRecord(), an
 * event represents an empty set of work, so for example ::rtEventQuery()
 * would return ::rtSuccess.
 *
 * \param event  - Event to record
 * \param stream - Stream in which to record event
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidResourceHandle,
 * ::rtErrorLaunchFailure
 * \note_null_stream
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa \ref ::rtEventCreate(rtEvent_t*) "rtEventCreate (C API)",
 * ::rtEventCreateWithFlags, ::rtEventQuery,
 * ::rtEventSynchronize, ::rtEventDestroy, ::rtEventElapsedTime,
 * ::rtStreamWaitEvent,
 * ::rppEventRecord
 */
extern rtError_t rtEventRecord(rtEvent_t event, rtStream_t stream);


/**
 * \brief Queries an event's status
 *
 * Queries the status of all work currently captured by \p event. See
 * ::rtEventRecord() for details on what is captured by an event.
 *
 * Returns ::rtSuccess if all captured work has been completed, or
 * ::rtErrorNotReady if any captured work is incomplete.
 *
 * For the purposes of Unified Memory, a return value of ::rtSuccess
 * is equivalent to having called ::rtEventSynchronize().
 *
 * \param event - Event to query
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorNotReady,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidResourceHandle,
 * ::rtErrorLaunchFailure
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa \ref ::rtEventCreate(rtEvent_t*) "rtEventCreate (C API)",
 * ::rtEventCreateWithFlags, ::rtEventRecord,
 * ::rtEventSynchronize, ::rtEventDestroy, ::rtEventElapsedTime,
 * ::rppEventQuery
 */
extern rtError_t rtEventQuery(rtEvent_t event);


/**
 * \brief Waits for an event to complete
 *
 * Waits until the completion of all work currently captured in \p event.
 * See ::rtEventRecord() for details on what is captured by an event.
 *
 *
 * \param event - Event to wait for
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidResourceHandle,
 * ::rtErrorLaunchFailure
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa \ref ::rtEventCreate(rtEvent_t*) "rtEventCreate (C API)",
 * ::rtEventCreateWithFlags, ::rtEventRecord,
 * ::rtEventQuery, ::rtEventDestroy, ::rtEventElapsedTime,
 * ::rppEventSynchronize
 */
extern rtError_t rtEventSynchronize(rtEvent_t event);


/**
 * \brief Destroys an event object
 *
 * Destroys the event specified by \p event.
 *
 * An event may be destroyed before it is complete (i.e., while
 * ::rtEventQuery() would return ::rtErrorNotReady). In this case, the
 * call does not block on completion of the event, and any associated
 * resources will automatically be released asynchronously at completion.
 *
 * \param event - Event to destroy
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorLaunchFailure
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa \ref ::rtEventCreate(rtEvent_t*) "rtEventCreate (C API)",
 * ::rtEventCreateWithFlags, ::rtEventQuery,
 * ::rtEventSynchronize, ::rtEventRecord, ::rtEventElapsedTime,
 * ::rppEventDestroy
 */
extern rtError_t rtEventDestroy(rtEvent_t event);


/**
 * \brief Computes the elapsed time between events
 *
 * Computes the elapsed time between two events (in milliseconds with a
 * resolution of around 0.5 microseconds).
 *
 * If either event was last recorded in a non-NULL stream, the resulting time
 * may be greater than expected (even if both used the same stream handle). This
 * happens because the ::rtEventRecord() operation takes place asynchronously
 * and there is no guarantee that the measured latency is actually just between
 * the two events. Any number of other different stream operations could execute
 * in between the two measured events, thus altering the timing in a significant
 * way.
 *
 * If ::rtEventRecord() has not been called on either event, then
 * ::rtErrorInvalidResourceHandle is returned. If ::rtEventRecord() has been
 * called on both events but one or both of them has not yet been completed
 * (that is, ::rtEventQuery() would return ::rtErrorNotReady on at least one
 * of the events), ::rtErrorNotReady is returned. If either event was created
 * with the ::rtEventDisableTiming flag, then this function will return
 * ::rtErrorInvalidResourceHandle.
 *
 * \param ms    - Time between \p start and \p end in ms
 * \param start - Starting event
 * \param end   - Ending event
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorNotReady,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidResourceHandle,
 * ::rtErrorLaunchFailure
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa \ref ::rtEventCreate(rtEvent_t*) "rtEventCreate (C API)",
 * ::rtEventCreateWithFlags, ::rtEventQuery,
 * ::rtEventSynchronize, ::rtEventDestroy, ::rtEventRecord,
 * ::rppEventElapsedTime
 */
extern rtError_t rtEventElapsedTime(float *ms, rtEvent_t start, rtEvent_t end);

/** @} */ /* END RPP_EVENT */


/*******************************************************************************
*                                                                              *
*                                                                              *
*                                                                              *
*******************************************************************************/

/**
 * \defgroup RPP_MEMORY Memory Management
 *
 * ___MANBRIEF___ memory management functions of the RPP runtime API
 * (___CURRENT_FILE___) ___ENDMANBRIEF___
 *
 * This section describes the memory management functions of the RPP runtime
 * application programming interface.
 *
 * Some functions have overloaded C++ API template versions documented separately in the
 * \ref RPP_HIGHLEVEL "C++ API Routines" module.
 *
 * @{
 */

struct rtPitchedPtr make_rtPitchedPtr(void *d, size_t p, size_t xsz, size_t ysz);
struct rtExtent make_rtExtent(size_t w, size_t h, size_t d);
struct rtPos make_rtPos(size_t x, size_t y, size_t z);

/**
 * \brief Allocates logical 1D, 2D, or 3D memory objects on the device
 *
 * Allocates at least \p width * \p height * \p depth bytes of linear memory
 * on the device and returns a ::rtPitchedPtr in which \p ptr is a pointer
 * to the allocated memory. The function may pad the allocation to ensure
 * hardware alignment requirements are met. The pitch returned in the \p pitch
 * field of \p pitchedDevPtr is the width in bytes of the allocation.
 *
 * The returned ::rtPitchedPtr contains additional fields \p xsize and
 * \p ysize, the logical width and height of the allocation, which are
 * equivalent to the \p width and \p height \p extent parameters provided by
 * the programmer during allocation.
 *
 * For allocations of 2D and 3D objects, it is highly recommended that
 * programmers perform allocations using ::rtMalloc3D() or
 * ::rtMallocPitch(). Due to alignment restrictions in the hardware, this is
 * especially true if the application will be performing memory copies
 * involving 2D or 3D objects (whether linear memory or RPP arrays).
 *
 * \param pitchedDevPtr  - Pointer to allocated pitched device memory
 * \param extent         - Requested allocation size (\p width field in bytes)
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorMemoryAllocation
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtMallocPitch, ::rtFree, ::rtMemcpy3D, ::rtMemset3D,
 * ::rtMalloc3DArray, ::rtMallocArray, ::rtFreeArray,
 * \ref ::rtMallocHost(void**, size_t) "rtMallocHost (C API)",
 * ::rtFreeHost, ::rtHostAlloc, ::make_rtPitchedPtr, ::make_rtExtent,
 * ::rppMemAllocPitch
 */
extern rtError_t rtMalloc3D(struct rtPitchedPtr* pitchedDevPtr,
	struct rtExtent extent);


/**
 * \brief Initializes or sets device memory to a value
 *
 * Initializes each element of a 3D array to the specified value \p value.
 * The object to initialize is defined by \p pitchedDevPtr. The \p pitch field
 * of \p pitchedDevPtr is the width in memory in bytes of the 3D array pointed
 * to by \p pitchedDevPtr, including any padding added to the end of each row.
 * The \p xsize field specifies the logical width of each row in bytes, while
 * the \p ysize field specifies the height of each 2D slice in rows.
 *
 * The extents of the initialized region are specified as a \p width in bytes,
 * a \p height in rows, and a \p depth in slices.
 *
 * Extents with \p width greater than or equal to the \p xsize of
 * \p pitchedDevPtr may perform significantly faster than extents narrower
 * than the \p xsize. Secondarily, extents with \p height equal to the
 * \p ysize of \p pitchedDevPtr will perform faster than when the \p height is
 * shorter than the \p ysize.
 *
 * This function performs fastest when the \p pitchedDevPtr has been allocated
 * by ::rtMalloc3D().
 *
 * Note that this function is asynchronous with respect to the host unless
 * \p pitchedDevPtr refers to pinned host memory.
 *
 * \param pitchedDevPtr - Pointer to pitched device memory
 * \param value         - Value to set for each byte of specified memory
 * \param extent        - Size parameters for where to set device memory (\p width field in bytes)
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * \notefnerr
 * \note_memset
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtMemset, ::rtMemset2D,
 * ::rtMemsetAsync, ::rtMemset2DAsync, ::rtMemset3DAsync,
 * ::rtMalloc3D, ::make_rtPitchedPtr,
 * ::make_rtExtent
 */
extern rtError_t rtMemset3D(struct rtPitchedPtr pitchedDevPtr,
	int value, struct rtExtent extent);

/**
 * \brief Initializes or sets device memory to a value
 *
 * Fills the first \p count bytes of the memory area pointed to by \p devPtr
 * with the constant byte value \p value.
 *
 * ::rtMemsetAsync() is asynchronous with respect to the host, so
 * the call may return before the memset is complete. The operation can optionally
 * be associated to a stream by passing a non-zero \p stream argument.
 * If \p stream is non-zero, the operation may overlap with operations in other streams.
 *
 * The device version of this function only handles device to device copies and
 * cannot be given local or shared pointers.
 *
 * \param devPtr - Pointer to device memory
 * \param value  - Value to set for each byte of specified memory
 * \param count  - Size in bytes to set
 * \param stream - Stream identifier
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * \notefnerr
 * \note_memset
 * \note_null_stream
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtMemset, ::rtMemset2D, ::rtMemset3D,
 * ::rtMemset2DAsync, ::rtMemset3DAsync,
 * ::rppMemsetD8Async,
 * ::rppMemsetD16Async,
 * ::rppMemsetD32Async
 */
#ifdef __cplusplus
extern rtError_t rtMemsetAsync(void *devPtr, int value, size_t count, rtStream_t stream = 0);
#else
extern rtError_t rtMemsetAsync(void *devPtr, int value, size_t count, rtStream_t stream);
#endif


/**
 * \brief Copies data between 3D objects
 *
\code
struct rtExtent {
  size_t width;
  size_t height;
  size_t depth;
};
struct rtExtent make_rtExtent(size_t w, size_t h, size_t d);

struct rtPos {
  size_t x;
  size_t y;
  size_t z;
};
struct rtPos make_rtPos(size_t x, size_t y, size_t z);

struct rtMemcpy3DParms {
  rtArray_t           srcArray;
  struct rtPos        srcPos;
  struct rtPitchedPtr srcPtr;
  rtArray_t           dstArray;
  struct rtPos        dstPos;
  struct rtPitchedPtr dstPtr;
  struct rtExtent     extent;
  enum rtMemcpyKind   kind;
};
\endcode
 *
 * ::rtMemcpy3D() copies data betwen two 3D objects. The source and
 * destination objects may be in either host memory, device memory, or a RPP
 * array. The source, destination, extent, and kind of copy performed is
 * specified by the ::rtMemcpy3DParms struct which should be initialized to
 * zero before use:
\code
rtMemcpy3DParms myParms = {0};
\endcode
 *
 * The struct passed to ::rtMemcpy3D() must specify one of \p srcArray or
 * \p srcPtr and one of \p dstArray or \p dstPtr. Passing more than one
 * non-zero source or destination will cause ::rtMemcpy3D() to return an
 * error.
 *
 * The \p srcPos and \p dstPos fields are optional offsets into the source and
 * destination objects and are defined in units of each object's elements. The
 * element for a host or device pointer is assumed to be <b>unsigned char</b>.
 *
 * The \p extent field defines the dimensions of the transferred area in
 * elements. If a RPP array is participating in the copy, the extent is
 * defined in terms of that array's elements. If no RPP array is
 * participating in the copy then the extents are defined in elements of
 * <b>unsigned char</b>.
 *
 * The \p kind field defines the direction of the copy and must be a supported
 * ::rtMemcpyKind value (see ::rtMemcpy), including host/SRAM paths
 * ::rtMemcpyHostToSram and ::rtMemcpySramToHost.
 * For ::rtMemcpyHostToHost or ::rtMemcpyHostToDevice or ::rtMemcpyDeviceToHost
 * passed as kind and rtArray type passed as source or destination, if the kind
 * implies rtArray type to be present on the host, ::rtMemcpy3D() will
 * disregard that implication and silently correct the kind based on the fact that
 * rtArray type can only be present on the device.
 *
 * If the source and destination are both arrays, ::rtMemcpy3D() will return
 * an error if they do not have the same element size.
 *
 * The source and destination object may not overlap. If overlapping source
 * and destination objects are specified, undefined behavior will result.
 *
 * The source object must lie entirely within the region defined by \p srcPos
 * and \p extent. The destination object must lie entirely within the region
 * defined by \p dstPos and \p extent.
 *
 * ::rtMemcpy3D() returns an error if the pitch of \p srcPtr or \p dstPtr
 * exceeds the maximum allowed. The pitch of a ::rtPitchedPtr allocated
 * with ::rtMalloc3D() will always be valid.
 *
 * \param p - 3D memory copy parameters
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidPitchValue,
 * ::rtErrorInvalidMemcpyDirection
 * \notefnerr
 * \note_sync
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtMalloc3D, ::rtMalloc3DArray, ::rtMemset3D, ::rtMemcpy3DAsync,
 * ::rtMemcpy, ::rtMemcpy2D,
 * ::rtMemcpy2DToArray, ::rtMemcpy2DFromArray,
 * ::rtMemcpy2DArrayToArray, ::rtMemcpyToSymbol,
 * ::rtMemcpyFromSymbol, ::rtMemcpyAsync, ::rtMemcpy2DAsync,
 * ::rtMemcpy2DToArrayAsync,
 * ::rtMemcpy2DFromArrayAsync,
 * ::rtMemcpyToSymbolAsync, ::rtMemcpyFromSymbolAsync,
 * ::make_rtExtent, ::make_rtPos,
 * ::rppMemcpy3D
 */
extern rtError_t rtMemcpy3D(const struct rtMemcpy3DParams *p);


/**
 * \brief Copies data between 3D objects
 *
\code
struct rtExtent {
  size_t width;
  size_t height;
  size_t depth;
};
struct rtExtent make_rtExtent(size_t w, size_t h, size_t d);

struct rtPos {
  size_t x;
  size_t y;
  size_t z;
};
struct rtPos make_rtPos(size_t x, size_t y, size_t z);

struct rtMemcpy3DParms {
  rtArray_t           srcArray;
  struct rtPos        srcPos;
  struct rtPitchedPtr srcPtr;
  rtArray_t           dstArray;
  struct rtPos        dstPos;
  struct rtPitchedPtr dstPtr;
  struct rtExtent     extent;
  enum rtMemcpyKind   kind;
};
\endcode
 *
 * ::rtMemcpy3DAsync() copies data betwen two 3D objects. The source and
 * destination objects may be in either host memory, device memory, or a RPP
 * array. The source, destination, extent, and kind of copy performed is
 * specified by the ::rtMemcpy3DParms struct which should be initialized to
 * zero before use:
\code
rtMemcpy3DParms myParms = {0};
\endcode
 *
 * The struct passed to ::rtMemcpy3DAsync() must specify one of \p srcArray
 * or \p srcPtr and one of \p dstArray or \p dstPtr. Passing more than one
 * non-zero source or destination will cause ::rtMemcpy3DAsync() to return an
 * error.
 *
 * The \p srcPos and \p dstPos fields are optional offsets into the source and
 * destination objects and are defined in units of each object's elements. The
 * element for a host or device pointer is assumed to be <b>unsigned char</b>.
 * For RPP arrays, positions must be in the range [0, 2048) for any
 * dimension.
 *
 * The \p extent field defines the dimensions of the transferred area in
 * elements. If a RPP array is participating in the copy, the extent is
 * defined in terms of that array's elements. If no RPP array is
 * participating in the copy then the extents are defined in elements of
 * <b>unsigned char</b>.
 *
 * The \p kind field defines the direction of the copy and must be a supported
 * ::rtMemcpyKind value (see ::rtMemcpy), including host/SRAM paths
 * ::rtMemcpyHostToSram and ::rtMemcpySramToHost.
 * For ::rtMemcpyHostToHost or ::rtMemcpyHostToDevice or ::rtMemcpyDeviceToHost
 * passed as kind and rtArray type passed as source or destination, if the kind
 * implies rtArray type to be present on the host, ::rtMemcpy3DAsync() will
 * disregard that implication and silently correct the kind based on the fact that
 * rtArray type can only be present on the device.
 *
 * If the source and destination are both arrays, ::rtMemcpy3DAsync() will
 * return an error if they do not have the same element size.
 *
 * The source and destination object may not overlap. If overlapping source
 * and destination objects are specified, undefined behavior will result.
 *
 * The source object must lie entirely within the region defined by \p srcPos
 * and \p extent. The destination object must lie entirely within the region
 * defined by \p dstPos and \p extent.
 *
 * ::rtMemcpy3DAsync() returns an error if the pitch of \p srcPtr or
 * \p dstPtr exceeds the maximum allowed. The pitch of a
 * ::rtPitchedPtr allocated with ::rtMalloc3D() will always be valid.
 *
 * ::rtMemcpy3DAsync() is asynchronous with respect to the host, so
 * the call may return before the copy is complete. The copy can optionally
 * be associated to a stream by passing a non-zero \p stream argument. If
 * \p kind is ::rtMemcpyHostToDevice or ::rtMemcpyDeviceToHost and \p stream
 * is non-zero, the copy may overlap with operations in other streams.
 *
 * The device version of this function only handles device to device copies and
 * cannot be given local or shared pointers.
 *
 * \param p      - 3D memory copy parameters
 * \param stream - Stream identifier
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidPitchValue,
 * ::rtErrorInvalidMemcpyDirection
 * \notefnerr
 * \note_async
 * \note_null_stream
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtMalloc3D, ::rtMalloc3DArray, ::rtMemset3D, ::rtMemcpy3D,
 * ::rtMemcpy, ::rtMemcpy2D,
 * ::rtMemcpy2DToArray, :::rtMemcpy2DFromArray,
 * ::rtMemcpy2DArrayToArray, ::rtMemcpyToSymbol,
 * ::rtMemcpyFromSymbol, ::rtMemcpyAsync, ::rtMemcpy2DAsync,
 * ::rtMemcpy2DToArrayAsync,
 * ::rtMemcpy2DFromArrayAsync,
 * ::rtMemcpyToSymbolAsync, ::rtMemcpyFromSymbolAsync,
 * ::make_rtExtent, ::make_rtPos,
 * ::rppMemcpy3DAsync
 */
extern rtError_t rtMemcpy3DAsync(const struct rtMemcpy3DParams *p,
	rtStream_t stream);

#if 0 // willjiang, not support yet, 20230508
extern rtError_t rtTrans1DCdma(void *dst, void *src, unsigned int count, enum rtCdmaTransKind kind);
#endif

/*******************************************************************************
*                                                                              *
*                                                                              *
*                                                                              *
*******************************************************************************/

/**
 * \brief Allocate memory on the device
 *
 * Allocates \p size bytes of linear memory on the device and returns in
 * \p *devPtr a pointer to the allocated memory. The allocated memory is
 * suitably aligned for any kind of variable. The memory is not cleared.
 * ::rtMalloc() returns ::rtErrorMemoryAllocation in case of failure.
 *
 * The device version of ::rtFree cannot be used with a \p *devPtr
 * allocated using the host API, and vice versa.
 *
 * \param devPtr - Pointer to allocated device memory
 * \param size   - Requested allocation size in bytes
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorMemoryAllocation
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtMallocPitch, ::rtFree, ::rtMallocArray, ::rtFreeArray,
 * ::rtMalloc3D, ::rtMalloc3DArray,
 * \ref ::rtMallocHost(void**, size_t) "rtMallocHost (C API)",
 * ::rtFreeHost, ::rtHostAlloc,
 * ::rppMemAlloc
 */
extern rtError_t rtMalloc(void **devPtr, size_t size);


/**
 * \brief Allocates page-locked memory on the host
 *
 * Allocates \p size bytes of host memory that is page-locked and accessible
 * to the device. The driver tracks the virtual memory ranges allocated with
 * this function and automatically accelerates calls to functions such as
 * ::rtMemcpy*(). Since the memory can be accessed directly by the device,
 * it can be read or written with much higher bandwidth than pageable memory
 * obtained with functions such as ::malloc(). Allocating excessive amounts of
 * memory with ::rtMallocHost() may degrade system performance, since it
 * reduces the amount of memory available to the system for paging. As a
 * result, this function is best used sparingly to allocate staging areas for
 * data exchange between host and device.
 *
 * \param ptr  - Pointer to allocated host memory
 * \param size - Requested allocation size in bytes
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorMemoryAllocation
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtMalloc, ::rtMallocPitch, ::rtMallocArray, ::rtMalloc3D,
 * ::rtMalloc3DArray, ::rtHostAlloc, ::rtFree, ::rtFreeArray,
 * \ref ::rtMallocHost(void**, size_t, unsigned int) "rtMallocHost (C++ API)",
 * ::rtFreeHost, ::rtHostAlloc,
 * ::rppMemAllocHost
 */
extern rtError_t rtMallocHost(void **ptr, size_t size);


/**
 * \brief Allocates pitched memory on the device
 *
 * Allocates at least \p width (in bytes) * \p height bytes of linear memory
 * on the device and returns in \p *devPtr a pointer to the allocated memory.
 * The function may pad the allocation to ensure that corresponding pointers
 * in any given row will continue to meet the alignment requirements for
 * coalescing as the address is updated from row to row. The pitch returned in
 * \p *pitch by ::rtMallocPitch() is the width in bytes of the allocation.
 * The intended usage of \p pitch is as a separate parameter of the allocation,
 * used to compute addresses within the 2D array. Given the row and column of
 * an array element of type \p T, the address is computed as:
 * \code
    T* pElement = (T*)((char*)BaseAddress + Row * pitch) + Column;
   \endcode
 *
 * For allocations of 2D arrays, it is recommended that programmers consider
 * performing pitch allocations using ::rtMallocPitch(). Due to pitch
 * alignment restrictions in the hardware, this is especially true if the
 * application will be performing 2D memory copies between different regions
 * of device memory (whether linear memory or RPP arrays).
 *
 * \param devPtr - Pointer to allocated pitched device memory
 * \param pitch  - Pitch for allocation
 * \param width  - Requested pitched allocation width (in bytes)
 * \param height - Requested pitched allocation height
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorMemoryAllocation
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtMalloc, ::rtFree, ::rtMallocArray, ::rtFreeArray,
 * \ref ::rtMallocHost(void**, size_t) "rtMallocHost (C API)",
 * ::rtFreeHost, ::rtMalloc3D, ::rtMalloc3DArray,
 * ::rtHostAlloc,
 * ::rppMemAllocPitch
 */
extern rtError_t rtMallocPitch(void **devPtr, size_t *pitch,
	size_t width, size_t height);

/**
 * \brief Allocate memory on the device sram
 *
 * Allocates \p size bytes of linear memory on the device sram and returns in
 * \p *devPtr a pointer to the allocated memory. The allocated memory is
 * suitably aligned for any kind of variable. The memory is not cleared.
 * ::rtMallocSram() returns ::rtErrorMemoryAllocation in case of failure.
 *
 * \param devPtr - Pointer to allocated device memory
 * \param size   - Requested allocation size in bytes
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorMemoryAllocation
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtMallocPitch, ::rtFree, ::rtMallocArray, ::rtFreeArray,
 * ::rtMalloc3D, ::rtMalloc3DArray,
 * \ref ::rtMallocSram(void**, size_t) "rppSramAlloc (C API)",
 * ::rtFreeSram,
 * ::rppMemAlloc
 */
extern rtError_t rtMallocSram(void **devPtr, size_t size);

/**
 * \brief Allocate virtual memory on the device sram
 *
 * Allocates \p size bytes of linear memory on the device virtual sram and returns in
 * \p *devPtr a pointer to the allocated memory.
 * The virtual memory can only be used in graph related API.
 * The allocated memory is suitably aligned for any kind of variable. The memory is not cleared.
 * ::rtMallocVirtSram() returns ::rtErrorMemoryAllocation in case of failure.
 *
 * \param devPtr - Pointer to allocated device memory
 * \param size   - Requested allocation size in bytes
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorMemoryAllocation
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtMallocPitch, ::rtFree, ::rtMallocArray, ::rtFreeArray,
 * ::rtMalloc3D, ::rtMalloc3DArray,
 * \ref ::rtMallocVirtSram(void**, size_t) "rppVirtSramAlloc (C API)",
 * ::rtFreeVirtSram,
 * ::rppMemAlloc
 */
extern rtError_t rtMallocVirtSram(void **devPtr, size_t size);

/**
 * \brief Allocate memory on the device MPU memory
 *
 * Allocates \p size bytes of linear memory on the device MPU memory and returns in
 * \p *devPtr a pointer to the allocated memory. The allocated memory is
 * suitably aligned for any kind of variable. The memory is not cleared.
 * \p flags indicates different regions of MPU.
 * ::rtMallocMpu() returns ::rtErrorMemoryAllocation in case of failure.
 *
 * \param devPtr - Pointer to allocated device memory
 * \param size   - Requested allocation size in bytes
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorMemoryAllocation
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtMallocPitch, ::rtFree, ::rtMallocArray, ::rtFreeArray,
 * ::rtMalloc3D, ::rtMalloc3DArray,
 * \ref ::rtMallocMpu(void**, size_t) "rppMpumemAlloc (C API)",
 * ::rtFreeMpu,
 * ::rppMemAlloc
 */
extern rtError_t rtMallocMpu(void **devPtr, size_t size, unsigned int flags);

/**
 * \brief Frees memory on the device MPU
 *
 * Frees the memory space pointed to by \p devPtr, which must have been
 * returned by a previous call to ::rtMallocMpu().
 * Otherwise, or if ::rtFreeMpu(\p devPtr) has already been called before,
 * an error is returned. If \p devPtr is 0, no operation is performed.
 * ::rtFree() returns ::rtErrorValue in case of failure.
 *
 * \param devPtr - Device pointer to memory to free
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtMallocMpu, ::rtMallocPitch, ::rtMallocArray, ::rtFreeArray,
 * \ref ::rtMallocHost(void**, size_t) "rtMallocHost (C API)",
 * ::rtFreeHost, ::rtMalloc3D, ::rtMalloc3DArray,
 * ::rtHostAlloc,
 * ::rppMpumemFree
 */
extern rtError_t rtFreeMpu(void *dptr);

/**
 * \brief Frees memory on the device
 *
 * Frees the memory space pointed to by \p devPtr, which must have been
 * returned by a previous call to ::rtMalloc() or ::rtMallocPitch().
 * Otherwise, or if ::rtFree(\p devPtr) has already been called before,
 * an error is returned. If \p devPtr is 0, no operation is performed.
 * ::rtFree() returns ::rtErrorValue in case of failure.
 *
 * The device version of ::rtFree cannot be used with a \p *devPtr
 * allocated using the host API, and vice versa.
 *
 * \param devPtr - Device pointer to memory to free
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtMalloc, ::rtMallocPitch, ::rtMallocArray, ::rtFreeArray,
 * \ref ::rtMallocHost(void**, size_t) "rtMallocHost (C API)",
 * ::rtFreeHost, ::rtMalloc3D, ::rtMalloc3DArray,
 * ::rtHostAlloc,
 * ::rppMemFree
 */
extern rtError_t rtFree(void *devPtr);


/**
 * \brief Frees page-locked memory
 *
 * Frees the memory space pointed to by \p hostPtr, which must have been
 * returned by a previous call to ::rtMallocHost() or ::rtHostAlloc().
 *
 * \param ptr - Pointer to memory to free
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtMalloc, ::rtMallocPitch, ::rtFree, ::rtMallocArray,
 * ::rtFreeArray,
 * \ref ::rtMallocHost(void**, size_t) "rtMallocHost (C API)",
 * ::rtMalloc3D, ::rtMalloc3DArray, ::rtHostAlloc,
 * ::rppMemFreeHost
 */
extern rtError_t rtFreeHost(void *ptr);

/**
 * \brief Frees memory on the device sram
 *
 * Frees the sram memory space pointed to by \p devPtr, which must have been
 * returned by a previous call to ::rtMallocSram().
 * Otherwise, or if ::rtFreeSram(\p devPtr) has already been called before,
 * an error is returned. If \p devPtr is 0, no operation is performed.
 * ::rtFreeSram() returns ::rtErrorValue in case of failure.
 *
 * The device version of ::rtFree cannot be used with a \p *devPtr
 * allocated using the host API, and vice versa.
 *
 * \param devPtr - Device pointer to memory to free
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtMallocSram, ::rtMallocArray, ::rtFreeArray,
 * \ref ::rtMallocHost(void**, size_t) "rtMallocHost (C API)",
 * ::rtFreeHost, ::rtMalloc3D, ::rtMalloc3DArray,
 * ::rtHostAlloc,
 * ::rppSramFree
 */
extern rtError_t rtFreeSram(void *devPtr);


/**
 * \brief Frees virtual memory on the device sram
 *
 * Frees the virtual sram memory space pointed to by \p devPtr, which must have been
 * returned by a previous call to ::rtMallocVirtSram().
 * Otherwise, or if ::rtFreeVirtSram(\p devPtr) has already been called before,
 * an error is returned. If \p devPtr is 0, no operation is performed.
 * ::rtFreeVirtSram() returns ::rtErrorValue in case of failure.
 *
 * The device version of ::rtFree cannot be used with a \p *devPtr
 * allocated using the host API, and vice versa.
 *
 * \param devPtr - Device pointer to memory to free
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtMallocVirtSram, ::rtMallocArray, ::rtFreeArray,
 * \ref ::rtMallocHost(void**, size_t) "rtMallocHost (C API)",
 * ::rtFreeHost, ::rtMalloc3D, ::rtMalloc3DArray,
 * ::rtHostAlloc,
 * ::rppVirtSramFree
 */
extern rtError_t rtFreeVirtSram(void *devPtr);


/**
 * \brief Allocates page-locked memory on the host
 *
 * Allocates \p size bytes of host memory that is page-locked and accessible
 * to the device. The driver tracks the virtual memory ranges allocated with
 * this function and automatically accelerates calls to functions such as
 * ::rtMemcpy(). Since the memory can be accessed directly by the device, it
 * can be read or written with much higher bandwidth than pageable memory
 * obtained with functions such as ::malloc(). Allocating excessive amounts of
 * pinned memory may degrade system performance, since it reduces the amount
 * of memory available to the system for paging. As a result, this function is
 * best used sparingly to allocate staging areas for data exchange between host
 * and device.
 *
 * The \p flags parameter enables different options to be specified that affect
 * the allocation, as follows.
 * - ::rtHostAllocDefault: This flag's value is defined to be 0 and causes
 * ::rtHostAlloc() to emulate ::rtMallocHost().
 * - ::rtHostAllocPortable: The memory returned by this call will be
 * considered as pinned memory by all RPP contexts, not just the one that
 * performed the allocation.
 * - ::rtHostAllocMapped: Maps the allocation into the RPP address space.
 * The device pointer to the memory may be obtained by calling
 * ::rtHostGetDevicePointer().
 * - ::rtHostAllocWriteCombined: Allocates the memory as write-combined (WC).
 * WC memory can be transferred across the PCI Express bus more quickly on some
 * system configurations, but cannot be read efficiently by most CPUs.  WC
 * memory is a good option for buffers that will be written by the CPU and read
 * by the device via mapped pinned memory or host->device transfers.
 *
 * All of these flags are orthogonal to one another: a developer may allocate
 * memory that is portable, mapped and/or write-combined with no restrictions.
 *
 * In order for the ::rtHostAllocMapped flag to have any effect, the RPP context
 * must support the ::rtDeviceMapHost flag, which can be checked via
 * ::rtGetDeviceFlags(). The ::rtDeviceMapHost flag is implicitly set for
 * contexts created via the runtime API.
 *
 * The ::rtHostAllocMapped flag may be specified on RPP contexts for devices
 * that do not support mapped pinned memory. The failure is deferred to
 * ::rtHostGetDevicePointer() because the memory may be mapped into other
 * RPP contexts via the ::rtHostAllocPortable flag.
 *
 * Memory allocated by this function must be freed with ::rtFreeHost().
 *
 * \param pHost - Device pointer to allocated memory
 * \param size  - Requested allocation size in bytes
 * \param flags - Requested properties of allocated memory
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorMemoryAllocation
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtSetDeviceFlags,
 * \ref ::rtMallocHost(void**, size_t) "rtMallocHost (C API)",
 * ::rtFreeHost,
 * ::rtGetDeviceFlags,
 * ::rppMemHostAlloc
 */
extern rtError_t rtHostAlloc(void **pHost, size_t bytes, unsigned int flags);



/**
 * \brief Passes back device pointer of mapped host memory allocated by
 * rtHostAlloc or registered by rtHostRegister
 *
 * Passes back the device pointer corresponding to the mapped, pinned host
 * buffer allocated by ::rtHostAlloc() or registered by ::rtHostRegister().
 *
 * ::rtHostGetDevicePointer() will fail if the ::rtDeviceMapHost flag was
 * not specified before deferred context creation occurred, or if called on a
 * device that does not support mapped, pinned memory.
 *
 * For devices that have a non-zero value for the device attribute
 * ::rtDevAttrCanUseHostPointerForRegisteredMem, the memory
 * can also be accessed from the device using the host pointer \p pHost.
 * The device pointer returned by ::rtHostGetDevicePointer() may or may not
 * match the original host pointer \p pHost and depends on the devices visible to the
 * application. If all devices visible to the application have a non-zero value for the
 * device attribute, the device pointer returned by ::rtHostGetDevicePointer()
 * will match the original pointer \p pHost. If any device visible to the application
 * has a zero value for the device attribute, the device pointer returned by
 * ::rtHostGetDevicePointer() will not match the original host pointer \p pHost,
 * but it will be suitable for use on all devices provided Unified Virtual Addressing
 * is enabled. In such systems, it is valid to access the memory using either pointer
 * on devices that have a non-zero value for the device attribute. Note however that
 * such devices should access the memory using only of the two pointers and not both.
 *
 * \p flags provides for future releases.  For now, it must be set to 0.
 *
 * \param pDevice - Returned device pointer for mapped memory
 * \param pHost   - Requested host pointer mapping
 * \param flags   - Flags for extensions (must be 0 for now)
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorMemoryAllocation
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtSetDeviceFlags, ::rtHostAlloc,
 * ::rppMemHostGetDevicePointer
 */
extern rtError_t rtHostGetDevicePointer(void **pDevice, void *pHost,
	unsigned int flags);


/**
 * \brief Passes back flags used to allocate pinned host memory allocated by
 * rtHostAlloc
 *
 * ::rtHostGetFlags() will fail if the input pointer does not
 * reside in an address range allocated by ::rtHostAlloc().
 *
 * \param pFlags - Returned flags word
 * \param pHost - Host pointer
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtHostAlloc,
 * ::rppMemHostGetFlags
 */
extern rtError_t rtHostGetFlags(unsigned int *pFlags, void *pHost);
/*******************************************************************************
*                                                                              *
*                                                                              *
*                                                                              *
*******************************************************************************/

/**
 * \brief Copies data between host and device
 *
 * Copies \p count bytes from the memory area pointed to by \p src to the
 * memory area pointed to by \p dst, where \p kind specifies the direction
 * of the copy and must be a supported ::rtMemcpyKind value, including
 * ::rtMemcpyHostToHost, ::rtMemcpyHostToDevice, ::rtMemcpyDeviceToHost,
 * ::rtMemcpyDeviceToDevice, ::rtMemcpyDeviceToSram, ::rtMemcpySramToDevice,
 * ::rtMemcpySramToSram, ::rtMemcpyHostToMpu, ::rtMemcpyMpuToHost,
 * ::rtMemcpyHostToSram, and ::rtMemcpySramToHost.
 * ::rtMemcpyHostToSram and ::rtMemcpySramToHost use PCIe DMA between host
 * and device SRAM (physical or virtual); the SRAM pointer must come from
 * ::rtMallocSram(), ::rtMallocVirtSram(), or the equivalent Driver API.
 * Calling ::rtMemcpy() with \p dst and \p src pointers that do not match
 * \p kind results in undefined behavior.
 *
 * \param dst   - Destination memory address
 * \param src   - Source memory address
 * \param count - Size in bytes to copy
 * \param kind  - Type of transfer
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidMemcpyDirection
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \note_sync
 *
 * \sa ::rtMemcpy2D,
 * ::rtMemcpy2DToArray, ::rtMemcpy2DFromArray,
 * ::rtMemcpy2DArrayToArray, ::rtMemcpyToSymbol,
 * ::rtMemcpyFromSymbol, ::rtMemcpyAsync, ::rtMemcpy2DAsync,
 * ::rtMemcpy2DToArrayAsync,
 * ::rtMemcpy2DFromArrayAsync,
 * ::rtMemcpyToSymbolAsync, ::rtMemcpyFromSymbolAsync,
 * ::rppMemcpyDtoH,
 * ::rppMemcpyHtoD,
 * ::rppMemcpyDtoD,
 * ::rppMemcpyHtoS,
 * ::rppMemcpyStoH,
 * ::rppMemcpy
 */
extern rtError_t rtMemcpy(void *dst, const void *src, size_t count,
	enum rtMemcpyKind kind);


/**
 * \brief Copies data between host and device
 *
 * Copies a matrix (\p height rows of \p width bytes each) from the memory
 * area pointed to by \p src to the memory area pointed to by \p dst, where
 * \p kind specifies the direction of the copy and must be a supported
 * ::rtMemcpyKind value (see ::rtMemcpy). \p dpitch and
 * \p spitch are the widths in memory in bytes of the 2D arrays pointed to by
 * \p dst and \p src, including any padding added to the end of each row. The
 * memory areas may not overlap. \p width must not exceed either \p dpitch or
 * \p spitch. Calling ::rtMemcpy2D() with \p dst and \p src pointers that do
 * not match the direction of the copy results in an undefined behavior.
 * ::rtMemcpy2D() returns an error if \p dpitch or \p spitch exceeds
 * the maximum allowed.
 *
 * \param dst    - Destination memory address
 * \param dpitch - Pitch of destination memory
 * \param src    - Source memory address
 * \param spitch - Pitch of source memory
 * \param width  - Width of matrix transfer (columns in bytes)
 * \param height - Height of matrix transfer (rows)
 * \param kind   - Type of transfer
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidPitchValue,
 * ::rtErrorInvalidMemcpyDirection
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtMemcpy,
 * ::rtMemcpy2DToArray, ::rtMemcpy2DFromArray,
 * ::rtMemcpy2DArrayToArray, ::rtMemcpyToSymbol,
 * ::rtMemcpyFromSymbol, ::rtMemcpyAsync, ::rtMemcpy2DAsync,
 * ::rtMemcpy2DToArrayAsync,
 * ::rtMemcpy2DFromArrayAsync,
 * ::rtMemcpyToSymbolAsync, ::rtMemcpyFromSymbolAsync,
 * ::rppMemcpy2D,
 * ::rppMemcpy2DUnaligned
 */
extern rtError_t rtMemcpy2D(void *dst, size_t dpitch, const void *src,
	size_t spitch, size_t width, size_t height, enum rtMemcpyKind kind);
/*******************************************************************************
*                                                                              *
*                                                                              *
*                                                                              *
*******************************************************************************/

/**
 * \brief Copies data between host and device
 *
 * Copies \p count bytes from the memory area pointed to by \p src to the
 * memory area pointed to by \p dst, where \p kind specifies the direction
 * of the copy and must be a supported ::rtMemcpyKind value (see ::rtMemcpy).
 *
 * The memory areas may not overlap. Calling ::rtMemcpyAsync() with \p dst and
 * \p src pointers that do not match \p kind results in undefined behavior.
 *
 * ::rtMemcpyAsync() is asynchronous with respect to the host, so the call
 * may return before the copy is complete. The copy can optionally be
 * associated to a stream by passing a non-zero \p stream argument. If \p kind
 * is ::rtMemcpyHostToDevice, ::rtMemcpyDeviceToHost, ::rtMemcpyHostToSram,
 * or ::rtMemcpySramToHost and \p stream is non-zero, host memory must be
 * pinned (e.g. ::rtMallocHost) and the copy may overlap with operations in
 * other streams.
 *
 * The device version of this function only handles device to device copies and
 * cannot be given local or shared pointers.
 *
 * \param dst    - Destination memory address
 * \param src    - Source memory address
 * \param count  - Size in bytes to copy
 * \param kind   - Type of transfer
 * \param stream - Stream identifier
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidMemcpyDirection
 * \notefnerr
 * \note_async
 * \note_null_stream
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtMemcpy, ::rtMemcpy2D,
 * ::rtMemcpy2DToArray, ::rtMemcpy2DFromArray,
 * ::rtMemcpy2DArrayToArray, ::rtMemcpyToSymbol,
 * ::rtMemcpyFromSymbol, ::rtMemcpy2DAsync,
 * ::rtMemcpy2DToArrayAsync,
 * ::rtMemcpy2DFromArrayAsync,
 * ::rtMemcpyToSymbolAsync, ::rtMemcpyFromSymbolAsync
 * ::rppMemcpyAsync,
 * ::rppMemcpyDtoHAsync,
 * ::rppMemcpyHtoDAsync,
 * ::rppMemcpyDtoDAsync,
 * ::rppMemcpyHtoSAsync,
 * ::rppMemcpyStoHAsync
 */
extern rtError_t rtMemcpyAsync(void *dst, const void *src, size_t count,
	enum rtMemcpyKind kind, rtStream_t stream);


/**
 * \brief Copies data between host and device
 *
 * Copies a matrix (\p height rows of \p width bytes each) from the memory
 * area pointed to by \p src to the memory area pointed to by \p dst, where
 * \p kind specifies the direction of the copy and must be a supported
 * ::rtMemcpyKind value (see ::rtMemcpy). \p dpitch and \p spitch are the
 * widths in memory in bytes of the 2D arrays pointed to by \p dst and \p src,
 * including any padding added to the end of each row. The memory areas may
 * not overlap. \p width must not exceed either \p dpitch or \p spitch.
 *
 * Calling ::rtMemcpy2DAsync() with \p dst and \p src pointers that do not
 * match \p kind results in undefined behavior.
 * ::rtMemcpy2DAsync() returns an error if \p dpitch or \p spitch is greater
 * than the maximum allowed.
 *
 * ::rtMemcpy2DAsync() is asynchronous with respect to the host, so
 * the call may return before the copy is complete. The copy can optionally
 * be associated to a stream by passing a non-zero \p stream argument. If
 * \p kind is ::rtMemcpyHostToDevice, ::rtMemcpyDeviceToHost,
 * ::rtMemcpyHostToSram, or ::rtMemcpySramToHost and \p stream is non-zero,
 * host memory must be pinned and the copy may overlap with operations in other
 * streams.
 *
 * The device version of this function only handles device to device copies and
 * cannot be given local or shared pointers.
 *
 * \param dst    - Destination memory address
 * \param dpitch - Pitch of destination memory
 * \param src    - Source memory address
 * \param spitch - Pitch of source memory
 * \param width  - Width of matrix transfer (columns in bytes)
 * \param height - Height of matrix transfer (rows)
 * \param kind   - Type of transfer
 * \param stream - Stream identifier
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidPitchValue,
 * ::rtErrorInvalidMemcpyDirection
 * \notefnerr
 * \note_async
 * \note_null_stream
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtMemcpy, ::rtMemcpy2D,
 * ::rtMemcpy2DToArray, ::rtMemcpy2DFromArray,
 * ::rtMemcpy2DArrayToArray, ::rtMemcpyToSymbol,
 * ::rtMemcpyFromSymbol, ::rtMemcpyAsync,
 * ::rtMemcpy2DToArrayAsync,
 * ::rtMemcpy2DFromArrayAsync,
 * ::rtMemcpyToSymbolAsync, ::rtMemcpyFromSymbolAsync,
 * ::rppMemcpy2DAsync
 */
extern rtError_t rtMemcpy2DAsync(void *dst, size_t dpitch, const void *src,
	size_t spitch, size_t width, size_t height, enum rtMemcpyKind kind,
	rtStream_t stream);

/*******************************************************************************
*                                                                              *
*                                                                              *
*                                                                              *
*******************************************************************************/

/**
 * \brief Initializes or sets device memory to a value
 *
 * Fills the first \p count bytes of the memory area pointed to by \p devPtr
 * with the constant byte value \p value.
 *
 * Note that this function is asynchronous with respect to the host unless
 * \p devPtr refers to pinned host memory.
 *
 * \param devPtr - Pointer to device memory
 * \param value  - Value to set for each byte of specified memory
 * \param count  - Size in bytes to set
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * \notefnerr
 * \note_memset
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rppMemsetD8,
 * ::rppMemsetD16,
 * ::rppMemsetD32
 */
extern rtError_t rtMemset(void *devPtr, int value, size_t count);
extern rtError_t  rtMemsetSram(void *devPtr, int value, size_t count);

/**
 * \brief Initializes or sets device memory to a value
 *
 * Sets to the specified value \p value a matrix (\p height rows of \p width
 * bytes each) pointed to by \p dstPtr. \p pitch is the width in bytes of the
 * 2D array pointed to by \p dstPtr, including any padding added to the end
 * of each row. This function performs fastest when the pitch is one that has
 * been passed back by ::rtMallocPitch().
 *
 * Note that this function is asynchronous with respect to the host unless
 * \p devPtr refers to pinned host memory.
 *
 * \param devPtr - Pointer to 2D device memory
 * \param pitch  - Pitch in bytes of 2D device memory
 * \param value  - Value to set for each byte of specified memory
 * \param width  - Width of matrix set (columns in bytes)
 * \param height - Height of matrix set (rows)
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * \notefnerr
 * \note_memset
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtMemset, ::rtMemset3D, ::rtMemsetAsync,
 * ::rtMemset2DAsync, ::rtMemset3DAsync,
 * ::rppMemsetD2D8,
 * ::rppMemsetD2D16,
 * ::rppMemsetD2D32
 */
extern rtError_t rtMemset2D(void *devPtr, size_t pitch, int value,
	size_t width, size_t height);

/** @} */ /* END RPP_MEMORY */

/*******************************************************************************
*                                                                              *
*                                                                              *
*                                                                              *
*******************************************************************************/
/**
 * \defgroup RPP_EXECUTION Execution Control
 *
 * ___MANBRIEF___ execution control functions of the RPP runtime API
 * (___CURRENT_FILE___) ___ENDMANBRIEF___
 *
 * This section describes the execution control functions of the RPP runtime
 * application programming interface.
 *
 * Some functions have overloaded C++ API template versions documented separately in the
 * \ref RPP_HIGHLEVEL "C++ API Routines" module.
 *
 * @{
 */

#if 1 // willjiang, not support yet, 20230508
#ifdef __cplusplus
extern rtError_t rtConfigureCall(dim3 gridDim, dim3 blockDim,
    size_t sharedMem = 0, rtStream_t stream = 0);

extern unsigned __rtPushCallConfiguration(dim3 gridDim, dim3 blockDim,
			size_t sharedMem = 0, rtStream_t stream = 0);
#else
extern rtError_t rtConfigureCall(dim3 gridDim, dim3 blockDim,
    size_t sharedMem, rtStream_t stream);

extern unsigned __rtPushCallConfiguration(dim3 gridDim, dim3 blockDim,
    size_t sharedMem, rtStream_t stream);
#endif

extern rtError_t __rtPopCallConfiguration(dim3 *gridDim, dim3 *blockDim,
			size_t *sharedMem, rtStream_t *stream);

extern rtError_t rtSetupArgument(const void *arg, size_t size,
	size_t offset);
#endif

/**
 * \brief Launches a device function
 *
 * The function invokes kernel \p func on \p gridDim (\p gridDim.x × \p gridDim.y
 * × \p gridDim.z) grid of blocks. Each block contains \p blockDim (\p blockDim.x ×
 * \p blockDim.y × \p blockDim.z) threads.
 *
 * If the kernel has N parameters the \p args should point to array of N pointers.
 * Each pointer, from <tt>args[0]</tt> to <tt>args[N - 1]</tt>, point to the region
 * of memory from which the actual parameter will be copied.
 *
 * For templated functions, pass the function symbol as follows:
 * func_name<template_arg_0,...,template_arg_N>
 *
 * \p sharedMem sets the amount of dynamic shared memory that will be available to
 * each thread block.
 *
 * \p stream specifies a stream the invocation is associated to.
 *
 * \param func        - Device function symbol
 * \param gridDim     - Grid dimentions
 * \param blockDim    - Block dimentions
 * \param args        - Arguments
 * \param sharedMem   - Shared memory
 * \param stream      - Stream identifier
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidDeviceFunction,
 * ::rtErrorInvalidConfiguration,
 * ::rtErrorLaunchFailure,
 * ::rtErrorLaunchTimeout,
 * ::rtErrorLaunchOutOfResources,
 * ::rtErrorSharedObjectInitFailed,
 * ::rtErrorInvalidPtx,
 * ::rtErrorNoKernelImageForDevice,
 * ::rtErrorJitCompilerNotFound
 * \note_null_stream
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * \ref ::rtLaunchKernel(const T *func, dim3 gridDim, dim3 blockDim, void **args, size_t sharedMem, rtStream_t stream) "rtLaunchKernel (C++ API)",
 * ::rppLaunchKernel
 */
extern rtError_t rtLaunchKernel(const void *func, dim3 gridDim, dim3 blockDim,
	void **args, size_t sharedMem, rtStream_t stream);

/**
 * \brief Launches a device function
 *
 * The function invokes kernel \p func on \p gridDim (\p gridDim.x × \p gridDim.y
 * × \p gridDim.z) grid of blocks. Each block contains \p blockDim (\p blockDim.x ×
 * \p blockDim.y × \p blockDim.z) threads.
 *
 * If the kernel has N parameters the \p args should point to array of N pointers.
 * Each pointer, from <tt>args[0]</tt> to <tt>args[N - 1]</tt>, point to the region
 * of memory from which the actual parameter will be copied.
 *
 * For templated functions, pass the function symbol as follows:
 * func_name<template_arg_0,...,template_arg_N>
 *
 * \p sharedMem sets the amount of dynamic shared memory that will be available to
 * each thread block.
 *
 * \p stream specifies a stream the invocation is associated to.
 *
 * \param func        - Device function symbol
 * \param gridDim     - Grid dimentions
 * \param blockDim    - Block dimentions
 * \param args        - Arguments
 * \param sharedMem   - Shared memory
 * \param stream      - Stream identifier
 * \param extra       - Extra arguments
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidDeviceFunction,
 * ::rtErrorInvalidConfiguration,
 * ::rtErrorLaunchFailure,
 * ::rtErrorLaunchTimeout,
 * ::rtErrorLaunchOutOfResources,
 * ::rtErrorSharedObjectInitFailed,
 * ::rtErrorInvalidPtx,
 * ::rtErrorNoKernelImageForDevice,
 * ::rtErrorJitCompilerNotFound
 * \note_null_stream
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * \ref ::rtLaunchKernel2(const T *func, dim3 gridDim, dim3 blockDim, void **args, size_t sharedMem, rtStream_t stream) "rtLaunchKernel (C++ API)",
 * ::rppLaunchKernel
 */
extern rtError_t rtLaunchKernel2(const void *func, dim3 gridDim, dim3 blockDim,
	void **args, size_t sharedMem, rtStream_t stream, void **extra);

#if 0 // willjiang, not support yet, 20230508
extern rtError_t rtLaunch(const char *entry);
#endif

/**
 * \brief Find out attributes for a given function
 *
 * This function obtains the attributes of a function specified via \p func.
 * \p func is a device function symbol and must be declared as a
 * \c __global__ function. The fetched attributes are placed in \p attr.
 * If the specified function does not exist, then
 * ::rtErrorInvalidDeviceFunction is returned. For templated functions, pass
 * the function symbol as follows: func_name<template_arg_0,...,template_arg_N>
 *
 * Note that some function attributes such as
 * \ref ::rtFuncAttributes::maxThreadsPerBlock "maxThreadsPerBlock"
 * may vary based on the device that is currently being used.
 *
 * \param attr - Return pointer to function's attributes
 * \param func - Device function symbol
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidDeviceFunction
 * \notefnerr
 * \note_string_api_deprecation2
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * \ref ::rtFuncSetCacheConfig(const void*, enum rtFuncCache) "rtFuncSetCacheConfig (C API)",
 * \ref ::rtFuncGetAttributes(struct rtFuncAttributes*, T*) "rtFuncGetAttributes (C++ API)",
 * \ref ::rtLaunchKernel(const void *func, dim3 gridDim, dim3 blockDim, void **args, size_t sharedMem, rtStream_t stream) "rtLaunchKernel (C API)",
 * ::rtSetDoubleForDevice,
 * ::rtSetDoubleForHost,
 * ::rppFuncGetAttribute
 */
extern rtError_t rtFuncGetAttributes(struct rtFuncAttributes *attr,
	const char *func);


/**
 * \brief Sets the preferred cache configuration for a device function
 *
 * On devices where the L1 cache and shared memory use the same hardware
 * resources, this sets through \p cacheConfig the preferred cache configuration
 * for the function specified via \p func. This is only a preference. The
 * runtime will use the requested configuration if possible, but it is free to
 * choose a different configuration if required to execute \p func.
 *
 * \p func is a device function symbol and must be declared as a
 * \c __global__ function. If the specified function does not exist,
 * then ::rtErrorInvalidDeviceFunction is returned. For templated functions,
 * pass the function symbol as follows: func_name<template_arg_0,...,template_arg_N>
 *
 * This setting does nothing on devices where the size of the L1 cache and
 * shared memory are fixed.
 *
 * Launching a kernel with a different preference than the most recent
 * preference setting may insert a device-side synchronization point.
 *
 * The supported cache configurations are:
 * - ::rtFuncCachePreferNone: no preference for shared memory or L1 (default)
 * - ::rtFuncCachePreferShared: prefer larger shared memory and smaller L1 cache
 * - ::rtFuncCachePreferL1: prefer larger L1 cache and smaller shared memory
 * - ::rtFuncCachePreferEqual: prefer equal size L1 cache and shared memory
 *
 * \param func        - Device function symbol
 * \param cacheConfig - Requested cache configuration
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidDeviceFunction
 * \notefnerr
 * \note_string_api_deprecation2
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * \ref ::rtFuncSetCacheConfig(T*, enum rtFuncCache) "rtFuncSetCacheConfig (C++ API)",
 * \ref ::rtFuncGetAttributes(struct rtFuncAttributes*, const void*) "rtFuncGetAttributes (C API)",
 * \ref ::rtLaunchKernel(const void *func, dim3 gridDim, dim3 blockDim, void **args, size_t sharedMem, rtStream_t stream) "rtLaunchKernel (C API)",
 * ::rtSetDoubleForDevice,
 * ::rtSetDoubleForHost,
 * ::rtThreadGetCacheConfig,
 * ::rtThreadSetCacheConfig,
 * ::rppFuncSetCacheConfig
 */
extern rtError_t rtFuncSetCacheConfig(const char *func,
	enum rtFuncCache cacheConfig);

/** @} */ /* END RPP_EXECUTION */

/*******************************************************************************
*                                                                              *
*                                                                              *
*                                                                              *
*******************************************************************************/

/**
 * \defgroup RPP_OCCUPANCY Occupancy
 *
 * ___MANBRIEF___ occupancy calculation functions of the RPP runtime API
 * (___CURRENT_FILE___) ___ENDMANBRIEF___
 *
 * This section describes the occupancy calculation functions of the RPP runtime
 * application programming interface.
 *
 *
 * @{
 */

/**
 * \brief Returns occupancy for a device function with the specified flags
 *
 * Returns in \p *numBlocks the maximum number of active blocks per
 * streaming multiprocessor for the device function.
 *
 * The \p flags parameter controls how special cases are handled. Valid flags include:
 *
 * - ::rtOccupancyDefault: keeps the default behavior as
 *   ::rtOccupancyMaxActiveBlocksPerMultiprocessor
 *
 * \param numBlocks       - Returned occupancy
 * \param func            - Kernel function for which occupancy is calculated
 * \param blockSize       - Block size the kernel is intended to be launched with
 * \param dynamicSMemSize - Per-block dynamic shared memory usage intended, in bytes
 * \param flags           - Requested behavior for the occupancy calculator
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidDevice,
 * ::rtErrorInvalidDeviceFunction,
 * ::rtErrorInvalidValue,
 * ::rtErrorUnknown,
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 */
extern rtError_t rtOccupancyMaxActiveBlocksPerMultiprocessorWithFlags(int *numBlocks,
		const void *func, int blockSize, size_t dynamicSmemSize, unsigned int flags);

/** @} */ /* END RPP_OCCUPANCY */

/*******************************************************************************
*                                                                              *
*                                                                              *
*                                                                              *
*******************************************************************************/
extern rtError_t rtProfilerInitialize(const char* configFile, const char* outputFile, rtOutputMode outputMode);
extern rtError_t rtProfilerStart(void);
extern rtError_t rtProfilerStop(void);


/*******************************************************************************
*                                                                              *
*                                                                              *
*                                                                              *
*******************************************************************************/

/**
 * \defgroup RPP_GRAPH Graph Management
 *
 * ___MANBRIEF___ graph management functions of the RPP runtime API
 * (___CURRENT_FILE___) ___ENDMANBRIEF___
 *
 * This section describes the graph management functions of RPP
 * runtime application programming interface.
 *
 * Typical flow: ::rtGraphCreate (or stream capture) -> add nodes -> ::rtGraphInstantiate
 * or ::rtGraphInstantiateWithParams -> ::rtGraphLaunch. See docs/api/graph-training-v1
 * for usage, constraints, and performance notes.
 *
 * @{
 */

/**
 * \brief Creates a graph
 *
 * Creates an empty graph, which is returned via \p pGraph.
 *
 * \param pGraph - Returns newly created graph
 * \param flags   - Graph creation flags in ::rtGraphFlags
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorMemoryAllocation
 * \note_graph_thread_safety
 * \note ::rtGraphNonBlocking uses per-node semaphores so other streams may access SRAM
 *       during graph execution; coordinate virt_sram regions or avoid virt_sram to prevent races.
 * \note Graphs captured with DFS frequency nodes may affect CDMA or kernel work on other streams.
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphAddChildGraphNode,
 * ::rtGraphAddEmptyNode,
 * ::rtGraphAddKernelNode,
 * ::rtGraphAddHostNode,
 * ::rtGraphAddMemcpyNode,
 * ::rtGraphAddMemsetNode,
 * ::rtGraphInstantiate,
 * ::rtGraphDestroy,
 * ::rtGraphGetNodes,
 * ::rtGraphGetRootNodes,
 * ::rtGraphGetEdges,
 * ::rtGraphClone
 */
extern rtError_t rtGraphCreate(rtGraph_t *pGraph, unsigned int flags);

#if 0 // willjiang, not support yet, 20230508
/**
 * \brief Creates a kernel execution node and adds it to a graph
 *
 * Creates a new kernel execution node and adds it to \p graph with \p numDependencies
 * dependencies specified via \p pDependencies and arguments specified in \p pNodeParams.
 * It is possible for \p numDependencies to be 0, in which case the node will be placed
 * at the root of the graph. \p pDependencies may not have any duplicate entries.
 * A handle to the new node will be returned in \p pGraphNode.
 *
 * The rtKernelNodeParams structure is defined as:
 *
 * \code
 *  struct rtKernelNodeParams
 *  {
 *      void* func;
 *      dim3 gridDim;
 *      dim3 blockDim;
 *      unsigned int sharedMemBytes;
 *      void **kernelParams;
 *      void **extra;
 *  };
 * \endcode
 *
 * When the graph is launched, the node will invoke kernel \p func on a (\p gridDim.x x
 * \p gridDim.y x \p gridDim.z) grid of blocks. Each block contains
 * (\p blockDim.x x \p blockDim.y x \p blockDim.z) threads.
 *
 * \p sharedMem sets the amount of dynamic shared memory that will be
 * available to each thread block.
 *
 * Kernel parameters to \p func can be specified in one of two ways:
 *
 * 1) Kernel parameters can be specified via \p kernelParams. If the kernel has N
 * parameters, then \p kernelParams needs to be an array of N pointers. Each pointer,
 * from \p kernelParams[0] to \p kernelParams[N-1], points to the region of memory from which the actual
 * parameter will be copied. The number of kernel parameters and their offsets and sizes do not need
 * to be specified as that information is retrieved directly from the kernel's image.
 *
 * 2) Kernel parameters can also be packaged by the application into a single buffer that is passed in
 * via \p extra. This places the burden on the application of knowing each kernel
 * parameter's size and alignment/padding within the buffer. The \p extra parameter exists
 * to allow this function to take additional less commonly used arguments. \p extra specifies
 * a list of names of extra settings and their corresponding values. Each extra setting name is
 * immediately followed by the corresponding value. The list must be terminated with either NULL or
 * CU_LAUNCH_PARAM_END.
 *
 * - ::CU_LAUNCH_PARAM_END, which indicates the end of the \p extra
 *   array;
 * - ::CU_LAUNCH_PARAM_BUFFER_POINTER, which specifies that the next
 *   value in \p extra will be a pointer to a buffer
 *   containing all the kernel parameters for launching kernel
 *   \p func;
 * - ::CU_LAUNCH_PARAM_BUFFER_SIZE, which specifies that the next
 *   value in \p extra will be a pointer to a size_t
 *   containing the size of the buffer specified with
 *   ::CU_LAUNCH_PARAM_BUFFER_POINTER;
 *
 * The error ::rtErrorInvalidValue will be returned if kernel parameters are specified with both
 * \p kernelParams and \p extra (i.e. both \p kernelParams and
 * \p extra are non-NULL).
 *
 * The \p kernelParams or \p extra array, as well as the argument values it points to,
 * are copied during this call.
 *
 * \note Kernels launched using graphs must not use texture and surface references. Reading or
 *       writing through any texture or surface reference is undefined behavior.
 *       This restriction does not apply to texture and surface objects.
 *
 * \param pGraphNode     - Returns newly created node
 * \param graph          - Graph to which to add the node
 * \param pDependencies    - Dependencies of the node
 * \param numDependencies - Number of dependencies
 * \param pNodeParams      - Parameters for the GPU execution node
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidDeviceFunction
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtLaunchKernel,
 * ::rtGraphKernelNodeGetParams,
 * ::rtGraphKernelNodeSetParams,
 * ::rtGraphCreate,
 * ::rtGraphDestroyNode,
 * ::rtGraphAddChildGraphNode,
 * ::rtGraphAddEmptyNode,
 * ::rtGraphAddHostNode,
 * ::rtGraphAddMemcpyNode,
 * ::rtGraphAddMemsetNode
 */
extern rtError_t rtGraphAddKernelNode(rtGraphNode_t *pGraphNode, rtGraph_t graph, const rtGraphNode_t *pDependencies, size_t numDependencies, const struct rtKernelNodeParams *pNodeParams);
#endif

/**
 * \brief Returns a kernel node's parameters
 *
 * Returns the parameters of kernel node \p node in \p pNodeParams.
 * The \p kernelParams or \p extra array returned in \p pNodeParams,
 * as well as the argument values it points to, are owned by the node.
 * This memory remains valid until the node is destroyed or its
 * parameters are modified, and should not be modified
 * directly. Use ::rtGraphKernelNodeSetParams to update the
 * parameters of this node.
 *
 * The params will contain either \p kernelParams or \p extra,
 * according to which of these was most recently set on the node.
 *
 * \param node        - Node to get the parameters for
 * \param pNodeParams - Pointer to return the parameters
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidDeviceFunction
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtLaunchKernel,
 * ::rtGraphAddKernelNode,
 * ::rtGraphKernelNodeSetParams
 */
extern rtError_t rtGraphKernelNodeGetParams(rtGraphNode_t node, struct rtKernelNodeParams *pNodeParams);


/**
 * \brief Sets a kernel node's parameters on the graph definition
 *
 * Updates the host-side graph only. Existing ::rtGraphExec_t instances are unchanged;
 * use ::rtGraphExecKernelNodeSetParams or re-instantiate to affect an executable graph.
 *
 * \param node        - Node to set the parameters for
 * \param pNodeParams - Parameters to copy
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidResourceHandle,
 * ::rtErrorMemoryAllocation
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtLaunchKernel,
 * ::rtGraphAddKernelNode,
 * ::rtGraphKernelNodeGetParams
 */
extern rtError_t rtGraphKernelNodeSetParams(rtGraphNode_t node, const struct rtKernelNodeParams *pNodeParams);

#if 0 // willjiang, not support yet, 20230508

/**
 * \brief Creates a memcpy node and adds it to a graph
 *
 * Creates a new memcpy node and adds it to \p graph with \p numDependencies
 * dependencies specified via \p pDependencies.
 * It is possible for \p numDependencies to be 0, in which case the node will be placed
 * at the root of the graph. \p pDependencies may not have any duplicate entries.
 * A handle to the new node will be returned in \p pGraphNode.
 *
 * When the graph is launched, the node will perform the memcpy described by \p pCopyParams.
 * See ::rtMemcpy3D() for a description of the structure and its restrictions.
 *
 * Memcpy nodes have some additional restrictions with regards to managed memory, if the
 * system contains at least one device which has a zero value for the device attribute
 * ::rtDevAttrConcurrentManagedAccess.
 *
 * \param pGraphNode     - Returns newly created node
 * \param graph          - Graph to which to add the node
 * \param pDependencies    - Dependencies of the node
 * \param numDependencies - Number of dependencies
 * \param pCopyParams      - Parameters for the memory copy
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtMemcpy3D,
 * ::rtGraphMemcpyNodeGetParams,
 * ::rtGraphMemcpyNodeSetParams,
 * ::rtGraphCreate,
 * ::rtGraphDestroyNode,
 * ::rtGraphAddChildGraphNode,
 * ::rtGraphAddEmptyNode,
 * ::rtGraphAddKernelNode,
 * ::rtGraphAddHostNode,
 * ::rtGraphAddMemsetNode
 */
extern rtError_t rtGraphAddMemcpyNode(rtGraphNode_t *pGraphNode, rtGraph_t graph, const rtGraphNode_t *pDependencies, size_t numDependencies, const struct rtMemcpy3DParams *pCopyParams);

#endif

/**
 * \brief Returns a memcpy node's parameters
 *
 * Returns the parameters of memcpy node \p node in \p pNodeParams.
 *
 * \param node        - Node to get the parameters for
 * \param pNodeParams - Pointer to return the parameters
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtMemcpy3D,
 * ::rtGraphAddMemcpyNode,
 * ::rtGraphMemcpyNodeSetParams
 */
extern rtError_t rtGraphMemcpyNodeGetParams(rtGraphNode_t node, struct rtMemcpy3DParams *pNodeParams);


/**
 * \brief Sets a memcpy node's parameters
 *
 * Sets the parameters of memcpy node \p node to \p pNodeParams.
 *
 * \param node        - Node to set the parameters for
 * \param pNodeParams - Parameters to copy
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtMemcpy3D,
 * ::rtGraphAddMemcpyNode,
 * ::rtGraphMemcpyNodeGetParams
 */
extern rtError_t rtGraphMemcpyNodeSetParams(rtGraphNode_t node, const struct rtMemcpy3DParams *pNodeParams);

#if 0 // willjiang, not support yet, 20230508

/**
 * \brief Creates a memset node and adds it to a graph
 *
 * Creates a new memset node and adds it to \p graph with \p numDependencies
 * dependencies specified via \p pDependencies.
 * It is possible for \p numDependencies to be 0, in which case the node will be placed
 * at the root of the graph. \p pDependencies may not have any duplicate entries.
 * A handle to the new node will be returned in \p pGraphNode.
 *
 * The element size must be 1, 2, or 4 bytes.
 * When the graph is launched, the node will perform the memset described by \p pMemsetParams.
 *
 * \param pGraphNode     - Returns newly created node
 * \param graph          - Graph to which to add the node
 * \param pDependencies    - Dependencies of the node
 * \param numDependencies - Number of dependencies
 * \param pMemsetParams    - Parameters for the memory set
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorInvalidDevice
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtMemset2D,
 * ::rtGraphMemsetNodeGetParams,
 * ::rtGraphMemsetNodeSetParams,
 * ::rtGraphCreate,
 * ::rtGraphDestroyNode,
 * ::rtGraphAddChildGraphNode,
 * ::rtGraphAddEmptyNode,
 * ::rtGraphAddKernelNode,
 * ::rtGraphAddHostNode,
 * ::rtGraphAddMemcpyNode
 */
extern rtError_t rtGraphAddMemsetNode(rtGraphNode_t *pGraphNode, rtGraph_t graph, const rtGraphNode_t *pDependencies, size_t numDependencies, const struct rtMemsetParams *pMemsetParams);

#endif

/**
 * \brief Returns a memset node's parameters
 *
 * Returns the parameters of memset node \p node in \p pNodeParams.
 *
 * \param node        - Node to get the parameters for
 * \param pNodeParams - Pointer to return the parameters
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtMemset2D,
 * ::rtGraphAddMemsetNode,
 * ::rtGraphMemsetNodeSetParams
 */
extern rtError_t rtGraphMemsetNodeGetParams(rtGraphNode_t node, struct rtMemsetParams *pNodeParams);


/**
 * \brief Sets a memset node's parameters
 *
 * Sets the parameters of memset node \p node to \p pNodeParams.
 *
 * \param node        - Node to set the parameters for
 * \param pNodeParams - Parameters to copy
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtMemset2D,
 * ::rtGraphAddMemsetNode,
 * ::rtGraphMemsetNodeGetParams
 */
extern rtError_t rtGraphMemsetNodeSetParams(rtGraphNode_t node, const struct rtMemsetParams *pNodeParams);

#if 0 // willjiang, not support yet, 20230508
/**
 * \brief Creates a host execution node and adds it to a graph
 *
 * Creates a new CPU execution node and adds it to \p graph with \p numDependencies
 * dependencies specified via \p pDependencies and arguments specified in \p pNodeParams.
 * It is possible for \p numDependencies to be 0, in which case the node will be placed
 * at the root of the graph. \p pDependencies may not have any duplicate entries.
 * A handle to the new node will be returned in \p pGraphNode.
 *
 * When the graph is launched, the node will invoke the specified CPU function.
 * Host nodes are not supported under MPS with pre-Volta GPUs.
 *
 * \param pGraphNode     - Returns newly created node
 * \param graph          - Graph to which to add the node
 * \param pDependencies    - Dependencies of the node
 * \param numDependencies - Number of dependencies
 * \param pNodeParams      - Parameters for the host node
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorNotSupported,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtLaunchHostFunc,
 * ::rtGraphHostNodeGetParams,
 * ::rtGraphHostNodeSetParams,
 * ::rtGraphCreate,
 * ::rtGraphDestroyNode,
 * ::rtGraphAddChildGraphNode,
 * ::rtGraphAddEmptyNode,
 * ::rtGraphAddKernelNode,
 * ::rtGraphAddMemcpyNode,
 * ::rtGraphAddMemsetNode
 */
extern rtError_t rtGraphAddHostNode(rtGraphNode_t *pGraphNode, rtGraph_t graph, const rtGraphNode_t *pDependencies, size_t numDependencies, const struct rtHostNodeParams *pNodeParams);
#endif

/**
 * \brief Returns a host node's parameters
 *
 * Returns the parameters of host node \p node in \p pNodeParams.
 *
 * \param node        - Node to get the parameters for
 * \param pNodeParams - Pointer to return the parameters
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtLaunchHostFunc,
 * ::rtGraphAddHostNode,
 * ::rtGraphHostNodeSetParams
 */
extern rtError_t rtGraphHostNodeGetParams(rtGraphNode_t node, struct rtHostNodeParams *pNodeParams);


/**
 * \brief Sets a host node's parameters
 *
 * Sets the parameters of host node \p node to \p nodeParams.
 *
 * \param node        - Node to set the parameters for
 * \param pNodeParams - Parameters to copy
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtLaunchHostFunc,
 * ::rtGraphAddHostNode,
 * ::rtGraphHostNodeGetParams
 */
extern rtError_t rtGraphHostNodeSetParams(rtGraphNode_t node, const struct rtHostNodeParams *pNodeParams);

#if 0 // willjiang, not support yet, 20230508
/**
 * \brief Creates a child graph node and adds it to a graph
 *
 * Creates a new node which executes an embedded graph, and adds it to \p graph with
 * \p numDependencies dependencies specified via \p pDependencies.
 * It is possible for \p numDependencies to be 0, in which case the node will be placed
 * at the root of the graph. \p pDependencies may not have any duplicate entries.
 * A handle to the new node will be returned in \p pGraphNode.
 *
 * The node executes an embedded child graph. The child graph is cloned in this call.
 *
 * \param pGraphNode     - Returns newly created node
 * \param graph          - Graph to which to add the node
 * \param pDependencies    - Dependencies of the node
 * \param numDependencies - Number of dependencies
 * \param childGraph      - The graph to clone into this node
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphChildGraphNodeGetGraph,
 * ::rtGraphCreate,
 * ::rtGraphDestroyNode,
 * ::rtGraphAddEmptyNode,
 * ::rtGraphAddKernelNode,
 * ::rtGraphAddHostNode,
 * ::rtGraphAddMemcpyNode,
 * ::rtGraphAddMemsetNode,
 * ::rtGraphClone
 */
extern rtError_t rtGraphAddChildGraphNode(rtGraphNode_t *pGraphNode, rtGraph_t graph, const rtGraphNode_t *pDependencies, size_t numDependencies, rtGraph_t childGraph);


/**
 * \brief Gets a handle to the embedded graph of a child graph node
 *
 * Gets a handle to the embedded graph in a child graph node. This call
 * does not clone the graph. Changes to the graph will be reflected in
 * the node, and the node retains ownership of the graph.
 *
 * \param node   - Node to get the embedded graph for
 * \param pGraph - Location to store a handle to the graph
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphAddChildGraphNode,
 * ::rtGraphNodeFindInClone
 */
extern rtError_t rtGraphChildGraphNodeGetGraph(rtGraphNode_t node, rtGraph_t *pGraph);


/**
 * \brief Creates an empty node and adds it to a graph
 *
 * Creates a new node which performs no operation, and adds it to \p graph with
 * \p numDependencies dependencies specified via \p pDependencies.
 * It is possible for \p numDependencies to be 0, in which case the node will be placed
 * at the root of the graph. \p pDependencies may not have any duplicate entries.
 * A handle to the new node will be returned in \p pGraphNode.
 *
 * An empty node performs no operation during execution, but can be used for
 * transitive ordering. For example, a phased execution graph with 2 groups of n
 * nodes with a barrier between them can be represented using an empty node and
 * 2*n dependency edges, rather than no empty node and n^2 dependency edges.
 *
 * \param pGraphNode     - Returns newly created node
 * \param graph          - Graph to which to add the node
 * \param pDependencies    - Dependencies of the node
 * \param numDependencies - Number of dependencies
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphCreate,
 * ::rtGraphDestroyNode,
 * ::rtGraphAddChildGraphNode,
 * ::rtGraphAddKernelNode,
 * ::rtGraphAddHostNode,
 * ::rtGraphAddMemcpyNode,
 * ::rtGraphAddMemsetNode
 */
extern rtError_t rtGraphAddEmptyNode(rtGraphNode_t *pGraphNode, rtGraph_t graph, const rtGraphNode_t *pDependencies, size_t numDependencies);


/**
 * \brief Clones a graph
 *
 * This function creates a copy of \p originalGraph and returns it in \p pGraphClone.
 * All parameters are copied into the cloned graph. The original graph may be modified
 * after this call without affecting the clone.
 *
 * Child graph nodes in the original graph are recursively copied into the clone.
 *
 * \param pGraphClone  - Returns newly created cloned graph
 * \param originalGraph - Graph to clone
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * ::rtErrorMemoryAllocation
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphCreate,
 * ::rtGraphNodeFindInClone
 */
extern rtError_t rtGraphClone(rtGraph_t *pGraphClone, rtGraph_t originalGraph);


/**
 * \brief Finds a cloned version of a node
 *
 * This function returns the node in \p clonedGraph corresponding to \p originalNode
 * in the original graph.
 *
 * \p clonedGraph must have been cloned from \p originalGraph via ::rtGraphClone.
 * \p originalNode must have been in \p originalGraph at the time of the call to
 * ::rtGraphClone, and the corresponding cloned node in \p clonedGraph must not have
 * been removed. The cloned node is then returned via \p pClonedNode.
 *
 * \param pNode  - Returns handle to the cloned node
 * \param originalNode - Handle to the original node
 * \param clonedGraph - Cloned graph to query
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphClone
 */
extern rtError_t rtGraphNodeFindInClone(rtGraphNode_t *pNode, rtGraphNode_t originalNode, rtGraph_t clonedGraph);

#endif

/**
 * \brief Returns a node's type
 *
 * Returns the node type of \p node in \p pType.
 *
 * \param node - Node to query
 * \param pType  - Pointer to return the node type
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphGetNodes,
 * ::rtGraphGetRootNodes,
 * ::rtGraphChildGraphNodeGetGraph,
 * ::rtGraphKernelNodeGetParams,
 * ::rtGraphKernelNodeSetParams,
 * ::rtGraphHostNodeGetParams,
 * ::rtGraphHostNodeSetParams,
 * ::rtGraphMemcpyNodeGetParams,
 * ::rtGraphMemcpyNodeSetParams,
 * ::rtGraphMemsetNodeGetParams,
 * ::rtGraphMemsetNodeSetParams
 */
extern rtError_t rtGraphNodeGetType(rtGraphNode_t node, enum rtGraphNodeType *pType);


/**
 * \brief Returns a graph's nodes
 *
 * Returns a list of \p graph's nodes. \p nodes may be NULL, in which case this
 * function will return the number of nodes in \p numNodes. Otherwise,
 * \p numNodes entries will be filled in. If \p numNodes is higher than the actual
 * number of nodes, the remaining entries in \p nodes will be set to NULL, and the
 * number of nodes actually obtained will be returned in \p numNodes.
 *
 * \param graph    - Graph to query
 * \param nodes    - Pointer to return the nodes
 * \param numNodes - See description
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphCreate,
 * ::rtGraphGetRootNodes,
 * ::rtGraphGetEdges,
 * ::rtGraphNodeGetType,
 * ::rtGraphNodeGetDependencies,
 * ::rtGraphNodeGetDependentNodes
 */
extern rtError_t rtGraphGetNodes(rtGraph_t graph, rtGraphNode_t *nodes, size_t *numNodes);

#if 0 // willjiang, not support yet, 20230508
/**
 * \brief Returns a graph's root nodes
 *
 * Returns a list of \p graph's root nodes. \p pRootNodes may be NULL, in which case this
 * function will return the number of root nodes in \p pNumRootNodes. Otherwise,
 * \p pNumRootNodes entries will be filled in. If \p pNumRootNodes is higher than the actual
 * number of root nodes, the remaining entries in \p pRootNodes will be set to NULL, and the
 * number of nodes actually obtained will be returned in \p pNumRootNodes.
 *
 * \param graph       - Graph to query
 * \param pRootNodes    - Pointer to return the root nodes
 * \param pNumRootNodes - See description
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphCreate,
 * ::rtGraphGetNodes,
 * ::rtGraphGetEdges,
 * ::rtGraphNodeGetType,
 * ::rtGraphNodeGetDependencies,
 * ::rtGraphNodeGetDependentNodes
 */
extern rtError_t rtGraphGetRootNodes(rtGraph_t graph, rtGraphNode_t *pRootNodes, size_t *pNumRootNodes);


/**
 * \brief Returns a graph's dependency edges
 *
 * Returns a list of \p graph's dependency edges. Edges are returned via corresponding
 * indices in \p from and \p to; that is, the node in \p to[i] has a dependency on the
 * node in \p from[i]. \p from and \p to may both be NULL, in which
 * case this function only returns the number of edges in \p numEdges. Otherwise,
 * \p numEdges entries will be filled in. If \p numEdges is higher than the actual
 * number of edges, the remaining entries in \p from and \p to will be set to NULL, and
 * the number of edges actually returned will be written to \p numEdges.
 *
 * \param graph    - Graph to get the edges from
 * \param from     - Location to return edge endpoints
 * \param to       - Location to return edge endpoints
 * \param numEdges - See description
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphGetNodes,
 * ::rtGraphGetRootNodes,
 * ::rtGraphAddDependencies,
 * ::rtGraphRemoveDependencies,
 * ::rtGraphNodeGetDependencies,
 * ::rtGraphNodeGetDependentNodes
 */
extern rtError_t rtGraphGetEdges(rtGraph_t graph, rtGraphNode_t *from, rtGraphNode_t *to, size_t *numEdges);


/**
 * \brief Returns a node's dependencies
 *
 * Returns a list of \p node's dependencies. \p pDependencies may be NULL, in which case this
 * function will return the number of dependencies in \p pNumDependencies. Otherwise,
 * \p pNumDependencies entries will be filled in. If \p pNumDependencies is higher than the actual
 * number of dependencies, the remaining entries in \p pDependencies will be set to NULL, and the
 * number of nodes actually obtained will be returned in \p pNumDependencies.
 *
 * \param node           - Node to query
 * \param pDependencies    - Pointer to return the dependencies
 * \param pNumDependencies - See description
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphNodeGetDependentNodes,
 * ::rtGraphGetNodes,
 * ::rtGraphGetRootNodes,
 * ::rtGraphGetEdges,
 * ::rtGraphAddDependencies,
 * ::rtGraphRemoveDependencies
 */
extern rtError_t rtGraphNodeGetDependencies(rtGraphNode_t node, rtGraphNode_t *pDependencies, size_t *pNumDependencies);


/**
 * \brief Returns a node's dependent nodes
 *
 * Returns a list of \p node's dependent nodes. \p pDependentNodes may be NULL, in which
 * case this function will return the number of dependent nodes in \p pNumDependentNodes.
 * Otherwise, \p pNumDependentNodes entries will be filled in. If \p pNumDependentNodes is
 * higher than the actual number of dependent nodes, the remaining entries in
 * \p pDependentNodes will be set to NULL, and the number of nodes actually obtained will
 * be returned in \p pNumDependentNodes.
 *
 * \param node             - Node to query
 * \param pDependentNodes    - Pointer to return the dependent nodes
 * \param pNumDependentNodes - See description
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphNodeGetDependencies,
 * ::rtGraphGetNodes,
 * ::rtGraphGetRootNodes,
 * ::rtGraphGetEdges,
 * ::rtGraphAddDependencies,
 * ::rtGraphRemoveDependencies
 */
extern rtError_t rtGraphNodeGetDependentNodes(rtGraphNode_t node, rtGraphNode_t *pDependentNodes, size_t *pNumDependentNodes);


/**
 * \brief Adds dependency edges to a graph.
 *
 * The number of dependencies to be added is defined by \p numDependencies
 * Elements in \p pFrom and \p pTo at corresponding indices define a dependency.
 * Each node in \p pFrom and \p pTo must belong to \p graph.
 *
 * If \p numDependencies is 0, elements in \p pFrom and \p pTo will be ignored.
 * Specifying an existing dependency will return an error.
 *
 * \param graph - Graph to which dependencies are added
 * \param from - Array of nodes that provide the dependencies
 * \param to - Array of dependent nodes
 * \param numDependencies - Number of dependencies to be added
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphRemoveDependencies,
 * ::rtGraphGetEdges,
 * ::rtGraphNodeGetDependencies,
 * ::rtGraphNodeGetDependentNodes
 */
extern rtError_t rtGraphAddDependencies(rtGraph_t graph, const rtGraphNode_t *from, const rtGraphNode_t *to, size_t numDependencies);


/**
 * \brief Removes dependency edges from a graph.
 *
 * The number of \p pDependencies to be removed is defined by \p numDependencies.
 * Elements in \p pFrom and \p pTo at corresponding indices define a dependency.
 * Each node in \p pFrom and \p pTo must belong to \p graph.
 *
 * If \p numDependencies is 0, elements in \p pFrom and \p pTo will be ignored.
 * Specifying a non-existing dependency will return an error.
 *
 * \param graph - Graph from which to remove dependencies
 * \param from - Array of nodes that provide the dependencies
 * \param to - Array of dependent nodes
 * \param numDependencies - Number of dependencies to be removed
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphAddDependencies,
 * ::rtGraphGetEdges,
 * ::rtGraphNodeGetDependencies,
 * ::rtGraphNodeGetDependentNodes
 */
extern rtError_t rtGraphRemoveDependencies(rtGraph_t graph, const rtGraphNode_t *from, const rtGraphNode_t *to, size_t numDependencies);


/**
 * \brief Remove a node from the graph
 *
 * Removes \p node from its graph. This operation also severs any dependencies of other nodes
 * on \p node and vice versa.
 *
 * \param node  - Node to remove
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphAddChildGraphNode,
 * ::rtGraphAddEmptyNode,
 * ::rtGraphAddKernelNode,
 * ::rtGraphAddHostNode,
 * ::rtGraphAddMemcpyNode,
 * ::rtGraphAddMemsetNode
 */
extern rtError_t rtGraphDestroyNode(rtGraphNode_t node);

#endif

/**
 * \brief Creates an executable graph from a graph
 *
 * Instantiates \p graph as an executable graph. The graph is validated for any
 * structural constraints or intra-node constraints which were not previously
 * validated. If instantiation is successful, a handle to the instantiated graph
 * is returned in \p pGraphExec.
 *
 * If there are any errors, diagnostic information may be returned in \p pErrorNode and
 * \p pLogBuffer. This is the primary way to inspect instantiation errors. The output
 * will be null terminated unless the diagnostics overflow
 * the buffer. In this case, they will be truncated, and the last byte can be
 * inspected to determine if truncation occurred.
 *
 * \param pGraphExec - Returns instantiated graph
 * \param graph      - Graph to instantiate
 * \param pErrorNode - In case of an instantiation error, this may be modified to
 *                      indicate a node contributing to the error
 * \param pLogBuffer   - A character buffer to store diagnostic messages
 * \param bufferSize  - Size of the log buffer in bytes
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphCreate,
 * ::rtGraphLaunch,
 * ::rtGraphExecDestroy
 */
extern rtError_t rtGraphInstantiate(rtGraphExec_t *pGraphExec, rtGraph_t graph, rtGraphNode_t *pErrorNode, char *pLogBuffer, size_t bufferSize);

/**
 * \brief Allocates device memory for an external graph resource pool
 *
 * \param dptr     - Returns device pointer
 * \param bytesize - Pool size in bytes
 * \param type     - Pool type (::rtGraphResourceType)
 *
 * \sa ::rtGraphResourceFree, ::rtGraphInstantiateWithParams
 */
extern rtError_t rtGraphResourceAlloc(uint64_t *dptr, size_t bytesize, rtGraphResourceType type);

/**
 * \brief Frees memory allocated by ::rtGraphResourceAlloc
 *
 * \sa ::rtGraphResourceAlloc
 */
extern rtError_t rtGraphResourceFree(uint64_t dptr, rtGraphResourceType type);

/**
 * \brief Instantiates a graph with caller-supplied resource pools
 *
 * \param phGraphExec        - Returns instantiated graphexec
 * \param hGraph             - Graph to instantiate
 * \param pInstantiateParams - Resource pools (see ::rtGraphInstantiateParams_t)
 *
 * \sa ::rtGraphInstantiate, ::rtGraphExecGetParams
 */
extern rtError_t rtGraphInstantiateWithParams(rtGraphExec_t *phGraphExec, rtGraph_t hGraph, const struct rtGraphInstantiateParams_t *pInstantiateParams);

/**
 * \brief Returns instantiate parameters stored on a graphexec
 *
 * \sa ::rtGraphInstantiateWithParams
 */
extern rtError_t rtGraphExecGetParams(rtGraphExec_t hGraphExec, struct rtGraphInstantiateParams_t *pInstantiateParams);

/**
 * \brief Serialize an executable graph
 *
 * Serialize the executable graph specified by \p hGraphExec, as well
 * as all of its executable nodes. If the executable graph is
 * in-flight, it will not be terminated, but rather freed
 * asynchronously on completion.
 *
 * \param hGraphExec - Executable graph to Serialize
 * \param name       - Folder to save executable graph
 * \param flag       - Serialization mode flags
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphCreate,
 * ::rtGraphLaunch,
 * ::rtGraphExecDestroy
 */
extern rtError_t rtGraphExecSerializeParams(rtGraphExec_t hGraphExec, uint32_t type, uint32_t size, void* data);
/**
 * \brief Serializes an executable graph to disk
 *
 * Writes \p hGraphExec and its executable nodes under folder \p gpath.
 *
 * \param hGraphExec - Executable graph to serialize
 * \param gpath      - Output folder path
 * \param flag       - Serialization mode flags
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphCreate,
 * ::rtGraphLaunch,
 * ::rtGraphExecDestroy
 */
extern rtError_t rtGraphExecSerialize(rtGraphExec_t hGraphExec, char* gpath, uint32_t flag);

/**
 * \brief Sets the parameters for a kernel node in the given graphExec
 *
 * Sets kernel parameters on \p hGraphExec only; the host graph and other graphexec
 * instances are unchanged. \p node must remain in the source graph; \p func in
 * \p pNodeParams must match the instantiate-time function. Changes apply on the next
 * launch; in-flight launches are unaffected.
 *
 * \param hGraphExec  - The executable graph in which to set the specified node
 * \param node        - kernel node from the graph from which graphExec was instantiated
 * \param pNodeParams - Updated Parameters to set
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphAddKernelNode,
 * ::rtGraphKernelNodeSetParams,
 * ::rtGraphInstantiate
 */
extern rtError_t rtGraphExecKernelNodeSetParams(rtGraphExec_t hGraphExec, rtGraphNode_t node, const struct rtKernelNodeParams *pNodeParams);

/**
 * \brief Sets the parameters for a memcpy node in the given graphExec
 *
 * Sets memcpy parameters on \p hGraphExec only. Source and destination must remain in
 * the same context as at instantiate, 1-dimensional, with unchanged mapping and non-zero
 * length. Does not modify the host graph or other graphexec instances.
 *
 * \param hGraphExec  - The executable graph in which to set the specified node
 * \param node        - Memcpy node from the graph from which graphExec was instantiated
 * \param pNodeParams - Updated Parameters to set
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphAddKernelNode,
 * ::rtGraphKernelNodeSetParams,
 * ::rtGraphInstantiate
 */
extern rtError_t rtGraphExecMemcpyNodeSetParams(rtGraphExec_t hGraphExec, rtGraphNode_t node, const struct rtMemcpy3DParams *pNodeParams);

#if 0 // willjiang, not support yet, 20230508
/**
 * \brief Sets the parameters for a memset node in the given graphExec
 *
 * Sets the parameters of a memset node in an executable graph \p hGraphExec.
 * The node is identified by the corresponding node \p node in the
 * non-executable graph, from which the executable graph was instantiated.
 *
 * The modifications take effect at the next launch of \p hGraphExec. Already
 * enqueued or running launches of \p hGraphExec are not affected by this call.
 * \p node is also not modified by this call.
 *
 * \param hGraphExec  - The executable graph in which to set the specified node
 * \param node        - Memset node from the graph from which graphExec was instantiated
 * \param pNodeParams - Updated Parameters to set
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphAddKernelNode,
 * ::rtGraphKernelNodeSetParams,
 * ::rtGraphInstantiate
 */
extern rtError_t rtGraphExecMemsetNodeSetParams(rtGraphExec_t hGraphExec, rtGraphNode_t node, const struct rtMemsetParams *pNodeParams);


/**
 * \brief Sets the parameters for a host node in the given graphExec
 *
 * Sets the parameters of a host node in an executable graph \p hGraphExec.
 * The node is identified by the corresponding node \p node in the
 * non-executable graph, from which the executable graph was instantiated.
 *
 * \p node must not have been removed from the original graph. The \p fn field
 * of \p nodeParams cannot be modified and must match the original value.
 * All other values can be modified.
 *
 * The modifications take effect at the next launch of \p hGraphExec. Already
 * enqueued or running launches of \p hGraphExec are not affected by this call.
 * \p node is also not modified by this call.
 *
 * \param hGraphExec  - The executable graph in which to set the specified node
 * \param node        - Host node from the graph from which graphExec was instantiated
 * \param pNodeParams - Updated Parameters to set
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue,
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphAddKernelNode,
 * ::rtGraphKernelNodeSetParams,
 * ::rtGraphInstantiate
 */
extern rtError_t rtGraphExecHostNodeSetParams(rtGraphExec_t hGraphExec, rtGraphNode_t node, const struct rtHostNodeParams *pNodeParams);
#endif

/**
 * \brief Launches an executable graph in a stream
 *
 * Executes \p graphExec in \p stream. Only one in-flight launch per \p graphExec is allowed;
 * a second launch blocks until the previous completes. For overlap, instantiate the same
 * graph into multiple ::rtGraphExec_t handles. Launch is ordered on \p stream.
 *
 * \param graphExec - Executable graph to launch
 * \param stream    - Stream in which to launch the graph
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphInstantiate,
 * ::rtGraphExecDestroy
 */
extern rtError_t rtGraphLaunch(rtGraphExec_t graphExec, rtStream_t stream);


/**
 * \brief Destroys an executable graph
 *
 * Destroys the executable graph specified by \p graphExec.
 *
 * \param graphExec - Executable graph to destroy
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphInstantiate,
 * ::rtGraphLaunch
 */
extern rtError_t rtGraphExecDestroy(rtGraphExec_t graphExec);


/**
 * \brief Destroys a graph
 *
 * Destroys \p graph and its nodes when no ::rtGraphExec_t instances derived from it remain;
 * otherwise destruction is deferred until the last graphexec is destroyed.
 *
 * \param graph - Graph to destroy
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_graph_thread_safety
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtGraphCreate
 */
extern rtError_t rtGraphDestroy(rtGraph_t graph);

/** @} */ /* END RPP_GRAPH */

/*******************************************************************************
*                                                                              *
*                                                                              *
*                                                                              *
*******************************************************************************/

/**
 * \defgroup RPP_EXTRES_INTEROP External Resource Interoperability
 *
 * ___MANBRIEF___ External resource interoperability functions of the RPP runtime API
 * (___CURRENT_FILE___) ___ENDMANBRIEF___
 *
 * This section describes the external resource interoperability functions of the RPP
 * runtime application programming interface.
 *
 * @{
 */

#if 0 // willjiang, not support yet, 20230508
/**
 * \brief Imports an external memory object
 *
 * Imports an externally allocated memory object and returns
 * a handle to that in \p extMem_out.
 *
 * The properties of the handle being imported must be described in
 * \p memHandleDesc. The ::rtExternalMemoryHandleDesc structure
 * is defined as follows:
 *
 * \code
        typedef struct rtExternalMemoryHandleDesc_st {
            rtExternalMemoryHandleType type;
            union {
                int fd;
                struct {
                    void *handle;
                    const void *name;
                } win32;
            } handle;
            unsigned long long size;
            unsigned int flags;
        } rtExternalMemoryHandleDesc;
 * \endcode
 *
 * where ::rtExternalMemoryHandleDesc::type specifies the type
 * of handle being imported. ::rtExternalMemoryHandleType is
 * defined as:
 *
 * \code
        enum rtExternalMemoryHandleType {
            // 0-8 reserved
            rtExternalMemoryHandleTypeVebuf = 9,
        };
 * \endcode
 *
 * The size of the memory object must be specified in
 * ::rtExternalMemoryHandleDesc::size.
 *
 * Specifying the flag ::rtExternalMemoryDedicated in
 * ::rtExternalMemoryHandleDesc::flags indicates that the
 * resource is a dedicated resource. The definition of what a
 * dedicated resource is outside the scope of this extension.
 *
 * \param extMem_out    - Returned handle to an external memory object
 * \param memHandleDesc - Memory import handle descriptor
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidResourceHandle
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \note If the Vulkan memory imported into RPP is mapped on the CPU then the
 * application must use vkInvalidateMappedMemoryRanges/vkFlushMappedMemoryRanges
 * as well as appropriate Vulkan pipeline barriers to maintain coherence between
 * CPU and GPU. For more information on these APIs, please refer to "Synchronization
 * and Cache Control" chapter from Vulkan specification.
 *
 * \sa ::rtDestroyExternalMemory,
 * ::rtExternalMemoryGetMappedBuffer,
 * ::rtExternalMemoryGetMappedMipmappedArray
 */
extern rtError_t rtImportExternalMemory(rtExtMem_t *extMem_out, const struct rtExternalMemoryHandleDesc *memHandleDesc);

#endif

/**
 * \brief Get an implicit external memory object by type
 *
 * Get an implicit externally allocated memory object by \p type and returns
 * a handle to that in \p extMem_out.
 *
 * where ::rtExternalMemoryHandleDesc::type specifies the type
 * of handle being imported. ::rtExternalMemoryHandleType is
 * defined as:
 *
 * \code
        enum rtExternalMemoryHandleType {
            // 0-8 reserved
            rtExternalMemoryHandleTypeVebuf = 9,
        };
 * \endcode
 *
 * \param extMem_out    - Returned handle to an external memory object
 * \param type - Type of implicit external memory object
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidResourceHandle
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 *
 * \sa ::rtDestroyExternalMemory,
 * ::rtExternalMemoryGetMappedBuffer,
 * ::rtExternalMemoryGetMappedMipmappedArray
 */
extern rtError_t rtGetExternalMemoryObjectByType(rtExtMem_t *extMem_out, const enum rtExternalMemoryHandleType type);

/**
 * \brief Maps a buffer onto an imported memory object
 *
 * Maps a buffer onto an imported memory object and returns a device
 * pointer in \p devPtr.
 *
 * The properties of the buffer being mapped must be described in
 * \p bufferDesc. The ::rtExternalMemoryBufferDesc structure is
 * defined as follows:
 *
 * \code
        struct rtExternalMemoryBufferDesc {
            unsigned long long offset;
            unsigned long long size;
            unsigned int flags;
        };
 * \endcode
 *
 * where ::rtExternalMemoryBufferDesc::flags equals to 0 that the
 * ::rtExternalMemoryBufferDesc::offset is the offset in
 * the memory object where the buffer's base address is.
 * where ::rtExternalMemoryBufferDesc::flags equals to 1 that the
 * ::rtExternalMemoryBufferDesc::offset is the absolute address.
 * ::rtExternalMemoryBufferDesc::size is the size of the buffer.
 *
 * The offset and size have to be suitably aligned to match the
 * requirements of the external API. Mapping two buffers whose ranges
 * overlap may or may not result in the same virtual address being
 * returned for the overlapped portion. In such cases, the application
 * must ensure that all accesses to that region from the GPU are
 * volatile. Otherwise writes made via one address are not guaranteed
 * to be visible via the other address, even if they're issued by the
 * same thread. It is recommended that applications map the combined
 * range instead of mapping separate buffers and then apply the
 * appropriate offsets to the returned pointer to derive the
 * individual buffers.
 *
 * The returned pointer \p devPtr must be freed using ::rtFree.
 *
 * \param devPtr     - Returned device pointer to buffer
 * \param extMem     - Handle to external memory object
 * \param bufferDesc - Buffer descriptor
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidResourceHandle
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtImportExternalMemory
 * ::rtDestroyExternalMemory,
 * ::rtExternalMemoryGetMappedMipmappedArray
 */
extern rtError_t rtExternalMemoryGetMappedBuffer(void **devPtr, rtExtMem_t extMem,
  const struct rtExternalMemoryBufferDesc *bufferDesc);

/**
 * \brief Destroys an external memory object.
 *
 * Destroys the specified external memory object. Any existing buffers
 * and RPP mipmapped arrays mapped onto this object must no longer be
 * used and must be explicitly freed using ::rtFree and
 * ::rtFreeMipmappedArray respectively.
 *
 * \param extMem - External memory object to be destroyed
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidResourceHandle
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa ::rtImportExternalMemory
 * ::rtExternalMemoryGetMappedBuffer,
 * ::rtExternalMemoryGetMappedMipmappedArray
 */
extern rtError_t rtDestroyExternalMemory(rtExtMem_t extMem);

/** @} */ /* END RPP_EXTRES_INTEROP */


/*******************************************************************************
*                                                                              *
*                                                                              *
*                                                                              *
*******************************************************************************/
/**
 * \defgroup RPP__VERSION Version Management
 *
 * @{
 */

/**
 * \brief Returns the latest version of RPP supported by the driver
 *
 * Returns in \p *driverVersion the latest version of RPP supported by
 * the driver. The version is returned as (1000 &times; major + 10 &times; minor).
 * For example, RPP 1.2 would be represented by 1020. If no driver is installed,
 * then 0 is returned as the driver version.
 *
 * This function automatically returns ::rtErrorInvalidValue
 * if \p driverVersion is NULL.
 *
 * \param driverVersion - Returns the RPP driver version.
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \notefnerr
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtRuntimeGetVersion,
 * ::rppDriverGetVersion
 */
extern rtError_t rtDriverGetVersion(int *driverVersion);


/**
 * \brief Returns the RPP Runtime version
 *
 * Returns in \p *runtimeVersion the version number of the current RPP
 * Runtime instance. The version is returned as
 * (1000 &times; major + 10 &times; minor). For example,
 * RPP 1.2 would be represented by 1020.
 *
 * This function automatically returns ::rtErrorInvalidValue if
 * the \p runtimeVersion argument is NULL.
 *
 * \param runtimeVersion - Returns the RPP Runtime version.
 *
 * \return
 * ::rtSuccess,
 * ::rtErrorInvalidValue
 * \note_init_rt
 * \note_callback
 *
 * \sa
 * ::rtDriverGetVersion,
 * ::rppDriverGetVersion
 */
extern rtError_t rtRuntimeGetVersion(int *runtimeVersion);
//extern rtError_t rtGetExportTable(const void **ppExportTable,
//	const rtUUID_t *pExportTableId);

// extern rtError_t rtCodecCreate(rtCodec_t codec);
// extern rtError_t rtCodecDestroy(rtCodec_t codec);

/** @} */ /* END RPP__VERSION */


#ifdef __cplusplus
}
#endif

#endif
