// memcpy_2d_rpp.cpp
#include "ggml-rpp/rpp_kernel_ctx.h"
#include "ggml-rpp/rpp_kernel_utils.h"
#include "rpp_drv_api.h"
#include "rpp_mul/src/rpp_kernel_block.h"
#include "rpp_mul/src/rpp_kernel_param.h"

#include <assert.h>
#include <rpp_runtime.h>

#include <cstdint>
#include <cstring>
#include <iostream>
#include <mutex>
#include <vector>

inline void get_tile_info(int C, int H, int W, int & num_of_tiles, int & elements_per_tile) {
    num_of_tiles      = C;
    elements_per_tile = H * W;
    if (H * W > MAX_TILE_SIZE) {
        throw std::runtime_error("Elementwise Tensor Size Too Big");
    }
}

inline int rpp_elementwise_round_up(int a) {
    return (a + 511) / 512 * 512 + 512;
}

inline int rpp_elementwise_round_up_to_32(int a) {
    return (a + 31) / 32 * 32;
}

inline RPPdeviceptr rpp_elementwise_prepare_reciprocal_lut_workspace(rpp_kernel_context & ctx) {
    constexpr int reciprocal_table_elements = 65536;
    constexpr int reciprocal_table_bytes    = reciprocal_table_elements * (int) sizeof(uint16_t);
    rpp_dev_lut_key key{};
    key.kind  = rpp_dev_lut_kind::mul_lut;
    key.bytes = (size_t) reciprocal_table_bytes;

    RPPdeviceptr managed_workspace =
        rpp_dev_resource_manager::instance().get_or_create_lut_workspace(
            ctx.device, key, [](RPPdeviceptr workspace, size_t bytes) {
                std::vector<uint16_t> reciprocal_table(reciprocal_table_elements);
                for (uint32_t i = 0; i < (uint32_t) reciprocal_table_elements; ++i) {
                    uint32_t bits = i << 16;
                    float    value;
                    std::memcpy(&value, &bits, sizeof(value));
                    reciprocal_table[i] = rpp::bfloat16::round_to_bfloat16(1.0f / value).value;
                }
                reciprocal_table[0]      = 0;
                reciprocal_table[0x8000] = 0;
                if (rtMemcpy((void *) workspace, reciprocal_table.data(), bytes, rtMemcpyHostToDevice) != rtSuccess) {
                    throw std::runtime_error("failed to initialize Elementwise reciprocal LUT");
                }
            });
    return rpp_bind_managed_lut_workspace(ctx, managed_workspace, key.bytes);
}

inline bool rpp_elementwise_input1_is_row_broadcast(int axis) {
    return axis == 1 || axis == 6 || axis == 7 || axis == 8;
}

inline bool rpp_elementwise_input1_is_scalar_broadcast(int axis) {
    return axis == 8;
}

inline bool rpp_elementwise_input1_is_materialized_row_broadcast(int axis) {
    return axis == 1 || axis == 6 || axis == 7;
}

inline int rpp_elementwise_get_input1_bytes(int axis, int H, int W, int in1_bytes_per_element) {
    if (axis == -1 || axis == 0) {
        return H * W * in1_bytes_per_element;
    }
    if (rpp_elementwise_input1_is_scalar_broadcast(axis)) {
        return H * W * in1_bytes_per_element;
    }
    if (rpp_elementwise_input1_is_materialized_row_broadcast(axis)) {
        return H * W * in1_bytes_per_element;
    }
    if (rpp_elementwise_input1_is_row_broadcast(axis)) {
        return W * in1_bytes_per_element;
    }
    if (axis == 2) {
        return H * in1_bytes_per_element;
    }
    throw std::runtime_error("Unsupported elementwise broadcast axis");
}

inline int rpp_elementwise_get_tile_sram_bytes(int tile_H,
                                               int W,
                                               int axis,
                                               int in0_bytes_per_element,
                                               int in1_bytes_per_element,
                                               int out_bytes_per_element,
                                               int reciprocal_table_bytes) {
    const int  padded_W             = rpp_elementwise_round_up_to_32(W);
    const bool use_row_tail_padding = padded_W != W;

    if (use_row_tail_padding) {
        assert(axis != 2);
        assert(padded_W < 8192);

        const int row_bytes_bf16   = padded_W * (int) sizeof(uint16_t);
        int       total_sram_bytes = reciprocal_table_bytes;

        if (in0_bytes_per_element == (int) sizeof(float)) {
            total_sram_bytes += rpp_elementwise_round_up(tile_H * W * (int) sizeof(float));
        }
        if (in1_bytes_per_element == (int) sizeof(float)) {
            total_sram_bytes +=
                rpp_elementwise_round_up(rpp_elementwise_get_input1_bytes(axis, tile_H, W, (int) sizeof(float)));
        }

        total_sram_bytes += rpp_elementwise_round_up(tile_H * row_bytes_bf16);
        total_sram_bytes +=
            rpp_elementwise_round_up((axis == -1 || axis == 0) ? tile_H * row_bytes_bf16 : row_bytes_bf16);
        total_sram_bytes += rpp_elementwise_round_up(tile_H * row_bytes_bf16);

        if (out_bytes_per_element == (int) sizeof(float) && in0_bytes_per_element != (int) sizeof(float) &&
            in1_bytes_per_element != (int) sizeof(float)) {
            total_sram_bytes += rpp_elementwise_round_up(tile_H * W * (int) sizeof(float));
        }

        return total_sram_bytes;
    }

    const int sizeA = tile_H * W * in0_bytes_per_element;
    const int sizeB = rpp_elementwise_get_input1_bytes(axis, tile_H, W, in1_bytes_per_element);
    const int sizeC = tile_H * W * out_bytes_per_element;
    return reciprocal_table_bytes + rpp_elementwise_round_up(sizeA) + rpp_elementwise_round_up(sizeB) +
           rpp_elementwise_round_up(sizeC);
}

inline int rpp_elementwise_get_max_tile_rows(int H,
                                             int W,
                                             int axis,
                                             int in0_bytes_per_element,
                                             int in1_bytes_per_element,
                                             int out_bytes_per_element,
                                             int reciprocal_table_bytes,
                                             int sram_limit) {
    int lo = 0;
    int hi = H;

    while (lo < hi) {
        const int mid              = (lo + hi + 1) / 2;
        const int total_sram_bytes = rpp_elementwise_get_tile_sram_bytes(
            mid, W, axis, in0_bytes_per_element, in1_bytes_per_element, out_bytes_per_element, reciprocal_table_bytes);
        if (total_sram_bytes <= sram_limit) {
            lo = mid;
        } else {
            hi = mid - 1;
        }
    }

    if (lo <= 0) {
        std::cerr << "SRAM overflow: even one row does not fit in SRAM\n";
        std::abort();
    }

    return lo;
}

inline int rpp_elementwise_get_mul_bc_input1_bytes(int axis, int W, int in1_bytes_per_element) {
    return rpp_elementwise_input1_is_scalar_broadcast(axis) ? in1_bytes_per_element : W * in1_bytes_per_element;
}

inline int rpp_elementwise_get_mul_bc_tile_sram_bytes(int tile_H,
                                                      int W,
                                                      int axis,
                                                      int in0_bytes_per_element,
                                                      int in1_bytes_per_element,
                                                      int out_bytes_per_element) {
    const int  padded_W             = rpp_elementwise_round_up_to_32(W);
    const bool use_row_tail_padding = padded_W != W;
    const int  input1_bytes         = rpp_elementwise_get_mul_bc_input1_bytes(axis, W, in1_bytes_per_element);

    if (use_row_tail_padding) {
        const int row_bytes_bf16 = padded_W * (int) sizeof(uint16_t);
        int       total          = 0;
        if (in0_bytes_per_element == (int) sizeof(float)) {
            total += rpp_elementwise_round_up(tile_H * W * (int) sizeof(float));
        }
        if (in1_bytes_per_element == (int) sizeof(float)) {
            total += rpp_elementwise_round_up(input1_bytes);
        }
        total += rpp_elementwise_round_up(tile_H * row_bytes_bf16);
        total += rpp_elementwise_round_up(rpp_elementwise_input1_is_scalar_broadcast(axis) ?
                                              (int) sizeof(uint16_t) :
                                              row_bytes_bf16);
        total += rpp_elementwise_round_up(tile_H * row_bytes_bf16);
        if (out_bytes_per_element == (int) sizeof(float) && in0_bytes_per_element != (int) sizeof(float) &&
            in1_bytes_per_element != (int) sizeof(float)) {
            total += rpp_elementwise_round_up(tile_H * W * (int) sizeof(float));
        }
        return total;
    }

    const int sizeA = tile_H * W * in0_bytes_per_element;
    const int sizeB = input1_bytes;
    const int sizeC = tile_H * W * out_bytes_per_element;
    return rpp_elementwise_round_up(sizeA) + rpp_elementwise_round_up(sizeB) + rpp_elementwise_round_up(sizeC);
}

inline int rpp_elementwise_get_mul_bc_max_tile_rows(int H,
                                                    int W,
                                                    int axis,
                                                    int in0_bytes_per_element,
                                                    int in1_bytes_per_element,
                                                    int out_bytes_per_element,
                                                    int sram_limit) {
    int lo = 0;
    int hi = H;
    while (lo < hi) {
        const int mid = (lo + hi + 1) / 2;
        const int total_sram_bytes =
            rpp_elementwise_get_mul_bc_tile_sram_bytes(mid, W, axis, in0_bytes_per_element, in1_bytes_per_element,
                                                       out_bytes_per_element);
        if (total_sram_bytes <= sram_limit) {
            lo = mid;
        } else {
            hi = mid - 1;
        }
    }
    if (lo <= 0) {
        std::cerr << "SRAM overflow: even one MUL broadcast row does not fit in SRAM\n";
        std::abort();
    }
    return lo;
}

inline void rpp_elementwise_build_mul_broadcast(rpp_kernel_context & ctx,
                                                int                  C,
                                                int                  H,
                                                int                  W,
                                                int                  axis,
                                                int                  in0_bytes_per_element,
                                                int                  in1_bytes_per_element,
                                                int                  out_bytes_per_element,
                                                int                  is_instantial = 1) {
    dim3                  threadsPerBlock;
    dim3                  blocksPerGrid;
    std::vector<uint32_t> params;
    RPPdeviceptr          devA;
    RPPdeviceptr          devB;

    if (axis <= 2 || axis == 6 || axis == 8) {
        devA = ctx.dev_in[0];
        devB = ctx.dev_in[1];
    } else {
        devA                  = ctx.dev_in[1];
        devB                  = ctx.dev_in[0];
        int tmp               = in1_bytes_per_element;
        in1_bytes_per_element = in0_bytes_per_element;
        in0_bytes_per_element = tmp;
        if (axis != 7) {
            axis = axis - 3;
        }
    }

    const bool scalar_broadcast = rpp_elementwise_input1_is_scalar_broadcast(axis);
    const bool row_broadcast    = rpp_elementwise_input1_is_materialized_row_broadcast(axis);
    if (!scalar_broadcast && !row_broadcast) {
        throw std::runtime_error("Unsupported MUL broadcast axis");
    }

    RPPdeviceptr devC = ctx.dev_out[0];

    rppStreamBeginCapture(ctx.kernelStream, RPP_STREAM_CAPTURE_MODE_GLOBAL);
    rpp_module_load_once(ctx.rppBinMod, "rpp_kernel/elementwise.o");

    RPPdeviceptr sram_base            = ctx.virtual_sram_base;
    const int    padded_W             = rpp_elementwise_round_up_to_32(W);
    const bool   use_row_tail_padding = padded_W != W;
    const int    SRAM_LIMIT           = 22 * 1024 * 1024;
    const int    max_tile_h           = rpp_elementwise_get_mul_bc_max_tile_rows(
        H, W, axis, in0_bytes_per_element, in1_bytes_per_element, out_bytes_per_element, SRAM_LIMIT);

    for (int c = 0; c < C; ++c) {
        const size_t devA_offset_base = (size_t) c * (size_t) H * (size_t) W * (size_t) in0_bytes_per_element;
        size_t       devB_offset_base = 0;
        if (axis == 1) {
            devB_offset_base = (size_t) c * (size_t) W * (size_t) in1_bytes_per_element;
        }
        const size_t devC_offset_base = (size_t) c * (size_t) H * (size_t) W * (size_t) out_bytes_per_element;

        for (int h_begin = 0; h_begin < H; h_begin += max_tile_h) {
            const int    tile_H       = std::min(max_tile_h, H - h_begin);
            const int    sizeA        = tile_H * W * in0_bytes_per_element;
            const int    sizeB        = rpp_elementwise_get_mul_bc_input1_bytes(axis, W, in1_bytes_per_element);
            const int    sizeC        = tile_H * W * out_bytes_per_element;
            const size_t devA_offset  = devA_offset_base + (size_t) h_begin * (size_t) W * in0_bytes_per_element;
            const size_t devB_offset  = devB_offset_base;
            const size_t devC_offset  = devC_offset_base + (size_t) h_begin * (size_t) W * out_bytes_per_element;

            if (use_row_tail_padding) {
                assert(padded_W < 8192);
                const int row_bytes_bf16 = padded_W * (int) sizeof(uint16_t);
                int       sram_cursor    = 0;

                RPPdeviceptr sramACompact = 0;
                if (in0_bytes_per_element == (int) sizeof(float)) {
                    sramACompact = sram_base + sram_cursor;
                    sram_cursor += rpp_elementwise_round_up(sizeA);
                }

                RPPdeviceptr sramBCompact = 0;
                if (in1_bytes_per_element == (int) sizeof(float)) {
                    sramBCompact = sram_base + sram_cursor;
                    sram_cursor += rpp_elementwise_round_up(sizeB);
                }

                RPPdeviceptr sramAPadded = sram_base + sram_cursor;
                sram_cursor += rpp_elementwise_round_up(tile_H * row_bytes_bf16);
                RPPdeviceptr sramBPadded = sram_base + sram_cursor;
                sram_cursor += rpp_elementwise_round_up(scalar_broadcast ? (int) sizeof(uint16_t) : row_bytes_bf16);
                RPPdeviceptr sramOutPadded = sram_base + sram_cursor;
                sram_cursor += rpp_elementwise_round_up(tile_H * row_bytes_bf16);

                RPPdeviceptr sramOutCompact = 0;
                if (out_bytes_per_element == (int) sizeof(float)) {
                    if (sramACompact != 0) {
                        sramOutCompact = sramACompact;
                    } else if (sramBCompact != 0) {
                        sramOutCompact = sramBCompact;
                    } else {
                        sramOutCompact = sram_base + sram_cursor;
                        sram_cursor += rpp_elementwise_round_up(sizeC);
                    }
                }
                assert(sram_cursor <= SRAM_LIMIT);

                auto copy_rows_from_dev = [&](RPPdeviceptr sramDst, RPPdeviceptr devSrc, int rows, int elem_bytes) {
                    for (int h = 0; h < rows; ++h) {
                        rtMemcpyAsync((void *) (sramDst + (RPPdeviceptr) h * row_bytes_bf16),
                                      (const void *) (devSrc + (RPPdeviceptr) h * W * elem_bytes), W * elem_bytes,
                                      rtMemcpyDeviceToSram, ctx.kernelStream);
                    }
                };
                auto convert_rows_f32_to_bf16 = [&](RPPdeviceptr sramSrcCompact, RPPdeviceptr sramDstPadded, int rows) {
                    for (int h = 0; h < rows; ++h) {
                        calc_tbdim_flattern(1, W, threadsPerBlock, blocksPerGrid);
                        params.clear();
                        cvt_kernel_param_init(
                            threadsPerBlock, (uint32_t) (sramSrcCompact + (RPPdeviceptr) h * W * (int) sizeof(float)),
                            (uint32_t) (sramDstPadded + (RPPdeviceptr) h * row_bytes_bf16), kFLOAT, kBF16, params);
                        launchWrapperAysnc("opt_vector_cvt_32_16", blocksPerGrid, threadsPerBlock, params,
                                           ctx.rppBinMod, ctx.kernelStream);
                    }
                };

                if (in0_bytes_per_element == (int) sizeof(float)) {
                    rtMemcpyAsync((void *) sramACompact, (const void *) (devA + (RPPdeviceptr) devA_offset), sizeA,
                                  rtMemcpyDeviceToSram, ctx.kernelStream);
                    convert_rows_f32_to_bf16(sramACompact, sramAPadded, tile_H);
                } else {
                    copy_rows_from_dev(sramAPadded, devA + (RPPdeviceptr) devA_offset, tile_H, (int) sizeof(uint16_t));
                }

                if (in1_bytes_per_element == (int) sizeof(float)) {
                    rtMemcpyAsync((void *) sramBCompact, (const void *) (devB + (RPPdeviceptr) devB_offset), sizeB,
                                  rtMemcpyDeviceToSram, ctx.kernelStream);
                    if (scalar_broadcast) {
                        calc_tbdim_flattern(1, 1, threadsPerBlock, blocksPerGrid);
                        params.clear();
                        cvt_kernel_param_init(threadsPerBlock, (uint32_t) sramBCompact, (uint32_t) sramBPadded, kFLOAT,
                                              kBF16, params);
                        launchWrapperAysnc("opt_vector_cvt_32_16", blocksPerGrid, threadsPerBlock, params,
                                           ctx.rppBinMod, ctx.kernelStream);
                    } else {
                        convert_rows_f32_to_bf16(sramBCompact, sramBPadded, 1);
                    }
                } else {
                    rtMemcpyAsync((void *) sramBPadded, (const void *) (devB + (RPPdeviceptr) devB_offset), sizeB,
                                  rtMemcpyDeviceToSram, ctx.kernelStream);
                }

                threadsPerBlock.x = padded_W;
                threadsPerBlock.y = 1;
                threadsPerBlock.z = 1;
                blocksPerGrid.x   = 1;
                blocksPerGrid.y   = 1;
                blocksPerGrid.z   = 1;
                while (threadsPerBlock.x * threadsPerBlock.y * threadsPerBlock.z <= 32) {
                    threadsPerBlock.y++;
                }

                params.clear();
                params.emplace_back((uint32_t) sramAPadded);
                params.emplace_back((uint32_t) sramBPadded);
                params.emplace_back((uint32_t) sramOutPadded);
                params.emplace_back(row_bytes_bf16);
                if (scalar_broadcast) {
                    params.emplace_back(1);
                    blocksPerGrid.z = tile_H;
                    launchWrapperAysnc("opt_binary_uniform_f16", blocksPerGrid, threadsPerBlock, params,
                                       ctx.rppBinMod, ctx.kernelStream);
                } else {
                    params.emplace_back(0);
                    params.emplace_back(padded_W);
                    params.emplace_back(1);
                    blocksPerGrid.z = tile_H;
                    launchWrapperAysnc("opt_binary_bc_y_f16", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                       ctx.kernelStream);
                }

                if (out_bytes_per_element == (int) sizeof(float)) {
                    for (int h = 0; h < tile_H; ++h) {
                        calc_tbdim_flattern(1, W * 2, threadsPerBlock, blocksPerGrid);
                        params.clear();
                        cvt_kernel_param_init_opt(
                            threadsPerBlock, (uint32_t) (sramOutPadded + (RPPdeviceptr) h * row_bytes_bf16),
                            (uint32_t) (sramOutCompact + (RPPdeviceptr) h * W * (int) sizeof(float)), kBF16, kFLOAT,
                            params);
                        launchWrapperAysnc("opt_vector_cvt_f16_f32_opt", blocksPerGrid, threadsPerBlock, params,
                                           ctx.rppBinMod, ctx.kernelStream);
                    }
                    rtMemcpyAsync((void *) (devC + (RPPdeviceptr) devC_offset), (const void *) sramOutCompact, sizeC,
                                  rtMemcpySramToDevice, ctx.kernelStream);
                } else {
                    for (int h = 0; h < tile_H; ++h) {
                        rtMemcpyAsync((void *) (devC + (RPPdeviceptr) devC_offset +
                                                (RPPdeviceptr) h * W * (int) sizeof(uint16_t)),
                                      (const void *) (sramOutPadded + (RPPdeviceptr) h * row_bytes_bf16),
                                      W * (int) sizeof(uint16_t), rtMemcpySramToDevice, ctx.kernelStream);
                    }
                }

                continue;
            }

            RPPdeviceptr sramA = sram_base;
            RPPdeviceptr sramB = sramA + rpp_elementwise_round_up(sizeA);
            RPPdeviceptr sramC = sramB + rpp_elementwise_round_up(sizeB);
            assert((int) (sramC + rpp_elementwise_round_up(sizeC) - sram_base) <= SRAM_LIMIT);

            rtMemcpyAsync((void *) sramA, (const void *) (devA + (RPPdeviceptr) devA_offset), sizeA,
                          rtMemcpyDeviceToSram, ctx.kernelStream);
            if (in0_bytes_per_element == (int) sizeof(float)) {
                calc_tbdim_flattern(tile_H, W, threadsPerBlock, blocksPerGrid);
                params.clear();
                cvt_kernel_param_init(threadsPerBlock, (uint32_t) sramA, (uint32_t) sramA, kFLOAT, kBF16, params);
                launchWrapperAysnc("opt_vector_cvt_32_16", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                   ctx.kernelStream);
            }

            rtMemcpyAsync((void *) sramB, (const void *) (devB + (RPPdeviceptr) devB_offset), sizeB,
                          rtMemcpyDeviceToSram, ctx.kernelStream);
            if (in1_bytes_per_element == (int) sizeof(float)) {
                calc_tbdim_flattern(1, scalar_broadcast ? 1 : W, threadsPerBlock, blocksPerGrid);
                params.clear();
                cvt_kernel_param_init(threadsPerBlock, (uint32_t) sramB, (uint32_t) sramB, kFLOAT, kBF16, params);
                launchWrapperAysnc("opt_vector_cvt_32_16", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                   ctx.kernelStream);
            }

            if (W < 8192) {
                threadsPerBlock.x = W;
                threadsPerBlock.y = 1;
                threadsPerBlock.z = 1;
                blocksPerGrid.x   = 1;
                blocksPerGrid.y   = 1;
                blocksPerGrid.z   = tile_H;
            } else {
                throw std::runtime_error("Elementwise Width is Too Big");
            }
            while (threadsPerBlock.x * threadsPerBlock.y * threadsPerBlock.z <= 32) {
                threadsPerBlock.y++;
            }

            const uint32_t offset0 = W * sizeof(uint16_t);
            const uint32_t out_addr =
                out_bytes_per_element == (int) sizeof(float) ? (uint32_t) sramA : (uint32_t) sramC;

            params.clear();
            params.emplace_back((uint32_t) sramA);
            params.emplace_back((uint32_t) sramB);
            params.emplace_back(out_addr);
            params.emplace_back(offset0);
            if (scalar_broadcast) {
                params.emplace_back(1);
                launchWrapperAysnc("opt_binary_uniform_f16", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                   ctx.kernelStream);
            } else {
                params.emplace_back(0);
                params.emplace_back(W);
                params.emplace_back(1);
                launchWrapperAysnc("opt_binary_bc_y_f16", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                   ctx.kernelStream);
            }

            if (out_bytes_per_element == (int) sizeof(float)) {
                params.clear();
                calc_tbdim_flattern(tile_H, W * 2, threadsPerBlock, blocksPerGrid);
                cvt_kernel_param_init_opt(threadsPerBlock, (uint32_t) sramA, (uint32_t) sramC, kBF16, kFLOAT, params);
                launchWrapperAysnc("opt_vector_cvt_f16_f32_opt", blocksPerGrid, threadsPerBlock, params,
                                   ctx.rppBinMod, ctx.kernelStream);
                rtMemcpyAsync((void *) (devC + (RPPdeviceptr) devC_offset), (const void *) sramC, sizeC,
                              rtMemcpySramToDevice, ctx.kernelStream);
            } else {
                rtMemcpyAsync((void *) (devC + (RPPdeviceptr) devC_offset), (const void *) sramC, sizeC,
                              rtMemcpySramToDevice, ctx.kernelStream);
            }
        }
    }

    rppStreamEndCapture(ctx.kernelStream, &ctx.graph);
    const std::string graph_key =
        rpp_join_function_name_and_args(__func__, "mul_bc_v1", C, H, W, axis, in0_bytes_per_element,
                                        in1_bytes_per_element, out_bytes_per_element);
    if (rpp_graph_instantiate(ctx.graphexec, ctx.graph, graph_key.c_str(), is_instantial) != RPP_SUCCESS) {
        throw std::runtime_error("rpp_graph_instantiate failed.");
    }
}

inline void rpp_elementwise_build_wide_rows(rpp_kernel_context & ctx,
                                            rppElementWiseType   type,
                                            int                  C,
                                            int                  H,
                                            int                  W,
                                            int                  axis,
                                            int                  in0_bytes_per_element,
                                            int                  in1_bytes_per_element,
                                            int                  out_bytes_per_element,
                                            int                  is_instantial = 1) {
    assert(type == RPP_ELEMWISE_ADD || type == RPP_ELEMWISE_MUL);
    assert(axis == -1 || axis == 0);
    assert(in0_bytes_per_element == (int) sizeof(uint16_t) || in0_bytes_per_element == (int) sizeof(float));
    assert(in1_bytes_per_element == (int) sizeof(uint16_t) || in1_bytes_per_element == (int) sizeof(float));
    assert(out_bytes_per_element == (int) sizeof(uint16_t) || out_bytes_per_element == (int) sizeof(float));

    constexpr int WIDTH_TILE = 4096;
    constexpr int SRAM_LIMIT = 22 * 1024 * 1024;

    dim3                  threadsPerBlock;
    dim3                  blocksPerGrid;
    std::vector<uint32_t> params;
    const RPPdeviceptr    devA      = ctx.dev_in[0];
    const RPPdeviceptr    devB      = ctx.dev_in[1];
    const RPPdeviceptr    devC      = ctx.dev_out[0];
    const RPPdeviceptr    sram_base = ctx.virtual_sram_base;

    rppStreamBeginCapture(ctx.kernelStream, RPP_STREAM_CAPTURE_MODE_GLOBAL);
    rpp_module_load_once(ctx.rppBinMod, "rpp_kernel/elementwise.o");

    if (in0_bytes_per_element == (int) sizeof(uint16_t) &&
        in1_bytes_per_element == (int) sizeof(uint16_t) &&
        out_bytes_per_element == (int) sizeof(uint16_t)) {
        constexpr int HEIGHT_TILE = 64;

        for (int c = 0; c < C; ++c) {
            for (int h_begin = 0; h_begin < H; h_begin += HEIGHT_TILE) {
                const int tile_H = std::min(HEIGHT_TILE, H - h_begin);

                for (int w_begin = 0; w_begin < W; w_begin += WIDTH_TILE) {
                    const int tile_W         = std::min(WIDTH_TILE, W - w_begin);
                    const int padded_W       = rpp_elementwise_round_up_to_32(tile_W);
                    const int sram_row_bytes = padded_W * (int) sizeof(uint16_t);
                    const int copy_row_bytes = tile_W * (int) sizeof(uint16_t);
                    const int tile_bytes     = tile_H * sram_row_bytes;

                    const RPPdeviceptr sramA   = sram_base;
                    const RPPdeviceptr sramB   = sramA + rpp_elementwise_round_up(tile_bytes);
                    const RPPdeviceptr sramOut = sramB + rpp_elementwise_round_up(tile_bytes);
                    assert((int) (sramOut + rpp_elementwise_round_up(tile_bytes) - sram_base) <= SRAM_LIMIT);

                    const size_t element_offset =
                        ((size_t) c * (size_t) H + (size_t) h_begin) * (size_t) W + (size_t) w_begin;
                    const RPPdeviceptr devA_tile = devA + (RPPdeviceptr) element_offset * sizeof(uint16_t);
                    const RPPdeviceptr devB_tile = devB + (RPPdeviceptr) element_offset * sizeof(uint16_t);
                    const RPPdeviceptr devC_tile = devC + (RPPdeviceptr) element_offset * sizeof(uint16_t);
                    const int          dev_row_bytes = W * (int) sizeof(uint16_t);

                    rtMemcpy2DAsync((void *) sramA, sram_row_bytes, (const void *) devA_tile, dev_row_bytes,
                                    copy_row_bytes, tile_H, rtMemcpyDeviceToSram, ctx.kernelStream);
                    rtMemcpy2DAsync((void *) sramB, sram_row_bytes, (const void *) devB_tile, dev_row_bytes,
                                    copy_row_bytes, tile_H, rtMemcpyDeviceToSram, ctx.kernelStream);

                    threadsPerBlock.x = padded_W;
                    threadsPerBlock.y = 1;
                    threadsPerBlock.z = 1;
                    blocksPerGrid.x   = 1;
                    blocksPerGrid.y   = 1;
                    blocksPerGrid.z   = 1;

                    params.clear();
                    params.emplace_back((uint32_t) sramA);
                    params.emplace_back((uint32_t) sramB);
                    params.emplace_back((uint32_t) sramOut);
                    params.emplace_back(sram_row_bytes);
                    params.emplace_back(sram_row_bytes);
                    params.emplace_back(tile_H);
                    params.emplace_back(padded_W);
                    params.emplace_back(padded_W);
                    if (type == RPP_ELEMWISE_ADD) {
                        launchWrapperAysnc("elementwise_add", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                           ctx.kernelStream);
                    } else {
                        launchWrapperAysnc("elementwise_mul", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                           ctx.kernelStream);
                    }

                    rtMemcpy2DAsync((void *) devC_tile, dev_row_bytes, (const void *) sramOut, sram_row_bytes,
                                    copy_row_bytes, tile_H, rtMemcpySramToDevice, ctx.kernelStream);
                }
            }
        }

        rppStreamEndCapture(ctx.kernelStream, &ctx.graph);
        const std::string graph_key =
            rpp_join_function_name_and_args(__func__, "bf16_v1", (int) type, C, H, W, axis,
                                            in0_bytes_per_element, in1_bytes_per_element, out_bytes_per_element);
        if (rpp_graph_instantiate(ctx.graphexec, ctx.graph, graph_key.c_str(), is_instantial) != RPP_SUCCESS) {
            throw std::runtime_error("rpp_graph_instantiate failed.");
        }
        return;
    }

    for (int c = 0; c < C; ++c) {
        for (int h = 0; h < H; ++h) {
            const size_t row_offset = ((size_t) c * (size_t) H + (size_t) h) * (size_t) W;

            for (int w_begin = 0; w_begin < W; w_begin += WIDTH_TILE) {
                const int tile_W       = std::min(WIDTH_TILE, W - w_begin);
                const int padded_W     = rpp_elementwise_round_up_to_32(tile_W);
                const int bf16_bytes   = padded_W * (int) sizeof(uint16_t);
                const int input0_bytes = tile_W * in0_bytes_per_element;
                const int input1_bytes = tile_W * in1_bytes_per_element;
                const int output_bytes = tile_W * out_bytes_per_element;

                RPPdeviceptr sram_cursor   = sram_base;
                RPPdeviceptr sramACompact = 0;
                RPPdeviceptr sramBCompact = 0;
                if (in0_bytes_per_element == (int) sizeof(float)) {
                    sramACompact = sram_cursor;
                    sram_cursor += rpp_elementwise_round_up(input0_bytes);
                }
                if (in1_bytes_per_element == (int) sizeof(float)) {
                    sramBCompact = sram_cursor;
                    sram_cursor += rpp_elementwise_round_up(input1_bytes);
                }

                const RPPdeviceptr sramA = sram_cursor;
                sram_cursor += rpp_elementwise_round_up(bf16_bytes);
                const RPPdeviceptr sramB = sram_cursor;
                sram_cursor += rpp_elementwise_round_up(bf16_bytes);
                const RPPdeviceptr sramOut = sram_cursor;
                sram_cursor += rpp_elementwise_round_up(bf16_bytes);

                RPPdeviceptr sramOutCompact = 0;
                if (out_bytes_per_element == (int) sizeof(float)) {
                    sramOutCompact = sram_cursor;
                    sram_cursor += rpp_elementwise_round_up(output_bytes);
                }
                assert((int) (sram_cursor - sram_base) <= SRAM_LIMIT);

                const size_t element_offset = row_offset + (size_t) w_begin;
                const RPPdeviceptr devA_tile =
                    devA + (RPPdeviceptr) element_offset * (RPPdeviceptr) in0_bytes_per_element;
                const RPPdeviceptr devB_tile =
                    devB + (RPPdeviceptr) element_offset * (RPPdeviceptr) in1_bytes_per_element;
                const RPPdeviceptr devC_tile =
                    devC + (RPPdeviceptr) element_offset * (RPPdeviceptr) out_bytes_per_element;

                if (in0_bytes_per_element == (int) sizeof(float)) {
                    rtMemcpyAsync((void *) sramACompact, (const void *) devA_tile, input0_bytes,
                                  rtMemcpyDeviceToSram, ctx.kernelStream);
                    calc_tbdim_flattern(1, tile_W, threadsPerBlock, blocksPerGrid);
                    params.clear();
                    cvt_kernel_param_init(threadsPerBlock, (uint32_t) sramACompact, (uint32_t) sramA, kFLOAT,
                                          kBF16, params);
                    launchWrapperAysnc("opt_vector_cvt_32_16", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                       ctx.kernelStream);
                } else {
                    rtMemcpyAsync((void *) sramA, (const void *) devA_tile, input0_bytes, rtMemcpyDeviceToSram,
                                  ctx.kernelStream);
                }

                if (in1_bytes_per_element == (int) sizeof(float)) {
                    rtMemcpyAsync((void *) sramBCompact, (const void *) devB_tile, input1_bytes,
                                  rtMemcpyDeviceToSram, ctx.kernelStream);
                    calc_tbdim_flattern(1, tile_W, threadsPerBlock, blocksPerGrid);
                    params.clear();
                    cvt_kernel_param_init(threadsPerBlock, (uint32_t) sramBCompact, (uint32_t) sramB, kFLOAT,
                                          kBF16, params);
                    launchWrapperAysnc("opt_vector_cvt_32_16", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                       ctx.kernelStream);
                } else {
                    rtMemcpyAsync((void *) sramB, (const void *) devB_tile, input1_bytes, rtMemcpyDeviceToSram,
                                  ctx.kernelStream);
                }

                threadsPerBlock.x = padded_W;
                threadsPerBlock.y = 1;
                threadsPerBlock.z = 1;
                blocksPerGrid.x   = 1;
                blocksPerGrid.y   = 1;
                blocksPerGrid.z   = 1;
                while (threadsPerBlock.x * threadsPerBlock.y * threadsPerBlock.z <= 32) {
                    threadsPerBlock.y++;
                }

                params.clear();
                params.emplace_back((uint32_t) sramA);
                params.emplace_back((uint32_t) sramB);
                params.emplace_back((uint32_t) sramOut);
                params.emplace_back(bf16_bytes);
                params.emplace_back(bf16_bytes);
                params.emplace_back(1);
                params.emplace_back(padded_W);
                params.emplace_back(padded_W);
                if (type == RPP_ELEMWISE_ADD) {
                    launchWrapperAysnc("elementwise_add", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                       ctx.kernelStream);
                } else {
                    launchWrapperAysnc("elementwise_mul", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                       ctx.kernelStream);
                }

                if (out_bytes_per_element == (int) sizeof(float)) {
                    calc_tbdim_flattern(1, tile_W * 2, threadsPerBlock, blocksPerGrid);
                    params.clear();
                    cvt_kernel_param_init_opt(threadsPerBlock, (uint32_t) sramOut, (uint32_t) sramOutCompact, kBF16,
                                              kFLOAT, params);
                    launchWrapperAysnc("opt_vector_cvt_f16_f32_opt", blocksPerGrid, threadsPerBlock, params,
                                       ctx.rppBinMod, ctx.kernelStream);
                    rtMemcpyAsync((void *) devC_tile, (const void *) sramOutCompact, output_bytes,
                                  rtMemcpySramToDevice, ctx.kernelStream);
                } else {
                    rtMemcpyAsync((void *) devC_tile, (const void *) sramOut, output_bytes, rtMemcpySramToDevice,
                                  ctx.kernelStream);
                }
            }
        }
    }

    rppStreamEndCapture(ctx.kernelStream, &ctx.graph);
    const std::string graph_key =
        rpp_join_function_name_and_args(__func__, (int) type, C, H, W, axis, in0_bytes_per_element,
                                        in1_bytes_per_element, out_bytes_per_element);
    if (rpp_graph_instantiate(ctx.graphexec, ctx.graph, graph_key.c_str(), is_instantial) != RPP_SUCCESS) {
        throw std::runtime_error("rpp_graph_instantiate failed.");
    }
}

inline void rpp_elementwise_build_tiled(rpp_kernel_context & ctx,
                                        rppElementWiseType   type,
                                        int                  C,
                                        int                  H,
                                        int                  W,
                                        int                  axis,
                                        int                  in0_bytes_per_element,
                                        int                  in1_bytes_per_element,
                                        int                  out_bytes_per_element,
                                        int                  is_instantial = 1) {
    dim3                  threadsPerBlock;
    dim3                  blocksPerGrid;
    std::vector<uint32_t> params;
    RPPdeviceptr          devA;
    RPPdeviceptr          devB;
    bool                  ab_switched = false;

    if (axis <= 2 || axis == 6 || axis == 8) {
        devA = ctx.dev_in[0];
        devB = ctx.dev_in[1];
    } else {
        ab_switched           = true;
        devA                  = ctx.dev_in[1];
        devB                  = ctx.dev_in[0];
        int tmp               = in1_bytes_per_element;
        in1_bytes_per_element = in0_bytes_per_element;
        in0_bytes_per_element = tmp;
        if (axis != 7) {
            axis = axis - 3;
        }
    }

    RPPdeviceptr devC = ctx.dev_out[0];

    RPPdeviceptr dev_reciprocal_lut    = 0;
    int          reciprocal_table_bytes = 0;
    if (type == RPP_ELEMWISE_DIV) {
        reciprocal_table_bytes = 65536 * (int) sizeof(uint16_t);
        dev_reciprocal_lut     = rpp_elementwise_prepare_reciprocal_lut_workspace(ctx);
    }

    rppStreamBeginCapture(ctx.kernelStream, RPP_STREAM_CAPTURE_MODE_GLOBAL);
    rpp_module_load_once(ctx.rppBinMod, "rpp_kernel/elementwise.o");

    RPPdeviceptr sram_base            = ctx.virtual_sram_base;
    RPPdeviceptr sramReciprocalTable  = sram_base;
    const int    padded_W             = rpp_elementwise_round_up_to_32(W);
    const bool   use_row_tail_padding = padded_W != W;
    const int    SRAM_LIMIT           = 22 * 1024 * 1024;
    const int max_tile_h = rpp_elementwise_get_max_tile_rows(H, W, axis, in0_bytes_per_element, in1_bytes_per_element,
                                                             out_bytes_per_element, reciprocal_table_bytes, SRAM_LIMIT);

    if (type == RPP_ELEMWISE_DIV) {
        rtMemcpyAsync((void *) sramReciprocalTable, (const void *) dev_reciprocal_lut, reciprocal_table_bytes,
                      rtMemcpyDeviceToSram, ctx.kernelStream);
    }

    for (int c = 0; c < C; ++c) {
        const size_t devA_offset_base = (size_t) c * (size_t) H * (size_t) W * (size_t) in0_bytes_per_element;
        size_t       devB_offset_base = 0;
        if (axis == -1) {
            devB_offset_base = (size_t) c * (size_t) H * (size_t) W * (size_t) in1_bytes_per_element;
        } else if (axis == 1) {
            devB_offset_base = (size_t) c * (size_t) W * (size_t) in1_bytes_per_element;
        } else if (axis == 2) {
            devB_offset_base = (size_t) c * (size_t) H * (size_t) in1_bytes_per_element;
        }
        const size_t devC_offset_base = (size_t) c * (size_t) H * (size_t) W * (size_t) out_bytes_per_element;

        for (int h_begin = 0; h_begin < H; h_begin += max_tile_h) {
            const int    tile_H = std::min(max_tile_h, H - h_begin);
            const int    sizeA  = tile_H * W * in0_bytes_per_element;
            const int    sizeB  = rpp_elementwise_get_input1_bytes(axis, tile_H, W, in1_bytes_per_element);
            const int    sizeC  = tile_H * W * out_bytes_per_element;
            const size_t devA_offset =
                devA_offset_base + (size_t) h_begin * (size_t) W * (size_t) in0_bytes_per_element;
            size_t devB_offset = devB_offset_base;
            if (axis == -1 || axis == 0) {
                devB_offset += (size_t) h_begin * (size_t) W * (size_t) in1_bytes_per_element;
            } else if (axis == 2) {
                devB_offset += (size_t) h_begin * (size_t) in1_bytes_per_element;
            }
            const size_t devC_offset =
                devC_offset_base + (size_t) h_begin * (size_t) W * (size_t) out_bytes_per_element;

            const int total_sram_bytes =
                rpp_elementwise_get_tile_sram_bytes(tile_H, W, axis, in0_bytes_per_element, in1_bytes_per_element,
                                                    out_bytes_per_element, reciprocal_table_bytes);
            assert(total_sram_bytes <= SRAM_LIMIT);

            RPPdeviceptr sramA = sramReciprocalTable + reciprocal_table_bytes;
            RPPdeviceptr sramB = sramA + rpp_elementwise_round_up(sizeA);
            RPPdeviceptr sramC = sramB + rpp_elementwise_round_up(sizeB);

            if (use_row_tail_padding) {
                assert(axis != 2);
                assert(padded_W < 8192);

                const int row_bytes_bf16 = padded_W * (int) sizeof(uint16_t);
                const int sizeA_compact  = sizeA;
                const int sizeB_compact  = sizeB;
                const int sizeA_padded   = tile_H * row_bytes_bf16;
                const int sizeB_padded   = (axis == -1 || axis == 0 ||
                                            rpp_elementwise_input1_is_materialized_row_broadcast(axis) ||
                                            rpp_elementwise_input1_is_scalar_broadcast(axis)) ?
                                               tile_H * row_bytes_bf16 :
                                               row_bytes_bf16;
                const int sizeOut_padded = tile_H * row_bytes_bf16;

                RPPdeviceptr sramCursor   = sramReciprocalTable + reciprocal_table_bytes;
                RPPdeviceptr sramACompact = 0;
                RPPdeviceptr sramBCompact = 0;
                if (in0_bytes_per_element == (int) sizeof(float)) {
                    sramACompact = sramCursor;
                    sramCursor += rpp_elementwise_round_up(sizeA_compact);
                }
                if (in1_bytes_per_element == (int) sizeof(float)) {
                    sramBCompact = sramCursor;
                    sramCursor += rpp_elementwise_round_up(sizeB_compact);
                }

                RPPdeviceptr sramAPadded = sramCursor;
                sramCursor += rpp_elementwise_round_up(sizeA_padded);
                RPPdeviceptr sramBPadded = sramCursor;
                sramCursor += rpp_elementwise_round_up(sizeB_padded);
                RPPdeviceptr sramOutPadded = sramCursor;
                sramCursor += rpp_elementwise_round_up(sizeOut_padded);

                RPPdeviceptr sramOutCompact = 0;
                if (out_bytes_per_element == (int) sizeof(float)) {
                    if (sramACompact != 0) {
                        sramOutCompact = sramACompact;
                    } else if (sramBCompact != 0) {
                        sramOutCompact = sramBCompact;
                    } else {
                        sramOutCompact = sramCursor;
                        sramCursor += rpp_elementwise_round_up(sizeC);
                    }
                }

                const int total_sram_bytes_padded = (int) (sramCursor - sram_base);
                if (total_sram_bytes_padded > SRAM_LIMIT) {
                    std::cerr << "SRAM overflow: need " << total_sram_bytes_padded << " bytes, but allocated "
                              << SRAM_LIMIT << " bytes\n";
                    std::abort();
                }

                auto copy_rows_from_dev = [&](RPPdeviceptr sramDst, RPPdeviceptr devSrc, int elem_bytes) {
                    for (int h = 0; h < tile_H; ++h) {
                        rtMemcpyAsync((void *) (sramDst + (RPPdeviceptr) h * row_bytes_bf16),
                                      (const void *) (devSrc + (RPPdeviceptr) h * W * elem_bytes), W * elem_bytes,
                                      rtMemcpyDeviceToSram, ctx.kernelStream);
                    }
                };
                auto copy_scalar_from_dev_as_row = [&](RPPdeviceptr sramDst, RPPdeviceptr devSrc, int elem_bytes) {
                    for (int h = 0; h < tile_H; ++h) {
                        for (int w = 0; w < W; ++w) {
                            rtMemcpyAsync((void *) (sramDst + ((RPPdeviceptr) h * W + w) * elem_bytes),
                                          (const void *) devSrc, elem_bytes, rtMemcpyDeviceToSram, ctx.kernelStream);
                        }
                    }
                };
                auto copy_same_row_from_dev = [&](RPPdeviceptr sramDst, RPPdeviceptr devSrc, int row_bytes_dst,
                                                  int elem_bytes) {
                    for (int h = 0; h < tile_H; ++h) {
                        rtMemcpyAsync((void *) (sramDst + (RPPdeviceptr) h * row_bytes_dst), (const void *) devSrc,
                                      W * elem_bytes, rtMemcpyDeviceToSram, ctx.kernelStream);
                    }
                };
                auto convert_rows_f32_to_bf16 = [&](RPPdeviceptr sramSrcCompact, RPPdeviceptr sramDstPadded, int rows) {
                    for (int h = 0; h < rows; ++h) {
                        calc_tbdim_flattern(1, W, threadsPerBlock, blocksPerGrid);
                        params.clear();
                        cvt_kernel_param_init(
                            threadsPerBlock, (uint32_t) (sramSrcCompact + (RPPdeviceptr) h * W * (int) sizeof(float)),
                            (uint32_t) (sramDstPadded + (RPPdeviceptr) h * row_bytes_bf16), kFLOAT, kBF16, params);
                        launchWrapperAysnc("opt_vector_cvt_32_16", blocksPerGrid, threadsPerBlock, params,
                                           ctx.rppBinMod, ctx.kernelStream);
                    }
                };

                if (in0_bytes_per_element == (int) sizeof(float)) {
                    rtMemcpyAsync((void *) sramACompact, (const void *) (devA + (RPPdeviceptr) devA_offset),
                                  sizeA_compact, rtMemcpyDeviceToSram, ctx.kernelStream);
                    convert_rows_f32_to_bf16(sramACompact, sramAPadded, tile_H);
                } else {
                    copy_rows_from_dev(sramAPadded, devA + (RPPdeviceptr) devA_offset, (int) sizeof(uint16_t));
                }

                if (in1_bytes_per_element == (int) sizeof(float)) {
                    if (axis == 8) {
                        copy_scalar_from_dev_as_row(sramBCompact, devB + (RPPdeviceptr) devB_offset,
                                                    in1_bytes_per_element);
                    } else if (rpp_elementwise_input1_is_materialized_row_broadcast(axis)) {
                        copy_same_row_from_dev(sramBCompact, devB + (RPPdeviceptr) devB_offset,
                                               W * in1_bytes_per_element, in1_bytes_per_element);
                    } else {
                        rtMemcpyAsync((void *) sramBCompact, (const void *) (devB + (RPPdeviceptr) devB_offset),
                                      sizeB_compact, rtMemcpyDeviceToSram, ctx.kernelStream);
                    }
                    if (axis == -1 || axis == 0 || rpp_elementwise_input1_is_materialized_row_broadcast(axis) ||
                        rpp_elementwise_input1_is_scalar_broadcast(axis)) {
                        convert_rows_f32_to_bf16(sramBCompact, sramBPadded, tile_H);
                    } else {
                        calc_tbdim_flattern(1, W, threadsPerBlock, blocksPerGrid);
                        params.clear();
                        cvt_kernel_param_init(threadsPerBlock, (uint32_t) sramBCompact, (uint32_t) sramBPadded, kFLOAT,
                                              kBF16, params);
                        launchWrapperAysnc("opt_vector_cvt_32_16", blocksPerGrid, threadsPerBlock, params,
                                           ctx.rppBinMod, ctx.kernelStream);
                    }
                } else {
                    if (axis == -1 || axis == 0) {
                        copy_rows_from_dev(sramBPadded, devB + (RPPdeviceptr) devB_offset, (int) sizeof(uint16_t));
                    } else if (axis == 8) {
                        copy_scalar_from_dev_as_row(sramBPadded, devB + (RPPdeviceptr) devB_offset,
                                                    in1_bytes_per_element);
                    } else if (rpp_elementwise_input1_is_materialized_row_broadcast(axis)) {
                        copy_same_row_from_dev(sramBPadded, devB + (RPPdeviceptr) devB_offset, row_bytes_bf16,
                                               in1_bytes_per_element);
                    } else {
                        rtMemcpyAsync((void *) sramBPadded, (const void *) (devB + (RPPdeviceptr) devB_offset),
                                      W * (int) sizeof(uint16_t), rtMemcpyDeviceToSram, ctx.kernelStream);
                    }
                }

                if (type == RPP_ELEMWISE_DIV) {
                    RPPdeviceptr reciprocalInput = ab_switched ? sramAPadded : sramBPadded;
                    const int    reciprocalRows  = (ab_switched || axis == -1 || axis == 0) ? tile_H : 1;
                    for (int h = 0; h < reciprocalRows; ++h) {
                        calc_tbdim_flattern(1, W, threadsPerBlock, blocksPerGrid);
                        params.clear();
                        params.emplace_back((uint32_t) (reciprocalInput + (RPPdeviceptr) h * row_bytes_bf16));
                        params.emplace_back((uint32_t) (reciprocalInput + (RPPdeviceptr) h * row_bytes_bf16));
                        params.emplace_back((uint32_t) sramReciprocalTable);
                        params.emplace_back(threadsPerBlock.x * threadsPerBlock.y * threadsPerBlock.z *
                                            sizeof(uint16_t));
                        launchWrapperAysnc("mish_f16", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                           ctx.kernelStream);
                    }
                }

                threadsPerBlock.x = padded_W;
                threadsPerBlock.y = 1;
                threadsPerBlock.z = 1;
                blocksPerGrid.x   = 1;
                blocksPerGrid.y   = 1;
                blocksPerGrid.z   = 1;
                while (threadsPerBlock.x * threadsPerBlock.y * threadsPerBlock.z <= 32) {
                    threadsPerBlock.y++;
                }

                params.clear();
                params.emplace_back((uint32_t) sramAPadded);
                params.emplace_back((uint32_t) sramBPadded);
                params.emplace_back((uint32_t) sramOutPadded);
                params.emplace_back(row_bytes_bf16);
                params.emplace_back(row_bytes_bf16);
                params.emplace_back(tile_H);
                params.emplace_back(padded_W);
                params.emplace_back(padded_W);
                if (type == RPP_ELEMWISE_ADD) {
                    launchWrapperAysnc("elementwise_add", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                       ctx.kernelStream);
                } else if (type == RPP_ELEMWISE_MUL || type == RPP_ELEMWISE_DIV) {
                    launchWrapperAysnc("elementwise_mul", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                       ctx.kernelStream);
                } else {
                    assert(0);
                }

                if (out_bytes_per_element == (int) sizeof(float)) {
                    for (int h = 0; h < tile_H; ++h) {
                        calc_tbdim_flattern(1, W * 2, threadsPerBlock, blocksPerGrid);
                        params.clear();
                        cvt_kernel_param_init_opt(
                            threadsPerBlock, (uint32_t) (sramOutPadded + (RPPdeviceptr) h * row_bytes_bf16),
                            (uint32_t) (sramOutCompact + (RPPdeviceptr) h * W * (int) sizeof(float)), kBF16, kFLOAT,
                            params);
                        launchWrapperAysnc("opt_vector_cvt_f16_f32_opt", blocksPerGrid, threadsPerBlock, params,
                                           ctx.rppBinMod, ctx.kernelStream);
                    }
                    rtMemcpyAsync((void *) (devC + (RPPdeviceptr) devC_offset), (const void *) sramOutCompact, sizeC,
                                  rtMemcpySramToDevice, ctx.kernelStream);
                } else {
                    for (int h = 0; h < tile_H; ++h) {
                        rtMemcpyAsync((void *) (devC + (RPPdeviceptr) devC_offset +
                                                (RPPdeviceptr) h * W * (int) sizeof(uint16_t)),
                                      (const void *) (sramOutPadded + (RPPdeviceptr) h * row_bytes_bf16),
                                      W * (int) sizeof(uint16_t), rtMemcpySramToDevice, ctx.kernelStream);
                    }
                }

                continue;
            }

            rtMemcpyAsync((void *) sramA, (const void *) (devA + (RPPdeviceptr) devA_offset), sizeA,
                          rtMemcpyDeviceToSram, ctx.kernelStream);
            if (in0_bytes_per_element == (int) sizeof(float)) {
                calc_tbdim_flattern(tile_H, W, threadsPerBlock, blocksPerGrid);
                params.clear();
                cvt_kernel_param_init(threadsPerBlock, (uint32_t) sramA, (uint32_t) sramA, kFLOAT, kBF16, params);
                launchWrapperAysnc("opt_vector_cvt_32_16", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                   ctx.kernelStream);
            }

            if (axis == 8) {
                for (int h = 0; h < tile_H; ++h) {
                    for (int w = 0; w < W; ++w) {
                        rtMemcpyAsync((void *) (sramB + ((RPPdeviceptr) h * W + w) * in1_bytes_per_element),
                                      (const void *) (devB + (RPPdeviceptr) devB_offset), in1_bytes_per_element,
                                      rtMemcpyDeviceToSram, ctx.kernelStream);
                    }
                }
            } else if (rpp_elementwise_input1_is_materialized_row_broadcast(axis)) {
                for (int h = 0; h < tile_H; ++h) {
                    rtMemcpyAsync((void *) (sramB + (RPPdeviceptr) h * W * in1_bytes_per_element),
                                  (const void *) (devB + (RPPdeviceptr) devB_offset),
                                  W * in1_bytes_per_element, rtMemcpyDeviceToSram, ctx.kernelStream);
                }
            } else {
                rtMemcpyAsync((void *) sramB, (const void *) (devB + (RPPdeviceptr) devB_offset), sizeB,
                              rtMemcpyDeviceToSram, ctx.kernelStream);
            }
            if (in1_bytes_per_element == (int) sizeof(float)) {
                if (axis == -1 || axis == 0 || rpp_elementwise_input1_is_materialized_row_broadcast(axis) ||
                    rpp_elementwise_input1_is_scalar_broadcast(axis)) {
                    calc_tbdim_flattern(tile_H, W, threadsPerBlock, blocksPerGrid);
                } else if (rpp_elementwise_input1_is_row_broadcast(axis)) {
                    calc_tbdim_flattern(1, W, threadsPerBlock, blocksPerGrid);
                } else if (axis == 2) {
                    calc_tbdim_flattern(1, tile_H, threadsPerBlock, blocksPerGrid);
                } else {
                    throw std::runtime_error("Unsupported elementwise broadcast axis");
                }
                params.clear();
                cvt_kernel_param_init(threadsPerBlock, (uint32_t) sramB, (uint32_t) sramB, kFLOAT, kBF16, params);
                launchWrapperAysnc("opt_vector_cvt_32_16", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                   ctx.kernelStream);
            }

            if (type == RPP_ELEMWISE_DIV) {
                if (ab_switched) {
                    calc_tbdim_flattern(tile_H, W, threadsPerBlock, blocksPerGrid);
                    params.clear();
                    params.emplace_back((uint32_t) sramA);
                    params.emplace_back((uint32_t) sramA);
                    params.emplace_back((uint32_t) sramReciprocalTable);
                    params.emplace_back(threadsPerBlock.x * threadsPerBlock.y * threadsPerBlock.z * sizeof(uint16_t));
                    launchWrapperAysnc("mish_f16", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                       ctx.kernelStream);
                } else {
                    if (axis == -1 || axis == 0) {
                        calc_tbdim_flattern(tile_H, W, threadsPerBlock, blocksPerGrid);
                    } else if (rpp_elementwise_input1_is_row_broadcast(axis)) {
                        calc_tbdim_flattern(1, W, threadsPerBlock, blocksPerGrid);
                    } else if (axis == 2) {
                        calc_tbdim_flattern(1, tile_H, threadsPerBlock, blocksPerGrid);
                    } else {
                        throw std::runtime_error("Unsupported elementwise broadcast axis");
                    }
                    params.clear();
                    params.emplace_back((uint32_t) sramB);
                    params.emplace_back((uint32_t) sramB);
                    params.emplace_back((uint32_t) sramReciprocalTable);
                    params.emplace_back(threadsPerBlock.x * threadsPerBlock.y * threadsPerBlock.z * sizeof(uint16_t));
                    launchWrapperAysnc("mish_f16", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                       ctx.kernelStream);
                }
            }

            if (W * tile_H < 8192) {
                threadsPerBlock.x = W;
                threadsPerBlock.y = 1;
                threadsPerBlock.z = tile_H;
                blocksPerGrid.x   = 1;
                blocksPerGrid.y   = 1;
                blocksPerGrid.z   = 1;
            } else if (W < 8192) {
                threadsPerBlock.x = W;
                threadsPerBlock.y = 1;
                threadsPerBlock.z = 1;
                blocksPerGrid.x   = 1;
                blocksPerGrid.y   = 1;
                blocksPerGrid.z   = tile_H;
            } else {
                throw std::runtime_error("Elementwise Width is Too Big");
            }

            while (threadsPerBlock.x * threadsPerBlock.y * threadsPerBlock.z <= 32) {
                threadsPerBlock.y++;
            }

            const uint32_t input0 = (uint32_t) sramA;
            const uint32_t input1 = (uint32_t) sramB;
            const uint32_t out_addr =
                out_bytes_per_element == (int) sizeof(float) ? (uint32_t) sramA : (uint32_t) sramC;
            uint32_t loop     = blocksPerGrid.z;
            uint32_t offset0  = threadsPerBlock.x * threadsPerBlock.z * sizeof(uint16_t);
            uint32_t stridez0 = threadsPerBlock.x;
            uint32_t offset1  = threadsPerBlock.x * threadsPerBlock.z * sizeof(uint16_t);
            uint32_t stridez1 = threadsPerBlock.x;
            blocksPerGrid.z   = 1;

            params.clear();
            if (axis == 2) {
                if (threadsPerBlock.z > 1) {
                    unsigned int tmp  = threadsPerBlock.z;
                    threadsPerBlock.z = threadsPerBlock.y;
                    threadsPerBlock.y = tmp;
                }
                params.emplace_back(input0);
                params.emplace_back(input1);
                params.emplace_back(out_addr);
                params.emplace_back(threadsPerBlock.x * threadsPerBlock.y * sizeof(uint16_t));
                params.emplace_back(threadsPerBlock.y * sizeof(uint16_t));
                if (type == RPP_ELEMWISE_ADD) {
                    params.emplace_back(0);
                } else if (type == RPP_ELEMWISE_MUL || type == RPP_ELEMWISE_DIV) {
                    params.emplace_back(1);
                } else {
                    assert(0);
                }
                blocksPerGrid.z = loop;
                launchWrapperAysnc("opt_binary_bc_x", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                   ctx.kernelStream);
            } else {
                params.emplace_back(input0);
                params.emplace_back(input1);
                params.emplace_back(out_addr);
                params.emplace_back(offset0);
                params.emplace_back(offset1);
                params.emplace_back(loop);
                params.emplace_back(stridez0);
                params.emplace_back(stridez1);
                if (type == RPP_ELEMWISE_ADD) {
                    launchWrapperAysnc("elementwise_add", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                       ctx.kernelStream);
                } else if (type == RPP_ELEMWISE_MUL || type == RPP_ELEMWISE_DIV) {
                    launchWrapperAysnc("elementwise_mul", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                       ctx.kernelStream);
                } else {
                    assert(0);
                }
            }

            if (out_bytes_per_element == (int) sizeof(float)) {
                params.clear();
                calc_tbdim_flattern(tile_H, W * 2, threadsPerBlock, blocksPerGrid);
                cvt_kernel_param_init_opt(threadsPerBlock, (uint32_t) sramA, (uint32_t) sramC, kBF16, kFLOAT, params);
                launchWrapperAysnc("opt_vector_cvt_f16_f32_opt", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                   ctx.kernelStream);

                rtMemcpyAsync((void *) (devC + (RPPdeviceptr) devC_offset), (const void *) sramC, sizeC,
                              rtMemcpySramToDevice, ctx.kernelStream);
            } else {
                rtMemcpyAsync((void *) (devC + (RPPdeviceptr) devC_offset), (const void *) sramC, sizeC,
                              rtMemcpySramToDevice, ctx.kernelStream);
            }
        }
    }

    rppStreamEndCapture(ctx.kernelStream, &ctx.graph);
    const std::string graph_key =
        rpp_join_function_name_and_args(__func__, "broadcast_materialized_v2", (int) type, C, H, W, axis,
                                        in0_bytes_per_element, in1_bytes_per_element, out_bytes_per_element);
    if (rpp_graph_instantiate(ctx.graphexec, ctx.graph, graph_key.c_str(), is_instantial) != RPP_SUCCESS) {
        throw std::runtime_error("rpp_graph_instantiate failed.");
    }

}

inline void rpp_elementwise_build_tiled_pipeline(rpp_kernel_context & ctx,
                                                 rppElementWiseType   type,
                                                 int                  C,
                                                 int                  H,
                                                 int                  W,
                                                 int                  axis,
                                                 int                  in0_bytes_per_element,
                                                 int                  in1_bytes_per_element,
                                                 int                  out_bytes_per_element,
                                                 int                  is_instantial = 1) {
    dim3                  threadsPerBlock;
    dim3                  blocksPerGrid;
    std::vector<uint32_t> params;
    RPPdeviceptr          devA;
    RPPdeviceptr          devB;
    bool                  ab_switched = false;

    if (axis <= 2 || axis == 6 || axis == 8) {
        devA = ctx.dev_in[0];
        devB = ctx.dev_in[1];
    } else {
        ab_switched           = true;
        devA                  = ctx.dev_in[1];
        devB                  = ctx.dev_in[0];
        int tmp               = in1_bytes_per_element;
        in1_bytes_per_element = in0_bytes_per_element;
        in0_bytes_per_element = tmp;
        if (axis != 7) {
            axis = axis - 3;
        }
    }

    RPPdeviceptr devC = ctx.dev_out[0];

    RPPdeviceptr dev_reciprocal_lut    = 0;
    int          reciprocal_table_bytes = 0;
    if (type == RPP_ELEMWISE_DIV) {
        reciprocal_table_bytes = 65536 * (int) sizeof(uint16_t);
        dev_reciprocal_lut     = rpp_elementwise_prepare_reciprocal_lut_workspace(ctx);
    }

    rppStreamBeginCapture(ctx.kernelStream, RPP_STREAM_CAPTURE_MODE_GLOBAL);
    rpp_module_load_once(ctx.rppBinMod, "rpp_kernel/elementwise.o");

    RPPdeviceptr sram_base                 = ctx.virtual_sram_base;
    RPPdeviceptr sramReciprocalTable       = sram_base;
    const int    padded_W                  = rpp_elementwise_round_up_to_32(W);
    const bool   use_row_tail_padding      = padded_W != W;
    const int    SRAM_LIMIT                = 22 * 1024 * 1024;
    // Pipeline path reserves SRAM for ping-pong staging, so each chunk only uses part of total SRAM.
    const int    PIPELINE_TILE_SRAM_BUDGET = SRAM_LIMIT / 2;
    const int    one_row_sram_bytes        = rpp_elementwise_get_tile_sram_bytes(
        1, W, axis, in0_bytes_per_element, in1_bytes_per_element, out_bytes_per_element, reciprocal_table_bytes);
    const int tile_sram_budget = std::max(PIPELINE_TILE_SRAM_BUDGET, one_row_sram_bytes);
    const int max_tile_h =
        rpp_elementwise_get_max_tile_rows(H, W, axis, in0_bytes_per_element, in1_bytes_per_element,
                                          out_bytes_per_element, reciprocal_table_bytes, tile_sram_budget);

    if (type == RPP_ELEMWISE_DIV) {
        rtMemcpyAsync((void *) sramReciprocalTable, (const void *) dev_reciprocal_lut, reciprocal_table_bytes,
                      rtMemcpyDeviceToSram, ctx.kernelStream);
    }

    const int max_tile_total_bytes =
        rpp_elementwise_get_tile_sram_bytes(max_tile_h, W, axis, in0_bytes_per_element, in1_bytes_per_element,
                                            out_bytes_per_element, reciprocal_table_bytes);
    const int    workspace_bytes_per_ping = rpp_elementwise_round_up(max_tile_total_bytes - reciprocal_table_bytes);
    RPPdeviceptr sramTileBase0            = sramReciprocalTable + reciprocal_table_bytes;
    RPPdeviceptr sramTileBase1            = sramTileBase0 + workspace_bytes_per_ping;
    const int total_pipeline_sram_bytes   = (int) (sramTileBase1 + (RPPdeviceptr) workspace_bytes_per_ping - sram_base);
    if (total_pipeline_sram_bytes > SRAM_LIMIT) {
        std::cerr << "SRAM overflow: need " << total_pipeline_sram_bytes << " bytes, but allocated " << SRAM_LIMIT
                  << " bytes\n";
        std::abort();
    }
    auto sram_tile_base = [&](int ping) {
        return ping ? sramTileBase1 : sramTileBase0;
    };

    auto copy_rows_from_dev_async = [&](RPPdeviceptr sramDst, RPPdeviceptr devSrc, int rows, int row_bytes_dst,
                                        int elem_bytes, RPPstream stream) {
        for (int h = 0; h < rows; ++h) {
            rtMemcpyAsync((void *) (sramDst + (RPPdeviceptr) h * row_bytes_dst),
                          (const void *) (devSrc + (RPPdeviceptr) h * W * elem_bytes), W * elem_bytes,
                          rtMemcpyDeviceToSram, stream);
        }
    };
    auto copy_scalar_from_dev_async = [&](RPPdeviceptr sramDst, RPPdeviceptr devSrc, int elem_bytes, RPPstream stream) {
        rtMemcpyAsync((void *) sramDst, (const void *) devSrc, elem_bytes, rtMemcpyDeviceToSram, stream);
    };

    struct tile_meta_t {
        int    tile_H;
        int    sizeA;
        int    sizeB;
        int    sizeC;
        int    row_bytes_bf16;
        int    sram_off_a_compact;
        int    sram_off_b_compact;
        int    sram_off_a_padded;
        int    sram_off_b_padded;
        int    sram_off_out_padded;
        int    sram_off_out_compact;
        size_t devA_offset;
        size_t devB_offset;
        size_t devC_offset;
    };

    auto schedule_dma = [&](int ping, const tile_meta_t & tile) {
        const int    tile_H      = tile.tile_H;
        const int    sizeA       = tile.sizeA;
        const int    sizeB       = tile.sizeB;
        const size_t devA_offset = tile.devA_offset;
        const size_t devB_offset = tile.devB_offset;

        const int total_sram_bytes =
            rpp_elementwise_get_tile_sram_bytes(tile_H, W, axis, in0_bytes_per_element, in1_bytes_per_element,
                                                out_bytes_per_element, reciprocal_table_bytes);
        assert(total_sram_bytes <= tile_sram_budget);
        assert(total_sram_bytes <= SRAM_LIMIT);

        rppStreamWaitEvent(ctx.dmaStream, ctx.kernel_done_ping[ping], 0);
        RPPdeviceptr sramTileBase = sram_tile_base(ping);
        if (use_row_tail_padding) {
            const int          row_bytes_bf16 = tile.row_bytes_bf16;
            const RPPdeviceptr sramACompact =
                tile.sram_off_a_compact >= 0 ? (sramTileBase + (RPPdeviceptr) tile.sram_off_a_compact) : 0;
            const RPPdeviceptr sramBCompact =
                tile.sram_off_b_compact >= 0 ? (sramTileBase + (RPPdeviceptr) tile.sram_off_b_compact) : 0;
            const RPPdeviceptr sramAPadded = sramTileBase + (RPPdeviceptr) tile.sram_off_a_padded;
            const RPPdeviceptr sramBPadded = sramTileBase + (RPPdeviceptr) tile.sram_off_b_padded;

            if (in0_bytes_per_element == (int) sizeof(float)) {
                rtMemcpyAsync((void *) sramACompact, (const void *) (devA + (RPPdeviceptr) devA_offset), sizeA,
                              rtMemcpyDeviceToSram, ctx.dmaStream);
            } else {
                copy_rows_from_dev_async(sramAPadded, devA + (RPPdeviceptr) devA_offset, tile_H, row_bytes_bf16,
                                         (int) sizeof(uint16_t), ctx.dmaStream);
            }

            if (in1_bytes_per_element == (int) sizeof(float)) {
                if (axis == 8) {
                    copy_scalar_from_dev_async(sramBCompact, devB + (RPPdeviceptr) devB_offset, in1_bytes_per_element,
                                               ctx.dmaStream);
                } else {
                    rtMemcpyAsync((void *) sramBCompact, (const void *) (devB + (RPPdeviceptr) devB_offset), sizeB,
                                  rtMemcpyDeviceToSram, ctx.dmaStream);
                }
            } else {
                if (axis == -1 || axis == 0) {
                    copy_rows_from_dev_async(sramBPadded, devB + (RPPdeviceptr) devB_offset, tile_H, row_bytes_bf16,
                                             (int) sizeof(uint16_t), ctx.dmaStream);
                } else if (axis == 8) {
                    copy_scalar_from_dev_async(sramBPadded, devB + (RPPdeviceptr) devB_offset, in1_bytes_per_element,
                                               ctx.dmaStream);
                } else {
                    rtMemcpyAsync((void *) sramBPadded, (const void *) (devB + (RPPdeviceptr) devB_offset),
                                  W * (int) sizeof(uint16_t), rtMemcpyDeviceToSram, ctx.dmaStream);
                }
            }
        } else {
            RPPdeviceptr sramA = sramTileBase;
            RPPdeviceptr sramB = sramA + rpp_elementwise_round_up(sizeA);
            rtMemcpyAsync((void *) sramA, (const void *) (devA + (RPPdeviceptr) devA_offset), sizeA,
                          rtMemcpyDeviceToSram, ctx.dmaStream);
            if (axis == 8) {
                copy_scalar_from_dev_async(sramB, devB + (RPPdeviceptr) devB_offset, in1_bytes_per_element,
                                           ctx.dmaStream);
            } else {
                rtMemcpyAsync((void *) sramB, (const void *) (devB + (RPPdeviceptr) devB_offset), sizeB,
                              rtMemcpyDeviceToSram, ctx.dmaStream);
            }
        }
        rppEventRecord(ctx.dma_done_ping[ping], ctx.dmaStream);
    };

    // Mark ping buffers as available before first prefetch.
    rppEventRecord(ctx.kernel_done_ping[0], ctx.kernelStream);
    rppEventRecord(ctx.kernel_done_ping[1], ctx.kernelStream);

    for (int c = 0; c < C; ++c) {
        const size_t devA_offset_base = (size_t) c * (size_t) H * (size_t) W * (size_t) in0_bytes_per_element;
        size_t       devB_offset_base = 0;
        if (axis == -1) {
            devB_offset_base = (size_t) c * (size_t) H * (size_t) W * (size_t) in1_bytes_per_element;
        } else if (axis == 1) {
            devB_offset_base = (size_t) c * (size_t) W * (size_t) in1_bytes_per_element;
        } else if (axis == 2) {
            devB_offset_base = (size_t) c * (size_t) H * (size_t) in1_bytes_per_element;
        }
        const size_t devC_offset_base = (size_t) c * (size_t) H * (size_t) W * (size_t) out_bytes_per_element;

        const int nr_of_tiles_h = (H + max_tile_h - 1) / max_tile_h;
        if (nr_of_tiles_h <= 0) {
            continue;
        }

        std::vector<tile_meta_t> tiles;
        tiles.reserve(nr_of_tiles_h);
        for (int tile_idx = 0; tile_idx < nr_of_tiles_h; ++tile_idx) {
            const int    h_begin = tile_idx * max_tile_h;
            const int    tile_H  = std::min(max_tile_h, H - h_begin);
            const int    sizeA   = tile_H * W * in0_bytes_per_element;
            const int    sizeB   = rpp_elementwise_get_input1_bytes(axis, tile_H, W, in1_bytes_per_element);
            const int    sizeC   = tile_H * W * out_bytes_per_element;
            const size_t devA_offset =
                devA_offset_base + (size_t) h_begin * (size_t) W * (size_t) in0_bytes_per_element;
            size_t devB_offset = devB_offset_base;
            if (axis == -1 || axis == 0) {
                devB_offset += (size_t) h_begin * (size_t) W * (size_t) in1_bytes_per_element;
            } else if (axis == 2) {
                devB_offset += (size_t) h_begin * (size_t) in1_bytes_per_element;
            }
            const size_t devC_offset =
                devC_offset_base + (size_t) h_begin * (size_t) W * (size_t) out_bytes_per_element;
            tile_meta_t tile = {};
            tile.tile_H      = tile_H;
            tile.sizeA       = sizeA;
            tile.sizeB       = sizeB;
            tile.sizeC       = sizeC;
            tile.devA_offset = devA_offset;
            tile.devB_offset = devB_offset;
            tile.devC_offset = devC_offset;

            if (use_row_tail_padding) {
                const int row_bytes_bf16 = padded_W * (int) sizeof(uint16_t);
                const int sizeA_compact  = sizeA;
                const int sizeB_compact  = sizeB;
                const int sizeA_padded   = tile_H * row_bytes_bf16;
                const int sizeB_padded   = (axis == -1 || axis == 0) ? tile_H * row_bytes_bf16 :
                                           (axis == 8) ? (int) sizeof(uint16_t) : row_bytes_bf16;
                const int sizeOut_padded = tile_H * row_bytes_bf16;

                int sram_cursor        = 0;
                int sram_off_a_compact = -1;
                int sram_off_b_compact = -1;
                if (in0_bytes_per_element == (int) sizeof(float)) {
                    sram_off_a_compact = sram_cursor;
                    sram_cursor += rpp_elementwise_round_up(sizeA_compact);
                }
                if (in1_bytes_per_element == (int) sizeof(float)) {
                    sram_off_b_compact = sram_cursor;
                    sram_cursor += rpp_elementwise_round_up(sizeB_compact);
                }

                const int sram_off_a_padded = sram_cursor;
                sram_cursor += rpp_elementwise_round_up(sizeA_padded);
                const int sram_off_b_padded = sram_cursor;
                sram_cursor += rpp_elementwise_round_up(sizeB_padded);
                const int sram_off_out_padded = sram_cursor;
                sram_cursor += rpp_elementwise_round_up(sizeOut_padded);

                int sram_off_out_compact = -1;
                if (out_bytes_per_element == (int) sizeof(float)) {
                    if (sram_off_a_compact >= 0) {
                        sram_off_out_compact = sram_off_a_compact;
                    } else if (sram_off_b_compact >= 0) {
                        sram_off_out_compact = sram_off_b_compact;
                    } else {
                        sram_off_out_compact = sram_cursor;
                        sram_cursor += rpp_elementwise_round_up(sizeC);
                    }
                }

                const int total_sram_bytes_padded =
                    (int) ((sram_tile_base(1) + (RPPdeviceptr) sram_cursor) - sram_base);
                if (total_sram_bytes_padded > SRAM_LIMIT) {
                    std::cerr << "SRAM overflow: need " << total_sram_bytes_padded << " bytes, but allocated "
                              << SRAM_LIMIT << " bytes\n";
                    std::abort();
                }

                tile.row_bytes_bf16       = row_bytes_bf16;
                tile.sram_off_a_compact   = sram_off_a_compact;
                tile.sram_off_b_compact   = sram_off_b_compact;
                tile.sram_off_a_padded    = sram_off_a_padded;
                tile.sram_off_b_padded    = sram_off_b_padded;
                tile.sram_off_out_padded  = sram_off_out_padded;
                tile.sram_off_out_compact = sram_off_out_compact;
            }
            tiles.push_back(tile);
        }

        schedule_dma(0, tiles[0]);
        for (int tile_idx = 0; tile_idx < nr_of_tiles_h; ++tile_idx) {
            const int           ping        = tile_idx & 1;
            const tile_meta_t & tile        = tiles[tile_idx];
            const int           tile_H      = tile.tile_H;
            const int           sizeA       = tile.sizeA;
            const int           sizeB       = tile.sizeB;
            const int           sizeC       = tile.sizeC;
            const size_t        devC_offset = tile.devC_offset;

            rppStreamWaitEvent(ctx.kernelStream, ctx.dma_done_ping[ping], 0);
            if (tile_idx + 1 < nr_of_tiles_h) {
                schedule_dma((tile_idx + 1) & 1, tiles[tile_idx + 1]);
            }

            RPPdeviceptr sramTileBase = sram_tile_base(ping);
            if (use_row_tail_padding) {
                assert(axis != 2);
                assert(padded_W < 8192);

                const int          row_bytes_bf16 = tile.row_bytes_bf16;
                const RPPdeviceptr sramACompact =
                    tile.sram_off_a_compact >= 0 ? (sramTileBase + (RPPdeviceptr) tile.sram_off_a_compact) : 0;
                const RPPdeviceptr sramBCompact =
                    tile.sram_off_b_compact >= 0 ? (sramTileBase + (RPPdeviceptr) tile.sram_off_b_compact) : 0;
                const RPPdeviceptr sramAPadded   = sramTileBase + (RPPdeviceptr) tile.sram_off_a_padded;
                const RPPdeviceptr sramBPadded   = sramTileBase + (RPPdeviceptr) tile.sram_off_b_padded;
                const RPPdeviceptr sramOutPadded = sramTileBase + (RPPdeviceptr) tile.sram_off_out_padded;
                const RPPdeviceptr sramOutCompact =
                    tile.sram_off_out_compact >= 0 ? (sramTileBase + (RPPdeviceptr) tile.sram_off_out_compact) : 0;

                auto convert_rows_f32_to_bf16 = [&](RPPdeviceptr sramSrcCompact, RPPdeviceptr sramDstPadded, int rows) {
                    for (int h = 0; h < rows; ++h) {
                        calc_tbdim_flattern(1, W, threadsPerBlock, blocksPerGrid);
                        params.clear();
                        cvt_kernel_param_init(
                            threadsPerBlock, (uint32_t) (sramSrcCompact + (RPPdeviceptr) h * W * (int) sizeof(float)),
                            (uint32_t) (sramDstPadded + (RPPdeviceptr) h * row_bytes_bf16), kFLOAT, kBF16, params);
                        launchWrapperAysnc("opt_vector_cvt_32_16", blocksPerGrid, threadsPerBlock, params,
                                           ctx.rppBinMod, ctx.kernelStream);
                    }
                };

                if (in0_bytes_per_element == (int) sizeof(float)) {
                    convert_rows_f32_to_bf16(sramACompact, sramAPadded, tile_H);
                }

                if (in1_bytes_per_element == (int) sizeof(float)) {
                    if (axis == -1 || axis == 0) {
                        convert_rows_f32_to_bf16(sramBCompact, sramBPadded, tile_H);
                    } else if (axis == 8) {
                        calc_tbdim_flattern(1, 1, threadsPerBlock, blocksPerGrid);
                        params.clear();
                        cvt_kernel_param_init(threadsPerBlock, (uint32_t) sramBCompact, (uint32_t) sramBPadded, kFLOAT,
                                              kBF16, params);
                        launchWrapperAysnc("opt_vector_cvt_32_16", blocksPerGrid, threadsPerBlock, params,
                                           ctx.rppBinMod, ctx.kernelStream);
                    } else {
                        calc_tbdim_flattern(1, W, threadsPerBlock, blocksPerGrid);
                        params.clear();
                        cvt_kernel_param_init(threadsPerBlock, (uint32_t) sramBCompact, (uint32_t) sramBPadded, kFLOAT,
                                              kBF16, params);
                        launchWrapperAysnc("opt_vector_cvt_32_16", blocksPerGrid, threadsPerBlock, params,
                                           ctx.rppBinMod, ctx.kernelStream);
                    }
                }

                if (type == RPP_ELEMWISE_DIV) {
                    RPPdeviceptr reciprocalInput = ab_switched ? sramAPadded : sramBPadded;
                    const int    reciprocalRows  = (ab_switched || axis == -1 || axis == 0) ? tile_H : 1;
                    for (int h = 0; h < reciprocalRows; ++h) {
                        calc_tbdim_flattern(1, W, threadsPerBlock, blocksPerGrid);
                        params.clear();
                        params.emplace_back((uint32_t) (reciprocalInput + (RPPdeviceptr) h * row_bytes_bf16));
                        params.emplace_back((uint32_t) (reciprocalInput + (RPPdeviceptr) h * row_bytes_bf16));
                        params.emplace_back((uint32_t) sramReciprocalTable);
                        params.emplace_back(threadsPerBlock.x * threadsPerBlock.y * threadsPerBlock.z *
                                            sizeof(uint16_t));
                        launchWrapperAysnc("mish_f16", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                           ctx.kernelStream);
                    }
                }

                threadsPerBlock.x = padded_W;
                threadsPerBlock.y = 1;
                threadsPerBlock.z = 1;
                blocksPerGrid.x   = 1;
                blocksPerGrid.y   = 1;
                blocksPerGrid.z   = 1;
                while (threadsPerBlock.x * threadsPerBlock.y * threadsPerBlock.z <= 32) {
                    threadsPerBlock.y++;
                }

                params.clear();
                params.emplace_back((uint32_t) sramAPadded);
                params.emplace_back((uint32_t) sramBPadded);
                params.emplace_back((uint32_t) sramOutPadded);
                params.emplace_back(row_bytes_bf16);
                params.emplace_back(rpp_elementwise_input1_is_row_broadcast(axis) ? 0 : row_bytes_bf16);
                params.emplace_back(tile_H);
                params.emplace_back(padded_W);
                params.emplace_back(rpp_elementwise_input1_is_row_broadcast(axis) ? 0 : padded_W);
                if (type == RPP_ELEMWISE_ADD) {
                    launchWrapperAysnc("elementwise_add", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                       ctx.kernelStream);
                } else if (type == RPP_ELEMWISE_MUL || type == RPP_ELEMWISE_DIV) {
                    launchWrapperAysnc("elementwise_mul", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                       ctx.kernelStream);
                } else {
                    assert(0);
                }

                if (out_bytes_per_element == (int) sizeof(float)) {
                    for (int h = 0; h < tile_H; ++h) {
                        calc_tbdim_flattern(1, W * 2, threadsPerBlock, blocksPerGrid);
                        params.clear();
                        cvt_kernel_param_init_opt(
                            threadsPerBlock, (uint32_t) (sramOutPadded + (RPPdeviceptr) h * row_bytes_bf16),
                            (uint32_t) (sramOutCompact + (RPPdeviceptr) h * W * (int) sizeof(float)), kBF16, kFLOAT,
                            params);
                        launchWrapperAysnc("opt_vector_cvt_f16_f32_opt", blocksPerGrid, threadsPerBlock, params,
                                           ctx.rppBinMod, ctx.kernelStream);
                    }
                    rtMemcpyAsync((void *) (devC + (RPPdeviceptr) devC_offset), (const void *) sramOutCompact, sizeC,
                                  rtMemcpySramToDevice, ctx.kernelStream);
                } else {
                    for (int h = 0; h < tile_H; ++h) {
                        rtMemcpyAsync((void *) (devC + (RPPdeviceptr) devC_offset +
                                                (RPPdeviceptr) h * W * (int) sizeof(uint16_t)),
                                      (const void *) (sramOutPadded + (RPPdeviceptr) h * row_bytes_bf16),
                                      W * (int) sizeof(uint16_t), rtMemcpySramToDevice, ctx.kernelStream);
                    }
                }
            } else {
                RPPdeviceptr sramA = sramTileBase;
                RPPdeviceptr sramB = sramA + rpp_elementwise_round_up(sizeA);
                RPPdeviceptr sramC = sramB + rpp_elementwise_round_up(sizeB);

                if (in0_bytes_per_element == (int) sizeof(float)) {
                    calc_tbdim_flattern(tile_H, W, threadsPerBlock, blocksPerGrid);
                    params.clear();
                    cvt_kernel_param_init(threadsPerBlock, (uint32_t) sramA, (uint32_t) sramA, kFLOAT, kBF16, params);
                    launchWrapperAysnc("opt_vector_cvt_32_16", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                       ctx.kernelStream);
                }

                if (in1_bytes_per_element == (int) sizeof(float)) {
                    if (axis == -1 || axis == 0) {
                        calc_tbdim_flattern(tile_H, W, threadsPerBlock, blocksPerGrid);
                    } else if (axis == 8) {
                        calc_tbdim_flattern(1, 1, threadsPerBlock, blocksPerGrid);
                    } else if (rpp_elementwise_input1_is_row_broadcast(axis)) {
                        calc_tbdim_flattern(1, W, threadsPerBlock, blocksPerGrid);
                    } else if (axis == 2) {
                        calc_tbdim_flattern(1, tile_H, threadsPerBlock, blocksPerGrid);
                    } else {
                        throw std::runtime_error("Unsupported elementwise broadcast axis");
                    }
                    params.clear();
                    cvt_kernel_param_init(threadsPerBlock, (uint32_t) sramB, (uint32_t) sramB, kFLOAT, kBF16, params);
                    launchWrapperAysnc("opt_vector_cvt_32_16", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                       ctx.kernelStream);
                }

                if (type == RPP_ELEMWISE_DIV) {
                    if (ab_switched) {
                        calc_tbdim_flattern(tile_H, W, threadsPerBlock, blocksPerGrid);
                        params.clear();
                        params.emplace_back((uint32_t) sramA);
                        params.emplace_back((uint32_t) sramA);
                        params.emplace_back((uint32_t) sramReciprocalTable);
                        params.emplace_back(threadsPerBlock.x * threadsPerBlock.y * threadsPerBlock.z *
                                            sizeof(uint16_t));
                        launchWrapperAysnc("mish_f16", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                           ctx.kernelStream);
                    } else {
                        if (axis == -1 || axis == 0) {
                            calc_tbdim_flattern(tile_H, W, threadsPerBlock, blocksPerGrid);
                        } else if (axis == 8) {
                            calc_tbdim_flattern(1, 1, threadsPerBlock, blocksPerGrid);
                        } else if (rpp_elementwise_input1_is_row_broadcast(axis)) {
                            calc_tbdim_flattern(1, W, threadsPerBlock, blocksPerGrid);
                        } else if (axis == 2) {
                            calc_tbdim_flattern(1, tile_H, threadsPerBlock, blocksPerGrid);
                        } else {
                            throw std::runtime_error("Unsupported elementwise broadcast axis");
                        }
                        params.clear();
                        params.emplace_back((uint32_t) sramB);
                        params.emplace_back((uint32_t) sramB);
                        params.emplace_back((uint32_t) sramReciprocalTable);
                        params.emplace_back(threadsPerBlock.x * threadsPerBlock.y * threadsPerBlock.z *
                                            sizeof(uint16_t));
                        launchWrapperAysnc("mish_f16", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                           ctx.kernelStream);
                    }
                }

                if (W * tile_H < 8192 && !rpp_elementwise_input1_is_row_broadcast(axis)) {
                    threadsPerBlock.x = W;
                    threadsPerBlock.y = 1;
                    threadsPerBlock.z = tile_H;
                    blocksPerGrid.x   = 1;
                    blocksPerGrid.y   = 1;
                    blocksPerGrid.z   = 1;
                } else if (W < 8192) {
                    threadsPerBlock.x = W;
                    threadsPerBlock.y = 1;
                    threadsPerBlock.z = 1;
                    blocksPerGrid.x   = 1;
                    blocksPerGrid.y   = 1;
                    blocksPerGrid.z   = tile_H;
                } else {
                    throw std::runtime_error("Elementwise Width is Too Big");
                }

                while (threadsPerBlock.x * threadsPerBlock.y * threadsPerBlock.z <= 32) {
                    threadsPerBlock.y++;
                }

                const uint32_t input0 = (uint32_t) sramA;
                const uint32_t input1 = (uint32_t) sramB;
                const uint32_t out_addr =
                    out_bytes_per_element == (int) sizeof(float) ? (uint32_t) sramA : (uint32_t) sramC;
                uint32_t loop     = blocksPerGrid.z;
                uint32_t offset0  = threadsPerBlock.x * threadsPerBlock.z * sizeof(uint16_t);
                uint32_t stridez0 = threadsPerBlock.x;
                uint32_t offset1  = threadsPerBlock.x * threadsPerBlock.z * sizeof(uint16_t);
                uint32_t stridez1 = threadsPerBlock.x;
                blocksPerGrid.z   = 1;
                if (rpp_elementwise_input1_is_row_broadcast(axis)) {
                    offset1  = 0;
                    stridez1 = 0;
                }

                params.clear();
                if (axis == 2) {
                    if (threadsPerBlock.z > 1) {
                        unsigned int tmp  = threadsPerBlock.z;
                        threadsPerBlock.z = threadsPerBlock.y;
                        threadsPerBlock.y = tmp;
                    }
                    params.emplace_back(input0);
                    params.emplace_back(input1);
                    params.emplace_back(out_addr);
                    params.emplace_back(threadsPerBlock.x * threadsPerBlock.y * sizeof(uint16_t));
                    params.emplace_back(threadsPerBlock.y * sizeof(uint16_t));
                    if (type == RPP_ELEMWISE_ADD) {
                        params.emplace_back(0);
                    } else if (type == RPP_ELEMWISE_MUL || type == RPP_ELEMWISE_DIV) {
                        params.emplace_back(1);
                    } else {
                        assert(0);
                    }
                    blocksPerGrid.z = loop;
                    launchWrapperAysnc("opt_binary_bc_x", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                       ctx.kernelStream);
                } else {
                    params.emplace_back(input0);
                    params.emplace_back(input1);
                    params.emplace_back(out_addr);
                    params.emplace_back(offset0);
                    params.emplace_back(offset1);
                    params.emplace_back(loop);
                    params.emplace_back(stridez0);
                    params.emplace_back(stridez1);
                    if (type == RPP_ELEMWISE_ADD) {
                        launchWrapperAysnc("elementwise_add", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                           ctx.kernelStream);
                    } else if (type == RPP_ELEMWISE_MUL || type == RPP_ELEMWISE_DIV) {
                        launchWrapperAysnc("elementwise_mul", blocksPerGrid, threadsPerBlock, params, ctx.rppBinMod,
                                           ctx.kernelStream);
                    } else {
                        assert(0);
                    }
                }

                if (out_bytes_per_element == (int) sizeof(float)) {
                    params.clear();
                    calc_tbdim_flattern(tile_H, W * 2, threadsPerBlock, blocksPerGrid);
                    cvt_kernel_param_init_opt(threadsPerBlock, (uint32_t) sramA, (uint32_t) sramC, kBF16, kFLOAT,
                                              params);
                    launchWrapperAysnc("opt_vector_cvt_f16_f32_opt", blocksPerGrid, threadsPerBlock, params,
                                       ctx.rppBinMod, ctx.kernelStream);

                    rtMemcpyAsync((void *) (devC + (RPPdeviceptr) devC_offset), (const void *) sramC, sizeC,
                                  rtMemcpySramToDevice, ctx.kernelStream);
                } else {
                    rtMemcpyAsync((void *) (devC + (RPPdeviceptr) devC_offset), (const void *) sramC, sizeC,
                                  rtMemcpySramToDevice, ctx.kernelStream);
                }
            }

            rppEventRecord(ctx.kernel_done_ping[ping], ctx.kernelStream);
        }
    }

    rppStreamEndCapture(ctx.kernelStream, &ctx.graph);
    const std::string graph_key =
        rpp_join_function_name_and_args(__func__, (int) type, C, H, W, axis, in0_bytes_per_element,
                                        in1_bytes_per_element, out_bytes_per_element);
    if (rpp_graph_instantiate(ctx.graphexec, ctx.graph, graph_key.c_str(), is_instantial) != RPP_SUCCESS) {
        throw std::runtime_error("rpp_graph_instantiate failed.");
    }

}

// -----------------------------
// Build graph once
// -----------------------------
static void rpp_elementwise_build(rpp_kernel_context & ctx,
                                  rppElementWiseType   type,
                                  int                  C,
                                  int                  H,
                                  int                  W,
                                  int                  axis,
                                  int                  in0_bytes_per_element,
                                  int                  in1_bytes_per_element,
                                  int                  out_bytes_per_element,
                                  int                  use_pipeline  = 0,
                                  int                  is_instantial = 1) {
    if (type == RPP_ELEMWISE_MUL && rpp_elementwise_input1_is_scalar_broadcast(axis)) {
        (void) use_pipeline;
        rpp_elementwise_build_mul_broadcast(ctx, C, H, W, axis, in0_bytes_per_element, in1_bytes_per_element,
                                            out_bytes_per_element, is_instantial);
        return;
    }
    if (W >= 8192 && (axis == -1 || axis == 0) &&
        (type == RPP_ELEMWISE_ADD || type == RPP_ELEMWISE_MUL)) {
        rpp_elementwise_build_wide_rows(ctx, type, C, H, W, axis, in0_bytes_per_element, in1_bytes_per_element,
                                        out_bytes_per_element, is_instantial);
        return;
    }

    // if (use_pipeline) {
    //     rpp_elementwise_build_tiled_pipeline(ctx, type, C, H, W, axis, in0_bytes_per_element, in1_bytes_per_element,
    //                                         out_bytes_per_element, is_instantial);
    // } else {
    //     rpp_elementwise_build_tiled(ctx, type, C, H, W, axis, in0_bytes_per_element, in1_bytes_per_element,
    //                             out_bytes_per_element, is_instantial);

    // }
    rpp_elementwise_build_tiled(ctx, type, C, H, W, axis, in0_bytes_per_element, in1_bytes_per_element,
                                out_bytes_per_element, is_instantial);
}
